# School Portal SaaS — Production Deployment & Release Management Guide

This guide details the complete production deployment, release management, disaster recovery, and operational procedures for **School Portal SaaS**.

---

## 1. System Requirements & Prerequisites

### 1.1 Operating System & Hardware
- **OS**: Ubuntu 22.04 LTS / 24.04 LTS, Debian 12, Rocky Linux 9, or Windows Server 2022+
- **Compute**: Minimum 2 vCPU, 4 GB RAM (Recommended: 4 vCPU, 8 GB RAM for > 50 institutions)
- **Disk**: 50 GB+ SSD / NVMe with high IOPS for database and document storage

### 1.2 Software Stack
- **PHP**: PHP 8.2+ (Strict types enabled)
  - Required Extensions: `pdo`, `pdo_mysql`, `mbstring`, `openssl`, `json`, `curl`, `session`, `tokenizer`, `fileinfo`
  - Recommended Extensions: `gd`, `zip`, `opcache`
- **Database**: MySQL 8.0+ or MariaDB 10.5+ with InnoDB engine and `utf8mb4` charset
- **Web Server**: Nginx 1.22+ with PHP-FPM or Apache 2.4+ (`mod_rewrite`, `mod_headers`)
- **Process Supervisor**: Systemd or Supervisor for `worker.php` background queue processing

---

## 2. Environment Configuration & Secrets Management

### 2.1 Initial Configuration
```bash
# Clone or extract application into production root
cd /var/www/schoolportal

# Copy production environment template
cp .env.example .env

# Restrict file permissions on secrets
chmod 600 .env
chmod -R 775 storage
```

### 2.2 Production Environment Variables (`.env`)
Configure the following required production parameters:

```ini
# Application Identity & Separation
APP_NAME="SchoolPortal SaaS"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://portal.yourdomain.com
APP_TIMEZONE=UTC
APP_LOCALE=en

# Session Hardening
SESSION_NAME=SCHOOLPORTAL_SESSID
SESSION_LIFETIME=7200
SESSION_SECURE=true
SESSION_SAMESITE=Lax

# Disaster Recovery AES-256 Vault Key (Must be 32+ characters)
# Generate with: php -r "echo bin2hex(random_bytes(16));"
BACKUP_ENCRYPTION_KEY=YOUR_SECURE_32_BYTE_HEX_KEY_HERE_REPLACE_ME

# Database Connection
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=school_portal
DB_USERNAME=school_portal_user
DB_PASSWORD=YOUR_STRONG_DATABASE_PASSWORD
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci

# Cache & Asynchronous Background Queues
CACHE_DRIVER=file
QUEUE_CONNECTION=database

# Optional AI Assistant Gateway
AI_PROVIDER=gemini
GEMINI_API_KEY=
GEMINI_MODEL=gemini-1.5-flash
```

---

## 3. Web Server Configuration

### 3.1 Nginx Production Virtual Host Configuration
Save as `/etc/nginx/sites-available/schoolportal.conf`:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name portal.yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name portal.yourdomain.com;

    root /var/www/schoolportal/public;
    index index.php;

    # SSL Certificates
    ssl_certificate /etc/letsencrypt/live/portal.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/portal.yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Enterprise Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Max Upload Payload (matches app configuration)
    client_max_body_size 25M;

    # Static Assets Caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|woff2|woff|ttf|svg)$ {
        expires 30d;
        add_header Cache-Control "public, no-transform";
        access_log off;
    }

    # Deny access to sensitive files and hidden dotfiles
    location ~ /\.(?!well-known).* {
        deny all;
    }

    location ~ ^/(storage|database|config|core|routes|bin|tests)/ {
        deny all;
        return 404;
    }

    # Primary Front Controller Routing
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    # PHP-FPM Handler
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT $realpath_root;
        fastcgi_hide_header X-Powered-By;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
        fastcgi_read_timeout 120s;
    }
}
```

Enable and restart Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/schoolportal.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 4. Background Queue Worker Setup

The platform uses an asynchronous database queue engine (`platform_jobs`, `platform_job_runs`) for chunked bulk imports, large CSV/Excel report generation, and notification delivery.

### 4.1 Systemd Worker Service
Create `/etc/systemd/system/schoolportal-worker.service`:

```ini
[Unit]
Description=School Portal SaaS Asynchronous Queue Worker
After=network.target mysql.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/schoolportal
ExecStart=/usr/bin/php /var/www/schoolportal/worker.php
Restart=always
RestartSec=5
StandardOutput=append:/var/www/schoolportal/storage/logs/worker.log
StandardError=append:/var/www/schoolportal/storage/logs/worker_error.log

[Install]
WantedBy=multi-user.target
```

Enable and start the worker daemon:
```bash
sudo systemctl daemon-reload
sudo systemctl enable schoolportal-worker.service
sudo systemctl start schoolportal-worker.service
sudo systemctl status schoolportal-worker.service
```

---

## 5. Scheduled Automation & Cron Jobs

Install application crontab for user `www-data`:
```bash
sudo crontab -u www-data -e
```

Add the following schedule entries:
```cron
# Run background automation tasks and queued schedules every minute
* * * * * php /var/www/schoolportal/cron/scheduler.php > /dev/null 2>&1

# Daily institutional database health check and diagnostic audit at 02:00 UTC
0 2 * * * php /var/www/schoolportal/bin/pre_release_check.php > /var/www/schoolportal/storage/logs/daily_audit.log 2>&1

# Daily automated encrypted snapshot backup at 03:00 UTC
0 3 * * * php -r "require '/var/www/schoolportal/core/bootstrap.php'; (new App\Services\BackupRecoveryService())->createBackup(0, 1, 'full_database');" > /dev/null 2>&1
```

---

## 6. Database Migration & Schema Management

All database schema evolutions are managed and tracked using `bin/migrate.php`.

### 6.1 Checking Migration Status
```bash
php bin/migrate.php status
```
Outputs a table of all migrations, batch numbers, durations, and flags any altered checksums.

### 6.2 Applying Migrations
```bash
# In production, this automatically captures an AES-256 encrypted snapshot first
php bin/migrate.php migrate

# Or skip backup if taking an external snapshot
php bin/migrate.php migrate --skip-backup
```

### 6.3 Rolling Back Migrations
```bash
# Roll back the most recent batch
php bin/migrate.php rollback

# Roll back multiple batches
php bin/migrate.php rollback --batches=2
```

### 6.4 Creating a New Migration
```bash
php bin/migrate.php create add_medical_records_table
```
Generates a timestamped class file in `database/migrations/` implementing `up()` and `down()`.

---

## 7. Standard Release & Deployment Workflow

Follow this procedure for safe, zero-downtime or low-downtime production updates:

### Step 1: Engage Maintenance Mode
```bash
# Activates HTTP 503 with a bypass token for the deployment engineer
php bin/maintenance.php down --secret=DeploySafeSecretKey2026 --retry=300
```
- Visitors receive a branded 503 Maintenance page with auto-refresh.
- API consumers receive structured JSON: `{"status": 503, "error": {"code": "MAINTENANCE_MODE"}}`.
- Engineers can bypass maintenance mode via: `https://portal.yourdomain.com/?bypass=DeploySafeSecretKey2026`.

### Step 2: Fetch Release Artifacts
```bash
git fetch origin
git checkout tags/v2.4.0
```

### Step 3: Run Database Migrations
```bash
php bin/migrate.php migrate
```
If any error occurs, the pre-migration snapshot is automatically referenced for rollback.

### Step 4: Run Automated Pre-Release Verification Suite
```bash
php bin/pre_release_check.php
```
Validates all 10 operational dimensions:
1. PHP Runtime & Extensions
2. Environment Security Configuration
3. Filesystem Storage Permissions
4. Database Health, InnoDB & Latency
5. Database Migration Status
6. Referential Data Integrity & Orphaned Records
7. Multi-Tenant Data Isolation
8. Auth, RBAC & CSRF Protection
9. Cache & Background Queue Telemetry
10. Critical Operational Workflows

### Step 5: Restart Workers & Flush Tenant Caches
```bash
sudo systemctl restart schoolportal-worker.service
php -r "require 'core/bootstrap.php'; Core\Cache::flushAll();"
```

### Step 6: Disengage Maintenance Mode
```bash
php bin/maintenance.php up
```

---

## 8. Rollback & Emergency Recovery Strategy

If an unexpected regression or deployment defect is identified:

### 8.1 Fast Code Rollback
```bash
# Rollback code to previous release tag
git checkout tags/v2.3.9

# Rollback last migration batch
php bin/migrate.php rollback

# Restart workers
sudo systemctl restart schoolportal-worker.service
```

### 8.2 Database Restoration from Snapshot
In the event of catastrophic data corruption or irrecoverable schema failure:
1. Locate the pre-migration snapshot in `storage/backups/tenant_0/` or list via:
   ```bash
   php -r "require 'core/bootstrap.php'; print_r((new App\Services\BackupRecoveryService())->getBackups(0));"
   ```
2. Run integrity verification (non-destructive):
   ```bash
   php -r "require 'core/bootstrap.php'; var_dump((new App\Services\BackupRecoveryService())->verifyBackupIntegrity(0, BACKUP_ID));"
   ```
3. Run dry-run simulation:
   ```bash
   php -r "require 'core/bootstrap.php'; var_dump((new App\Services\BackupRecoveryService())->dryRunRestorationSandbox(0, BACKUP_ID));"
   ```

---

## 9. Observability & Health Monitoring

### 9.1 Machine-Readable Health Endpoint
For integration with external monitoring systems (Datadog, New Relic, Uptime Kuma, AWS Route53):
```http
GET https://portal.yourdomain.com/api/v1/system/health
```
Delivers real-time telemetry:
```json
{
  "status": "healthy",
  "version": "2.4.0",
  "database": {
    "status": "connected",
    "latency_ms": 2.15
  },
  "cache": {
    "driver": "file",
    "status": "operational"
  },
  "queue": {
    "pending_jobs": 0,
    "failed_jobs": 0
  },
  "storage": {
    "logs_writable": true,
    "cache_writable": true,
    "backups_writable": true
  }
}
```

### 9.2 Structured JSON Logs
Application logs are written daily with automatic credential and PII scrubbing:
```bash
tail -f storage/logs/schoolportal-$(date +%Y-%m-%d).log
```

---

## 10. Security & Verification Checklist Before Go-Live

- [x] PHP 8.2+ verified with all core extensions
- [x] Database engine is InnoDB and character set is `utf8mb4`
- [x] Strict tenant isolation enforced with indexed `school_id`
- [x] CSRF protection active on all state-altering requests
- [x] Sensitive credentials scrubbed from logs and stack traces
- [x] Database migrations tracked and verified with SHA-256 checksums
- [x] Automated pre-migration backups enabled
- [x] Maintenance mode gated with HTTP 503 and bypass token support
- [x] Automated pre-release checks passing 10/10 with status 0
