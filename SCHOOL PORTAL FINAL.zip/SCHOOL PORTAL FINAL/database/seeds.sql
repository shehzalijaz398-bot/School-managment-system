-- Seed data for School Portal Phase 1
-- Default password for all accounts: Password@123

USE school_portal;
SET NAMES utf8mb4;

INSERT INTO schools (id, name, code, email, phone, address, status, created_at, updated_at) VALUES
(1, 'Greenfield International School', 'GIS001', 'admin@greenfield.edu', '+92-300-0000001', '123 Education Avenue, Karachi', 1, NOW(), NOW());

INSERT INTO roles (id, school_id, name, slug, description, is_system, created_at, updated_at) VALUES
(1, 1, 'Principal', 'principal', 'Highest operational authority', 1, NOW(), NOW()),
(2, 1, 'Teacher', 'teacher', 'Teaching staff', 1, NOW(), NOW()),
(3, 1, 'HR', 'hr', 'Human resources', 1, NOW(), NOW()),
(4, 1, 'Finance', 'finance', 'Accounts and finance', 1, NOW(), NOW()),
(5, 1, 'Receptionist', 'receptionist', 'Front desk / school admin', 1, NOW(), NOW()),
(6, 1, 'Parent', 'parent', 'Parent / guardian portal', 1, NOW(), NOW()),
(7, 1, 'School Admin', 'school_admin', 'Technical school administrator', 1, NOW(), NOW());

INSERT INTO permissions (name, slug, module, created_at) VALUES
('View Students', 'students.view', 'students', NOW()),
('Create Students', 'students.create', 'students', NOW()),
('Edit Students', 'students.edit', 'students', NOW()),
('Delete Students', 'students.delete', 'students', NOW()),
('View Teachers', 'teachers.view', 'teachers', NOW()),
('Create Teachers', 'teachers.create', 'teachers', NOW()),
('Edit Teachers', 'teachers.edit', 'teachers', NOW()),
('Delete Teachers', 'teachers.delete', 'teachers', NOW()),
('View Classes', 'classes.view', 'classes', NOW()),
('Manage Classes', 'classes.manage', 'classes', NOW()),
('Mark Student Attendance', 'attendance.students.mark', 'attendance', NOW()),
('View Student Attendance', 'attendance.students.view', 'attendance', NOW()),
('Mark Staff Attendance', 'attendance.staff.mark', 'attendance', NOW()),
('View Staff Attendance', 'attendance.staff.view', 'attendance', NOW()),
('Create Assignments', 'assignments.create', 'assignments', NOW()),
('Grade Assignments', 'assignments.grade', 'assignments', NOW()),
('View Assignments', 'assignments.view', 'assignments', NOW()),
('Manage Exams', 'exams.manage', 'exams', NOW()),
('View Exams', 'exams.view', 'exams', NOW()),
('Manage Grades', 'grades.manage', 'grades', NOW()),
('View Grades', 'grades.view', 'grades', NOW()),
('View Finance', 'finance.view', 'finance', NOW()),
('Manage Finance', 'finance.manage', 'finance', NOW()),
('Manage Payroll', 'payroll.manage', 'payroll', NOW()),
('Approve Payroll', 'payroll.approve', 'payroll', NOW()),
('Manage HR', 'hr.manage', 'hr', NOW()),
('Manage Recruitment', 'recruitment.manage', 'hr', NOW()),
('View Reports', 'reports.view', 'reports', NOW()),
('Manage Settings', 'settings.manage', 'settings', NOW()),
('View Audit Logs', 'audit.view', 'audit', NOW()),
('Manage Announcements', 'announcements.manage', 'announcements', NOW()),
('Manage Admissions', 'admissions.manage', 'admissions', NOW()),
('Manage Timetable', 'timetable.manage', 'timetable', NOW()),
('View Timetable', 'timetable.view', 'timetable', NOW()),
('Manage Leave', 'leave.manage', 'leave', NOW()),
('Request Leave', 'leave.request', 'leave', NOW()),
('Approve Leave', 'leave.approve', 'leave', NOW()),
('Manage Employees', 'employees.manage', 'hr', NOW()),
('View Parent Portal', 'parent.portal', 'parents', NOW()),
('Reception Manage', 'reception.manage', 'reception', NOW());

-- Principal: almost everything
INSERT INTO role_permissions (role_id, permission_id)
SELECT 1, id FROM permissions WHERE slug NOT IN ('assignments.create', 'assignments.grade');

-- Teacher
INSERT INTO role_permissions (role_id, permission_id)
SELECT 2, id FROM permissions WHERE slug IN (
  'students.view','classes.view','attendance.students.mark','attendance.students.view',
  'assignments.create','assignments.grade','assignments.view','exams.view','grades.manage','grades.view',
  'reports.view','timetable.view','leave.request','announcements.manage'
);

-- HR
INSERT INTO role_permissions (role_id, permission_id)
SELECT 3, id FROM permissions WHERE slug IN (
  'employees.manage','hr.manage','recruitment.manage','attendance.staff.mark','attendance.staff.view',
  'leave.manage','leave.approve','reports.view','teachers.view'
);

-- Finance
INSERT INTO role_permissions (role_id, permission_id)
SELECT 4, id FROM permissions WHERE slug IN (
  'finance.view','finance.manage','payroll.manage','reports.view','students.view'
);

-- Receptionist
INSERT INTO role_permissions (role_id, permission_id)
SELECT 5, id FROM permissions WHERE slug IN (
  'students.view','students.create','students.edit','admissions.manage','reception.manage',
  'announcements.manage','classes.view'
);

-- Parent
INSERT INTO role_permissions (role_id, permission_id)
SELECT 6, id FROM permissions WHERE slug IN (
  'parent.portal','assignments.view','exams.view','grades.view','attendance.students.view','timetable.view'
);

-- School Admin
INSERT INTO role_permissions (role_id, permission_id)
SELECT 7, id FROM permissions WHERE slug NOT IN ('assignments.create', 'assignments.grade');

INSERT INTO departments (id, school_id, name, code, status, created_at, updated_at) VALUES
(1, 1, 'Academics', 'ACAD', 1, NOW(), NOW()),
(2, 1, 'Administration', 'ADMIN', 1, NOW(), NOW()),
(3, 1, 'Finance', 'FIN', 1, NOW(), NOW()),
(4, 1, 'Human Resources', 'HR', 1, NOW(), NOW());

INSERT INTO designations (id, school_id, name, status, created_at, updated_at) VALUES
(1, 1, 'Principal', 1, NOW(), NOW()),
(2, 1, 'Teacher', 1, NOW(), NOW()),
(3, 1, 'HR Manager', 1, NOW(), NOW()),
(4, 1, 'Accountant', 1, NOW(), NOW()),
(5, 1, 'Receptionist', 1, NOW(), NOW());

INSERT INTO academic_years (id, school_id, name, start_date, end_date, is_active, created_at, updated_at) VALUES
(1, 1, '2026-2027', '2026-04-01', '2027-03-31', 1, NOW(), NOW());

INSERT INTO classes (id, school_id, name, numeric_name, status, created_at, updated_at) VALUES
(1, 1, 'Grade 5', 5, 1, NOW(), NOW()),
(2, 1, 'Grade 6', 6, 1, NOW(), NOW()),
(3, 1, 'Grade 7', 7, 1, NOW(), NOW());

INSERT INTO sections (id, school_id, class_id, name, capacity, status, created_at, updated_at) VALUES
(1, 1, 1, 'A', 40, 1, NOW(), NOW()),
(2, 1, 2, 'A', 40, 1, NOW(), NOW()),
(3, 1, 2, 'B', 40, 1, NOW(), NOW()),
(4, 1, 3, 'A', 40, 1, NOW(), NOW());

INSERT INTO subjects (id, school_id, name, code, type, status, created_at, updated_at) VALUES
(1, 1, 'Mathematics', 'MATH', 'core', 1, NOW(), NOW()),
(2, 1, 'English', 'ENG', 'core', 1, NOW(), NOW()),
(3, 1, 'Science', 'SCI', 'core', 1, NOW(), NOW()),
(4, 1, 'Computer Science', 'CS', 'core', 1, NOW(), NOW()),
(5, 1, 'Biology', 'BIO', 'elective', 1, NOW(), NOW());

INSERT INTO employees (id, school_id, employee_code, first_name, last_name, email, phone, gender, department_id, designation_id, joining_date, status, created_at, updated_at) VALUES
(1, 1, 'EMP001', 'Ayesha', 'Khan', 'principal@greenfield.edu', '3001111111', 'female', 2, 1, '2020-01-15', 'active', NOW(), NOW()),
(2, 1, 'EMP002', 'Hassan', 'Ali', 'teacher@greenfield.edu', '3002222222', 'male', 1, 2, '2021-03-01', 'active', NOW(), NOW()),
(3, 1, 'EMP003', 'Sara', 'Malik', 'hr@greenfield.edu', '3003333333', 'female', 4, 3, '2021-06-01', 'active', NOW(), NOW()),
(4, 1, 'EMP004', 'Imran', 'Qureshi', 'finance@greenfield.edu', '3004444444', 'male', 3, 4, '2022-01-10', 'active', NOW(), NOW()),
(5, 1, 'EMP005', 'Nadia', 'Ahmed', 'reception@greenfield.edu', '3005555555', 'female', 2, 5, '2022-08-01', 'active', NOW(), NOW()),
(6, 1, 'EMP006', 'Farah', 'Siddiqui', 'teacher2@greenfield.edu', '3006666666', 'female', 1, 2, '2023-02-01', 'active', NOW(), NOW());

INSERT INTO teachers (id, school_id, employee_id, qualification, specialization, experience_years, status, created_at, updated_at) VALUES
(1, 1, 2, 'MSc Mathematics', 'Mathematics', 8, 1, NOW(), NOW()),
(2, 1, 6, 'MSc Biology', 'Science', 5, 1, NOW(), NOW());

INSERT INTO parents (id, school_id, first_name, last_name, email, phone, occupation, address, relation_label, status, created_at, updated_at) VALUES
(1, 1, 'Omar', 'Raza', 'parent@greenfield.edu', '3007777777', 'Business', '45 Lake Road, Karachi', 'Father', 1, NOW(), NOW());

-- Password: Password@123
SET @pwd = '$2y$12$mj5aoWTRqx3vnSRyJsYxYuLULBROyyvAfr6BSM3KZ4dhPgiAZJKde';

INSERT INTO users (id, school_id, employee_id, parent_id, name, email, phone, password, role_id, status, created_at, updated_at) VALUES
(1, 1, 1, NULL, 'Ayesha Khan', 'principal@greenfield.edu', '3001111111', @pwd, 1, 1, NOW(), NOW()),
(2, 1, 2, NULL, 'Hassan Ali', 'teacher@greenfield.edu', '3002222222', @pwd, 2, 1, NOW(), NOW()),
(3, 1, 3, NULL, 'Sara Malik', 'hr@greenfield.edu', '3003333333', @pwd, 3, 1, NOW(), NOW()),
(4, 1, 4, NULL, 'Imran Qureshi', 'finance@greenfield.edu', '3004444444', @pwd, 4, 1, NOW(), NOW()),
(5, 1, 5, NULL, 'Nadia Ahmed', 'reception@greenfield.edu', '3005555555', @pwd, 5, 1, NOW(), NOW()),
(6, 1, NULL, 1, 'Omar Raza', 'parent@greenfield.edu', '3007777777', @pwd, 6, 1, NOW(), NOW()),
(7, 1, NULL, NULL, 'System Admin', 'admin@greenfield.edu', '3008888888', @pwd, 7, 1, NOW(), NOW());

INSERT INTO students (id, school_id, admission_no, roll_no, first_name, last_name, gender, date_of_birth, class_id, section_id, academic_year_id, phone, address, admission_date, emergency_contact, emergency_phone, status, created_at, updated_at) VALUES
(1, 1, 'ADM-2026-0001', '01', 'Zain', 'Raza', 'male', '2015-05-12', 2, 2, 1, '3007777777', '45 Lake Road, Karachi', '2026-04-01', 'Omar Raza', '3007777777', 'active', NOW(), NOW()),
(2, 1, 'ADM-2026-0002', '02', 'Hina', 'Raza', 'female', '2016-08-20', 1, 1, 1, '3007777777', '45 Lake Road, Karachi', '2026-04-01', 'Omar Raza', '3007777777', 'active', NOW(), NOW()),
(3, 1, 'ADM-2026-0003', '03', 'Bilal', 'Hussain', 'male', '2014-11-03', 2, 3, 1, '3011111111', '12 Park Street', '2026-04-01', 'Ali Hussain', '3011111111', 'active', NOW(), NOW()),
(4, 1, 'ADM-2026-0004', '04', 'Amina', 'Shah', 'female', '2013-02-14', 3, 4, 1, '3022222222', '88 Garden Ave', '2026-04-01', 'Sana Shah', '3022222222', 'active', NOW(), NOW());

INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES
(1, 1, 1, 'Father', 1, NOW()),
(1, 2, 1, 'Father', 1, NOW());

INSERT INTO teacher_assignments (school_id, teacher_id, class_id, section_id, subject_id, academic_year_id, status, created_at, updated_at) VALUES
(1, 1, 2, 2, 1, 1, 1, NOW(), NOW()),
(1, 1, 2, 3, 1, 1, 1, NOW(), NOW()),
(1, 1, 3, 4, 1, 1, 1, NOW(), NOW()),
(1, 2, 1, 1, 3, 1, 1, NOW(), NOW()),
(1, 2, 2, 2, 5, 1, 1, NOW(), NOW()),
(1, 2, 3, 4, 3, 1, 1, NOW(), NOW());

INSERT INTO grade_scales (school_id, grade, min_percentage, max_percentage, gpa, remark, created_at) VALUES
(1, 'A+', 90.00, 100.00, 4.00, 'Outstanding', NOW()),
(1, 'A', 80.00, 89.99, 3.70, 'Excellent', NOW()),
(1, 'B', 70.00, 79.99, 3.00, 'Good', NOW()),
(1, 'C', 60.00, 69.99, 2.00, 'Satisfactory', NOW()),
(1, 'D', 50.00, 59.99, 1.00, 'Needs Improvement', NOW()),
(1, 'F', 0.00, 49.99, 0.00, 'Fail', NOW());

INSERT INTO exam_types (id, school_id, name, created_at) VALUES
(1, 1, 'Midterm', NOW()),
(2, 1, 'Final', NOW()),
(3, 1, 'Quiz', NOW()),
(4, 1, 'Class Test', NOW());

INSERT INTO exams (id, school_id, exam_type_id, academic_year_id, name, class_id, start_date, end_date, status, created_at, updated_at) VALUES
(1, 1, 1, 1, 'Grade 6 Midterm 2026', 2, '2026-09-20', '2026-09-30', 'scheduled', NOW(), NOW()),
(2, 1, 3, 1, 'Grade 6 Math Quiz 1', 2, '2026-09-18', '2026-09-18', 'scheduled', NOW(), NOW());

INSERT INTO exam_subjects (id, school_id, exam_id, subject_id, exam_date, max_marks, pass_marks, created_at) VALUES
(1, 1, 1, 1, '2026-09-22', 100.00, 40.00, NOW()),
(2, 1, 1, 2, '2026-09-24', 100.00, 40.00, NOW()),
(3, 1, 2, 1, '2026-09-18', 20.00, 8.00, NOW());

INSERT INTO fee_categories (id, school_id, name, amount, frequency, status, created_at, updated_at) VALUES
(1, 1, 'Monthly Tuition', 15000.00, 'monthly', 1, NOW(), NOW()),
(2, 1, 'Admission Fee', 25000.00, 'one_time', 1, NOW(), NOW()),
(3, 1, 'Examination Fee', 3000.00, 'term', 1, NOW(), NOW()),
(4, 1, 'Transport Fee', 5000.00, 'monthly', 1, NOW(), NOW());

INSERT INTO student_fee_invoices (id, school_id, student_id, academic_year_id, invoice_no, title, invoice_date, due_date, subtotal, discount, late_fee, total_amount, paid_amount, status, created_by, created_at, updated_at) VALUES
(1, 1, 1, 1, 'INV-2026-0001', 'September 2026 Fees - Zain Raza', '2026-09-01', '2026-09-10', 20000.00, 0.00, 0.00, 20000.00, 10000.00, 'partial', 4, NOW(), NOW()),
(2, 1, 2, 1, 'INV-2026-0002', 'September 2026 Fees - Hina Raza', '2026-09-01', '2026-09-10', 15000.00, 0.00, 0.00, 15000.00, 0.00, 'unpaid', 4, NOW(), NOW());

INSERT INTO student_fee_invoice_items (school_id, invoice_id, fee_category_id, description, amount, created_at) VALUES
(1, 1, 1, 'Monthly Tuition', 15000.00, NOW()),
(1, 1, 4, 'Transport Fee', 5000.00, NOW()),
(1, 2, 1, 'Monthly Tuition', 15000.00, NOW());

INSERT INTO payments (school_id, invoice_id, student_id, receipt_no, amount, payment_method, payment_date, received_by, created_at) VALUES
(1, 1, 1, 'RCP-2026-0001', 10000.00, 'cash', '2026-09-05', 4, NOW());

INSERT INTO salary_structures (school_id, employee_id, basic_salary, house_allowance, transport_allowance, other_allowance, deductions, effective_from, status, created_at, updated_at) VALUES
(1, 1, 120000.00, 20000.00, 10000.00, 5000.00, 2000.00, '2026-01-01', 1, NOW(), NOW()),
(1, 2, 70000.00, 10000.00, 5000.00, 0.00, 1000.00, '2026-01-01', 1, NOW(), NOW()),
(1, 3, 80000.00, 12000.00, 5000.00, 0.00, 1000.00, '2026-01-01', 1, NOW(), NOW()),
(1, 4, 75000.00, 10000.00, 5000.00, 0.00, 1000.00, '2026-01-01', 1, NOW(), NOW()),
(1, 5, 45000.00, 5000.00, 3000.00, 0.00, 500.00, '2026-01-01', 1, NOW(), NOW()),
(1, 6, 65000.00, 8000.00, 4000.00, 0.00, 1000.00, '2026-01-01', 1, NOW(), NOW());

INSERT INTO payroll (school_id, employee_id, payroll_month, basic_salary, allowances, bonuses, deductions, leave_deduction, attendance_deduction, net_salary, status, created_by, created_at, updated_at) VALUES
(1, 2, '2026-08', 70000.00, 15000.00, 0.00, 1000.00, 0.00, 0.00, 84000.00, 'pending', 4, NOW(), NOW()),
(1, 3, '2026-08', 80000.00, 17000.00, 0.00, 1000.00, 0.00, 0.00, 96000.00, 'approved', 4, NOW(), NOW());

INSERT INTO expenses (school_id, title, category, amount, expense_date, payment_method, created_by, created_at, updated_at) VALUES
(1, 'Utility Bills - August', 'Utilities', 45000.00, '2026-08-28', 'bank', 4, NOW(), NOW()),
(1, 'Lab Supplies', 'Academics', 18000.00, '2026-09-05', 'cash', 4, NOW(), NOW());

INSERT INTO leave_types (id, school_id, name, is_paid, created_at) VALUES
(1, 1, 'Sick Leave', 1, NOW()),
(2, 1, 'Casual Leave', 1, NOW()),
(3, 1, 'Annual Leave', 1, NOW()),
(4, 1, 'Unpaid Leave', 0, NOW()),
(5, 1, 'Other', 0, NOW());

INSERT INTO leave_requests (school_id, employee_id, leave_type_id, start_date, end_date, days, reason, status, created_at, updated_at) VALUES
(1, 2, 2, '2026-09-20', '2026-09-20', 1.0, 'Personal errand', 'pending', NOW(), NOW());

INSERT INTO student_attendance (school_id, academic_year_id, student_id, class_id, section_id, attendance_date, status, marked_by, marked_at) VALUES
(1, 1, 1, 2, 2, CURDATE(), 'present', 2, NOW()),
(1, 1, 3, 2, 3, CURDATE(), 'absent', 2, NOW()),
(1, 1, 2, 1, 1, CURDATE(), 'present', 2, NOW()),
(1, 1, 4, 3, 4, CURDATE(), 'late', 2, NOW());

INSERT INTO staff_attendance (school_id, employee_id, attendance_date, status, marked_by, marked_at) VALUES
(1, 2, CURDATE(), 'present', 1, NOW()),
(1, 3, CURDATE(), 'present', 1, NOW()),
(1, 4, CURDATE(), 'present', 1, NOW()),
(1, 5, CURDATE(), 'absent', 1, NOW()),
(1, 6, CURDATE(), 'present', 1, NOW());

INSERT INTO assignments (id, school_id, teacher_id, class_id, section_id, subject_id, academic_year_id, title, description, assigned_date, due_date, max_marks, status, created_at, updated_at) VALUES
(1, 1, 1, 2, 2, 1, 1, 'Algebra Worksheet 1', 'Complete exercises 1-20 from chapter 2.', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY), 50.00, 'published', NOW(), NOW());

INSERT INTO assignment_submissions (school_id, assignment_id, student_id, status, created_at, updated_at) VALUES
(1, 1, 1, 'pending', NOW(), NOW());

INSERT INTO timetables (school_id, academic_year_id, class_id, section_id, subject_id, teacher_id, day_of_week, start_time, end_time, room, created_at, updated_at) VALUES
(1, 1, 2, 2, 1, 1, 1, '08:00:00', '08:45:00', 'R101', NOW(), NOW()),
(1, 1, 2, 2, 2, 1, 1, '08:45:00', '09:30:00', 'R101', NOW(), NOW()),
(1, 1, 2, 3, 1, 1, 2, '08:00:00', '08:45:00', 'R102', NOW(), NOW()),
(1, 1, 1, 1, 3, 2, 1, '09:30:00', '10:15:00', 'R201', NOW(), NOW());

INSERT INTO announcements (school_id, title, body, audience, published_at, created_by, status, created_at, updated_at) VALUES
(1, 'Welcome to Academic Year 2026-2027', 'Dear staff and parents, welcome to the new academic year. Classes begin as scheduled.', 'all', NOW(), 1, 'published', NOW(), NOW()),
(1, 'Parent-Teacher Meeting', 'PTM will be held next Friday after school hours.', 'parents', NOW(), 1, 'published', NOW(), NOW());

INSERT INTO admission_inquiries (school_id, student_name, parent_name, phone, email, interested_class_id, notes, status, handled_by, created_at, updated_at) VALUES
(1, 'Yusuf Khan', 'Rehan Khan', '3033333333', 'rehan@example.com', 1, 'Interested in Grade 5 admission', 'new', 5, NOW(), NOW());

INSERT INTO admissions (school_id, application_no, student_name, gender, date_of_birth, parent_name, parent_phone, class_id, section_id, status, created_by, created_at, updated_at) VALUES
(1, 'APP-2026-0001', 'Yusuf Khan', 'male', '2016-01-10', 'Rehan Khan', '3033333333', 1, 1, 'review', 5, NOW(), NOW());

INSERT INTO candidates (school_id, first_name, last_name, email, phone, position_applied, department_id, status, notes, created_at, updated_at) VALUES
(1, 'Kamran', 'Mehmood', 'kamran@example.com', '3044444444', 'Science Teacher', 1, 'interview', 'Strong subject knowledge', NOW(), NOW());

INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at) VALUES
(1, 'school_name', 'Greenfield International School', NOW(), NOW()),
(1, 'attendance_edit_hours', '48', NOW(), NOW()),
(1, 'currency', 'PKR', NOW(), NOW());

INSERT INTO notifications (school_id, user_id, type, title, message, is_read, created_at) VALUES
(1, 1, 'system', 'Staff absence alert', 'Nadia Ahmed (Reception) is marked absent today.', 0, NOW()),
(1, 4, 'hr', 'Payroll pending', 'August payroll for Hassan Ali is pending approval.', 0, NOW()),
(1, 6, 'finance', 'Fee reminder', 'Outstanding fee for Hina Raza: PKR 15,000.00', 0, NOW());
