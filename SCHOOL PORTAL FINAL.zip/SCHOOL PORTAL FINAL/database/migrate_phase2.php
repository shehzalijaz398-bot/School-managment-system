<?php

declare(strict_types=1);

require_once __DIR__ . '/migrations/migrate_phase2.php';

