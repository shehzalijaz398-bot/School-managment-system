<?php
declare(strict_types=1);

require dirname(__DIR__) . '/core/bootstrap.php';

use Core\Database;

echo "Seeding School 2 (Guiding star International) Demo Data...\n";

$schoolId = 2;
$pwd = password_hash('Password@123', PASSWORD_DEFAULT);
$now = date('Y-m-d H:i:s');

// 1. Academic Year
$ay = Database::fetch("SELECT id FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1", [$schoolId]);
if (!$ay) {
    Database::execute(
        "INSERT INTO academic_years (school_id, name, start_date, end_date, is_active, status, created_at, updated_at)
         VALUES (?, '2026-2027', '2026-04-01', '2027-03-31', 1, 'active', ?, ?)",
        [$schoolId, $now, $now]
    );
    $ayId = (int)Database::connection()->lastInsertId();
} else {
    $ayId = (int)$ay['id'];
}
echo "✓ Academic Year ID: $ayId\n";

// 2. Departments & Designations
$depts = [
    ['Academics', 'ACAD'],
    ['Administration', 'ADMIN'],
    ['Finance', 'FIN'],
    ['Human Resources', 'HR']
];
$deptMap = [];
foreach ($depts as [$name, $code]) {
    $existing = Database::fetch("SELECT id FROM departments WHERE school_id = ? AND name = ?", [$schoolId, $name]);
    if (!$existing) {
        Database::execute("INSERT INTO departments (school_id, name, code, status, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)", [$schoolId, $name, $code, $now, $now]);
        $deptMap[$name] = (int)Database::connection()->lastInsertId();
    } else {
        $deptMap[$name] = (int)$existing['id'];
    }
}

$desigs = ['Principal', 'Senior Teacher', 'Teacher', 'Accountant', 'Receptionist', 'Lab Instructor'];
$desigMap = [];
foreach ($desigs as $name) {
    $existing = Database::fetch("SELECT id FROM designations WHERE school_id = ? AND name = ?", [$schoolId, $name]);
    if (!$existing) {
        Database::execute("INSERT INTO designations (school_id, name, status, created_at, updated_at) VALUES (?, ?, 1, ?, ?)", [$schoolId, $name, $now, $now]);
        $desigMap[$name] = (int)Database::connection()->lastInsertId();
    } else {
        $desigMap[$name] = (int)$existing['id'];
    }
}
echo "✓ Departments & Designations configured\n";

// 3. Classes & Sections
$classesConfig = [
    ['Grade 1', 1],
    ['Grade 5', 5],
    ['Grade 8', 8],
    ['Grade 9 (Matric)', 9],
    ['Grade 10 (Matric)', 10],
];
$classMap = [];
foreach ($classesConfig as [$cName, $cNum]) {
    $existing = Database::fetch("SELECT id FROM classes WHERE school_id = ? AND numeric_name = ?", [$schoolId, $cNum]);
    if (!$existing) {
        Database::execute("INSERT INTO classes (school_id, name, numeric_name, status, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)", [$schoolId, $cName, $cNum, $now, $now]);
        $cId = (int)Database::connection()->lastInsertId();
    } else {
        $cId = (int)$existing['id'];
    }
    $classMap[$cNum] = $cId;

    // Create Sections A and B
    foreach (['Section A', 'Section B'] as $secName) {
        $secExisting = Database::fetch("SELECT id FROM sections WHERE school_id = ? AND class_id = ? AND name = ?", [$schoolId, $cId, $secName]);
        if (!$secExisting) {
            Database::execute("INSERT INTO sections (school_id, class_id, name, capacity, status, created_at, updated_at) VALUES (?, ?, ?, 40, 1, ?, ?)", [$schoolId, $cId, $secName, $now, $now]);
        }
    }
}
echo "✓ Classes & Sections configured\n";

// 4. Roles mapping for school 2
$roles = Database::fetchAll("SELECT id, slug FROM roles WHERE school_id = ?", [$schoolId]);
$roleMap = [];
foreach ($roles as $r) {
    $roleMap[$r['slug']] = (int)$r['id'];
}

// 5. Staff Accounts & Employees
$staffAccounts = [
    ['teacher@gsischools.com', 'Ayesha Khan', 'teacher', 'EMP-001', 'Senior Teacher', 'Academics', '+923001234567'],
    ['finance@gsischools.com', 'Tariq Mehmood', 'accountant', 'EMP-002', 'Accountant', 'Finance', '+923001234568'],
    ['reception@gsischools.com', 'Sara Ahmed', 'receptionist', 'EMP-003', 'Receptionist', 'Administration', '+923001234569'],
];
$employeeMap = [];
foreach ($staffAccounts as [$email, $name, $roleSlug, $empCode, $desig, $dept, $phone]) {
    $roleId = $roleMap[$roleSlug] ?? ($roleMap['teacher'] ?? 10);
    $parts = explode(' ', $name, 2);
    $fName = $parts[0];
    $lName = $parts[1] ?? '';

    $u = Database::fetch("SELECT id FROM users WHERE email = ? AND school_id = ?", [$email, $schoolId]);
    if (!$u) {
        Database::execute("INSERT INTO users (school_id, role_id, email, password, status, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?)", [$schoolId, $roleId, $email, $pwd, $now, $now]);
        $uId = (int)Database::connection()->lastInsertId();
    } else {
        $uId = (int)$u['id'];
    }

    $emp = Database::fetch("SELECT id FROM employees WHERE school_id = ? AND employee_code = ?", [$schoolId, $empCode]);
    if (!$emp) {
        Database::execute(
            "INSERT INTO employees (school_id, employee_code, first_name, last_name, email, phone, department_id, designation_id, joining_date, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, '2026-01-15', 'active', ?, ?)",
            [$schoolId, $empCode, $fName, $lName, $email, $phone, $deptMap[$dept] ?? 1, $desigMap[$desig] ?? 1, $now, $now]
        );
        $empId = (int)Database::connection()->lastInsertId();
    } else {
        $empId = (int)$emp['id'];
    }
    $employeeMap[$roleSlug] = $empId;

    if ($roleSlug === 'teacher') {
        $t = Database::fetch("SELECT id FROM teachers WHERE school_id = ? AND employee_id = ?", [$schoolId, $empId]);
        if (!$t) {
            Database::execute("INSERT INTO teachers (school_id, employee_id, qualification, specialization, experience_years, status, created_at, updated_at) VALUES (?, ?, 'M.Sc Mathematics', 'Mathematics & Science', 6, 'active', ?, ?)", [$schoolId, $empId, $now, $now]);
        }
    }
}
echo "✓ Staff and Teacher profiles linked\n";

// 6. Parent & Student Accounts
$parentEmail = 'parent@gsischools.com';
$parentRoleId = $roleMap['parent'] ?? 13;
$pUser = Database::fetch("SELECT id FROM users WHERE email = ? AND school_id = ?", [$parentEmail, $schoolId]);
if (!$pUser) {
    Database::execute("INSERT INTO users (school_id, role_id, email, password, status, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?)", [$schoolId, $parentRoleId, $parentEmail, $pwd, $now, $now]);
    $pUserId = (int)Database::connection()->lastInsertId();
} else {
    $pUserId = (int)$pUser['id'];
}

$parent = Database::fetch("SELECT id FROM parents WHERE school_id = ? AND email = ?", [$schoolId, $parentEmail]);
if (!$parent) {
    Database::execute(
        "INSERT INTO parents (school_id, user_id, first_name, last_name, relation_label, phone, email, address, occupation, status, created_at, updated_at)
         VALUES (?, ?, 'Bilal', 'Ahmed', 'Father', '+923112233445', ?, 'House 14, Block 3, Korangi, Karachi', 'Engineer', 'active', ?, ?)",
        [$schoolId, $pUserId, $parentEmail, $now, $now]
    );
    $parentId = (int)Database::connection()->lastInsertId();
} else {
    $parentId = (int)$parent['id'];
}

// Student User
$studentEmail = 'student@gsischools.com';
$studentRoleId = $roleMap['student'] ?? 14;
$sUser = Database::fetch("SELECT id FROM users WHERE email = ? AND school_id = ?", [$studentEmail, $schoolId]);
if (!$sUser) {
    Database::execute("INSERT INTO users (school_id, role_id, email, password, status, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?)", [$schoolId, $studentRoleId, $studentEmail, $pwd, $now, $now]);
    $sUserId = (int)Database::connection()->lastInsertId();
} else {
    $sUserId = (int)$sUser['id'];
}

$g10Id = $classMap[10] ?? 1;
$secA = Database::fetch("SELECT id FROM sections WHERE school_id = ? AND class_id = ? LIMIT 1", [$schoolId, $g10Id]);
$secAId = (int)($secA['id'] ?? 1);

$stu1 = Database::fetch("SELECT id FROM students WHERE school_id = ? AND admission_no = 'ADM-2026-0001'", [$schoolId]);
if (!$stu1) {
    Database::execute(
        "INSERT INTO students (school_id, user_id, admission_no, roll_no, first_name, last_name, gender, date_of_birth, class_id, section_id, academic_year_id, email, phone, address, admission_date, status, created_at, updated_at)
         VALUES (?, ?, 'ADM-2026-0001', '101', 'Ahmed', 'Bilal', 'male', '2010-05-14', ?, ?, ?, ?, '+923112233445', 'House 14, Block 3, Korangi, Karachi', '2026-04-01', 'active', ?, ?)",
        [$schoolId, $sUserId, $g10Id, $secAId, $ayId, $studentEmail, $now, $now]
    );
    $studentId = (int)Database::connection()->lastInsertId();
} else {
    $studentId = (int)$stu1['id'];
}

// Link Parent & Student
$ps = Database::fetch("SELECT id FROM student_parents WHERE school_id = ? AND parent_id = ? AND student_id = ?", [$schoolId, $parentId, $studentId]);
if (!$ps) {
    Database::execute("INSERT INTO student_parents (school_id, parent_id, student_id, relationship, is_primary, created_at) VALUES (?, ?, ?, 'Father', 1, ?)", [$schoolId, $parentId, $studentId, $now]);
}
echo "✓ Parent & Student (Ahmed Bilal #$studentId) configured and linked\n";

// 7. Fee Categories & Sample Invoices
$feeCategories = [
    ['Monthly Tuition Fee', 'TUI-M', 6500.00, 'monthly'],
    ['Computer & Lab Fee', 'LAB-F', 1500.00, 'term'],
    ['Exam & Assessment Fee', 'EXAM-F', 2000.00, 'term']
];
$fcMap = [];
foreach ($feeCategories as [$fcName, $fcCode, $fcAmt, $fcFreq]) {
    $fc = Database::fetch("SELECT id FROM fee_categories WHERE school_id = ? AND (code = ? OR name = ?)", [$schoolId, $fcCode, $fcName]);
    if (!$fc) {
        Database::execute(
            "INSERT INTO fee_categories (school_id, name, code, description, amount, frequency, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)",
            [$schoolId, $fcName, $fcCode, $fcName, $fcAmt, $fcFreq, $now, $now]
        );
        $fcMap[$fcCode] = (int)Database::connection()->lastInsertId();
    } else {
        $fcMap[$fcCode] = (int)$fc['id'];
    }
}

// Sample Invoice
$inv = Database::fetch("SELECT id FROM student_fee_invoices WHERE school_id = ? AND student_id = ? LIMIT 1", [$schoolId, $studentId]);
if (!$inv) {
    Database::execute(
        "INSERT INTO student_fee_invoices (school_id, student_id, academic_year_id, invoice_no, title, invoice_date, due_date, subtotal, discount, late_fee, total_amount, paid_amount, status, created_at, updated_at)
         VALUES (?, ?, ?, 'INV-2026-00001', 'May 2026 Tuition Fee', '2026-05-01', '2026-05-10', 8000.00, 0, 0, 8000.00, 8000.00, 'paid', ?, ?)",
        [$schoolId, $studentId, $ayId, $now, $now]
    );
    $invId = (int)Database::connection()->lastInsertId();
    Database::execute(
        "INSERT INTO student_fee_invoice_items (school_id, invoice_id, fee_category_id, description, amount, created_at)
         VALUES (?, ?, ?, 'Monthly Tuition Fee', 6500.00, ?),
                (?, ?, ?, 'Computer & Lab Fee', 1500.00, ?)",
        [$schoolId, $invId, $fcMap['TUI-M'], $now, $schoolId, $invId, $fcMap['LAB-F'], $now]
    );
    Database::execute(
        "INSERT INTO payments (school_id, invoice_id, student_id, receipt_no, amount, payment_method, payment_date, reference_no, status, created_at)
         VALUES (?, ?, ?, 'REC-2026-00001', 8000.00, 'cash', '2026-05-05', 'TRX-PAY-2026-001', 'completed', ?)",
        [$schoolId, $invId, $studentId, $now]
    );
}
echo "✓ Fee Invoices & Payment Ledger seeded\n";

// 8. Sample Attendance Records for Student
$today = date('Y-m-d');
for ($i = 0; $i < 10; $i++) {
    $attDate = date('Y-m-d', strtotime("-$i days"));
    $att = Database::fetch("SELECT id FROM student_attendance WHERE school_id = ? AND student_id = ? AND attendance_date = ?", [$schoolId, $studentId, $attDate]);
    if (!$att) {
        $status = ($i === 3) ? 'late' : (($i === 7) ? 'absent' : 'present');
        $adminUser = Database::fetch("SELECT id FROM users WHERE school_id = ? ORDER BY id ASC LIMIT 1", [$schoolId]);
        $markerId = (int)($adminUser['id'] ?? 2);
        Database::execute(
            "INSERT INTO student_attendance (school_id, academic_year_id, student_id, class_id, section_id, attendance_date, status, marked_by, marked_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$schoolId, $ayId, $studentId, $g10Id, $secAId, $attDate, $status, $markerId, $now, $now]
        );
    }
}
echo "✓ Attendance Records seeded\n";

echo "Seeding completed successfully!\n";
