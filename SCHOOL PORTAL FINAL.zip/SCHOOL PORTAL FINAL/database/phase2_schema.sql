-- Phase 2 Multi-Tenant SaaS Schema (safe upgrade — does not drop Phase 1 data)
-- Run: mysql -u root school_portal < database/phase2_schema.sql

USE school_portal;
SET NAMES utf8mb4;

-- ---------------------------------------------------------------------------
-- Extend schools for SaaS tenancy
-- ---------------------------------------------------------------------------
ALTER TABLE schools
  ADD COLUMN IF NOT EXISTS school_uuid CHAR(36) NULL AFTER id,
  ADD COLUMN IF NOT EXISTS city VARCHAR(100) NULL AFTER address,
  ADD COLUMN IF NOT EXISTS country VARCHAR(100) NULL AFTER city,
  ADD COLUMN IF NOT EXISTS timezone VARCHAR(64) NULL DEFAULT 'Asia/Karachi' AFTER country,
  ADD COLUMN IF NOT EXISTS currency VARCHAR(10) NULL DEFAULT 'PKR' AFTER timezone,
  ADD COLUMN IF NOT EXISTS plan_id BIGINT UNSIGNED NULL AFTER currency,
  ADD COLUMN IF NOT EXISTS subscription_status VARCHAR(30) NOT NULL DEFAULT 'active' AFTER plan_id,
  ADD COLUMN IF NOT EXISTS trial_ends_at DATETIME NULL AFTER subscription_status,
  ADD COLUMN IF NOT EXISTS subscription_ends_at DATETIME NULL AFTER trial_ends_at,
  ADD COLUMN IF NOT EXISTS notes TEXT NULL AFTER subscription_ends_at,
  ADD COLUMN IF NOT EXISTS archived_at DATETIME NULL AFTER notes,
  ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL AFTER archived_at;

-- MySQL 8 on some installs may not support IF NOT EXISTS on ADD COLUMN — fallback handled below via procedure-free checks
-- If ALTER fails on duplicate columns, ignore those columns.

CREATE UNIQUE INDEX IF NOT EXISTS uq_schools_uuid ON schools (school_uuid);
CREATE INDEX IF NOT EXISTS idx_schools_sub_status ON schools (subscription_status);
CREATE INDEX IF NOT EXISTS idx_schools_plan ON schools (plan_id);

-- ---------------------------------------------------------------------------
-- Platform (SaaS) RBAC
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS platform_roles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_permissions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(150) NOT NULL UNIQUE,
  module VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_role_permissions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id BIGINT UNSIGNED NOT NULL,
  permission_id BIGINT UNSIGNED NOT NULL,
  UNIQUE KEY uq_prp (role_id, permission_id),
  CONSTRAINT fk_prp_role FOREIGN KEY (role_id) REFERENCES platform_roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_prp_perm FOREIGN KEY (permission_id) REFERENCES platform_permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  email VARCHAR(191) NOT NULL UNIQUE,
  phone VARCHAR(50) NULL,
  password VARCHAR(255) NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  status TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  last_login_ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  CONSTRAINT fk_pu_role FOREIGN KEY (role_id) REFERENCES platform_roles(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Plans & features
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS plans (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  description TEXT NULL,
  monthly_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  annual_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  trial_days INT UNSIGNED NOT NULL DEFAULT 14,
  student_limit INT UNSIGNED NULL COMMENT 'NULL = unlimited',
  teacher_limit INT UNSIGNED NULL,
  employee_limit INT UNSIGNED NULL,
  storage_limit_mb INT UNSIGNED NULL,
  status TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS features (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(150) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  module VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS plan_features (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id BIGINT UNSIGNED NOT NULL,
  feature_id BIGINT UNSIGNED NOT NULL,
  UNIQUE KEY uq_plan_feature (plan_id, feature_id),
  CONSTRAINT fk_pf_plan FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_pf_feature FOREIGN KEY (feature_id) REFERENCES features(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Link schools.plan_id if FK not present
-- ALTER ignored if already exists

CREATE TABLE IF NOT EXISTS subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  billing_cycle ENUM('monthly','annual') NOT NULL DEFAULT 'monthly',
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  trial_end_date DATE NULL,
  status ENUM('trial','active','past_due','expired','cancelled','suspended') NOT NULL DEFAULT 'trial',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'PKR',
  auto_renew TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_sub_school (school_id, status),
  KEY idx_sub_end (end_date, status),
  CONSTRAINT fk_sub_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CONSTRAINT fk_sub_plan FOREIGN KEY (plan_id) REFERENCES plans(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subscription_invoices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  subscription_id BIGINT UNSIGNED NULL,
  invoice_no VARCHAR(50) NOT NULL,
  billing_period_start DATE NOT NULL,
  billing_period_end DATE NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  tax DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  due_date DATE NOT NULL,
  status ENUM('draft','pending','paid','partial','overdue','cancelled') NOT NULL DEFAULT 'pending',
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_sai_no (invoice_no),
  KEY idx_sai_school (school_id, status),
  CONSTRAINT fk_sai_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CONSTRAINT fk_sai_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subscription_invoice_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_id BIGINT UNSIGNED NOT NULL,
  description VARCHAR(255) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  created_at DATETIME NOT NULL,
  CONSTRAINT fk_saii_inv FOREIGN KEY (invoice_id) REFERENCES subscription_invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subscription_payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  invoice_id BIGINT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  currency VARCHAR(10) NOT NULL DEFAULT 'PKR',
  payment_method VARCHAR(50) NOT NULL DEFAULT 'manual',
  payment_status ENUM('pending','paid','failed','refunded','cancelled') NOT NULL DEFAULT 'pending',
  transaction_reference VARCHAR(100) NULL,
  paid_at DATETIME NULL,
  verified_by BIGINT UNSIGNED NULL,
  notes TEXT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_subpay_school (school_id),
  CONSTRAINT fk_subpay_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CONSTRAINT fk_subpay_invoice FOREIGN KEY (invoice_id) REFERENCES subscription_invoices(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payment_transactions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  payment_id BIGINT UNSIGNED NULL,
  gateway VARCHAR(50) NOT NULL DEFAULT 'manual',
  gateway_reference VARCHAR(150) NULL,
  amount DECIMAL(12,2) NOT NULL,
  currency VARCHAR(10) NOT NULL DEFAULT 'PKR',
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  raw_payload JSON NULL,
  created_at DATETIME NOT NULL,
  CONSTRAINT fk_paytxn_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CONSTRAINT fk_paytxn_payment FOREIGN KEY (payment_id) REFERENCES subscription_payments(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS school_usage (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  metric_date DATE NOT NULL,
  students_count INT UNSIGNED NOT NULL DEFAULT 0,
  teachers_count INT UNSIGNED NOT NULL DEFAULT 0,
  employees_count INT UNSIGNED NOT NULL DEFAULT 0,
  users_count INT UNSIGNED NOT NULL DEFAULT 0,
  storage_mb INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_usage_day (school_id, metric_date),
  CONSTRAINT fk_usage_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS school_branding (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL UNIQUE,
  logo VARCHAR(255) NULL,
  primary_color VARCHAR(20) NULL DEFAULT '#0b4f6c',
  secondary_color VARCHAR(20) NULL DEFAULT '#01baef',
  receipt_footer TEXT NULL,
  report_footer TEXT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  CONSTRAINT fk_brand_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS school_domains (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id BIGINT UNSIGNED NOT NULL,
  domain VARCHAR(191) NOT NULL,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_domain (domain),
  CONSTRAINT fk_domain_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_settings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL COMMENT 'platform_users.id; NULL = all platform admins',
  school_id BIGINT UNSIGNED NULL,
  type VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(255) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  KEY idx_pn_user (user_id, is_read)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_announcements (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  audience ENUM('all_schools','plan','selected','maintenance') NOT NULL DEFAULT 'all_schools',
  plan_id BIGINT UNSIGNED NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'published',
  published_at DATETIME NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_announcement_schools (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  announcement_id BIGINT UNSIGNED NOT NULL,
  school_id BIGINT UNSIGNED NOT NULL,
  UNIQUE KEY uq_pas (announcement_id, school_id),
  CONSTRAINT fk_pas_ann FOREIGN KEY (announcement_id) REFERENCES platform_announcements(id) ON DELETE CASCADE,
  CONSTRAINT fk_pas_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS support_tickets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_number VARCHAR(50) NOT NULL UNIQUE,
  school_id BIGINT UNSIGNED NOT NULL,
  created_by BIGINT UNSIGNED NOT NULL COMMENT 'school users.id',
  category ENUM('technical','billing','account','feature','other') NOT NULL DEFAULT 'other',
  priority ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  subject VARCHAR(255) NOT NULL,
  status ENUM('open','in_progress','waiting','resolved','closed') NOT NULL DEFAULT 'open',
  assigned_to BIGINT UNSIGNED NULL COMMENT 'platform_users.id',
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_ticket_school (school_id, status),
  CONSTRAINT fk_ticket_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS support_ticket_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT UNSIGNED NOT NULL,
  sender_type ENUM('school','platform') NOT NULL,
  sender_id BIGINT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  created_at DATETIME NOT NULL,
  CONSTRAINT fk_stm_ticket FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id BIGINT UNSIGNED NULL,
  actor_type ENUM('platform','school','system') NOT NULL DEFAULT 'platform',
  action VARCHAR(100) NOT NULL,
  module VARCHAR(100) NOT NULL,
  school_id BIGINT UNSIGNED NULL,
  entity_type VARCHAR(100) NULL,
  entity_id BIGINT UNSIGNED NULL,
  old_values JSON NULL,
  new_values JSON NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(500) NULL,
  created_at DATETIME NOT NULL,
  KEY idx_pal_school (school_id, created_at),
  KEY idx_pal_action (module, action)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS support_impersonations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  platform_user_id BIGINT UNSIGNED NOT NULL,
  school_id BIGINT UNSIGNED NOT NULL,
  school_user_id BIGINT UNSIGNED NULL,
  mode ENUM('read_only','full') NOT NULL DEFAULT 'read_only',
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  ip_address VARCHAR(45) NULL,
  CONSTRAINT fk_imp_pu FOREIGN KEY (platform_user_id) REFERENCES platform_users(id),
  CONSTRAINT fk_imp_school FOREIGN KEY (school_id) REFERENCES schools(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS school_registrations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_name VARCHAR(191) NOT NULL,
  contact_person VARCHAR(191) NOT NULL,
  email VARCHAR(191) NOT NULL,
  phone VARCHAR(50) NULL,
  country VARCHAR(100) NULL,
  city VARCHAR(100) NULL,
  estimated_students INT UNSIGNED NULL,
  plan_id BIGINT UNSIGNED NULL,
  password_hash VARCHAR(255) NOT NULL,
  email_verified_at DATETIME NULL,
  verification_token VARCHAR(64) NULL,
  status ENUM('pending','verified','provisioned','rejected') NOT NULL DEFAULT 'pending',
  school_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS platform_login_attempts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(191) NOT NULL,
  ip_address VARCHAR(45) NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at DATETIME NOT NULL,
  KEY idx_pla (email, attempted_at)
) ENGINE=InnoDB;

-- Helpful composite indexes for Phase 1 tenant queries
CREATE INDEX IF NOT EXISTS idx_students_school_status ON students (school_id, status);
CREATE INDEX IF NOT EXISTS idx_users_school_email ON users (school_id, email);
CREATE INDEX IF NOT EXISTS idx_sa_school_date ON student_attendance (school_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_payments_school_date ON payments (school_id, payment_date);
