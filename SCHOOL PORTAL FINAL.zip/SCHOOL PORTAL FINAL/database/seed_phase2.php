<?php

declare(strict_types=1);

/**
 * Phase 2 seed — idempotent. Run after migrate_phase2.php:
 *   php database/seed_phase2.php
 */

require dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\Platform\SchoolOnboardingService;
use App\Services\Platform\SubscriptionService;
use App\Services\Platform\TenantService;
use Core\Database;

function seedExists(string $sql, array $params = []): bool
{
    return (bool) Database::fetch($sql, $params);
}

// Production safety guard
if (app_config('env') === 'production' && !in_array('--force', $argv ?? [], true)) {
    echo "[ABORTED] Application environment is set to 'production'.\n";
    echo "To run seeds in production, you must explicitly pass the --force flag:\n";
    echo "  php database/seed_phase2.php --force\n";
    exit(1);
}

echo "Phase 2 seeding...\n";

$now = date('Y-m-d H:i:s');
$pwd = password_hash('Password@123', PASSWORD_DEFAULT);

// Platform roles
$roles = [
    ['Super Admin', 'super_admin', 'Full platform control'],
    ['SaaS Support Admin', 'support_admin', 'Support and tenant assistance'],
    ['Billing Admin', 'billing_admin', 'Subscriptions and payments'],
    ['Account Manager', 'account_manager', 'Sales / account management'],
];
foreach ($roles as [$name, $slug, $desc]) {
    if (!seedExists('SELECT id FROM platform_roles WHERE slug = ?', [$slug])) {
        Database::insert(
            'INSERT INTO platform_roles (name, slug, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
            [$name, $slug, $desc, $now, $now]
        );
        echo "Role {$slug}\n";
    }
}

$perms = [
    ['View Dashboard', 'dashboard.view', 'dashboard'],
    ['View Schools', 'schools.view', 'schools'],
    ['Create Schools', 'schools.create', 'schools'],
    ['Edit Schools', 'schools.edit', 'schools'],
    ['Manage Plans', 'plans.manage', 'plans'],
    ['Manage Billing', 'billing.manage', 'billing'],
    ['View Billing', 'billing.view', 'billing'],
    ['Manage Support', 'support.manage', 'support'],
    ['Impersonate', 'support.impersonate', 'support'],
    ['Manage Announcements', 'announcements.manage', 'announcements'],
    ['View Reports', 'reports.view', 'reports'],
    ['View Audit', 'audit.view', 'audit'],
    ['Manage Settings', 'settings.manage', 'settings'],
    ['View System', 'system.view', 'system'],
];
foreach ($perms as [$name, $slug, $mod]) {
    if (!seedExists('SELECT id FROM platform_permissions WHERE slug = ?', [$slug])) {
        Database::insert(
            'INSERT INTO platform_permissions (name, slug, module, created_at) VALUES (?, ?, ?, ?)',
            [$name, $slug, $mod, $now]
        );
    }
}

// Super admin gets all; others get subsets
$allPermIds = Database::fetchAll('SELECT id, slug FROM platform_permissions');
$roleMap = [];
foreach (Database::fetchAll('SELECT id, slug FROM platform_roles') as $r) {
    $roleMap[$r['slug']] = (int) $r['id'];
}
$assign = [
    'super_admin' => array_column($allPermIds, 'slug'),
    'support_admin' => ['dashboard.view', 'schools.view', 'schools.edit', 'support.manage', 'support.impersonate', 'announcements.manage', 'audit.view'],
    'billing_admin' => ['dashboard.view', 'schools.view', 'billing.manage', 'billing.view', 'plans.manage', 'reports.view'],
    'account_manager' => ['dashboard.view', 'schools.view', 'schools.create', 'reports.view', 'announcements.manage'],
];
foreach ($assign as $roleSlug => $slugs) {
    $rid = $roleMap[$roleSlug] ?? null;
    if (!$rid) {
        continue;
    }
    foreach ($allPermIds as $p) {
        if (!in_array($p['slug'], $slugs, true)) {
            continue;
        }
        if (!seedExists('SELECT id FROM platform_role_permissions WHERE role_id = ? AND permission_id = ?', [$rid, $p['id']])) {
            Database::insert(
                'INSERT INTO platform_role_permissions (role_id, permission_id) VALUES (?, ?)',
                [$rid, $p['id']]
            );
        }
    }
}

if (!seedExists('SELECT id FROM platform_users WHERE email = ?', ['superadmin@platform.local'])) {
    Database::insert(
        'INSERT INTO platform_users (name, email, phone, password, role_id, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)',
        ['Platform Super Admin', 'superadmin@platform.local', null, $pwd, $roleMap['super_admin'], $now, $now]
    );
    echo "Created superadmin@platform.local\n";
}

// Plans
$plans = [
    ['Starter', 'starter', 'Core school operations', 4999, 49990, 14, 300, 25, 50, 1024, 1],
    ['Professional', 'professional', 'Finance, HR and advanced tools', 9999, 99990, 14, 1000, 100, 200, 5120, 2],
    ['Enterprise', 'enterprise', 'Unlimited custom school platform', 24999, 249990, 30, null, null, null, null, 3],
];
foreach ($plans as $p) {
    if (!seedExists('SELECT id FROM plans WHERE slug = ?', [$p[1]])) {
        Database::insert(
            'INSERT INTO plans (name, slug, description, monthly_price, annual_price, trial_days, student_limit, teacher_limit, employee_limit, storage_limit_mb, status, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)',
            [$p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6], $p[7], $p[8], $p[9], $p[10], $now, $now]
        );
        echo "Plan {$p[1]}\n";
    }
}

$features = [
    ['Student Management', 'students', 'students'],
    ['Teacher Management', 'teachers', 'teachers'],
    ['Attendance', 'attendance', 'attendance'],
    ['Assignments', 'assignments', 'assignments'],
    ['Examinations', 'examinations', 'exams'],
    ['Parent Portal', 'parent_portal', 'parents'],
    ['HR', 'hr', 'hr'],
    ['Payroll', 'payroll', 'payroll'],
    ['Finance', 'finance', 'finance'],
    ['Reports', 'reports', 'reports'],
    ['Advanced Reports', 'advanced_reports', 'reports'],
    ['Custom Branding', 'custom_branding', 'branding'],
    ['API Access', 'api_access', 'api'],
    ['Additional Administrators', 'additional_admins', 'users'],
    ['Priority Support', 'priority_support', 'support'],
];
foreach ($features as [$name, $slug, $mod]) {
    if (!seedExists('SELECT id FROM features WHERE slug = ?', [$slug])) {
        Database::insert(
            'INSERT INTO features (name, slug, description, module, created_at) VALUES (?, ?, ?, ?, ?)',
            [$name, $slug, $name, $mod, $now]
        );
    }
}

$starterFeatures = ['students', 'teachers', 'attendance', 'assignments'];
$proFeatures = array_merge($starterFeatures, ['examinations', 'parent_portal', 'hr', 'payroll', 'finance', 'reports']);
$entFeatures = array_merge($proFeatures, ['advanced_reports', 'custom_branding', 'api_access', 'additional_admins', 'priority_support']);
$planFeatureMap = [
    'starter' => $starterFeatures,
    'professional' => $proFeatures,
    'enterprise' => $entFeatures,
];
foreach ($planFeatureMap as $planSlug => $fslugs) {
    $plan = Database::fetch('SELECT id FROM plans WHERE slug = ?', [$planSlug]);
    if (!$plan) {
        continue;
    }
    foreach ($fslugs as $fs) {
        $f = Database::fetch('SELECT id FROM features WHERE slug = ?', [$fs]);
        if (!$f) {
            continue;
        }
        if (!seedExists('SELECT id FROM plan_features WHERE plan_id = ? AND feature_id = ?', [$plan['id'], $f['id']])) {
            Database::insert('INSERT INTO plan_features (plan_id, feature_id) VALUES (?, ?)', [$plan['id'], $f['id']]);
        }
    }
}

$settings = [
    'platform_name' => 'School Portal SaaS',
    'support_email' => 'support@platform.local',
    'default_currency' => 'PKR',
    'default_trial_days' => '14',
    'invoice_prefix' => 'SAAS',
    'registration_enabled' => '1',
    'maintenance_mode' => '0',
    'default_timezone' => 'Asia/Karachi',
    'data_retention_days' => '365',
];
foreach ($settings as $k => $v) {
    if (!seedExists('SELECT id FROM platform_settings WHERE setting_key = ?', [$k])) {
        Database::insert(
            'INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, ?)',
            [$k, $v, $now, $now]
        );
    }
}

// Upgrade existing Phase 1 school (School A) to Professional + active
$pro = Database::fetch('SELECT id FROM plans WHERE slug = ?', ['professional']);
$starter = Database::fetch('SELECT id FROM plans WHERE slug = ?', ['starter']);
$ent = Database::fetch('SELECT id FROM plans WHERE slug = ?', ['enterprise']);

$schoolA = Database::fetch('SELECT * FROM schools WHERE id = 1 LIMIT 1');
if ($schoolA && $pro) {
    $uuid = $schoolA['school_uuid'] ?: TenantService::generateUuid();
    Database::execute(
        'UPDATE schools SET school_uuid = ?, city = COALESCE(city, ?), country = COALESCE(country, ?),
         plan_id = ?, subscription_status = ?, subscription_ends_at = DATE_ADD(NOW(), INTERVAL 1 YEAR),
         status = 1, updated_at = NOW() WHERE id = 1',
        [$uuid, 'Karachi', 'Pakistan', (int) $pro['id'], 'active']
    );
    if (!seedExists('SELECT id FROM subscriptions WHERE school_id = 1 AND status = ?', ['active'])) {
        Database::insert(
            'INSERT INTO subscriptions (school_id, plan_id, billing_cycle, start_date, end_date, status, amount, currency, auto_renew, created_at, updated_at)
             VALUES (1, ?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR), ?, ?, ?, 1, NOW(), NOW())',
            [(int) $pro['id'], 'annual', 'active', $pro['annual_price'] ?? 99990, 'PKR']
        );
    }
    if (!seedExists('SELECT id FROM school_branding WHERE school_id = 1')) {
        Database::insert(
            'INSERT INTO school_branding (school_id, primary_color, secondary_color, created_at, updated_at) VALUES (1, ?, ?, NOW(), NOW())',
            ['#0b4f6c', '#01baef']
        );
    }
    echo "School A (GIS001) upgraded to Professional\n";
}

// School B — Starter trial
if (!seedExists('SELECT id FROM schools WHERE code = ?', ['SCH-LHR-B7E21']) && $starter) {
    $idB = SchoolOnboardingService::provision([
        'name' => 'School B — Lahore Academy',
        'code' => 'SCH-LHR-B7E21',
        'email' => 'admin@schoolb.local',
        'phone' => '+92-300-2000002',
        'city' => 'Lahore',
        'country' => 'Pakistan',
        'address' => '22 Canal Road, Lahore',
    ], [
        'name' => 'School B Admin',
        'email' => 'admin@schoolb.local',
        'password' => 'Password@123',
        'phone' => '+92-300-2000002',
    ], (int) $starter['id'], true);
    echo "School B created id={$idB}\n";
}

// School C — Enterprise active
if (!seedExists('SELECT id FROM schools WHERE code = ?', ['SCH-ISB-C9F33']) && $ent) {
    $idC = SchoolOnboardingService::provision([
        'name' => 'School C — Islamabad Prep',
        'code' => 'SCH-ISB-C9F33',
        'email' => 'admin@schoolc.local',
        'phone' => '+92-300-3000003',
        'city' => 'Islamabad',
        'country' => 'Pakistan',
        'address' => '5 Blue Area, Islamabad',
    ], [
        'name' => 'School C Admin',
        'email' => 'admin@schoolc.local',
        'password' => 'Password@123',
        'phone' => '+92-300-3000003',
    ], (int) $ent['id'], false);
    SubscriptionService::activate($idC, (int) $ent['id'], 'annual');
    echo "School C created id={$idC}\n";
}

echo "Phase 2 seed complete.\n";
echo "Super Admin: superadmin@platform.local / Password@123\n";
echo "School A: GIS001 / principal@greenfield.edu / Password@123\n";
echo "School B: SCH-LHR-B7E21 / admin@schoolb.local / Password@123\n";
echo "School C: SCH-ISB-C9F33 / admin@schoolc.local / Password@123\n";
