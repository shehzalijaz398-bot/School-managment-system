<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

Database::execute("
CREATE TABLE IF NOT EXISTS platform_firewall_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    school_id INT DEFAULT NULL,
    user_id INT DEFAULT NULL,
    attempted_email VARCHAR(255) DEFAULT NULL,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    user_agent VARCHAR(500) DEFAULT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_firewall_ip (ip_address),
    INDEX idx_firewall_event (event_type),
    INDEX idx_firewall_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");

echo "Platform firewall logs table migrated successfully.\n";
