<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';
use Core\Database;

try {
    Database::beginTransaction();

    echo "Starting Academic Terms migration...\n";

    Database::execute("
        CREATE TABLE IF NOT EXISTS academic_terms (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            academic_year_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(50) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uq_term_ay_name (academic_year_id, name),
            KEY idx_term_school_active (school_id, is_active),
            CONSTRAINT fk_term_ay FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE,
            CONSTRAINT fk_term_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
        ) ENGINE=InnoDB;
    ");

    echo "Created academic_terms table.\n";

    Database::commit();
    echo "Migration completed successfully.\n";

} catch (Throwable $e) {
    Database::rollBack();
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
