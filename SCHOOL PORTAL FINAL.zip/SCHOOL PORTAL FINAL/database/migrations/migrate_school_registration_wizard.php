<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

// Add fields to school_registrations if they don't already exist
$cols = array_column(Database::fetchAll('SHOW COLUMNS FROM school_registrations'), 'Field');

$fieldsToAdd = [
    'school_type' => "VARCHAR(100) NULL AFTER school_name",
    'website' => "VARCHAR(255) NULL AFTER school_type",
    'province' => "VARCHAR(100) NULL AFTER country",
    'area' => "VARCHAR(100) NULL AFTER city",
    'street' => "VARCHAR(255) NULL AFTER area",
    'house_number' => "VARCHAR(100) NULL AFTER street",
    'education_levels' => "VARCHAR(255) NULL AFTER estimated_students",
    'curriculum' => "VARCHAR(100) NULL AFTER education_levels",
    'academic_year_start' => "VARCHAR(50) NULL AFTER curriculum",
    'academic_year_end' => "VARCHAR(50) NULL AFTER academic_year_start",
    'estimated_staff' => "INT UNSIGNED NULL AFTER academic_year_end",
    'logo' => "VARCHAR(255) NULL AFTER plan_id",
    'terms_accepted' => "TINYINT(1) NOT NULL DEFAULT 1 AFTER status",
    'draft_data' => "LONGTEXT NULL AFTER terms_accepted",
];

foreach ($fieldsToAdd as $col => $definition) {
    if (!in_array($col, $cols, true)) {
        Database::execute("ALTER TABLE school_registrations ADD COLUMN `{$col}` {$definition}");
        echo "Added column `{$col}` to school_registrations.\n";
    }
}

// Ensure default_trial_days in platform_settings is set to 30
Database::execute("UPDATE platform_settings SET setting_value = '30' WHERE setting_key = 'default_trial_days'");
Database::execute("UPDATE plans SET trial_days = 30 WHERE trial_days IS NULL OR trial_days < 30");

echo "School registration wizard migration completed successfully.\n";
