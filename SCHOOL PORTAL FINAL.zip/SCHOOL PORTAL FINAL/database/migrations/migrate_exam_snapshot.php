<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

try {
    $sql = "
    CREATE TABLE IF NOT EXISTS exam_results_snapshot (
        id INT AUTO_INCREMENT PRIMARY KEY,
        school_id INT NOT NULL,
        academic_year_id INT NOT NULL,
        exam_id INT NOT NULL,
        class_id INT NOT NULL,
        section_id INT NOT NULL,
        student_id INT NOT NULL,
        total_obtained_marks DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        total_max_marks DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        final_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        class_position INT NULL,
        status VARCHAR(50) DEFAULT 'published',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_exam_results_deep (school_id, exam_id, class_id, final_percentage)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    Database::execute($sql);
    echo "Table exam_results_snapshot created successfully.\n";
} catch (Throwable $e) {
    if (str_contains(strtolower($e->getMessage()), 'already exists')) {
        echo "Table exam_results_snapshot already exists.\n";
    } else {
        throw $e;
    }
}
