<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

try {
    $cols = array_column(Database::fetchAll('DESCRIBE schools'), 'Field');
    if (!in_array('trial_started_at', $cols, true)) {
        Database::execute('ALTER TABLE schools ADD COLUMN trial_started_at DATETIME NULL AFTER subscription_status');
        echo "Added trial_started_at column to schools table.\n";
    } else {
        echo "trial_started_at column already exists in schools table.\n";
    }

    // Ensure password_resets table exists
    Database::execute("
        CREATE TABLE IF NOT EXISTS password_resets (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id INT NULL,
            email VARCHAR(191) NOT NULL,
            ip_address VARCHAR(45) NULL,
            token_hash VARCHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            INDEX idx_email_expires (email, expires_at),
            INDEX idx_token_hash (token_hash)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    echo "password_resets table verified.\n";
} catch (\Throwable $e) {
    echo "Migration notice: " . $e->getMessage() . "\n";
}
