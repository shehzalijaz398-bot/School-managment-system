<?php

declare(strict_types=1);

/**
 * Migrate Academic Foundation
 */

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

if (!function_exists('columnExists')) {
    function columnExists(string $table, string $column): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
            [$table, $column]
        );
        return ((int) ($row['c'] ?? 0)) > 0;
    }
}

if (!function_exists('indexExists')) {
    function indexExists(string $table, string $index): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?',
            [$table, $index]
        );
        return ((int) ($row['c'] ?? 0)) > 0;
    }
}

try {
    Database::beginTransaction();

    echo "Starting Academic Foundation migration...\n";

    // 1. Add academic_year_id to sections
    if (!columnExists('sections', 'academic_year_id')) {
        Database::execute("ALTER TABLE sections ADD COLUMN academic_year_id BIGINT UNSIGNED NULL AFTER class_id");
        Database::execute("ALTER TABLE sections ADD CONSTRAINT fk_section_ay FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT");
        echo "Added academic_year_id to sections.\n";
    }

    // 2. Add class_teacher_id to sections
    if (!columnExists('sections', 'class_teacher_id')) {
        Database::execute("ALTER TABLE sections ADD COLUMN class_teacher_id BIGINT UNSIGNED NULL AFTER capacity");
        Database::execute("ALTER TABLE sections ADD CONSTRAINT fk_section_ct FOREIGN KEY (class_teacher_id) REFERENCES teachers(id) ON DELETE SET NULL");
        echo "Added class_teacher_id to sections.\n";
    }

    // 3. Update unique key on sections to include academic_year_id
    if (indexExists('sections', 'uq_section_class_name')) {
        // MySQL relies on uq_section_class_name for the fk_section_school constraint.
        // Create an explicit index for school_id so we can drop the unique key safely.
        Database::execute("CREATE INDEX idx_section_school ON sections (school_id)");

        Database::execute("ALTER TABLE sections DROP INDEX uq_section_class_name");
        Database::execute("ALTER TABLE sections ADD UNIQUE KEY uq_section_ay_class_name (school_id, academic_year_id, class_id, name)");
        echo "Updated unique key on sections.\n";
    }

    // Ensure permissions for academic sessions exist
    $modules = [
        'academic_sessions' => ['manage', 'view'],
        'teacher_assignments' => ['manage', 'view']
    ];

    foreach ($modules as $module => $actions) {
        foreach ($actions as $action) {
            $slug = "{$module}.{$action}";
            $exists = Database::fetch("SELECT id FROM permissions WHERE slug = ?", [$slug]);
            if (!$exists) {
                Database::execute(
                    "INSERT INTO permissions (name, slug, module, created_at) VALUES (?, ?, ?, NOW())",
                    [ucwords(str_replace('_', ' ', $module)) . ' ' . ucfirst($action), $slug, $module]
                );
                echo "Added permission: {$slug}\n";
            }
        }
    }

    Database::commit();
    echo "Academic Foundation migration completed successfully.\n";

} catch (Throwable $e) {
    Database::rollBack();
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
