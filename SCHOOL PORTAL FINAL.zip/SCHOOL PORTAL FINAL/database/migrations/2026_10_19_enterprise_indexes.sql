-- Enterprise Index Optimization Migration
-- Antigravity Engine: High-throughput Multi-tenant Index Optimization

-- 1. PTM Appointments Isolation & Search Indexes
ALTER TABLE `ptm_appointments` 
  ADD INDEX `idx_ptm_school_date` (`school_id`, `meeting_date`),
  ADD INDEX `idx_ptm_school_teacher` (`school_id`, `teacher_id`),
  ADD INDEX `idx_ptm_school_student` (`school_id`, `student_id`);

-- 2. Assignment Submissions Query Index
ALTER TABLE `assignment_submissions`
  ADD INDEX `idx_asub_school_assign_status` (`school_id`, `assignment_id`, `status`);

-- 3. Payments Tenant Cross-Lookup Index
ALTER TABLE `payments`
  ADD INDEX `idx_pay_school_invoice` (`school_id`, `invoice_id`);

-- 4. Behavior & Merit Logs Fast Lookup
ALTER TABLE `student_behaviour_logs`
  ADD INDEX `idx_sbl_school_student` (`school_id`, `student_id`),
  ADD INDEX `idx_sbl_school_action` (`school_id`, `action_type`);

-- 5. Student Warnings Lookup
ALTER TABLE `student_warnings`
  ADD INDEX `idx_sw_school_student` (`school_id`, `student_id`);

-- 6. Exam Marks High-Throughput Aggregation Index
ALTER TABLE `exam_marks`
  ADD INDEX `idx_em_school_student_exam` (`school_id`, `student_id`, `exam_id`);
