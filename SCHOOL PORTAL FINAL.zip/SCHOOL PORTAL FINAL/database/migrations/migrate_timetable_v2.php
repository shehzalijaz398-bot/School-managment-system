<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

try {
    Database::execute("
        CREATE TABLE IF NOT EXISTS timetable_periods (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(100) NULL,
            period_number INT NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            type ENUM('Regular', 'Break', 'Assembly', 'Free Period') DEFAULT 'Regular',
            status TINYINT(1) DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            KEY idx_ttp_school (school_id, period_number),
            CONSTRAINT fk_ttp_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
} catch (Throwable $e) {}

try {
    $cols = array_column(Database::fetchAll('SHOW COLUMNS FROM timetables'), 'Field');
    if (!in_array('period_id', $cols, true)) {
        Database::execute("ALTER TABLE timetables ADD COLUMN period_id BIGINT UNSIGNED NULL AFTER teacher_id");
    }
} catch (Throwable $e) {}

try {
    Database::execute("
        ALTER TABLE timetables
        ADD COLUMN notes TEXT NULL AFTER room,
        ADD COLUMN status TINYINT(1) DEFAULT 1 AFTER notes;
    ");
} catch (Throwable $e) {}

echo "Timetable V2 migration completed successfully.\n";
