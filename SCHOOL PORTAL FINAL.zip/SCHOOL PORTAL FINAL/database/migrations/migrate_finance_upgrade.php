<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

try {
    Database::execute("ALTER TABLE fee_categories ADD COLUMN IF NOT EXISTS code VARCHAR(50) NULL AFTER name;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE fee_categories ADD COLUMN IF NOT EXISTS description VARCHAR(255) NULL AFTER code;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE fee_categories ADD COLUMN IF NOT EXISTS scope VARCHAR(50) NULL DEFAULT 'global' AFTER frequency;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE fee_categories ADD COLUMN IF NOT EXISTS overrides_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER scope;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE schools ADD COLUMN IF NOT EXISTS fee_due_day INT NOT NULL DEFAULT 7 AFTER status;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE student_fee_invoices ADD COLUMN IF NOT EXISTS last_warning_sent_at TIMESTAMP NULL DEFAULT NULL AFTER status;");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE student_fee_invoices ADD INDEX idx_mass_billing (school_id, status, due_date);");
} catch (Throwable $e) {}

try {
    Database::execute("
    CREATE TABLE IF NOT EXISTS student_warnings (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        school_id BIGINT UNSIGNED NOT NULL,
        student_id INT NOT NULL,
        invoice_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_student_warnings_tenant (school_id, student_id, is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
} catch (Throwable $e) {}

echo "Finance upgrade migration completed successfully.\n";
