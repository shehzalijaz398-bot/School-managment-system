<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

echo "Migrating: create_message_queues_table...\n";

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `message_queues` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `school_id` BIGINT UNSIGNED NOT NULL,
  `channel` ENUM('whatsapp', 'sms', 'email', 'push') NOT NULL DEFAULT 'whatsapp',
  `provider` VARCHAR(50) NOT NULL DEFAULT 'whatsapp_cloud',
  `recipient` VARCHAR(191) NOT NULL,
  `recipient_name` VARCHAR(150) DEFAULT NULL,
  `recipient_id` BIGINT UNSIGNED DEFAULT NULL,
  `recipient_type` VARCHAR(50) DEFAULT NULL,
  `message_type` VARCHAR(50) NOT NULL DEFAULT 'general',
  `subject` VARCHAR(255) DEFAULT NULL,
  `payload` LONGTEXT NOT NULL,
  `priority` TINYINT UNSIGNED NOT NULL DEFAULT 5 COMMENT '1=Urgent, 3=High, 5=Normal, 10=Bulk',
  `status` ENUM('pending', 'processing', 'sent', 'failed') NOT NULL DEFAULT 'pending',
  `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `max_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 3,
  `reserved_at` DATETIME DEFAULT NULL,
  `reserved_by` VARCHAR(100) DEFAULT NULL,
  `available_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` DATETIME DEFAULT NULL,
  `failed_at` DATETIME DEFAULT NULL,
  `error_message` TEXT DEFAULT NULL,
  `gateway_message_id` VARCHAR(150) DEFAULT NULL,
  `gateway_response` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_queue_dispatch` (`status`, `priority`, `available_at`, `school_id`),
  KEY `idx_queue_reservation` (`status`, `reserved_at`),
  KEY `idx_school_type_status` (`school_id`, `message_type`, `status`),
  KEY `idx_recipient` (`recipient`),
  KEY `idx_gateway_msg_id` (`gateway_message_id`),
  CONSTRAINT `fk_msg_queue_school` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

Database::execute($sql);

echo "Migration completed successfully: `message_queues` table created.\n";
