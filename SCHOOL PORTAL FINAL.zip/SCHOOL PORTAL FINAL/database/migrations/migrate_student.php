<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

Database::execute("INSERT IGNORE INTO roles (slug, name, description, is_system) VALUES ('student', 'Student', 'Student access portal', 1)");

try {
    Database::execute("ALTER TABLE students MODIFY COLUMN user_id BIGINT UNSIGNED NULL DEFAULT NULL");
} catch (Throwable $e) {}

try {
    Database::execute("ALTER TABLE students ADD CONSTRAINT fk_students_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL");
} catch (Throwable $e) {}

echo "Student migration completed successfully.\n";
