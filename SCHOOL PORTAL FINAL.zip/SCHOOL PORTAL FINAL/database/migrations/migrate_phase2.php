<?php

declare(strict_types=1);

/**
 * Safe Phase 2 migrator — run: php database/migrate_phase2.php
 */

require_once dirname(__DIR__, 2) . '/core/bootstrap.php';

use Core\Database;

if (!function_exists('columnExists')) {
    function columnExists(string $table, string $column): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
            [$table, $column]
        );
        return ((int) ($row['c'] ?? 0)) > 0;
    }
}

if (!function_exists('indexExists')) {
    function indexExists(string $table, string $index): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?',
            [$table, $index]
        );
        return ((int) ($row['c'] ?? 0)) > 0;
    }
}

if (!function_exists('stripSqlComments')) {
    function stripSqlComments(string $stmt): string
    {
        $lines = preg_split('/\R/', $stmt) ?: [];
        $clean = [];
        foreach ($lines as $line) {
            $trimmed = trim($line);
            if ($trimmed === '' || str_starts_with($trimmed, '--') || str_starts_with($trimmed, '#')) {
                continue;
            }
            $clean[] = $line;
        }
        return trim(implode("\n", $clean));
    }
}

echo "Phase 2 migration starting...\n";

$schoolCols = [
    'school_uuid' => "CHAR(36) NULL",
    'city' => "VARCHAR(100) NULL",
    'province' => "VARCHAR(100) NULL",
    'country' => "VARCHAR(100) NULL",
    'area' => "VARCHAR(100) NULL",
    'street' => "VARCHAR(255) NULL",
    'house_number' => "VARCHAR(100) NULL",
    'timezone' => "VARCHAR(64) NULL DEFAULT 'Asia/Karachi'",
    'currency' => "VARCHAR(10) NULL DEFAULT 'PKR'",
    'plan_id' => "BIGINT UNSIGNED NULL",
    'subscription_status' => "VARCHAR(30) NOT NULL DEFAULT 'active'",
    'trial_ends_at' => "DATETIME NULL",
    'subscription_ends_at' => "DATETIME NULL",
    'notes' => "TEXT NULL",
    'archived_at' => "DATETIME NULL",
    'deleted_at' => "DATETIME NULL",
];

foreach ($schoolCols as $col => $def) {
    if (!columnExists('schools', $col)) {
        Database::execute("ALTER TABLE schools ADD COLUMN {$col} {$def}");
        echo "Added schools.{$col}\n";
    }
}

if (!indexExists('schools', 'uq_schools_uuid') && columnExists('schools', 'school_uuid')) {
    try {
        Database::execute('CREATE UNIQUE INDEX uq_schools_uuid ON schools (school_uuid)');
    } catch (Throwable $e) {
        echo "Index note: " . $e->getMessage() . "\n";
    }
}

$sqlFile = dirname(__DIR__, 2) . '/database/phase2_schema.sql';
$raw = file_get_contents($sqlFile);
$statements = array_filter(array_map('trim', preg_split('/;\s*\n/', $raw) ?: []));

foreach ($statements as $stmt) {
    $stmt = stripSqlComments($stmt);
    if ($stmt === '') {
        continue;
    }
    $upper = strtoupper($stmt);
    if (str_starts_with($upper, 'USE ') || str_starts_with($upper, 'SET ')) {
        continue;
    }
    if (preg_match('/^ALTER TABLE schools/i', $stmt)) {
        continue;
    }
    if (preg_match('/^CREATE (UNIQUE )?INDEX IF NOT EXISTS/i', $stmt)) {
        if (preg_match('/CREATE (UNIQUE )?INDEX IF NOT EXISTS (\w+) ON (\w+)/i', $stmt, $m)) {
            $idx = $m[2];
            $tbl = $m[3];
            if (indexExists($tbl, $idx)) {
                continue;
            }
            $stmt = preg_replace('/IF NOT EXISTS\s+/i', '', $stmt) ?? $stmt;
        }
    }
    try {
        Database::execute($stmt);
        if (preg_match('/CREATE TABLE IF NOT EXISTS (\w+)/i', $stmt, $m)) {
            echo "Ensured table {$m[1]}\n";
        }
    } catch (Throwable $e) {
        echo "Skip/Warn: " . substr($e->getMessage(), 0, 160) . "\n";
    }
}

echo "Phase 2 schema migration complete.\n";
