"use client"

import * as React from "react"
import { Home, Sparkles, Layers, DollarSign } from "lucide-react"
import { AnimeNavBar } from "@/components/ui/anime-navbar"

const items = [
  {
    name: "Home",
    url: "#home",
    icon: Home,
  },
  {
    name: "Features",
    url: "#features",
    icon: Sparkles,
  },
  {
    name: "Architecture",
    url: "#architecture",
    icon: Layers,
  },
  {
    name: "Pricing",
    url: "#pricing",
    icon: DollarSign,
  },
]

export function AnimeNavBarDemo() {
  return (
    <div className="relative min-h-[300px] w-full bg-[#0B192C] flex items-center justify-center">
      <AnimeNavBar items={items} defaultActive="Pricing" />
    </div>
  )
}
