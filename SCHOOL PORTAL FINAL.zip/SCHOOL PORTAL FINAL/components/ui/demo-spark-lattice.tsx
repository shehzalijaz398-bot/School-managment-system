"use client"

import * as React from "react"
import SparkLattice from "@/components/ui/spark-lattice"

export default function SparkLatticeDemo() {
    return (
        <div className="relative w-full h-[600px] overflow-hidden rounded-2xl bg-[#070D18]">
            <SparkLattice
                background="#070D18"
                lineColor="#111E33"
                accent="#01baef"
                size={110}
                lights={8}
                speed={50}
                trail={6}
                glow={92}
                hover={100}
            />
        </div>
    )
}
