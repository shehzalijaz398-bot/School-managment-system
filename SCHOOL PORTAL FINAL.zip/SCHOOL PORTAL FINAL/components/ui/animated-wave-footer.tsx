"use client";

import * as React from "react";
import { 
  Send, 
  Mail, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  ExternalLink,
  Twitter, 
  Linkedin, 
  Facebook, 
  Instagram, 
  Github,
  GraduationCap
} from "lucide-react";

export interface AnimatedWaveFooterProps {
  companyName?: string;
  supportEmail?: string;
  phone?: string;
  address?: string;
}

export default function AnimatedWaveFooter({
  companyName = "School Portal SaaS",
  supportEmail = "support@schoolportalsaas.com",
  phone = "+1 (800) 555-0199",
  address = "Innovation Tech Park, Suite 400, Education City, CA 94016"
}: AnimatedWaveFooterProps) {
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail("");
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  return (
    <footer className="relative bg-[#070D18] text-slate-300 pt-28 pb-12 overflow-hidden border-t border-white/5">
      {/* Dynamic Multi-Layer Animated Wave Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
        {/* Ambient Top Glow */}
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-[#01baef]/12 rounded-full blur-[120px]" />
        
        {/* Layer 1 - Deep Slow Wave */}
        <div className="absolute bottom-0 w-[200%] h-[560px] opacity-40 animate-[wave_20s_linear_infinite]">
          <svg
            className="w-full h-full"
            viewBox="0 0 1800 500"
            preserveAspectRatio="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M0 240C250 140 500 340 750 200C1000 80 1250 300 1500 180C1650 110 1750 200 1800 240V500H0V240Z"
              fill="url(#wave-grad-1)"
            />
            <defs>
              <linearGradient id="wave-grad-1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#01baef" stopOpacity="0.25" />
                <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#01baef" stopOpacity="0.25" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Layer 2 - Fast Foreground Accent Wave */}
        <div className="absolute bottom-0 w-[200%] h-[480px] opacity-55 animate-[wave_14s_linear_infinite_reverse]">
          <svg
            className="w-full h-full"
            viewBox="0 0 1800 440"
            preserveAspectRatio="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M0 200C220 300 450 120 700 240C950 360 1200 150 1450 250C1650 320 1750 180 1800 200V440H0V200Z"
              fill="url(#wave-grad-2)"
            />
            <defs>
              <linearGradient id="wave-grad-2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#0284c7" stopOpacity="0.32" />
                <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.22" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0.32" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Newsletter & SaaS Banner Card */}
        <div className="relative mb-16 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl p-8 lg:p-12 shadow-2xl overflow-hidden">
          <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-[#01baef]/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid gap-8 lg:grid-cols-12 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#01baef]/10 border border-[#01baef]/20 text-[#01baef] text-xs font-semibold mb-4">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Enterprise Multi-Tenant Cloud ERP</span>
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
                Stay Connected with Educational Innovation
              </h2>
              <p className="mt-3 text-slate-400 text-sm sm:text-base leading-relaxed max-w-xl">
                Receive platform enhancements, academic compliance notices, and institutional automation updates directly in your mailbox.
              </p>
            </div>

            <div className="lg:col-span-5">
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your institutional email..."
                    className="w-full bg-[#0B1426]/90 border border-white/15 rounded-xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-[#01baef] focus:ring-2 focus:ring-[#01baef]/20 transition-all shadow-inner"
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 bg-[#01baef] hover:bg-[#00a3d4] text-[#0B192C] font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-[#01baef]/25 hover:shadow-[#01baef]/40 transition-all active:scale-95 whitespace-nowrap cursor-pointer"
                >
                  <span>Subscribe</span>
                  <Send className="w-4 h-4" />
                </button>
              </form>

              {subscribed && (
                <div className="mt-3 inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Thank you! Your institutional subscription is confirmed.</span>
                </div>
              )}
              <p className="mt-2.5 text-xs text-slate-500">
                Zero spam. Encrypted institutional transmission. Unsubscribe anytime.
              </p>
            </div>
          </div>
        </div>

        {/* 4-Column Clean Project Directory Navigation */}
        <div className="grid gap-10 grid-cols-2 md:grid-cols-4 lg:grid-cols-12 text-sm mb-16">
          {/* Col 1: Platform & Vision */}
          <div className="col-span-2 md:col-span-4 lg:col-span-5">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-9 h-9 rounded-xl bg-[#01baef] flex items-center justify-center text-[#0B192C] font-black text-lg shadow-md shadow-[#01baef]/30">
                S
              </div>
              <span className="text-white font-extrabold text-lg tracking-tight">
                {companyName}
              </span>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-6 max-w-md">
              Complete, cloud-based platform to manage Students, Faculty, Attendance, Exams, Finance, and Parents—all in one unified SaaS interface.
            </p>
            
            {/* System Status Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>All Cloud Clusters Operational</span>
            </div>
          </div>

          {/* Col 2: Core Platform Modules */}
          <div className="col-span-1 md:col-span-2 lg:col-span-3">
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Core Modules
            </h3>
            <ul className="space-y-2.5">
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Student Admissions & Records
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Smart Daily Attendance
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Examination & Automated Grading
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Homework & Submission Desk
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Conflict-Free Timetables
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Fee Billing & Payroll Ledger
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Dedicated Portals */}
          <div className="col-span-1 md:col-span-2 lg:col-span-2">
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Dedicated Portals
            </h3>
            <ul className="space-y-2.5">
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>School Admin</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>Faculty Hub</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>Student Desk</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>Parent Portal</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>Finance Desk</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-[#01baef] transition-colors flex items-center gap-1.5">
                  <span>Super Admin</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Platform Navigation */}
          <div className="col-span-2 md:col-span-2 lg:col-span-2">
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Platform Access
            </h3>
            <ul className="space-y-2.5">
              <li>
                <a href="#home" className="text-slate-400 hover:text-white transition-colors">
                  Home Overview
                </a>
              </li>
              <li>
                <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                  Platform Features
                </a>
              </li>
              <li>
                <a href="#architecture" className="text-slate-400 hover:text-white transition-colors">
                  SaaS Architecture
                </a>
              </li>
              <li>
                <a href="#pricing" className="text-slate-400 hover:text-white transition-colors">
                  Subscription Plans
                </a>
              </li>
              <li>
                <a href="/register" className="text-slate-400 hover:text-white transition-colors">
                  Register School
                </a>
              </li>
              <li>
                <a href="/login" className="text-slate-400 hover:text-white transition-colors">
                  Sign In to Account
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Clean Copyright & Direct Section Navigation */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} {companyName}. Complete Multi-Tenant Enterprise Education System.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <a href="#home" className="hover:text-white transition-colors">Home</a>
            <span>·</span>
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <span>·</span>
            <a href="#architecture" className="hover:text-white transition-colors">Architecture</a>
            <span>·</span>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <span>·</span>
            <a href="/login" className="hover:text-white transition-colors">Sign In</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
