"use client";

import * as React from "react";
import AnimatedWaveFooter from "@/components/ui/animated-wave-footer";

export default function AnimatedWaveFooterDemo() {
  return (
    <div className="w-full bg-[#070D18]">
      <AnimatedWaveFooter 
        companyName="School Portal SaaS"
        supportEmail="support@schoolportalsaas.com"
        phone="+1 (800) 555-0199"
        address="Innovation Tech Park, Suite 400, Education City, CA 94016"
      />
    </div>
  );
}
