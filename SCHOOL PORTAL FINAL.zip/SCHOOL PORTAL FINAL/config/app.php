<?php

declare(strict_types=1);

return [
    'name' => env('APP_NAME', 'SchoolPortal'),
    'env' => env('APP_ENV', 'local'), // local | production
    'debug' => env('APP_DEBUG', true),
    'url' => env('APP_URL', 'http://localhost/SCHOOL%20PORTAL%20FINAL/public'),
    'timezone' => env('APP_TIMEZONE', 'Asia/Karachi'),
    'locale' => env('APP_LOCALE', 'en'),
    'session' => [
        'name' => env('SESSION_NAME', 'SCHOOLPORTAL_SESSID'),
        'lifetime' => (int) env('SESSION_LIFETIME', 7200),
        'secure' => (bool) env('SESSION_SECURE', false),
        'httponly' => true,
        'samesite' => env('SESSION_SAMESITE', 'Lax'),
    ],
    'csrf_token_name' => '_csrf_token',
    'password_reset_expiry' => 3600,
    'backup_key' => env('BACKUP_ENCRYPTION_KEY', 'super_secret_unexposed_vault_key_AES_256'),
    'login' => [
        'max_attempts' => 5,
        'lockout_minutes' => 15,
    ],
    'upload' => [
        'max_size' => 5 * 1024 * 1024,
        'allowed_images' => ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
        'allowed_docs' => [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/png',
        ],
    ],
    'attendance' => [
        'edit_window_hours' => 48,
    ],
    'remember_me' => [
        'enabled' => true,
        'days' => 30,
        'cookie' => 'sp_remember',
    ],
];
