<?php

declare(strict_types=1);

/**
 * AI Chatbot Configuration
 * Supports Google Gemini API & OpenAI API with tenant guardrails.
 */
return [
    // Default provider: 'gemini' or 'openai'
    'provider' => env('AI_PROVIDER', 'gemini'),

    // Google Gemini API Configuration
    'gemini' => [
        'api_key' => env('GEMINI_API_KEY', ''),
        'model' => env('GEMINI_MODEL', 'gemini-1.5-flash'),
        'endpoint' => 'https://generativelanguage.googleapis.com/v1beta/models',
    ],

    // OpenAI API Configuration
    'openai' => [
        'api_key' => env('OPENAI_API_KEY', ''),
        'model' => env('OPENAI_MODEL', 'gpt-4o-mini'),
        'endpoint' => 'https://api.openai.com/v1/chat/completions',
    ],

    // LLM Inference Tuning
    'temperature' => 0.25,
    'max_tokens' => 1024,
    'top_p' => 0.95,

    // Safety and Rate Limiting
    'rate_limit' => [
        'max_requests_per_minute' => 25,
        'max_prompt_chars' => 1000,
        'max_history_turns' => 6,
    ],

    // Feature Flags
    'features' => [
        'streaming_enabled' => true,
        'mock_fallback_on_missing_key' => true,
        'log_conversations' => true,
    ],
];
