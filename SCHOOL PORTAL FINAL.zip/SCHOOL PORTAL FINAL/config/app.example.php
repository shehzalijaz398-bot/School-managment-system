<?php

declare(strict_types=1);

/**
 * Copy to app.php and adjust for your environment.
 */
return [
    'name' => 'SchoolPortal',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost/SCHOOL%20PORTAL%20FINAL/public',
    'timezone' => 'Asia/Karachi',
];
