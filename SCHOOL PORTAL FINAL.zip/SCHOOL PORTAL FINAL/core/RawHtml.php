<?php

declare(strict_types=1);

namespace Core;

/**
 * Value object wrapper to mark trusted HTML strings that should bypass automatic XSS escaping.
 */
final class RawHtml implements \Stringable
{
    public function __construct(private string $html)
    {
    }

    public function __toString(): string
    {
        return $this->html;
    }

    public function getHtml(): string
    {
        return $this->html;
    }

    public static function mark(string $html): self
    {
        return new self($html);
    }
}
