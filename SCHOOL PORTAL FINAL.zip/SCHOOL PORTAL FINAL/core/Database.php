<?php

declare(strict_types=1);

namespace Core;

use PDO;
use PDOException;
use PDOStatement;

final class Database
{
    private static ?PDO $pdo = null;
    private static int $txDepth = 0;

    /** @var array<int, array{sql: string, params: array, time_ms: float}> */
    private static array $queryLog = [];
    private static bool $loggingEnabled = false;

    /** @var array<int, callable> Query event listeners */
    private static array $listeners = [];

    public static function connection(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $config = require dirname(__DIR__) . '/config/database.php';

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $config['host'],
            (int) $config['port'],
            $config['database'],
            $config['charset']
        );

        try {
            self::$pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            throw new PDOException('Database connection failed. Please check configuration.');
        }

        return self::$pdo;
    }

    /**
     * Prepare and execute a parameterized query with telemetry, timing, and listener hooks.
     *
     * @param string $sql
     * @param array<int|string, mixed> $params
     * @return PDOStatement
     */
    public static function query(string $sql, array $params = []): PDOStatement
    {
        $start = microtime(true);
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        $elapsed = (microtime(true) - $start) * 1000.0;

        if (self::$loggingEnabled) {
            self::$queryLog[] = [
                'sql' => $sql,
                'params' => $params,
                'time_ms' => round($elapsed, 3),
            ];
        }

        // Fire registered query listeners (e.g. for profiling slow queries > 250ms)
        foreach (self::$listeners as $listener) {
            $listener($sql, $params, $elapsed);
        }

        return $stmt;
    }

    public static function fetch(string $sql, array $params = []): ?array
    {
        $row = self::query($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function insert(string $sql, array $params = []): int
    {
        self::query($sql, $params);
        return (int) self::connection()->lastInsertId();
    }

    public static function execute(string $sql, array $params = []): int
    {
        return self::query($sql, $params)->rowCount();
    }

    public static function fetchValue(string $sql, array $params = []): mixed
    {
        $val = self::query($sql, $params)->fetchColumn();
        return $val === false ? null : $val;
    }

    public static function beginTransaction(): void
    {
        if (self::$txDepth === 0) {
            self::connection()->beginTransaction();
        }
        self::$txDepth++;
    }

    public static function commit(): void
    {
        if (self::$txDepth <= 0) {
            return;
        }
        self::$txDepth--;
        if (self::$txDepth === 0 && self::connection()->inTransaction()) {
            self::connection()->commit();
        }
    }

    public static function rollBack(): void
    {
        if (self::$txDepth > 0) {
            self::$txDepth = 0;
            if (self::connection()->inTransaction()) {
                self::connection()->rollBack();
            }
        }
    }

    public static function inTransaction(): bool
    {
        return self::$txDepth > 0 || self::connection()->inTransaction();
    }

    public static function lastInsertId(): int
    {
        return (int) self::connection()->lastInsertId();
    }

    /**
     * Execute a callback inside a safe transaction closure with auto-commit / auto-rollback.
     * Guarantees locks are released even on unhandled exceptions.
     *
     * @template T
     * @param callable(PDO): T $callback
     * @return T
     * @throws \Throwable
     */
    public static function transaction(callable $callback): mixed
    {
        self::beginTransaction();
        try {
            $result = $callback(self::connection());
            self::commit();
            return $result;
        } catch (\Throwable $e) {
            self::rollBack();
            throw $e;
        }
    }

    /**
     * Inspect execution plan for a SQL query via EXPLAIN.
     *
     * @param string $sql
     * @param array<int|string, mixed> $params
     * @return array<int, array<string, mixed>>
     */
    public static function explain(string $sql, array $params = []): array
    {
        return self::fetchAll('EXPLAIN ' . $sql, $params);
    }

    /**
     * Enable in-memory query profiling.
     */
    public static function enableQueryLog(): void
    {
        self::$loggingEnabled = true;
    }

    /**
     * Disable query profiling and flush memory.
     */
    public static function disableQueryLog(): void
    {
        self::$loggingEnabled = false;
        self::$queryLog = [];
    }

    /**
     * Retrieve logged query executions.
     *
     * @return array<int, array{sql: string, params: array, time_ms: float}>
     */
    public static function getQueryLog(): array
    {
        return self::$queryLog;
    }

    /**
     * Register a callback listener triggered after every query execution.
     *
     * @param callable(string $sql, array $params, float $timeMs): void $callback
     */
    public static function listen(callable $callback): void
    {
        self::$listeners[] = $callback;
    }
}
