<?php

declare(strict_types=1);

namespace Core;

final class Validator
{
    private array $errors = [];
    private array $data = [];

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public static function make(array $data, array $rules): self
    {
        $v = new self($data);
        $v->validate($rules);
        return $v;
    }

    public function validate(array $rules): void
    {
        foreach ($rules as $field => $ruleString) {
            $rulesList = is_array($ruleString) ? $ruleString : explode('|', $ruleString);
            $value = $this->data[$field] ?? null;

            foreach ($rulesList as $rule) {
                $param = null;
                if (str_contains($rule, ':')) {
                    [$rule, $param] = explode(':', $rule, 2);
                }

                $method = 'rule' . ucfirst($rule);
                if (method_exists($this, $method)) {
                    $this->{$method}($field, $value, $param);
                }
            }
        }
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    public function passes(): bool
    {
        return !$this->fails();
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): ?string
    {
        foreach ($this->errors as $fieldErrors) {
            return $fieldErrors[0] ?? null;
        }
        return null;
    }

    public function validated(): array
    {
        return $this->data;
    }

    private function addError(string $field, string $message): void
    {
        $this->errors[$field][] = $message;
    }

    private function ruleRequired(string $field, mixed $value, ?string $param): void
    {
        if ($value === null || $value === '' || (is_array($value) && $value === [])) {
            $this->addError($field, ucfirst(str_replace('_', ' ', $field)) . ' is required.');
        }
    }

    private function ruleEmail(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '' && !filter_var((string) $value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, 'Invalid email address.');
        }
    }

    private function ruleMin(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '' && mb_strlen((string) $value) < (int) $param) {
            $this->addError($field, ucfirst(str_replace('_', ' ', $field)) . " must be at least {$param} characters.");
        }
    }

    private function ruleMax(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '' && mb_strlen((string) $value) > (int) $param) {
            $this->addError($field, ucfirst(str_replace('_', ' ', $field)) . " must not exceed {$param} characters.");
        }
    }

    private function ruleNumeric(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '' && !is_numeric($value)) {
            $this->addError($field, ucfirst(str_replace('_', ' ', $field)) . ' must be numeric.');
        }
    }

    private function ruleInteger(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '' && filter_var($value, FILTER_VALIDATE_INT) === false) {
            $this->addError($field, ucfirst(str_replace('_', ' ', $field)) . ' must be an integer.');
        }
    }

    private function ruleIn(string $field, mixed $value, ?string $param): void
    {
        $allowed = explode(',', (string) $param);
        if ($value !== null && $value !== '' && !in_array((string) $value, $allowed, true)) {
            $this->addError($field, 'Invalid value for ' . str_replace('_', ' ', $field) . '.');
        }
    }

    private function ruleDate(string $field, mixed $value, ?string $param): void
    {
        if ($value !== null && $value !== '') {
            $d = \DateTime::createFromFormat('Y-m-d', (string) $value);
            if (!$d || $d->format('Y-m-d') !== $value) {
                $this->addError($field, 'Invalid date format.');
            }
        }
    }

    private function ruleConfirmed(string $field, mixed $value, ?string $param): void
    {
        $confirm = $this->data[$field . '_confirmation'] ?? null;
        if ((string) $value !== (string) $confirm) {
            $this->addError($field, 'Confirmation does not match.');
        }
    }
}
