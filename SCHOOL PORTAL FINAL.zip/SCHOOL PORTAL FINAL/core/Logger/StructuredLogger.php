<?php

declare(strict_types=1);

namespace Core\Logger;

use Core\Auth;
use Core\Database;
use Throwable;

/**
 * StructuredLogger
 *
 * Enterprise structured JSON logger and real-time actionable alert engine.
 * - Rotates logs daily into storage/logs/schoolportal-YYYY-MM-DD.log
 * - Automatic redaction of sensitive credentials, tokens, and PII
 * - Real-time actionable alerts stored in system_alerts with incident aggregation
 */
final class StructuredLogger
{
    public const EMERGENCY = 'EMERGENCY';
    public const ALERT     = 'ALERT';
    public const CRITICAL  = 'CRITICAL';
    public const ERROR     = 'ERROR';
    public const WARNING   = 'WARNING';
    public const NOTICE    = 'NOTICE';
    public const INFO      = 'INFO';
    public const DEBUG     = 'DEBUG';

    private static ?string $logDir = null;
    private static bool $schemaChecked = false;

    /**
     * Get or initialize the storage logs directory.
     */
    public static function getLogDir(): string
    {
        if (self::$logDir === null) {
            self::$logDir = dirname(__DIR__, 2) . '/storage/logs';
            if (!is_dir(self::$logDir)) {
                @mkdir(self::$logDir, 0755, true);
            }
        }
        return self::$logDir;
    }

    public static function emergency(string $message, array $context = []): void
    {
        self::log(self::EMERGENCY, $message, $context);
    }

    public static function alert(string $message, array $context = []): void
    {
        self::log(self::ALERT, $message, $context);
    }

    public static function critical(string $message, array $context = []): void
    {
        self::log(self::CRITICAL, $message, $context);
    }

    public static function error(string $message, array $context = []): void
    {
        self::log(self::ERROR, $message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::log(self::WARNING, $message, $context);
    }

    public static function notice(string $message, array $context = []): void
    {
        self::log(self::NOTICE, $message, $context);
    }

    public static function info(string $message, array $context = []): void
    {
        self::log(self::INFO, $message, $context);
    }

    public static function debug(string $message, array $context = []): void
    {
        // Only write debug in development or if APP_DEBUG is true
        if (self::isDebugEnabled()) {
            self::log(self::DEBUG, $message, $context);
        }
    }

    /**
     * Write structured log entry to daily log file and dispatch actionable alert if critical.
     */
    public static function log(string $level, string $message, array $context = []): void
    {
        $logDir = self::getLogDir();
        $date = date('Y-m-d');
        $filePath = "{$logDir}/schoolportal-{$date}.log";

        $cleanContext = self::sanitizeData($context);
        $cleanMessage = self::sanitizeString($message);

        $entry = [
            'timestamp'  => date('c'),
            'level'      => strtoupper($level),
            'message'    => $cleanMessage,
            'tenant_id'  => (class_exists(Auth::class) && method_exists(Auth::class, 'schoolId')) ? (Auth::schoolId() ?? 0) : 0,
            'user_id'    => (class_exists(Auth::class) && method_exists(Auth::class, 'id')) ? (Auth::id() ?? 0) : 0,
            'ip'         => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'method'     => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'uri'        => $_SERVER['REQUEST_URI'] ?? (isset($argv) ? implode(' ', $argv) : 'CLI'),
            'context'    => $cleanContext,
        ];

        // Format single line JSON
        $json = json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        @file_put_contents($filePath, $json . "\n", FILE_APPEND | LOCK_EX);

        // Actionable alert dispatch for high-severity levels
        if (in_array(strtoupper($level), [self::EMERGENCY, self::ALERT, self::CRITICAL], true)) {
            self::dispatchActionableAlert(strtoupper($level), $cleanMessage, $cleanContext);
        }
    }

    /**
     * Dispatch actionable alert to system_alerts table.
     */
    public static function dispatchActionableAlert(string $severity, string $title, array $metadata = []): void
    {
        try {
            self::ensureAlertSchema();

            $schoolId = (class_exists(Auth::class) && method_exists(Auth::class, 'schoolId')) ? (Auth::schoolId() ?? 0) : 0;
            $alertType = substr(preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower($title)), 0, 60);

            // Check if existing open alert exists for this type within the past 1 hour
            $existing = Database::fetch("
                SELECT id, occurrences FROM system_alerts 
                WHERE alert_type = ? AND status = 'open' AND last_seen_at > (NOW() - INTERVAL 1 HOUR)
                LIMIT 1
            ", [$alertType]);

            if ($existing) {
                Database::execute("
                    UPDATE system_alerts 
                    SET occurrences = occurrences + 1, last_seen_at = NOW(), metadata = ?
                    WHERE id = ?
                ", [json_encode($metadata), $existing['id']]);
            } else {
                Database::execute("
                    INSERT INTO system_alerts 
                    (school_id, alert_type, severity, title, message, metadata, status, occurrences, last_seen_at, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'open', 1, NOW(), NOW())
                ", [
                    $schoolId,
                    $alertType,
                    strtolower($severity),
                    substr($title, 0, 190),
                    substr($title, 0, 500),
                    json_encode($metadata),
                ]);
            }
        } catch (Throwable $e) {
            // Failsafe: alert engine must never throw or disrupt execution
        }
    }

    /**
     * Ensure system_alerts schema exists in database.
     */
    public static function ensureAlertSchema(): void
    {
        if (self::$schemaChecked) {
            return;
        }

        try {
            Database::execute("
                CREATE TABLE IF NOT EXISTS system_alerts (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    alert_type VARCHAR(64) NOT NULL,
                    severity ENUM('info', 'warning', 'critical', 'emergency') NOT NULL DEFAULT 'warning',
                    title VARCHAR(191) NOT NULL,
                    message TEXT NULL,
                    metadata JSON NULL,
                    status ENUM('open', 'acknowledged', 'resolved') NOT NULL DEFAULT 'open',
                    occurrences INT UNSIGNED NOT NULL DEFAULT 1,
                    last_seen_at DATETIME NOT NULL,
                    created_at DATETIME NOT NULL,
                    INDEX idx_alert_status (status, severity),
                    INDEX idx_alert_tenant (school_id, status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");
            self::$schemaChecked = true;
        } catch (Throwable $e) {
            // Ignore if schema check fails during bootstrap
        }
    }

    /**
     * Sanitize nested array data scrubbing credentials, tokens, credit cards, and keys.
     */
    public static function sanitizeData(mixed $data): mixed
    {
        if (is_string($data)) {
            return self::sanitizeString($data);
        }

        if ($data instanceof Throwable) {
            return [
                'class'   => get_class($data),
                'message' => self::sanitizeString($data->getMessage()),
                'file'    => basename($data->getFile()),
                'line'    => $data->getLine(),
            ];
        }

        if (!is_array($data)) {
            return $data;
        }

        $sensitiveKeys = [
            'password', 'passwd', 'pwd', 'secret', 'token', 'api_key', 'apikey',
            'authorization', 'bearer', 'auth', 'card_number', 'credit_card', 'card_no',
            'cvv', 'cvc', 'ssn', 'encryption_key', 'national_id', 'nin', 'aadhaar', 'bvn'
        ];

        $clean = [];
        foreach ($data as $key => $value) {
            $keyStr = strtolower((string) $key);
            $isSensitive = false;
            foreach ($sensitiveKeys as $sk) {
                if (str_contains($keyStr, $sk)) {
                    $isSensitive = true;
                    break;
                }
            }

            if ($isSensitive) {
                $clean[$key] = '[REDACTED]';
            } elseif (is_array($value)) {
                $clean[$key] = self::sanitizeData($value);
            } elseif (is_string($value)) {
                $clean[$key] = self::sanitizeString($value);
            } else {
                $clean[$key] = $value;
            }
        }

        return $clean;
    }

    /**
     * Sanitize string content by removing passwords, tokens, PII, and connection strings.
     */
    public static function sanitizeString(string $input): string
    {
        $patterns = [
            '/(password|pwd|pass|secret|token|api_key|access_token|key|auth)\s*[:=]\s*["\']?[^"\'\s,;]+["\']?/i' => '$1: [REDACTED]',
            '/mysql:host=[^;]+;port=\d+;dbname=[^;]+;charset=[^;]+/i' => 'mysql:host=[HOST];port=[PORT];dbname=[DB]',
            '/bearer\s+[a-zA-Z0-9_\-\.]+/i' => 'Bearer [REDACTED_TOKEN]',
            '/sk-[a-zA-Z0-9]{20,}/' => 'sk-[REDACTED_API_KEY]',
            '/AIzaSy[a-zA-Z0-9_-]{33}/' => 'AIzaSy[REDACTED_API_KEY]',
            '/\b(?:\d{4}[-\s]\d{4}[-\s]\d{4}[-\s]\d{4}|4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b/' => '[REDACTED_CARD]',
            '/\b\d{3}-\d{2}-\d{4}\b/' => '[REDACTED_SSN]',
        ];

        return (string) preg_replace(array_keys($patterns), array_values($patterns), $input);
    }

    private static function isDebugEnabled(): bool
    {
        if (function_exists('app_config')) {
            return (bool) app_config('debug', false);
        }
        return true;
    }
}
