<?php

declare(strict_types=1);

namespace Core;

use App\Helpers\Audit;

final class Auth
{
    private static ?array $user = null;
    private static ?array $permissions = null;

    public static function clearCache(): void
    {
        self::$user = null;
        self::$permissions = null;
    }

    public static function attempt(string $email, string $password, bool $remember = false, ?string $schoolCode = null): bool
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $email = strtolower(trim($email));

        $sql = 'SELECT u.*, r.slug AS role_slug, r.name AS role_name, s.name AS school_name,
                       s.status AS school_status, s.code AS school_code, s.subscription_status,
                       s.school_uuid, s.plan_id
                FROM users u
                INNER JOIN roles r ON r.id = u.role_id
                INNER JOIN schools s ON s.id = u.school_id
                WHERE u.email = ? AND s.deleted_at IS NULL';
        $params = [$email];
        if (!empty($schoolCode)) {
            $sql .= ' AND s.code = ?';
            $params[] = strtoupper(trim($schoolCode));
        }
        
        $users = Database::fetchAll($sql, $params);

        if (empty($users)) {
            self::recordFailedLogin($email);
            try {
                (new \App\Services\SecurityService())->recordLoginAttempt(0, $email, 'user_not_found', null, 'Account does not exist');
            } catch (\Throwable $e) {}
            $_SESSION['login_error'] = 'User not found.';
            $_SESSION['login_error_field'] = 'email';
            return false;
        }

        $matchedUser = null;
        $matchCount = 0;
        $lockedOutFound = false;
        $inactiveFound = false;

        foreach ($users as $u) {
            if ((int) $u['status'] !== 1 || (int) ($u['school_status'] ?? 1) !== 1) {
                $inactiveFound = true;
                continue;
            }
            if (self::isLockedOut((int) $u['id'])) {
                $lockedOutFound = true;
                continue;
            }
            if (password_verify($password, $u['password'])) {
                $matchedUser = $u;
                $matchCount++;
                // Modernize password hash if cost or algorithm needs updating
                if (password_needs_rehash($u['password'], PASSWORD_DEFAULT)) {
                    $newHash = password_hash($password, PASSWORD_DEFAULT);
                    Database::execute(
                        'UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?',
                        [$newHash, (int)$u['id']]
                    );
                }
            }
        }

        if ($lockedOutFound && $matchCount === 0) {
            try {
                (new \App\Services\SecurityService())->recordLoginAttempt(
                    (int)($users[0]['school_id'] ?? 0),
                    $email,
                    'locked_out',
                    isset($users[0]['id']) ? (int)$users[0]['id'] : null,
                    'Account locked due to excessive failed attempts'
                );
            } catch (\Throwable $e) {}
            $_SESSION['login_error'] = 'Too many failed login attempts. Your account is temporarily locked for security. Please try again later.';
            return false;
        }

        if ($inactiveFound && $matchCount === 0) {
            $_SESSION['login_error'] = 'Your account or school has been suspended or is inactive. Please contact support.';
            return false;
        }

        if ($matchCount === 0) {
            // Password didn't match any active account
            self::recordFailedLogin($email, isset($users[0]['id']) ? (int) $users[0]['id'] : null);
            try {
                (new \App\Services\SecurityService())->recordLoginAttempt(
                    (int)($users[0]['school_id'] ?? 0),
                    $email,
                    'failed_password',
                    isset($users[0]['id']) ? (int)$users[0]['id'] : null,
                    'Incorrect password attempt'
                );
            } catch (\Throwable $e) {}
            $_SESSION['login_error'] = 'Incorrect password.';
            $_SESSION['login_error_field'] = 'password';
            return false;
        }

        if ($matchCount > 1) {
            $_SESSION['login_error'] = 'Multiple accounts share these credentials. Please contact support.';
            return false;
        }

        $user = $matchedUser;

        $subStatus = $user['subscription_status'] ?? 'active';
        if (in_array($subStatus, ['suspended', 'expired', 'cancelled', 'archived', 'pending'], true)) {
            $_SESSION['blocked_school'] = [
                'code' => $user['school_code'],
                'name' => $user['school_name'],
                'status' => $subStatus,
            ];
            return false;
        }

        self::clearFailedLogins((int) $user['id']);
        // Ensure platform session cleared
        unset($_SESSION['platform_user_id'], $_SESSION['platform_role_id'], $_SESSION['platform_role_slug'], $_SESSION['auth_context']);
        $_SESSION['auth_context'] = 'school';
        self::loginUser($user, $remember);

        Database::execute(
            'UPDATE users SET last_login_at = NOW(), last_login_ip = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
            [self::clientIp(), (int) $user['id'], (int) $user['school_id']]
        );

        Audit::log('login', 'auth', 'user', (int) $user['id'], null, [
            'email' => $email,
            'ip' => self::clientIp(),
            'school_code' => $user['school_code'] ?? null,
        ], (int) $user['school_id'], (int) $user['id']);

        try {
            (new \App\Services\SecurityService())->recordLoginAttempt(
                (int)$user['school_id'],
                $email,
                'success',
                (int)$user['id'],
                null
            );
        } catch (\Throwable $e) {}

        return true;
    }

    public static function loginUser(array $user, bool $remember = false): void
    {
        if (!headers_sent() && session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        unset($user['password']);
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['school_id'] = (int) $user['school_id'];
        $_SESSION['role_id'] = (int) $user['role_id'];
        $_SESSION['role_slug'] = $user['role_slug'] ?? '';
        $_SESSION['auth_time'] = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['_last_session_regenerate'] = time();

        self::$user = $user;
        self::$permissions = null;

        $config = require dirname(__DIR__) . '/config/app.php';
        if ($remember && ($config['remember_me']['enabled'] ?? false)) {
            self::setRememberToken((int) $user['id'], (int) $user['school_id']);
        }
    }

    public static function logout(): void
    {
        $userId = self::id();
        $schoolId = self::schoolId();

        if ($userId && $schoolId) {
            Database::execute(
                'DELETE FROM remember_tokens WHERE user_id = ? AND school_id = ?',
                [$userId, $schoolId]
            );
            Audit::log('logout', 'auth', 'user', $userId);
        }

        if (!headers_sent()) {
            $config = require dirname(__DIR__) . '/config/app.php';
            $cookie = $config['remember_me']['cookie'] ?? 'sp_remember';
            setcookie($cookie, '', [
                'expires' => time() - 3600,
                'path' => '/',
                'secure' => (bool) ($config['session']['secure'] ?? false),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);

            if (ini_get('session.use_cookies') && session_id() !== '') {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
            }
        }
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
            if (!headers_sent()) {
                session_start();
                session_regenerate_id(true);
            }
        }
        self::$user = null;
        self::$permissions = null;
    }

    public static function check(): bool
    {
        if (isset($_SESSION['user_id'])) {
            // Check idle session timeout
            if (!empty($_SESSION['last_activity']) && !empty($_SESSION['school_id'])) {
                $timeoutMinutes = 120; // Default safe timeout
                try {
                    $custom = Database::fetch(
                        'SELECT session_timeout_minutes FROM security_settings WHERE school_id = ? LIMIT 1',
                        [(int)$_SESSION['school_id']]
                    );
                    if ($custom && !empty($custom['session_timeout_minutes'])) {
                        $timeoutMinutes = (int)$custom['session_timeout_minutes'];
                    }
                } catch (\Throwable $e) {}

                if ((time() - (int)$_SESSION['last_activity']) > ($timeoutMinutes * 60)) {
                    // Session expired due to inactivity
                    self::logout();
                    $_SESSION['session_expired'] = true;
                    return false;
                }
            }

            // Periodic session ID regeneration (every 15 minutes) for active sessions
            if (!headers_sent() && session_status() === PHP_SESSION_ACTIVE) {
                if (empty($_SESSION['_last_session_regenerate']) || (time() - (int)$_SESSION['_last_session_regenerate']) > 900) {
                    session_regenerate_id(true);
                    $_SESSION['_last_session_regenerate'] = time();
                }
            }

            $_SESSION['last_activity'] = time();
            return self::user() !== null;
        }

        return self::attemptRememberMe();
    }

    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }

        if (empty($_SESSION['user_id']) || empty($_SESSION['school_id'])) {
            return null;
        }

        $user = Database::fetch(
            'SELECT u.*, r.slug AS role_slug, r.name AS role_name, s.name AS school_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             INNER JOIN schools s ON s.id = u.school_id
             WHERE u.id = ? AND u.school_id = ? AND u.status = 1 AND s.deleted_at IS NULL LIMIT 1',
            [(int) $_SESSION['user_id'], (int) $_SESSION['school_id']]
        );

        if (!$user) {
            unset($_SESSION['user_id'], $_SESSION['school_id'], $_SESSION['role_id'], $_SESSION['role_slug']);
            self::$user = null;
            return null;
        }

        unset($user['password']);
        self::$user = $user;
        return self::$user;
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user ? (int) $user['id'] : null;
    }

    public static function schoolId(): ?int
    {
        $user = self::user();
        return $user ? (int) $user['school_id'] : null;
    }

    public static function roleSlug(): ?string
    {
        $user = self::user();
        return $user['role_slug'] ?? null;
    }

    public static function roleName(): ?string
    {
        $user = self::user();
        return $user['role_name'] ?? ($user['role_slug'] ? ucwords(str_replace('_', ' ', $user['role_slug'])) : null);
    }

    public static function isRole(string|array $roles): bool
    {
        $slug = self::roleSlug();
        if ($slug === null) {
            return false;
        }
        $roles = (array) $roles;
        return in_array($slug, $roles, true);
    }

    public static function permissions(): array
    {
        if (self::$permissions !== null) {
            return self::$permissions;
        }

        $user = self::user();
        if (!$user) {
            return [];
        }

        $rows = Database::fetchAll(
            'SELECT p.slug
             FROM permissions p
             INNER JOIN role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ?',
            [(int) $user['role_id']]
        );

        self::$permissions = array_column($rows, 'slug');
        return self::$permissions;
    }

    public static function hasPermission(string $permission): bool
    {
        if (self::isRole('school_admin') || self::isRole('principal')) {
            return true; // Principal and Owner (school_admin) have absolute full access
        }

        return in_array($permission, self::permissions(), true);
    }

    public static function requirePermission(string $permission): void
    {
        if (!self::check()) {
            if (function_exists('is_json_request') && is_json_request()) {
                http_response_code(401);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'success' => false,
                    'status' => 401,
                    'error' => [
                        'code' => 'UNAUTHENTICATED',
                        'message' => 'Your session has expired. Please log in again.'
                    ]
                ], JSON_UNESCAPED_SLASHES);
                exit;
            }
            flash('error', 'Your session has expired. Please log in to continue.');
            redirect(url('login'));
        }

        if (!self::hasPermission($permission)) {
            if (function_exists('is_json_request') && is_json_request()) {
                http_response_code(403);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'success' => false,
                    'status' => 403,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'You do not have permission to perform this action.'
                    ]
                ], JSON_UNESCAPED_SLASHES);
                exit;
            }
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            exit;
        }
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            if (function_exists('is_json_request') && is_json_request()) {
                http_response_code(401);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'success' => false,
                    'status' => 401,
                    'error' => [
                        'code' => 'UNAUTHENTICATED',
                        'message' => 'Your session has expired. Please log in again.'
                    ]
                ], JSON_UNESCAPED_SLASHES);
                exit;
            }
            flash('error', 'Your session has expired. Please log in to continue.');
            redirect(url('login'));
        }
    }

    public static function clientIp(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    private static function isLockedOut(int $userId): bool
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $max = (int) $config['login']['max_attempts'];
        $minutes = (int) $config['login']['lockout_minutes'];

        try {
            $userRow = Database::fetch("SELECT school_id FROM users WHERE id = ? LIMIT 1", [$userId]);
            if ($userRow && !empty($userRow['school_id'])) {
                $custom = Database::fetch("SELECT max_failed_logins, lockout_duration_minutes FROM security_settings WHERE school_id = ? LIMIT 1", [(int)$userRow['school_id']]);
                if ($custom) {
                    $max = (int)$custom['max_failed_logins'];
                    $minutes = (int)$custom['lockout_duration_minutes'];
                }
            }
        } catch (\Throwable $e) {}

        $row = Database::fetch(
            'SELECT COUNT(*) AS cnt FROM login_attempts
             WHERE user_id = ? AND success = 0 AND attempted_at > (NOW() - INTERVAL ? MINUTE)',
            [$userId, $minutes]
        );

        return ((int) ($row['cnt'] ?? 0)) >= $max;
    }

    private static function recordFailedLogin(string $email, ?int $userId = null): void
    {
        Database::insert(
            'INSERT INTO login_attempts (user_id, email, ip_address, success, attempted_at)
             VALUES (?, ?, ?, 0, NOW())',
            [$userId, $email, self::clientIp()]
        );
    }

    private static function clearFailedLogins(int $userId): void
    {
        Database::execute('DELETE FROM login_attempts WHERE user_id = ? AND success = 0', [$userId]);
    }

    private static function setRememberToken(int $userId, int $schoolId): void
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $selector = bin2hex(random_bytes(16));
        $validator = bin2hex(random_bytes(32));
        $hash = hash('sha256', $validator);
        $days = (int) ($config['remember_me']['days'] ?? 30);
        $expires = (new \DateTimeImmutable("+{$days} days"))->format('Y-m-d H:i:s');

        Database::execute('DELETE FROM remember_tokens WHERE user_id = ? AND school_id = ?', [$userId, $schoolId]);
        Database::insert(
            'INSERT INTO remember_tokens (school_id, user_id, selector, token_hash, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())',
            [$schoolId, $userId, $selector, $hash, $expires]
        );

        $cookie = $config['remember_me']['cookie'] ?? 'sp_remember';
        setcookie($cookie, $selector . ':' . $validator, [
            'expires' => time() + ($days * 86400),
            'path' => '/',
            'secure' => (bool) ($config['session']['secure'] ?? false),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    private static function attemptRememberMe(): bool
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        if (!($config['remember_me']['enabled'] ?? false)) {
            return false;
        }

        $cookieName = $config['remember_me']['cookie'] ?? 'sp_remember';
        $raw = $_COOKIE[$cookieName] ?? '';
        if (!str_contains($raw, ':')) {
            return false;
        }

        [$selector, $validator] = explode(':', $raw, 2);
        $row = Database::fetch(
            'SELECT * FROM remember_tokens WHERE selector = ? AND expires_at > NOW() LIMIT 1',
            [$selector]
        );

        if (!$row || !hash_equals($row['token_hash'], hash('sha256', $validator))) {
            return false;
        }

        $user = Database::fetch(
            'SELECT u.*, r.slug AS role_slug, r.name AS role_name, s.name AS school_name, s.status AS school_status
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             INNER JOIN schools s ON s.id = u.school_id
             WHERE u.id = ? AND u.school_id = ? AND u.status = 1 AND s.deleted_at IS NULL LIMIT 1',
            [(int) $row['user_id'], (int) $row['school_id']]
        );

        if (!$user || (int) $user['school_status'] !== 1) {
            return false;
        }

        self::loginUser($user, true);
        return true;
    }
}
