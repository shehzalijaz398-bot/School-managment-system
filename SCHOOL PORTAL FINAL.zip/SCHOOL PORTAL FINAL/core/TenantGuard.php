<?php

declare(strict_types=1);

namespace Core;

use Core\Database;
use Core\Exceptions\TenantSecurityException;

/**
 * Enterprise Multi-Tenant Boundary Guard & IDOR Defense Engine.
 * Enforces strict tenant separation on all dynamic parameters and prevents cross-tenant access.
 */
final class TenantGuard
{
    /**
     * Resolves the current tenant context.
     *
     * @throws TenantSecurityException If no valid tenant context is resolved.
     */
    public static function resolveSchoolId(?int $explicitSchoolId = null): int
    {
        $tenantId = $explicitSchoolId ?? TenantContext::schoolId() ?? Auth::schoolId();
        if (!$tenantId || $tenantId <= 0) {
            throw new TenantSecurityException(
                message: 'Access Denied: Unauthenticated or missing tenant isolation context.',
                resource: 'tenant_context',
                resourceId: 0,
                tenantId: 0,
                code: 403
            );
        }
        return (int) $tenantId;
    }

    /**
     * Enforce strict tenant ownership on an arbitrary database table row.
     * Protects against Insecure Direct Object References (IDOR).
     *
     * @param string $table The table name to check.
     * @param int $id The primary key ID of the target resource.
     * @param int|null $explicitSchoolId Optional override for tenant context (default null = active tenant).
     * @param string $tenantColumn The column representing the tenant boundary (default 'school_id').
     * @return array The authenticated database row.
     * 
     * @throws TenantSecurityException When the record exists but belongs to another tenant.
     * @throws \RuntimeException When the record does not exist at all.
     */
    public static function enforce(
        string $table,
        int $id,
        ?int $explicitSchoolId = null,
        string $tenantColumn = 'school_id'
    ): array {
        $tenantId = self::resolveSchoolId($explicitSchoolId);

        // Sanitize table and column names against SQL injection
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
            throw new \InvalidArgumentException("Invalid table identifier: {$table}");
        }
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $tenantColumn)) {
            throw new \InvalidArgumentException("Invalid tenant column: {$tenantColumn}");
        }

        // Query the raw resource to inspect its tenant boundary
        $row = Database::fetch(
            "SELECT * FROM `{$table}` WHERE `id` = ? LIMIT 1",
            [$id]
        );

        if (!$row) {
            http_response_code(404);
            throw new \RuntimeException("Resource #{$id} in '{$table}' was not found.");
        }

        // Check if the record has the tenant column
        if (array_key_exists($tenantColumn, $row)) {
            $recordTenantId = (int) $row[$tenantColumn];
            if ($recordTenantId !== $tenantId) {
                // Log security incident with actor details
                $actorId = Auth::id() ?? 0;
                $actorEmail = Auth::user()['email'] ?? 'unauthenticated';
                $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

                error_log(sprintf(
                    "[SECURITY ALERT] IDOR Attempt Detected! User ID: %d (%s) from IP: %s attempted to access %s #%d belonging to School #%d while authenticated in School #%d",
                    $actorId,
                    $actorEmail,
                    $ip,
                    $table,
                    $id,
                    $recordTenantId,
                    $tenantId
                ));

                if (function_exists('auditLog')) {
                    auditLog(
                        'security.idor_blocked',
                        $table,
                        $table,
                        $id,
                        null,
                        [
                            'attempted_id' => $id,
                            'target_school_id' => $recordTenantId,
                            'actor_school_id' => $tenantId,
                            'ip' => $ip,
                        ]
                    );
                }

                try {
                    $validActorId = null;
                    if ($actorId) {
                        $userExists = Database::fetch('SELECT id FROM users WHERE id = ? LIMIT 1', [$actorId]);
                        if ($userExists) {
                            $validActorId = (int)$actorId;
                        }
                    }

                    Database::insert("
                        INSERT INTO security_incidents (school_id, user_id, event_type, severity, ip_address, details, status, created_at)
                        VALUES (?, ?, 'idor_attempt', 'high', ?, ?, 'open', NOW())
                    ", [
                        $tenantId,
                        $validActorId,
                        $ip,
                        json_encode([
                            'table' => $table,
                            'attempted_id' => $id,
                            'target_school_id' => $recordTenantId,
                            'actor_school_id' => $tenantId,
                            'actor_email' => $actorEmail,
                            'time' => date('Y-m-d H:i:s'),
                        ], JSON_UNESCAPED_SLASHES)
                    ]);
                } catch (\Throwable $e) {}

                http_response_code(403);
                throw new TenantSecurityException(
                    message: "Forbidden: You do not have permission to access resource #{$id}.",
                    resource: $table,
                    resourceId: $id,
                    tenantId: $recordTenantId,
                    code: 403
                );
            }
        }

        return $row;
    }

    /**
     * Asserts that a given resource's tenant ID matches the active tenant session.
     *
     * @throws TenantSecurityException
     */
    public static function assertTenant(
        int $resourceSchoolId,
        ?int $explicitSchoolId = null,
        string $resourceName = 'Resource'
    ): void {
        $tenantId = self::resolveSchoolId($explicitSchoolId);
        if ($resourceSchoolId !== $tenantId) {
            $actorId = Auth::id() ?? 0;
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

            try {
                $validActorId = null;
                if ($actorId) {
                    $userExists = Database::fetch('SELECT id FROM users WHERE id = ? LIMIT 1', [$actorId]);
                    if ($userExists) {
                        $validActorId = (int)$actorId;
                    }
                }

                Database::insert("
                    INSERT INTO security_incidents (school_id, user_id, event_type, severity, ip_address, details, status, created_at)
                    VALUES (?, ?, 'idor_attempt', 'high', ?, ?, 'open', NOW())
                ", [
                    $tenantId,
                    $validActorId,
                    $ip,
                    json_encode([
                        'resource' => $resourceName,
                        'target_school_id' => $resourceSchoolId,
                        'actor_school_id' => $tenantId,
                        'time' => date('Y-m-d H:i:s'),
                    ], JSON_UNESCAPED_SLASHES)
                ]);
            } catch (\Throwable $e) {}

            http_response_code(403);
            throw new TenantSecurityException(
                message: "Forbidden: Cross-tenant access violation on {$resourceName}.",
                resource: $resourceName,
                resourceId: 0,
                tenantId: $resourceSchoolId,
                code: 403
            );
        }
    }
}
