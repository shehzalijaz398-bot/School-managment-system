<?php

declare(strict_types=1);

namespace Core;

use Core\Database;

/**
 * Resolves tenant exclusively from authenticated session / impersonation — never from request input.
 */
final class TenantContext
{
    private static ?array $school = null;
    private static ?int $explicitSchoolId = null;

    public static function clear(): void
    {
        self::$school = null;
        self::$explicitSchoolId = null;
    }

    public static function setExplicitSchoolId(?int $schoolId): void
    {
        self::$explicitSchoolId = $schoolId;
        self::$school = null; // Clear cached school row on change
    }

    public static function schoolId(): ?int
    {
        if (self::$explicitSchoolId !== null) {
            return self::$explicitSchoolId;
        }
        if (!empty($_SESSION['impersonation']['school_id'])) {
            return (int) $_SESSION['impersonation']['school_id'];
        }
        if (!empty($_SESSION['school_id'])) {
            return (int) $_SESSION['school_id'];
        }
        return Auth::schoolId();
    }

    public static function currentSchool(): ?array
    {
        $id = self::schoolId();
        if (!$id) {
            return null;
        }
        if (self::$school && (int) self::$school['id'] === $id) {
            return self::$school;
        }
        self::$school = Database::fetch('SELECT * FROM schools WHERE id = ? AND deleted_at IS NULL LIMIT 1', [$id]);
        return self::$school;
    }

    public static function currentSchoolId(): int
    {
        $id = self::schoolId();
        if (!$id) {
            throw new \RuntimeException('No tenant context.');
        }
        return $id;
    }

    public static function requireActiveTenant(): void
    {
        $school = self::currentSchool();
        if (!$school) {
            http_response_code(403);
            view('tenant/inactive', ['title' => 'School Not Found', 'message' => 'School context missing.'], 'layouts/guest');
            exit;
        }

        $status = $school['subscription_status'] ?? 'active';
        $isTrialExpired = ($status === 'trial' && !empty($school['trial_ends_at']) && strtotime($school['trial_ends_at']) < time()) || $status === 'expired';
        $blocked = ['suspended', 'expired', 'cancelled', 'archived', 'pending'];

        if ($isTrialExpired || in_array($status, $blocked, true) || (int) ($school['status'] ?? 0) !== 1) {
            http_response_code(403);
            view('tenant/inactive', [
                'title' => $isTrialExpired ? 'Trial Period Expired' : 'Subscription Inactive',
                'isTrialExpired' => $isTrialExpired,
                'status' => $status,
                'message' => $isTrialExpired 
                    ? 'Your 30-day free trial has concluded. Subscribe to a paid plan to continue managing your institution.' 
                    : ($status === 'suspended' ? 'Your school account has been suspended by the platform administrator.' : 'Your school\'s subscription is currently inactive.'),
                'school' => $school,
            ], 'layouts/guest');
            exit;
        }
    }

    public static function isOperational(): bool
    {
        $school = self::currentSchool();
        if (!$school || (int) ($school['status'] ?? 0) !== 1) {
            return false;
        }
        $status = $school['subscription_status'] ?? 'active';

        // Server-side timestamp check: trial expiry
        if ($status === 'trial' && !empty($school['trial_ends_at']) && strtotime($school['trial_ends_at']) < time()) {
            Database::execute('UPDATE schools SET subscription_status = "expired", status = 0, updated_at = NOW() WHERE id = ?', [(int) $school['id']]);
            Database::execute('UPDATE subscriptions SET status = "expired", updated_at = NOW() WHERE school_id = ? AND status = "trial"', [(int) $school['id']]);
            self::$school['subscription_status'] = 'expired';
            self::$school['status'] = 0;
            return false;
        }

        // Server-side timestamp check: paid subscription expiry
        if ($status === 'active' && !empty($school['subscription_ends_at']) && strtotime($school['subscription_ends_at']) < time()) {
            Database::execute('UPDATE schools SET subscription_status = "expired", status = 0, updated_at = NOW() WHERE id = ?', [(int) $school['id']]);
            Database::execute('UPDATE subscriptions SET status = "expired", updated_at = NOW() WHERE school_id = ? AND status = "active"', [(int) $school['id']]);
            self::$school['subscription_status'] = 'expired';
            self::$school['status'] = 0;
            return false;
        }

        return in_array($status, ['trial', 'active', 'past_due'], true);
    }

    public static function findByCode(string $code): ?array
    {
        $code = strtoupper(trim($code));
        return Database::fetch(
            'SELECT * FROM schools WHERE UPPER(code) = ? AND deleted_at IS NULL LIMIT 1',
            [$code]
        );
    }
}
