<?php

declare(strict_types=1);

namespace Core;

use Core\Cache\CacheManager;

/**
 * Cache Facade for Core Framework.
 */
final class Cache
{
    public static function get(string $key, mixed $default = null, ?int $schoolId = null): mixed
    {
        return CacheManager::get($key, $default, $schoolId);
    }

    public static function set(string $key, mixed $value, int $ttlSeconds = 300, ?int $schoolId = null): bool
    {
        return CacheManager::set($key, $value, $ttlSeconds, $schoolId);
    }

    public static function has(string $key, ?int $schoolId = null): bool
    {
        return CacheManager::has($key, $schoolId);
    }

    public static function remember(string $key, int $ttlSeconds, callable $callback, ?int $schoolId = null): mixed
    {
        return CacheManager::remember($key, $ttlSeconds, $callback, $schoolId);
    }

    public static function forget(string $key, ?int $schoolId = null): bool
    {
        return CacheManager::forget($key, $schoolId);
    }

    public static function flushTenant(?int $schoolId = null): int
    {
        return CacheManager::flushTenant($schoolId);
    }

    public static function flushAll(): int
    {
        return CacheManager::flushAll();
    }

    public static function stats(): array
    {
        return CacheManager::stats();
    }
}
