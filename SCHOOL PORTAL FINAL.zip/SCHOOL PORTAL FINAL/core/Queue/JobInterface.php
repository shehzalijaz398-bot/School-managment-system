<?php

declare(strict_types=1);

namespace Core\Queue;

/**
 * Interface JobInterface
 * Defines the contract for all asynchronous jobs processed by the Antigravity Queue Engine.
 */
interface JobInterface
{
    /**
     * Execute the job logic.
     *
     * @return void
     * @throws \Throwable If job execution fails.
     */
    public function handle(): void;
}
