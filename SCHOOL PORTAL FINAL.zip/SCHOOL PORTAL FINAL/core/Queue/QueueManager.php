<?php

declare(strict_types=1);

namespace Core\Queue;

/**
 * Enterprise Queue Facade & Dispatcher.
 */
final class QueueManager
{
    private static ?DatabaseQueue $queue = null;

    public static function queue(): DatabaseQueue
    {
        if (self::$queue === null) {
            self::$queue = new DatabaseQueue();
        }
        return self::$queue;
    }

    /**
     * Dispatch an asynchronous job to the background queue.
     *
     * @param JobInterface $job
     * @param string $queue
     * @param int $delaySeconds
     * @return int The ID of the queued job.
     */
    public static function dispatch(JobInterface $job, string $queue = 'default', int $delaySeconds = 0): int
    {
        return self::queue()->push($job, $queue, $delaySeconds);
    }

    /**
     * Helper to get total pending jobs in a queue.
     */
    public static function count(string $queue = 'default'): int
    {
        return self::queue()->count($queue);
    }
}
