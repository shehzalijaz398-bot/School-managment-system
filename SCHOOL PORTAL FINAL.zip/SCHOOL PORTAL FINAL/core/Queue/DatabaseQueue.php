<?php

declare(strict_types=1);

namespace Core\Queue;

use Core\Database;
use Throwable;

/**
 * Enterprise Database Queue Engine for Pure PHP 8.2+ Architecture.
 * Implements high-concurrency atomic reservation using MySQL Row-Level Locking (FOR UPDATE).
 */
final class DatabaseQueue
{
    private static bool $schemaChecked = false;

    public function __construct()
    {
        self::ensureSchema();
    }

    /**
     * Ensure database schema tables exist for background jobs, execution runs, and bulk tasks.
     */
    public static function ensureSchema(): void
    {
        if (self::$schemaChecked) {
            return;
        }

        try {
            Database::execute("
                CREATE TABLE IF NOT EXISTS platform_jobs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    queue VARCHAR(64) NOT NULL DEFAULT 'default',
                    payload LONGTEXT NOT NULL,
                    attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
                    reserved_at DATETIME NULL,
                    available_at DATETIME NOT NULL,
                    created_at DATETIME NOT NULL,
                    INDEX idx_queue_available (queue, available_at),
                    INDEX idx_reserved (reserved_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            Database::execute("
                CREATE TABLE IF NOT EXISTS platform_failed_jobs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    queue VARCHAR(64) NOT NULL DEFAULT 'default',
                    payload LONGTEXT NOT NULL,
                    exception LONGTEXT NOT NULL,
                    failed_at DATETIME NOT NULL,
                    INDEX idx_queue (queue)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            Database::execute("
                CREATE TABLE IF NOT EXISTS platform_job_runs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NULL,
                    job_id BIGINT UNSIGNED NULL,
                    job_name VARCHAR(191) NOT NULL,
                    queue VARCHAR(64) NOT NULL DEFAULT 'default',
                    status ENUM('queued', 'running', 'completed', 'failed', 'retrying') NOT NULL DEFAULT 'queued',
                    attempts TINYINT UNSIGNED NOT NULL DEFAULT 1,
                    execution_time_ms DECIMAL(10, 2) NULL,
                    memory_peak_mb DECIMAL(8, 2) NULL,
                    error_message TEXT NULL,
                    created_at DATETIME NOT NULL,
                    started_at DATETIME NULL,
                    completed_at DATETIME NULL,
                    INDEX idx_pjr_school (school_id),
                    INDEX idx_pjr_status (status),
                    INDEX idx_pjr_created (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            Database::execute("
                CREATE TABLE IF NOT EXISTS bulk_import_jobs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NOT NULL,
                    user_id BIGINT UNSIGNED NULL,
                    entity VARCHAR(50) NOT NULL,
                    file_name VARCHAR(255) NULL,
                    total_rows INT UNSIGNED NOT NULL DEFAULT 0,
                    processed_rows INT UNSIGNED NOT NULL DEFAULT 0,
                    success_count INT UNSIGNED NOT NULL DEFAULT 0,
                    error_count INT UNSIGNED NOT NULL DEFAULT 0,
                    status ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
                    error_summary TEXT NULL,
                    created_at DATETIME NOT NULL,
                    completed_at DATETIME NULL,
                    INDEX idx_bij_school_status (school_id, status),
                    INDEX idx_bij_created (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            Database::execute("
                CREATE TABLE IF NOT EXISTS report_export_jobs (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NOT NULL,
                    user_id BIGINT UNSIGNED NULL,
                    report_type VARCHAR(64) NOT NULL,
                    format VARCHAR(10) NOT NULL DEFAULT 'csv',
                    parameters TEXT NULL,
                    file_path VARCHAR(255) NULL,
                    status ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
                    created_at DATETIME NOT NULL,
                    completed_at DATETIME NULL,
                    INDEX idx_rej_school_status (school_id, status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            self::$schemaChecked = true;
        } catch (\Throwable $e) {
            error_log('DatabaseQueue::ensureSchema warning: ' . $e->getMessage());
        }
    }

    /**
     * Push a new job onto the queue.
     *
     * @param JobInterface $job The executable job instance.
     * @param string $queue The queue channel name (default 'default').
     * @param int $delaySeconds Delay in seconds before the job becomes available.
     * @return int The ID of the queued job.
     */
    public function push(JobInterface $job, string $queue = 'default', int $delaySeconds = 0): int
    {
        $payload = json_encode([
            'displayName' => get_class($job),
            'command' => serialize($job),
            'timestamp' => time(),
        ], JSON_THROW_ON_ERROR);

        $availableAt = date('Y-m-d H:i:s', time() + $delaySeconds);
        $createdAt = date('Y-m-d H:i:s');

        return Database::insert(
            'INSERT INTO platform_jobs (queue, payload, attempts, reserved_at, available_at, created_at)
             VALUES (?, ?, 0, NULL, ?, ?)',
            [$queue, $payload, $availableAt, $createdAt]
        );
    }

    /**
     * Atomically pop the next available job from the queue with lock contention prevention.
     *
     * @param string $queue
     * @param int $retryAfterSeconds Time in seconds before an uncompleted reserved job is recycled.
     * @return array|null An array containing job record details or null if queue is empty.
     */
    public function pop(string $queue = 'default', int $retryAfterSeconds = 90): ?array
    {
        Database::beginTransaction();
        try {
            $staleReservationCutoff = date('Y-m-d H:i:s', time() - $retryAfterSeconds);
            $now = date('Y-m-d H:i:s');

            // Find next eligible job using row lock FOR UPDATE
            $job = Database::fetch(
                'SELECT id, queue, payload, attempts 
                 FROM platform_jobs 
                 WHERE queue = ? 
                   AND (reserved_at IS NULL OR reserved_at <= ?)
                   AND available_at <= ?
                 ORDER BY id ASC 
                 LIMIT 1 
                 FOR UPDATE',
                [$queue, $staleReservationCutoff, $now]
            );

            if (!$job) {
                Database::commit();
                return null;
            }

            $jobId = (int) $job['id'];
            $attempts = (int) $job['attempts'] + 1;

            // Reserve job
            Database::execute(
                'UPDATE platform_jobs 
                 SET reserved_at = ?, attempts = ? 
                 WHERE id = ?',
                [$now, $attempts, $jobId]
            );

            Database::commit();
            $job['attempts'] = $attempts;
            return $job;
        } catch (Throwable $e) {
            Database::rollBack();
            error_log('DatabaseQueue::pop failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Delete a successfully executed job from the queue.
     */
    public function delete(int $jobId): void
    {
        Database::execute('DELETE FROM platform_jobs WHERE id = ?', [$jobId]);
    }

    /**
     * Release a reserved job back to the queue for retry.
     */
    public function release(int $jobId, int $delaySeconds = 0): void
    {
        $availableAt = date('Y-m-d H:i:s', time() + $delaySeconds);
        Database::execute(
            'UPDATE platform_jobs 
             SET reserved_at = NULL, available_at = ? 
             WHERE id = ?',
            [$availableAt, $jobId]
        );
    }

    /**
     * Mark a job as permanently failed and log its stack trace into platform_failed_jobs.
     */
    public function fail(int $jobId, string $queue, string $payload, Throwable $e): void
    {
        Database::beginTransaction();
        try {
            $exceptionTrace = $this->sanitizeExceptionTrace($e);

            Database::insert(
                'INSERT INTO platform_failed_jobs (queue, payload, exception, failed_at) 
                 VALUES (?, ?, ?, NOW())',
                [$queue, $payload, $exceptionTrace]
            );

            Database::execute('DELETE FROM platform_jobs WHERE id = ?', [$jobId]);
            Database::commit();
        } catch (Throwable $dbErr) {
            Database::rollBack();
            error_log('DatabaseQueue::fail logging error: ' . $dbErr->getMessage());
        }
    }

    /**
     * Recover interrupted or abandoned jobs (e.g. from server crashes or timeouts)
     * by resetting their reservation status after a defined timeout threshold.
     *
     * @param int $timeoutSeconds Threshold in seconds after which a reserved job is considered abandoned.
     * @return int Number of recovered jobs.
     */
    public function recoverInterruptedJobs(int $timeoutSeconds = 300): int
    {
        $cutoff = date('Y-m-d H:i:s', time() - $timeoutSeconds);
        return Database::execute(
            'UPDATE platform_jobs 
             SET reserved_at = NULL, available_at = NOW() 
             WHERE reserved_at IS NOT NULL AND reserved_at <= ?',
            [$cutoff]
        );
    }

    /**
     * Safely retry a previously failed job from platform_failed_jobs by re-inserting
     * it into the active queue and deleting the failed record.
     *
     * @param int $failedJobId ID in platform_failed_jobs table.
     * @return bool True if successfully requeued, false if not found.
     */
    public function retryFailedJob(int $failedJobId): bool
    {
        Database::beginTransaction();
        try {
            $failed = Database::fetch(
                'SELECT id, queue, payload FROM platform_failed_jobs WHERE id = ? FOR UPDATE',
                [$failedJobId]
            );
            if (!$failed) {
                Database::rollBack();
                return false;
            }

            Database::insert(
                'INSERT INTO platform_jobs (queue, payload, attempts, reserved_at, available_at, created_at)
                 VALUES (?, ?, 0, NULL, NOW(), NOW())',
                [$failed['queue'], $failed['payload']]
            );

            Database::execute('DELETE FROM platform_failed_jobs WHERE id = ?', [$failedJobId]);
            Database::commit();
            return true;
        } catch (Throwable $e) {
            Database::rollBack();
            error_log('DatabaseQueue::retryFailedJob error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Sanitize exception message and stack trace to scrub database credentials, API keys, and sensitive tokens.
     */
    public function sanitizeExceptionTrace(Throwable $e): string
    {
        $msg = $e->getMessage();
        $trace = $e->getTraceAsString();

        // Scrub database credentials and common secrets patterns
        $patterns = [
            '/(password|pwd|pass|secret|token|api_key|access_token|key)\s*[:=]\s*["\']?[^"\'\s,;]+["\']?/i' => '$1: [REDACTED]',
            '/mysql:host=[^;]+;port=\d+;dbname=[^;]+;charset=[^;]+/i' => 'mysql:host=[HOST];port=[PORT];dbname=[DB]',
            '/bearer\s+[a-zA-Z0-9_\-\.]+/i' => 'Bearer [REDACTED_TOKEN]',
            '/sk-[a-zA-Z0-9]{20,}/' => 'sk-[REDACTED_API_KEY]',
            '/AIzaSy[a-zA-Z0-9_-]{33}/' => 'AIzaSy[REDACTED_API_KEY]',
        ];

        foreach ($patterns as $pattern => $replacement) {
            $msg = preg_replace($pattern, $replacement, $msg);
            $trace = preg_replace($pattern, $replacement, $trace);
        }

        return sprintf(
            "Exception: %s\nMessage: %s\nFile: %s:%d\n\nSanitized Stack Trace:\n%s",
            get_class($e),
            $msg,
            $e->getFile(),
            $e->getLine(),
            $trace
        );
    }

    /**
     * Count pending jobs for a specific queue.
     */
    public function count(string $queue = 'default'): int
    {
        $res = Database::fetch(
            'SELECT COUNT(*) as total FROM platform_jobs WHERE queue = ?',
            [$queue]
        );
        return (int) ($res['total'] ?? 0);
    }

    /**
     * Clear all pending jobs in a queue.
     */
    public function purge(string $queue = 'default'): int
    {
        return Database::execute('DELETE FROM platform_jobs WHERE queue = ?', [$queue]);
    }

    /**
     * Record the beginning of a job execution run.
     */
    public function startJobRun(int $jobId, string $jobName, string $queue, int $attempts = 1, ?int $schoolId = null): int
    {
        try {
            return (int) Database::insert(
                'INSERT INTO platform_job_runs (school_id, job_id, job_name, queue, status, attempts, created_at, started_at)
                 VALUES (?, ?, ?, ?, "running", ?, NOW(), NOW())',
                [$schoolId, $jobId, $jobName, $queue, $attempts]
            );
        } catch (Throwable $e) {
            error_log('DatabaseQueue::startJobRun error: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Mark a job execution run as successfully completed.
     */
    public function completeJobRun(int $runId, float $executionTimeMs, float $memoryPeakMb): void
    {
        if ($runId <= 0) return;
        try {
            Database::execute(
                'UPDATE platform_job_runs 
                 SET status = "completed", execution_time_ms = ?, memory_peak_mb = ?, completed_at = NOW() 
                 WHERE id = ?',
                [$executionTimeMs, $memoryPeakMb, $runId]
            );
        } catch (Throwable $e) {
            error_log('DatabaseQueue::completeJobRun error: ' . $e->getMessage());
        }
    }

    /**
     * Mark a job execution run as failed or retrying.
     */
    public function failJobRun(int $runId, Throwable $e, float $executionTimeMs, float $memoryPeakMb, string $status = 'failed'): void
    {
        if ($runId <= 0) return;
        try {
            $msg = $this->sanitizeExceptionTrace($e);
            Database::execute(
                'UPDATE platform_job_runs 
                 SET status = ?, execution_time_ms = ?, memory_peak_mb = ?, error_message = ?, completed_at = NOW() 
                 WHERE id = ?',
                [$status, $executionTimeMs, $memoryPeakMb, mb_substr($msg, 0, 1000), $runId]
            );
        } catch (Throwable $dbErr) {
            error_log('DatabaseQueue::failJobRun error: ' . $dbErr->getMessage());
        }
    }

    /**
     * Retrieve recent job execution history with optional tenant filtering.
     */
    public function getJobRuns(?int $schoolId = null, int $limit = 20): array
    {
        $limit = max(1, min(100, $limit));
        if ($schoolId !== null && $schoolId > 0) {
            return Database::fetchAll(
                'SELECT * FROM platform_job_runs WHERE school_id = ? ORDER BY id DESC LIMIT ?',
                [$schoolId, $limit]
            );
        }
        return Database::fetchAll(
            'SELECT * FROM platform_job_runs ORDER BY id DESC LIMIT ?',
            [$limit]
        );
    }
}
