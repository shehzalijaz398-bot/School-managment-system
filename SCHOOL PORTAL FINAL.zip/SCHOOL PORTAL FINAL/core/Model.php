<?php

declare(strict_types=1);

namespace Core;

use App\Helpers\Audit;

abstract class Model
{
    protected string $table;
    protected string $primaryKey = 'id';
    protected bool $schoolScoped = true;
    protected bool $useCache = true;

    /**
     * Set to true to automatically record audit log transitions on create, update, and delete.
     */
    protected bool $enableAuditTrail = true;

    /**
     * Columns that should not trigger dirty state diffs in the audit log.
     *
     * @var array<int, string>
     */
    protected array $auditIgnoredColumns = [
        'updated_at',
        'created_at',
        'last_login_at',
        'last_login_ip',
    ];

    /**
     * Sensitive fields that must be masked before recording to audit logs.
     *
     * @var array<int, string>
     */
    protected array $auditHiddenColumns = [
        'password',
        'remember_token',
        'secret',
        'api_key',
    ];

    protected function db(): Database
    {
        return new Database();
    }

    protected function schoolId(): int
    {
        $id = \Core\TenantContext::schoolId() ?? Auth::schoolId();
        if (!$id) {
            throw new \RuntimeException('Missing school context.');
        }
        return $id;
    }

    // CACHE INTERCEPTOR LOGIC
    protected function getCachePath(): string
    {
        return dirname(__DIR__) . '/storage/cache/school_' . $this->schoolId();
    }

    protected function cacheRead(string $sql, array $params = []): ?array
    {
        if (!$this->useCache || !$this->schoolScoped) {
            return null;
        }
        $hash = md5($sql . serialize($params));
        $file = $this->getCachePath() . '/' . $this->table . '_' . $hash . '.php';

        if (file_exists($file)) {
            if (time() - filemtime($file) < 3600) {
                return unserialize(file_get_contents($file));
            }
            @unlink($file);
        }
        return null;
    }

    protected function cacheWrite(string $sql, array $params, array $data): void
    {
        if (!$this->useCache || !$this->schoolScoped) {
            return;
        }
        $hash = md5($sql . serialize($params));
        $dir = $this->getCachePath();
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $file = $dir . '/' . $this->table . '_' . $hash . '.php';
        file_put_contents($file, serialize($data));
    }

    public function invalidateCache(): void
    {
        if (!$this->schoolScoped) {
            return;
        }
        $dir = $this->getCachePath();
        if (is_dir($dir)) {
            $files = glob($dir . '/' . $this->table . '_*.php');
            if ($files) {
                foreach ($files as $file) {
                    @unlink($file);
                }
            }
        }
    }

    public function find(int $id): ?array
    {
        if ($this->schoolScoped) {
            $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? AND school_id = ? LIMIT 1";
            $params = [$id, $this->schoolId()];

            $cached = $this->cacheRead($sql, $params);
            if ($cached !== null) {
                return $cached ?: null;
            }

            $result = Database::fetch($sql, $params);
            $this->cacheWrite($sql, $params, $result ?: []);
            return $result;
        }

        return Database::fetch(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? LIMIT 1",
            [$id]
        );
    }

    public function findOrFail(int $id, ?int $schoolId = null): array
    {
        if ($this->schoolScoped) {
            return TenantGuard::enforce($this->table, $id, $schoolId ?? $this->schoolId());
        }

        $row = Database::fetch(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? LIMIT 1",
            [$id]
        );

        if (!$row) {
            http_response_code(404);
            throw new \RuntimeException("Record #{$id} not found in {$this->table}.");
        }

        return $row;
    }

    public function findForTenant(int $id, ?int $schoolId = null): ?array
    {
        $targetSchoolId = $schoolId ?? $this->schoolId();
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? AND school_id = ? LIMIT 1";
        return Database::fetch($sql, [$id, $targetSchoolId]);
    }

    public function all(string $orderBy = 'id DESC'): array
    {
        if ($this->schoolScoped) {
            $sql = "SELECT * FROM {$this->table} WHERE school_id = ? ORDER BY {$orderBy}";
            $params = [$this->schoolId()];

            $cached = $this->cacheRead($sql, $params);
            if ($cached !== null) {
                return $cached;
            }

            $result = Database::fetchAll($sql, $params);
            $this->cacheWrite($sql, $params, $result);
            return $result;
        }

        return Database::fetchAll("SELECT * FROM {$this->table} ORDER BY {$orderBy}");
    }

    /**
     * Insert a new record with automatic tenant scoping and audit logging.
     *
     * @param array<string, mixed> $data
     * @return int Inserted ID
     */
    public function create(array $data): int
    {
        if ($this->schoolScoped && !isset($data['school_id'])) {
            $data['school_id'] = $this->schoolId();
        }

        if (!isset($data['created_at'])) {
            $data['created_at'] = date('Y-m-d H:i:s');
        }
        if (!isset($data['updated_at'])) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }

        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');

        $id = Database::insert(
            sprintf(
                'INSERT INTO %s (%s) VALUES (%s)',
                $this->table,
                implode(', ', $columns),
                implode(', ', $placeholders)
            ),
            array_values($data)
        );

        $this->invalidateCache();

        // Automated Audit Trail Logging
        if ($this->enableAuditTrail && $this->table !== 'audit_logs') {
            try {
                $schoolId = isset($data['school_id']) ? (int) $data['school_id'] : (Auth::schoolId() ?: null);
                Audit::log(
                    'create',
                    $this->table,
                    $this->table,
                    $id,
                    null,
                    $this->sanitizeForAudit($data),
                    $schoolId
                );
            } catch (\Throwable $e) {
                error_log('Audit log failure on create: ' . $e->getMessage());
            }
        }

        return $id;
    }

    /**
     * Update a record with dirty diff detection and audit logging.
     *
     * @param int $id
     * @param array<string, mixed> $data
     * @return int Affected rows
     */
    public function update(int $id, array $data): int
    {
        $oldState = null;
        if ($this->enableAuditTrail && $this->table !== 'audit_logs') {
            $oldState = $this->find($id);
        }

        $data['updated_at'] = date('Y-m-d H:i:s');
        $sets = [];
        $params = [];
        foreach ($data as $col => $val) {
            $sets[] = "{$col} = ?";
            $params[] = $val;
        }
        $params[] = $id;

        if ($this->schoolScoped) {
            $params[] = $this->schoolId();
            $res = Database::execute(
                sprintf(
                    'UPDATE %s SET %s WHERE %s = ? AND school_id = ?',
                    $this->table,
                    implode(', ', $sets),
                    $this->primaryKey
                ),
                $params
            );
        } else {
            $res = Database::execute(
                sprintf(
                    'UPDATE %s SET %s WHERE %s = ?',
                    $this->table,
                    implode(', ', $sets),
                    $this->primaryKey
                ),
                $params
            );
        }

        $this->invalidateCache();

        // Automated State Diffing & Audit Trail
        if ($this->enableAuditTrail && $this->table !== 'audit_logs' && $oldState) {
            try {
                $diffOld = [];
                $diffNew = [];
                foreach ($data as $key => $newVal) {
                    if (in_array($key, $this->auditIgnoredColumns, true)) {
                        continue;
                    }
                    $oldVal = $oldState[$key] ?? null;
                    if ((string) $oldVal !== (string) $newVal) {
                        $diffOld[$key] = $oldVal;
                        $diffNew[$key] = $newVal;
                    }
                }

                if (!empty($diffNew)) {
                    $schoolId = isset($oldState['school_id']) ? (int) $oldState['school_id'] : (Auth::schoolId() ?: null);
                    Audit::log(
                        'update',
                        $this->table,
                        $this->table,
                        $id,
                        $this->sanitizeForAudit($diffOld),
                        $this->sanitizeForAudit($diffNew),
                        $schoolId
                    );
                }
            } catch (\Throwable $e) {
                error_log('Audit log failure on update: ' . $e->getMessage());
            }
        }

        return $res;
    }

    /**
     * Delete a record with audit logging.
     *
     * @param int $id
     * @return int Affected rows
     */
    public function delete(int $id): int
    {
        $oldState = null;
        if ($this->enableAuditTrail && $this->table !== 'audit_logs') {
            $oldState = $this->find($id);
        }

        if ($this->schoolScoped) {
            $res = Database::execute(
                "DELETE FROM {$this->table} WHERE {$this->primaryKey} = ? AND school_id = ?",
                [$id, $this->schoolId()]
            );
        } else {
            $res = Database::execute(
                "DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?",
                [$id]
            );
        }

        $this->invalidateCache();

        // Automated Audit Trail Logging
        if ($this->enableAuditTrail && $this->table !== 'audit_logs' && $oldState) {
            try {
                $schoolId = isset($oldState['school_id']) ? (int) $oldState['school_id'] : (Auth::schoolId() ?: null);
                Audit::log(
                    'delete',
                    $this->table,
                    $this->table,
                    $id,
                    $this->sanitizeForAudit($oldState),
                    null,
                    $schoolId
                );
            } catch (\Throwable $e) {
                error_log('Audit log failure on delete: ' . $e->getMessage());
            }
        }

        return $res;
    }

    public function paginate(string $sql, array $params, int $page = 1, int $perPage = 20): array
    {
        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;

        $countSql = 'SELECT COUNT(*) AS total FROM (' . $sql . ') AS counted';

        $cachedTotal = $this->cacheRead($countSql, $params);
        if ($cachedTotal !== null) {
            $total = (int) ($cachedTotal['total'] ?? 0);
        } else {
            $total = (int) (Database::fetch($countSql, $params)['total'] ?? 0);
            $this->cacheWrite($countSql, $params, ['total' => $total]);
        }

        $itemsSql = $sql . " LIMIT {$perPage} OFFSET {$offset}";
        $items = $this->cacheRead($itemsSql, $params);
        if ($items === null) {
            $items = Database::fetchAll($itemsSql, $params);
            $this->cacheWrite($itemsSql, $params, $items);
        }

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'pages' => (int) ceil(max(1, $total) / $perPage),
        ];
    }

    public function explainOptimizer(string $sql, array $params = []): array
    {
        return Database::fetchAll("EXPLAIN " . $sql, $params);
    }

    /**
     * Masks sensitive attributes before recording into the audit log.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function sanitizeForAudit(array $data): array
    {
        foreach ($this->auditHiddenColumns as $hidden) {
            if (array_key_exists($hidden, $data)) {
                $data[$hidden] = '[REDACTED]';
            }
        }
        return $data;
    }
}
