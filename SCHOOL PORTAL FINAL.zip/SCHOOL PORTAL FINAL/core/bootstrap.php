<?php

declare(strict_types=1);

/**
 * Application bootstrap
 */

define('BASE_PATH', dirname(__DIR__));

// Load environment variables from .env file if present
if (file_exists(BASE_PATH . '/.env')) {
    $lines = file(BASE_PATH . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (str_contains($line, '=')) {
            [$k, $v] = explode('=', $line, 2);
            $k = trim($k);
            $v = trim($v);
            if ((str_starts_with($v, '"') && str_ends_with($v, '"')) ||
                (str_starts_with($v, "'") && str_ends_with($v, "'"))) {
                $v = substr($v, 1, -1);
            }
            putenv("{$k}={$v}");
            $_ENV[$k] = $v;
            $_SERVER[$k] = $v;
        }
    }
}

require_once BASE_PATH . '/app/Helpers/functions.php';

$config = require BASE_PATH . '/config/app.php';

date_default_timezone_set($config['timezone'] ?? 'UTC');

if (($config['env'] ?? 'local') === 'production' || !($config['debug'] ?? false)) {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', $config['session']['samesite'] ?? 'Lax');

session_name($config['session']['name'] ?? 'SCHOOLPORTAL_SESSID');

session_set_cookie_params([
    'lifetime' => (int) ($config['session']['lifetime'] ?? 7200),
    'path' => '/',
    'secure' => (bool) ($config['session']['secure'] ?? false),
    'httponly' => true,
    'samesite' => $config['session']['samesite'] ?? 'Lax',
]);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

spl_autoload_register(static function (string $class): void {
    $prefixes = [
        'Core\\' => BASE_PATH . '/core/',
        'App\\' => BASE_PATH . '/app/',
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        if (!str_starts_with($class, $prefix)) {
            continue;
        }
        $relative = substr($class, strlen($prefix));
        $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

if (php_sapi_name() !== 'cli' && !headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

set_exception_handler(static function (Throwable $e): void {
    if ($e instanceof \App\Exceptions\RedirectException) {
        exit;
    }
    
    // Structured and sanitized error logging (scrubs credentials, passwords, and API keys)
    try {
        if (class_exists(\Core\Logger\StructuredLogger::class)) {
            \Core\Logger\StructuredLogger::error($e->getMessage(), [
                'exception' => $e,
            ]);
        }
        if (class_exists(\App\Services\SystemDiagnosticsService::class)) {
            (new \App\Services\SystemDiagnosticsService())->logStructuredError($e);
        } else {
            error_log($e->getMessage());
        }
    } catch (\Throwable $loggingErr) {
        error_log($e->getMessage());
    }

    $debug = (bool) app_config('debug', false);
    if (php_sapi_name() === 'cli') {
        fwrite(STDERR, $e->getMessage() . "\n");
        exit(1);
    }
    $currentCode = http_response_code();
    $statusCode = ($currentCode && $currentCode >= 400 && $currentCode <= 499) ? $currentCode : 500;
    if (str_contains(strtolower($e->getMessage()), 'csrf')) {
        $statusCode = 419;
    }
    http_response_code($statusCode);

    $isJsonExpected = (
        (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) ||
        (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json')) ||
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
        (!empty($_SERVER['REQUEST_URI']) && str_contains($_SERVER['REQUEST_URI'], '/api/'))
    );

    if ($isJsonExpected) {
        header('Content-Type: application/json; charset=utf-8');
        $errorCode = match ($statusCode) {
            419 => 'CSRF_TOKEN_MISMATCH',
            403 => 'FORBIDDEN',
            404 => 'NOT_FOUND',
            422 => 'UNPROCESSABLE_ENTITY',
            default => 'INTERNAL_SERVER_ERROR',
        };
        $errorMessage = ($statusCode === 419)
            ? 'Your session security token has expired. Please refresh the page and try again.'
            : ($debug ? $e->getMessage() : 'An internal error occurred. Please contact support.');

        echo json_encode([
            'success' => false,
            'status' => $statusCode,
            'error' => [
                'code' => $errorCode,
                'message' => $errorMessage,
            ],
            'meta' => [
                'timestamp' => date('c'),
            ]
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($debug) {
        echo '<h1>Application Error (' . $statusCode . ')</h1><pre>' . e($e->getMessage()) . '</pre>';
    } else {
        if ($statusCode === 419 && file_exists(BASE_PATH . '/app/Views/errors/419.php')) {
            view('errors/419', ['title' => 'Session Expired'], 'layouts/guest');
        } elseif ($statusCode === 403 && file_exists(BASE_PATH . '/app/Views/errors/403.php')) {
            view('errors/403', ['title' => 'Access Denied'], 'layouts/guest');
        } else {
            view('errors/500', ['title' => 'Server Error'], 'layouts/guest');
        }
    }
});
