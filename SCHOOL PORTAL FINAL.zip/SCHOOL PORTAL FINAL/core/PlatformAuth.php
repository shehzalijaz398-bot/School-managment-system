<?php

declare(strict_types=1);

namespace Core;

use Core\Database;

final class PlatformAuth
{
    private static ?array $user = null;
    private static ?array $permissions = null;

    public static function attempt(string $email, string $password): bool
    {
        $email = strtolower(trim($email));
        $user = Database::fetch(
            'SELECT u.*, r.slug AS role_slug, r.name AS role_name
             FROM platform_users u
             INNER JOIN platform_roles r ON r.id = u.role_id
             WHERE u.email = ? LIMIT 1',
            [$email]
        );

        if (!$user || (int) $user['status'] !== 1) {
            Database::insert(
                'INSERT INTO platform_login_attempts (email, ip_address, success, attempted_at) VALUES (?, ?, 0, NOW())',
                [$email, Auth::clientIp()]
            );
            return false;
        }

        $lock = Database::fetch(
            'SELECT COUNT(*) AS c FROM platform_login_attempts
             WHERE email = ? AND success = 0 AND attempted_at > (NOW() - INTERVAL 15 MINUTE)',
            [$email]
        );
        if (((int) ($lock['c'] ?? 0)) >= 5) {
            return false;
        }

        if (!password_verify($password, $user['password'])) {
            Database::insert(
                'INSERT INTO platform_login_attempts (email, ip_address, success, attempted_at) VALUES (?, ?, 0, NOW())',
                [$email, Auth::clientIp()]
            );
            return false;
        }

        Database::execute('DELETE FROM platform_login_attempts WHERE email = ? AND success = 0', [$email]);
        self::login($user);
        Database::execute(
            'UPDATE platform_users SET last_login_at = NOW(), last_login_ip = ?, updated_at = NOW() WHERE id = ?',
            [Auth::clientIp(), (int) $user['id']]
        );

        \App\Services\Platform\PlatformAudit::log('login', 'auth', null, 'platform_user', (int) $user['id']);
        return true;
    }

    public static function login(array $user): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            @session_regenerate_id(true);
        }
        unset($user['password']);
        // Clear school session if any
        unset($_SESSION['user_id'], $_SESSION['school_id'], $_SESSION['role_id'], $_SESSION['role_slug']);
        $_SESSION['platform_user_id'] = (int) $user['id'];
        $_SESSION['platform_role_id'] = (int) $user['role_id'];
        $_SESSION['platform_role_slug'] = $user['role_slug'] ?? '';
        $_SESSION['auth_context'] = 'platform';
        self::$user = $user;
        self::$permissions = null;
        TenantContext::clear();
        Auth::clearCache();
    }

    public static function logout(): void
    {
        if (self::id()) {
            \App\Services\Platform\PlatformAudit::log('logout', 'auth', null, 'platform_user', self::id());
        }
        unset($_SESSION['platform_user_id'], $_SESSION['platform_role_id'], $_SESSION['platform_role_slug'], $_SESSION['auth_context'], $_SESSION['impersonation']);
        self::$user = null;
        self::$permissions = null;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }
        if (empty($_SESSION['platform_user_id'])) {
            return null;
        }
        // Allow platform identity during support impersonation even if auth_context is school
        $ctx = $_SESSION['auth_context'] ?? '';
        if ($ctx !== 'platform' && empty($_SESSION['impersonation'])) {
            return null;
        }
        $user = Database::fetch(
            'SELECT u.*, r.slug AS role_slug, r.name AS role_name
             FROM platform_users u
             INNER JOIN platform_roles r ON r.id = u.role_id
             WHERE u.id = ? AND u.status = 1 LIMIT 1',
            [(int) $_SESSION['platform_user_id']]
        );
        if (!$user) {
            return null;
        }
        unset($user['password']);
        self::$user = $user;
        return self::$user;
    }

    public static function id(): ?int
    {
        $u = self::user();
        return $u ? (int) $u['id'] : null;
    }

    public static function permissions(): array
    {
        if (self::$permissions !== null) {
            return self::$permissions;
        }
        $u = self::user();
        if (!$u) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT p.slug FROM platform_permissions p
             INNER JOIN platform_role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ?',
            [(int) $u['role_id']]
        );
        self::$permissions = array_column($rows, 'slug');
        return self::$permissions;
    }

    public static function hasPermission(string $permission): bool
    {
        $slug = self::user()['role_slug'] ?? '';
        if ($slug === 'super_admin') {
            return true;
        }
        return in_array($permission, self::permissions(), true);
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            flash('error', 'Please log in with verified platform administrator credentials.');
            redirect(url('superadmin/login'));
        }
    }

    public static function requirePermission(string $permission): void
    {
        self::requireLogin();
        if (!self::hasPermission($permission)) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            exit;
        }
    }
}
