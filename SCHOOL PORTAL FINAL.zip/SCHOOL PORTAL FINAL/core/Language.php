<?php

declare(strict_types=1);

namespace Core;

class Language
{
    private static array $dictionary = [];
    private static string $currentLocale = 'en';
    private static bool $initialized = false;
    private static string $direction = 'ltr';

    public static function init(): void
    {
        if (self::$initialized) return;

        try {
            Database::execute("
                CREATE TABLE IF NOT EXISTS system_languages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    locale_code VARCHAR(10) NOT NULL UNIQUE,
                    language_name VARCHAR(50) NOT NULL,
                    direction VARCHAR(5) NOT NULL DEFAULT 'ltr',
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            
            Database::execute("
                CREATE TABLE IF NOT EXISTS system_translations (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    locale_code VARCHAR(10) NOT NULL,
                    translation_key VARCHAR(150) NOT NULL,
                    translated_value TEXT NOT NULL,
                    module_scope VARCHAR(50) NULL,
                    updated_at DATETIME NOT NULL,
                    UNIQUE KEY unique_translation (locale_code, translation_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
        } catch (\Throwable $e) {}

        // Insert default EN if none exists
        try {
            $check = Database::fetch("SELECT id FROM system_languages WHERE locale_code = 'en'");
            if (!$check) {
                Database::insert("INSERT INTO system_languages (locale_code, language_name, direction, is_active, created_at) VALUES ('en', 'English', 'ltr', 1, NOW())");
            }
        } catch (\Throwable $e) {}

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $locale = $_COOKIE['app_locale'] ?? $_SESSION['app_locale'] ?? 'en';
        
        try {
            $langDef = Database::fetch("SELECT * FROM system_languages WHERE locale_code = ? AND is_active = 1", [$locale]);
            if ($langDef) {
                self::$currentLocale = $locale;
                self::$direction = $langDef['direction'];
            } else {
                self::$currentLocale = 'en';
                self::$direction = 'ltr';
            }

            // Memory-cached language array
            $translations = Database::fetchAll("SELECT translation_key, translated_value FROM system_translations WHERE locale_code = ?", [self::$currentLocale]);
            foreach ($translations as $row) {
                self::$dictionary[$row['translation_key']] = $row['translated_value'];
            }
        } catch (\Throwable $e) {}

        self::$initialized = true;
    }

    public static function translate(string $key, string $default = ''): string
    {
        self::init();
        return self::$dictionary[$key] ?? ($default ?: $key);
    }
    
    public static function getDirection(): string
    {
        self::init();
        return self::$direction;
    }
    
    public static function getActiveLanguages(): array
    {
        self::init();
        try {
            return Database::fetchAll("SELECT * FROM system_languages WHERE is_active = 1 ORDER BY language_name ASC");
        } catch (\Throwable $e) {
            return [['locale_code' => 'en', 'language_name' => 'English', 'direction' => 'ltr']];
        }
    }
    
    public static function current(): string
    {
        self::init();
        return self::$currentLocale;
    }
}
