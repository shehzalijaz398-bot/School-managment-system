<?php

declare(strict_types=1);

namespace Core;

use App\Middleware\AuthMiddleware;
use App\Middleware\GuestMiddleware;
use App\Middleware\TenantBoundaryMiddleware;
use Closure;

final class Router
{
    /** @var array<int, array<string, mixed>> */
    private array $routes = [];

    /** @var array<int, callable|string|array> */
    private array $globalMiddleware = [];

    /** @var array<string, string|Closure> */
    private array $middlewareAliases = [
        'auth'     => AuthMiddleware::class,
        'guest'    => GuestMiddleware::class,
        'tenant'   => TenantBoundaryMiddleware::class,
        'api.auth' => \App\Middleware\ApiAuthMiddleware::class,
    ];

    /** @var array<string, mixed> Active group stack attributes */
    private array $groupStack = [];

    /**
     * Register a global middleware that executes on all matched routes.
     */
    public function use(callable|string|array $middleware): self
    {
        $this->globalMiddleware[] = $middleware;
        return $this;
    }

    /**
     * Register a named middleware alias.
     */
    public function aliasMiddleware(string $alias, string|Closure $handler): self
    {
        $this->middlewareAliases[$alias] = $handler;
        return $this;
    }

    /**
     * Create a route group with shared attributes (e.g., prefix, middleware).
     *
     * @param array{prefix?: string, middleware?: array} $attributes
     * @param callable(Router): void $callback
     */
    public function group(array $attributes, callable $callback): void
    {
        $this->groupStack[] = $attributes;
        $callback($this);
        array_pop($this->groupStack);
    }

    public function get(string $path, callable|array $handler, array $middleware = []): void
    {
        $this->add('GET', $path, $handler, $middleware);
    }

    public function post(string $path, callable|array $handler, array $middleware = []): void
    {
        $this->add('POST', $path, $handler, $middleware);
    }

    public function put(string $path, callable|array $handler, array $middleware = []): void
    {
        $this->add('PUT', $path, $handler, $middleware);
    }

    public function delete(string $path, callable|array $handler, array $middleware = []): void
    {
        $this->add('DELETE', $path, $handler, $middleware);
    }

    private function add(string $method, string $path, callable|array $handler, array $middleware): void
    {
        $prefix = '';
        $groupMiddleware = [];

        foreach ($this->groupStack as $group) {
            if (!empty($group['prefix'])) {
                $prefix .= '/' . trim((string) $group['prefix'], '/');
            }
            if (!empty($group['middleware'])) {
                $groupMiddleware = array_merge($groupMiddleware, (array) $group['middleware']);
            }
        }

        $fullPath = trim($prefix . '/' . trim($path, '/'), '/');

        $this->routes[] = [
            'method'     => $method,
            'path'       => $fullPath,
            'handler'    => $handler,
            'middleware' => array_merge($groupMiddleware, $middleware),
        ];
    }

    public function dispatch(string $uri, string $method): void
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $path = $this->normalizePath($path);
        $method = strtoupper($method);

        foreach ($this->routes as $route) {
            $params = $this->match($route['path'], $path);
            if ($params === null || $route['method'] !== $method) {
                continue;
            }

            // Assemble execution pipeline: Global middleware + Route middleware
            $pipeline = array_merge($this->globalMiddleware, $route['middleware']);
            $this->runMiddlewarePipeline($pipeline);

            $handler = $route['handler'];
            if (is_array($handler)) {
                [$class, $action] = $handler;
                $controller = new $class();
                call_user_func_array([$controller, $action], $params);
                return;
            }

            call_user_func_array($handler, $params);
            return;
        }

        http_response_code(404);
        view('errors/404', ['title' => 'Page Not Found']);
    }

    /**
     * Executes the middleware pipeline with automated permission and tenant resolution.
     *
     * @param array<int, mixed> $middlewares
     */
    private function runMiddlewarePipeline(array $middlewares): void
    {
        foreach ($middlewares as $mw) {
            // 1. String expression: "permission:perm_name" or "can:perm_name"
            if (is_string($mw) && (str_starts_with($mw, 'permission:') || str_starts_with($mw, 'can:'))) {
                $permission = substr($mw, strpos($mw, ':') + 1);
                $this->assertPermission($permission);
                continue;
            }

            // 2. String expression: "role:role1,role2"
            if (is_string($mw) && str_starts_with($mw, 'role:')) {
                $roles = explode(',', substr($mw, 5));
                $this->assertRole($roles);
                continue;
            }

            // 3. String expression: "tenant"
            if ($mw === 'tenant') {
                (new TenantBoundaryMiddleware())->handle();
                continue;
            }

            // 4. String expression: "csrf"
            if ($mw === 'csrf') {
                CSRF::verifyRequest();
                continue;
            }

            // 5. Named alias lookup
            if (is_string($mw) && isset($this->middlewareAliases[$mw])) {
                $resolved = $this->middlewareAliases[$mw];
                if (is_string($resolved) && class_exists($resolved)) {
                    (new $resolved())->handle();
                    continue;
                }
                if ($resolved instanceof Closure) {
                    $resolved();
                    continue;
                }
            }

            // 6. Direct Class string
            if (is_string($mw) && class_exists($mw)) {
                (new $mw())->handle();
                continue;
            }

            // 7. Array parameterized middleware: [ClassName, ...args]
            if (is_array($mw) && isset($mw[0]) && is_string($mw[0]) && class_exists($mw[0])) {
                $class = $mw[0];
                $args = array_slice($mw, 1);
                (new $class(...$args))->handle();
                continue;
            }

            // 8. Closure / Callable
            if (is_callable($mw)) {
                $mw();
                continue;
            }
        }
    }

    /**
     * Role-based permission assertion.
     */
    private function assertPermission(string $permission): void
    {
        if (!Auth::check()) {
            flash('error', 'Please log in to continue.');
            redirect(url('login'));
        }

        if (!Auth::hasPermission($permission)) {
            http_response_code(403);
            view('errors/403', [
                'title'   => 'Access Forbidden',
                'message' => "You do not have the required [{$permission}] permission to access this module.",
            ]);
            exit;
        }
    }

    /**
     * Role assertion check against allowed roles.
     *
     * @param array<int, string> $allowedRoles
     */
    private function assertRole(array $allowedRoles): void
    {
        if (!Auth::check()) {
            flash('error', 'Please log in to continue.');
            redirect(url('login'));
        }

        $userRole = Auth::roleSlug();
        $matched = false;
        foreach ($allowedRoles as $role) {
            $role = trim($role);
            if ($role === $userRole || Auth::isRole($role)) {
                $matched = true;
                break;
            }
        }

        if (!$matched) {
            http_response_code(403);
            view('errors/403', [
                'title'   => 'Forbidden Role',
                'message' => 'Your current system role does not have authorization for this area.',
            ]);
            exit;
        }
    }

    private function normalizePath(string $path): string
    {
        $path = rawurldecode($path);
        $scriptName = dirname($_SERVER['SCRIPT_NAME'] ?? '');
        $scriptName = str_replace('\\', '/', $scriptName);

        $basePath = $scriptName;
        if (str_ends_with($basePath, '/public')) {
            $basePath = substr($basePath, 0, -7);
        }

        if ($basePath !== '' && $basePath !== '/' && str_starts_with($path, $basePath)) {
            $path = substr($path, strlen($basePath));
        }

        // Support /public prefix removal when rewriting
        if (str_starts_with($path, '/public/')) {
            $path = substr($path, 7);
        } elseif ($path === '/public') {
            $path = '';
        }

        return trim($path, '/');
    }

    private function match(string $routePath, string $requestPath): ?array
    {
        if ($routePath === $requestPath) {
            return [];
        }

        $routeParts = $routePath === '' ? [] : explode('/', $routePath);
        $requestParts = $requestPath === '' ? [] : explode('/', $requestPath);

        if (count($routeParts) !== count($requestParts)) {
            return null;
        }

        $params = [];
        foreach ($routeParts as $i => $part) {
            if (preg_match('/^\{([a-zA-Z_][a-zA-Z0-9_]*)\}$/', $part, $m)) {
                $params[] = $requestParts[$i];
                continue;
            }
            if ($part !== $requestParts[$i]) {
                return null;
            }
        }

        return $params;
    }
}
