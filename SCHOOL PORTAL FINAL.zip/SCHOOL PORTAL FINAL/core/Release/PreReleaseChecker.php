<?php

declare(strict_types=1);

namespace Core\Release;

use Core\CSRF;
use Core\Database;
use Core\Database\MigrationManager;
use Core\Cache;
use Throwable;

/**
 * PreReleaseChecker
 *
 * Automated pre-release verification engine for enterprise deployment readiness:
 * - Runtime & PHP 8.2+ extensions audit
 * - Production security & secrets entropy audit
 * - Storage filesystem permissions & directory structure
 * - Database health, InnoDB engine, utf8mb4 collation & latency
 * - Migration status & checksum tampering detection
 * - Referential data integrity & orphaned records audit
 * - Multi-tenant isolation & RBAC matrix verification
 * - CSRF token verification & auth security
 * - Cache & background queue worker telemetry
 * - Critical operational workflows smoke test
 */
final class PreReleaseChecker
{
    /**
     * Run all 10 pre-release verification checks.
     *
     * @return array{passed: bool, total_checks: int, passed_checks: int, failed_checks: int, results: array}
     */
    public function runAll(): array
    {
        $checks = [
            'php_runtime'             => $this->checkPhpRuntime(),
            'environment_security'    => $this->checkEnvironmentSecurity(),
            'storage_permissions'     => $this->checkStoragePermissions(),
            'database_engine_health'  => $this->checkDatabaseEngineHealth(),
            'database_migrations'     => $this->checkMigrations(),
            'referential_integrity'   => $this->checkReferentialIntegrity(),
            'tenant_isolation'        => $this->checkTenantIsolation(),
            'auth_rbac_csrf'          => $this->checkAuthRbacCsrf(),
            'cache_queue_telemetry'   => $this->checkCacheQueueTelemetry(),
            'critical_workflows'      => $this->checkCriticalWorkflows(),
        ];

        $passedCount = 0;
        $failedCount = 0;

        foreach ($checks as $c) {
            if ($c['passed']) {
                $passedCount++;
            } else {
                $failedCount++;
            }
        }

        return [
            'passed' => $failedCount === 0,
            'total_checks' => count($checks),
            'passed_checks' => $passedCount,
            'failed_checks' => $failedCount,
            'results' => $checks,
        ];
    }

    /**
     * 1. PHP Runtime & Extensions Audit
     */
    public function checkPhpRuntime(): array
    {
        $phpVersion = PHP_VERSION;
        $versionOk = version_compare($phpVersion, '8.2.0', '>=');

        $requiredExts = ['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'json', 'curl', 'session', 'tokenizer', 'fileinfo'];
        $missingExts = [];

        foreach ($requiredExts as $ext) {
            if (!extension_loaded($ext)) {
                $missingExts[] = $ext;
            }
        }

        $recommendedExts = ['gd', 'zip'];
        $advisoryNotes = [];
        foreach ($recommendedExts as $ext) {
            if (!extension_loaded($ext)) {
                $advisoryNotes[] = "Extension '{$ext}' recommended for image processing/archive export.";
            }
        }

        $passed = $versionOk && empty($missingExts);

        return [
            'name' => 'PHP Runtime & Extensions',
            'passed' => $passed,
            'details' => [
                'php_version' => $phpVersion,
                'min_required' => '8.2.0',
                'version_ok' => $versionOk,
                'required_extensions' => $requiredExts,
                'missing_extensions' => $missingExts,
                'advisory' => $advisoryNotes,
            ],
            'message' => $passed
                ? "PHP {$phpVersion} running with all required enterprise extensions." . (!empty($advisoryNotes) ? " (" . implode(' ', $advisoryNotes) . ")" : "")
                : ("PHP runtime issue: " . (!$versionOk ? "PHP 8.2+ required. " : "") . (!empty($missingExts) ? "Missing extensions: " . implode(', ', $missingExts) : "")),
        ];
    }

    /**
     * 2. Environment & Security Configuration Audit
     */
    public function checkEnvironmentSecurity(): array
    {
        $appEnv = env('APP_ENV', 'local');
        $appDebug = (bool) env('APP_DEBUG', true);
        $backupKey = env('BACKUP_ENCRYPTION_KEY', '');

        $issues = [];

        if ($appEnv === 'production' && $appDebug) {
            $issues[] = 'APP_DEBUG must be false when APP_ENV is production.';
        }

        if (strlen($backupKey) < 32 || $backupKey === 'CHANGE_THIS_TO_A_SECURE_RANDOM_KEY_AT_LEAST_32_BYTES') {
            $issues[] = 'BACKUP_ENCRYPTION_KEY is insecure, default, or less than 32 characters.';
        }

        $sessionSecure = (bool) env('SESSION_SECURE', false);
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        if ($isHttps && !$sessionSecure) {
            $issues[] = 'SESSION_SECURE must be enabled on HTTPS environments.';
        }

        $passed = empty($issues);

        return [
            'name' => 'Environment & Security Config',
            'passed' => $passed,
            'details' => [
                'app_env' => $appEnv,
                'app_debug' => $appDebug,
                'backup_key_length' => strlen($backupKey),
                'session_secure' => $sessionSecure,
                'issues' => $issues,
            ],
            'message' => $passed
                ? "Environment configuration and secret entropy verified."
                : ("Security warnings: " . implode('; ', $issues)),
        ];
    }

    /**
     * 3. Filesystem Permissions & Storage Roots
     */
    public function checkStoragePermissions(): array
    {
        $base = dirname(__DIR__, 2);
        $dirs = [
            'storage/logs'      => $base . '/storage/logs',
            'storage/cache'     => $base . '/storage/cache',
            'storage/backups'   => $base . '/storage/backups',
            'storage/documents' => $base . '/storage/documents',
            'storage/reports'   => $base . '/storage/reports',
            'storage/framework' => $base . '/storage/framework',
        ];

        $status = [];
        $failedDirs = [];

        foreach ($dirs as $label => $path) {
            if (!is_dir($path)) {
                @mkdir($path, 0755, true);
            }
            $isWritable = is_writable($path);
            $status[$label] = $isWritable;
            if (!$isWritable) {
                $failedDirs[] = $label;
            }
        }

        $passed = empty($failedDirs);

        return [
            'name' => 'Filesystem Storage Permissions',
            'passed' => $passed,
            'details' => $status,
            'message' => $passed
                ? "All 6 critical storage directories exist and are writable."
                : ("Writable permissions missing on: " . implode(', ', $failedDirs)),
        ];
    }

    /**
     * 4. Database Engine, Collation & Performance
     */
    public function checkDatabaseEngineHealth(): array
    {
        $startTime = microtime(true);
        $connected = false;
        $latencyMs = 0.0;
        $nonInnodbTables = [];
        $nonUtf8Tables = [];

        try {
            $res = Database::fetch("SELECT 1 as alive");
            $latencyMs = round((microtime(true) - $startTime) * 1000, 2);
            $connected = ($res && (int)$res['alive'] === 1);

            // Audit engine & collation of core tables
            $tables = Database::fetchAll("
                SELECT TABLE_NAME, ENGINE, TABLE_COLLATION 
                FROM information_schema.TABLES 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME IN ('users', 'students', 'classes', 'student_fee_invoices', 'payments')
            ");

            foreach ($tables as $t) {
                if (strtolower($t['ENGINE'] ?? '') !== 'innodb') {
                    $nonInnodbTables[] = $t['TABLE_NAME'];
                }
                if (!str_contains(strtolower($t['TABLE_COLLATION'] ?? ''), 'utf8mb4')) {
                    $nonUtf8Tables[] = $t['TABLE_NAME'];
                }
            }
        } catch (Throwable $e) {
            $connected = false;
        }

        $passed = $connected && $latencyMs < 100.0 && empty($nonInnodbTables) && empty($nonUtf8Tables);

        return [
            'name' => 'Database Engine & Latency',
            'passed' => $passed,
            'details' => [
                'connected' => $connected,
                'latency_ms' => $latencyMs,
                'non_innodb_tables' => $nonInnodbTables,
                'non_utf8_tables' => $nonUtf8Tables,
            ],
            'message' => $passed
                ? "Database responsive ({$latencyMs}ms), InnoDB engine and utf8mb4 verified."
                : "Database check failed or degraded (Latency: {$latencyMs}ms).",
        ];
    }

    /**
     * 5. Database Migration Status
     */
    public function checkMigrations(): array
    {
        try {
            $manager = new MigrationManager();
            $statusList = $manager->getStatus();

            $pending = [];
            $tampered = [];

            foreach ($statusList as $item) {
                if ($item['status'] === 'pending') {
                    $pending[] = $item['migration'];
                }
                if ($item['checksum_tampered']) {
                    $tampered[] = $item['migration'];
                }
            }

            $passed = empty($pending) && empty($tampered);

            return [
                'name' => 'Database Migrations',
                'passed' => $passed,
                'details' => [
                    'total_migrations' => count($statusList),
                    'pending' => $pending,
                    'tampered' => $tampered,
                ],
                'message' => $passed
                    ? "All " . count($statusList) . " database migrations applied cleanly with verified checksums."
                    : ("Migration issues: " . (!empty($pending) ? count($pending) . " pending migrations. " : "") . (!empty($tampered) ? count($tampered) . " tampered checksums." : "")),
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Database Migrations',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Unable to verify migrations: " . $e->getMessage(),
            ];
        }
    }

    /**
     * 6. Referential Data Integrity & Orphaned Records
     */
    public function checkReferentialIntegrity(): array
    {
        try {
            // Check A: Students with non-existent classes
            $orphanedStudents = (int) (Database::fetch("
                SELECT COUNT(*) as c FROM students s 
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
                WHERE s.class_id IS NOT NULL AND c.id IS NULL
            ")['c'] ?? 0);

            // Check B: Fee invoices with non-existent student reference
            $orphanedInvoices = (int) (Database::fetch("
                SELECT COUNT(*) as c FROM student_fee_invoices i 
                LEFT JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
                WHERE s.id IS NULL
            ")['c'] ?? 0);

            // Check C: Payments with non-existent invoice reference
            $orphanedPayments = (int) (Database::fetch("
                SELECT COUNT(*) as c FROM payments p 
                LEFT JOIN student_fee_invoices i ON i.id = p.invoice_id AND i.school_id = p.school_id
                WHERE i.id IS NULL
            ")['c'] ?? 0);

            // Check D: Exam marks with non-existent student reference
            $orphanedMarks = (int) (Database::fetch("
                SELECT COUNT(*) as c FROM exam_marks m 
                LEFT JOIN students s ON s.id = m.student_id AND s.school_id = m.school_id
                WHERE s.id IS NULL
            ")['c'] ?? 0);

            // Check E: Attendance records with non-existent student reference
            $orphanedAttendance = (int) (Database::fetch("
                SELECT COUNT(*) as c FROM student_attendance sa 
                LEFT JOIN students s ON s.id = sa.student_id AND s.school_id = sa.school_id
                WHERE s.id IS NULL
            ")['c'] ?? 0);

            $passed = ($orphanedStudents === 0 && $orphanedInvoices === 0 && $orphanedPayments === 0 && $orphanedMarks === 0 && $orphanedAttendance === 0);

            return [
                'name' => 'Referential Data Integrity',
                'passed' => $passed,
                'details' => [
                    'orphaned_students' => $orphanedStudents,
                    'orphaned_invoices' => $orphanedInvoices,
                    'orphaned_payments' => $orphanedPayments,
                    'orphaned_exam_marks' => $orphanedMarks,
                    'orphaned_attendance' => $orphanedAttendance,
                ],
                'message' => $passed
                    ? "Zero orphaned students, invoices, payment records, marks, or attendance logs found."
                    : "Integrity alert: Orphaned records detected.",
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Referential Data Integrity',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Integrity audit query failed: " . $e->getMessage(),
            ];
        }
    }

    /**
     * 7. Multi-Tenant Isolation Verification
     */
    public function checkTenantIsolation(): array
    {
        try {
            // Confirm tenant tables possess indexing school_id
            $coreTenantTables = [
                'students',
                'classes',
                'sections',
                'student_fee_invoices',
                'payments',
                'student_attendance',
                'staff_attendance',
                'exams',
                'exam_marks',
                'leave_requests',
                'payroll'
            ];
            $missingSchoolId = [];

            foreach ($coreTenantTables as $tbl) {
                $hasCol = Database::fetch("
                    SELECT COUNT(*) as c FROM information_schema.COLUMNS 
                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'school_id'
                ", [$tbl]);

                if ((int)($hasCol['c'] ?? 0) === 0) {
                    $missingSchoolId[] = $tbl;
                }
            }

            $passed = empty($missingSchoolId);

            return [
                'name' => 'Multi-Tenant Data Isolation',
                'passed' => $passed,
                'details' => [
                    'checked_tables' => $coreTenantTables,
                    'missing_school_id' => $missingSchoolId,
                ],
                'message' => $passed
                    ? "Tenant isolation confirmed across all core operational tables with indexing school_id."
                    : ("Tenant isolation risk: Tables missing school_id: " . implode(', ', $missingSchoolId)),
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Multi-Tenant Data Isolation',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Tenant isolation check failed: " . $e->getMessage(),
            ];
        }
    }

    /**
     * 8. Authentication, RBAC & CSRF Safeguards
     */
    public function checkAuthRbacCsrf(): array
    {
        try {
            // CSRF Token Generation & Validation Test
            $token = CSRF::token();
            $csrfValid = (!empty($token) && CSRF::validate($token));

            // Verify Core Roles & Permissions
            $rolesCount = (int) (Database::fetch("SELECT COUNT(*) as c FROM roles")['c'] ?? 0);
            $permsCount = (int) (Database::fetch("SELECT COUNT(*) as c FROM permissions")['c'] ?? 0);

            $passed = $csrfValid && $rolesCount >= 4 && $permsCount >= 10;

            return [
                'name' => 'Auth, RBAC & CSRF Protection',
                'passed' => $passed,
                'details' => [
                    'csrf_token_functional' => $csrfValid,
                    'roles_count' => $rolesCount,
                    'permissions_count' => $permsCount,
                ],
                'message' => $passed
                    ? "Anti-CSRF token verification and RBAC matrix ({$rolesCount} roles, {$permsCount} permissions) verified."
                    : "Auth/RBAC validation failed.",
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Auth, RBAC & CSRF Protection',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Auth check error: " . $e->getMessage(),
            ];
        }
    }

    /**
     * 9. Cache & Background Queue Telemetry
     */
    public function checkCacheQueueTelemetry(): array
    {
        try {
            // 1. Cache Read/Write/Forget verification
            $testKey = 'prerelease_test_' . time();
            $testVal = 'enterprise_verified_' . bin2hex(random_bytes(4));
            Cache::set($testKey, $testVal, 60);
            $retrieved = Cache::get($testKey);
            Cache::forget($testKey);
            $cacheOk = ($retrieved === $testVal);

            // 2. Queue Tables Verification
            $queueTables = ['platform_jobs', 'platform_failed_jobs', 'platform_job_runs'];
            $missingTables = [];

            foreach ($queueTables as $tbl) {
                $chk = Database::fetch("
                    SELECT COUNT(*) as c FROM information_schema.TABLES 
                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
                ", [$tbl]);

                if ((int)($chk['c'] ?? 0) === 0) {
                    $missingTables[] = $tbl;
                }
            }

            // 3. Worker & Scheduler CLI Runners Verification
            $workerPath = dirname(__DIR__, 2) . '/bin/worker.php';
            $schedulerPath = dirname(__DIR__, 2) . '/bin/scheduler.php';
            $workerOk = file_exists($workerPath) && is_readable($workerPath);
            $schedulerOk = file_exists($schedulerPath) && is_readable($schedulerPath);

            $passed = $cacheOk && empty($missingTables) && $workerOk && $schedulerOk;

            return [
                'name' => 'Cache & Background Queue Telemetry',
                'passed' => $passed,
                'details' => [
                    'cache_operational' => $cacheOk,
                    'queue_tables_verified' => $queueTables,
                    'missing_queue_tables' => $missingTables,
                    'worker_cli_verified' => $workerOk,
                    'scheduler_cli_verified' => $schedulerOk,
                ],
                'message' => $passed
                    ? "Cache engine (L1/L2), queue schema, and CLI automation daemons (worker.php & scheduler.php) verified."
                    : ("Cache/Queue issue: " . (!$cacheOk ? "Cache storage failed. " : "") . (!empty($missingTables) ? "Missing tables: " . implode(', ', $missingTables) . ". " : "") . (!$workerOk ? "bin/worker.php missing. " : "") . (!$schedulerOk ? "bin/scheduler.php missing." : "")),
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Cache & Background Queue Telemetry',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Cache/Queue check error: " . $e->getMessage(),
            ];
        }
    }

    /**
     * 10. Critical Workflows Smoke Verification
     */
    public function checkCriticalWorkflows(): array
    {
        try {
            // Ensure at least one active school tenant exists
            $schoolsCount = (int) (Database::fetch("SELECT COUNT(*) as c FROM schools WHERE status = 1 OR status = 'active'")['c'] ?? 0);

            // Ensure academic years exist
            $yearsCount = (int) (Database::fetch("SELECT COUNT(*) as c FROM academic_years")['c'] ?? 0);
            $termsCount = (int) (Database::fetch("SELECT COUNT(*) as c FROM academic_terms")['c'] ?? 0);

            // Cached settings retrieval speed test (< 5ms)
            $benchStart = microtime(true);
            $settings = school_settings(4);
            $benchMs = round((microtime(true) - $benchStart) * 1000, 2);

            $passed = ($schoolsCount > 0 && ($yearsCount > 0 || $termsCount > 0) && is_array($settings) && $benchMs < 50.0);

            return [
                'name' => 'Critical Operational Workflows',
                'passed' => $passed,
                'details' => [
                    'active_schools' => $schoolsCount,
                    'academic_years' => $yearsCount,
                    'academic_terms' => $termsCount,
                    'cached_settings_read_ms' => $benchMs,
                ],
                'message' => $passed
                    ? "Critical school workflows active ({$schoolsCount} schools, {$yearsCount} academic years, {$termsCount} terms, settings read in {$benchMs}ms)."
                    : "Critical workflow smoke test failed.",
            ];
        } catch (Throwable $e) {
            return [
                'name' => 'Critical Operational Workflows',
                'passed' => false,
                'details' => ['error' => $e->getMessage()],
                'message' => "Workflow check error: " . $e->getMessage(),
            ];
        }
    }
}
