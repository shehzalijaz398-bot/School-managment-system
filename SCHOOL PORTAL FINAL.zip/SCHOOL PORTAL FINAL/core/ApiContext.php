<?php

declare(strict_types=1);

namespace Core;

/**
 * Manages request-scoped authenticated API token claims and tenant boundary.
 */
final class ApiContext
{
    /** @var array<string, mixed>|null */
    private static ?array $claims = null;

    public static function setClaims(array $claims): void
    {
        self::$claims = $claims;
        if (!empty($claims['tenant_id'])) {
            TenantContext::setExplicitSchoolId((int) $claims['tenant_id']);
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function getClaims(): ?array
    {
        return self::$claims;
    }

    public static function isAuthenticated(): bool
    {
        return self::$claims !== null;
    }

    public static function userId(): ?int
    {
        return isset(self::$claims['sub']) ? (int) self::$claims['sub'] : null;
    }

    public static function tenantId(): int
    {
        if (empty(self::$claims['tenant_id'])) {
            throw new \RuntimeException('No tenant ID bound to current API token.');
        }
        return (int) self::$claims['tenant_id'];
    }

    public static function role(): string
    {
        return (string) (self::$claims['role'] ?? 'guest');
    }

    public static function studentId(): ?int
    {
        return isset(self::$claims['student_id']) ? (int) self::$claims['student_id'] : null;
    }

    public static function deviceId(): ?string
    {
        return isset(self::$claims['device_id']) ? (string) self::$claims['device_id'] : null;
    }

    public static function clear(): void
    {
        self::$claims = null;
        TenantContext::setExplicitSchoolId(null);
    }
}
