<?php

declare(strict_types=1);

namespace Core\Exceptions;

use RuntimeException;

/**
 * Thrown whenever an Insecure Direct Object Reference (IDOR) or
 * cross-tenant asset access attempt is detected.
 */
class TenantSecurityException extends RuntimeException
{
    private string $resource;
    private int $resourceId;
    private int $tenantId;

    public function __construct(
        string $message = "Forbidden: Cross-tenant access violation detected.",
        string $resource = '',
        int $resourceId = 0,
        int $tenantId = 0,
        int $code = 403,
        ?\Throwable $previous = null
    ) {
        parent::__construct($message, $code, $previous);
        $this->resource = $resource;
        $this->resourceId = $resourceId;
        $this->tenantId = $tenantId;
    }

    public function getResource(): string
    {
        return $this->resource;
    }

    public function getResourceId(): int
    {
        return $this->resourceId;
    }

    public function getTenantId(): int
    {
        return $this->tenantId;
    }
}
