<?php

declare(strict_types=1);

namespace Core;

final class CSRF
{
    public static function token(): string
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $key = $config['csrf_token_name'];

        if (empty($_SESSION[$key])) {
            $_SESSION[$key] = bin2hex(random_bytes(32));
        }

        return $_SESSION[$key];
    }

    public static function field(): string
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $name = htmlspecialchars($config['csrf_token_name'], ENT_QUOTES, 'UTF-8');
        $token = htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="' . $name . '" value="' . $token . '">';
    }

    public static function validate(?string $token): bool
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $key = $config['csrf_token_name'];
        $sessionToken = $_SESSION[$key] ?? '';

        if ($token === null || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
            return false;
        }

        return true;
    }

    public static function verifyRequest(): void
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $key = $config['csrf_token_name'];
        $token = $_POST[$key] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_SERVER['HTTP_X_XSRF_TOKEN'] ?? null;

        if ($token === null) {
            $rawInput = file_get_contents('php://input');
            if ($rawInput !== false && $rawInput !== '') {
                $decoded = json_decode($rawInput, true);
                if (is_array($decoded)) {
                    $token = $decoded[$key] ?? $decoded['csrf_token'] ?? null;
                }
            }
        }

        if (!self::validate(is_string($token) ? $token : null)) {
            http_response_code(419);
            throw new \RuntimeException('Invalid or missing CSRF token.');
        }
    }
}
