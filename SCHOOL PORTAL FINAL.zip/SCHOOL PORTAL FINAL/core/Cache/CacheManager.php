<?php

declare(strict_types=1);

namespace Core\Cache;

use Core\TenantContext;

/**
 * Enterprise Multi-Tenant Aware Cache Engine for Pure PHP 8.2+ Architecture.
 * Combines zero-latency L1 in-memory caching with high-throughput L2 atomic filesystem storage.
 */
final class CacheManager
{
    /** @var array<string, mixed> L1 In-Memory process cache for instantaneous within-request lookups */
    private static array $memoryStore = [];

    /** @var string Base storage directory for persistent L2 file cache */
    private static ?string $cacheDir = null;

    /**
     * Get the cache directory, ensuring it exists.
     */
    public static function getCacheDir(): string
    {
        if (self::$cacheDir === null) {
            $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
            self::$cacheDir = $base . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'cache';
            if (!is_dir(self::$cacheDir)) {
                @mkdir(self::$cacheDir, 0755, true);
            }
        }
        return self::$cacheDir;
    }

    /**
     * Build tenant-isolated cache key.
     */
    public static function buildKey(string $key, ?int $schoolId = null): string
    {
        $tenantId = $schoolId ?? TenantContext::schoolId();
        $prefix = ($tenantId !== null && $tenantId > 0) ? "tenant_{$tenantId}" : "platform";
        $sanitizedKey = preg_replace('/[^a-zA-Z0-9_\-\.:]/', '_', $key);
        return "{$prefix}:{$sanitizedKey}";
    }

    /**
     * Retrieve an item from cache.
     *
     * @param string $key Cache key
     * @param mixed $default Fallback value if missing or expired
     * @param int|null $schoolId Optional tenant override
     * @return mixed
     */
    public static function get(string $key, mixed $default = null, ?int $schoolId = null): mixed
    {
        $scopedKey = self::buildKey($key, $schoolId);

        // 1. Check L1 Memory Cache (Instant 0.00ms lookup)
        if (array_key_exists($scopedKey, self::$memoryStore)) {
            $memItem = self::$memoryStore[$scopedKey];
            if ($memItem['expires_at'] === null || $memItem['expires_at'] >= time()) {
                return $memItem['value'];
            }
            unset(self::$memoryStore[$scopedKey]);
        }

        // 2. Check L2 Filesystem Cache
        $filePath = self::getFilePath($scopedKey);
        if (!file_exists($filePath)) {
            return $default;
        }

        $raw = @file_get_contents($filePath);
        if ($raw === false) {
            return $default;
        }

        try {
            $payload = unserialize($raw, ['allowed_classes' => false]);
            if (!is_array($payload) || !isset($payload['expires_at'], $payload['value'])) {
                @unlink($filePath);
                return $default;
            }

            // Expiry check
            if ($payload['expires_at'] !== null && $payload['expires_at'] < time()) {
                @unlink($filePath);
                return $default;
            }

            // Populate L1 cache for subsequent lookups in this request
            self::$memoryStore[$scopedKey] = [
                'value' => $payload['value'],
                'expires_at' => $payload['expires_at'],
            ];

            return $payload['value'];
        } catch (\Throwable $e) {
            @unlink($filePath);
            return $default;
        }
    }

    /**
     * Store an item in the cache.
     *
     * @param string $key Cache key
     * @param mixed $value Serializable value to cache
     * @param int $ttlSeconds Time to live in seconds (default: 300 = 5 minutes, 0 = forever)
     * @param int|null $schoolId Optional tenant override
     * @return bool True on success
     */
    public static function set(string $key, mixed $value, int $ttlSeconds = 300, ?int $schoolId = null): bool
    {
        $scopedKey = self::buildKey($key, $schoolId);
        $expiresAt = $ttlSeconds > 0 ? (time() + $ttlSeconds) : null;

        // 1. Update L1 Memory Cache
        self::$memoryStore[$scopedKey] = [
            'value' => $value,
            'expires_at' => $expiresAt,
        ];

        // 2. Persist to L2 Filesystem Storage
        $filePath = self::getFilePath($scopedKey);
        $payload = serialize([
            'key' => $scopedKey,
            'expires_at' => $expiresAt,
            'created_at' => time(),
            'value' => $value,
        ]);

        $tmpFile = $filePath . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (@file_put_contents($tmpFile, $payload, LOCK_EX) !== false) {
            return @rename($tmpFile, $filePath);
        }

        return false;
    }

    /**
     * Check if an item exists and has not expired.
     */
    public static function has(string $key, ?int $schoolId = null): bool
    {
        return self::get($key, '__CACHE_MISSING_SENTINEL__', $schoolId) !== '__CACHE_MISSING_SENTINEL__';
    }

    /**
     * Retrieve an item from the cache, or execute the given Closure and store the result.
     *
     * @param string $key Cache key
     * @param int $ttlSeconds Time to live in seconds
     * @param callable $callback Resolver function executing on cache miss
     * @param int|null $schoolId Optional tenant override
     * @return mixed
     */
    public static function remember(string $key, int $ttlSeconds, callable $callback, ?int $schoolId = null): mixed
    {
        $existing = self::get($key, '__CACHE_MISSING_SENTINEL__', $schoolId);
        if ($existing !== '__CACHE_MISSING_SENTINEL__') {
            return $existing;
        }

        $freshValue = $callback();
        self::set($key, $freshValue, $ttlSeconds, $schoolId);
        return $freshValue;
    }

    /**
     * Remove an item from the cache.
     */
    public static function forget(string $key, ?int $schoolId = null): bool
    {
        $scopedKey = self::buildKey($key, $schoolId);
        unset(self::$memoryStore[$scopedKey]);

        $filePath = self::getFilePath($scopedKey);
        if (file_exists($filePath)) {
            return @unlink($filePath);
        }
        return true;
    }

    /**
     * Flush all cached keys belonging strictly to a specific tenant.
     *
     * @param int|null $schoolId
     * @return int Number of cleared cache files
     */
    public static function flushTenant(?int $schoolId = null): int
    {
        $tenantId = $schoolId ?? TenantContext::schoolId();
        if ($tenantId === null || $tenantId <= 0) {
            return 0;
        }

        $prefix = "tenant_{$tenantId}:";
        $cleared = 0;

        // Clear matching keys from L1 memory
        foreach (array_keys(self::$memoryStore) as $k) {
            if (str_starts_with($k, $prefix)) {
                unset(self::$memoryStore[$k]);
            }
        }

        // Clear matching files from L2 storage
        $dir = self::getCacheDir();
        $files = glob($dir . DIRECTORY_SEPARATOR . 'cache_*.dat') ?: [];
        foreach ($files as $file) {
            $content = @file_get_contents($file);
            if ($content !== false && str_contains($content, $prefix)) {
                @unlink($file);
                $cleared++;
            }
        }

        return $cleared;
    }

    /**
     * Flush all platform and tenant cached data completely.
     *
     * @return int Number of cleared cache files
     */
    public static function flushAll(): int
    {
        self::$memoryStore = [];
        $dir = self::getCacheDir();
        $files = glob($dir . DIRECTORY_SEPARATOR . 'cache_*.dat') ?: [];
        $cleared = 0;
        foreach ($files as $file) {
            if (@unlink($file)) {
                $cleared++;
            }
        }
        return $cleared;
    }

    /**
     * Get operational telemetry for the cache engine.
     */
    public static function stats(): array
    {
        $dir = self::getCacheDir();
        $files = glob($dir . DIRECTORY_SEPARATOR . 'cache_*.dat') ?: [];
        $totalBytes = 0;
        $activeCount = 0;
        $expiredCount = 0;
        $now = time();

        foreach ($files as $file) {
            $bytes = filesize($file) ?: 0;
            $totalBytes += $bytes;

            $raw = @file_get_contents($file);
            if ($raw !== false) {
                try {
                    $payload = unserialize($raw, ['allowed_classes' => false]);
                    if (isset($payload['expires_at']) && $payload['expires_at'] !== null && $payload['expires_at'] < $now) {
                        $expiredCount++;
                    } else {
                        $activeCount++;
                    }
                } catch (\Throwable) {
                    $expiredCount++;
                }
            }
        }

        return [
            'status' => 'operational',
            'driver' => 'hybrid_memory_filesystem',
            'memory_entries' => count(self::$memoryStore),
            'total_files' => count($files),
            'active_entries' => $activeCount,
            'expired_entries' => $expiredCount,
            'storage_size_kb' => round($totalBytes / 1024, 2),
            'cache_directory' => $dir,
        ];
    }

    /**
     * Generate deterministically hashed filesystem path for a scoped key.
     */
    private static function getFilePath(string $scopedKey): string
    {
        $hash = hash('sha256', $scopedKey);
        return self::getCacheDir() . DIRECTORY_SEPARATOR . "cache_{$hash}.dat";
    }
}
