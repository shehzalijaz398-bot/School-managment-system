<?php

declare(strict_types=1);

namespace Core\Database;

use App\Services\BackupRecoveryService;
use Core\Database;
use Core\Logger\StructuredLogger;
use RuntimeException;
use Throwable;

/**
 * MigrationManager
 *
 * Enterprise database migration manager with:
 * - Schema tracking via `migrations` table
 * - Automated pre-migration encrypted backup snapshot
 * - Integrity validation & checksum verification (detecting altered files)
 * - Support for Object-Oriented migrations (up/down), SQL scripts, and legacy procedural scripts
 * - Granular rollback and failure handling
 */
final class MigrationManager
{
    private string $migrationsPath;

    public function __construct(?string $migrationsPath = null)
    {
        $this->migrationsPath = $migrationsPath ?? (dirname(__DIR__, 2) . '/database/migrations');
    }

    /**
     * Ensure the internal `migrations` tracking table exists.
     */
    public function ensureMigrationSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS `migrations` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `migration` VARCHAR(255) NOT NULL UNIQUE,
                `batch` INT UNSIGNED NOT NULL,
                `checksum` VARCHAR(64) NOT NULL,
                `status` ENUM('applied', 'rolled_back') NOT NULL DEFAULT 'applied',
                `execution_time_ms` DECIMAL(8, 2) NOT NULL DEFAULT 0.00,
                `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX `idx_mig_batch` (`batch`),
                INDEX `idx_mig_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    /**
     * Get all discovered migration files ordered naturally.
     *
     * @return array<int, string> List of migration filenames
     */
    public function getDiscoveredMigrations(): array
    {
        if (!is_dir($this->migrationsPath)) {
            return [];
        }

        $files = scandir($this->migrationsPath);
        if ($files === false) {
            return [];
        }

        $migrations = [];
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            if (str_ends_with($file, '.php') || str_ends_with($file, '.sql')) {
                $migrations[] = $file;
            }
        }

        natsort($migrations);
        return array_values($migrations);
    }

    /**
     * Get the status of all migrations (applied, pending, checksum altered).
     *
     * @return array<int, array<string, mixed>>
     */
    public function getStatus(): array
    {
        $this->ensureMigrationSchema();

        $rows = Database::fetchAll("SELECT * FROM `migrations` WHERE `status` = 'applied' ORDER BY `id` ASC");
        $appliedMap = [];
        foreach ($rows as $r) {
            $appliedMap[$r['migration']] = $r;
        }

        $discovered = $this->getDiscoveredMigrations();
        $statusList = [];

        foreach ($discovered as $file) {
            $filePath = $this->migrationsPath . '/' . $file;
            $currentChecksum = file_exists($filePath) ? hash_file('sha256', $filePath) : '';

            if (isset($appliedMap[$file])) {
                $rec = $appliedMap[$file];
                $tampered = ($currentChecksum !== '' && !hash_equals($rec['checksum'], $currentChecksum));

                $statusList[] = [
                    'migration' => $file,
                    'status' => 'applied',
                    'batch' => (int) $rec['batch'],
                    'applied_at' => $rec['applied_at'],
                    'execution_time_ms' => (float) $rec['execution_time_ms'],
                    'checksum' => $rec['checksum'],
                    'checksum_tampered' => $tampered,
                ];
            } else {
                $statusList[] = [
                    'migration' => $file,
                    'status' => 'pending',
                    'batch' => null,
                    'applied_at' => null,
                    'execution_time_ms' => null,
                    'checksum' => $currentChecksum,
                    'checksum_tampered' => false,
                ];
            }
        }

        return $statusList;
    }

    /**
     * Execute all pending migrations.
     *
     * @param bool $backupFirst Whether to create an automated snapshot before applying migrations
     * @return array{applied: array, batch: int, backup: ?array, total_time_ms: float}
     */
    public function migrate(bool $backupFirst = true): array
    {
        $this->ensureMigrationSchema();
        $statusList = $this->getStatus();

        $pending = array_filter($statusList, fn($s) => $s['status'] === 'pending');
        if (empty($pending)) {
            return [
                'applied' => [],
                'batch' => 0,
                'backup' => null,
                'total_time_ms' => 0.0,
                'message' => 'Database is already up to date. No pending migrations.',
            ];
        }

        $backupResult = null;
        if ($backupFirst) {
            $backupResult = $this->createPreMigrationBackup();
        }

        // Determine next batch number
        $maxBatchRow = Database::fetch("SELECT MAX(`batch`) as mb FROM `migrations`");
        $nextBatch = ((int) ($maxBatchRow['mb'] ?? 0)) + 1;

        $applied = [];
        $overallStart = microtime(true);

        foreach ($pending as $item) {
            $file = $item['migration'];
            $filePath = $this->migrationsPath . '/' . $file;

            $itemStart = microtime(true);
            try {
                $this->executeMigrationFile($filePath);
                $durationMs = round((microtime(true) - $itemStart) * 1000, 2);
                $checksum = hash_file('sha256', $filePath) ?: '';

                Database::execute("
                    INSERT INTO `migrations` (`migration`, `batch`, `checksum`, `status`, `execution_time_ms`, `applied_at`)
                    VALUES (?, ?, ?, 'applied', ?, NOW())
                    ON DUPLICATE KEY UPDATE 
                        `batch` = VALUES(`batch`),
                        `checksum` = VALUES(`checksum`),
                        `status` = 'applied',
                        `execution_time_ms` = VALUES(`execution_time_ms`),
                        `applied_at` = NOW()
                ", [$file, $nextBatch, $checksum, $durationMs]);

                $applied[] = [
                    'migration' => $file,
                    'duration_ms' => $durationMs,
                    'status' => 'success',
                ];

                if (class_exists(StructuredLogger::class)) {
                    StructuredLogger::info("Applied migration: {$file}", [
                        'batch' => $nextBatch,
                        'duration_ms' => $durationMs,
                    ]);
                }
            } catch (Throwable $e) {
                $durationMs = round((microtime(true) - $itemStart) * 1000, 2);

                if (class_exists(StructuredLogger::class)) {
                    StructuredLogger::error("Migration failed: {$file}", [
                        'batch' => $nextBatch,
                        'duration_ms' => $durationMs,
                        'error' => $e->getMessage(),
                    ]);
                }

                throw new RuntimeException(
                    "Migration failed on [{$file}]: " . $e->getMessage() . 
                    ($backupResult ? " (Pre-migration backup snapshot preserved at: " . ($backupResult['file_name'] ?? 'storage') . ")" : ""),
                    (int) $e->getCode(),
                    $e
                );
            }
        }

        $totalTimeMs = round((microtime(true) - $overallStart) * 1000, 2);

        return [
            'applied' => $applied,
            'batch' => $nextBatch,
            'backup' => $backupResult,
            'total_time_ms' => $totalTimeMs,
            'message' => count($applied) . ' migrations applied successfully in batch ' . $nextBatch . '.',
        ];
    }

    /**
     * Rollback the last batch of migrations (or N batches).
     *
     * @param int $batches Number of batches to roll back (default 1)
     * @return array{rolled_back: array, message: string}
     */
    public function rollback(int $batches = 1): array
    {
        $this->ensureMigrationSchema();

        $batchRows = Database::fetchAll("
            SELECT DISTINCT `batch` FROM `migrations` 
            WHERE `status` = 'applied' 
            ORDER BY `batch` DESC 
            LIMIT ?
        ", [$batches]);

        if (empty($batchRows)) {
            return [
                'rolled_back' => [],
                'message' => 'No applied migrations found to roll back.',
            ];
        }

        $targetBatches = array_column($batchRows, 'batch');
        $placeholders = implode(',', array_fill(0, count($targetBatches), '?'));

        $migrationsToRollback = Database::fetchAll("
            SELECT * FROM `migrations` 
            WHERE `status` = 'applied' AND `batch` IN ({$placeholders})
            ORDER BY `id` DESC
        ", $targetBatches);

        $rolledBack = [];

        foreach ($migrationsToRollback as $rec) {
            $file = $rec['migration'];
            $filePath = $this->migrationsPath . '/' . $file;

            $hasDown = false;
            if (file_exists($filePath) && str_ends_with($file, '.php')) {
                // Check if class-based migration with down()
                $instance = $this->loadMigrationInstance($filePath);
                if (is_object($instance) && method_exists($instance, 'down')) {
                    $instance->down();
                    $hasDown = true;
                }
            }

            // Update status or delete migration record
            Database::execute("
                UPDATE `migrations` SET `status` = 'rolled_back' WHERE `id` = ?
            ", [$rec['id']]);

            $rolledBack[] = [
                'migration' => $file,
                'batch' => $rec['batch'],
                'has_down_method' => $hasDown,
                'status' => $hasDown ? 'rolled_back_executed' : 'record_marked_rolled_back',
            ];

            if (class_exists(StructuredLogger::class)) {
                StructuredLogger::warning("Rolled back migration: {$file}", [
                    'batch' => $rec['batch'],
                    'had_down' => $hasDown,
                ]);
            }
        }

        return [
            'rolled_back' => $rolledBack,
            'message' => count($rolledBack) . ' migrations rolled back.',
        ];
    }

    /**
     * Create a new migration file template.
     *
     * @param string $name Descriptive name (e.g. 'create_health_records_table')
     * @return string Created file path
     */
    public function createMigration(string $name): string
    {
        if (!is_dir($this->migrationsPath)) {
            @mkdir($this->migrationsPath, 0755, true);
        }

        $timestamp = date('Y_m_d_His');
        $cleanName = preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower($name));
        $filename = "{$timestamp}_{$cleanName}.php";
        $filePath = $this->migrationsPath . '/' . $filename;

        $template = <<<PHP
<?php

declare(strict_types=1);

use Core\Database;

/**
 * Migration: {$cleanName}
 * Created: {$timestamp}
 */
return new class {
    public function up(): void
    {
        // Example:
        // Database::execute("
        //     CREATE TABLE IF NOT EXISTS `sample_table` (
        //         `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        //         `school_id` BIGINT UNSIGNED NOT NULL,
        //         `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        //     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        // ");
    }

    public function down(): void
    {
        // Example:
        // Database::execute("DROP TABLE IF EXISTS `sample_table`;");
    }
};

PHP;

        file_put_contents($filePath, $template);
        return $filePath;
    }

    /**
     * Create pre-migration backup snapshot.
     */
    private function createPreMigrationBackup(): ?array
    {
        try {
            $backupService = new BackupRecoveryService();
            // School ID 0 = Platform/Global full database backup snapshot
            $backup = $backupService->createBackup(0, 1, 'full_database');
            return $backup;
        } catch (Throwable $e) {
            // In development, if BackupRecoveryService throws because school 0 isn't seeded, fallback safely
            return [
                'file_name' => 'auto_backup_bypassed_dev',
                'message' => 'Backup warning: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Execute a single migration file.
     */
    private function executeMigrationFile(string $filePath): void
    {
        if (str_ends_with($filePath, '.sql')) {
            $sql = file_get_contents($filePath);
            if ($sql === false || trim($sql) === '') {
                return;
            }

            // Split statements safely
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if ($stmt === '' || str_starts_with($stmt, '--') || str_starts_with($stmt, '#')) {
                    continue;
                }
                try {
                    Database::execute($stmt);
                } catch (Throwable $e) {
                    $msg = strtolower($e->getMessage());
                    // Idempotent safeguard: if index or table or column already exists, safely skip
                    if (str_contains($msg, 'duplicate key name') ||
                        str_contains($msg, 'already exists') ||
                        str_contains($msg, 'duplicate column name')) {
                        continue;
                    }
                    throw $e;
                }
            }
            return;
        }

        // It is a PHP file
        $instance = $this->loadMigrationInstance($filePath);
        if (is_object($instance) && method_exists($instance, 'up')) {
            $instance->up();
            return;
        }

        // Procedural script execution inside isolated closure
        $runner = function (string $__file) {
            ob_start();
            try {
                require $__file;
            } catch (Throwable $e) {
                $msg = strtolower($e->getMessage());
                if (!str_contains($msg, 'duplicate key name') &&
                    !str_contains($msg, 'already exists') &&
                    !str_contains($msg, 'duplicate column name')) {
                    throw $e;
                }
            } finally {
                ob_end_clean();
            }
        };

        $runner($filePath);
    }

    /**
     * Attempt to load object instance from migration file if returned.
     */
    private function loadMigrationInstance(string $filePath): mixed
    {
        $res = null;
        try {
            $res = require $filePath;
        } catch (Throwable $e) {
            // May fail if already required or procedural
        }
        return is_object($res) ? $res : null;
    }
}
