<?php

declare(strict_types=1);

namespace Core;

use App\Helpers\Audit;

abstract class Controller
{
    /**
     * Set to true to automatically enforce CSRF token checks on all POST/PUT/DELETE requests.
     */
    protected bool $autoCsrf = false;

    public function __construct()
    {
        if ($this->autoCsrf && in_array(strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
            $this->requireCsrf();
        }
    }

    /**
     * Render view with automated CSRF injection, contextual XSS protection, and security headers.
     *
     * @param string $name View path (e.g. 'finance/invoices')
     * @param array<string, mixed> $data Template variables
     * @param string|null $layout Master layout file
     */
    protected function view(string $name, array $data = [], ?string $layout = 'layouts/app'): void
    {
        // 1. Enforce HTTP Security Headers
        $this->sendSecurityHeaders();

        // 2. Automated CSRF payload injection into template scope
        $data['csrf_token'] = CSRF::token();
        $data['csrf_field'] = new RawHtml(CSRF::field());

        // 3. Automated Contextual XSS Protection on view data
        $safeData = $this->sanitizeViewData($data);

        // 4. Render view with automated Form CSRF injection via output buffer
        $this->renderWithAutoCsrf($name, $safeData, $layout);
    }

    /**
     * Render template and auto-inject CSRF tokens into POST forms missing a token field.
     *
     * @param string $name
     * @param array<string, mixed> $data
     * @param string|null $layout
     */
    private function renderWithAutoCsrf(string $name, array $data, ?string $layout): void
    {
        extract($data, EXTR_SKIP);
        $viewFile = base_path('app/Views/' . str_replace('.', '/', $name) . '.php');
        if (!is_file($viewFile)) {
            http_response_code(500);
            echo 'View not found: ' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
            return;
        }

        ob_start();
        require $viewFile;
        $content = (string) ob_get_clean();

        if ($layout !== null) {
            $layoutFile = base_path('app/Views/' . str_replace('.', '/', $layout) . '.php');
            if (is_file($layoutFile)) {
                ob_start();
                require $layoutFile;
                $content = (string) ob_get_clean();
            }
        }

        // Post-process HTML: Inject CSRF field into any POST form lacking a token
        $content = $this->injectCsrfIntoForms($content);

        echo $content;
    }

    /**
     * Auto-injects CSRF hidden inputs into any HTML form using POST method that lacks one.
     */
    private function injectCsrfIntoForms(string $html): string
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        $tokenName = $config['csrf_token_name'] ?? '_csrf_token';
        $tokenField = CSRF::field();

        return (string) preg_replace_callback(
            '/(<form\b[^>]*method=["\']?POST["\']?[^>]*>)(.*?)(<\/form>)/is',
            static function (array $matches) use ($tokenName, $tokenField): string {
                $openingTag = $matches[1];
                $body = $matches[2];
                $closingTag = $matches[3];

                if (str_contains($body, 'name="' . $tokenName . '"') || str_contains($body, "name='" . $tokenName . "'")) {
                    return $matches[0];
                }

                return $openingTag . "\n" . $tokenField . $body . $closingTag;
            },
            $html
        );
    }

    /**
     * Recursively sanitizes view variables against XSS attacks.
     * Variables wrapped in RawHtml or keys prefixed with 'raw_' / suffixed with '_html' bypass escaping.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function sanitizeViewData(array $data): array
    {
        $sanitized = [];
        foreach ($data as $key => $value) {
            $keyStr = (string) $key;
            if (str_starts_with($keyStr, 'raw_') || str_ends_with($keyStr, '_html') || $keyStr === 'csrf_field') {
                $sanitized[$key] = $value instanceof RawHtml ? $value->getHtml() : $value;
                continue;
            }

            $sanitized[$key] = $this->escapeValue($value);
        }

        return $sanitized;
    }

    private function escapeValue(mixed $value): mixed
    {
        if ($value instanceof RawHtml) {
            return $value->getHtml();
        }

        if (is_string($value)) {
            return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', false);
        }

        if (is_array($value)) {
            $cleaned = [];
            foreach ($value as $k => $v) {
                $cleaned[$k] = $this->escapeValue($v);
            }
            return $cleaned;
        }

        return $value;
    }

    /**
     * Emits hardened HTTP headers preventing clickjacking, MIME sniffing, and cross-site leaks.
     */
    private function sendSecurityHeaders(): void
    {
        if (!headers_sent()) {
            header('X-Frame-Options: SAMEORIGIN');
            header('X-Content-Type-Options: nosniff');
            header('X-XSS-Protection: 1; mode=block');
            header('Referrer-Policy: strict-origin-when-cross-origin');
        }
    }

    protected function json(array $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function validate(array $data, array $rules): array
    {
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            flash('error', $validator->firstError() ?? 'Validation failed.');
            flash('old', array_filter(
                $data,
                static fn (string $key): bool => !str_contains(strtolower($key), 'password') && !str_contains(strtolower($key), 'token'),
                ARRAY_FILTER_USE_KEY
            ));
            flash('errors', $validator->errors());
            back();
        }
        return $validator->validated();
    }

    protected function requireCsrf(): void
    {
        CSRF::verifyRequest();
    }

    protected function schoolId(): int
    {
        $id = Auth::schoolId();
        if (!$id) {
            http_response_code(403);
            exit('School context required.');
        }
        return $id;
    }

    protected function userId(): int
    {
        $id = Auth::id();
        if (!$id) {
            redirect(url('login'));
        }
        return $id;
    }

    protected function input(string $key, mixed $default = null): mixed
    {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }

    protected function redirect(string $path): never
    {
        redirect($path);
    }

    protected function isAjax(): bool
    {
        return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
    }

    /**
     * Authorize that a database resource belongs strictly to the authenticated tenant.
     * Prevents Insecure Direct Object Reference (IDOR).
     */
    protected function authorizeTenantResource(string $table, int $id, string $tenantColumn = 'school_id'): array
    {
        return TenantGuard::enforce($table, $id, $this->schoolId(), $tenantColumn);
    }
}
