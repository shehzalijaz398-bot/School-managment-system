<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\PlatformAuth;
use Throwable;

/**
 * MaintenanceMiddleware
 *
 * Intercepts incoming requests during maintenance windows:
 * - Checks for storage/framework/down flag file
 * - Allows seamless bypass for SuperAdmins, allowed IPs, and authorized secret tokens (?bypass=TOKEN)
 * - Returns HTTP 503 Service Unavailable with Retry-After header
 * - Delivers JSON payload for API requests and rich styled page for browser visits
 */
final class MaintenanceMiddleware
{
    private string $downFilePath;

    public function __construct(?string $downFilePath = null)
    {
        $this->downFilePath = $downFilePath ?? (dirname(__DIR__, 2) . '/storage/framework/down');
    }

    public function handle(): void
    {
        if (!file_exists($this->downFilePath)) {
            return;
        }

        $raw = @file_get_contents($this->downFilePath);
        $data = $raw ? json_decode($raw, true) : [];
        if (!is_array($data)) {
            $data = [];
        }

        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';

        // 1. Bypass: Machine-readable system health check must remain accessible to monitoring
        if (str_contains($path, '/api/v1/system/health')) {
            return;
        }

        $secret = $data['secret'] ?? env('MAINTENANCE_BYPASS_SECRET', '');

        // 2. Bypass: Query parameter secret token
        if (!empty($secret) && isset($_GET['bypass']) && hash_equals((string)$secret, (string)$_GET['bypass'])) {
            // Set cookie for 2 hours so operator can browse during maintenance
            @setcookie('sp_maintenance_bypass', $secret, [
                'expires' => time() + 7200,
                'path' => '/',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            return;
        }

        // 3. Bypass: Cookie verification
        if (!empty($secret) && !empty($_COOKIE['sp_maintenance_bypass']) && hash_equals((string)$secret, (string)$_COOKIE['sp_maintenance_bypass'])) {
            return;
        }

        // 4. Bypass: Allowed IP addresses
        $clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
        $allowedIps = $data['allowed_ips'] ?? [];
        if (in_array($clientIp, $allowedIps, true)) {
            return;
        }

        // 5. Bypass: Active Platform SuperAdmin session
        try {
            if (class_exists(PlatformAuth::class) && PlatformAuth::check()) {
                return;
            }
            if (!empty($_SESSION['is_superadmin']) || (!empty($_SESSION['role']) && $_SESSION['role'] === 'superadmin')) {
                return;
            }
        } catch (Throwable $e) {
            // Fallthrough to maintenance block
        }

        // Not bypassed: Enforce 503 Service Unavailable
        $retryAfter = (int) ($data['retry'] ?? 300);
        http_response_code(503);
        header('Retry-After: ' . $retryAfter);

        $isJsonExpected = (
            (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) ||
            (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json')) ||
            (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            str_contains($path, '/api/')
        );

        if ($isJsonExpected) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'status' => 503,
                'error' => [
                    'code' => 'MAINTENANCE_MODE',
                    'message' => $data['message'] ?? 'The platform is currently undergoing scheduled maintenance. Please check back shortly.',
                ],
                'retry_after' => $retryAfter,
                'started_at' => $data['started_at'] ?? date('c'),
            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            exit;
        }

        // Render full 503 HTML view
        $viewFile = dirname(__DIR__) . '/Views/errors/503.php';
        if (file_exists($viewFile)) {
            $message = $data['message'] ?? null;
            $retry = $retryAfter;
            $started_at = $data['started_at'] ?? null;
            require $viewFile;
            exit;
        }

        echo "<h1>503 Service Unavailable</h1><p>Scheduled Maintenance in Progress.</p>";
        exit;
    }
}
