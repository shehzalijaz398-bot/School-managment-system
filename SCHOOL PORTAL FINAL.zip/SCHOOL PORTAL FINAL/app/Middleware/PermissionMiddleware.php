<?php

declare(strict_types=1);

namespace App\Middleware;

final class PermissionMiddleware
{
    public function __construct(private string $permission)
    {
    }

    public function handle(): void
    {
        requirePermission($this->permission);
    }
}
