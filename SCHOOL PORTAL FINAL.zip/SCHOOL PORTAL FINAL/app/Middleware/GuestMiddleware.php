<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Auth;

final class GuestMiddleware
{
    public function handle(): void
    {
        if (\Core\PlatformAuth::check()) {
            redirect(url('superadmin/dashboard'));
        }
        if (Auth::check()) {
            redirect(url('dashboard'));
        }
    }
}
