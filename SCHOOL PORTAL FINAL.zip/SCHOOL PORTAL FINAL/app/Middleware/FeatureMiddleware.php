<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Services\Platform\FeatureAccessService;

final class FeatureMiddleware
{
    public function __construct(private string $feature)
    {
    }

    public function handle(): void
    {
        FeatureAccessService::requireFeature($this->feature);
    }
}
