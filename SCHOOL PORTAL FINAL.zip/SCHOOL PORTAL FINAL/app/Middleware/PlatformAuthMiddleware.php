<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\PlatformAuth;

final class PlatformAuthMiddleware
{
    public function handle(): void
    {
        if (\Core\Auth::check() && !\Core\PlatformAuth::check()) {
            http_response_code(403);
            flash('error', 'Access Denied: School Admin accounts are strictly prohibited from accessing the SaaS Super Admin Control Panel.');
            redirect(url('dashboard'));
            return;
        }
        PlatformAuth::requireLogin();
    }
}
