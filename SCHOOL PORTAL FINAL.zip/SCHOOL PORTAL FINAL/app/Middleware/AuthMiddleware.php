<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Auth;
use Core\TenantContext;

final class AuthMiddleware
{
    public function handle(): void
    {
        Auth::requireLogin();

        // Allow subscription management and logout even if tenant is currently inactive/expired
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
        if (str_contains($uri, '/subscription') || str_contains($uri, '/logout')) {
            return;
        }

        // Block inactive tenants (except when viewing is already handled)
        if (!TenantContext::isOperational()) {
            TenantContext::requireActiveTenant();
        }
    }
}
