<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Auth;
use Core\PlatformAuth;

/**
 * SuperAdminMiddleware
 * 
 * Enforces strict role and privilege separation:
 * - Only verified platform administrators (platform_users with role 'super_admin' or platform permissions)
 *   are allowed access to SaaS control plane routes.
 * - Authenticated School Admin users attempting to access /superadmin/* routes are strictly denied.
 * - Unauthenticated visitors are redirected to the platform login.
 */
final class SuperAdminMiddleware
{
    public function handle(): void
    {
        // 1. Detect if a School user is attempting cross-tenant / platform privilege escalation
        if (Auth::check() && !PlatformAuth::check()) {
            http_response_code(403);
            flash('error', 'Access Denied: School Admin accounts are strictly prohibited from accessing the SaaS Super Admin Control Panel.');
            redirect(url('dashboard'));
            return;
        }

        // 2. Ensure the user is logged into the platform console
        if (!PlatformAuth::check()) {
            flash('error', 'Please log in with verified platform administrator credentials.');
            redirect(url('superadmin/login'));
            return;
        }

        // 3. Verify that the platform user has super_admin role or global permissions
        $user = PlatformAuth::user();
        $roleSlug = $user['role_slug'] ?? '';
        if ($roleSlug !== 'super_admin' && !PlatformAuth::hasPermission('platform.dashboard')) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden - Super Admin Required']);
            exit;
        }
    }
}
