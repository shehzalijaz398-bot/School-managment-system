<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Auth;
use Core\PlatformAuth;

/**
 * AiAuthMiddleware
 *
 * Verifies that the incoming request is from an authenticated user
 * in either a school tenant (Auth) or the SaaS platform admin portal (PlatformAuth).
 * Responds with standard 401 JSON for API requests.
 */
final class AiAuthMiddleware
{
    public function handle(): void
    {
        // 1. Standard School Tenant User
        if (Auth::check() && Auth::schoolId()) {
            return;
        }

        // 2. Platform Super Admin User
        if (class_exists(PlatformAuth::class) && PlatformAuth::check()) {
            return;
        }

        // Unauthenticated - Return JSON 401 for API requests
        if (is_json_request() || str_starts_with($_SERVER['REQUEST_URI'] ?? '', '/api/')) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'status' => 401,
                'error' => 'Authentication required. Please refresh or log in again.',
            ]);
            exit;
        }

        redirect(url('login'));
    }
}
