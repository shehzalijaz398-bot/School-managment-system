<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\PlatformAuth;

final class PlatformGuestMiddleware
{
    public function handle(): void
    {
        if (PlatformAuth::check()) {
            redirect(url('superadmin/dashboard'));
        }
    }
}
