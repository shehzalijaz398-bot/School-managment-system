<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Auth;
use Core\Exceptions\TenantSecurityException;
use Core\TenantContext;

/**
 * TenantBoundaryMiddleware
 * Guarantees that any request entering authenticated routes cannot bypass or spoof
 * the tenant isolation perimeter.
 */
final class TenantBoundaryMiddleware
{
    public function handle(): void
    {
        Auth::requireLogin();

        $activeSchoolId = TenantContext::schoolId() ?? Auth::schoolId();
        if (!$activeSchoolId || $activeSchoolId <= 0) {
            http_response_code(403);
            view('tenant/inactive', [
                'title' => 'Tenant Context Missing',
                'message' => 'No active school tenant context could be resolved for this session.'
            ], 'layouts/guest');
            exit;
        }

        // Verify that the tenant is active and operational in the system
        if (!TenantContext::isOperational()) {
            TenantContext::requireActiveTenant();
        }
    }
}
