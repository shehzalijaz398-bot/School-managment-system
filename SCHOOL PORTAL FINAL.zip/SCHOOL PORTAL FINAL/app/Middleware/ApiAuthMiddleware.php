<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\ApiContext;
use Core\Database;
use Core\Security\JwtService;

final class ApiAuthMiddleware
{
    /**
     * Handle incoming API request authentication via Bearer Token or API Key.
     */
    public function handle(?string $requiredRole = null): void
    {
        $apiKey = $this->extractApiKey();
        $token = $this->extractBearerToken();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        // 1. Authenticate via Tenant API Key (if provided)
        if ($apiKey) {
            $integrationService = new \App\Services\IntegrationService();
            $authData = $integrationService->authenticateApiKey($apiKey, $requiredRole ?? '');
            if (!$authData) {
                $this->unauthorized('Invalid, revoked, or unauthorized API Key.');
            }

            $tenantId = (int)$authData['school_id'];
            $keyId = (int)$authData['key_id'];

            // Rate Limit Verification
            $rateLimit = (int)($authData['rate_limit_per_minute'] ?? 60);
            $rateStatus = $integrationService->checkRateLimit($tenantId, $keyId, $ip, $rateLimit);

            if (!$rateStatus['allowed']) {
                $this->tooManyRequests($rateStatus['reset_seconds']);
            }

            // Log request for rate limiting & telemetry
            $integrationService->logApiRequest($tenantId, $keyId, $_SERVER['REQUEST_URI'] ?? '/api', $_SERVER['REQUEST_METHOD'] ?? 'GET', $ip, 200, 0.0);

            // Populate Claims
            $claims = [
                'sub' => $authData['name'],
                'user_id' => 0,
                'tenant_id' => $tenantId,
                'school_id' => $tenantId,
                'role' => 'api_service',
                'scopes' => $authData['scopes']
            ];
            ApiContext::setClaims($claims);
            return;
        }

        // 2. Authenticate via JWT Bearer Token
        if (!$token) {
            $this->unauthorized('Missing authentication credentials. Expected X-API-Key or Bearer <token>.');
        }

        $claims = JwtService::decode($token);
        if (!$claims || empty($claims['tenant_id'])) {
            $this->unauthorized('Invalid or expired authentication token.');
        }

        $tenantId = (int) $claims['tenant_id'];

        // Enforce Multi-Tenant Isolation & Operational Perimeter
        $school = Database::fetch(
            'SELECT id, status, subscription_status FROM schools WHERE id = ? AND deleted_at IS NULL LIMIT 1',
            [$tenantId]
        );

        if (!$school || (int) ($school['status'] ?? 0) !== 1) {
            $this->forbidden('School tenant is suspended, deleted, or does not exist.');
        }

        // Optional Role Gate
        if ($requiredRole !== null && ($claims['role'] ?? '') !== $requiredRole) {
            $this->forbidden("Access denied. Required role: {$requiredRole}");
        }

        // Rate Limit Verification for JWT users
        $integrationService = new \App\Services\IntegrationService();
        $rateStatus = $integrationService->checkRateLimit($tenantId, null, $ip, 120);
        if (!$rateStatus['allowed']) {
            $this->tooManyRequests($rateStatus['reset_seconds']);
        }
        $integrationService->logApiRequest($tenantId, null, $_SERVER['REQUEST_URI'] ?? '/api', $_SERVER['REQUEST_METHOD'] ?? 'GET', $ip, 200, 0.0);

        // Initialize Request-Scoped Api Context & Tenant Context
        ApiContext::setClaims($claims);
    }

    /**
     * Extract API Key from headers (X-API-Key or ApiKey in Authorization)
     */
    private function extractApiKey(): ?string
    {
        if (!empty($_SERVER['HTTP_X_API_KEY'])) {
            return trim($_SERVER['HTTP_X_API_KEY']);
        }

        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (!empty($headers['X-API-Key'])) {
                return trim($headers['X-API-Key']);
            }
            if (!empty($headers['x-api-key'])) {
                return trim($headers['x-api-key']);
            }
        }

        return null;
    }

    /**
     * Extract token across various Apache/Nginx server header environments
     */
    private function extractBearerToken(): ?string
    {
        $header = null;

        if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['HTTP_AUTHORIZATION'];
        } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        } elseif (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            $header = $headers['Authorization'] ?? $headers['authorization'] ?? null;
        }

        if ($header && preg_match('/Bearer\s+(\S+)/i', $header, $matches)) {
            return $matches[1];
        }

        return null;
    }

    private function unauthorized(string $message): void
    {
        if (!headers_sent()) {
            http_response_code(401);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode([
            'success' => false,
            'status' => 401,
            'error' => [
                'code' => 'UNAUTHORIZED',
                'message' => $message,
            ],
            'meta' => [
                'timestamp' => date('c'),
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    private function forbidden(string $message): void
    {
        if (!headers_sent()) {
            http_response_code(403);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode([
            'success' => false,
            'status' => 403,
            'error' => [
                'code' => 'FORBIDDEN',
                'message' => $message,
            ],
            'meta' => [
                'timestamp' => date('c'),
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    private function tooManyRequests(int $retryAfter = 60): void
    {
        if (!headers_sent()) {
            http_response_code(429);
            header('Content-Type: application/json; charset=UTF-8');
            header('Retry-After: ' . $retryAfter);
            header('X-RateLimit-Reset: ' . $retryAfter);
        }
        echo json_encode([
            'success' => false,
            'status' => 429,
            'error' => [
                'code' => 'RATE_LIMIT_EXCEEDED',
                'message' => "Too many requests. Rate limit exceeded. Please retry after {$retryAfter} seconds.",
            ],
            'meta' => [
                'retry_after_seconds' => $retryAfter,
                'timestamp' => date('c'),
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
}

