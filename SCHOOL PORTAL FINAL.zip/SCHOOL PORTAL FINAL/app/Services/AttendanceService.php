<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;
use Core\TenantGuard;

final class AttendanceService
{
    public function markStudentAttendance(int $classId, int $sectionId, string $date, array $statuses, int $markedBy, array $remarks = []): void
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for student attendance.');
        }

        if ($classId <= 0) {
            throw new \InvalidArgumentException('Valid class ID is required.');
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) {
            throw new \InvalidArgumentException('Invalid attendance date format. Must be YYYY-MM-DD.');
        }

        if ($markedBy <= 0) {
            throw new \InvalidArgumentException('Valid marker user ID is required.');
        }

        TenantGuard::enforce('classes', $classId, $schoolId);
        if ($sectionId > 0) {
            TenantGuard::enforce('sections', $sectionId, $schoolId);
        }

        $yearId = activeAcademicYearId();
        if (!$yearId) {
            throw new \RuntimeException('No active academic year found for tenant.');
        }

        Database::beginTransaction();
        try {
            foreach ($statuses as $studentId => $status) {
                $studentId = (int) $studentId;
                $status = (string) $status;
                $allowed = ['present', 'absent', 'late', 'leave', 'excused', 'half_day'];
                if (!in_array($status, $allowed, true)) {
                    continue;
                }

                $remark = trim((string) ($remarks[$studentId] ?? ''));

                if ($sectionId > 0) {
                    $student = Database::fetch(
                        'SELECT id, section_id FROM students WHERE id = ? AND school_id = ? AND class_id = ? AND section_id = ? AND status = "active" LIMIT 1',
                        [$studentId, $schoolId, $classId, $sectionId]
                    );
                } else {
                    $student = Database::fetch(
                        'SELECT id, section_id FROM students WHERE id = ? AND school_id = ? AND class_id = ? AND status = "active" LIMIT 1',
                        [$studentId, $schoolId, $classId]
                    );
                }
                if (!$student) {
                    continue;
                }
                $secVal = !empty($student['section_id']) ? (int) $student['section_id'] : ($sectionId > 0 ? $sectionId : null);
                if (!$secVal) {
                    $sec = Database::fetch('SELECT id FROM sections WHERE class_id = ? AND school_id = ? LIMIT 1', [$classId, $schoolId]);
                    if ($sec) {
                        $secVal = (int) $sec['id'];
                    } else {
                        $secVal = (int) Database::insert(
                            'INSERT INTO sections (school_id, class_id, name, capacity, status, created_at, updated_at) VALUES (?, ?, "A", 40, 1, NOW(), NOW())',
                            [$schoolId, $classId]
                        );
                    }
                    if (empty($student['section_id'])) {
                        Database::execute('UPDATE students SET section_id = ? WHERE id = ? AND school_id = ?', [$secVal, $studentId, $schoolId]);
                    }
                }
                $effectiveSectionId = $secVal;

                $existing = Database::fetch(
                    'SELECT id, status, remarks FROM student_attendance
                     WHERE school_id = ? AND student_id = ? AND attendance_date = ? AND class_id = ? LIMIT 1',
                    [$schoolId, $studentId, $date, $classId]
                );

                if ($existing) {
                    Database::execute(
                        'UPDATE student_attendance SET status = ?, remarks = ?, section_id = ?, updated_by = ?, updated_at = NOW()
                         WHERE id = ? AND school_id = ?',
                        [$status, $remark ?: null, $effectiveSectionId, $markedBy, (int) $existing['id'], $schoolId]
                    );
                    if ($existing['status'] !== $status) {
                        auditLog('attendance.update', 'attendance', 'student_attendance', (int) $existing['id'], ['status' => $existing['status']], ['status' => $status]);
                    }
                } else {
                    $id = Database::insert(
                        'INSERT INTO student_attendance
                        (school_id, academic_year_id, student_id, class_id, section_id, attendance_date, status, remarks, marked_by, marked_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $yearId, $studentId, $classId, $effectiveSectionId, $date, $status, $remark ?: null, $markedBy]
                    );
                    auditLog('attendance.create', 'attendance', 'student_attendance', $id, null, ['student_id' => $studentId, 'status' => $status, 'date' => $date]);
                }

                // Automated Absence Notification for Authorized Parents
                if ($status === 'absent' && (!$existing || $existing['status'] !== 'absent')) {
                    $this->dispatchAbsenceAlert($schoolId, $studentId, $classId, $date);
                }
            }
            Database::commit();
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    /**
     * Dispatch automated absence notification to authorized parent users.
     */
    public function dispatchAbsenceAlert(int $schoolId, int $studentId, int $classId, string $date): int
    {
        $parents = Database::fetchAll(
            'SELECT u.id AS user_id, s.first_name, s.last_name, c.name AS class_name
             FROM student_parents sp
             JOIN parents p ON p.id = sp.parent_id
             JOIN users u ON u.parent_id = p.id AND u.school_id = sp.school_id
             JOIN students s ON s.id = sp.student_id
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE sp.student_id = ? AND sp.school_id = ?',
            [$studentId, $schoolId]
        );

        $notified = 0;
        foreach ($parents as $p) {
            $studentName = trim($p['first_name'] . ' ' . $p['last_name']);
            $className = $p['class_name'] ?: 'Class';
            $title = "Attendance Alert: {$studentName} Absent";
            $msg = "Your child {$studentName} ({$className}) was marked absent on " . date('l, F j, Y', strtotime($date)) . ". Please contact the school office if this was unexpected.";

            // Prevent duplicate notification for same student on same day
            $dup = Database::fetch(
                'SELECT id FROM notifications WHERE school_id = ? AND user_id = ? AND type = "attendance.absent" AND entity_id = ? AND DATE(created_at) = CURDATE() LIMIT 1',
                [$schoolId, (int) $p['user_id'], $studentId]
            );
            if (!$dup) {
                Database::insert(
                    'INSERT INTO notifications (school_id, user_id, type, title, message, entity_type, entity_id, link, is_read, created_at)
                     VALUES (?, ?, "attendance.absent", ?, ?, "students", ?, "portal/attendance", 0, NOW())',
                    [$schoolId, (int) $p['user_id'], $title, $msg, $studentId]
                );
                $notified++;
            }
        }
        return $notified;
    }

    public function markStaffAttendance(string $date, array $statuses, int $markedBy, array $remarks = []): void
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for staff attendance.');
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) {
            throw new \InvalidArgumentException('Invalid attendance date format. Must be YYYY-MM-DD.');
        }

        if ($markedBy <= 0) {
            throw new \InvalidArgumentException('Valid marker user ID is required.');
        }

        $marker = Auth::user();
        $markerEmployeeId = $marker['employee_id'] ?? null;

        Database::beginTransaction();
        try {
            foreach ($statuses as $employeeId => $status) {
                $employeeId = (int) $employeeId;
                $status = (string) $status;
                $allowed = ['present', 'absent', 'late', 'half_day', 'leave', 'holiday'];
                if (!in_array($status, $allowed, true)) {
                    continue;
                }

                // Teachers/staff cannot mark their own attendance
                if ($markerEmployeeId && (int) $markerEmployeeId === $employeeId) {
                    throw new \RuntimeException('You cannot mark your own staff attendance.');
                }

                $emp = Database::fetch(
                    'SELECT id FROM employees WHERE id = ? AND school_id = ? AND status IN ("active", "on_leave") LIMIT 1',
                    [$employeeId, $schoolId]
                );
                if (!$emp) {
                    continue;
                }

                $remark = isset($remarks[$employeeId]) ? trim((string)$remarks[$employeeId]) : null;
                if ($remark === '') {
                    $remark = null;
                }

                $existing = Database::fetch(
                    'SELECT id, status FROM staff_attendance WHERE school_id = ? AND employee_id = ? AND attendance_date = ? LIMIT 1',
                    [$schoolId, $employeeId, $date]
                );

                if ($existing) {
                    Database::execute(
                        'UPDATE staff_attendance SET status = ?, remarks = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                        [$status, $remark, $markedBy, (int) $existing['id'], $schoolId]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO staff_attendance (school_id, employee_id, attendance_date, status, remarks, marked_by, marked_at)
                         VALUES (?, ?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $employeeId, $date, $status, $remark, $markedBy]
                    );
                }
            }
            Database::commit();
            auditLog('staff_attendance.mark', 'attendance', 'staff_attendance', null, null, ['date' => $date]);
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function todayStudentStats(): array
    {
        $schoolId = (int) Auth::schoolId();
        $rows = Database::fetchAll(
            'SELECT status, COUNT(*) AS c FROM student_attendance
             WHERE school_id = ? AND attendance_date = CURDATE() GROUP BY status',
            [$schoolId]
        );
        $stats = ['present' => 0, 'absent' => 0, 'late' => 0, 'leave' => 0, 'excused' => 0, 'total' => 0];
        foreach ($rows as $row) {
            $stats[$row['status']] = (int) $row['c'];
            $stats['total'] += (int) $row['c'];
        }
        return $stats;
    }

    public function todayStaffStats(): array
    {
        $schoolId = (int) Auth::schoolId();
        $rows = Database::fetchAll(
            'SELECT status, COUNT(*) AS c FROM staff_attendance
             WHERE school_id = ? AND attendance_date = CURDATE() GROUP BY status',
            [$schoolId]
        );
        $stats = ['present' => 0, 'absent' => 0, 'late' => 0, 'half_day' => 0, 'leave' => 0, 'holiday' => 0, 'total' => 0];
        foreach ($rows as $row) {
            $stats[$row['status']] = (int) $row['c'];
            $stats['total'] += (int) $row['c'];
        }
        return $stats;
    }

    public function studentPercentage(int $studentId, ?string $from = null, ?string $to = null): float
    {
        $schoolId = (int) Auth::schoolId();
        $sql = 'SELECT COUNT(*) AS total,
                       SUM(CASE WHEN status IN ("present","late","excused") THEN 1 ELSE 0 END) AS presentish
                FROM student_attendance WHERE school_id = ? AND student_id = ?';
        $params = [$schoolId, $studentId];
        if ($from) {
            $sql .= ' AND attendance_date >= ?';
            $params[] = $from;
        }
        if ($to) {
            $sql .= ' AND attendance_date <= ?';
            $params[] = $to;
        }
        $row = Database::fetch($sql, $params);
        $total = (int) ($row['total'] ?? 0);
        if ($total === 0) {
            return 0.0;
        }
        return round(((int) $row['presentish'] / $total) * 100, 2);
    }

    public function absentStaffToday(): array
    {
        return Database::fetchAll(
            'SELECT e.first_name, e.last_name, e.employee_code, sa.status
             FROM staff_attendance sa
             INNER JOIN employees e ON e.id = sa.employee_id
             WHERE sa.school_id = ? AND sa.attendance_date = CURDATE() AND sa.status IN ("absent","leave")
             ORDER BY e.first_name',
            [Auth::schoolId()]
        );
    }

    public function classReport(int $classId, int $sectionId, string $from, string $to): array
    {
        $schoolId = (int) Auth::schoolId();
        if (empty($from)) {
            $from = date('Y-m-01');
        }
        if (empty($to)) {
            $to = date('Y-m-d');
        }
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }

        $sql = 'SELECT sa.attendance_date, sa.status, CONCAT(st.first_name, " ", st.last_name) AS student_name, st.roll_no
             FROM student_attendance sa
             INNER JOIN students st ON st.id = sa.student_id
             WHERE sa.school_id = ? AND sa.class_id = ?';
        $params = [$schoolId, $classId];

        if ($sectionId > 0) {
            $sql .= ' AND sa.section_id = ?';
            $params[] = $sectionId;
        }

        $sql .= ' AND sa.attendance_date BETWEEN ? AND ? ORDER BY sa.attendance_date, st.roll_no';
        $params[] = $from;
        $params[] = $to;

        return Database::fetchAll($sql, $params);
    }
}
