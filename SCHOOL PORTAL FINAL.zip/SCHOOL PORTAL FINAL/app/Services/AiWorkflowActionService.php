<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;
use Throwable;

/**
 * AiWorkflowActionService
 *
 * Handles intelligent administrative workflow execution proposed by the AI Assistant:
 * - Detects actionable, consequential user intents (fee reminders, automated billing, missing attendance reminders, timetable conflict audits)
 * - Verifies user role authorization
 * - Provides live database preview statistics
 * - Enforces mandatory explicit confirmation via cryptographic HMAC tokens
 * - Executes approved actions atomically with comprehensive security audit logging
 */
final class AiWorkflowActionService
{
    private const TOKEN_LIFETIME_SECONDS = 900; // 15 minutes

    /**
     * Detect if user query is requesting an automated consequential action.
     *
     * @param string $prompt User prompt
     * @param string $roleSlug Authenticated user role
     * @return array{action: string, params: array}|null
     */
    public function detectActionableIntent(string $prompt, string $roleSlug): ?array
    {
        $prompt = trim($prompt);
        if ($prompt === '') {
            return null;
        }

        // 1. Fee Reminders
        if (preg_match('/\b(send|dispatch|issue)\b.*\b(fee|payment|overdue)\s+(reminders?|notices?)\b/i', $prompt)
            || preg_match('/\b(remind|notify)\b.*\b(parents|defaulters|students)\b.*\b(fee|fees|overdue|unpaid|balance)\b/i', $prompt)
            || preg_match('/\b(send\s+reminders?\s+to\s+(overdue|unpaid)\s+parents?)\b/i', $prompt)) {
            if ($this->hasPermission('send_fee_reminders', $roleSlug)) {
                return ['action' => 'send_fee_reminders', 'params' => []];
            }
        }

        // 2. Generate Monthly / Recurring Invoices
        if (preg_match('/\b(generate|create|issue|run)\b.*\b(monthly|recurring)\s+(fee\s+)?invoices?\b/i', $prompt)
            || preg_match('/\b(generate|create)\b.*\binvoices?\b.*\b(this\s+month|active\s+students)\b/i', $prompt)) {
            if ($this->hasPermission('generate_monthly_invoices', $roleSlug)) {
                $month = date('Y-m');
                if (preg_match('/\b(202\d-[01]\d)\b/', $prompt, $mMatches)) {
                    $month = $mMatches[1];
                }
                return ['action' => 'generate_monthly_invoices', 'params' => ['billing_month' => $month]];
            }
        }

        // 3. Remind Unsubmitted Attendance
        if (preg_match('/\b(remind|notify|alert)\b.*\b(teachers?|faculty|staff)\b.*\b(attendance|unsubmitted|missing|mark)\b/i', $prompt)
            || preg_match('/\b(send|dispatch)\s+attendance\s+reminders?\b/i', $prompt)) {
            if ($this->hasPermission('remind_unsubmitted_attendance', $roleSlug)) {
                return ['action' => 'remind_unsubmitted_attendance', 'params' => []];
            }
        }

        // 4. Timetable Conflict Scan & Resolution Audit
        if (preg_match('/\b(scan|check|detect|audit|verify|find)\b.*\b(timetable|schedule)\b.*\b(conflicts?|clashes?|double[ -]?bookings?)\b/i', $prompt)
            || preg_match('/\b(run|execute)\b.*\btimetable\s+conflict\b/i', $prompt)) {
            if ($this->hasPermission('run_timetable_conflict_audit', $roleSlug)) {
                return ['action' => 'run_timetable_conflict_audit', 'params' => []];
            }
        }

        // 5. Daily Scheduled Routine Automations
        if (preg_match('/\b(run|trigger|execute|start)\b.*\b(daily|routine|scheduled)?\s*(automations?|scheduled tasks?|routine jobs?|daily jobs?)\b/i', $prompt)) {
            if ($this->hasPermission('run_daily_automation', $roleSlug)) {
                return ['action' => 'run_daily_automation', 'params' => []];
            }
        }

        return null;
    }

    /**
     * Check if a given role slug is permitted to initiate this consequential action.
     */
    public function hasPermission(string $action, string $roleSlug): bool
    {
        $permissions = [
            'send_fee_reminders' => ['admin', 'school_admin', 'owner', 'administrator', 'super_admin', 'superadmin', 'platform_super_admin', 'principal', 'accountant', 'finance'],
            'generate_monthly_invoices' => ['admin', 'school_admin', 'owner', 'administrator', 'super_admin', 'superadmin', 'platform_super_admin', 'principal', 'accountant'],
            'remind_unsubmitted_attendance' => ['admin', 'school_admin', 'owner', 'administrator', 'super_admin', 'superadmin', 'platform_super_admin', 'principal'],
            'run_timetable_conflict_audit' => ['admin', 'school_admin', 'owner', 'administrator', 'super_admin', 'superadmin', 'platform_super_admin', 'principal', 'teacher'],
            'run_daily_automation' => ['admin', 'school_admin', 'owner', 'administrator', 'super_admin', 'superadmin', 'platform_super_admin', 'principal'],
        ];

        return in_array($roleSlug, $permissions[$action] ?? [], true);
    }

    /**
     * Build an actionable proposal with live preview data and a signed confirmation token.
     */
    public function buildProposal(string $action, int $schoolId, int $userId, array $params = []): array
    {
        $preview = [];
        $summary = '';
        $actionTitle = '';

        switch ($action) {
            case 'send_fee_reminders':
                $actionTitle = 'Dispatch Overdue Fee Reminders';
                $overdueData = Database::fetch("
                    SELECT COUNT(*) AS invoice_count,
                           COUNT(DISTINCT student_id) AS student_count,
                           COALESCE(SUM(total_amount - paid_amount), 0.00) AS total_overdue
                    FROM student_fee_invoices
                    WHERE school_id = ? 
                      AND status IN ('unpaid', 'partially_paid', 'partial')
                      AND due_date < CURDATE()
                ", [$schoolId]);

                $invCount = (int)($overdueData['invoice_count'] ?? 0);
                $stCount = (int)($overdueData['student_count'] ?? 0);
                $totalAmt = (float)($overdueData['total_overdue'] ?? 0.0);

                $preview = [
                    'overdue_invoices_count' => $invCount,
                    'students_count' => $stCount,
                    'total_overdue_formatted' => formatMoney($totalAmt),
                ];
                $summary = "Dispatch automated fee reminder notifications to parents of {$stCount} student(s) with {$invCount} overdue invoice(s) totaling " . formatMoney($totalAmt) . ".";
                break;

            case 'generate_monthly_invoices':
                $actionTitle = 'Generate Monthly Recurring Invoices';
                $billingMonth = $params['billing_month'] ?? date('Y-m');

                // Active students count without invoice for this month
                $eligibleStudents = Database::fetch("
                    SELECT COUNT(*) AS count 
                    FROM students 
                    WHERE school_id = ? AND status = 'active'
                      AND id NOT IN (
                          SELECT student_id FROM student_fee_invoices 
                          WHERE school_id = ? AND DATE_FORMAT(invoice_date, '%Y-%m') = ?
                      )
                ", [$schoolId, $schoolId, $billingMonth]);

                $feeCategories = Database::fetch("
                    SELECT COUNT(*) AS cat_count, COALESCE(SUM(amount), 0.00) AS standard_total
                    FROM fee_categories
                    WHERE school_id = ? AND status = 1 AND frequency IN ('monthly', 'term')
                ", [$schoolId]);

                $stCount = (int)($eligibleStudents['count'] ?? 0);
                $stdRate = (float)($feeCategories['standard_total'] ?? 0.0);

                $preview = [
                    'billing_month' => $billingMonth,
                    'eligible_students_count' => $stCount,
                    'standard_monthly_rate' => formatMoney($stdRate),
                    'projected_billing' => formatMoney($stCount * $stdRate),
                ];
                $summary = "Generate {$stCount} recurring fee invoices for active students for {$billingMonth} (Standard rate: " . formatMoney($stdRate) . "/student, projected total: " . formatMoney($stCount * $stdRate) . ").";
                break;

            case 'remind_unsubmitted_attendance':
                $actionTitle = 'Send Unsubmitted Attendance Alerts';
                $today = date('Y-m-d');
                $unmarked = Database::fetchAll("
                    SELECT s.id, s.name AS section_name, c.name AS class_name,
                           CONCAT(COALESCE(e.first_name, ''), ' ', COALESCE(e.last_name, '')) AS teacher_name
                    FROM sections s
                    JOIN classes c ON c.id = s.class_id
                    LEFT JOIN teachers t ON t.id = s.class_teacher_id
                    LEFT JOIN employees e ON e.id = t.employee_id
                    WHERE s.school_id = ?
                      AND s.id NOT IN (
                          SELECT DISTINCT section_id FROM student_attendance 
                          WHERE school_id = ? AND attendance_date = ?
                      )
                ", [$schoolId, $schoolId, $today]);

                $unmarkedCount = count($unmarked);
                $preview = [
                    'unsubmitted_sections_count' => $unmarkedCount,
                    'sections' => array_slice($unmarked, 0, 5),
                ];
                $summary = "Dispatch urgent attendance submission reminders to teachers for {$unmarkedCount} section(s) with unrecorded attendance today.";
                break;

            case 'run_timetable_conflict_audit':
                $actionTitle = 'Scan & Audit Timetable Conflicts';
                $conflictService = new TimetableConflictService();
                $scan = $conflictService->detectConflicts($schoolId);
                $conflictsCount = (int) ($scan['total_conflicts'] ?? $scan['conflict_count'] ?? 0);

                $preview = [
                    'conflicts_count' => $conflictsCount,
                    'teacher_overlaps' => count($scan['teacher_conflicts'] ?? []),
                    'room_clashes' => count($scan['room_conflicts'] ?? []),
                    'section_collisions' => count($scan['section_conflicts'] ?? []),
                ];
                $summary = "Execute a full institutional timetable conflict scan. Found {$conflictsCount} potential scheduling clash(es).";
                break;

            case 'run_daily_automation':
                $actionTitle = 'Run Scheduled Institutional Automations';
                $preview = [
                    'attendance_summary' => 'Aggregate daily roll-call and flag unsubmitted registers',
                    'fee_reminders' => 'Dispatch reminders for invoices overdue by ≥ 3 days',
                    'rules_engine' => 'Execute all active school automation rules with cooldown protection',
                ];
                $summary = "Execute automated routine administrative jobs: aggregate daily attendance, evaluate overdue invoices, and trigger active school automation rules.";
                break;

            default:
                throw new \InvalidArgumentException("Unsupported actionable workflow: {$action}");
        }

        $token = $this->generateConfirmationToken($action, $schoolId, $userId, $params);

        $reply = "⚠️ **Consequential Administrative Action Proposed**\n\n"
            . "**Action:** {$actionTitle}\n"
            . "**Summary:** {$summary}\n\n"
            . "Please confirm this operation before it is applied to the database. "
            . "This action will execute atomically within a transaction and will be recorded in the institutional audit log.";

        return [
            'confirmation_required' => true,
            'action' => $action,
            'action_title' => $actionTitle,
            'summary' => $summary,
            'preview_data' => $preview,
            'confirmation_token' => $token,
            'expires_in_seconds' => self::TOKEN_LIFETIME_SECONDS,
            'reply' => $reply,
        ];
    }

    /**
     * Generate a cryptographically signed HMAC confirmation token.
     */
    public function generateConfirmationToken(string $action, int $schoolId, int $userId, array $params = []): string
    {
        $payload = [
            'action' => $action,
            'school_id' => $schoolId,
            'user_id' => $userId,
            'params' => $params,
            'expires_at' => time() + self::TOKEN_LIFETIME_SECONDS,
            'nonce' => bin2hex(random_bytes(8)),
        ];

        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        $encodedPayload = rtrim(strtr(base64_encode($json), '+/', '-_'), '=');
        $signature = hash_hmac('sha256', $encodedPayload, $this->getSigningKey());

        return $encodedPayload . '.' . $signature;
    }

    /**
     * Verify token signature and execute consequential action.
     */
    public function verifyAndExecute(string $token, int $schoolId, int $userId): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            return [
                'success' => false,
                'error' => 'Malformed confirmation token.',
            ];
        }

        [$encodedPayload, $signature] = $parts;
        $expectedSignature = hash_hmac('sha256', $encodedPayload, $this->getSigningKey());

        if (!hash_equals($expectedSignature, $signature)) {
            return [
                'success' => false,
                'error' => 'Invalid confirmation token signature.',
            ];
        }

        $json = base64_decode(strtr($encodedPayload, '-_', '+/'));
        $payload = json_decode($json, true);

        if (!is_array($payload)) {
            return [
                'success' => false,
                'error' => 'Invalid token payload data.',
            ];
        }

        if (($payload['expires_at'] ?? 0) < time()) {
            return [
                'success' => false,
                'error' => 'Confirmation token has expired. Please initiate the request again.',
            ];
        }

        if ((int)($payload['school_id'] ?? 0) !== $schoolId) {
            return [
                'success' => false,
                'error' => 'School tenant mismatch on confirmation token.',
            ];
        }

        if ((int)($payload['user_id'] ?? 0) !== $userId) {
            return [
                'success' => false,
                'error' => 'User identity mismatch on confirmation token.',
            ];
        }

        $action = (string)($payload['action'] ?? '');
        $params = is_array($payload['params'] ?? null) ? $payload['params'] : [];

        // Execute action
        return $this->executeAction($action, $schoolId, $userId, $params);
    }

    /**
     * Execute authorized action with transaction handling and audit logging.
     */
    private function executeAction(string $action, int $schoolId, int $userId, array $params): array
    {
        try {
            switch ($action) {
                case 'send_fee_reminders':
                    $billingService = new AutomatedBillingService();
                    $result = $billingService->dispatchOverdueFeeReminders($schoolId);

                    auditLog('ai.action.fee_reminders', [
                        'user_id' => $userId,
                        'school_id' => $schoolId,
                        'reminders_sent' => $result['reminders_sent'] ?? 0,
                        'total_overdue' => $result['total_overdue'] ?? 0,
                    ]);

                    return [
                        'success' => true,
                        'action' => $action,
                        'executed_at' => date('c'),
                        'message' => $result['message'],
                        'data' => $result,
                    ];

                case 'generate_monthly_invoices':
                    $billingMonth = $params['billing_month'] ?? date('Y-m');
                    $billingService = new AutomatedBillingService();
                    $result = $billingService->generateRecurringInvoices($schoolId, $billingMonth);

                    auditLog('ai.action.generate_invoices', [
                        'user_id' => $userId,
                        'school_id' => $schoolId,
                        'billing_month' => $billingMonth,
                        'invoices_created' => $result['invoices_created'] ?? 0,
                        'total_billed' => $result['total_billed'] ?? 0,
                    ]);

                    return [
                        'success' => true,
                        'action' => $action,
                        'executed_at' => date('c'),
                        'message' => $result['message'],
                        'data' => $result,
                    ];

                case 'remind_unsubmitted_attendance':
                    $today = date('Y-m-d');
                    $unmarked = Database::fetchAll("
                        SELECT s.id, s.name AS section_name, c.name AS class_name, e.id AS employee_id, u.id AS user_id,
                               CONCAT(COALESCE(e.first_name, ''), ' ', COALESCE(e.last_name, '')) AS teacher_name
                        FROM sections s
                        JOIN classes c ON c.id = s.class_id
                        LEFT JOIN teachers t ON t.id = s.class_teacher_id
                        LEFT JOIN employees e ON e.id = t.employee_id
                        LEFT JOIN users u ON u.employee_id = e.id AND u.school_id = s.school_id
                        WHERE s.school_id = ?
                          AND s.id NOT IN (
                              SELECT DISTINCT section_id FROM student_attendance 
                              WHERE school_id = ? AND attendance_date = ?
                          )
                    ", [$schoolId, $schoolId, $today]);

                    $sentCount = 0;
                    foreach ($unmarked as $row) {
                        $targetUserId = (int)($row['user_id'] ?? 0);
                        if ($targetUserId > 0) {
                            Database::insert("
                                INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                                VALUES (?, ?, 'attendance.reminder', 'Urgent: Daily Attendance Unsubmitted', ?, '/portal/attendance', 0, NOW())
                            ", [
                                $schoolId,
                                $targetUserId,
                                "Daily attendance has not been recorded for {$row['class_name']} - {$row['section_name']} today ({$today}). Please submit promptly.",
                            ]);
                            $sentCount++;
                        }
                    }

                    auditLog('ai.action.attendance_reminders', [
                        'user_id' => $userId,
                        'school_id' => $schoolId,
                        'unmarked_sections' => count($unmarked),
                        'notifications_sent' => $sentCount,
                    ]);

                    return [
                        'success' => true,
                        'action' => $action,
                        'executed_at' => date('c'),
                        'message' => "Dispatched {$sentCount} urgent attendance reminder(s) for " . count($unmarked) . " section(s).",
                        'data' => [
                            'unmarked_sections' => count($unmarked),
                            'reminders_sent' => $sentCount,
                        ],
                    ];

                case 'run_timetable_conflict_audit':
                    $conflictService = new TimetableConflictService();
                    $scan = $conflictService->detectConflicts($schoolId);
                    $conflictsFound = (int) ($scan['total_conflicts'] ?? $scan['conflict_count'] ?? 0);

                    auditLog('ai.action.timetable_conflict_audit', [
                        'user_id' => $userId,
                        'school_id' => $schoolId,
                        'conflicts_found' => $conflictsFound,
                    ]);

                    return [
                        'success' => true,
                        'action' => $action,
                        'executed_at' => date('c'),
                        'message' => "Timetable conflict audit completed: {$conflictsFound} conflict(s) detected.",
                        'data' => $scan,
                    ];

                case 'run_daily_automation':
                    $ruleEngine = new AutomationRuleEngine();
                    $ruleSummary = $ruleEngine->runScheduledAutomations($schoolId);

                    $attSummary = new AttendanceSummaryService();
                    $attResult = $attSummary->generateDailySummary($schoolId);

                    auditLog('ai.action.daily_automation', [
                        'user_id' => $userId,
                        'school_id' => $schoolId,
                        'rules_summary' => $ruleSummary,
                    ]);

                    return [
                        'success' => true,
                        'action' => $action,
                        'executed_at' => date('c'),
                        'message' => "Daily automations executed: {$ruleSummary['fee_reminders_sent']} fee reminder(s), {$ruleSummary['truancy_alerts_sent']} truancy alert(s), and attendance summary processed.",
                        'data' => [
                            'rules' => $ruleSummary,
                            'attendance' => $attResult,
                        ],
                    ];

                default:
                    return [
                        'success' => false,
                        'error' => "Unknown action: {$action}",
                    ];
            }
        } catch (Throwable $e) {
            if (class_exists(StructuredLogger::class)) {
                StructuredLogger::error("Failed executing AI action {$action}: " . $e->getMessage(), [
                    'school_id' => $schoolId,
                    'user_id' => $userId,
                    'exception' => $e,
                ]);
            }
            return [
                'success' => false,
                'error' => 'Execution failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Secret key for cryptographic HMAC token signing.
     */
    private function getSigningKey(): string
    {
        $key = $_ENV['APP_KEY'] ?? '';
        if ($key === '') {
            $key = 'codec-clove-enterprise-ai-action-key-2026';
        }
        return $key;
    }
}
