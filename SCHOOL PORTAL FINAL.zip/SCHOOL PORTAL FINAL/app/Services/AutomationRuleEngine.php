<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class AutomationRuleEngine
{
    public function __construct()
    {
        $this->ensureSchema();
    }

    private function ensureSchema(): void
    {
        Database::execute('CREATE TABLE IF NOT EXISTS automation_rules (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(191) NOT NULL,
            code VARCHAR(100) NOT NULL,
            category VARCHAR(50) NOT NULL DEFAULT "general",
            trigger_event VARCHAR(100) NOT NULL,
            description VARCHAR(255) NULL,
            conditions_json LONGTEXT NULL,
            action_type VARCHAR(100) NOT NULL,
            action_params_json LONGTEXT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            cooldown_hours INT UNSIGNED NOT NULL DEFAULT 24,
            execution_count INT UNSIGNED NOT NULL DEFAULT 0,
            last_executed_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_school_active (school_id, is_active),
            INDEX idx_trigger (school_id, trigger_event)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        Database::execute('CREATE TABLE IF NOT EXISTS automation_execution_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            rule_id BIGINT UNSIGNED NULL,
            rule_code VARCHAR(100) NOT NULL,
            trigger_event VARCHAR(100) NOT NULL,
            target_type VARCHAR(100) NOT NULL,
            target_id BIGINT UNSIGNED NOT NULL,
            status ENUM("success", "skipped", "failed") NOT NULL DEFAULT "success",
            action_taken VARCHAR(191) NOT NULL,
            details_json LONGTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_target_cooldown (school_id, rule_code, target_type, target_id, created_at),
            INDEX idx_rule_log (school_id, rule_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    /**
     * Seeds the standard enterprise automation rules for a school if none exist.
     */
    public function seedDefaultRules(int $schoolId): void
    {
        $count = Database::fetch('SELECT COUNT(*) AS total FROM automation_rules WHERE school_id = ?', [$schoolId]);
        if ((int) ($count['total'] ?? 0) > 0) {
            return;
        }

        $defaults = [
            [
                'name' => 'Automated Fee Overdue Notice',
                'code' => 'fee_overdue_notice',
                'category' => 'finance',
                'trigger_event' => 'fee.overdue_scan',
                'description' => 'Automatically dispatches in-app payment reminders to parents for invoices overdue by ≥ 3 days.',
                'conditions_json' => json_encode(['days_overdue_min' => 3]),
                'action_type' => 'notify_parent',
                'action_params_json' => json_encode(['title' => 'Fee Payment Reminder', 'type' => 'finance.overdue']),
                'is_active' => 1,
                'cooldown_hours' => 72, // Don't spam: once every 3 days max
            ],
            [
                'name' => 'Consecutive Absence Escalation Alert',
                'code' => 'attendance_consecutive_absence',
                'category' => 'attendance',
                'trigger_event' => 'attendance.consecutive_absent',
                'description' => 'Escalates an urgent alert to School Administration when a student has 3 or more consecutive unexcused absences.',
                'conditions_json' => json_encode(['consecutive_days' => 3]),
                'action_type' => 'notify_admin',
                'action_params_json' => json_encode(['title' => 'Student Truancy / Consecutive Absence Alert', 'type' => 'attendance.alert']),
                'is_active' => 1,
                'cooldown_hours' => 48,
            ],
            [
                'name' => 'Admission Verification Auto-Task',
                'code' => 'admission_verify_task',
                'category' => 'admissions',
                'trigger_event' => 'admission.submitted',
                'description' => 'Creates an admissions review task in the Approval Workflow queue upon receiving a completed application.',
                'conditions_json' => json_encode(['require_docs' => true]),
                'action_type' => 'create_workflow_task',
                'action_params_json' => json_encode(['workflow_category' => 'admission']),
                'is_active' => 1,
                'cooldown_hours' => 0,
            ],
            [
                'name' => 'Pending Leave 48h Escalation',
                'code' => 'leave_escalation_48h',
                'category' => 'hr',
                'trigger_event' => 'leave.pending_scan',
                'description' => 'Alerts the Head of Institution when staff leave requests remain unresolved for more than 48 hours.',
                'conditions_json' => json_encode(['pending_hours' => 48]),
                'action_type' => 'notify_admin',
                'action_params_json' => json_encode(['title' => 'Overdue Leave Approval Alert', 'type' => 'leave.escalation']),
                'is_active' => 1,
                'cooldown_hours' => 24,
            ],
            [
                'name' => 'Exam Results Publication Announcement',
                'code' => 'exam_publish_notice',
                'category' => 'academics',
                'trigger_event' => 'exam.published',
                'description' => 'Notifies enrolled students and parents immediately when examination results and grade sheets are published.',
                'conditions_json' => json_encode(['min_marks_entered' => 1]),
                'action_type' => 'notify_class_students',
                'action_params_json' => json_encode(['title' => 'Examination Report Cards Available', 'type' => 'academic.exam_result']),
                'is_active' => 1,
                'cooldown_hours' => 24,
            ],
            [
                'name' => 'Daily Unmarked Attendance Alert',
                'code' => 'attendance_daily_unmarked',
                'category' => 'attendance',
                'trigger_event' => 'attendance.daily_unmarked',
                'description' => 'Dispatches alerts to administration and class teachers when section attendance registers remain unsubmitted.',
                'conditions_json' => json_encode(['cutoff_hour' => 14]),
                'action_type' => 'notify_admin',
                'action_params_json' => json_encode(['title' => 'Unsubmitted Attendance Alert', 'type' => 'attendance.unsubmitted']),
                'is_active' => 1,
                'cooldown_hours' => 12,
            ],
            [
                'name' => 'Pending Admission Follow-up',
                'code' => 'admission_unverified_followup',
                'category' => 'admissions',
                'trigger_event' => 'admission.unverified_followup',
                'description' => 'Alerts admissions desk of submitted student applications awaiting review for over 3 days.',
                'conditions_json' => json_encode(['pending_days' => 3]),
                'action_type' => 'notify_admin',
                'action_params_json' => json_encode(['title' => 'Pending Admission Application Follow-up', 'type' => 'admission.followup']),
                'is_active' => 1,
                'cooldown_hours' => 24,
            ]
        ];

        foreach ($defaults as $r) {
            Database::insert(
                'INSERT INTO automation_rules (school_id, name, code, category, trigger_event, description, conditions_json, action_type, action_params_json, is_active, cooldown_hours, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                [
                    $schoolId,
                    $r['name'],
                    $r['code'],
                    $r['category'],
                    $r['trigger_event'],
                    $r['description'],
                    $r['conditions_json'],
                    $r['action_type'],
                    $r['action_params_json'],
                    $r['is_active'],
                    $r['cooldown_hours'],
                ]
            );
        }
    }

    /**
     * Lists all automation rules for a tenant.
     */
    public function getRules(int $schoolId): array
    {
        $this->seedDefaultRules($schoolId);
        return Database::fetchAll(
            'SELECT * FROM automation_rules WHERE school_id = ? ORDER BY category ASC, name ASC',
            [$schoolId]
        );
    }

    /**
     * Get a single rule by ID and school.
     */
    public function getRule(int $ruleId, int $schoolId): ?array
    {
        $row = Database::fetch(
            'SELECT * FROM automation_rules WHERE id = ? AND school_id = ? LIMIT 1',
            [$ruleId, $schoolId]
        );
        return $row ?: null;
    }

    /**
     * Create a custom automation rule.
     */
    public function createRule(int $schoolId, array $data): int
    {
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new \InvalidArgumentException('Rule name cannot be empty.');
        }

        $code = trim((string) ($data['code'] ?? ''));
        if ($code === '') {
            $code = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '_', $name) ?: 'custom_rule');
            $code .= '_' . substr(bin2hex(random_bytes(2)), 0, 4);
        }

        $category = trim((string) ($data['category'] ?? 'general'));
        $trigger = trim((string) ($data['trigger_event'] ?? 'manual'));
        $description = trim((string) ($data['description'] ?? ''));
        $actionType = trim((string) ($data['action_type'] ?? 'notify_admin'));
        $cooldown = max(0, (int) ($data['cooldown_hours'] ?? 24));
        $isActive = !empty($data['is_active']) ? 1 : 0;

        $conditionsJson = is_array($data['conditions'] ?? null)
            ? json_encode($data['conditions'], JSON_UNESCAPED_SLASHES)
            : (is_string($data['conditions_json'] ?? null) ? $data['conditions_json'] : '{}');

        $actionParamsJson = is_array($data['action_params'] ?? null)
            ? json_encode($data['action_params'], JSON_UNESCAPED_SLASHES)
            : (is_string($data['action_params_json'] ?? null) ? $data['action_params_json'] : '{}');

        $id = (int) Database::insert(
            'INSERT INTO automation_rules 
             (school_id, name, code, category, trigger_event, description, conditions_json, action_type, action_params_json, is_active, cooldown_hours, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $schoolId,
                $name,
                $code,
                $category,
                $trigger,
                $description,
                $conditionsJson,
                $actionType,
                $actionParamsJson,
                $isActive,
                $cooldown,
            ]
        );

        auditLog('automation.rule_create', 'automation_rules', 'rule', $id, null, [
            'name' => $name,
            'code' => $code,
            'trigger' => $trigger,
        ]);

        return $id;
    }

    /**
     * Update an existing automation rule.
     */
    public function updateRule(int $ruleId, int $schoolId, array $data): bool
    {
        $rule = $this->getRule($ruleId, $schoolId);
        if (!$rule) {
            throw new \RuntimeException('Automation rule not found.');
        }

        $name = trim((string) ($data['name'] ?? $rule['name']));
        $category = trim((string) ($data['category'] ?? $rule['category']));
        $trigger = trim((string) ($data['trigger_event'] ?? $rule['trigger_event']));
        $description = trim((string) ($data['description'] ?? $rule['description']));
        $actionType = trim((string) ($data['action_type'] ?? $rule['action_type']));
        $cooldown = isset($data['cooldown_hours']) ? max(0, (int) $data['cooldown_hours']) : (int) $rule['cooldown_hours'];
        $isActive = isset($data['is_active']) ? (!empty($data['is_active']) ? 1 : 0) : (int) $rule['is_active'];

        $conditionsJson = is_array($data['conditions'] ?? null)
            ? json_encode($data['conditions'], JSON_UNESCAPED_SLASHES)
            : (isset($data['conditions_json']) ? (string) $data['conditions_json'] : $rule['conditions_json']);

        $actionParamsJson = is_array($data['action_params'] ?? null)
            ? json_encode($data['action_params'], JSON_UNESCAPED_SLASHES)
            : (isset($data['action_params_json']) ? (string) $data['action_params_json'] : $rule['action_params_json']);

        Database::execute(
            'UPDATE automation_rules 
             SET name = ?, category = ?, trigger_event = ?, description = ?, conditions_json = ?, action_type = ?, action_params_json = ?, is_active = ?, cooldown_hours = ?, updated_at = NOW()
             WHERE id = ? AND school_id = ?',
            [
                $name,
                $category,
                $trigger,
                $description,
                $conditionsJson,
                $actionType,
                $actionParamsJson,
                $isActive,
                $cooldown,
                $ruleId,
                $schoolId,
            ]
        );

        auditLog('automation.rule_update', 'automation_rules', 'rule', $ruleId, null, [
            'name' => $name,
            'is_active' => $isActive,
        ]);

        return true;
    }

    /**
     * Delete an automation rule.
     */
    public function deleteRule(int $ruleId, int $schoolId): bool
    {
        $rule = $this->getRule($ruleId, $schoolId);
        if (!$rule) {
            return false;
        }

        Database::execute(
            'DELETE FROM automation_rules WHERE id = ? AND school_id = ?',
            [$ruleId, $schoolId]
        );

        auditLog('automation.rule_delete', 'automation_rules', 'rule', $ruleId, ['name' => $rule['name']], null);
        return true;
    }

    /**
     * Toggles rule state (active/inactive).
     */
    public function toggleRule(int $ruleId, int $schoolId, bool $isActive): bool
    {
        return Database::execute(
            'UPDATE automation_rules SET is_active = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$isActive ? 1 : 0, $ruleId, $schoolId]
        ) > 0;
    }

    /**
     * Checks if a target action was executed within cooldown window.
     */
    public function isWithinCooldown(int $schoolId, string $ruleCode, string $targetType, int $targetId, int $cooldownHours): bool
    {
        if ($cooldownHours <= 0) {
            return false;
        }

        $recent = Database::fetch(
            'SELECT id FROM automation_execution_logs
             WHERE school_id = ? AND rule_code = ? AND target_type = ? AND target_id = ?
               AND status = "success"
               AND created_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)
             LIMIT 1',
            [$schoolId, $ruleCode, $targetType, $targetId, $cooldownHours]
        );

        return !empty($recent);
    }

    /**
     * Executes the daily scheduled automations (Fee Overdues, Consecutive Absences, Pending Leaves).
     */
    public function runScheduledAutomations(int $schoolId): array
    {
        $this->seedDefaultRules($schoolId);
        $summary = [
            'school_id' => $schoolId,
            'fee_reminders_sent' => 0,
            'truancy_alerts_sent' => 0,
            'leave_escalations_sent' => 0,
            'total_actions' => 0,
            'timestamp' => date('Y-m-d H:i:s'),
        ];

        // 1. Fee Overdue Automation
        $feeRule = Database::fetch(
            'SELECT * FROM automation_rules WHERE school_id = ? AND code = "fee_overdue_notice" AND is_active = 1',
            [$schoolId]
        );
        if ($feeRule) {
            $overdueInvoices = Database::fetchAll(
                'SELECT i.id, i.invoice_no, i.student_id, i.total_amount, i.paid_amount, i.due_date,
                        s.first_name, s.last_name
                 FROM student_fee_invoices i
                 JOIN students s ON s.id = i.student_id
                 WHERE i.school_id = ? AND i.status IN ("unpaid", "partial")
                   AND i.due_date <= DATE_SUB(CURDATE(), INTERVAL 3 DAY)
                 ORDER BY i.due_date ASC LIMIT 50',
                [$schoolId]
            );

            foreach ($overdueInvoices as $inv) {
                $targetId = (int) $inv['id'];
                if ($this->isWithinCooldown($schoolId, $feeRule['code'], 'student_fee_invoices', $targetId, (int) $feeRule['cooldown_hours'])) {
                    continue;
                }

                // Locate parent users linked to student
                $parents = Database::fetchAll(
                    'SELECT u.id AS user_id FROM users u
                     JOIN student_parents sp ON sp.parent_id = u.parent_id
                     WHERE sp.student_id = ? AND sp.school_id = ?',
                    [(int) $inv['student_id'], $schoolId]
                );

                $due = number_format((float) $inv['total_amount'] - (float) $inv['paid_amount'], 2);
                $msg = "Overdue Fee Notice: Invoice #{$inv['invoice_no']} for {$inv['first_name']} {$inv['last_name']} has an outstanding balance of {$due} that was due on {$inv['due_date']}. Please clear dues promptly.";

                $notifiedCount = 0;
                foreach ($parents as $p) {
                    \App\Models\Notification::createNotification(
                        $schoolId,
                        (int) $p['user_id'],
                        'finance.overdue',
                        'Urgent: Fee Invoice Overdue',
                        $msg,
                        'student_fee_invoices',
                        $targetId,
                        url('finance/invoices')
                    );
                    $notifiedCount++;
                }

                Database::insert(
                    'INSERT INTO automation_execution_logs (school_id, rule_id, rule_code, trigger_event, target_type, target_id, status, action_taken, details_json, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, "success", ?, ?, NOW())',
                    [
                        $schoolId,
                        $feeRule['id'],
                        $feeRule['code'],
                        $feeRule['trigger_event'],
                        'student_fee_invoices',
                        $targetId,
                        "Dispatched in-app overdue notice to {$notifiedCount} parent account(s)",
                        json_encode(['invoice_no' => $inv['invoice_no'], 'due_amount' => $due, 'parents_notified' => $notifiedCount]),
                    ]
                );

                $summary['fee_reminders_sent']++;
                $summary['total_actions']++;
            }

            if ($summary['fee_reminders_sent'] > 0) {
                Database::execute(
                    'UPDATE automation_rules SET execution_count = execution_count + ?, last_executed_at = NOW() WHERE id = ?',
                    [$summary['fee_reminders_sent'], $feeRule['id']]
                );
            }
        }

        // 2. Truancy / Consecutive Absence Automation
        $truancyRule = Database::fetch(
            'SELECT * FROM automation_rules WHERE school_id = ? AND code = "attendance_consecutive_absence" AND is_active = 1',
            [$schoolId]
        );
        if ($truancyRule) {
            // Find students with absent records in recent days
            $absentStudents = Database::fetchAll(
                'SELECT s.id, s.first_name, s.last_name, s.roll_no, c.name AS class_name,
                        COUNT(sa.id) AS absent_streak
                 FROM students s
                 JOIN classes c ON c.id = s.class_id
                 JOIN student_attendance sa ON sa.student_id = s.id AND sa.status = "absent"
                 WHERE s.school_id = ? AND s.status = "active"
                   AND sa.attendance_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                 GROUP BY s.id
                 HAVING absent_streak >= 3',
                [$schoolId]
            );

            // Locate school admin users
            $admins = Database::fetchAll(
                'SELECT u.id AS user_id FROM users u
                 JOIN roles r ON r.id = u.role_id
                 WHERE u.school_id = ? AND r.slug IN ("admin", "super_admin", "principal")
                 LIMIT 5',
                [$schoolId]
            );

            foreach ($absentStudents as $stu) {
                $targetId = (int) $stu['id'];
                if ($this->isWithinCooldown($schoolId, $truancyRule['code'], 'students', $targetId, (int) $truancyRule['cooldown_hours'])) {
                    continue;
                }

                $msg = "Truancy Alert: {$stu['first_name']} {$stu['last_name']} ({$stu['class_name']}) has recorded {$stu['absent_streak']} absences in the past 7 days. Administrative review recommended.";

                foreach ($admins as $adm) {
                    \App\Models\Notification::createNotification(
                        $schoolId,
                        (int) $adm['user_id'],
                        'attendance.alert',
                        'Truancy Escalation: ' . $stu['first_name'] . ' ' . $stu['last_name'],
                        $msg,
                        'students',
                        $targetId,
                        url('students/' . $targetId)
                    );
                }

                Database::insert(
                    'INSERT INTO automation_execution_logs (school_id, rule_id, rule_code, trigger_event, target_type, target_id, status, action_taken, details_json, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, "success", ?, ?, NOW())',
                    [
                        $schoolId,
                        $truancyRule['id'],
                        $truancyRule['code'],
                        $truancyRule['trigger_event'],
                        'students',
                        $targetId,
                        "Escalated truancy alert for {$stu['first_name']} {$stu['last_name']} to admin team",
                        json_encode(['streak' => $stu['absent_streak'], 'class' => $stu['class_name']]),
                    ]
                );

                $summary['truancy_alerts_sent']++;
                $summary['total_actions']++;
            }

            if ($summary['truancy_alerts_sent'] > 0) {
                Database::execute(
                    'UPDATE automation_rules SET execution_count = execution_count + ?, last_executed_at = NOW() WHERE id = ?',
                    [$summary['truancy_alerts_sent'], $truancyRule['id']]
                );
            }
        }

        // 3. Pending Leave 48h Escalation
        $leaveRule = Database::fetch(
            'SELECT * FROM automation_rules WHERE school_id = ? AND code = "leave_escalation_48h" AND is_active = 1',
            [$schoolId]
        );
        if ($leaveRule) {
            $staleLeaves = Database::fetchAll(
                'SELECT lr.id, lr.employee_id, lr.created_at, e.first_name, e.last_name, lt.name AS leave_type
                 FROM leave_requests lr
                 JOIN employees e ON e.id = lr.employee_id
                 LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                 WHERE lr.school_id = ? AND lr.status = "pending"
                   AND lr.created_at <= DATE_SUB(NOW(), INTERVAL 48 HOUR)',
                [$schoolId]
            );

            $admins = Database::fetchAll(
                'SELECT u.id AS user_id FROM users u
                 JOIN roles r ON r.id = u.role_id
                 WHERE u.school_id = ? AND r.slug IN ("admin", "super_admin", "principal")
                 LIMIT 5',
                [$schoolId]
            );

            foreach ($staleLeaves as $lv) {
                $targetId = (int) $lv['id'];
                if ($this->isWithinCooldown($schoolId, $leaveRule['code'], 'leave_requests', $targetId, (int) $leaveRule['cooldown_hours'])) {
                    continue;
                }

                $msg = "Overdue Leave Review: Leave request for {$lv['first_name']} {$lv['last_name']} ({$lv['leave_type']}) has been awaiting review for over 48 hours.";

                foreach ($admins as $adm) {
                    \App\Models\Notification::createNotification(
                        $schoolId,
                        (int) $adm['user_id'],
                        'leave.escalation',
                        'Action Required: Overdue Leave Review',
                        $msg,
                        'leave_requests',
                        $targetId,
                        url('leaves')
                    );
                }

                Database::insert(
                    'INSERT INTO automation_execution_logs (school_id, rule_id, rule_code, trigger_event, target_type, target_id, status, action_taken, details_json, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, "success", ?, ?, NOW())',
                    [
                        $schoolId,
                        $leaveRule['id'],
                        $leaveRule['code'],
                        $leaveRule['trigger_event'],
                        'leave_requests',
                        $targetId,
                        "Escalated 48h+ overdue leave request for {$lv['first_name']} {$lv['last_name']}",
                        json_encode(['leave_id' => $targetId, 'submitted_at' => $lv['created_at']]),
                    ]
                );

                $summary['leave_escalations_sent']++;
                $summary['total_actions']++;
            }

            if ($summary['leave_escalations_sent'] > 0) {
                Database::execute(
                    'UPDATE automation_rules SET execution_count = execution_count + ?, last_executed_at = NOW() WHERE id = ?',
                    [$summary['leave_escalations_sent'], $leaveRule['id']]
                );
            }
        }

        // 4. Daily Unmarked Attendance Check
        $unmarkedRule = Database::fetch(
            'SELECT * FROM automation_rules WHERE school_id = ? AND code = "attendance_daily_unmarked" AND is_active = 1',
            [$schoolId]
        );
        if ($unmarkedRule) {
            $unmarkedSections = Database::fetchAll(
                'SELECT sec.id, sec.name AS section_name, c.name AS class_name, e.first_name, e.last_name, e.id AS teacher_emp_id
                 FROM sections sec
                 JOIN classes c ON c.id = sec.class_id
                 LEFT JOIN teachers t ON t.id = sec.class_teacher_id
                 LEFT JOIN employees e ON e.id = t.employee_id
                 WHERE sec.school_id = ?
                   AND sec.id NOT IN (
                       SELECT DISTINCT section_id FROM student_attendance
                       WHERE school_id = ? AND attendance_date = CURDATE()
                   )
                 LIMIT 20',
                [$schoolId, $schoolId]
            );

            $admins = Database::fetchAll(
                'SELECT u.id AS user_id FROM users u
                 JOIN roles r ON r.id = u.role_id
                 WHERE u.school_id = ? AND r.slug IN ("admin", "super_admin", "principal")
                 LIMIT 5',
                [$schoolId]
            );

            $unmarkedCount = 0;
            foreach ($unmarkedSections as $sec) {
                $targetId = (int) $sec['id'];
                if ($this->isWithinCooldown($schoolId, $unmarkedRule['code'], 'sections', $targetId, (int) $unmarkedRule['cooldown_hours'])) {
                    continue;
                }

                $secTitle = "{$sec['class_name']} - {$sec['section_name']}";
                $teacherStr = !empty($sec['first_name']) ? " (Teacher: {$sec['first_name']} {$sec['last_name']})" : "";
                $msg = "Unsubmitted Register: Daily attendance has not yet been marked for {$secTitle}{$teacherStr}.";

                foreach ($admins as $adm) {
                    \App\Models\Notification::createNotification(
                        $schoolId,
                        (int) $adm['user_id'],
                        'attendance.unsubmitted',
                        'Attendance Not Submitted: ' . $secTitle,
                        $msg,
                        'sections',
                        $targetId,
                        url('attendance/students')
                    );
                }

                Database::insert(
                    'INSERT INTO automation_execution_logs (school_id, rule_id, rule_code, trigger_event, target_type, target_id, status, action_taken, details_json, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, "success", ?, ?, NOW())',
                    [
                        $schoolId,
                        $unmarkedRule['id'],
                        $unmarkedRule['code'],
                        $unmarkedRule['trigger_event'],
                        'sections',
                        $targetId,
                        "Dispatched unsubmitted attendance alert for {$secTitle}",
                        json_encode(['section' => $secTitle, 'teacher_id' => $sec['teacher_emp_id']]),
                    ]
                );

                $unmarkedCount++;
                $summary['total_actions']++;
            }

            if ($unmarkedCount > 0) {
                Database::execute(
                    'UPDATE automation_rules SET execution_count = execution_count + ?, last_executed_at = NOW() WHERE id = ?',
                    [$unmarkedCount, $unmarkedRule['id']]
                );
            }
        }

        // 5. Pending Admission Follow-up
        $admissionRule = Database::fetch(
            'SELECT * FROM automation_rules WHERE school_id = ? AND code = "admission_unverified_followup" AND is_active = 1',
            [$schoolId]
        );
        if ($admissionRule) {
            $pendingAdmissions = Database::fetchAll(
                'SELECT a.id, a.application_no, a.first_name, a.last_name, a.created_at, c.name AS class_name
                 FROM admissions a
                 LEFT JOIN classes c ON c.id = a.class_id
                 WHERE a.school_id = ? AND a.status IN ("pending", "submitted")
                   AND a.created_at <= DATE_SUB(NOW(), INTERVAL 3 DAY)
                 LIMIT 20',
                [$schoolId]
            );

            $admins = Database::fetchAll(
                'SELECT u.id AS user_id FROM users u
                 JOIN roles r ON r.id = u.role_id
                 WHERE u.school_id = ? AND r.slug IN ("admin", "super_admin", "principal")
                 LIMIT 5',
                [$schoolId]
            );

            $admissionAlerts = 0;
            foreach ($pendingAdmissions as $adm) {
                $targetId = (int) $adm['id'];
                if ($this->isWithinCooldown($schoolId, $admissionRule['code'], 'admissions', $targetId, (int) $admissionRule['cooldown_hours'])) {
                    continue;
                }

                $msg = "Pending Application: Admission request #{$adm['application_no']} for {$adm['first_name']} {$adm['last_name']} ({$adm['class_name']}) has been awaiting review for over 3 days.";

                foreach ($admins as $u) {
                    \App\Models\Notification::createNotification(
                        $schoolId,
                        (int) $u['user_id'],
                        'admission.followup',
                        'Admission Review Pending: ' . $adm['application_no'],
                        $msg,
                        'admissions',
                        $targetId,
                        url('admissions/' . $targetId)
                    );
                }

                Database::insert(
                    'INSERT INTO automation_execution_logs (school_id, rule_id, rule_code, trigger_event, target_type, target_id, status, action_taken, details_json, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, "success", ?, ?, NOW())',
                    [
                        $schoolId,
                        $admissionRule['id'],
                        $admissionRule['code'],
                        $admissionRule['trigger_event'],
                        'admissions',
                        $targetId,
                        "Dispatched pending admission review reminder for #{$adm['application_no']}",
                        json_encode(['application_no' => $adm['application_no'], 'submitted_at' => $adm['created_at']]),
                    ]
                );

                $admissionAlerts++;
                $summary['total_actions']++;
            }

            if ($admissionAlerts > 0) {
                Database::execute(
                    'UPDATE automation_rules SET execution_count = execution_count + ?, last_executed_at = NOW() WHERE id = ?',
                    [$admissionAlerts, $admissionRule['id']]
                );
            }
        }

        return $summary;
    }

    /**
     * Preview execution impact for a saved rule.
     */
    public function previewRule(int $ruleId, int $schoolId): array
    {
        $rule = $this->getRule($ruleId, $schoolId);
        if (!$rule) {
            throw new \RuntimeException('Rule not found for preview.');
        }

        return $this->previewConfig($schoolId, $rule);
    }

    /**
     * Dry-run preview engine: matches records without executing side-effects or dispatching alerts.
     */
    public function previewConfig(int $schoolId, array $rule): array
    {
        $trigger = (string) ($rule['trigger_event'] ?? '');
        $code = (string) ($rule['code'] ?? 'custom_rule');
        $cooldown = max(0, (int) ($rule['cooldown_hours'] ?? 24));
        $conditions = is_string($rule['conditions_json'] ?? null)
            ? json_decode($rule['conditions_json'], true) ?: []
            : (is_array($rule['conditions_json'] ?? null) ? $rule['conditions_json'] : []);

        $matchedRecords = [];
        $targetType = 'entities';

        switch ($trigger) {
            case 'fee.overdue_scan':
                $targetType = 'student_fee_invoices';
                $days = max(1, (int) ($conditions['days_overdue_min'] ?? 3));
                $rows = Database::fetchAll(
                    'SELECT i.id, i.invoice_no, i.total_amount, i.paid_amount, i.due_date,
                            s.first_name, s.last_name, DATEDIFF(CURDATE(), i.due_date) AS days_overdue
                     FROM student_fee_invoices i
                     JOIN students s ON s.id = i.student_id
                     WHERE i.school_id = ? AND i.status IN ("unpaid", "partial")
                       AND i.due_date <= DATE_SUB(CURDATE(), INTERVAL ? DAY)
                     ORDER BY i.due_date ASC LIMIT 50',
                    [$schoolId, $days]
                );
                foreach ($rows as $r) {
                    $due = (float) $r['total_amount'] - (float) $r['paid_amount'];
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Invoice #{$r['invoice_no']} ({$r['first_name']} {$r['last_name']})",
                        'detail' => "Due: " . number_format($due, 2) . " (Overdue {$r['days_overdue']} days)",
                    ];
                }
                break;

            case 'attendance.consecutive_absent':
                $targetType = 'students';
                $streak = max(1, (int) ($conditions['consecutive_days'] ?? 3));
                $rows = Database::fetchAll(
                    'SELECT s.id, s.first_name, s.last_name, s.roll_no, c.name AS class_name,
                            COUNT(sa.id) AS absent_streak
                     FROM students s
                     JOIN classes c ON c.id = s.class_id
                     JOIN student_attendance sa ON sa.student_id = s.id AND sa.status = "absent"
                     WHERE s.school_id = ? AND s.status = "active"
                       AND sa.attendance_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                     GROUP BY s.id
                     HAVING absent_streak >= ?
                     LIMIT 50',
                    [$schoolId, $streak]
                );
                foreach ($rows as $r) {
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Student: {$r['first_name']} {$r['last_name']} ({$r['class_name']})",
                        'detail' => "Recorded {$r['absent_streak']} absences in past 7 days",
                    ];
                }
                break;

            case 'attendance.daily_unmarked':
                $targetType = 'sections';
                $rows = Database::fetchAll(
                    'SELECT sec.id, sec.name AS section_name, c.name AS class_name
                     FROM sections sec
                     JOIN classes c ON c.id = sec.class_id
                     WHERE sec.school_id = ?
                       AND sec.id NOT IN (
                           SELECT DISTINCT section_id FROM student_attendance
                           WHERE school_id = ? AND attendance_date = CURDATE()
                       )
                     LIMIT 50',
                    [$schoolId, $schoolId]
                );
                foreach ($rows as $r) {
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Class Section: {$r['class_name']} - {$r['section_name']}",
                        'detail' => "No student attendance register logged today",
                    ];
                }
                break;

            case 'admission.unverified_followup':
            case 'admission.submitted':
                $targetType = 'admissions';
                $days = max(0, (int) ($conditions['pending_days'] ?? 3));
                $rows = Database::fetchAll(
                    'SELECT a.id, a.application_no, a.first_name, a.last_name, a.created_at, c.name AS class_name
                     FROM admissions a
                     LEFT JOIN classes c ON c.id = a.class_id
                     WHERE a.school_id = ? AND a.status IN ("pending", "submitted")
                       AND a.created_at <= DATE_SUB(NOW(), INTERVAL ? DAY)
                     LIMIT 50',
                    [$schoolId, $days]
                );
                foreach ($rows as $r) {
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Application #{$r['application_no']} ({$r['first_name']} {$r['last_name']})",
                        'detail' => "Applied for {$r['class_name']} on " . date('M j, Y', strtotime($r['created_at'])),
                    ];
                }
                break;

            case 'leave.pending_scan':
                $targetType = 'leave_requests';
                $hours = max(1, (int) ($conditions['pending_hours'] ?? 48));
                $rows = Database::fetchAll(
                    'SELECT lr.id, lr.created_at, e.first_name, e.last_name, lt.name AS leave_type
                     FROM leave_requests lr
                     JOIN employees e ON e.id = lr.employee_id
                     LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                     WHERE lr.school_id = ? AND lr.status = "pending"
                       AND lr.created_at <= DATE_SUB(NOW(), INTERVAL ? HOUR)
                     LIMIT 50',
                    [$schoolId, $hours]
                );
                foreach ($rows as $r) {
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Leave Request: {$r['first_name']} {$r['last_name']} ({$r['leave_type']})",
                        'detail' => "Pending review since " . date('M j, Y h:i A', strtotime($r['created_at'])),
                    ];
                }
                break;

            default:
                $rows = Database::fetchAll('SELECT id FROM students WHERE school_id = ? AND status = "active" LIMIT 5', [$schoolId]);
                foreach ($rows as $r) {
                    $matchedRecords[] = [
                        'id' => (int) $r['id'],
                        'title' => "Target Item #{$r['id']}",
                        'detail' => "Sample matched entity under trigger {$trigger}",
                    ];
                }
                break;
        }

        $totalMatched = count($matchedRecords);
        $cooldownExcluded = 0;
        $actionable = [];

        foreach ($matchedRecords as $item) {
            $inCooldown = $this->isWithinCooldown($schoolId, $code, $targetType, (int) $item['id'], $cooldown);
            if ($inCooldown) {
                $cooldownExcluded++;
            } else {
                $actionable[] = $item;
            }
        }

        return [
            'status' => 'preview_ready',
            'rule_name' => $rule['name'] ?? 'Custom Rule',
            'trigger_event' => $trigger,
            'target_type' => $targetType,
            'total_matched' => $totalMatched,
            'cooldown_excluded' => $cooldownExcluded,
            'actionable_count' => count($actionable),
            'sample_records' => array_slice($actionable, 0, 5),
            'cooldown_hours' => $cooldown,
            'timestamp' => date('Y-m-d H:i:s'),
        ];
    }

    /**
     * AI-Assisted Workflow Synthesizer: converts natural language instructions into a reviewable rule proposal.
     * Always requires explicit human review and authorization before activation.
     */
    public function suggestWorkflow(string $prompt): array
    {
        $p = strtolower(trim($prompt));

        $category = 'general';
        $trigger = 'attendance.consecutive_absent';
        $name = 'Smart Automated Workflow';
        $desc = 'Automated workflow rule synthesized from administrative instruction.';
        $conditions = [];
        $actionType = 'notify_admin';
        $actionParams = ['title' => 'Automation Alert', 'type' => 'general.alert'];
        $cooldown = 24;

        if (str_contains($p, 'fee') || str_contains($p, 'invoice') || str_contains($p, 'due') || str_contains($p, 'unpaid')) {
            $category = 'finance';
            $trigger = 'fee.overdue_scan';
            $days = 3;
            if (preg_match('/(\d+)\s*day/i', $p, $m)) {
                $days = max(1, (int) $m[1]);
            }
            $name = "Automated Overdue Fee Notice ({$days}d+ Overdue)";
            $desc = "Automatically alerts parents when student fee invoices exceed {$days} days past the scheduled due date.";
            $conditions = ['days_overdue_min' => $days];
            $actionType = 'notify_parent';
            $actionParams = [
                'title' => 'Fee Payment Reminder',
                'type' => 'finance.overdue',
                'channels' => ['in_app', 'email'],
            ];
            $cooldown = 72;
        } elseif (str_contains($p, 'absent') || str_contains($p, 'absence') || str_contains($p, 'truan') || str_contains($p, 'attendance')) {
            $category = 'attendance';
            if (str_contains($p, 'unmarked') || str_contains($p, 'register') || str_contains($p, 'unsubmitted') || str_contains($p, 'submit')) {
                $trigger = 'attendance.daily_unmarked';
                $name = "Daily Unsubmitted Attendance Warning";
                $desc = "Alerts administrative leads and class teachers if attendance has not been registered.";
                $conditions = ['cutoff_hour' => 14];
                $actionType = 'notify_admin';
                $actionParams = ['title' => 'Unsubmitted Register Warning', 'type' => 'attendance.unsubmitted'];
                $cooldown = 12;
            } else {
                $trigger = 'attendance.consecutive_absent';
                $streak = 3;
                if (preg_match('/(\d+)\s*(?:day|consecutive|time|absence)/i', $p, $m)) {
                    $streak = max(1, (int) $m[1]);
                }
                $name = "Consecutive Absence Alert ({$streak}+ Days)";
                $desc = "Flags truancy alerts to administrators when a student is marked absent {$streak} or more times in 7 days.";
                $conditions = ['consecutive_days' => $streak];
                $actionType = 'notify_admin';
                $actionParams = ['title' => 'Student Truancy Escalation', 'type' => 'attendance.alert'];
                $cooldown = 48;
            }
        } elseif (str_contains($p, 'admission') || str_contains($p, 'applicant') || str_contains($p, 'enroll')) {
            $category = 'admissions';
            $trigger = 'admission.unverified_followup';
            $days = 3;
            if (preg_match('/(\d+)\s*day/i', $p, $m)) {
                $days = max(1, (int) $m[1]);
            }
            $name = "Pending Admission Follow-up ({$days}d)";
            $desc = "Reminds admissions officers to review submitted applications that have been pending for {$days} or more days.";
            $conditions = ['pending_days' => $days];
            $actionType = 'notify_admin';
            $actionParams = ['title' => 'Admissions Queue Reminder', 'type' => 'admission.followup'];
            $cooldown = 24;
        } elseif (str_contains($p, 'leave') || str_contains($p, 'staff') || str_contains($p, 'employee')) {
            $category = 'hr';
            $trigger = 'leave.pending_scan';
            $hours = 48;
            if (preg_match('/(\d+)\s*hour/i', $p, $m)) {
                $hours = max(1, (int) $m[1]);
            } elseif (preg_match('/(\d+)\s*day/i', $p, $m)) {
                $hours = max(1, (int) $m[1]) * 24;
            }
            $name = "Pending Leave Escalation ({$hours}h)";
            $desc = "Escalates unresolved staff leave applications to the Principal after {$hours} hours.";
            $conditions = ['pending_hours' => $hours];
            $actionType = 'notify_admin';
            $actionParams = ['title' => 'Overdue Staff Leave Escalation', 'type' => 'leave.escalation'];
            $cooldown = 24;
        }

        $code = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '_', $name) ?: 'ai_workflow');
        $code .= '_' . substr(bin2hex(random_bytes(2)), 0, 4);

        return [
            'name' => $name,
            'code' => $code,
            'category' => $category,
            'trigger_event' => $trigger,
            'description' => $desc,
            'conditions' => $conditions,
            'action_type' => $actionType,
            'action_params' => $actionParams,
            'cooldown_hours' => $cooldown,
            'is_active' => 0, // Inactive by default; user must review and approve!
            'requires_review' => true,
            'preview_explanation' => "AI proposed configuration based on: \"{$prompt}\". Please review the trigger event, conditions, and notification recipients before activating.",
        ];
    }

    /**
     * Retrieves recent automation execution logs.
     */
    public function getExecutionLogs(int $schoolId, int $limit = 50): array
    {
        return Database::fetchAll(
            'SELECT l.*, r.name AS rule_name, r.category
             FROM automation_execution_logs l
             LEFT JOIN automation_rules r ON r.id = l.rule_id
             WHERE l.school_id = ?
             ORDER BY l.created_at DESC LIMIT ?',
            [$schoolId, $limit]
        );
    }

    /**
     * Metrics overview.
     */
    public function getMetrics(int $schoolId): array
    {
        $this->seedDefaultRules($schoolId);

        $rulesCount = Database::fetch(
            'SELECT COUNT(*) AS total,
                    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active_rules,
                    SUM(execution_count) AS total_executions
             FROM automation_rules WHERE school_id = ?',
            [$schoolId]
        );

        $recentLogs = Database::fetch(
            'SELECT COUNT(*) AS total_recent,
                    SUM(CASE WHEN status = "success" THEN 1 ELSE 0 END) AS successful_recent
             FROM automation_execution_logs
             WHERE school_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)',
            [$schoolId]
        );

        $tot = (int) ($recentLogs['total_recent'] ?? 0);
        $suc = (int) ($recentLogs['successful_recent'] ?? 0);
        $successRate = $tot > 0 ? round(($suc / $tot) * 100, 1) : 100.0;

        return [
            'total_rules' => (int) ($rulesCount['total'] ?? 0),
            'active_rules' => (int) ($rulesCount['active_rules'] ?? 0),
            'total_executions' => (int) ($rulesCount['total_executions'] ?? 0),
            'success_rate' => $successRate,
            'recent_30d_executions' => $tot,
        ];
    }
}
