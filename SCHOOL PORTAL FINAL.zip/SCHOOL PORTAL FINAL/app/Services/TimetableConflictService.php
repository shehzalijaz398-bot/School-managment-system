<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * TimetableConflictService
 *
 * Enterprise conflict detection and timetable validation engine:
 * - Detects teacher overlaps (same teacher in multiple sections during same period)
 * - Detects room/facility overlaps (same room double-booked)
 * - Detects section collisions (section scheduled with multiple subjects in same slot)
 * - Pre-save validation for interactive timetable schedulers
 */
final class TimetableConflictService
{
    /**
     * Run full institutional timetable conflict audit.
     *
     * @param int $schoolId Current tenant ID
     * @param int|null $academicYearId Optional academic session filter
     * @return array Structured conflict report
     */
    public function detectConflicts(int $schoolId, ?int $academicYearId = null): array
    {
        // 1. Detect Teacher Overlaps
        $teacherConflictsSql = "
            SELECT 
                t.day_of_week,
                t.period_id,
                t.teacher_id,
                CONCAT(COALESCE(e.first_name, ''), ' ', COALESCE(e.last_name, '')) AS teacher_name,
                tp.period_number,
                tp.name AS period_name,
                tp.start_time,
                tp.end_time,
                COUNT(*) AS conflict_count,
                GROUP_CONCAT(CONCAT(c.name, ' - ', s.name) SEPARATOR ' vs ') AS conflicting_classes
            FROM timetables t
            JOIN teachers tc ON tc.id = t.teacher_id
            JOIN employees e ON e.id = tc.employee_id
            JOIN timetable_periods tp ON tp.id = t.period_id
            JOIN classes c ON c.id = t.class_id
            JOIN sections s ON s.id = t.section_id
            WHERE t.school_id = ? AND t.status = 1
        ";
        $params = [$schoolId];
        if ($academicYearId !== null) {
            $teacherConflictsSql .= " AND t.academic_year_id = ?";
            $params[] = $academicYearId;
        }
        $teacherConflictsSql .= "
            GROUP BY t.day_of_week, t.period_id, t.teacher_id, teacher_name, tp.period_number, tp.name, tp.start_time, tp.end_time
            HAVING COUNT(*) > 1
        ";
        $teacherConflicts = Database::fetchAll($teacherConflictsSql, $params);

        // 2. Detect Room Overlaps
        $roomConflictsSql = "
            SELECT 
                t.day_of_week,
                t.period_id,
                t.room,
                tp.period_number,
                tp.name AS period_name,
                tp.start_time,
                tp.end_time,
                COUNT(*) AS conflict_count,
                GROUP_CONCAT(CONCAT(c.name, ' - ', s.name) SEPARATOR ' vs ') AS conflicting_classes
            FROM timetables t
            JOIN timetable_periods tp ON tp.id = t.period_id
            JOIN classes c ON c.id = t.class_id
            JOIN sections s ON s.id = t.section_id
            WHERE t.school_id = ? AND t.status = 1 AND t.room IS NOT NULL AND t.room != ''
        ";
        $params = [$schoolId];
        if ($academicYearId !== null) {
            $roomConflictsSql .= " AND t.academic_year_id = ?";
            $params[] = $academicYearId;
        }
        $roomConflictsSql .= "
            GROUP BY t.day_of_week, t.period_id, t.room, tp.period_number, tp.name, tp.start_time, tp.end_time
            HAVING COUNT(*) > 1
        ";
        $roomConflicts = Database::fetchAll($roomConflictsSql, $params);

        // 3. Detect Section Duplicate Slots
        $sectionConflictsSql = "
            SELECT 
                t.day_of_week,
                t.period_id,
                t.section_id,
                c.name AS class_name,
                s.name AS section_name,
                tp.period_number,
                tp.name AS period_name,
                COUNT(*) AS conflict_count,
                GROUP_CONCAT(sub.name SEPARATOR ' vs ') AS conflicting_subjects
            FROM timetables t
            JOIN classes c ON c.id = t.class_id
            JOIN sections s ON s.id = t.section_id
            JOIN subjects sub ON sub.id = t.subject_id
            JOIN timetable_periods tp ON tp.id = t.period_id
            WHERE t.school_id = ? AND t.status = 1
        ";
        $params = [$schoolId];
        if ($academicYearId !== null) {
            $sectionConflictsSql .= " AND t.academic_year_id = ?";
            $params[] = $academicYearId;
        }
        $sectionConflictsSql .= "
            GROUP BY t.day_of_week, t.period_id, t.section_id, c.name, s.name, tp.period_number, tp.name
            HAVING COUNT(*) > 1
        ";
        $sectionConflicts = Database::fetchAll($sectionConflictsSql, $params);

        $totalConflicts = count($teacherConflicts) + count($roomConflicts) + count($sectionConflicts);

        return [
            'status'            => $totalConflicts > 0 ? 'conflicts_detected' : 'conflict_free',
            'has_conflicts'     => $totalConflicts > 0,
            'total_conflicts'   => $totalConflicts,
            'teacher_conflicts' => $teacherConflicts,
            'room_conflicts'    => $roomConflicts,
            'section_conflicts' => $sectionConflicts,
            'checked_at'        => date('Y-m-d H:i:s'),
        ];
    }

    /**
     * Pre-save slot validation to prevent saving a conflicting schedule entry.
     */
    public function validatePeriodAssignment(
        int $schoolId,
        int $dayOfWeek,
        int $periodId,
        int $classId,
        int $sectionId,
        int $teacherId,
        ?string $room = null,
        ?int $ignoreId = null
    ): array {
        $errors = [];

        // Check Teacher Overlap
        $teacherCheckSql = "
            SELECT t.id, c.name AS class_name, s.name AS section_name
            FROM timetables t
            JOIN classes c ON c.id = t.class_id
            JOIN sections s ON s.id = t.section_id
            WHERE t.school_id = ? AND t.day_of_week = ? AND t.period_id = ? AND t.teacher_id = ? AND t.status = 1
        ";
        $params = [$schoolId, $dayOfWeek, $periodId, $teacherId];
        if ($ignoreId !== null) {
            $teacherCheckSql .= " AND t.id != ?";
            $params[] = $ignoreId;
        }
        $existingTeacher = Database::fetch($teacherCheckSql, $params);
        if ($existingTeacher) {
            $errors[] = "Teacher is already scheduled with {$existingTeacher['class_name']} ({$existingTeacher['section_name']}) in this period.";
        }

        // Check Room Overlap (if room specified)
        if (!empty($room)) {
            $roomCheckSql = "
                SELECT t.id, c.name AS class_name, s.name AS section_name
                FROM timetables t
                JOIN classes c ON c.id = t.class_id
                JOIN sections s ON s.id = t.section_id
                WHERE t.school_id = ? AND t.day_of_week = ? AND t.period_id = ? AND t.room = ? AND t.status = 1
            ";
            $params = [$schoolId, $dayOfWeek, $periodId, $room];
            if ($ignoreId !== null) {
                $roomCheckSql .= " AND t.id != ?";
                $params[] = $ignoreId;
            }
            $existingRoom = Database::fetch($roomCheckSql, $params);
            if ($existingRoom) {
                $errors[] = "Room '{$room}' is already allocated to {$existingRoom['class_name']} ({$existingRoom['section_name']}) in this period.";
            }
        }

        // Check Section Duplicate
        $sectionCheckSql = "
            SELECT t.id, sub.name AS subject_name
            FROM timetables t
            JOIN subjects sub ON sub.id = t.subject_id
            WHERE t.school_id = ? AND t.day_of_week = ? AND t.period_id = ? AND t.section_id = ? AND t.status = 1
        ";
        $params = [$schoolId, $dayOfWeek, $periodId, $sectionId];
        if ($ignoreId !== null) {
            $sectionCheckSql .= " AND t.id != ?";
            $params[] = $ignoreId;
        }
        $existingSection = Database::fetch($sectionCheckSql, $params);
        if ($existingSection) {
            $errors[] = "This section already has '{$existingSection['subject_name']}' assigned in this period.";
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors,
        ];
    }
}
