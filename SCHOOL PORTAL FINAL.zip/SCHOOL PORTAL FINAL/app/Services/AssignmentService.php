<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class AssignmentService
{
    public function create(int $teacherId, array $data): int
    {
        $schoolId = (int) (currentSchoolId() ?? Auth::schoolId() ?? 0);

        $ayId = activeAcademicYearId();
        if (!$ayId) {
            $ayRow = Database::fetch('SELECT id FROM academic_years WHERE school_id = ? ORDER BY is_active DESC, id DESC LIMIT 1', [$schoolId]);
            $ayId = $ayRow ? (int)$ayRow['id'] : 1;
        }

        $teacherIdVal = ($teacherId > 0) ? $teacherId : null;

        $id = Database::insert(
            'INSERT INTO assignments
            (school_id, teacher_id, class_id, section_id, subject_id, academic_year_id, title, description,
             assigned_date, due_date, max_marks, attachment, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $schoolId,
                $teacherIdVal,
                (int) $data['class_id'],
                (int) $data['section_id'],
                (int) $data['subject_id'],
                $ayId,
                trim((string)$data['title']),
                $data['description'] ?? null,
                $data['assigned_date'] ?? date('Y-m-d'),
                $data['due_date'],
                (float) ($data['max_marks'] ?? 100),
                $data['attachment'] ?? null,
                $data['status'] ?? 'published',
            ]
        );

        // Notify students & parents of this class/section
        $students = Database::fetchAll(
            'SELECT s.id, s.user_id FROM students s WHERE s.school_id = ? AND s.class_id = ? AND s.section_id = ? AND s.status = "active"',
            [$schoolId, (int) $data['class_id'], (int) $data['section_id']]
        );

        $subject = Database::fetch('SELECT name FROM subjects WHERE id = ?', [(int) $data['subject_id']]);
        $subName = $subject['name'] ?? 'Subject';

        foreach ($students as $st) {
            // Pre-seed pending submission record
            Database::insert(
                'INSERT INTO assignment_submissions (school_id, assignment_id, student_id, status, created_at, updated_at)
                 VALUES (?, ?, ?, "pending", NOW(), NOW())
                 ON DUPLICATE KEY UPDATE updated_at = NOW()',
                [$schoolId, $id, (int) $st['id']]
            );

            if (!empty($st['user_id'])) {
                notify_user(
                    $schoolId,
                    (int) $st['user_id'],
                    'assignment',
                    'New Homework Assigned',
                    "New assignment for {$subName}: {$data['title']}. Due date: {$data['due_date']}.",
                    'assignments',
                    $id,
                    'portal/assignments'
                );
            }
        }

        auditLog('assignment.create', 'assignments', 'assignments', $id);
        return $id;
    }

    public function createDailyDiary(int $teacherId, int $classId, int $sectionId, string $date, array $tasks): int
    {
        $schoolId = (int) (currentSchoolId() ?? Auth::schoolId() ?? 0);
        $ayId = activeAcademicYearId();
        if (!$ayId) {
            $ayRow = Database::fetch('SELECT id FROM academic_years WHERE school_id = ? ORDER BY is_active DESC, id DESC LIMIT 1', [$schoolId]);
            $ayId = $ayRow ? (int)$ayRow['id'] : 1;
        }

        $count = 0;
        foreach ($tasks as $subjectId => $description) {
            $desc = trim((string)$description);
            if ($desc === '') continue;

            $subject = Database::fetch('SELECT name FROM subjects WHERE id = ?', [(int) $subjectId]);
            $title = 'Daily Task: ' . ($subject['name'] ?? 'Subject');

            $teacherIdVal = ($teacherId > 0) ? $teacherId : null;

            $id = Database::insert(
                'INSERT INTO assignments
                (school_id, teacher_id, class_id, section_id, subject_id, academic_year_id, title, description,
                 assigned_date, due_date, max_marks, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, "published", NOW(), NOW())',
                [
                    $schoolId,
                    $teacherIdVal,
                    $classId,
                    $sectionId,
                    (int) $subjectId,
                    $ayId,
                    $title,
                    $desc,
                    $date,
                    date('Y-m-d', strtotime($date . ' +1 day')),
                ]
            );
            $count++;
        }

        // Notify students & parents of class
        if ($count > 0) {
            $students = Database::fetchAll(
                'SELECT s.id, s.user_id FROM students s WHERE s.school_id = ? AND s.class_id = ? AND s.section_id = ? AND s.status = "active"',
                [$schoolId, $classId, $sectionId]
            );
            foreach ($students as $st) {
                if (!empty($st['user_id'])) {
                    notify_user(
                        $schoolId,
                        (int) $st['user_id'],
                        'diary',
                        'Daily School Diary Updated',
                        "Daily homework tasks have been posted for {$date}.",
                        'assignments',
                        0,
                        'portal/assignments'
                    );
                }
            }
        }

        auditLog('assignment.daily_diary', 'assignments', 'assignments', null, null, ['class_id' => $classId, 'tasks' => $count]);
        return $count;
    }

    public function submitStudentWork(int $assignmentId, int $studentId, ?string $content, ?string $attachment): int
    {
        $schoolId = (int) (currentSchoolId() ?? Auth::schoolId() ?? 0);

        $assignment = Database::fetch(
            'SELECT * FROM assignments WHERE id = ? AND school_id = ? LIMIT 1',
            [$assignmentId, $schoolId]
        );
        if (!$assignment) {
            throw new \RuntimeException('Assignment not found.');
        }

        $now = date('Y-m-d');
        $isLate = ($now > $assignment['due_date']) ? 1 : 0;
        $status = $isLate ? 'late' : 'submitted';

        // Check if existing submission
        $existing = Database::fetch(
            'SELECT id FROM assignment_submissions WHERE assignment_id = ? AND student_id = ? AND school_id = ? LIMIT 1',
            [$assignmentId, $studentId, $schoolId]
        );

        if ($existing) {
            $subId = (int) $existing['id'];
            Database::execute(
                'UPDATE assignment_submissions 
                 SET submitted_at = NOW(), content = ?, attachment = COALESCE(?, attachment), status = ?, is_late = ?, updated_at = NOW()
                 WHERE id = ? AND school_id = ?',
                [$content, $attachment, $status, $isLate, $subId, $schoolId]
            );
        } else {
            $subId = Database::insert(
                'INSERT INTO assignment_submissions
                (school_id, assignment_id, student_id, submitted_at, content, attachment, status, is_late, created_at, updated_at)
                 VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, NOW(), NOW())',
                [$schoolId, $assignmentId, $studentId, $content, $attachment, $status, $isLate]
            );
        }

        // Notify teacher
        if (!empty($assignment['teacher_id'])) {
            $teacher = Database::fetch(
                'SELECT u.id FROM teachers t INNER JOIN employees e ON e.id = t.employee_id INNER JOIN users u ON u.employee_id = e.id WHERE t.id = ? LIMIT 1',
                [(int) $assignment['teacher_id']]
            );
            if ($teacher) {
                $student = Database::fetch('SELECT first_name, last_name FROM students WHERE id = ?', [$studentId]);
                $stName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
                notify_user(
                    $schoolId,
                    (int) $teacher['id'],
                    'assignment_submission',
                    'Homework Submitted',
                    "{$stName} submitted work for: {$assignment['title']}.",
                    'assignments',
                    $assignmentId,
                    'assignments/' . $assignmentId
                );
            }
        }

        auditLog('assignment.submit', 'assignments', 'assignment_submissions', $subId);
        return $subId;
    }

    public function grade(int $submissionId, float $marks, ?string $comment): void
    {
        $schoolId = (int) (currentSchoolId() ?? Auth::schoolId() ?? 0);
        $sub = Database::fetch(
            'SELECT sub.*, a.max_marks, a.due_date, a.title, st.user_id, st.first_name, st.last_name 
             FROM assignment_submissions sub
             INNER JOIN assignments a ON a.id = sub.assignment_id
             INNER JOIN students st ON st.id = sub.student_id
             WHERE sub.id = ? AND sub.school_id = ? LIMIT 1',
            [$submissionId, $schoolId]
        );
        if (!$sub) {
            throw new \RuntimeException('Submission not found.');
        }

        $max = (float) $sub['max_marks'];
        if ($max > 0 && ($marks < 0 || $marks > $max)) {
            throw new \RuntimeException("Marks out of range (0 to {$max}).");
        }

        Database::execute(
            'UPDATE assignment_submissions SET marks = ?, teacher_comment = ?, status = "graded", updated_at = NOW()
             WHERE id = ? AND school_id = ?',
            [$marks, $comment, $submissionId, $schoolId]
        );

        // Notify student
        if (!empty($sub['user_id'])) {
            notify_user(
                $schoolId,
                (int) $sub['user_id'],
                'assignment_graded',
                'Assignment Graded',
                "Your submission for '{$sub['title']}' has been graded: {$marks}/{$max}.",
                'assignments',
                (int) $sub['assignment_id'],
                'portal/assignments'
            );
        }

        // Notify parents
        $parents = Database::fetchAll(
            'SELECT u.id FROM users u
             INNER JOIN student_parents sp ON sp.parent_id = u.parent_id
             WHERE u.school_id = ? AND sp.student_id = ? AND u.status = 1',
            [$schoolId, (int) $sub['student_id']]
        );
        foreach ($parents as $p) {
            notify_user(
                $schoolId, 
                (int) $p['id'], 
                'assignment_graded', 
                'Child Assignment Graded', 
                "Assignment '{$sub['title']}' for {$sub['first_name']} has been graded ({$marks}/{$max}).", 
                'assignment_submission', 
                $submissionId, 
                'parent/assignments'
            );
        }

        auditLog('assignment.grade', 'assignments', 'assignment_submissions', $submissionId, null, ['marks' => $marks]);
    }
}
