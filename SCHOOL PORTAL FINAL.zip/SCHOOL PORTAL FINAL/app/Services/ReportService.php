<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class ReportService
{
    private function normalizeDateRange(string &$from, string &$to): void
    {
        if (empty($from)) {
            $from = date('Y-m-01');
        }
        if (empty($to)) {
            $to = date('Y-m-d');
        }
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }
    }

    public function feeCollection(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        return Database::fetchAll(
            'SELECT p.payment_date, p.receipt_no, p.amount, p.payment_method,
                    CONCAT(s.first_name," ",s.last_name) AS student_name, s.admission_no
             FROM payments p
             INNER JOIN students s ON s.id = p.student_id
             WHERE p.school_id = ? AND p.payment_date BETWEEN ? AND ?
             ORDER BY p.payment_date',
            [Auth::schoolId(), $from, $to]
        );
    }

    public function expenses(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        return Database::fetchAll(
            'SELECT * FROM expenses WHERE school_id = ? AND expense_date BETWEEN ? AND ? ORDER BY expense_date',
            [Auth::schoolId(), $from, $to]
        );
    }

    public function payroll(string $month): array
    {
        return (new \App\Models\PayrollModel())->listAll($month);
    }

    public function studentAttendance(string $from, string $to, ?int $classId = null): array
    {
        $this->normalizeDateRange($from, $to);
        $sql = 'SELECT sa.attendance_date, sa.status, CONCAT(st.first_name," ",st.last_name) AS student_name,
                       c.name AS class_name, sec.name AS section_name
                FROM student_attendance sa
                INNER JOIN students st ON st.id = sa.student_id
                INNER JOIN classes c ON c.id = sa.class_id
                LEFT JOIN sections sec ON sec.id = sa.section_id
                WHERE sa.school_id = ? AND sa.attendance_date BETWEEN ? AND ?';
        $params = [Auth::schoolId(), $from, $to];
        if ($classId) {
            $sql .= ' AND sa.class_id = ?';
            $params[] = $classId;
        }
        $sql .= ' ORDER BY sa.attendance_date, c.name';
        return Database::fetchAll($sql, $params);
    }

    public function staffAttendance(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        return Database::fetchAll(
            'SELECT sa.attendance_date, sa.status, sa.remarks, CONCAT(e.first_name, " ", e.last_name) AS employee_name
             FROM staff_attendance sa
             INNER JOIN employees e ON e.id = sa.employee_id
             WHERE sa.school_id = ? AND sa.attendance_date BETWEEN ? AND ?
             ORDER BY sa.attendance_date, employee_name',
            [Auth::schoolId(), $from, $to]
        );
    }

    public function leaves(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        return Database::fetchAll(
            'SELECT lr.start_date, lr.end_date, lr.days, lr.status, lr.reason, CONCAT(e.first_name, " ", e.last_name) AS employee_name, lt.name as leave_type
             FROM leave_requests lr
             INNER JOIN employees e ON e.id = lr.employee_id
             INNER JOIN leave_types lt ON lt.id = lr.leave_type_id
             WHERE lr.school_id = ? AND lr.created_at BETWEEN ? AND ?
             ORDER BY lr.created_at DESC',
            [Auth::schoolId(), $from . ' 00:00:00', $to . ' 23:59:59']
        );
    }

    public function students(?int $classId = null): array
    {
        $sql = 'SELECT s.admission_no, CONCAT(s.first_name, " ", s.last_name) AS student_name, s.gender, s.date_of_birth, c.name AS class_name, sec.name AS section_name
                FROM students s
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                WHERE s.school_id = ?';
        $params = [Auth::schoolId()];
        
        if ($classId) {
            $sql .= ' AND s.class_id = ?';
            $params[] = $classId;
        }
        $sql .= ' ORDER BY c.numeric_name, sec.name, student_name';
        
        return Database::fetchAll($sql, $params);
    }

    /**
     * Cross-module executive analytics summary for date range.
     *
     * @param string $from
     * @param string $to
     * @return array<string, mixed>
     */
    public function executiveSummary(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        $schoolId = (int) Auth::schoolId();

        // 1. Fee Collections
        $feeRow = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS total_collected, COUNT(id) AS payment_count
             FROM payments WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
            [$schoolId, $from, $to]
        );
        $feeCollected = (float) ($feeRow['total_collected'] ?? 0);
        $paymentCount = (int) ($feeRow['payment_count'] ?? 0);

        // 2. Expenses
        $expRow = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS total_expense, COUNT(id) AS expense_count
             FROM expenses WHERE school_id = ? AND expense_date BETWEEN ? AND ?',
            [$schoolId, $from, $to]
        );
        $expenseTotal = (float) ($expRow['total_expense'] ?? 0);
        $expenseCount = (int) ($expRow['expense_count'] ?? 0);

        // 3. Outstanding Unpaid Invoices
        $outRow = Database::fetch(
            'SELECT COALESCE(SUM(total_amount - paid_amount), 0) AS total_outstanding, COUNT(id) AS overdue_count
             FROM student_fee_invoices WHERE school_id = ? AND status IN ("unpaid", "partial")',
            [$schoolId]
        );
        $outstandingTotal = (float) ($outRow['total_outstanding'] ?? 0);
        $overdueCount = (int) ($outRow['overdue_count'] ?? 0);

        // 4. Student Attendance
        $sAttRows = Database::fetchAll(
            'SELECT status, COUNT(*) AS count FROM student_attendance
             WHERE school_id = ? AND attendance_date BETWEEN ? AND ? GROUP BY status',
            [$schoolId, $from, $to]
        );
        $sPresent = 0;
        $sTotal = 0;
        foreach ($sAttRows as $sa) {
            $c = (int) $sa['count'];
            $sTotal += $c;
            if ($sa['status'] === 'present' || $sa['status'] === 'late') {
                $sPresent += $c;
            }
        }
        $studentAttendanceRate = $sTotal > 0 ? round(($sPresent / $sTotal) * 100, 1) : 100.0;

        // 5. Staff Attendance
        $stAttRows = Database::fetchAll(
            'SELECT status, COUNT(*) AS count FROM staff_attendance
             WHERE school_id = ? AND attendance_date BETWEEN ? AND ? GROUP BY status',
            [$schoolId, $from, $to]
        );
        $stPresent = 0;
        $stTotal = 0;
        foreach ($stAttRows as $sta) {
            $c = (int) $sta['count'];
            $stTotal += $c;
            if ($sta['status'] === 'present' || $sta['status'] === 'late') {
                $stPresent += $c;
            }
        }
        $staffAttendanceRate = $stTotal > 0 ? round(($stPresent / $stTotal) * 100, 1) : 100.0;

        // 6. Enrollment & Faculty Counts
        $enrollRow = Database::fetch(
            'SELECT COUNT(*) AS active_students FROM students WHERE school_id = ? AND status = "active"',
            [$schoolId]
        );
        $staffRow = Database::fetch(
            'SELECT COUNT(*) AS active_staff FROM employees WHERE school_id = ? AND status = "active"',
            [$schoolId]
        );

        return [
            'from' => $from,
            'to' => $to,
            'fee_collected' => $feeCollected,
            'payment_count' => $paymentCount,
            'expenses_total' => $expenseTotal,
            'expense_count' => $expenseCount,
            'net_operating_balance' => round($feeCollected - $expenseTotal, 2),
            'outstanding_total' => $outstandingTotal,
            'overdue_invoices_count' => $overdueCount,
            'student_attendance_rate' => $studentAttendanceRate,
            'staff_attendance_rate' => $staffAttendanceRate,
            'active_students' => (int) ($enrollRow['active_students'] ?? 0),
            'active_staff' => (int) ($staffRow['active_staff'] ?? 0),
        ];
    }

    /**
     * Historical Trend Analysis with MoM Comparisons
     */
    public function analyticsTrends(?int $schoolId = null, int $months = 6): array
    {
        $schoolId = $schoolId ?? (int) Auth::schoolId();
        $monthlySeries = [];

        // Loop chronologically from ($months - 1) months ago up to current month
        for ($i = $months - 1; $i >= 0; $i--) {
            $monthStart = date('Y-m-01', strtotime("-{$i} month"));
            $monthEnd = date('Y-m-t', strtotime("-{$i} month"));
            $monthKey = date('M Y', strtotime("-{$i} month"));
            $shortKey = date('M', strtotime("-{$i} month"));

            // Fee Collections
            $rev = Database::fetch(
                'SELECT COALESCE(SUM(amount), 0) AS total_revenue, COUNT(id) AS tx_count
                 FROM payments WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
                [$schoolId, $monthStart, $monthEnd]
            );
            $revenue = (float) ($rev['total_revenue'] ?? 0);

            // Invoiced
            $inv = Database::fetch(
                'SELECT COALESCE(SUM(total_amount), 0) AS total_invoiced
                 FROM student_fee_invoices WHERE school_id = ? AND invoice_date BETWEEN ? AND ?',
                [$schoolId, $monthStart, $monthEnd]
            );
            $invoiced = (float) ($inv['total_invoiced'] ?? 0);

            // Expenses
            $exp = Database::fetch(
                'SELECT COALESCE(SUM(amount), 0) AS total_expense
                 FROM expenses WHERE school_id = ? AND expense_date BETWEEN ? AND ?',
                [$schoolId, $monthStart, $monthEnd]
            );
            $expense = (float) ($exp['total_expense'] ?? 0);

            // Student Attendance Rate
            $sAtt = Database::fetchAll(
                'SELECT status, COUNT(*) AS count FROM student_attendance
                 WHERE school_id = ? AND attendance_date BETWEEN ? AND ? GROUP BY status',
                [$schoolId, $monthStart, $monthEnd]
            );
            $sTot = 0;
            $sPres = 0;
            foreach ($sAtt as $sa) {
                $c = (int) $sa['count'];
                $sTot += $c;
                if ($sa['status'] === 'present' || $sa['status'] === 'late') {
                    $sPres += $c;
                }
            }
            $studentAttRate = $sTot > 0 ? round(($sPres / $sTot) * 100, 1) : 100.0;

            // Staff Attendance Rate
            $stAtt = Database::fetchAll(
                'SELECT status, COUNT(*) AS count FROM staff_attendance
                 WHERE school_id = ? AND attendance_date BETWEEN ? AND ? GROUP BY status',
                [$schoolId, $monthStart, $monthEnd]
            );
            $stTot = 0;
            $stPres = 0;
            foreach ($stAtt as $sta) {
                $c = (int) $sta['count'];
                $stTot += $c;
                if ($sta['status'] === 'present' || $sta['status'] === 'late') {
                    $stPres += $c;
                }
            }
            $staffAttRate = $stTot > 0 ? round(($stPres / $stTot) * 100, 1) : 100.0;

            // New Admissions
            $adm = Database::fetch(
                'SELECT COUNT(id) AS new_students FROM students
                 WHERE school_id = ? AND admission_date BETWEEN ? AND ?',
                [$schoolId, $monthStart, $monthEnd]
            );
            $newAdmissions = (int) ($adm['new_students'] ?? 0);

            $collectionEfficiency = $invoiced > 0 ? round(($revenue / $invoiced) * 100, 1) : 100.0;
            $netOperating = round($revenue - $expense, 2);

            $monthlySeries[] = [
                'month_key' => $monthKey,
                'short_key' => $shortKey,
                'start_date' => $monthStart,
                'end_date' => $monthEnd,
                'revenue' => $revenue,
                'invoiced' => $invoiced,
                'expense' => $expense,
                'net_operating' => $netOperating,
                'collection_efficiency' => $collectionEfficiency,
                'student_attendance_rate' => $studentAttRate,
                'staff_attendance_rate' => $staffAttRate,
                'new_admissions' => $newAdmissions,
            ];
        }

        // Calculate MoM Comparisons (Current Month vs Previous Month)
        $n = count($monthlySeries);
        $curr = $n >= 1 ? $monthlySeries[$n - 1] : null;
        $prev = $n >= 2 ? $monthlySeries[$n - 2] : null;

        $calcGrowth = function (float $current, float $previous): array {
            if ($previous == 0.0) {
                $pct = $current > 0 ? 100.0 : 0.0;
            } else {
                $pct = round((($current - $previous) / abs($previous)) * 100, 1);
            }
            return [
                'diff' => round($current - $previous, 2),
                'percent' => $pct,
                'trend' => $pct >= 0 ? 'up' : 'down',
            ];
        };

        $comparisons = [
            'revenue_growth' => $curr && $prev ? $calcGrowth((float) $curr['revenue'], (float) $prev['revenue']) : ['diff' => 0, 'percent' => 0, 'trend' => 'flat'],
            'expense_growth' => $curr && $prev ? $calcGrowth((float) $curr['expense'], (float) $prev['expense']) : ['diff' => 0, 'percent' => 0, 'trend' => 'flat'],
            'net_growth' => $curr && $prev ? $calcGrowth((float) $curr['net_operating'], (float) $prev['net_operating']) : ['diff' => 0, 'percent' => 0, 'trend' => 'flat'],
            'attendance_diff' => $curr && $prev ? round($curr['student_attendance_rate'] - $prev['student_attendance_rate'], 1) : 0.0,
            'admissions_diff' => $curr && $prev ? ($curr['new_admissions'] - $prev['new_admissions']) : 0,
        ];

        return [
            'series' => $monthlySeries,
            'current_month' => $curr,
            'previous_month' => $prev,
            'comparisons' => $comparisons,
        ];
    }

    /**
     * Enterprise Income vs Expense Statement.
     * Computes Gross Revenue (Fees + Incomes), Total Refunds, Net Revenue,
     * Operating Expenses, Net Operating Margin, and Category Breakdowns.
     */
    public function incomeVsExpense(string $from, string $to): array
    {
        $this->normalizeDateRange($from, $to);
        $schoolId = Auth::schoolId();

        // 1. Fee Collections
        $feePayments = Database::fetchAll(
            'SELECT COALESCE(SUM(amount), 0) AS total_fee_collected, COUNT(*) AS payment_count
             FROM payments
             WHERE school_id = ? AND payment_date BETWEEN ? AND ? AND status != "voided"',
            [$schoolId, $from, $to]
        );
        $totalFees = (float) ($feePayments[0]['total_fee_collected'] ?? 0);
        $paymentCount = (int) ($feePayments[0]['payment_count'] ?? 0);

        // 2. Other Incomes
        $incomes = Database::fetchAll(
            'SELECT id, title, COALESCE(category, "General Income") AS category, amount, income_date
             FROM incomes
             WHERE school_id = ? AND income_date BETWEEN ? AND ?
             ORDER BY income_date DESC',
            [$schoolId, $from, $to]
        );
        $totalOtherIncome = 0.0;
        $incomesByCategory = [];
        if ($totalFees > 0) {
            $incomesByCategory['Fee Collections'] = $totalFees;
        }
        foreach ($incomes as $inc) {
            $amt = (float) $inc['amount'];
            $totalOtherIncome += $amt;
            $cat = (string) $inc['category'];
            $incomesByCategory[$cat] = ($incomesByCategory[$cat] ?? 0.0) + $amt;
        }

        // 3. Refunds Issued
        $totalRefunds = 0.0;
        try {
            $refundRows = Database::fetchAll(
                'SELECT COALESCE(SUM(amount), 0) AS total_refunded, COUNT(*) AS refund_count
                 FROM refund_transactions
                 WHERE school_id = ? AND refund_date BETWEEN ? AND ?',
                [$schoolId, $from, $to]
            );
            $totalRefunds = (float) ($refundRows[0]['total_refunded'] ?? 0);
        } catch (\Throwable $e) {
            $totalRefunds = 0.0;
        }

        $grossRevenue = $totalFees + $totalOtherIncome;
        $netRevenue = max(0.0, $grossRevenue - $totalRefunds);

        // 4. Operating Expenses
        $expenses = Database::fetchAll(
            'SELECT id, title, COALESCE(category, "General Expense") AS category, amount, expense_date, payment_method, reference_no
             FROM expenses
             WHERE school_id = ? AND expense_date BETWEEN ? AND ?
             ORDER BY expense_date DESC',
            [$schoolId, $from, $to]
        );
        $totalExpenses = 0.0;
        $expensesByCategory = [];
        foreach ($expenses as $exp) {
            $amt = (float) $exp['amount'];
            $totalExpenses += $amt;
            $cat = (string) $exp['category'];
            $expensesByCategory[$cat] = ($expensesByCategory[$cat] ?? 0.0) + $amt;
        }

        // 5. Net Operating Margin / Surplus
        $netOperatingSurplus = $netRevenue - $totalExpenses;
        $profitMargin = $netRevenue > 0 ? round(($netOperatingSurplus / $netRevenue) * 100, 2) : 0.0;
        $expenseRatio = $netRevenue > 0 ? round(($totalExpenses / $netRevenue) * 100, 2) : 0.0;

        return [
            'from' => $from,
            'to' => $to,
            'summary' => [
                'total_fees' => $totalFees,
                'payment_count' => $paymentCount,
                'total_other_income' => $totalOtherIncome,
                'gross_revenue' => $grossRevenue,
                'total_refunds' => $totalRefunds,
                'net_revenue' => $netRevenue,
                'total_expenses' => $totalExpenses,
                'net_operating_surplus' => $netOperatingSurplus,
                'profit_margin_pct' => $profitMargin,
                'expense_ratio_pct' => $expenseRatio,
                'is_profitable' => $netOperatingSurplus >= 0,
            ],
            'incomes_by_category' => $incomesByCategory,
            'expenses_by_category' => $expensesByCategory,
            'other_incomes' => $incomes,
            'expenses' => $expenses,
        ];
    }
}

