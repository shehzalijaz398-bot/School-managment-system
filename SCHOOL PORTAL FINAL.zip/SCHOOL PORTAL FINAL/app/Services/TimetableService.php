<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class TimetableService
{
    public function create(array $data): int
    {
        $schoolId = (int) Auth::schoolId();
        $yearId = (int) ($data['academic_year_id'] ?? activeAcademicYearId());

        if ($this->hasTeacherConflict($schoolId, $yearId, (int) $data['teacher_id'], (int) $data['day_of_week'], (int)$data['period_id'])) {
            throw new \RuntimeException('Teacher is already scheduled during this period.');
        }
        if ($this->hasClassConflict($schoolId, $yearId, (int) $data['class_id'], (int) $data['section_id'], (int) $data['day_of_week'], (int)$data['period_id'])) {
            throw new \RuntimeException('Class/section already has a subject during this period.');
        }
        if ($this->hasRoomConflict($schoolId, $yearId, $data['room'] ?? '', (int) $data['day_of_week'], (int)$data['period_id'])) {
            throw new \RuntimeException('Room is already occupied during this period.');
        }

        $id = Database::insert(
            'INSERT INTO timetables
            (school_id, academic_year_id, class_id, section_id, period_id, subject_id, teacher_id, day_of_week, room, notes, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $schoolId,
                $yearId,
                (int) $data['class_id'],
                (int) $data['section_id'],
                (int) $data['period_id'],
                (int) $data['subject_id'],
                (int) $data['teacher_id'],
                (int) $data['day_of_week'],
                $data['room'] ?? null,
                $data['notes'] ?? null,
            ]
        );
        auditLog('timetable.create', 'timetable', 'timetables', $id);
        return $id;
    }

    public function update(int $id, array $data): void
    {
        $schoolId = (int) Auth::schoolId();
        $yearId = (int) ($data['academic_year_id'] ?? activeAcademicYearId());
        
        $existing = Database::fetch('SELECT id FROM timetables WHERE id = ? AND school_id = ?', [$id, $schoolId]);
        if (!$existing) {
            throw new \RuntimeException('Timetable entry not found.');
        }

        if ($this->hasTeacherConflict($schoolId, $yearId, (int) $data['teacher_id'], (int) $data['day_of_week'], (int)$data['period_id'], $id)) {
            throw new \RuntimeException('Teacher is already scheduled during this period.');
        }
        if ($this->hasClassConflict($schoolId, $yearId, (int) $data['class_id'], (int) $data['section_id'], (int) $data['day_of_week'], (int)$data['period_id'], $id)) {
            throw new \RuntimeException('Class/section already has a subject during this period.');
        }
        if ($this->hasRoomConflict($schoolId, $yearId, $data['room'] ?? '', (int) $data['day_of_week'], (int)$data['period_id'], $id)) {
            throw new \RuntimeException('Room is already occupied during this period.');
        }

        Database::execute(
            'UPDATE timetables SET class_id = ?, section_id = ?, period_id = ?, subject_id = ?, teacher_id = ?, day_of_week = ?, room = ?, notes = ?, updated_at = NOW() WHERE id = ?',
            [
                (int) $data['class_id'],
                (int) $data['section_id'],
                (int) $data['period_id'],
                (int) $data['subject_id'],
                (int) $data['teacher_id'],
                (int) $data['day_of_week'],
                $data['room'] ?? null,
                $data['notes'] ?? null,
                $id
            ]
        );
        auditLog('timetable.update', 'timetable', 'timetables', $id);
    }

    private function hasTeacherConflict(int $schoolId, int $yearId, int $teacherId, int $day, int $periodId, ?int $excludeId = null): bool
    {
        $query = 'SELECT id FROM timetables
                  WHERE school_id = ? AND academic_year_id = ? AND teacher_id = ? AND day_of_week = ? AND period_id = ?';
        $params = [$schoolId, $yearId, $teacherId, $day, $periodId];
        if ($excludeId !== null) {
            $query .= ' AND id != ?';
            $params[] = $excludeId;
        }
        $query .= ' LIMIT 1';
        return Database::fetch($query, $params) !== null;
    }

    private function hasClassConflict(int $schoolId, int $yearId, int $classId, int $sectionId, int $day, int $periodId, ?int $excludeId = null): bool
    {
        $query = 'SELECT id FROM timetables
                  WHERE school_id = ? AND academic_year_id = ? AND class_id = ? AND section_id = ? AND day_of_week = ? AND period_id = ?';
        $params = [$schoolId, $yearId, $classId, $sectionId, $day, $periodId];
        if ($excludeId !== null) {
            $query .= ' AND id != ?';
            $params[] = $excludeId;
        }
        $query .= ' LIMIT 1';
        return Database::fetch($query, $params) !== null;
    }

    private function hasRoomConflict(int $schoolId, int $yearId, string $room, int $day, int $periodId, ?int $excludeId = null): bool
    {
        if (empty($room)) return false;
        
        $query = 'SELECT id FROM timetables
                  WHERE school_id = ? AND academic_year_id = ? AND room = ? AND day_of_week = ? AND period_id = ?';
        $params = [$schoolId, $yearId, $room, $day, $periodId];
        if ($excludeId !== null) {
            $query .= ' AND id != ?';
            $params[] = $excludeId;
        }
        $query .= ' LIMIT 1';
        return Database::fetch($query, $params) !== null;
    }

    /**
     * Comprehensive Timetable Conflict & Collision Scanner.
     * Checks for teacher collisions, room over-allocation, and class double-booking.
     */
    public function scanAllConflicts(int $schoolId, int $academicYearId): array
    {
        $dayNames = [
            1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday',
            4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'
        ];

        $entries = Database::fetchAll(
            'SELECT t.id, t.day_of_week, t.period_id, t.room, t.teacher_id, t.class_id, t.section_id,
                    tp.name AS period_name, tp.start_time, tp.end_time,
                    sub.name AS subject_name,
                    c.name AS class_name,
                    sec.name AS section_name,
                    COALESCE(CONCAT(emp.first_name, " ", emp.last_name), "Assigned Teacher") AS teacher_name
             FROM timetables t
             JOIN timetable_periods tp ON tp.id = t.period_id
             JOIN subjects sub ON sub.id = t.subject_id
             JOIN classes c ON c.id = t.class_id
             LEFT JOIN sections sec ON sec.id = t.section_id
             LEFT JOIN teachers tch ON tch.id = t.teacher_id
             LEFT JOIN employees emp ON emp.id = tch.employee_id
             WHERE t.school_id = ? AND t.academic_year_id = ?
             ORDER BY t.day_of_week ASC, tp.period_number ASC',
            [$schoolId, $academicYearId]
        );

        $conflicts = [];
        $teacherMap = [];
        $roomMap = [];
        $classMap = [];

        foreach ($entries as $e) {
            $day = (int) $e['day_of_week'];
            $period = (int) $e['period_id'];
            $teacherId = (int) $e['teacher_id'];
            $room = trim((string) ($e['room'] ?? ''));
            $classSec = "{$e['class_id']}-{$e['section_id']}";
            $slotKey = "{$day}-{$period}";

            // 1. Check Teacher Collision
            if ($teacherId > 0) {
                if (isset($teacherMap[$slotKey][$teacherId])) {
                    $other = $teacherMap[$slotKey][$teacherId];
                    $conflicts[] = [
                        'type' => 'teacher_collision',
                        'severity' => 'critical',
                        'day_of_week' => $day,
                        'day_name' => $dayNames[$day] ?? 'Day ' . $day,
                        'period_name' => $e['period_name'] . " ({$e['start_time']} - {$e['end_time']})",
                        'title' => 'Teacher Double-Booked',
                        'description' => "Teacher {$e['teacher_name']} is scheduled for both '{$other['class_name']}' ({$other['subject_name']}) and '{$e['class_name']}' ({$e['subject_name']}) at the same time.",
                        'entries' => [$other['id'], $e['id']],
                    ];
                } else {
                    $teacherMap[$slotKey][$teacherId] = $e;
                }
            }

            // 2. Check Room Collision
            if ($room !== '') {
                if (isset($roomMap[$slotKey][$room])) {
                    $other = $roomMap[$slotKey][$room];
                    $conflicts[] = [
                        'type' => 'room_collision',
                        'severity' => 'critical',
                        'day_of_week' => $day,
                        'day_name' => $dayNames[$day] ?? 'Day ' . $day,
                        'period_name' => $e['period_name'] . " ({$e['start_time']} - {$e['end_time']})",
                        'title' => "Room Collision ({$room})",
                        'description' => "Room '{$room}' is assigned to both {$other['class_name']} ({$other['subject_name']}) and {$e['class_name']} ({$e['subject_name']}) at the same time.",
                        'entries' => [$other['id'], $e['id']],
                    ];
                } else {
                    $roomMap[$slotKey][$room] = $e;
                }
            }

            // 3. Check Class Section Collision
            if (isset($classMap[$slotKey][$classSec])) {
                $other = $classMap[$slotKey][$classSec];
                $conflicts[] = [
                    'type' => 'class_overlap',
                    'severity' => 'critical',
                    'day_of_week' => $day,
                    'day_name' => $dayNames[$day] ?? 'Day ' . $day,
                    'period_name' => $e['period_name'] . " ({$e['start_time']} - {$e['end_time']})",
                    'title' => 'Class Double-Scheduled',
                    'description' => "Class {$e['class_name']} has two subjects ({$other['subject_name']} and {$e['subject_name']}) assigned simultaneously.",
                    'entries' => [$other['id'], $e['id']],
                ];
            } else {
                $classMap[$slotKey][$classSec] = $e;
            }
        }

        $teacherCollisions = count(array_filter($conflicts, fn($c) => $c['type'] === 'teacher_collision'));
        $roomCollisions = count(array_filter($conflicts, fn($c) => $c['type'] === 'room_collision'));
        $classOverlaps = count(array_filter($conflicts, fn($c) => $c['type'] === 'class_overlap'));

        $summary = [
            'total_entries' => count($entries),
            'conflict_count' => count($conflicts),
            'teacher_conflicts' => $teacherCollisions,
            'room_conflicts' => $roomCollisions,
            'class_conflicts' => $classOverlaps,
        ];

        return [
            'total_entries' => count($entries),
            'conflict_count' => count($conflicts),
            'teacher_conflicts' => $teacherCollisions,
            'room_conflicts' => $roomCollisions,
            'class_conflicts' => $classOverlaps,
            'conflicts' => $conflicts,
            'is_conflict_free' => empty($conflicts),
            'summary' => $summary,
        ];
    }
}
