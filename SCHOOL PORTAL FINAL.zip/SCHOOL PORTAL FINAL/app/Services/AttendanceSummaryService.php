<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;
use Throwable;

/**
 * AttendanceSummaryService
 *
 * Daily automated attendance aggregation and compliance alert engine:
 * - Aggregates school-wide, class-by-class, and staff attendance percentages
 * - Flags unsubmitted attendance registers by afternoon cutoff
 * - Detects classes with low attendance (< 85%) and dispatches administrative alerts
 */
final class AttendanceSummaryService
{
    public function generateDailySummary(int $schoolId, ?string $date = null): array
    {
        $targetDate = $date ?? date('Y-m-d');

        // 1. Student Attendance Aggregation
        $studentStats = Database::fetch("
            SELECT 
                COUNT(*) AS total_marked,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late_count
            FROM student_attendance
            WHERE school_id = ? AND attendance_date = ?
        ", [$schoolId, $targetDate]);

        $totalMarked = (int)($studentStats['total_marked'] ?? 0);
        $presentCount = (int)($studentStats['present_count'] ?? 0);
        $studentAttPct = $totalMarked > 0 ? round(($presentCount / $totalMarked) * 100, 1) : 0.0;

        // 2. Staff Attendance Aggregation
        $staffStats = Database::fetch("
            SELECT 
                COUNT(*) AS total_marked,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count
            FROM staff_attendance
            WHERE school_id = ? AND attendance_date = ?
        ", [$schoolId, $targetDate]);

        $totalStaff = (int)($staffStats['total_marked'] ?? 0);
        $presentStaff = (int)($staffStats['present_count'] ?? 0);
        $staffAttPct = $totalStaff > 0 ? round(($presentStaff / $totalStaff) * 100, 1) : 0.0;

        // 3. Sections with unsubmitted registers for today
        $unsubmittedSections = Database::fetchAll("
            SELECT sec.id, sec.name AS section_name, c.name AS class_name, e.first_name, e.last_name
            FROM sections sec
            JOIN classes c ON c.id = sec.class_id AND c.school_id = sec.school_id
            LEFT JOIN teachers t ON t.id = sec.class_teacher_id
            LEFT JOIN employees e ON e.id = t.employee_id
            WHERE sec.school_id = ?
            AND NOT EXISTS (
                SELECT 1 FROM student_attendance sa 
                WHERE sa.section_id = sec.id AND sa.school_id = sec.school_id AND sa.attendance_date = ?
            )
            ORDER BY c.name, sec.name
        ", [$schoolId, $targetDate]);

        // 4. Classes with low attendance (< 85%)
        $lowAttendanceClasses = Database::fetchAll("
            SELECT 
                c.name AS class_name,
                sec.name AS section_name,
                COUNT(sa.id) AS total_students,
                SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) AS present_students,
                ROUND((SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) / COUNT(sa.id)) * 100, 1) AS att_pct
            FROM student_attendance sa
            JOIN classes c ON c.id = sa.class_id AND c.school_id = sa.school_id
            JOIN sections sec ON sec.id = sa.section_id AND sec.school_id = sa.school_id
            WHERE sa.school_id = ? AND sa.attendance_date = ?
            GROUP BY c.name, sec.name
            HAVING att_pct < 85.0
            ORDER BY att_pct ASC
        ", [$schoolId, $targetDate]);

        // Dispatches administrative alert if attendance is low
        if (!empty($lowAttendanceClasses)) {
            $this->dispatchLowAttendanceAlert($schoolId, $targetDate, $lowAttendanceClasses);
        }

        if (class_exists(StructuredLogger::class)) {
            StructuredLogger::info("Daily attendance summary generated", [
                'school_id' => $schoolId,
                'date' => $targetDate,
                'student_pct' => $studentAttPct,
                'staff_pct' => $staffAttPct,
                'unsubmitted_count' => count($unsubmittedSections),
            ]);
        }

        return [
            'date'                  => $targetDate,
            'school_id'             => $schoolId,
            'student_attendance'    => [
                'total_marked' => $totalMarked,
                'present'      => $presentCount,
                'percentage'   => $studentAttPct,
            ],
            'staff_attendance'      => [
                'total_marked' => $totalStaff,
                'present'      => $presentStaff,
                'percentage'   => $staffAttPct,
            ],
            'unsubmitted_sections'  => $unsubmittedSections,
            'low_attendance_classes'=> $lowAttendanceClasses,
        ];
    }

    private function dispatchLowAttendanceAlert(int $schoolId, string $date, array $lowClasses): void
    {
        try {
            $classListStr = implode(', ', array_map(fn($c) => "{$c['class_name']} ({$c['section_name']}: {$c['att_pct']}%)", array_slice($lowClasses, 0, 3)));
            
            // Send in-app notification to administrators
            $admins = Database::fetchAll("
                SELECT u.id FROM users u
                JOIN roles r ON r.id = u.role_id
                WHERE u.school_id = ? AND r.slug IN ('principal', 'school_admin', 'owner')
            ", [$schoolId]);

            foreach ($admins as $adm) {
                Database::insert("
                    INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                    VALUES (?, ?, 'attendance.low_summary', 'Daily Attendance Alert (< 85%)', ?, '/attendance/students', 0, NOW())
                ", [
                    $schoolId,
                    (int)$adm['id'],
                    "Low attendance flagged on {$date} for: {$classListStr}.",
                ]);
            }
        } catch (Throwable $e) {
            // Notification dispatch is non-blocking
        }
    }
}
