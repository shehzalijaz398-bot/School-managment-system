<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class ParentTeacherMessageService
{
    public function ensureSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS parent_teacher_conversations (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id INT UNSIGNED NOT NULL,
                student_id BIGINT UNSIGNED NOT NULL,
                parent_id BIGINT UNSIGNED NOT NULL,
                teacher_id BIGINT UNSIGNED NOT NULL,
                subject VARCHAR(191) NOT NULL,
                status ENUM('active', 'closed') NOT NULL DEFAULT 'active',
                last_message_at DATETIME NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_ptc_school_parent (school_id, parent_id),
                INDEX idx_ptc_school_teacher (school_id, teacher_id),
                INDEX idx_ptc_student (student_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS parent_teacher_messages (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                conversation_id BIGINT UNSIGNED NOT NULL,
                sender_id BIGINT UNSIGNED NOT NULL,
                sender_role VARCHAR(50) NOT NULL,
                message TEXT NOT NULL,
                attachment VARCHAR(255) NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL,
                INDEX idx_ptm_conversation (conversation_id),
                INDEX idx_ptm_sender (sender_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    /**
     * List all conversations for the authenticated user.
     */
    public function getConversations(int $userId, string $role, int $schoolId): array
    {
        $this->ensureSchema();

        $where = "c.school_id = :school_id";
        $params = ['school_id' => $schoolId];

        if ($role === 'parent') {
            $user = Database::fetch("SELECT parent_id FROM users WHERE id = ? LIMIT 1", [$userId]);
            $parentId = $user ? (int) $user['parent_id'] : 0;
            $where .= " AND c.parent_id = :parent_id";
            $params['parent_id'] = $parentId;
        } elseif ($role === 'teacher') {
            $teacher = Database::fetch("SELECT t.id FROM teachers t INNER JOIN users u ON u.employee_id = t.employee_id WHERE u.id = ? AND t.school_id = ? LIMIT 1", [$userId, $schoolId]);
            $teacherId = $teacher ? (int) $teacher['id'] : 0;
            $where .= " AND c.teacher_id = :teacher_id";
            $params['teacher_id'] = $teacherId;
        }

        $sql = "
            SELECT c.*,
                   CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                   s.admission_no,
                   cls.name AS class_name,
                   sec.name AS section_name,
                   CONCAT(p.first_name, ' ', p.last_name) AS parent_name,
                   p.phone AS parent_phone,
                   CONCAT(emp.first_name, ' ', emp.last_name) AS teacher_name,
                   (
                       SELECT m.message 
                       FROM parent_teacher_messages m 
                       WHERE m.conversation_id = c.id 
                       ORDER BY m.id DESC LIMIT 1
                   ) AS latest_message,
                   (
                       SELECT COUNT(m.id) 
                       FROM parent_teacher_messages m 
                       WHERE m.conversation_id = c.id 
                         AND m.is_read = 0 
                         AND m.sender_id != :current_user
                   ) AS unread_count
            FROM parent_teacher_conversations c
            INNER JOIN students s ON s.id = c.student_id
            LEFT JOIN classes cls ON cls.id = s.class_id
            LEFT JOIN sections sec ON sec.id = s.section_id
            INNER JOIN parents p ON p.id = c.parent_id
            INNER JOIN teachers t ON t.id = c.teacher_id
            INNER JOIN employees emp ON emp.id = t.employee_id
            WHERE {$where}
            ORDER BY c.last_message_at DESC
        ";

        $params['current_user'] = $userId;
        return Database::fetchAll($sql, $params);
    }

    /**
     * Retrieve a specific conversation thread and its message history.
     */
    public function getConversationThread(int $conversationId, int $userId, string $role, int $schoolId): ?array
    {
        $this->ensureSchema();

        $conv = Database::fetch("
            SELECT c.*,
                   CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                   s.admission_no,
                   cls.name AS class_name,
                   sec.name AS section_name,
                   CONCAT(p.first_name, ' ', p.last_name) AS parent_name,
                   (SELECT u.id FROM users u WHERE u.parent_id = p.id AND u.school_id = c.school_id LIMIT 1) AS parent_user_id,
                   CONCAT(emp.first_name, ' ', emp.last_name) AS teacher_name,
                   (SELECT u.id FROM users u WHERE u.employee_id = t.employee_id AND u.school_id = c.school_id LIMIT 1) AS teacher_user_id
            FROM parent_teacher_conversations c
            INNER JOIN students s ON s.id = c.student_id
            LEFT JOIN classes cls ON cls.id = s.class_id
            LEFT JOIN sections sec ON sec.id = s.section_id
            INNER JOIN parents p ON p.id = c.parent_id
            INNER JOIN teachers t ON t.id = c.teacher_id
            INNER JOIN employees emp ON emp.id = t.employee_id
            WHERE c.id = ? AND c.school_id = ?
            LIMIT 1
        ", [$conversationId, $schoolId]);

        if (!$conv) {
            return null;
        }

        // Authorization Guard: User must be participant (parent or teacher) or admin
        $isParent = ((int) $conv['parent_user_id'] === $userId);
        $isTeacher = ((int) $conv['teacher_user_id'] === $userId);
        $isAdmin = in_array($role, ['admin', 'super_admin', 'owner', 'principal'], true);

        if (!$isParent && !$isTeacher && !$isAdmin) {
            return null;
        }

        // Mark incoming messages as read
        Database::execute("
            UPDATE parent_teacher_messages 
            SET is_read = 1 
            WHERE conversation_id = ? AND sender_id != ?
        ", [$conversationId, $userId]);

        // Fetch chronological messages
        $messages = Database::fetchAll("
            SELECT m.*, u.name AS sender_name, u.email AS sender_email
            FROM parent_teacher_messages m
            LEFT JOIN users u ON u.id = m.sender_id
            WHERE m.conversation_id = ?
            ORDER BY m.created_at ASC
        ", [$conversationId]);

        return [
            'conversation' => $conv,
            'messages' => $messages,
            'is_parent' => $isParent,
            'is_teacher' => $isTeacher,
            'is_admin' => $isAdmin,
        ];
    }

    /**
     * Start a new parent-teacher conversation thread.
     */
    public function startConversation(
        int $schoolId,
        int $parentId,
        int $teacherId,
        int $studentId,
        string $subject,
        string $initialMessage,
        int $senderUserId,
        string $senderRole,
        ?string $attachment = null
    ): int {
        $this->ensureSchema();

        // Security check: verify parent owns the student
        $owns = Database::fetch("
            SELECT id FROM student_parents 
            WHERE parent_id = ? AND student_id = ? LIMIT 1
        ", [$parentId, $studentId]);

        if (!$owns) {
            throw new \InvalidArgumentException('Unauthorized: Child is not linked to this parent account.');
        }

        $convId = Database::transaction(function () use (
            $schoolId, $parentId, $teacherId, $studentId, $subject, $initialMessage, $senderUserId, $senderRole, $attachment
        ) {
            $conversationId = Database::insert("
                INSERT INTO parent_teacher_conversations 
                (school_id, student_id, parent_id, teacher_id, subject, status, last_message_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'active', NOW(), NOW(), NOW())
            ", [$schoolId, $studentId, $parentId, $teacherId, $subject]);

            Database::insert("
                INSERT INTO parent_teacher_messages 
                (conversation_id, sender_id, sender_role, message, attachment, is_read, created_at)
                VALUES (?, ?, ?, ?, ?, 0, NOW())
            ", [$conversationId, $senderUserId, $senderRole, $initialMessage, $attachment]);

            // Notify recipient
            $teacher = Database::fetch("SELECT u.id AS user_id FROM teachers t INNER JOIN users u ON u.employee_id = t.employee_id WHERE t.id = ? LIMIT 1", [$teacherId]);
            if ($teacher && !empty($teacher['user_id'])) {
                Database::insert(
                    "INSERT INTO notifications (school_id, user_id, type, title, message, link, is_read, created_at)
                     VALUES (?, ?, 'parent_communication', 'New Message from Parent', ?, ?, 0, NOW())",
                    [
                        $schoolId,
                        (int) $teacher['user_id'],
                        "Subject: {$subject} — " . mb_substr($initialMessage, 0, 120),
                        "parent/messages/{$conversationId}"
                    ]
                );
            }

            auditLog('parent_teacher.message_start', 'communication', 'parent_teacher_conversations', $conversationId, null, [
                'student_id' => $studentId,
                'parent_id' => $parentId,
                'teacher_id' => $teacherId,
                'subject' => $subject,
            ]);

            return $conversationId;
        });

        return (int) $convId;
    }

    /**
     * Send reply in an existing conversation thread.
     */
    public function sendReply(
        int $conversationId,
        int $senderUserId,
        string $senderRole,
        string $message,
        int $schoolId,
        ?string $attachment = null
    ): int {
        $this->ensureSchema();

        $conv = Database::fetch("
            SELECT c.*,
                   (SELECT u.id FROM users u WHERE u.parent_id = p.id AND u.school_id = c.school_id LIMIT 1) AS parent_user_id,
                   (SELECT u.id FROM users u WHERE u.employee_id = t.employee_id AND u.school_id = c.school_id LIMIT 1) AS teacher_user_id
            FROM parent_teacher_conversations c
            INNER JOIN parents p ON p.id = c.parent_id
            INNER JOIN teachers t ON t.id = c.teacher_id
            WHERE c.id = ? AND c.school_id = ? LIMIT 1
        ", [$conversationId, $schoolId]);

        if (!$conv) {
            throw new \RuntimeException('Conversation not found or access denied.');
        }

        $isParent = ((int) $conv['parent_user_id'] === $senderUserId);
        $isTeacher = ((int) $conv['teacher_user_id'] === $senderUserId);
        $isAdmin = in_array($senderRole, ['admin', 'super_admin', 'owner', 'principal'], true);

        if (!$isParent && !$isTeacher && !$isAdmin) {
            throw new \RuntimeException('Access denied: You are not a participant in this conversation.');
        }

        $msgId = Database::transaction(function () use ($conversationId, $senderUserId, $senderRole, $message, $attachment, $conv) {
            $messageId = Database::insert("
                INSERT INTO parent_teacher_messages 
                (conversation_id, sender_id, sender_role, message, attachment, is_read, created_at)
                VALUES (?, ?, ?, ?, ?, 0, NOW())
            ", [$conversationId, $senderUserId, $senderRole, $message, $attachment]);

            Database::execute("
                UPDATE parent_teacher_conversations 
                SET last_message_at = NOW(), updated_at = NOW(), status = 'active'
                WHERE id = ?
            ", [$conversationId]);

            // Notify counterpart
            $recipientUserId = ((int) $conv['parent_user_id'] === $senderUserId) 
                ? (int) $conv['teacher_user_id'] 
                : (int) $conv['parent_user_id'];

            if ($recipientUserId > 0) {
                Database::insert(
                    "INSERT INTO notifications (school_id, user_id, type, title, message, link, is_read, created_at)
                     VALUES (?, ?, 'parent_communication', 'New Reply in Conversation', ?, ?, 0, NOW())",
                    [
                        (int) $conv['school_id'],
                        $recipientUserId,
                        mb_substr($message, 0, 120),
                        "parent/messages/{$conversationId}"
                    ]
                );
            }

            return $messageId;
        });

        return (int) $msgId;
    }
}
