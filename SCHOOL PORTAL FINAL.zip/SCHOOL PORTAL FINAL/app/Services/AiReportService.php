<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * AiReportService
 *
 * Synthesizes institutional natural-language executive reports on-demand
 * using verified real-time database aggregates with strict role and tenant boundaries.
 */
final class AiReportService
{
    /**
     * Generate a natural-language report based on plain English user request.
     *
     * @param int $schoolId Tenant ID
     * @param int $userId Authenticated user ID
     * @param string $roleSlug User role
     * @param string $query Natural language query
     * @return array{success: bool, report_type: string, title: string, content: string, metrics: array, verified: bool}
     */
    public function generateReport(int $schoolId, int $userId, string $roleSlug, string $query): array
    {
        $q = strtolower(trim($query));

        // 1. Attendance Trends
        if (preg_match('/\b(attendance|absenteeism|presence|turnout|attendance trend)\b/i', $q)) {
            return $this->buildAttendanceReport($schoolId, $userId, $roleSlug);
        }

        // 2. Fee Collection & Revenue Ledger
        if (preg_match('/\b(fee|fees|revenue|collection|arrears|overdue|invoices?|outstanding|cashier)\b/i', $q)) {
            return $this->buildFeeCollectionReport($schoolId, $userId, $roleSlug);
        }

        // 3. Admissions & Student Enrollments
        if (preg_match('/\b(admission|admissions|enrollment|enrolled|intake|demographics)\b/i', $q)) {
            return $this->buildAdmissionsReport($schoolId, $userId, $roleSlug);
        }

        // 4. Examination & Academic Performance
        if (preg_match('/\b(exam|exams|examination|result|results|grade|grades|marks|score|pass rate|performance)\b/i', $q)) {
            return $this->buildExamPerformanceReport($schoolId, $userId, $roleSlug);
        }

        // 5. Pending Tasks & Operational Backlog
        if (preg_match('/\b(pending|tasks|backlog|to[- ]do|operations|unsubmitted|unapproved)\b/i', $q)) {
            return $this->buildPendingTasksReport($schoolId, $userId, $roleSlug);
        }

        // Default Institutional Overview Report
        return $this->buildInstitutionalOverviewReport($schoolId, $userId, $roleSlug);
    }

    /**
     * Attendance Trends Report.
     */
    private function buildAttendanceReport(int $schoolId, int $userId, string $roleSlug): array
    {
        // 30-Day aggregate attendance for tenant
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
        $stats = Database::fetch("
            SELECT COUNT(*) AS total_records,
                   SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count,
                   SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
                   SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late_count,
                   SUM(CASE WHEN status = 'half_day' THEN 1 ELSE 0 END) AS half_day_count
            FROM student_attendance
            WHERE school_id = ? AND attendance_date >= ?
        ", [$schoolId, $thirtyDaysAgo]) ?: [];

        $total = (int) ($stats['total_records'] ?? 0);

        if ($total === 0) {
            return [
                'success' => true,
                'report_type' => 'attendance_trends',
                'title' => 'Student Attendance Trends Analysis (Last 30 Days)',
                'content' => "### 📊 Student Attendance Trends Analysis\n\n"
                    . "> [!WARNING]\n"
                    . "> **[DATA_SPARSE_WARNING]**: No student attendance logs found within the last 30 days for this institution.\n\n"
                    . "Please ensure daily attendance registers are submitted via **Attendance > Student Attendance**.",
                'metrics' => ['total_records' => 0],
                'verified' => true,
            ];
        }

        $present = (int) ($stats['present_count'] ?? 0);
        $absent = (int) ($stats['absent_count'] ?? 0);
        $late = (int) ($stats['late_count'] ?? 0);

        $presentPct = round(($present / $total) * 100, 1);
        $absentPct = round(($absent / $total) * 100, 1);
        $latePct = round(($late / $total) * 100, 1);

        // Class breakdown
        $classBreakdown = Database::fetchAll("
            SELECT c.name AS class_name,
                   COUNT(sa.id) AS total_logs,
                   SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) AS present_cnt
            FROM student_attendance sa
            JOIN students s ON s.id = sa.student_id
            JOIN classes c ON c.id = s.class_id
            WHERE sa.school_id = ? AND sa.attendance_date >= ?
            GROUP BY c.id, c.name
            ORDER BY c.name ASC
        ", [$schoolId, $thirtyDaysAgo]);

        $tableRows = '';
        foreach ($classBreakdown as $row) {
            $cTotal = (int) $row['total_logs'];
            $cPres = (int) $row['present_cnt'];
            $cRate = $cTotal > 0 ? round(($cPres / $cTotal) * 100, 1) : 0.0;
            $tableRows .= "| {$row['class_name']} | {$cTotal} | {$cPres} | {$cRate}% |\n";
        }

        $markdown = "### 📊 Student Attendance Trends Analysis (Last 30 Days)\n\n"
            . "`[VERIFIED_STATISTICS]` *Generated from official institutional attendance ledger.*\n\n"
            . "| Metric | Count | Percentage |\n"
            . "|---|---|---|\n"
            . "| **Total Recorded Sessions** | " . number_format($total) . " | 100.0% |\n"
            . "| **Present Attendance** | " . number_format($present) . " | **{$presentPct}%** |\n"
            . "| **Unexcused Absences** | " . number_format($absent) . " | {$absentPct}% |\n"
            . "| **Tardiness / Late Arrivals** | " . number_format($late) . " | {$latePct}% |\n\n";

        if ($tableRows !== '') {
            $markdown .= "#### 🏫 Cohort Breakdown by Grade Level\n\n"
                . "| Class | Total Marks | Present Count | Attendance Rate |\n"
                . "|---|---|---|---|\n"
                . $tableRows . "\n";
        }

        $markdown .= "#### 💡 Actionable Insights\n"
            . "- Overall institutional attendance stands at **{$presentPct}%** (" . ($presentPct >= 85 ? "Optimal ✅" : "Needs Attention ⚠️") . ").\n"
            . "- Late arrival rate is **{$latePct}%**; targeted punctuality notifications are recommended.\n";

        return [
            'success' => true,
            'report_type' => 'attendance_trends',
            'title' => 'Student Attendance Trends Analysis (Last 30 Days)',
            'content' => $markdown,
            'metrics' => [
                'total_sessions' => $total,
                'present_rate' => $presentPct,
                'absent_rate' => $absentPct,
                'late_rate' => $latePct,
            ],
            'verified' => true,
        ];
    }

    /**
     * Fee Collection & Revenue Ledger Report.
     */
    private function buildFeeCollectionReport(int $schoolId, int $userId, string $roleSlug): array
    {
        // Permission guard: Non-financial roles cannot inspect institutional revenue
        if (!in_array($roleSlug, ['admin', 'school_admin', 'owner', 'super_admin', 'superadmin', 'principal', 'accountant', 'finance'], true)) {
            return [
                'success' => false,
                'report_type' => 'fee_collection',
                'title' => 'Access Denied',
                'content' => "⚠️ **Access Restricted**: Institutional fee collection reports require administrative or bursar authorization.",
                'metrics' => [],
                'verified' => false,
            ];
        }

        $stats = Database::fetch("
            SELECT COUNT(*) AS total_invoices,
                   COALESCE(SUM(total_amount), 0.00) AS total_invoiced,
                   COALESCE(SUM(paid_amount), 0.00) AS total_collected,
                   COALESCE(SUM(total_amount - paid_amount), 0.00) AS total_outstanding,
                   SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid_invoices,
                   SUM(CASE WHEN status IN ('unpaid', 'partially_paid', 'partial') THEN 1 ELSE 0 END) AS unpaid_invoices
            FROM student_fee_invoices
            WHERE school_id = ?
        ", [$schoolId]) ?: [];

        $totalInvoices = (int) ($stats['total_invoices'] ?? 0);
        $totalInvoiced = (float) ($stats['total_invoiced'] ?? 0.0);
        $totalCollected = (float) ($stats['total_collected'] ?? 0.0);
        $totalOutstanding = (float) ($stats['total_outstanding'] ?? 0.0);

        if ($totalInvoices === 0) {
            return [
                'success' => true,
                'report_type' => 'fee_collection',
                'title' => 'Institutional Fee Collection & Arrears Audit',
                'content' => "### 💳 Fee Collection & Arrears Audit\n\n"
                    . "> [!NOTE]\n"
                    . "> **[DATA_SPARSE_WARNING]**: No fee invoices have been generated for this school tenant yet.",
                'metrics' => ['total_invoices' => 0],
                'verified' => true,
            ];
        }

        $collectionPct = $totalInvoiced > 0 ? round(($totalCollected / $totalInvoiced) * 100, 2) : 0.0;

        // Class-wise outstanding breakdown
        $classArrears = Database::fetchAll("
            SELECT c.name AS class_name,
                   COUNT(sfi.id) AS invoice_count,
                   COALESCE(SUM(sfi.total_amount - sfi.paid_amount), 0.00) AS class_overdue
            FROM student_fee_invoices sfi
            JOIN students s ON s.id = sfi.student_id
            JOIN classes c ON c.id = s.class_id
            WHERE sfi.school_id = ? AND sfi.status IN ('unpaid', 'partially_paid', 'partial')
            GROUP BY c.id, c.name
            HAVING class_overdue > 0
            ORDER BY class_overdue DESC
            LIMIT 5
        ", [$schoolId]);

        $classRows = '';
        foreach ($classArrears as $ca) {
            $classRows .= "| {$ca['class_name']} | {$ca['invoice_count']} | $" . number_format((float) $ca['class_overdue'], 2) . " |\n";
        }

        $markdown = "### 💳 Institutional Fee Collection & Arrears Audit\n\n"
            . "`[VERIFIED_STATISTICS]` *Extracted from verified double-entry and student invoice tables.*\n\n"
            . "| Financial Metric | Value |\n"
            . "|---|---|\n"
            . "| **Total Invoiced Volume** | **$" . number_format($totalInvoiced, 2) . "** (" . number_format($totalInvoices) . " invoices) |\n"
            . "| **Realized Collections** | **$" . number_format($totalCollected, 2) . "** |\n"
            . "| **Uncollected Arrears** | **$" . number_format($totalOutstanding, 2) . "** |\n"
            . "| **Collection Efficiency Ratio** | **{$collectionPct}%** |\n\n";

        if ($classRows !== '') {
            $markdown .= "#### ⚠️ Top Arrears by Grade Cohort\n\n"
                . "| Class | Outstanding Invoices | Total Arrears Amount |\n"
                . "|---|---|---|\n"
                . $classRows . "\n";
        }

        $markdown .= "#### 💡 Strategic Recommendations\n"
            . "- Current collection rate is **{$collectionPct}%**.\n"
            . "- Automated overdue reminders can be dispatched via the AI Workflow Engine or **Finance > Automated Reminders**.\n";

        return [
            'success' => true,
            'report_type' => 'fee_collection',
            'title' => 'Institutional Fee Collection & Arrears Audit',
            'content' => $markdown,
            'metrics' => [
                'total_invoiced' => $totalInvoiced,
                'total_collected' => $totalCollected,
                'total_outstanding' => $totalOutstanding,
                'collection_efficiency_pct' => $collectionPct,
            ],
            'verified' => true,
        ];
    }

    /**
     * Admissions & Enrollment Breakdown Report.
     */
    private function buildAdmissionsReport(int $schoolId, int $userId, string $roleSlug): array
    {
        $students = Database::fetchAll("
            SELECT s.status, s.gender, c.name AS class_name
            FROM students s
            LEFT JOIN classes c ON c.id = s.class_id
            WHERE s.school_id = ?
        ", [$schoolId]);

        $totalStudents = count($students);
        if ($totalStudents === 0) {
            return [
                'success' => true,
                'report_type' => 'admissions',
                'title' => 'Student Enrollment & Admissions Census',
                'content' => "### 🎓 Student Enrollment & Admissions Census\n\n"
                    . "> [!NOTE]\n"
                    . "> **[DATA_SPARSE_WARNING]**: No active student records found in this school tenant.",
                'metrics' => ['total_students' => 0],
                'verified' => true,
            ];
        }

        $activeCount = 0;
        $maleCount = 0;
        $femaleCount = 0;
        $classDistribution = [];

        foreach ($students as $s) {
            if (($s['status'] ?? 'active') === 'active') {
                $activeCount++;
            }
            $gender = strtolower((string) ($s['gender'] ?? ''));
            if ($gender === 'male' || $gender === 'm') {
                $maleCount++;
            } elseif ($gender === 'female' || $gender === 'f') {
                $femaleCount++;
            }
            $className = $s['class_name'] ?? 'Unassigned';
            $classDistribution[$className] = ($classDistribution[$className] ?? 0) + 1;
        }

        ksort($classDistribution);

        $distRows = '';
        foreach ($classDistribution as $cName => $cnt) {
            $pct = round(($cnt / $totalStudents) * 100, 1);
            $distRows .= "| {$cName} | {$cnt} | {$pct}% |\n";
        }

        $markdown = "### 🎓 Student Enrollment & Admissions Census\n\n"
            . "`[VERIFIED_STATISTICS]` *Accurate to active database student roster.*\n\n"
            . "| Metric | Count | Ratio |\n"
            . "|---|---|---|\n"
            . "| **Total Registered Students** | " . number_format($totalStudents) . " | 100.0% |\n"
            . "| **Active Enrolled Students** | " . number_format($activeCount) . " | " . round(($activeCount / $totalStudents) * 100, 1) . "% |\n"
            . "| **Male Students** | {$maleCount} | " . round(($maleCount / $totalStudents) * 100, 1) . "% |\n"
            . "| **Female Students** | {$femaleCount} | " . round(($femaleCount / $totalStudents) * 100, 1) . "% |\n\n"
            . "#### 🏫 Grade Enrollment Distribution\n\n"
            . "| Class | Student Count | Share |\n"
            . "|---|---|---|\n"
            . $distRows . "\n";

        return [
            'success' => true,
            'report_type' => 'admissions',
            'title' => 'Student Enrollment & Admissions Census',
            'content' => $markdown,
            'metrics' => [
                'total_students' => $totalStudents,
                'active_students' => $activeCount,
                'male_students' => $maleCount,
                'female_students' => $femaleCount,
            ],
            'verified' => true,
        ];
    }

    /**
     * Examination Performance Report.
     */
    private function buildExamPerformanceReport(int $schoolId, int $userId, string $roleSlug): array
    {
        $examStats = Database::fetch("
            SELECT COUNT(*) AS total_marks_recorded,
                   COALESCE(AVG(marks_obtained), 0.0) AS avg_score,
                   COALESCE(MAX(marks_obtained), 0.0) AS max_score,
                   COALESCE(MIN(marks_obtained), 0.0) AS min_score
            FROM exam_marks
            WHERE school_id = ?
        ", [$schoolId]) ?: [];

        $totalMarks = (int) ($examStats['total_marks_recorded'] ?? 0);

        if ($totalMarks === 0) {
            return [
                'success' => true,
                'report_type' => 'exam_performance',
                'title' => 'Institutional Academic & Examination Performance Review',
                'content' => "### 📝 Academic & Examination Performance Review\n\n"
                    . "> [!NOTE]\n"
                    . "> **[DATA_SPARSE_WARNING]**: No examination score records have been published in the database for this institution yet.",
                'metrics' => ['total_marks' => 0],
                'verified' => true,
            ];
        }

        $avgScore = round((float) $examStats['avg_score'], 1);
        $maxScore = round((float) $examStats['max_score'], 1);

        $markdown = "### 📝 Academic & Examination Performance Review\n\n"
            . "`[VERIFIED_STATISTICS]` *Compiled from verified term examination score entries.*\n\n"
            . "| Academic Metric | Value |\n"
            . "|---|---|\n"
            . "| **Total Graded Submissions** | " . number_format($totalMarks) . " |\n"
            . "| **Mean Examination Score** | **{$avgScore} / 100** |\n"
            . "| **Highest Score Recorded** | **{$maxScore} / 100** |\n\n"
            . "#### 💡 Performance Summary\n"
            . "- Institution-wide academic average is **{$avgScore}%**.\n"
            . "- Use the Predictive Analytics suite to identify students at risk of academic probation.\n";

        return [
            'success' => true,
            'report_type' => 'exam_performance',
            'title' => 'Institutional Academic & Examination Performance Review',
            'content' => $markdown,
            'metrics' => [
                'total_marks' => $totalMarks,
                'average_score' => $avgScore,
                'max_score' => $maxScore,
            ],
            'verified' => true,
        ];
    }

    /**
     * Pending Tasks & Operational Backlog Report.
     */
    private function buildPendingTasksReport(int $schoolId, int $userId, string $roleSlug): array
    {
        $today = date('Y-m-d');

        // Missing attendance registers today
        $totalClasses = (int) Database::fetchValue('SELECT COUNT(*) FROM classes WHERE school_id = ?', [$schoolId]);
        $submittedClasses = (int) Database::fetchValue("
            SELECT COUNT(DISTINCT s.class_id)
            FROM student_attendance sa
            JOIN students s ON s.id = sa.student_id
            WHERE sa.school_id = ? AND sa.attendance_date = ?
        ", [$schoolId, $today]);
        $unsubmittedAttendance = max(0, $totalClasses - $submittedClasses);

        // Overdue fee invoices
        $overdueInvoices = (int) Database::fetchValue("
            SELECT COUNT(*) FROM student_fee_invoices 
            WHERE school_id = ? AND status IN ('unpaid', 'partially_paid', 'partial') AND due_date < ?
        ", [$schoolId, $today]);

        // Unapproved staff leave applications
        $pendingLeaves = (int) (Database::fetchValue("
            SELECT COUNT(*) FROM leave_requests WHERE school_id = ? AND status = 'pending'
        ", [$schoolId]) ?? 0);

        $markdown = "### 📋 Institutional Operational Backlog & Action Items\n\n"
            . "`[VERIFIED_STATISTICS]` *Real-time operational health monitor as of " . date('F j, Y, g:i A') . "*\n\n"
            . "| Priority Area | Status | Count | Recommended Action |\n"
            . "|---|---|---|---|\n"
            . "| **Today's Attendance Registers** | " . ($unsubmittedAttendance > 0 ? "⚠️ Unsubmitted" : "✅ Complete") . " | {$unsubmittedAttendance} of {$totalClasses} pending | Send reminder to section teachers |\n"
            . "| **Overdue Student Fee Invoices** | " . ($overdueInvoices > 0 ? "⚠️ Overdue" : "✅ Clear") . " | {$overdueInvoices} invoices | Dispatch automated reminder cycle |\n"
            . "| **Pending Staff Leave Approvals** | " . ($pendingLeaves > 0 ? "ℹ️ Pending Review" : "✅ None") . " | {$pendingLeaves} requests | Review in HR > Leave Approvals |\n\n";

        return [
            'success' => true,
            'report_type' => 'pending_tasks',
            'title' => 'Institutional Operational Backlog & Action Items',
            'content' => $markdown,
            'metrics' => [
                'unsubmitted_attendance' => $unsubmittedAttendance,
                'overdue_invoices' => $overdueInvoices,
                'pending_leaves' => $pendingLeaves,
            ],
            'verified' => true,
        ];
    }

    /**
     * Institutional Overview Report fallback.
     */
    private function buildInstitutionalOverviewReport(int $schoolId, int $userId, string $roleSlug): array
    {
        $school = Database::fetch('SELECT name, code FROM schools WHERE id = ?', [$schoolId]);
        $schoolName = $school['name'] ?? 'School Institution';

        $totalStudents = (int) Database::fetchValue('SELECT COUNT(*) FROM students WHERE school_id = ?', [$schoolId]);
        $totalTeachers = (int) Database::fetchValue('SELECT COUNT(*) FROM staff WHERE school_id = ? AND role = "teacher"', [$schoolId]);
        $totalClasses = (int) Database::fetchValue('SELECT COUNT(*) FROM classes WHERE school_id = ?', [$schoolId]);

        $markdown = "### 🏛️ {$schoolName} — Executive Snapshot\n\n"
            . "`[VERIFIED_STATISTICS]` *Summary of institution metrics.*\n\n"
            . "| Key Indicator | Value |\n"
            . "|---|---|\n"
            . "| **Enrolled Students** | " . number_format($totalStudents) . " |\n"
            . "| **Faculty Teachers** | " . number_format($totalTeachers) . " |\n"
            . "| **Academic Classes** | " . number_format($totalClasses) . " |\n\n"
            . "💡 *You can ask for specific reports like:*\n"
            . "- *\"Show attendance trends for the last 30 days\"*\n"
            . "- *\"Summarize fee collections and overdue arrears\"*\n"
            . "- *\"Give me admissions demographic breakdown\"*\n"
            . "- *\"Show academic examination performance\"*\n"
            . "- *\"List pending operational tasks\"*\n";

        return [
            'success' => true,
            'report_type' => 'overview',
            'title' => "{$schoolName} — Executive Snapshot",
            'content' => $markdown,
            'metrics' => [
                'total_students' => $totalStudents,
                'total_teachers' => $totalTeachers,
                'total_classes' => $totalClasses,
            ],
            'verified' => true,
        ];
    }
}
