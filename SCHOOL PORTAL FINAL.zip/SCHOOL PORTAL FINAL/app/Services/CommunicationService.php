<?php

declare(strict_types=1);

namespace App\Services;

use App\Jobs\SendWhatsAppBroadcastJob;
use Core\Auth;
use Core\Database;
use Core\Queue\QueueManager;
use Core\TenantGuard;

final class CommunicationService
{
    /**
     * Dispatch an asynchronous bulk WhatsApp alert to hundreds/thousands of parents/students.
     * Pushes to the background queue immediately without stalling HTTP web workers.
     *
     * @param int $schoolId
     * @param array<int, array{phone: string, name: string, student_id?: int}> $recipients
     * @param string $templateName WhatsApp Pre-Approved HSM Template name (e.g. 'fee_due_reminder')
     * @param array<string, string> $templateParameters Dynamic merge parameters
     * @param string $fallbackMessage Fallback text message
     * @param int|null $dispatchedBy User ID of sender
     * @return int Asynchronous Job ID
     */
    public function dispatchMassWhatsAppBroadcast(
        int $schoolId,
        array $recipients,
        string $templateName,
        array $templateParameters,
        string $fallbackMessage,
        ?int $dispatchedBy = null
    ): int {
        if ($schoolId <= 0) {
            throw new \InvalidArgumentException('Valid tenant school context is required.');
        }

        if (empty($recipients)) {
            throw new \InvalidArgumentException('Recipient list cannot be empty.');
        }

        $userId = $dispatchedBy ?? (int) Auth::id();

        // Instantiate Job payload
        $job = new SendWhatsAppBroadcastJob(
            schoolId: $schoolId,
            recipients: $recipients,
            templateName: $templateName,
            templateParameters: $templateParameters,
            fallbackMessage: $fallbackMessage,
            dispatchedBy: $userId
        );

        // Dispatch to 'notifications' queue channel
        $jobId = QueueManager::dispatch($job, 'notifications');

        // Audit the dispatch action
        auditLog('communication.whatsapp_dispatch', 'communication', 'platform_jobs', $jobId, null, [
            'recipients_count' => count($recipients),
            'template' => $templateName,
            'queue' => 'notifications',
        ]);

        return $jobId;
    }

    /**
     * Query delivery metrics for tenant communication.
     *
     * @param int $schoolId
     * @return array{total_sent: int, delivered: int, failed: int}
     */
    public function getDeliveryStats(int $schoolId): array
    {
        $row = Database::fetch(
            'SELECT 
                COUNT(*) AS total_sent,
                COUNT(CASE WHEN status = "delivered" THEN 1 END) AS delivered,
                COUNT(CASE WHEN status = "failed" THEN 1 END) AS failed
             FROM communication_logs 
             WHERE school_id = ?',
            [$schoolId]
        );

        return [
            'total_sent' => (int) ($row['total_sent'] ?? 0),
            'delivered'  => (int) ($row['delivered'] ?? 0),
            'failed'     => (int) ($row['failed'] ?? 0),
        ];
    }
}
