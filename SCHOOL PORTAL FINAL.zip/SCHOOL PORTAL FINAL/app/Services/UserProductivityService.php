<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class UserProductivityService
{
    private static bool $schemaChecked = false;

    public function __construct()
    {
        $this->ensureSchema();
    }

    /**
     * Auto-provision user_preferences table for configurable widgets, saved filters, and recent records.
     */
    public function ensureSchema(): void
    {
        if (self::$schemaChecked) {
            return;
        }

        Database::execute("
            CREATE TABLE IF NOT EXISTS user_preferences (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT UNSIGNED NOT NULL,
                school_id BIGINT UNSIGNED NOT NULL,
                preference_key VARCHAR(100) NOT NULL,
                preference_value LONGTEXT NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                UNIQUE KEY uq_user_pref (user_id, preference_key),
                INDEX idx_user_school (user_id, school_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        self::$schemaChecked = true;
    }

    /**
     * Default dashboard widgets configuration.
     */
    public function getDefaultDashboardWidgets(): array
    {
        return [
            'widget_checklist' => true,
            'widget_attendance' => true,
            'widget_action_items' => true,
            'widget_kpis' => true,
            'widget_ai_analytics' => true,
            'widget_fee_chart' => true,
            'widget_quick_actions' => true,
            'widget_recent_activity' => true
        ];
    }

    /**
     * Get user dashboard widget preferences with fallbacks to defaults.
     */
    public function getDashboardWidgets(int $userId, int $schoolId): array
    {
        $defaults = $this->getDefaultDashboardWidgets();
        if ($userId <= 0 || $schoolId <= 0) {
            return $defaults;
        }

        $row = Database::fetch("
            SELECT preference_value FROM user_preferences 
            WHERE user_id = ? AND school_id = ? AND preference_key = 'dashboard_widgets'
            LIMIT 1
        ", [$userId, $schoolId]);

        if (!$row || empty($row['preference_value'])) {
            return $defaults;
        }

        $saved = json_decode((string)$row['preference_value'], true);
        if (!is_array($saved)) {
            return $defaults;
        }

        return array_merge($defaults, $saved);
    }

    /**
     * Save user dashboard widget preferences.
     */
    public function saveDashboardWidgets(int $userId, int $schoolId, array $widgets): bool
    {
        if ($userId <= 0 || $schoolId <= 0) {
            return false;
        }

        $defaults = $this->getDefaultDashboardWidgets();
        $cleaned = [];
        foreach (array_keys($defaults) as $key) {
            $cleaned[$key] = !empty($widgets[$key]);
        }

        return $this->setPreference($userId, $schoolId, 'dashboard_widgets', json_encode($cleaned));
    }

    /**
     * Get recent records viewed by the user.
     */
    public function getRecentRecords(int $userId, int $schoolId): array
    {
        if ($userId <= 0 || $schoolId <= 0) {
            return [];
        }

        $row = Database::fetch("
            SELECT preference_value FROM user_preferences 
            WHERE user_id = ? AND school_id = ? AND preference_key = 'recent_records'
            LIMIT 1
        ", [$userId, $schoolId]);

        if (!$row || empty($row['preference_value'])) {
            return [];
        }

        $records = json_decode((string)$row['preference_value'], true);
        return is_array($records) ? $records : [];
    }

    /**
     * Record a recently visited record (capped at 10 items, deduplicated).
     */
    public function addRecentRecord(int $userId, int $schoolId, array $record): array
    {
        if ($userId <= 0 || $schoolId <= 0 || empty($record['url']) || empty($record['title'])) {
            return [];
        }

        $current = $this->getRecentRecords($userId, $schoolId);

        // Normalize new record
        $newEntry = [
            'type' => $record['type'] ?? 'record',
            'id' => (int)($record['id'] ?? 0),
            'title' => trim((string)$record['title']),
            'subtitle' => trim((string)($record['subtitle'] ?? '')),
            'url' => trim((string)$record['url']),
            'badge' => trim((string)($record['badge'] ?? '')),
            'badge_color' => $record['badge_color'] ?? 'primary',
            'icon' => $record['icon'] ?? 'file-text',
            'viewed_at' => date('Y-m-d H:i:s')
        ];

        // Deduplicate against existing URL or ID+Type
        $filtered = array_filter($current, function ($item) use ($newEntry) {
            if ($item['url'] === $newEntry['url']) {
                return false;
            }
            if ($newEntry['id'] > 0 && !empty($item['id']) && $item['id'] === $newEntry['id'] && $item['type'] === $newEntry['type']) {
                return false;
            }
            return true;
        });

        // Prepend new entry and cap at 10
        array_unshift($filtered, $newEntry);
        $updated = array_slice($filtered, 0, 10);

        $this->setPreference($userId, $schoolId, 'recent_records', json_encode($updated));
        return $updated;
    }

    /**
     * Get saved filters for an entity (e.g. students, invoices, staff) or all entities if empty.
     */
    public function getSavedFilters(int $userId, int $schoolId, string $entity = ''): array
    {
        if ($userId <= 0 || $schoolId <= 0) {
            return [];
        }

        if ($entity === '') {
            $rows = Database::fetchAll("
                SELECT preference_value FROM user_preferences 
                WHERE user_id = ? AND school_id = ? AND preference_key LIKE 'saved_filters_%'
            ", [$userId, $schoolId]);
            $all = [];
            foreach ($rows as $r) {
                $decoded = json_decode((string)$r['preference_value'], true);
                if (is_array($decoded)) {
                    foreach ($decoded as $item) {
                        $all[] = $item;
                    }
                }
            }
            return $all;
        }

        $key = 'saved_filters_' . preg_replace('/[^a-z0-9_]/', '', strtolower($entity));
        $row = Database::fetch("
            SELECT preference_value FROM user_preferences 
            WHERE user_id = ? AND school_id = ? AND preference_key = ?
            LIMIT 1
        ", [$userId, $schoolId, $key]);

        if (!$row || empty($row['preference_value'])) {
            return [];
        }

        $filters = json_decode((string)$row['preference_value'], true);
        return is_array($filters) ? $filters : [];
    }

    /**
     * Save a named search filter for an entity.
     */
    public function saveFilter(int $userId, int $schoolId, string $entity, string $name, array $criteria): array
    {
        if ($userId <= 0 || $schoolId <= 0 || trim($name) === '') {
            return [];
        }

        $filters = $this->getSavedFilters($userId, $schoolId, $entity);
        $id = uniqid('flt_', true);

        $newFilter = [
            'id' => $id,
            'name' => trim($name),
            'criteria' => $criteria,
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Replace if same name, else append
        $updated = [];
        $replaced = false;
        foreach ($filters as $f) {
            if (strtolower($f['name']) === strtolower($name)) {
                $updated[] = $newFilter;
                $replaced = true;
            } else {
                $updated[] = $f;
            }
        }
        if (!$replaced) {
            $updated[] = $newFilter;
        }

        $key = 'saved_filters_' . preg_replace('/[^a-z0-9_]/', '', strtolower($entity));
        $this->setPreference($userId, $schoolId, $key, json_encode($updated));

        return $newFilter;
    }

    /**
     * Delete a saved filter by ID. Entity is optional; if omitted, searched across all saved_filters.
     */
    public function deleteSavedFilter(int $userId, int $schoolId, string $filterId, string $entity = ''): bool
    {
        if ($userId <= 0 || $schoolId <= 0 || trim($filterId) === '') {
            return false;
        }

        if ($entity !== '') {
            $filters = $this->getSavedFilters($userId, $schoolId, $entity);
            $remaining = array_values(array_filter($filters, fn($f) => ($f['id'] ?? '') !== $filterId));

            $key = 'saved_filters_' . preg_replace('/[^a-z0-9_]/', '', strtolower($entity));
            return $this->setPreference($userId, $schoolId, $key, json_encode($remaining));
        }

        // Search across all saved_filters_% keys for this user
        $rows = Database::fetchAll("
            SELECT preference_key, preference_value FROM user_preferences 
            WHERE user_id = ? AND school_id = ? AND preference_key LIKE 'saved_filters_%'
        ", [$userId, $schoolId]);

        $deletedAny = false;
        foreach ($rows as $r) {
            $decoded = json_decode((string)$r['preference_value'], true);
            if (is_array($decoded)) {
                $remaining = array_values(array_filter($decoded, fn($f) => ($f['id'] ?? '') !== $filterId));
                if (count($remaining) !== count($decoded)) {
                    $this->setPreference($userId, $schoolId, $r['preference_key'], json_encode($remaining));
                    $deletedAny = true;
                }
            }
        }

        return $deletedAny;
    }

    /**
     * Alias for deleteSavedFilter to match saveFilter naming.
     */
    public function deleteFilter(int $userId, int $schoolId, string $filterId, string $entity = ''): bool
    {
        return $this->deleteSavedFilter($userId, $schoolId, $filterId, $entity);
    }

    /**
     * Generic preference setter.
     */
    public function setPreference(int $userId, int $schoolId, string $key, string $value): bool
    {
        $existing = Database::fetch("
            SELECT id FROM user_preferences 
            WHERE user_id = ? AND preference_key = ?
            LIMIT 1
        ", [$userId, $key]);

        if ($existing) {
            Database::execute("
                UPDATE user_preferences 
                SET preference_value = ?, school_id = ?, updated_at = NOW() 
                WHERE id = ?
            ", [$value, $schoolId, (int)$existing['id']]);
        } else {
            Database::insert("
                INSERT INTO user_preferences (user_id, school_id, preference_key, preference_value, created_at, updated_at)
                VALUES (?, ?, ?, ?, NOW(), NOW())
            ", [$userId, $schoolId, $key, $value]);
        }

        return true;
    }

    /**
     * Generic preference getter.
     */
    public function getPreference(int $userId, int $schoolId, string $key, ?string $default = null): ?string
    {
        $row = Database::fetch("
            SELECT preference_value FROM user_preferences 
            WHERE user_id = ? AND school_id = ? AND preference_key = ?
            LIMIT 1
        ", [$userId, $schoolId, $key]);

        return $row ? (string)$row['preference_value'] : $default;
    }
}
