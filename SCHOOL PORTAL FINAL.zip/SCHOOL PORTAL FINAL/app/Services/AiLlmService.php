<?php

declare(strict_types=1);

namespace App\Services;

/**
 * AiLlmService
 * Handles communication with Google Gemini API & OpenAI API via native PHP cURL.
 * Includes support for streaming (Server-Sent Events) and intelligent contextual fallback.
 */
final class AiLlmService
{
    private array $config;

    public function __construct()
    {
        $configFile = base_path('config/ai.php');
        $this->config = file_exists($configFile) ? require $configFile : [];
    }

    /**
     * Send chat completion request to the active LLM provider.
     *
     * @param string $systemPrompt System instructions and RAG database context
     * @param array $messages Conversation history: [['role' => 'user'|'assistant', 'content' => '...']]
     * @param string|null $overrideProvider Optional provider override ('gemini' or 'openai')
     * @param bool $isAdmin Whether the requesting user is an administrator
     * @return array{success: bool, content: string, provider: string, model: string, usage: array, configured?: bool}
     */
    public function complete(string $systemPrompt, array $messages, ?string $overrideProvider = null, bool $isAdmin = true): array
    {
        $provider = $overrideProvider ?: ($this->config['provider'] ?? 'gemini');

        // Check if API key is present for the requested provider
        $hasKey = $this->hasApiKey($provider);

        if (!$hasKey) {
            // Check if alternate provider has key
            $alternate = $provider === 'gemini' ? 'openai' : 'gemini';
            if ($this->hasApiKey($alternate)) {
                $provider = $alternate;
                $hasKey = true;
            }
        }

        if (!$hasKey) {
            // If explicit mock provider is requested for testing, synthesize test response
            if ($overrideProvider === 'mock' || $overrideProvider === 'mock-test') {
                $reply = $this->synthesizeContextualResponse($systemPrompt, $messages);
                return [
                    'success' => true,
                    'content' => $reply,
                    'provider' => 'mock-test',
                    'model' => 'test-synthesizer',
                    'usage' => ['total_tokens' => strlen($reply) / 4],
                ];
            }

            // Administrator setup guidance vs. End-user maintenance notification
            if ($isAdmin) {
                $setupMessage = "### ⚙️ AI Provider Not Configured\n\n"
                    . "The School Portal AI Assistant is ready, but requires an API key in your server environment to generate live responses.\n\n"
                    . "**Administrator Setup Instructions:**\n"
                    . "1. Open the `.env` file in your application root directory.\n"
                    . "2. Configure your preferred AI provider:\n"
                    . "   ```ini\n"
                    . "   # For Google Gemini (Recommended)\n"
                    . "   AI_PROVIDER=gemini\n"
                    . "   GEMINI_API_KEY=your_gemini_api_key_here\n"
                    . "   GEMINI_MODEL=gemini-1.5-flash\n\n"
                    . "   # Or for OpenAI\n"
                    . "   # AI_PROVIDER=openai\n"
                    . "   # OPENAI_API_KEY=your_openai_api_key_here\n"
                    . "   ```\n"
                    . "3. Save the `.env` file. The AI Copilot will automatically activate on your next message.\n\n"
                    . "*Note: Student and parent users should contact their school administrator to enable AI features.*";
            } else {
                $setupMessage = "### ℹ️ AI Assistant Unavailable\n\n"
                    . "The School Portal AI Assistant is currently undergoing configuration by system administrators.\n\n"
                    . "Please check back shortly or contact your school administrator to activate AI features for your account.";
            }

            return [
                'success' => true,
                'configured' => false,
                'content' => $setupMessage,
                'provider' => 'not-configured',
                'model' => 'none',
                'usage' => ['total_tokens' => 0],
            ];
        }

        $privacyService = new AiPrivacyService();
        $systemPrompt = $privacyService->redactPii($systemPrompt);
        foreach ($messages as $idx => $msg) {
            if (isset($msg['content'])) {
                $messages[$idx]['content'] = $privacyService->redactPii((string) $msg['content']);
            }
        }

        if ($provider === 'openai') {
            return $this->callOpenAi($systemPrompt, $messages);
        }

        return $this->callGemini($systemPrompt, $messages);
    }

    /**
     * Test real provider connectivity and model availability safely.
     *
     * @param string|null $overrideProvider
     * @return array{configured: bool, provider: string, model: string, reachable: bool, status_code: int, latency_ms: float, message: string}
     */
    public function testProviderConnectivity(?string $overrideProvider = null): array
    {
        $provider = $overrideProvider ?: ($this->config['provider'] ?? 'gemini');
        $hasKey = $this->hasApiKey($provider);

        if (!$hasKey) {
            $model = $provider === 'gemini' 
                ? ($this->config['gemini']['model'] ?? 'gemini-1.5-flash') 
                : ($this->config['openai']['model'] ?? 'gpt-4o-mini');

            return [
                'configured' => false,
                'provider' => $provider,
                'model' => $model,
                'reachable' => false,
                'status_code' => 0,
                'latency_ms' => 0.0,
                'message' => "API key is not configured for provider '{$provider}' in .env. Configure GEMINI_API_KEY or OPENAI_API_KEY.",
            ];
        }

        $start = microtime(true);

        if ($provider === 'openai') {
            $apiKey = $this->config['openai']['api_key'] ?? '';
            $model = $this->config['openai']['model'] ?? 'gpt-4o-mini';
            $endpoint = 'https://api.openai.com/v1/models';

            $ch = curl_init($endpoint);
            curl_setopt_array($ch, [
                CURLOPT_HTTPGET => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $apiKey,
                ],
                CURLOPT_TIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            $latency = round((microtime(true) - $start) * 1000, 2);

            $reachable = !$err && $httpCode >= 200 && $httpCode < 300;
            $msg = $reachable 
                ? "OpenAI API is reachable and authorized. Model '{$model}' ready." 
                : "OpenAI connection failed: " . $this->maskSecret($err ?: "HTTP {$httpCode}");

            return [
                'configured' => true,
                'provider' => 'openai',
                'model' => $model,
                'reachable' => $reachable,
                'status_code' => $httpCode,
                'latency_ms' => $latency,
                'message' => $msg,
            ];
        }

        // Gemini Connectivity Check
        $apiKey = $this->config['gemini']['api_key'] ?? '';
        $model = $this->config['gemini']['model'] ?? 'gemini-1.5-flash';
        $endpoint = rtrim($this->config['gemini']['endpoint'] ?? 'https://generativelanguage.googleapis.com/v1beta/models', '/');
        $url = "{$endpoint}/{$model}";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'x-goog-api-key: ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        $latency = round((microtime(true) - $start) * 1000, 2);

        $reachable = !$err && $httpCode >= 200 && $httpCode < 300;
        $msg = $reachable 
            ? "Google Gemini API is reachable. Model '{$model}' is verified available." 
            : "Gemini connection failed: " . $this->maskSecret($err ?: "HTTP {$httpCode}");

        return [
            'configured' => true,
            'provider' => 'gemini',
            'model' => $model,
            'reachable' => $reachable,
            'status_code' => $httpCode,
            'latency_ms' => $latency,
            'message' => $msg,
        ];
    }

    /**
     * Stream response chunks via callback (for SSE endpoints).
     *
     * @param string $systemPrompt
     * @param array $messages
     * @param callable $onChunk Callable receiving string $chunk
     * @param string|null $overrideProvider
     * @param bool $isAdmin
     */
    public function stream(string $systemPrompt, array $messages, callable $onChunk, ?string $overrideProvider = null, bool $isAdmin = true): void
    {
        $provider = $overrideProvider ?: ($this->config['provider'] ?? 'gemini');

        if (!$this->hasApiKey($provider)) {
            $alternate = $provider === 'gemini' ? 'openai' : 'gemini';
            if ($this->hasApiKey($alternate)) {
                $provider = $alternate;
            }
        }

        if (!$this->hasApiKey($provider)) {
            if ($overrideProvider === 'mock' || $overrideProvider === 'mock-test') {
                $fullText = $this->synthesizeContextualResponse($systemPrompt, $messages);
                $words = explode(' ', $fullText);
                foreach ($words as $word) {
                    $onChunk($word . ' ');
                    usleep(15000);
                }
                return;
            }

            if ($isAdmin) {
                $setupNotice = "⚙️ **AI Provider Not Configured**: Please configure `GEMINI_API_KEY` or `OPENAI_API_KEY` in your `.env` file to enable live responses.";
            } else {
                $setupNotice = "ℹ️ **AI Assistant Unavailable**: The School Portal AI Assistant is currently disabled. Please contact your school administrator.";
            }
            $onChunk($setupNotice);
            return;
        }

        if ($provider === 'openai') {
            $this->streamOpenAi($systemPrompt, $messages, $onChunk);
        } else {
            $this->streamGemini($systemPrompt, $messages, $onChunk);
        }
    }

    /**
     * Mask any API keys or secrets from strings to prevent accidental leakage in logs/UI.
     */
    public function maskSecret(string $text): string
    {
        return preg_replace('/(AIza[0-9A-Za-z\-_]{30,50}|sk-[a-zA-Z0-9_\-]{20,})/', '[REDACTED_SECRET]', $text);
    }

    /**
     * Normalize conversation turns for Google Gemini API:
     * - Discards empty parts
     * - Merges consecutive turns from the same role
     * - Ensures initial turn is from 'user'
     */
    private function normalizeGeminiContents(array $messages): array
    {
        $normalized = [];
        $currentRole = null;
        $currentParts = [];

        foreach ($messages as $msg) {
            $text = trim((string) ($msg['content'] ?? ''));
            if ($text === '') {
                continue;
            }

            $role = ($msg['role'] ?? 'user') === 'assistant' ? 'model' : 'user';

            if ($currentRole === $role) {
                $currentParts[] = ['text' => $text];
            } else {
                if ($currentRole !== null && !empty($currentParts)) {
                    $normalized[] = ['role' => $currentRole, 'parts' => $currentParts];
                }
                $currentRole = $role;
                $currentParts = [['text' => $text]];
            }
        }

        if ($currentRole !== null && !empty($currentParts)) {
            $normalized[] = ['role' => $currentRole, 'parts' => $currentParts];
        }

        // Gemini contents must start with a 'user' turn
        if (!empty($normalized) && $normalized[0]['role'] === 'model') {
            array_unshift($normalized, [
                'role' => 'user',
                'parts' => [['text' => 'Hello']],
            ]);
        }

        if (empty($normalized)) {
            $normalized[] = [
                'role' => 'user',
                'parts' => [['text' => 'Hello']],
            ];
        }

        return $normalized;
    }

    /**
     * Check if API key is configured.
     */
    public function hasApiKey(string $provider): bool
    {
        $cfg = $this->config[$provider] ?? [];
        $key = $cfg['api_key'] ?? '';
        return !empty($key) && $key !== 'YOUR_API_KEY' && strlen(trim($key)) > 5;
    }

    /**
     * Call Google Gemini API (generateContent).
     */
    private function callGemini(string $systemPrompt, array $messages): array
    {
        $cfg = $this->config['gemini'] ?? [];
        $apiKey = $cfg['api_key'] ?? '';
        $model = $cfg['model'] ?? 'gemini-1.5-flash';
        $endpoint = rtrim($cfg['endpoint'] ?? 'https://generativelanguage.googleapis.com/v1beta/models', '/');
        // Secure header-based authentication: prevents API key leakage in URL query strings and proxy logs
        $url = "{$endpoint}/{$model}:generateContent";

        // Format normalized contents
        $contents = $this->normalizeGeminiContents($messages);

        $payload = [
            'system_instruction' => [
                'parts' => [['text' => $systemPrompt]],
            ],
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => (float) ($this->config['temperature'] ?? 0.25),
                'maxOutputTokens' => (int) ($this->config['max_tokens'] ?? 1024),
                'topP' => (float) ($this->config['top_p'] ?? 0.95),
            ],
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'x-goog-api-key: ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400 || !$response) {
            $errDetails = '';
            if ($response) {
                $errJson = json_decode((string) $response, true);
                if (!empty($errJson['error']['message'])) {
                    $errDetails = ' - ' . $this->maskSecret((string) $errJson['error']['message']);
                }
            }
            $errSnippet = ($err ?: "HTTP {$httpCode}") . $errDetails;
            error_log("Gemini API Error: " . $this->maskSecret($errSnippet));
            return [
                'success' => false,
                'content' => "⚠️ **AI Provider Communication Notice**\n\nThe AI provider could not complete this request ({$errSnippet}).\n\nPossible reasons:\n- The API key may have expired or reached its quota limit.\n- Network connectivity or firewall restriction to `generativelanguage.googleapis.com`.\n\nPlease verify your `.env` configuration or try again in a few moments.",
                'provider' => 'gemini',
                'model' => $model,
                'usage' => [],
            ];
        }

        $data = json_decode((string) $response, true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        if ($text === '') {
            $finishReason = $data['candidates'][0]['finishReason'] ?? 'UNKNOWN';
            if ($finishReason === 'SAFETY') {
                $text = "I am unable to answer this question due to safety policies.";
            } else {
                $text = "The AI model completed the request but did not return text content.";
            }
        }

        return [
            'success' => true,
            'content' => trim($text),
            'provider' => 'gemini',
            'model' => $model,
            'usage' => $data['usageMetadata'] ?? [],
        ];
    }

    /**
     * Call OpenAI API (chat/completions).
     */
    private function callOpenAi(string $systemPrompt, array $messages): array
    {
        $cfg = $this->config['openai'] ?? [];
        $apiKey = $cfg['api_key'] ?? '';
        $model = $cfg['model'] ?? 'gpt-4o-mini';
        $endpoint = $cfg['endpoint'] ?? 'https://api.openai.com/v1/chat/completions';

        $apiMessages = [
            ['role' => 'system', 'content' => $systemPrompt],
        ];

        foreach ($messages as $msg) {
            $apiMessages[] = [
                'role' => ($msg['role'] ?? 'user') === 'assistant' ? 'assistant' : 'user',
                'content' => (string) ($msg['content'] ?? ''),
            ];
        }

        $payload = [
            'model' => $model,
            'messages' => $apiMessages,
            'temperature' => (float) ($this->config['temperature'] ?? 0.25),
            'max_tokens' => (int) ($this->config['max_tokens'] ?? 1024),
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400 || !$response) {
            $errSnippet = $err ?: "HTTP {$httpCode}";
            error_log("OpenAI API Error: {$errSnippet}");
            return [
                'success' => false,
                'content' => "⚠️ **AI Provider Communication Notice**\n\nThe AI provider could not complete this request ({$errSnippet}).\n\nPossible reasons:\n- The OpenAI API key may be invalid or rate-limited.\n- Network connectivity issue to `api.openai.com`.\n\nPlease verify your `.env` configuration or try again in a few moments.",
                'provider' => 'openai',
                'model' => $model,
                'usage' => [],
            ];
        }

        $data = json_decode((string) $response, true);
        $text = $data['choices'][0]['message']['content'] ?? '';

        return [
            'success' => true,
            'content' => trim($text),
            'provider' => 'openai',
            'model' => $model,
            'usage' => $data['usage'] ?? [],
        ];
    }

    /**
     * Stream from OpenAI API via Server-Sent Events.
     */
    private function streamOpenAi(string $systemPrompt, array $messages, callable $onChunk): void
    {
        $cfg = $this->config['openai'] ?? [];
        $apiKey = $cfg['api_key'] ?? '';
        $model = $cfg['model'] ?? 'gpt-4o-mini';
        $endpoint = $cfg['endpoint'] ?? 'https://api.openai.com/v1/chat/completions';

        $apiMessages = [['role' => 'system', 'content' => $systemPrompt]];
        foreach ($messages as $msg) {
            $apiMessages[] = [
                'role' => ($msg['role'] ?? 'user') === 'assistant' ? 'assistant' : 'user',
                'content' => (string) ($msg['content'] ?? ''),
            ];
        }

        $payload = [
            'model' => $model,
            'messages' => $apiMessages,
            'stream' => true,
            'temperature' => 0.25,
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_WRITEFUNCTION => function ($ch, $data) use ($onChunk) {
                $lines = explode("\n", $data);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (str_starts_with($line, 'data: ') && $line !== 'data: [DONE]') {
                        $json = json_decode(substr($line, 6), true);
                        $delta = $json['choices'][0]['delta']['content'] ?? '';
                        if ($delta !== '') {
                            $onChunk($delta);
                        }
                    }
                }
                return strlen($data);
            },
        ]);

        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400) {
            $errSnippet = $err ?: "HTTP {$httpCode}";
            error_log("OpenAI Stream Error: {$errSnippet}");
            $onChunk("\n\n⚠️ **Stream Notice**: Communication interrupted ({$errSnippet}). Please retry.");
        }
    }

    /**
     * Stream from Gemini API.
     */
    private function streamGemini(string $systemPrompt, array $messages, callable $onChunk): void
    {
        $cfg = $this->config['gemini'] ?? [];
        $apiKey = $cfg['api_key'] ?? '';
        $model = $cfg['model'] ?? 'gemini-1.5-flash';
        $endpoint = rtrim($cfg['endpoint'] ?? 'https://generativelanguage.googleapis.com/v1beta/models', '/');
        // Secure header-based authentication
        $url = "{$endpoint}/{$model}:streamGenerateContent?alt=sse";

        $contents = $this->normalizeGeminiContents($messages);

        $payload = [
            'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => (float) ($this->config['temperature'] ?? 0.25),
                'maxOutputTokens' => (int) ($this->config['max_tokens'] ?? 1024),
                'topP' => (float) ($this->config['top_p'] ?? 0.95),
            ],
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'x-goog-api-key: ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_WRITEFUNCTION => function ($ch, $data) use ($onChunk) {
                $lines = explode("\n", $data);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (str_starts_with($line, 'data: ')) {
                        $json = json_decode(substr($line, 6), true);
                        $chunk = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
                        if ($chunk !== '') {
                            $onChunk($chunk);
                        }
                    }
                }
                return strlen($data);
            },
        ]);

        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400) {
            $errSnippet = $err ?: "HTTP {$httpCode}";
            error_log("Gemini Stream Error: " . $this->maskSecret($errSnippet));
            $onChunk("\n\n⚠️ **Stream Notice**: Communication interrupted ({$errSnippet}). Please retry.");
        }
    }

    /**
     * Intelligent Contextual Fallback Engine.
     * When external LLM APIs are offline or no API keys are yet configured in .env,
     * this engine parses the assembled database RAG context and formulates an
     * accurate, structured markdown response directly answering the user query.
     */
    private function synthesizeContextualResponse(string $systemPrompt, array $messages): string
    {
        $lastUserMsg = '';
        for ($i = count($messages) - 1; $i >= 0; $i--) {
            if (($messages[$i]['role'] ?? '') === 'user') {
                $lastUserMsg = $messages[$i]['content'] ?? '';
                break;
            }
        }

        $q = strtolower($lastUserMsg);

        // Extract context enclosed in <tenant_context>
        $context = '';
        if (preg_match('/<tenant_context>(.*?)<\/tenant_context>/s', $systemPrompt, $match)) {
            $context = trim($match[1]);
        }

        // If asking about fees / invoices
        if (preg_match('/\b(fee|fees|invoice|invoices|paid|unpaid|due|dues|balance|amount|cost|challan)\b/i', $q)) {
            if (str_contains($context, 'Child Fee Invoices') || str_contains($context, 'Personal Fee Invoices') || str_contains($context, 'Fee Invoices for')) {
                return "### 💳 Fee & Invoices Summary\n\n"
                    . "Here is the official billing record from your school profile:\n\n"
                    . $this->extractContextSection($context, ['Child Fee Invoices', 'Personal Fee Invoices', 'Fee Invoices for'])
                    . "\n\n💡 *Tip: You can download official receipt vouchers or pay online via the Finance portal.*";
            }
            if (str_contains($context, 'Institutional Financial Ledger')) {
                return "### 🏛️ Institution Finance Overview\n\n"
                    . $this->extractContextSection($context, ['Institutional Financial Ledger'])
                    . "\n\n*All records strictly reflect verified tenant transactions.*";
            }
        }

        // If asking about attendance
        if (preg_match('/\b(attendance|absent|present|percentage|leave)\b/i', $q)) {
            if (str_contains($context, 'Attendance')) {
                return "### 📅 Attendance Records\n\n"
                    . "Here are the verified attendance statistics:\n\n"
                    . $this->extractContextSection($context, ['Child Attendance Records', 'Attendance Summary', 'Attendance'])
                    . "\n\n*Records are updated daily by classroom instructors.*";
            }
        }

        // If asking about assignments
        if (preg_match('/\b(assignment|homework|project|submission)\b/i', $q)) {
            if (str_contains($context, 'Homework') || str_contains($context, 'Assignments')) {
                return "### 📚 Active Assignments\n\n"
                    . $this->extractContextSection($context, ['Active Homework', 'Assignments'])
                    . "\n\n*Please ensure assignments are submitted before 11:59 PM on the due date.*";
            }
        }

        // Greeting or generic prompt
        if (preg_match('/\b(hi|hello|hey|help|who are you|greetings)\b/i', $q) || empty($q)) {
            return "👋 Hello! I am your **CodeClove School AI Assistant**.\n\n"
                . "I have secure, real-time access to your school profile. Here is what you can ask me:\n"
                . "- 💳 *\"Is my child's fee paid?\"* or *\"Show my pending fee balance\"*\n"
                . "- 📅 *\"What is the attendance record this month?\"*\n"
                . "- 📝 *\"Are there any pending assignments due soon?\"*\n"
                . "- 🏫 *\"What is the current academic term?\"*\n\n"
                . "How can I assist you today?";
        }

        // General contextual answer
        return "### ℹ️ School Portal Assistant\n\n"
            . "Based on your verified school record:\n\n"
            . $context
            . "\n\n*If you need further assistance or changes to your records, please contact the administration desk.*";
    }

    /**
     * Helper to extract a relevant snippet from markdown context.
     */
    private function extractContextSection(string $context, array $headers): string
    {
        $lines = explode("\n", $context);
        $capturing = false;
        $snippet = [];

        foreach ($lines as $line) {
            $isTargetHeader = false;
            foreach ($headers as $h) {
                if (stripos($line, $h) !== false) {
                    $isTargetHeader = true;
                    break;
                }
            }

            if ($isTargetHeader) {
                $capturing = true;
                $snippet[] = $line;
                continue;
            }

            if ($capturing) {
                // If we hit another major heading, stop
                if (str_starts_with(trim($line), '### ') || str_starts_with(trim($line), '#### ')) {
                    break;
                }
                $snippet[] = $line;
            }
        }

        return !empty($snippet) ? trim(implode("\n", $snippet)) : $context;
    }
}
