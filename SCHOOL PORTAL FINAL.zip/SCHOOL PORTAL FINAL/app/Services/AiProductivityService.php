<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * AiProductivityService
 *
 * Provides institutional drafting, report summarization, meeting note formulation,
 * error explanation, and interactive step-by-step workflow navigation.
 */
final class AiProductivityService
{
    /**
     * Draft an official school notice or announcement.
     *
     * @param int $schoolId
     * @param string $type e.g. 'holiday', 'ptm', 'exam', 'fees', 'sports', 'general'
     * @param string $topic
     * @param string $targetAudience 'parents', 'students', 'teachers', 'all'
     * @param array $details
     * @return array{title: string, content: string, suggested_channel: string}
     */
    public function draftAnnouncement(int $schoolId, string $type, string $topic, string $targetAudience = 'all', array $details = []): array
    {
        $school = Database::fetch('SELECT name FROM schools WHERE id = ?', [$schoolId]);
        $schoolName = $school['name'] ?? 'The Administration';
        $today = date('F j, Y');

        switch ($type) {
            case 'holiday':
                $title = "Official Notice: Institutional Holiday Announcement — {$topic}";
                $content = "### 📢 {$title}\n\n"
                    . "**Date of Issuance:** {$today}\n"
                    . "**To:** All Respected Parents, Guardians, Faculty, and Students\n\n"
                    . "Dear Members of the {$schoolName} Community,\n\n"
                    . "Please be advised that all academic and administrative operations at **{$schoolName}** will remain closed on the occasion of **{$topic}**.\n\n"
                    . "**Key Information:**\n"
                    . "- **Closure Effective:** " . ($details['date'] ?? date('l, F j, Y', strtotime('+1 day'))) . "\n"
                    . "- **Resumption of Classes:** " . ($details['resume_date'] ?? date('l, F j, Y', strtotime('+2 days'))) . "\n"
                    . "- **Homework / Self-Study:** Students are encouraged to review pending classroom assignments via their student portal.\n\n"
                    . "We wish everyone a safe and restful break.\n\n"
                    . "**Warm regards,**\n\n"
                    . "*Office of the Principal*\n"
                    . "**{$schoolName}**";
                $channel = 'broadcast_sms_email';
                break;

            case 'ptm':
                $title = "Invitation: Parent-Teacher Consultation Meeting (PTM)";
                $content = "### 🏫 {$title}\n\n"
                    . "**Date of Issuance:** {$today}\n"
                    . "**To:** Parents and Guardians of All Enrolled Students\n\n"
                    . "Dear Parents & Guardians,\n\n"
                    . "You are cordially invited to attend our upcoming **Parent-Teacher Meeting (PTM)** to review your child's academic development, attendance trajectory, and classroom engagement.\n\n"
                    . "**Event Details:**\n"
                    . "- **Meeting Date:** " . ($details['date'] ?? 'Saturday, ' . date('F j, Y', strtotime('+7 days'))) . "\n"
                    . "- **Time Window:** " . ($details['time'] ?? '09:00 AM – 01:00 PM') . "\n"
                    . "- **Venue:** Main Academic Campus / Respective Section Classrooms\n\n"
                    . "Parents are requested to bring their student's portal credentials for instant digital gradebook review. Teachers look forward to meaningful consultations.\n\n"
                    . "**Cordially,**\n\n"
                    . "*Academic Department*\n"
                    . "**{$schoolName}**";
                $channel = 'parent_portal_notice';
                break;

            case 'fees':
                $title = "Important Notice: School Fee Payment Schedule & Reminder";
                $content = "### 💳 {$title}\n\n"
                    . "**Date of Issuance:** {$today}\n"
                    . "**To:** All Parents & Fee Sponsors\n\n"
                    . "Dear Parents & Guardians,\n\n"
                    . "This is a courtesy communication regarding tuition fees for the current academic term at **{$schoolName}**.\n\n"
                    . "**Schedule Highlights:**\n"
                    . "- **Standard Due Date:** " . ($details['due_date'] ?? date('F 15, Y')) . "\n"
                    . "- **Online Payment Desk:** Log in to **Parent Portal > Fees & Invoices** to view itemized challans and pay via bank transfer or credit card.\n"
                    . "- **Assistance:** For financial concessions or installment plans, please visit the bursar's office before the due date.\n\n"
                    . "Thank you for your ongoing partnership in your child's education.\n\n"
                    . "**Finance & Accounts Desk**\n"
                    . "**{$schoolName}**";
                $channel = 'email_and_portal';
                break;

            default:
                $title = "Institutional Circular: {$topic}";
                $content = "### 📌 {$title}\n\n"
                    . "**Date:** {$today}\n"
                    . "**Audience:** " . ucfirst($targetAudience) . "\n\n"
                    . "Dear Members of **{$schoolName}**,\n\n"
                    . "This circular serves to inform all stakeholders regarding **{$topic}**.\n\n"
                    . ($details['notes'] ?? "Please refer to the school portal notices for additional instructional guidelines.") . "\n\n"
                    . "For questions or clarifications, please reach out to the campus administration desk.\n\n"
                    . "**Administration Desk**\n"
                    . "**{$schoolName}**";
                $channel = 'general_announcement';
                break;
        }

        return [
            'title' => $title,
            'content' => $content,
            'suggested_channel' => $channel,
        ];
    }

    /**
     * Generate an executive briefing summarizing complex raw metrics.
     */
    public function summarizeReport(int $schoolId, string $reportTitle, array $metrics): string
    {
        $school = Database::fetch('SELECT name FROM schools WHERE id = ?', [$schoolId]);
        $schoolName = $school['name'] ?? 'School Institution';

        $summary = "### 📑 Executive Briefing: {$reportTitle}\n\n"
            . "**Institution:** {$schoolName} | **Date:** " . date('F j, Y') . "\n\n"
            . "#### 1. Strategic Highlights\n"
            . "- Operational indicators reflect steady baseline activity across academic cohorts.\n";

        foreach ($metrics as $k => $v) {
            $formattedKey = ucwords(str_replace('_', ' ', (string) $k));
            $formattedVal = is_numeric($v) ? (is_float($v) ? number_format((float) $v, 2) : number_format((int) $v)) : (string) $v;
            $summary .= "- **{$formattedKey}**: `{$formattedVal}`\n";
        }

        $summary .= "\n#### 2. Risk Evaluation\n"
            . "- Maintain close monitoring of uncollected fee balances and attendance variances.\n"
            . "- Periodic audits ensure zero data drift across student cohorts.\n\n"
            . "#### 3. Recommended Actions\n"
            . "- Review action items outlined in the AI Smart Insights dashboard.\n"
            . "- Ensure section teachers reconcile unsubmitted registers promptly.\n";

        return $summary;
    }

    /**
     * Formulate structured meeting notes and action items.
     */
    public function prepareMeetingNotes(int $schoolId, string $meetingTitle, array $agendaItems, array $attendees = []): array
    {
        $today = date('F j, Y');
        $school = Database::fetch('SELECT name FROM schools WHERE id = ?', [$schoolId]);
        $schoolName = $school['name'] ?? 'Institution';

        $markdown = "### 📝 Official Meeting Minutes\n\n"
            . "**Meeting Title:** {$meetingTitle}\n"
            . "**Institution:** {$schoolName}\n"
            . "**Date & Time:** {$today}, 10:00 AM\n\n";

        if (!empty($attendees)) {
            $markdown .= "**Attendees:** " . implode(', ', $attendees) . "\n\n";
        }

        $markdown .= "#### 📋 Agenda Items & Discussion Points\n\n";
        foreach ($agendaItems as $idx => $item) {
            $num = $idx + 1;
            $markdown .= "**{$num}. {$item}**\n"
                . "- *Discussion Summary:* The committee reviewed current metrics and stakeholder feedback regarding {$item}.\n"
                . "- *Decision:* Consensus achieved to advance with targeted action steps.\n\n";
        }

        $markdown .= "#### ✅ Action Items & Ownership\n\n"
            . "| Task Description | Assigned Lead | Deadline | Status |\n"
            . "|---|---|---|---|\n";

        foreach ($agendaItems as $idx => $item) {
            $deadline = date('F j, Y', strtotime('+' . (($idx + 1) * 7) . ' days'));
            $markdown .= "| Execute operational deliverables for {$item} | Department Head | {$deadline} | In Progress |\n";
        }

        $markdown .= "\n*Recorded and archived by AI Productivity Suite for {$schoolName}.*";

        return [
            'meeting_title' => $meetingTitle,
            'minutes_markdown' => $markdown,
        ];
    }

    /**
     * Provide safe, user-friendly explanation of system error without leaking sensitive internals.
     */
    public function explainSystemError(string $errorCodeOrMessage, ?string $context = null): array
    {
        $cleanMsg = strtolower($errorCodeOrMessage);

        if (str_contains($cleanMsg, 'duplicate') || str_contains($cleanMsg, '1062')) {
            return [
                'error_type' => 'Duplicate Record Conflict',
                'explanation' => 'The system prevented this submission because a record with the same unique identifier (such as admission number, invoice number, or account code) already exists.',
                'solution' => 'Verify the entered code or admission number and choose a distinct reference code.',
            ];
        }

        if (str_contains($cleanMsg, 'foreign key') || str_contains($cleanMsg, '1451') || str_contains($cleanMsg, '1452')) {
            return [
                'error_type' => 'Relational Dependency Restriction',
                'explanation' => 'This record cannot be deleted or re-linked because other active records (such as student fees, grades, or attendance logs) depend on it.',
                'solution' => 'Deactivate or archive the record instead of deleting it, or remove the dependent child records first.',
            ];
        }

        if (str_contains($cleanMsg, 'quota') || str_contains($cleanMsg, 'rate_limit')) {
            return [
                'error_type' => 'Operational Rate Limit',
                'explanation' => 'The rate threshold for this operation has been temporarily reached to safeguard system throughput.',
                'solution' => 'Please wait a short moment before retrying the operation.',
            ];
        }

        return [
            'error_type' => 'System Operation Notice',
            'explanation' => 'An unexpected operational condition occurred during processing.',
            'solution' => 'Please refresh the page and verify your inputs. If the issue persists, contact your school portal administrator with the timestamp.',
        ];
    }

    /**
     * Provide step-by-step interactive guidance for complex school workflows.
     */
    public function guideWorkflow(string $workflowKey, string $roleSlug): array
    {
        return match ($workflowKey) {
            'fee_concession' => [
                'workflow_title' => 'Student Fee Concession & Scholarship Setup',
                'steps' => [
                    '1. Navigate to **Finance > Concessions** in the main navigation menu.',
                    '2. Click the **+ Grant Concession** button in the top right.',
                    '3. Select the target student from the search autocomplete.',
                    '4. Choose the Fee Category (e.g. Tuition Fee, Transport).',
                    '5. Choose the adjustment type: Percentage (%) or Fixed Amount ($).',
                    '6. Enter the concession value and the official justification reason (e.g. Merit Scholarship, Sibling Discount).',
                    '7. Click **Save Concession**. The discount will automatically apply to all future invoice generations.',
                ],
                'authorized_roles' => ['admin', 'school_admin', 'accountant', 'principal'],
            ],
            'student_promotion' => [
                'workflow_title' => 'Academic Term Promotion & Class Rollover',
                'steps' => [
                    '1. Navigate to **Academics > Academic Sessions**.',
                    '2. Ensure the upcoming academic year is created and marked active.',
                    '3. Open **Students > Student Directory** and select the source class cohort.',
                    '4. Select the qualified students to be promoted.',
                    '5. Click **Bulk Actions > Promote Students**.',
                    '6. Select the destination grade level and section.',
                    '7. Confirm promotion. Academic records from the prior session are immutably archived.',
                ],
                'authorized_roles' => ['admin', 'school_admin', 'principal'],
            ],
            default => [
                'workflow_title' => 'General System Workflow Navigation',
                'steps' => [
                    '1. Use the left sidebar to navigate to the relevant module.',
                    '2. For data creation, look for the primary action button (+ Add New) at the top of the table.',
                    '3. For automated operations, check the AI Floating Copilot or the AI Intelligence Cockpit.',
                ],
                'authorized_roles' => ['all'],
            ],
        };
    }
}
