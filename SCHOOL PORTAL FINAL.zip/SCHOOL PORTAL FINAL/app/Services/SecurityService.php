<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class SecurityService
{
    /**
     * Ensure security tables and indexes exist idempotently.
     */
    public function ensureSecuritySchema(): void
    {
        // 1. Comprehensive Login History
        Database::execute("
            CREATE TABLE IF NOT EXISTS login_history (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                user_id BIGINT UNSIGNED NULL,
                email VARCHAR(191) NOT NULL,
                ip_address VARCHAR(45) NOT NULL,
                user_agent VARCHAR(255) NULL,
                status ENUM('success', 'failed_password', 'locked_out', 'user_not_found') NOT NULL,
                failure_reason VARCHAR(255) NULL,
                attempted_at DATETIME NOT NULL,
                INDEX idx_login_school_date (school_id, attempted_at),
                INDEX idx_login_email (email, attempted_at),
                INDEX idx_login_ip (ip_address, attempted_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 2. Suspicious Activity & Security Incidents
        Database::execute("
            CREATE TABLE IF NOT EXISTS security_incidents (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                user_id BIGINT UNSIGNED NULL,
                event_type ENUM('brute_force', 'unusual_ip', 'account_lockout', 'idor_attempt', 'privilege_anomaly') NOT NULL,
                severity ENUM('low', 'medium', 'high', 'critical') NOT NULL DEFAULT 'medium',
                ip_address VARCHAR(45) NOT NULL,
                details JSON NULL,
                status ENUM('open', 'investigating', 'resolved') NOT NULL DEFAULT 'open',
                resolution_notes TEXT NULL,
                resolved_by BIGINT UNSIGNED NULL,
                created_at DATETIME NOT NULL,
                resolved_at DATETIME NULL,
                INDEX idx_incident_school_status (school_id, status),
                INDEX idx_incident_severity (school_id, severity)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 3. Tenant Configurable Password Policy & Lockout Settings
        Database::execute("
            CREATE TABLE IF NOT EXISTS security_settings (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL UNIQUE,
                min_password_length INT UNSIGNED NOT NULL DEFAULT 8,
                require_uppercase TINYINT(1) NOT NULL DEFAULT 1,
                require_lowercase TINYINT(1) NOT NULL DEFAULT 1,
                require_numbers TINYINT(1) NOT NULL DEFAULT 1,
                require_special_chars TINYINT(1) NOT NULL DEFAULT 0,
                max_failed_logins INT UNSIGNED NOT NULL DEFAULT 5,
                lockout_duration_minutes INT UNSIGNED NOT NULL DEFAULT 15,
                session_timeout_minutes INT UNSIGNED NOT NULL DEFAULT 120,
                notify_admin_on_lockout TINYINT(1) NOT NULL DEFAULT 1,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    /**
     * Get security settings for a school tenant with safe defaults.
     */
    public function getSecuritySettings(int $schoolId): array
    {
        $this->ensureSecuritySchema();
        $row = Database::fetch("SELECT * FROM security_settings WHERE school_id = ? LIMIT 1", [$schoolId]);
        if ($row) {
            return $row;
        }

        // Default security profile
        return [
            'school_id' => $schoolId,
            'min_password_length' => 8,
            'require_uppercase' => 1,
            'require_lowercase' => 1,
            'require_numbers' => 1,
            'require_special_chars' => 0,
            'max_failed_logins' => 5,
            'lockout_duration_minutes' => 15,
            'session_timeout_minutes' => 120,
            'notify_admin_on_lockout' => 1,
        ];
    }

    /**
     * Save or update security settings for a school tenant.
     */
    public function updateSecuritySettings(int $schoolId, array $data): bool
    {
        $this->ensureSecuritySchema();

        $minLen = max(6, min(32, (int)($data['min_password_length'] ?? 8)));
        $reqUpper = !empty($data['require_uppercase']) ? 1 : 0;
        $reqLower = !empty($data['require_lowercase']) ? 1 : 0;
        $reqNum = !empty($data['require_numbers']) ? 1 : 0;
        $reqSpec = !empty($data['require_special_chars']) ? 1 : 0;
        $maxFailed = max(3, min(20, (int)($data['max_failed_logins'] ?? 5)));
        $lockoutMins = max(5, min(1440, (int)($data['lockout_duration_minutes'] ?? 15)));
        $timeoutMins = max(15, min(1440, (int)($data['session_timeout_minutes'] ?? 120)));
        $notifyAdmin = !empty($data['notify_admin_on_lockout']) ? 1 : 0;

        Database::execute("
            INSERT INTO security_settings 
            (school_id, min_password_length, require_uppercase, require_lowercase, require_numbers, require_special_chars, max_failed_logins, lockout_duration_minutes, session_timeout_minutes, notify_admin_on_lockout, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
                min_password_length = VALUES(min_password_length),
                require_uppercase = VALUES(require_uppercase),
                require_lowercase = VALUES(require_lowercase),
                require_numbers = VALUES(require_numbers),
                require_special_chars = VALUES(require_special_chars),
                max_failed_logins = VALUES(max_failed_logins),
                lockout_duration_minutes = VALUES(lockout_duration_minutes),
                session_timeout_minutes = VALUES(session_timeout_minutes),
                notify_admin_on_lockout = VALUES(notify_admin_on_lockout),
                updated_at = NOW()
        ", [$schoolId, $minLen, $reqUpper, $reqLower, $reqNum, $reqSpec, $maxFailed, $lockoutMins, $timeoutMins, $notifyAdmin]);

        auditLog('security.settings_updated', 'security', 'security_settings', $schoolId, null, [
            'min_length' => $minLen,
            'max_failed_logins' => $maxFailed,
            'lockout_minutes' => $lockoutMins
        ]);

        return true;
    }

    /**
     * Validate a candidate password against the tenant's security policy.
     */
    public function validatePasswordPolicy(int $schoolId, string $password): array
    {
        $settings = $this->getSecuritySettings($schoolId);
        $errors = [];

        $minLen = (int)($settings['min_password_length'] ?? 8);
        if (strlen($password) < $minLen) {
            $errors[] = "Password must be at least {$minLen} characters long.";
        }

        if (!empty($settings['require_uppercase']) && !preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter (A-Z).";
        }

        if (!empty($settings['require_lowercase']) && !preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter (a-z).";
        }

        if (!empty($settings['require_numbers']) && !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number (0-9).";
        }

        if (!empty($settings['require_special_chars']) && !preg_match('/[^a-zA-Z0-9]/', $password)) {
            $errors[] = "Password must contain at least one special character (!@#$%^&*).";
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Record a login attempt and evaluate suspicious activity.
     */
    public function recordLoginAttempt(
        int $schoolId,
        string $email,
        string $status,
        ?int $userId = null,
        ?string $reason = null
    ): void {
        $this->ensureSecuritySchema();

        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Agent', 0, 255);

        Database::insert("
            INSERT INTO login_history (school_id, user_id, email, ip_address, user_agent, status, failure_reason, attempted_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ", [$schoolId, $userId, strtolower(trim($email)), $ip, $ua, $status, $reason]);

        // Evaluate Suspicious Activity
        if ($status !== 'success') {
            $settings = $this->getSecuritySettings($schoolId);
            $lockoutLimit = (int)($settings['max_failed_logins'] ?? 5);

            // Check failed attempts from this IP in the last 15 minutes
            $recentFailures = Database::fetch("
                SELECT COUNT(*) AS c 
                FROM login_history 
                WHERE school_id = ? AND ip_address = ? AND status != 'success' 
                  AND attempted_at >= (NOW() - INTERVAL 15 MINUTE)
            ", [$schoolId, $ip]);

            $failCount = (int)($recentFailures['c'] ?? 0);

            if ($failCount >= $lockoutLimit) {
                // Check if an open incident already exists for this IP
                $existing = Database::fetch("
                    SELECT id FROM security_incidents 
                    WHERE school_id = ? AND ip_address = ? AND event_type = 'account_lockout' AND status = 'open' 
                    LIMIT 1
                ", [$schoolId, $ip]);

                if (!$existing) {
                    Database::insert("
                        INSERT INTO security_incidents (school_id, user_id, event_type, severity, ip_address, details, status, created_at)
                        VALUES (?, ?, 'account_lockout', 'high', ?, ?, 'open', NOW())
                    ", [
                        $schoolId,
                        $userId,
                        $ip,
                        json_encode([
                            'target_email' => $email,
                            'failure_count' => $failCount,
                            'reason' => 'Threshold exceeded. Account/IP temporarily locked.',
                            'time' => date('Y-m-d H:i:s')
                        ])
                    ]);

                    if (!empty($settings['notify_admin_on_lockout'])) {
                        $admins = Database::fetchAll("SELECT id FROM users WHERE school_id = ? AND role_id IN (SELECT id FROM roles WHERE slug IN ('school_admin', 'owner', 'principal', 'administrator', 'admin'))", [$schoolId]);
                        foreach ($admins as $adm) {
                            notify_user(
                                $schoolId,
                                (int)$adm['id'],
                                'security',
                                'Security Alert: Multiple Failed Logins',
                                "Multiple failed login attempts ({$failCount}) detected for {$email} from IP: {$ip}.",
                                'security_incidents',
                                null,
                                'admin/security'
                            );
                        }
                    }
                }
            } elseif ($failCount >= 3) {
                // Brute force warning
                $existingBf = Database::fetch("
                    SELECT id FROM security_incidents 
                    WHERE school_id = ? AND ip_address = ? AND event_type = 'brute_force' AND status = 'open'
                      AND created_at >= (NOW() - INTERVAL 30 MINUTE)
                    LIMIT 1
                ", [$schoolId, $ip]);

                if (!$existingBf) {
                    Database::insert("
                        INSERT INTO security_incidents (school_id, user_id, event_type, severity, ip_address, details, status, created_at)
                        VALUES (?, ?, 'brute_force', 'medium', ?, ?, 'open', NOW())
                    ", [
                        $schoolId,
                        $userId,
                        $ip,
                        json_encode([
                            'target_email' => $email,
                            'consecutive_failures' => $failCount,
                            'time' => date('Y-m-d H:i:s')
                        ])
                    ]);
                }
            }
        }
    }

    /**
     * Retrieve paginated login history.
     */
    public function getLoginHistory(int $schoolId, array $filters = []): array
    {
        $this->ensureSecuritySchema();

        $page = max(1, (int)($filters['page'] ?? 1));
        $limit = max(5, min(100, (int)($filters['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;

        $sql = "SELECT lh.*, u.name AS user_name, r.name AS role_name
                FROM login_history lh
                LEFT JOIN users u ON u.id = lh.user_id
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE lh.school_id = ?";
        $params = [$schoolId];

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND lh.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['q'])) {
            $q = '%' . trim((string)$filters['q']) . '%';
            $sql .= " AND (lh.email LIKE ? OR lh.ip_address LIKE ? OR u.name LIKE ?)";
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $totalRow = Database::fetch(str_replace("lh.*, u.name AS user_name, r.name AS role_name", "COUNT(*) AS c", $sql), $params);
        $total = (int)($totalRow['c'] ?? 0);

        $sql .= " ORDER BY lh.attempted_at DESC LIMIT {$limit} OFFSET {$offset}";
        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'totalPages' => max(1, (int)ceil($total / $limit))
        ];
    }

    /**
     * Retrieve security incident alerts.
     */
    public function getSecurityIncidents(int $schoolId, array $filters = []): array
    {
        $this->ensureSecuritySchema();

        $sql = "SELECT si.*, u.name AS target_name, rb.name AS resolver_name
                FROM security_incidents si
                LEFT JOIN users u ON u.id = si.user_id
                LEFT JOIN users rb ON rb.id = si.resolved_by
                WHERE si.school_id = ?";
        $params = [$schoolId];

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND si.status = ?";
            $params[] = $filters['status'];
        }

        $sql .= " ORDER BY CASE WHEN si.status = 'open' THEN 1 WHEN si.status = 'investigating' THEN 2 ELSE 3 END, si.created_at DESC LIMIT 50";
        return Database::fetchAll($sql, $params);
    }

    /**
     * Resolve a security incident.
     */
    public function resolveSecurityIncident(int $schoolId, int $incidentId, string $notes, int $resolvedBy): bool
    {
        $this->ensureSecuritySchema();

        $exists = Database::fetch("SELECT id FROM security_incidents WHERE id = ? AND school_id = ?", [$incidentId, $schoolId]);
        if (!$exists) {
            return false;
        }

        Database::execute("
            UPDATE security_incidents 
            SET status = 'resolved', resolution_notes = ?, resolved_by = ?, resolved_at = NOW()
            WHERE id = ? AND school_id = ?
        ", [$notes, $resolvedBy, $incidentId, $schoolId]);

        auditLog('security.incident_resolved', 'security', 'security_incidents', $incidentId, null, [
            'notes' => $notes,
            'resolver_id' => $resolvedBy
        ]);

        return true;
    }

    /**
     * Alias for resolveSecurityIncident with parameter flexibility.
     */
    public function resolveIncident(int $schoolId, int $incidentId, int $resolvedBy, string $notes): bool
    {
        return $this->resolveSecurityIncident($schoolId, $incidentId, $notes, $resolvedBy);
    }

    /**
     * Run an automated Tenant Isolation & Security Health Audit.
     * Verifies that all resources are strictly scoped with valid school_id foreign boundaries.
     */
    public function runTenantIsolationAudit(int $schoolId): array
    {
        $coreTables = [
            'users' => 'school_id',
            'students' => 'school_id',
            'employees' => 'school_id',
            'classes' => 'school_id',
            'sections' => 'school_id',
            'invoices' => 'school_id',
            'fee_payments' => 'school_id',
            'exams' => 'school_id',
            'timetables' => 'school_id',
            'leave_requests' => 'school_id',
            'staff_tasks' => 'school_id',
            'school_holidays' => 'school_id'
        ];

        $results = [];
        $totalChecks = 0;
        $passedChecks = 0;

        foreach ($coreTables as $table => $tenantCol) {
            $tableExists = Database::fetch("SELECT COUNT(*) AS c FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?", [$table]);
            if ((int)($tableExists['c'] ?? 0) === 0) {
                continue;
            }

            $totalChecks++;

            // 1. Check for orphaned records with NULL or 0 school_id
            $orphans = Database::fetch("SELECT COUNT(*) AS c FROM `{$table}` WHERE `{$tenantCol}` IS NULL OR `{$tenantCol}` = 0");
            $orphanCount = (int)($orphans['c'] ?? 0);

            // 2. Count tenant's isolated records
            $tenantRecords = Database::fetch("SELECT COUNT(*) AS c FROM `{$table}` WHERE `{$tenantCol}` = ?", [$schoolId]);
            $count = (int)($tenantRecords['c'] ?? 0);

            $isClean = ($orphanCount === 0);
            if ($isClean) {
                $passedChecks++;
            }

            $results[] = [
                'table' => $table,
                'status' => $isClean ? 'secure' : 'warning',
                'tenant_records' => $count,
                'orphan_records' => $orphanCount,
                'message' => $isClean 
                    ? "Strict tenant boundary active ({$count} records correctly isolated)." 
                    : "Found {$orphanCount} unassigned or null tenant records."
            ];
        }

        $score = ($totalChecks > 0) ? round(($passedChecks / $totalChecks) * 100) : 100;

        return [
            'score' => $score,
            'total_tables_checked' => $totalChecks,
            'secure_tables_count' => $passedChecks,
            'table_details' => $results,
            'audited_at' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Compute Executive Security Center Metrics.
     */
    public function getSecurityDashboardMetrics(int $schoolId): array
    {
        $this->ensureSecuritySchema();

        // 1. Total Logins today
        $today = date('Y-m-d');
        $loginsToday = Database::fetch("
            SELECT 
                COUNT(*) AS total_today,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successful_today,
                SUM(CASE WHEN status != 'success' THEN 1 ELSE 0 END) AS failed_today
            FROM login_history 
            WHERE school_id = ? AND attempted_at >= ?
        ", [$schoolId, $today . ' 00:00:00']);

        // 2. Open Security Incidents
        $incidents = Database::fetch("
            SELECT 
                COUNT(*) AS total_incidents,
                SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) AS open_incidents,
                SUM(CASE WHEN status = 'open' AND severity = 'critical' THEN 1 ELSE 0 END) AS critical_incidents
            FROM security_incidents 
            WHERE school_id = ?
        ", [$schoolId]);

        // 3. Active Users with Administrative Roles
        $adminUsersCount = Database::fetch("
            SELECT COUNT(*) AS c 
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE u.school_id = ? AND u.status = 1 AND r.slug IN ('admin', 'superadmin', 'principal')
        ", [$schoolId]);

        // 4. Settings
        $settings = $this->getSecuritySettings($schoolId);

        return [
            'logins_today' => $loginsToday,
            'incidents' => $incidents,
            'admin_accounts_count' => (int)($adminUsersCount['c'] ?? 0),
            'settings' => $settings
        ];
    }
}
