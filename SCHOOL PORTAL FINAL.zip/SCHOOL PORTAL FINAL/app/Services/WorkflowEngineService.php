<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Notification;
use Core\Auth;
use Core\Database;
use Core\TenantGuard;

final class WorkflowEngineService
{
    public function __construct()
    {
        $this->ensureTable();
    }

    /**
     * Ensure the approvals_workflow table exists.
     */
    private function ensureTable(): void
    {
        static $checked = false;
        if ($checked) {
            return;
        }

        try {
            Database::execute(
                "CREATE TABLE IF NOT EXISTS approvals_workflow (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    school_id INT NOT NULL,
                    entity_type VARCHAR(50) NOT NULL,
                    entity_id INT NOT NULL,
                    requester_user_id INT NOT NULL,
                    approver_user_id INT NULL,
                    current_stage VARCHAR(50) NOT NULL DEFAULT 'submitted',
                    current_stage_order INT NOT NULL DEFAULT 1,
                    total_stages INT NOT NULL DEFAULT 1,
                    assigned_role VARCHAR(50) NULL,
                    status ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
                    title VARCHAR(255) NOT NULL,
                    description TEXT NULL,
                    reviewer_remarks TEXT NULL,
                    meta_data TEXT NULL,
                    audit_trail_json LONGTEXT NULL,
                    submitted_at DATETIME NOT NULL,
                    actioned_at DATETIME NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_wf_school_status (school_id, status),
                    INDEX idx_wf_school_entity (school_id, entity_type, entity_id),
                    INDEX idx_wf_assigned_role (school_id, assigned_role)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );

            // Conditional column check for existing installs
            $cols = Database::fetchAll("SHOW COLUMNS FROM approvals_workflow");
            $colNames = array_column($cols, 'Field');
            if (!in_array('current_stage_order', $colNames, true)) {
                Database::execute("ALTER TABLE approvals_workflow ADD COLUMN current_stage_order INT NOT NULL DEFAULT 1 AFTER current_stage");
            }
            if (!in_array('total_stages', $colNames, true)) {
                Database::execute("ALTER TABLE approvals_workflow ADD COLUMN total_stages INT NOT NULL DEFAULT 1 AFTER current_stage_order");
            }
            if (!in_array('assigned_role', $colNames, true)) {
                Database::execute("ALTER TABLE approvals_workflow ADD COLUMN assigned_role VARCHAR(50) NULL AFTER total_stages");
            }
            if (!in_array('audit_trail_json', $colNames, true)) {
                Database::execute("ALTER TABLE approvals_workflow ADD COLUMN audit_trail_json LONGTEXT NULL AFTER meta_data");
            }

            // Approval chains definition table
            Database::execute(
                "CREATE TABLE IF NOT EXISTS approval_chains (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NOT NULL,
                    entity_type VARCHAR(50) NOT NULL,
                    name VARCHAR(191) NOT NULL,
                    description VARCHAR(255) NULL,
                    stages_json LONGTEXT NOT NULL,
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY uk_school_entity (school_id, entity_type),
                    INDEX idx_school_active (school_id, is_active)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        } catch (\Throwable $e) {
            // Ignore if exists or cannot create
        }
        $checked = true;
    }

    /**
     * Seeds default institutional approval chains if none exist.
     */
    public function seedDefaultApprovalChains(int $schoolId): void
    {
        $existing = Database::fetch('SELECT COUNT(*) AS c FROM approval_chains WHERE school_id = ?', [$schoolId]);
        if ((int) ($existing['c'] ?? 0) > 0) {
            return;
        }

        $defaults = [
            [
                'entity_type' => 'leave_request',
                'name' => 'Staff Leave Multi-Stage Approval',
                'description' => 'Two-tier verification: Academic/Department review followed by Principal authorization.',
                'stages' => [
                    ['stage' => 1, 'name' => 'Department Verification', 'role' => 'academic_manager'],
                    ['stage' => 2, 'name' => 'Principal Final Approval', 'role' => 'principal'],
                ],
            ],
            [
                'entity_type' => 'expense_claim',
                'name' => 'Expense & Reimbursement Authorization',
                'description' => 'Accounts audit followed by Executive Principal sign-off.',
                'stages' => [
                    ['stage' => 1, 'name' => 'Accounts Audit', 'role' => 'accountant'],
                    ['stage' => 2, 'name' => 'Principal Approval', 'role' => 'principal'],
                ],
            ],
            [
                'entity_type' => 'fee_waiver',
                'name' => 'Fee Concession & Discount Approval',
                'description' => 'Fee auditor review followed by Institutional Director clearance.',
                'stages' => [
                    ['stage' => 1, 'name' => 'Fee Audit Verification', 'role' => 'accountant'],
                    ['stage' => 2, 'name' => 'Executive Clearance', 'role' => 'principal'],
                ],
            ],
            [
                'entity_type' => 'admission',
                'name' => 'Student Admission Clearance',
                'description' => 'Admissions team application verification and registrar clearance.',
                'stages' => [
                    ['stage' => 1, 'name' => 'Admissions Verification', 'role' => 'admin'],
                ],
            ],
            [
                'entity_type' => 'exam_publish',
                'name' => 'Examination Result Publication',
                'description' => 'Academic Controller verification before grade sheet release.',
                'stages' => [
                    ['stage' => 1, 'name' => 'Academic Head Review', 'role' => 'principal'],
                ],
            ],
        ];

        foreach ($defaults as $d) {
            Database::insert(
                'INSERT INTO approval_chains (school_id, entity_type, name, description, stages_json, is_active, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())',
                [
                    $schoolId,
                    $d['entity_type'],
                    $d['name'],
                    $d['description'],
                    json_encode($d['stages'], JSON_UNESCAPED_SLASHES),
                ]
            );
        }
    }

    /**
     * Get configured approval chains for a school tenant.
     */
    public function getApprovalChains(int $schoolId): array
    {
        $this->seedDefaultApprovalChains($schoolId);
        $rows = Database::fetchAll(
            'SELECT * FROM approval_chains WHERE school_id = ? ORDER BY id ASC',
            [$schoolId]
        );

        foreach ($rows as &$r) {
            $r['stages'] = json_decode((string) $r['stages_json'], true) ?: [];
        }
        unset($r);

        return $rows;
    }

    /**
     * Get specific approval chain for an entity type.
     */
    public function getApprovalChain(int $schoolId, string $entityType): ?array
    {
        $this->seedDefaultApprovalChains($schoolId);
        $row = Database::fetch(
            'SELECT * FROM approval_chains WHERE school_id = ? AND entity_type = ? AND is_active = 1 LIMIT 1',
            [$schoolId, $entityType]
        );

        if ($row) {
            $row['stages'] = json_decode((string) $row['stages_json'], true) ?: [];
        }

        return $row ?: null;
    }

    /**
     * Create or update an approval chain.
     */
    public function saveApprovalChain(int $schoolId, string $entityType, string $name, array $stages, ?string $description = null): int
    {
        $stagesJson = json_encode(array_values($stages), JSON_UNESCAPED_SLASHES);

        $existing = Database::fetch(
            'SELECT id FROM approval_chains WHERE school_id = ? AND entity_type = ? LIMIT 1',
            [$schoolId, $entityType]
        );

        if ($existing) {
            $id = (int) $existing['id'];
            Database::execute(
                'UPDATE approval_chains SET name = ?, description = ?, stages_json = ?, is_active = 1, updated_at = NOW() WHERE id = ? AND school_id = ?',
                [$name, $description, $stagesJson, $id, $schoolId]
            );
            return $id;
        }

        return (int) Database::insert(
            'INSERT INTO approval_chains (school_id, entity_type, name, description, stages_json, is_active, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())',
            [$schoolId, $entityType, $name, $description, $stagesJson]
        );
    }

    /**
     * Submit a new entity to the approval workflow.
     */
    public function submit(
        int $schoolId,
        string $entityType,
        int $entityId,
        int $requesterUserId,
        string $title,
        ?string $description = null,
        array $meta = []
    ): int {
        // Enforce deduplication: check if already pending
        $existing = Database::fetch(
            'SELECT id FROM approvals_workflow WHERE school_id = ? AND entity_type = ? AND entity_id = ? AND status = "pending" LIMIT 1',
            [$schoolId, $entityType, $entityId]
        );

        if ($existing) {
            return (int) $existing['id'];
        }

        // Determine chain stages
        $chain = $this->getApprovalChain($schoolId, $entityType);
        $stages = $chain['stages'] ?? [
            ['stage' => 1, 'name' => 'Initial Review', 'role' => 'admin']
        ];
        $totalStages = max(1, count($stages));
        $firstStage = $stages[0];
        $initialStageName = (string) ($firstStage['name'] ?? 'Stage 1 Review');
        $initialRole = (string) ($firstStage['role'] ?? 'admin');

        $initialAudit = [
            [
                'stage' => 1,
                'stage_name' => $initialStageName,
                'action' => 'submitted',
                'user_id' => $requesterUserId,
                'role' => 'requester',
                'timestamp' => date('Y-m-d H:i:s'),
                'remarks' => $description,
            ]
        ];

        $id = (int) Database::insert(
            'INSERT INTO approvals_workflow 
            (school_id, entity_type, entity_id, requester_user_id, current_stage, current_stage_order, total_stages, assigned_role, status, title, description, meta_data, audit_trail_json, submitted_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?, ?, "pending", ?, ?, ?, ?, NOW(), NOW(), NOW())',
            [
                $schoolId,
                $entityType,
                $entityId,
                $requesterUserId,
                $initialStageName,
                $totalStages,
                $initialRole,
                $title,
                $description,
                !empty($meta) ? json_encode($meta, JSON_UNESCAPED_SLASHES) : null,
                json_encode($initialAudit, JSON_UNESCAPED_SLASHES),
            ]
        );

        auditLog('workflow.submit', 'approvals_workflow', $entityType, $entityId, null, [
            'workflow_id' => $id,
            'title' => $title,
            'total_stages' => $totalStages,
        ]);

        return $id;
    }

    /**
     * Transition a workflow item (approve, reject, cancel).
     * Supports multi-stage advance vs final completion.
     */
    public function transition(int $workflowId, string $action, int $actorUserId, ?string $remarks = null): bool
    {
        $schoolId = (int) (Auth::schoolId() ?: TenantContext::getSchoolId());
        TenantGuard::enforce('approvals_workflow', $workflowId, $schoolId);

        $wf = Database::fetch(
            'SELECT * FROM approvals_workflow WHERE id = ? AND school_id = ? LIMIT 1',
            [$workflowId, $schoolId]
        );

        if (!$wf) {
            throw new \RuntimeException('Workflow approval record not found.');
        }

        if ($wf['status'] !== 'pending') {
            throw new \RuntimeException('This workflow item has already been actioned.');
        }

        $audit = json_decode((string) ($wf['audit_trail_json'] ?? '[]'), true) ?: [];
        $currentOrder = max(1, (int) ($wf['current_stage_order'] ?? 1));
        $totalStages = max(1, (int) ($wf['total_stages'] ?? 1));

        if ($action === 'approve') {
            // Check if there are further stages in chain
            if ($currentOrder < $totalStages) {
                // Multi-stage advance
                $chain = $this->getApprovalChain($schoolId, (string) $wf['entity_type']);
                $stages = $chain['stages'] ?? [];
                $nextIndex = $currentOrder; // 0-based index for next stage
                $nextStage = $stages[$nextIndex] ?? [
                    'stage' => $currentOrder + 1,
                    'name' => 'Stage ' . ($currentOrder + 1) . ' Review',
                    'role' => 'principal',
                ];

                $nextStageOrder = $currentOrder + 1;
                $nextStageName = (string) ($nextStage['name'] ?? 'Next Review');
                $nextRole = (string) ($nextStage['role'] ?? 'admin');

                $audit[] = [
                    'stage' => $currentOrder,
                    'stage_name' => $wf['current_stage'],
                    'action' => 'approved_and_advanced',
                    'user_id' => $actorUserId,
                    'timestamp' => date('Y-m-d H:i:s'),
                    'remarks' => $remarks,
                    'next_stage' => $nextStageName,
                ];

                Database::execute(
                    'UPDATE approvals_workflow 
                     SET current_stage = ?, current_stage_order = ?, assigned_role = ?, reviewer_remarks = ?, audit_trail_json = ?, updated_at = NOW()
                     WHERE id = ? AND school_id = ?',
                    [$nextStageName, $nextStageOrder, $nextRole, $remarks, json_encode($audit, JSON_UNESCAPED_SLASHES), $workflowId, $schoolId]
                );

                auditLog('workflow.advance', 'approvals_workflow', (string) $wf['entity_type'], (int) $wf['entity_id'], [
                    'previous_stage' => $wf['current_stage'],
                ], [
                    'new_stage' => $nextStageName,
                    'order' => $nextStageOrder,
                    'remarks' => $remarks,
                ]);

                return true;
            }

            // Final Approval
            $newStatus = 'approved';
        } else {
            $newStatus = match ($action) {
                'reject' => 'rejected',
                'cancel' => 'cancelled',
                default => throw new \InvalidArgumentException("Invalid workflow action: {$action}"),
            };
        }

        $audit[] = [
            'stage' => $currentOrder,
            'stage_name' => $wf['current_stage'],
            'action' => $newStatus,
            'user_id' => $actorUserId,
            'timestamp' => date('Y-m-d H:i:s'),
            'remarks' => $remarks,
        ];

        Database::execute(
            'UPDATE approvals_workflow 
             SET status = ?, approver_user_id = ?, reviewer_remarks = ?, current_stage = ?, audit_trail_json = ?, actioned_at = NOW(), updated_at = NOW()
             WHERE id = ? AND school_id = ?',
            [$newStatus, $actorUserId, $remarks, $newStatus, json_encode($audit, JSON_UNESCAPED_SLASHES), $workflowId, $schoolId]
        );

        // Execute entity-specific state transition
        $this->applyEntitySideEffect($schoolId, (string) $wf['entity_type'], (int) $wf['entity_id'], $newStatus, $remarks);

        // Dispatch notification to original requester
        if (!empty($wf['requester_user_id'])) {
            $notifTitle = "Workflow Update: " . ucfirst($newStatus) . " — {$wf['title']}";
            $notifMsg = "Your request '{$wf['title']}' has been " . strtoupper($newStatus) . " by an administrator." . ($remarks ? " Remarks: {$remarks}" : "");
            (new Notification())->createNotification(
                $schoolId,
                (int) $wf['requester_user_id'],
                'workflow.' . $newStatus,
                $notifTitle,
                $notifMsg,
                (string) $wf['entity_type'],
                (int) $wf['entity_id']
            );
        }

        auditLog('workflow.' . $action, 'approvals_workflow', (string) $wf['entity_type'], (int) $wf['entity_id'], [
            'previous_status' => $wf['status'],
        ], [
            'new_status' => $newStatus,
            'remarks' => $remarks,
            'actor_id' => $actorUserId,
        ]);

        return true;
    }

    /**
     * List pending workflow items applicable to a given user or user role.
     */
    public function listPendingForUser(int $schoolId, int $userId, ?string $userRoleSlug = null, int $limit = 10): array
    {
        $sql = 'SELECT wf.*, u.name AS requester_name, u.email AS requester_email
                FROM approvals_workflow wf
                LEFT JOIN users u ON u.id = wf.requester_user_id
                WHERE wf.school_id = ? AND wf.status = "pending"';
        $params = [$schoolId];

        // If not administrative role, restrict to assigned role or own requests
        if ($userRoleSlug && !in_array($userRoleSlug, ['admin', 'super_admin', 'owner', 'administrator', 'principal'], true)) {
            $sql .= ' AND (wf.assigned_role = ? OR wf.requester_user_id = ?)';
            $params[] = $userRoleSlug;
            $params[] = $userId;
        }

        $sql .= ' ORDER BY wf.submitted_at DESC LIMIT ' . (int) $limit;
        return Database::fetchAll($sql, $params);
    }

    /**
     * Apply target entity side-effects upon approval/rejection.
     */
    private function applyEntitySideEffect(int $schoolId, string $entityType, int $entityId, string $newStatus, ?string $remarks): void
    {
        try {
            switch ($entityType) {
                case 'leave_request':
                    Database::execute(
                        'UPDATE leave_requests SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_notes = COALESCE(?, review_notes), updated_at = NOW() WHERE id = ? AND school_id = ?',
                        [$newStatus, Auth::id(), $remarks, $entityId, $schoolId]
                    );
                    break;

                case 'admission':
                    $admStatus = $newStatus === 'approved' ? 'approved' : 'rejected';
                    Database::execute(
                        'UPDATE admissions SET status = ?, notes = COALESCE(?, notes), updated_at = NOW() WHERE id = ? AND school_id = ?',
                        [$admStatus, $remarks, $entityId, $schoolId]
                    );
                    break;

                case 'exam_publish':
                    if ($newStatus === 'approved') {
                        Database::execute(
                            'UPDATE exams SET status = "published", updated_at = NOW() WHERE id = ? AND school_id = ?',
                            [$entityId, $schoolId]
                        );
                    }
                    break;

                case 'expense_claim':
                    Database::execute(
                        'UPDATE expenses SET notes = CONCAT(COALESCE(notes, ""), " [Workflow: ' . strtoupper($newStatus) . ' by User #", ?, "]"), updated_at = NOW() WHERE id = ? AND school_id = ?',
                        [(int) Auth::id(), $entityId, $schoolId]
                    );
                    break;

                case 'fee_waiver':
                    Database::execute(
                        'UPDATE student_fee_invoices SET notes = CONCAT(COALESCE(notes, ""), " [Concession: ' . strtoupper($newStatus) . ' by User #", ?, "]"), updated_at = NOW() WHERE id = ? AND school_id = ?',
                        [(int) Auth::id(), $entityId, $schoolId]
                    );
                    break;
            }
        } catch (\Throwable $e) {
            // Log but don't crash
            error_log("Workflow side effect error for {$entityType} #{$entityId}: " . $e->getMessage());
        }
    }

    /**
     * List pending workflows for the current tenant.
     *
     * @param int $schoolId
     * @param string|null $entityType
     * @param int $limit
     * @return array<int, array<string, mixed>>
     */
    public function listPending(int $schoolId, ?string $entityType = null, int $limit = 25): array
    {
        $sql = 'SELECT wf.*, u.name AS requester_name, u.email AS requester_email
                FROM approvals_workflow wf
                LEFT JOIN users u ON u.id = wf.requester_user_id
                WHERE wf.school_id = ? AND wf.status = "pending"';
        $params = [$schoolId];

        if ($entityType) {
            $sql .= ' AND wf.entity_type = ?';
            $params[] = $entityType;
        }

        $sql .= ' ORDER BY wf.submitted_at DESC LIMIT ' . (int) $limit;
        return Database::fetchAll($sql, $params);
    }

    /**
     * List all workflows with filter and pagination.
     *
     * @param int $schoolId
     * @param string|null $status
     * @param string|null $entityType
     * @param int $limit
     * @param int $offset
     * @return array{rows: array, total: int}
     */
    public function listAll(int $schoolId, ?string $status = null, ?string $entityType = null, int $limit = 20, int $offset = 0): array
    {
        $where = ['wf.school_id = ?'];
        $params = [$schoolId];

        if ($status && $status !== 'all') {
            $where[] = 'wf.status = ?';
            $params[] = $status;
        }

        if ($entityType && $entityType !== 'all') {
            $where[] = 'wf.entity_type = ?';
            $params[] = $entityType;
        }

        $whereClause = implode(' AND ', $where);

        $countRow = Database::fetch(
            "SELECT COUNT(*) AS total FROM approvals_workflow wf WHERE {$whereClause}",
            $params
        );
        $total = (int) ($countRow['total'] ?? 0);

        $sql = "SELECT wf.*, u.name AS requester_name, u.email AS requester_email,
                       appr.name AS approver_name
                FROM approvals_workflow wf
                LEFT JOIN users u ON u.id = wf.requester_user_id
                LEFT JOIN users appr ON appr.id = wf.approver_user_id
                WHERE {$whereClause}
                ORDER BY wf.created_at DESC
                LIMIT {$limit} OFFSET {$offset}";

        $rows = Database::fetchAll($sql, $params);

        return [
            'rows' => $rows,
            'total' => $total,
        ];
    }

    /**
     * Get executive workflow turnaround metrics.
     *
     * @param int $schoolId
     * @return array<string, mixed>
     */
    public function metrics(int $schoolId): array
    {
        $rows = Database::fetchAll(
            'SELECT status, COUNT(*) AS count FROM approvals_workflow WHERE school_id = ? GROUP BY status',
            [$schoolId]
        );

        $counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0, 'cancelled' => 0];
        $total = 0;
        foreach ($rows as $r) {
            $st = (string) $r['status'];
            $c = (int) $r['count'];
            $counts[$st] = $c;
            $total += $c;
        }

        $approvalRate = $total > 0 && ($counts['approved'] + $counts['rejected']) > 0
            ? round(($counts['approved'] / ($counts['approved'] + $counts['rejected'])) * 100, 1)
            : 100.0;

        return [
            'total' => $total,
            'pending' => $counts['pending'],
            'approved' => $counts['approved'],
            'rejected' => $counts['rejected'],
            'approval_rate' => $approvalRate,
        ];
    }
}
