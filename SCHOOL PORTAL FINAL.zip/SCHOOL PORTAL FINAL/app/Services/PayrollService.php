<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\PayrollModel;
use Core\Auth;
use Core\Database;
use Core\TenantGuard;

final class PayrollService
{
    private PayrollModel $payrollModel;

    public function __construct()
    {
        $this->payrollModel = new PayrollModel();
    }

    /**
     * Backward-compatible alias for generateMonthlyPayroll returning count.
     */
    public function generateDraft(string $month): int
    {
        $res = $this->generateMonthlyPayroll($month);
        return (int) ($res['processed'] ?? 0);
    }

    /**
     * Generate or auto-calculate mass payroll for a specified month with attendance deductions.
     *
     * @param string $month Format "YYYY-MM"
     * @param float $deductionPerDay
     * @param float $bonusMultiplier
     * @return array{processed: int, skipped: int}
     */
    public function generateMonthlyPayroll(string $month, float $deductionPerDay = 0.0, float $bonusMultiplier = 1.0): array
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for payroll calculation.');
        }

        return Database::transaction(function () use ($schoolId, $month, $deductionPerDay, $bonusMultiplier): array {
            $structures = Database::fetchAll(
                'SELECT ss.*, e.id AS emp_id, e.first_name, e.last_name 
                 FROM salary_structures ss
                 INNER JOIN employees e ON e.id = ss.employee_id AND e.school_id = ss.school_id
                 WHERE ss.school_id = ? AND ss.status = 1 AND e.status = "active"',
                [$schoolId]
            );

            // If no structures are set up, fallback to all active employees with default structure
            if (empty($structures)) {
                $employees = Database::fetchAll(
                    'SELECT id AS emp_id, first_name, last_name FROM employees WHERE school_id = ? AND status = "active"',
                    [$schoolId]
                );

                $structures = array_map(function ($emp) use ($schoolId) {
                    return [
                        'emp_id' => $emp['emp_id'],
                        'employee_id' => $emp['emp_id'],
                        'basic_salary' => 30000.00,
                        'house_allowance' => 5000.00,
                        'transport_allowance' => 2500.00,
                        'other_allowance' => 1500.00,
                        'deductions' => 1500.00,
                        'school_id' => $schoolId,
                    ];
                }, $employees);
            }

            $processed = 0;
            $skipped = 0;

            $monthStart = $month . '-01';
            $monthEnd = date('Y-m-t', strtotime($monthStart));

            foreach ($structures as $s) {
                $empId = (int) $s['emp_id'];

                $exists = Database::fetch(
                    'SELECT id FROM payroll WHERE school_id = ? AND employee_id = ? AND payroll_month = ? LIMIT 1',
                    [$schoolId, $empId, $month]
                );

                if ($exists) {
                    $skipped++;
                    continue;
                }

                $unapprovedAbsences = 0;
                if ($deductionPerDay > 0) {
                    $absences = Database::fetchAll(
                        "SELECT attendance_date FROM staff_attendance 
                         WHERE school_id = ? AND employee_id = ? AND status = 'absent' 
                         AND attendance_date BETWEEN ? AND ?",
                        [$schoolId, $empId, $monthStart, $monthEnd]
                    );

                    $leaves = Database::fetchAll(
                        "SELECT start_date, end_date FROM leave_requests 
                         WHERE school_id = ? AND employee_id = ? AND status = 'approved'
                         AND (start_date <= ? AND end_date >= ?)",
                        [$schoolId, $empId, $monthEnd, $monthStart]
                    );

                    foreach ($absences as $absent) {
                        $absDate = $absent['attendance_date'];
                        $onLeave = false;
                        foreach ($leaves as $leave) {
                            if ($absDate >= $leave['start_date'] && $absDate <= $leave['end_date']) {
                                $onLeave = true;
                                break;
                            }
                        }
                        if (!$onLeave) {
                            $unapprovedAbsences++;
                        }
                    }
                }

                $attendanceDeduction = $unapprovedAbsences * $deductionPerDay;
                $basic = (float) ($s['basic_salary'] ?? 30000.00);
                $house = (float) ($s['house_allowance'] ?? 0.0);
                $trans = (float) ($s['transport_allowance'] ?? 0.0);
                $other = (float) ($s['other_allowance'] ?? 0.0);
                $fixedDeductions = (float) ($s['deductions'] ?? 0.0);

                $allowances = $house + $trans + $other;
                $bonuses = max(0.0, $basic * ($bonusMultiplier - 1.0));
                $net = max(0.0, ($basic + $allowances + $bonuses) - ($fixedDeductions + $attendanceDeduction));

                $payrollId = Database::insert(
                    'INSERT INTO payroll
                    (school_id, employee_id, payroll_month, basic_salary, allowances, bonuses, deductions,
                     leave_deduction, attendance_deduction, net_salary, status, created_by, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 0.00, ?, ?, "pending", ?, NOW(), NOW())',
                    [
                        $schoolId,
                        $empId,
                        $month,
                        $basic,
                        $allowances,
                        $bonuses,
                        $fixedDeductions,
                        $attendanceDeduction,
                        $net,
                        Auth::id(),
                    ]
                );

                // Insert breakdown lines with strict tenant isolation
                Database::insert(
                    'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                    [$schoolId, $payrollId, 'Basic Salary', 'earning', $basic]
                );
                if ($house > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, 'House Rent Allowance (HRA)', 'earning', $house]
                    );
                }
                if ($trans > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, 'Transport Allowance', 'earning', $trans]
                    );
                }
                if ($other > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, 'Special Allowance', 'earning', $other]
                    );
                }
                if ($bonuses > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, 'Performance Bonus', 'earning', $bonuses]
                    );
                }
                if ($fixedDeductions > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, 'Standard Deductions', 'deduction', $fixedDeductions]
                    );
                }
                if ($attendanceDeduction > 0) {
                    Database::insert(
                        'INSERT INTO payroll_items (school_id, payroll_id, label, type, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $payrollId, "Attendance Deductions ({$unapprovedAbsences} unexcused days)", 'deduction', $attendanceDeduction]
                    );
                }

                $processed++;
            }

            auditLog('payroll.mass_generate', 'hr', 'payroll', 0, null, [
                'month' => $month,
                'processed' => $processed,
                'skipped' => $skipped,
            ]);

            return ['processed' => $processed, 'skipped' => $skipped];
        });
    }

    /**
     * Submit a draft payroll for approval.
     */
    public function submitForApproval(int $payrollId): void
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('payroll', $payrollId, $schoolId);

        Database::execute(
            'UPDATE payroll SET status = "pending", updated_at = NOW() 
             WHERE id = ? AND school_id = ? AND status = "draft"',
            [$payrollId, $schoolId]
        );

        auditLog('payroll.submit', 'hr', 'payroll', $payrollId);
    }

    /**
     * Approve payroll for disbursement.
     */
    public function approvePayroll(int $payrollId, int $approvedBy): void
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('payroll', $payrollId, $schoolId);

        Database::execute(
            'UPDATE payroll SET status = "approved", approved_by = ?, updated_at = NOW()
             WHERE id = ? AND school_id = ? AND status = "pending"',
            [$approvedBy, $payrollId, $schoolId]
        );

        auditLog('payroll.approve', 'hr', 'payroll', $payrollId, null, ['approved_by' => $approvedBy]);
    }

    /**
     * Disburse and record salary payment.
     */
    public function disburseSalary(int $payrollId, string $method, string $date, ?string $notes = null): void
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('payroll', $payrollId, $schoolId);

        Database::execute(
            'UPDATE payroll 
             SET status = "paid", payment_date = ?, payment_method = ?, notes = ?, updated_at = NOW()
             WHERE id = ? AND school_id = ? AND status = "approved"',
            [$date, $method, $notes, $payrollId, $schoolId]
        );

        auditLog('payroll.disburse', 'finance', 'payroll', $payrollId, null, [
            'payment_method' => $method,
            'payment_date' => $date,
        ]);
    }

    /**
     * Backward-compatible alias for approvePayroll.
     */
    public function approve(int $payrollId, ?int $approvedBy = null): void
    {
        $this->approvePayroll($payrollId, $approvedBy ?? (int) Auth::id() ?? 1);
    }

    /**
     * Backward-compatible alias for disburseSalary.
     */
    public function markPaid(int $payrollId, string $date, string $method = 'bank', ?string $notes = null): void
    {
        $this->disburseSalary($payrollId, $method, $date, $notes);
    }

    /**
     * Retrieve complete payslip dataset with employee, items, and school information.
     *
     * @param int $payrollId
     * @return array{payroll: array, items: array, school: array}
     */
    public function getPayslipDetails(int $payrollId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('payroll', $payrollId, $schoolId);

        $payroll = $this->payrollModel->findByIdWithDetails($payrollId);
        if (!$payroll) {
            throw new \RuntimeException('Payslip not found.');
        }

        $items = $this->payrollModel->items($payrollId);
        $school = Database::fetch('SELECT * FROM schools WHERE id = ?', [$schoolId]);

        return [
            'payroll' => $payroll,
            'items' => $items,
            'school' => $school ?: [],
        ];
    }

    /**
     * Month aggregate total.
     */
    public function monthTotal(string $month): float
    {
        $row = Database::fetch(
            'SELECT COALESCE(SUM(net_salary), 0) AS total FROM payroll WHERE school_id = ? AND payroll_month = ? AND status != "cancelled"',
            [Auth::schoolId(), $month]
        );
        return (float) ($row['total'] ?? 0.0);
    }

    /**
     * Count pending approval.
     */
    public function pendingCount(): int
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM payroll WHERE school_id = ? AND status IN ("draft", "pending")',
            [Auth::schoolId()]
        );
        return (int) ($row['c'] ?? 0);
    }
}
