<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * AiAnalyticsService
 * Compiles multi-dimensional historical student metrics (Attendance, Behavior, Academics)
 * into normalized tensors formatted for Machine Learning model inference (Dropout Risk,
 * Retention Analytics, Performance Forecasting).
 */
final class AiAnalyticsService
{
    /**
     * Compile student profile and activity records into a normalized ML ingestion dataset.
     *
     * @param int $schoolId
     * @param int $studentId
     * @return array Multi-dimensional ML dataset.
     */
    public function compileStudentDataset(int $schoolId, int $studentId): array
    {
        $student = Database::fetch(
            'SELECT s.id, s.school_id, s.class_id, s.section_id, s.admission_no, 
                    s.first_name, s.last_name, s.gender, s.date_of_birth, s.status,
                    c.name AS class_name, sec.name AS section_name
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             WHERE s.id = ? AND s.school_id = ? LIMIT 1',
            [$studentId, $schoolId]
        );

        if (!$student) {
            throw new \RuntimeException("Student #{$studentId} not found in tenant context.");
        }

        $attendanceMetrics = $this->computeAttendanceFeatures($schoolId, $studentId);
        $behaviorMetrics = $this->computeBehaviorFeatures($schoolId, $studentId);
        $academicMetrics = $this->computeAcademicFeatures($schoolId, $studentId);

        // Synthesize 10-dimensional normalized ML feature tensor [0.0 - 1.0]
        $mlVector = $this->buildNormalizedFeatureVector($attendanceMetrics, $behaviorMetrics, $academicMetrics);

        return [
            'status' => 'success',
            'schema_version' => 'v1.2-ml',
            'metadata' => [
                'tenant_id' => $schoolId,
                'student_id' => $studentId,
                'admission_no' => $student['admission_no'],
                'full_name' => trim($student['first_name'] . ' ' . $student['last_name']),
                'cohort' => [
                    'class_id' => (int) $student['class_id'],
                    'class_name' => $student['class_name'],
                    'section_id' => (int) $student['section_id'],
                    'section_name' => $student['section_name'],
                ],
                'vector_dimension' => count($mlVector['values']),
                'vector_labels' => $mlVector['labels'],
                'timestamp' => date('c'),
            ],
            'ml_feature_vector' => $mlVector['values'],
            'feature_breakdown' => [
                'attendance' => $attendanceMetrics,
                'behavior' => $behaviorMetrics,
                'academics' => $academicMetrics,
            ],
            'predictive_indices' => [
                'retention_health_score' => round($mlVector['values'][9] * 100, 2), // 0 to 100%
                'dropout_risk_category' => $this->categorizeRiskLevel($mlVector['values'][9]),
            ]
        ];
    }

    /**
     * Compute comprehensive attendance statistics and streak patterns.
     */
    private function computeAttendanceFeatures(int $schoolId, int $studentId): array
    {
        $records = Database::fetchAll(
            'SELECT attendance_date, status 
             FROM student_attendance 
             WHERE school_id = ? AND student_id = ? 
             ORDER BY attendance_date ASC',
            [$schoolId, $studentId]
        );

        $totalDays = count($records);
        if ($totalDays === 0) {
            return [
                'total_recorded_days' => 0,
                'present_rate' => 1.0,
                'absent_rate' => 0.0,
                'tardiness_rate' => 0.0,
                'excused_rate' => 0.0,
                'consecutive_absence_max_streak' => 0,
                'recent_30d_present_rate' => 1.0,
                'attendance_stability_index' => 1.0,
            ];
        }

        $presentCount = 0;
        $absentCount = 0;
        $lateCount = 0;
        $excusedCount = 0;

        $maxAbsentStreak = 0;
        $currentAbsentStreak = 0;

        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
        $recentTotal = 0;
        $recentPresent = 0;

        foreach ($records as $r) {
            $status = $r['status'];
            $date = $r['attendance_date'];

            if ($status === 'present') {
                $presentCount++;
                $currentAbsentStreak = 0;
            } elseif ($status === 'absent') {
                $absentCount++;
                $currentAbsentStreak++;
                if ($currentAbsentStreak > $maxAbsentStreak) {
                    $maxAbsentStreak = $currentAbsentStreak;
                }
            } elseif ($status === 'late') {
                $lateCount++;
                $currentAbsentStreak = 0;
            } elseif (in_array($status, ['leave', 'excused', 'half_day'], true)) {
                $excusedCount++;
                $currentAbsentStreak = 0;
            }

            if ($date >= $thirtyDaysAgo) {
                $recentTotal++;
                if (in_array($status, ['present', 'late', 'half_day'], true)) {
                    $recentPresent++;
                }
            }
        }

        $presentRate = round($presentCount / $totalDays, 4);
        $absentRate = round($absentCount / $totalDays, 4);
        $tardinessRate = round($lateCount / $totalDays, 4);
        $excusedRate = round($excusedCount / $totalDays, 4);
        $recent30dRate = $recentTotal > 0 ? round($recentPresent / $recentTotal, 4) : $presentRate;

        // Stability index penalizes unexcused absences and high tardiness
        $stability = max(0.0, min(1.0, 1.0 - ($absentRate * 1.5 + $tardinessRate * 0.5)));

        return [
            'total_recorded_days' => $totalDays,
            'present_rate' => $presentRate,
            'absent_rate' => $absentRate,
            'tardiness_rate' => $tardinessRate,
            'excused_rate' => $excusedRate,
            'consecutive_absence_max_streak' => $maxAbsentStreak,
            'recent_30d_present_rate' => $recent30dRate,
            'attendance_stability_index' => round($stability, 4),
        ];
    }

    /**
     * Compute behavioral merits, demerits, disciplinary incidents, and active warnings.
     */
    private function computeBehaviorFeatures(int $schoolId, int $studentId): array
    {
        $logs = Database::fetchAll(
            'SELECT points_impact, action_type, status, created_at 
             FROM student_behaviour_logs 
             WHERE school_id = ? AND student_id = ?',
            [$schoolId, $studentId]
        );

        $warnings = Database::fetchAll(
            'SELECT id, is_read, created_at 
             FROM student_warnings 
             WHERE school_id = ? AND student_id = ?',
            [$schoolId, $studentId]
        );

        $netPoints = 0;
        $meritsCount = 0;
        $demeritsCount = 0;
        $totalIncidents = count($logs);

        foreach ($logs as $log) {
            $points = (int) ($log['points_impact'] ?? 0);
            $netPoints += $points;
            if ($points > 0) {
                $meritsCount++;
            } elseif ($points < 0) {
                $demeritsCount++;
            }
        }

        $activeWarnings = count(array_filter($warnings, fn($w) => (int)$w['is_read'] === 0));

        // Normalization: 50 base points, each demerit subtracts, bounded [0.0, 1.0]
        $rawScore = 50 + ($netPoints * 5) - ($activeWarnings * 10);
        $conductStability = max(0.0, min(1.0, round($rawScore / 100.0, 4)));

        return [
            'net_points' => $netPoints,
            'total_incidents' => $totalIncidents,
            'merits_count' => $meritsCount,
            'demerits_count' => $demeritsCount,
            'total_warnings' => count($warnings),
            'active_warnings' => $activeWarnings,
            'conduct_stability_score' => $conductStability,
        ];
    }

    /**
     * Compute multi-term exam mark distributions, subject breakdown, and trajectory trends.
     */
    private function computeAcademicFeatures(int $schoolId, int $studentId): array
    {
        $marks = Database::fetchAll(
            'SELECT m.marks_obtained, es.max_marks, es.max_marks AS total_marks, es.pass_marks, s.name AS subject_name, e.id AS exam_id, e.name AS exam_name
             FROM exam_marks m
             INNER JOIN exam_subjects es ON es.id = m.exam_subject_id
             INNER JOIN subjects s ON s.id = es.subject_id
             INNER JOIN exams e ON e.id = m.exam_id
             WHERE m.school_id = ? AND m.student_id = ? AND m.marks_obtained IS NOT NULL
             ORDER BY e.id ASC',
            [$schoolId, $studentId]
        );

        if (empty($marks)) {
            return [
                'total_exams_evaluated' => 0,
                'overall_average_pct' => 75.0,
                'normalized_performance' => 0.75,
                'performance_std_dev' => 0.0,
                'trajectory_delta' => 0.0,
                'subject_breakdown' => [],
            ];
        }

        $subjectTotals = [];
        $percentages = [];
        $examGroups = [];

        foreach ($marks as $m) {
            $obtained = (float) $m['marks_obtained'];
            $max = (float) ($m['total_marks'] ?? $m['max_marks'] ?? 100.0);
            $pct = $max > 0 ? ($obtained / $max) * 100 : 0.0;

            $percentages[] = $pct;
            $subjectName = $m['subject_name'] ?? 'General';

            $subjectTotals[$subjectName][] = $pct;
            $examGroups[$m['exam_id']][] = $pct;
        }

        $avgPct = count($percentages) > 0 ? array_sum($percentages) / count($percentages) : 0.0;

        // Compute Standard Deviation for consistency index
        $variance = 0.0;
        foreach ($percentages as $p) {
            $variance += pow($p - $avgPct, 2);
        }
        $stdDev = count($percentages) > 1 ? sqrt($variance / (count($percentages) - 1)) : 0.0;

        // Trajectory delta (compare latest exam average with initial exam average)
        $trajectoryDelta = 0.0;
        if (count($examGroups) >= 2) {
            $examKeys = array_keys($examGroups);
            $firstExamAvg = array_sum($examGroups[$examKeys[0]]) / count($examGroups[$examKeys[0]]);
            $latestExamAvg = array_sum(end($examGroups)) / count(end($examGroups));
            $trajectoryDelta = $latestExamAvg - $firstExamAvg;
        }

        $subjectBreakdown = [];
        foreach ($subjectTotals as $sub => $scores) {
            $subjectBreakdown[$sub] = round(array_sum($scores) / count($scores), 2);
        }

        return [
            'total_exams_evaluated' => count($marks),
            'overall_average_pct' => round($avgPct, 2),
            'normalized_performance' => round($avgPct / 100.0, 4),
            'performance_std_dev' => round($stdDev, 2),
            'trajectory_delta' => round($trajectoryDelta, 2),
            'subject_breakdown' => $subjectBreakdown,
        ];
    }

    /**
     * Synthesize 10 normalized float features [0.0 - 1.0] for Machine Learning model ingestion.
     */
    private function buildNormalizedFeatureVector(array $att, array $beh, array $acad): array
    {
        $presentRate = (float) $att['present_rate'];
        $tardinessRate = (float) $att['tardiness_rate'];
        $recent30dRate = (float) $att['recent_30d_present_rate'];
        $conductStability = (float) $beh['conduct_stability_score'];
        $academicNorm = (float) $acad['normalized_performance'];

        // Consistency index: low standard deviation = high consistency (bounded 0 to 1)
        $consistencyIndex = max(0.0, min(1.0, 1.0 - ($acad['performance_std_dev'] / 50.0)));

        // Trajectory slope: delta of +20 maps to 1.0, -20 maps to 0.0, 0 maps to 0.5
        $trajectoryIndex = max(0.0, min(1.0, 0.5 + ($acad['trajectory_delta'] / 40.0)));

        // Active warnings penalty
        $warningsPenalty = max(0.0, min(1.0, 1.0 - ((int)$beh['active_warnings'] * 0.2)));

        // Streak penalty
        $streakPenalty = max(0.0, min(1.0, 1.0 - ((int)$att['consecutive_absence_max_streak'] * 0.1)));

        // Composite Retention Health Score (weighted combination)
        $retentionScore = (
            ($presentRate * 0.30) +
            ($recent30dRate * 0.15) +
            ($conductStability * 0.15) +
            ($academicNorm * 0.25) +
            ($warningsPenalty * 0.10) +
            ($streakPenalty * 0.05)
        );

        $labels = [
            'f0_present_rate',
            'f1_tardiness_rate',
            'f2_recent_30d_present_rate',
            'f3_conduct_stability_score',
            'f4_normalized_academic_performance',
            'f5_exam_consistency_index',
            'f6_academic_trajectory_index',
            'f7_warnings_penalty_factor',
            'f8_absence_streak_factor',
            'f9_composite_retention_index',
        ];

        $values = [
            round($presentRate, 4),
            round($tardinessRate, 4),
            round($recent30dRate, 4),
            round($conductStability, 4),
            round($academicNorm, 4),
            round($consistencyIndex, 4),
            round($trajectoryIndex, 4),
            round($warningsPenalty, 4),
            round($streakPenalty, 4),
            round(max(0.0, min(1.0, $retentionScore)), 4),
        ];

        return [
            'labels' => $labels,
            'values' => $values,
        ];
    }

    private function categorizeRiskLevel(float $retentionScore): string
    {
        if ($retentionScore >= 0.85) return 'Low (Thriving)';
        if ($retentionScore >= 0.70) return 'Moderate (Stable)';
        if ($retentionScore >= 0.50) return 'Elevated (Attention Required)';
        return 'Critical (High Dropout Risk)';
    }
}
