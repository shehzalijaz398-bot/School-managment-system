<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;

final class SuperAdminOversightService
{
    /**
     * Retrieve global platform health, subscription distributions, and capacity telemetry.
     * Keeps platform-level management strictly separated from private tenant student data.
     */
    public function getPlatformHealthOverview(): array
    {
        // 1. Subscription & School Counts
        $statusCounts = Database::fetchAll("
            SELECT subscription_status, COUNT(*) AS count
            FROM schools
            WHERE deleted_at IS NULL
            GROUP BY subscription_status
        ");

        $byStatus = [
            'total' => 0,
            'active' => 0,
            'trial' => 0,
            'pending' => 0,
            'past_due' => 0,
            'suspended' => 0,
            'expired' => 0
        ];

        foreach ($statusCounts as $sc) {
            $status = (string)($sc['subscription_status'] ?: 'pending');
            $cnt = (int)$sc['count'];
            $byStatus[$status] = $cnt;
            $byStatus['total'] += $cnt;
        }

        // 2. Global Aggregate Usage Metrics (Aggregated counts only, no private records)
        $studentCountRow = Database::fetch("SELECT COUNT(*) AS total FROM students");
        $employeeCountRow = Database::fetch("SELECT COUNT(*) AS total FROM employees");
        $totalStudents = (int)($studentCountRow['total'] ?? 0);
        $totalStaff = (int)($employeeCountRow['total'] ?? 0);

        // 3. Plan Distribution
        $plansDistribution = Database::fetchAll("
            SELECT p.id, p.name, COUNT(s.id) AS active_schools, p.student_limit, p.monthly_price
            FROM plans p
            LEFT JOIN schools s ON s.plan_id = p.id AND s.deleted_at IS NULL
            WHERE p.status = 1
            GROUP BY p.id, p.name, p.student_limit, p.monthly_price
            ORDER BY p.sort_order ASC
        ");

        // 4. Capacity & Usage Warnings: Schools exceeding 85% of plan student limit
        $schoolsNearLimit = Database::fetchAll("
            SELECT s.id, s.name, s.subscription_status,
                   COALESCE(s.override_student_limit, p.student_limit) AS max_students,
                   (SELECT COUNT(*) FROM students stu WHERE stu.school_id = s.id) AS current_students
            FROM schools s
            LEFT JOIN plans p ON p.id = s.plan_id
            WHERE s.deleted_at IS NULL AND s.status = 1
            HAVING current_students > 0 AND max_students IS NOT NULL AND (current_students / max_students) >= 0.85
            ORDER BY (current_students / max_students) DESC
            LIMIT 10
        ");

        $warnings = [];
        foreach ($schoolsNearLimit as $row) {
            $current = (int)$row['current_students'];
            $max = (int)$row['max_students'];
            $percent = round(($current / $max) * 100, 1);
            $warnings[] = [
                'school_id' => (int)$row['id'],
                'school_name' => $row['name'],
                'current_students' => $current,
                'max_students' => $max,
                'utilization_percent' => $percent,
                'status' => $percent >= 100 ? 'exceeded' : 'near_limit'
            ];
        }

        return [
            'schools_by_status' => $byStatus,
            'total_students_hosted' => $totalStudents,
            'total_staff_hosted' => $totalStaff,
            'plans_distribution' => $plansDistribution,
            'capacity_warnings' => $warnings,
            'warnings_count' => count($warnings),
            'checked_at' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Retrieve high-level institutional governance info without private student data.
     * Enforces the Privacy Boundary: Confidential records remain inaccessible to SuperAdmin.
     */
    public function getSchoolGovernanceDetails(int $schoolId): ?array
    {
        $school = Database::fetch("
            SELECT s.*, p.name AS plan_name, p.student_limit, p.teacher_limit, p.employee_limit, p.storage_limit_mb
            FROM schools s
            LEFT JOIN plans p ON p.id = s.plan_id
            WHERE s.id = ? AND s.deleted_at IS NULL
            LIMIT 1
        ", [$schoolId]);

        if (!$school) {
            return null;
        }

        // Usage counts
        $studentCnt = (int)(Database::fetch("SELECT COUNT(*) AS c FROM students WHERE school_id = ?", [$schoolId])['c'] ?? 0);
        $employeeCnt = (int)(Database::fetch("SELECT COUNT(*) AS c FROM employees WHERE school_id = ?", [$schoolId])['c'] ?? 0);

        $activeStudentLimit = $school['override_student_limit'] ?? $school['student_limit'] ?? null;
        $studentUtilization = $activeStudentLimit ? round(($studentCnt / (int)$activeStudentLimit) * 100, 1) : 0;

        return [
            'id' => (int)$school['id'],
            'name' => $school['name'],
            'code' => $school['code'] ?? '',
            'email' => $school['email'],
            'status' => (int)$school['status'] === 1 ? 'active' : 'suspended',
            'subscription_status' => $school['subscription_status'] ?? 'pending',
            'plan_name' => $school['plan_name'] ?? 'Custom Plan',
            'active_student_limit' => $activeStudentLimit,
            'active_teacher_limit' => $school['override_teacher_limit'] ?? $school['teacher_limit'] ?? null,
            'student_count' => $studentCnt,
            'employee_count' => $employeeCnt,
            'student_utilization_percent' => $studentUtilization,
            'is_near_capacity' => $studentUtilization >= 85,
            'created_at' => $school['created_at']
        ];
    }

    /**
     * Configure tenant operational limits (overrides).
     */
    public function updateSchoolUsageLimits(int $schoolId, array $limits, ?int $updatedBy = null): bool
    {
        $studentLimit = isset($limits['student_limit']) && $limits['student_limit'] !== '' ? (int)$limits['student_limit'] : null;
        $teacherLimit = isset($limits['teacher_limit']) && $limits['teacher_limit'] !== '' ? (int)$limits['teacher_limit'] : null;
        $employeeLimit = isset($limits['employee_limit']) && $limits['employee_limit'] !== '' ? (int)$limits['employee_limit'] : null;
        $storageLimitMb = isset($limits['storage_limit_mb']) && $limits['storage_limit_mb'] !== '' ? (int)$limits['storage_limit_mb'] : null;

        Database::execute("
            UPDATE schools 
            SET override_student_limit = ?,
                override_teacher_limit = ?,
                override_employee_limit = ?,
                override_storage_limit_mb = ?,
                updated_at = NOW()
            WHERE id = ?
        ", [$studentLimit, $teacherLimit, $employeeLimit, $storageLimitMb, $schoolId]);

        PlatformAudit::log('school.limits_updated', 'schools', $schoolId, 'limits', $schoolId, null, [
            'student_limit' => $studentLimit,
            'teacher_limit' => $teacherLimit,
            'updated_by' => $updatedBy
        ]);

        return true;
    }

    /**
     * Guard against unauthorized access to confidential school operational data.
     * Prevents SuperAdmin from querying student grades, health files, or private communications.
     */
    public function assertPrivacyBoundary(string $attemptedAction): void
    {
        $restrictedActions = [
            'view_student_grades',
            'view_private_messages',
            'view_student_medical',
            'modify_payroll_disbursals',
            'view_parent_credentials'
        ];

        if (in_array($attemptedAction, $restrictedActions, true)) {
            throw new \Core\Exceptions\TenantSecurityException("SuperAdmin Privacy Boundary Violation: Action '{$attemptedAction}' is strictly restricted to authorized tenant institution staff.");
        }
    }
}
