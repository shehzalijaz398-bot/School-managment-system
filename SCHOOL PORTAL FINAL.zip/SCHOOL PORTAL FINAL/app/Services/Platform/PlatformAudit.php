<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;
use Core\PlatformAuth;

final class PlatformAudit
{
    public static function log(
        string $action,
        string $module,
        ?int $schoolId = null,
        ?string $entityType = null,
        ?int $entityId = null,
        ?array $old = null,
        ?array $new = null
    ): void {
        Database::insert(
            'INSERT INTO platform_audit_logs
            (actor_id, actor_type, action, module, school_id, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
            [
                PlatformAuth::id(),
                'platform',
                $action,
                $module,
                $schoolId,
                $entityType,
                $entityId,
                $old !== null ? json_encode($old) : null,
                $new !== null ? json_encode($new) : null,
                $_SERVER['REMOTE_ADDR'] ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            ]
        );
    }
}
