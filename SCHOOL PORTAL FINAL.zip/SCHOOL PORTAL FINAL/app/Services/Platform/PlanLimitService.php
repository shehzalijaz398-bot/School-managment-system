<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;
use Core\TenantContext;

final class PlanLimitService
{
    public static function plan(?int $schoolId = null): ?array
    {
        $schoolId = $schoolId ?? TenantContext::schoolId();
        if (!$schoolId) {
            return null;
        }
        return Database::fetch(
            'SELECT p.* FROM plans p
             INNER JOIN schools s ON s.plan_id = p.id
             WHERE s.id = ? LIMIT 1',
            [$schoolId]
        );
    }

    public static function usage(?int $schoolId = null): array
    {
        $schoolId = $schoolId ?? TenantContext::currentSchoolId();
        $students = Database::fetch(
            'SELECT COUNT(*) AS c FROM students WHERE school_id = ? AND status = ?',
            [$schoolId, 'active']
        );
        $teachers = Database::fetch(
            'SELECT COUNT(*) AS c FROM teachers WHERE school_id = ? AND status = 1',
            [$schoolId]
        );
        $employees = Database::fetch(
            'SELECT COUNT(*) AS c FROM employees WHERE school_id = ? AND status = ?',
            [$schoolId, 'active']
        );
        return [
            'students' => (int) ($students['c'] ?? 0),
            'teachers' => (int) ($teachers['c'] ?? 0),
            'employees' => (int) ($employees['c'] ?? 0),
        ];
    }

    public static function tenantWithinLimit(string $metric, int $additional = 1, ?int $schoolId = null): bool
    {
        $schoolId = $schoolId ?? TenantContext::schoolId();
        try {
            $school = Database::fetch('SELECT override_student_limit, override_teacher_limit, override_employee_limit, override_storage_limit_mb FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
        } catch (\Throwable $e) {
            $school = null;
        }
        
        $plan = self::plan($schoolId);
        if (!$plan && !$school) {
            return true; // no plan bound = do not block (legacy)
        }

        $usage = self::usage($schoolId);
        $map = [
            'students' => 'student_limit',
            'teachers' => 'teacher_limit',
            'employees' => 'employee_limit',
        ];
        
        $limitKey = $map[$metric] ?? null;
        if (!$limitKey) {
            return true;
        }

        $overrideKey = 'override_' . $limitKey;
        if ($school && isset($school[$overrideKey]) && $school[$overrideKey] !== null) {
            $limit = $school[$overrideKey];
        } else {
            $limit = $plan[$limitKey] ?? null;
        }

        if ($limit === null) {
            return true; // unlimited
        }
        return ($usage[$metric] + $additional) <= (int) $limit;
    }

    public static function assertCanCreate(string $metric): void
    {
        if (!self::tenantWithinLimit($metric)) {
            $plan = self::plan();
            throw new \RuntimeException(
                'Plan limit reached for ' . $metric . '. Your ' . ($plan['name'] ?? 'current') .
                ' plan does not allow additional ' . $metric . '. Please upgrade.'
            );
        }
    }
}
