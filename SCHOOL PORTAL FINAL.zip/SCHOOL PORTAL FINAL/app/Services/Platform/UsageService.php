<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;

final class UsageService
{
    public static function snapshot(?int $schoolId = null): void
    {
        $schools = $schoolId
            ? [['id' => $schoolId]]
            : Database::fetchAll('SELECT id FROM schools WHERE deleted_at IS NULL');

        foreach ($schools as $s) {
            $id = (int) $s['id'];
            $usage = PlanLimitService::usage($id);
            $users = Database::fetch('SELECT COUNT(*) AS c FROM users WHERE school_id = ? AND status = 1', [$id]);
            $exists = Database::fetch(
                'SELECT id FROM school_usage WHERE school_id = ? AND metric_date = CURDATE() LIMIT 1',
                [$id]
            );
            if ($exists) {
                Database::execute(
                    'UPDATE school_usage SET students_count = ?, teachers_count = ?, employees_count = ?, users_count = ?, updated_at = NOW() WHERE id = ?',
                    [$usage['students'], $usage['teachers'], $usage['employees'], (int) ($users['c'] ?? 0), (int) $exists['id']]
                );
            } else {
                Database::insert(
                    'INSERT INTO school_usage (school_id, metric_date, students_count, teachers_count, employees_count, users_count, storage_mb, created_at, updated_at)
                     VALUES (?, CURDATE(), ?, ?, ?, ?, 0, NOW(), NOW())',
                    [$id, $usage['students'], $usage['teachers'], $usage['employees'], (int) ($users['c'] ?? 0)]
                );
            }
        }
    }
}
