<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;

final class SubscriptionService
{
    public static function startTrial(int $schoolId, int $planId, int $trialDays): int
    {
        $plan = Database::fetch('SELECT * FROM plans WHERE id = ? LIMIT 1', [$planId]);
        if (!$plan) {
            throw new \RuntimeException('Plan not found.');
        }
        $days = $trialDays > 0 ? $trialDays : (int) $plan['trial_days'];
        $start = date('Y-m-d');
        $end = date('Y-m-d', strtotime("+{$days} days"));

        Database::beginTransaction();
        try {
            $id = Database::insert(
                'INSERT INTO subscriptions
                (school_id, plan_id, billing_cycle, start_date, end_date, trial_end_date, status, amount, currency, auto_renew, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 1, NOW(), NOW())',
                [$schoolId, $planId, 'monthly', $start, $end, $end, 'trial', 'PKR']
            );
            Database::execute(
                'UPDATE schools SET plan_id = ?, subscription_status = ?, trial_started_at = COALESCE(trial_started_at, NOW()), trial_ends_at = ?, subscription_ends_at = ?, status = 1, updated_at = NOW() WHERE id = ?',
                [$planId, 'trial', $end . ' 23:59:59', $end . ' 23:59:59', $schoolId]
            );
            PlatformAudit::log('subscription.trial', 'subscriptions', $schoolId, 'subscription', $id, null, ['end' => $end]);
            Database::commit();
            return $id;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public static function activate(int $schoolId, int $planId, string $cycle = 'monthly', ?int $months = null): int
    {
        $plan = Database::fetch('SELECT * FROM plans WHERE id = ? LIMIT 1', [$planId]);
        if (!$plan) {
            throw new \RuntimeException('Plan not found.');
        }
        $months = $months ?? ($cycle === 'annual' ? 12 : 1);
        $amount = $cycle === 'annual' ? (float) $plan['annual_price'] : (float) $plan['monthly_price'];
        $start = date('Y-m-d');
        $end = date('Y-m-d', strtotime("+{$months} months"));

        Database::beginTransaction();
        try {
            Database::execute(
                'UPDATE subscriptions SET status = ? WHERE school_id = ? AND status IN ("trial","active","past_due")',
                ['cancelled', $schoolId]
            );
            $id = Database::insert(
                'INSERT INTO subscriptions
                (school_id, plan_id, billing_cycle, start_date, end_date, trial_end_date, status, amount, currency, auto_renew, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, 1, NOW(), NOW())',
                [$schoolId, $planId, $cycle, $start, $end, 'active', $amount, 'PKR']
            );
            Database::execute(
                'UPDATE schools SET plan_id = ?, subscription_status = ?, subscription_ends_at = ?, trial_ends_at = NULL, status = 1, updated_at = NOW() WHERE id = ?',
                [$planId, 'active', $end . ' 23:59:59', $schoolId]
            );
            PlatformAudit::log('subscription.activate', 'subscriptions', $schoolId, 'subscription', $id);
            Database::commit();
            return $id;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public static function extend(int $schoolId, int $days): void
    {
        $school = Database::fetch('SELECT * FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
        if (!$school) {
            throw new \RuntimeException('School not found.');
        }
        $base = $school['subscription_ends_at'] && strtotime($school['subscription_ends_at']) > time()
            ? $school['subscription_ends_at']
            : date('Y-m-d H:i:s');
        $newEnd = date('Y-m-d H:i:s', strtotime($base . " +{$days} days"));
        Database::execute(
            'UPDATE schools SET subscription_ends_at = ?, subscription_status = ?, status = 1, updated_at = NOW() WHERE id = ?',
            [$newEnd, 'active', $schoolId]
        );
        Database::execute(
            'UPDATE subscriptions SET end_date = ?, status = ?, updated_at = NOW()
             WHERE school_id = ? ORDER BY id DESC LIMIT 1',
            [date('Y-m-d', strtotime($newEnd)), 'active', $schoolId]
        );
        PlatformAudit::log('subscription.extend', 'subscriptions', $schoolId, 'school', $schoolId, null, ['days' => $days, 'new_end' => $newEnd]);
    }

    public static function changePlan(int $schoolId, int $planId): void
    {
        $old = Database::fetch('SELECT plan_id FROM schools WHERE id = ?', [$schoolId]);
        Database::execute('UPDATE schools SET plan_id = ?, updated_at = NOW() WHERE id = ?', [$planId, $schoolId]);
        Database::execute(
            'UPDATE subscriptions SET plan_id = ?, updated_at = NOW() WHERE school_id = ? AND status IN ("trial","active","past_due")',
            [$planId, $schoolId]
        );
        FeatureAccessService::clearCache();
        PlatformAudit::log('subscription.plan_change', 'subscriptions', $schoolId, 'school', $schoolId, ['plan_id' => $old['plan_id'] ?? null], ['plan_id' => $planId]);
    }

    /** Idempotent status sync for cron */
    public static function syncExpired(): int
    {
        $rows = Database::fetchAll(
            'SELECT id FROM schools
             WHERE deleted_at IS NULL
               AND subscription_status IN ("trial","active","past_due")
               AND subscription_ends_at IS NOT NULL
               AND subscription_ends_at < NOW()'
        );
        $n = 0;
        foreach ($rows as $r) {
            TenantService::setStatus((int) $r['id'], 'expired', 0);
            Database::execute(
                'UPDATE subscriptions SET status = ?, updated_at = NOW() WHERE school_id = ? AND status IN ("trial","active","past_due")',
                ['expired', (int) $r['id']]
            );
            $n++;
        }
        return $n;
    }

    public static function expiringWithin(int $days): array
    {
        return Database::fetchAll(
            'SELECT s.*, p.name AS plan_name FROM schools s
             LEFT JOIN plans p ON p.id = s.plan_id
             WHERE s.deleted_at IS NULL
               AND s.subscription_status IN ("trial","active","past_due")
               AND s.subscription_ends_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL ? DAY)
             ORDER BY s.subscription_ends_at ASC',
            [$days]
        );
    }
}
