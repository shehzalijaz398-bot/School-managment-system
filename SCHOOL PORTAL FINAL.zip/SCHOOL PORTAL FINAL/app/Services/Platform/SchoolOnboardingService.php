<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;

final class SchoolOnboardingService
{
    /**
     * Provision tenant with default roles/permissions cloned from a template school or seeds.
     */
    public static function provision(array $schoolData, array $adminData, int $planId, bool $startTrial = true): int
    {
        Database::beginTransaction();
        try {
            $schoolData['plan_id'] = $planId;
            $schoolData['subscription_status'] = $startTrial ? 'trial' : 'pending';
            $schoolData['status'] = $startTrial ? 1 : 0;
            $schoolId = TenantService::createSchool($schoolData);

            self::cloneRolesAndPermissions($schoolId);
            self::seedBasics($schoolId);

            $role = Database::fetch(
                'SELECT id FROM roles WHERE school_id = ? AND slug = ? LIMIT 1',
                [$schoolId, 'school_admin']
            );
            if (!$role) {
                $role = Database::fetch(
                    'SELECT id FROM roles WHERE school_id = ? AND slug = ? LIMIT 1',
                    [$schoolId, 'principal']
                );
            }

            $passwordHash = $adminData['password_hash'] ?? password_hash((string) ($adminData['password'] ?? ''), PASSWORD_DEFAULT);
            if (!is_string($passwordHash) || $passwordHash === '') {
                throw new \InvalidArgumentException('A password hash is required for the administrator account.');
            }

            $userId = Database::insert(
                'INSERT INTO users (school_id, name, email, phone, password, role_id, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                [
                    $schoolId,
                    $adminData['name'],
                    strtolower(trim($adminData['email'])),
                    $adminData['phone'] ?? null,
                    $passwordHash,
                    (int) $role['id'],
                ]
            );

            $addressParts = array_filter([
                $schoolData['house_number'] ?? '',
                $schoolData['street'] ?? '',
                $schoolData['area'] ?? '',
                $schoolData['city'] ?? '',
                $schoolData['province'] ?? '',
                $schoolData['country'] ?? ''
            ]);
            $resolvedAddress = !empty($schoolData['address']) ? $schoolData['address'] : (!empty($addressParts) ? implode(', ', $addressParts) : '');

            $initialSettings = [
                'school_name' => $schoolData['name'],
                'primary_email' => $schoolData['email'] ?? '',
                'primary_phone' => $schoolData['phone'] ?? '',
                'institution_website' => $schoolData['website'] ?? '',
                'postal_address' => $resolvedAddress,
                'timezone' => $schoolData['timezone'] ?? 'Asia/Karachi',
                'currency' => $schoolData['currency'] ?? 'PKR',
                'date_format' => $schoolData['date_format'] ?? 'd M Y',
                'time_format' => '12_hour',
                'grading_system' => 'letter_grade',
                'passing_percentage' => '40',
                'admission_status' => 'open',
                'theme_color' => $schoolData['theme_color'] ?? '#0b4f6c',
                'default_language' => $schoolData['default_language'] ?? 'en',
                'school_type' => $schoolData['school_type'] ?? 'Private School',
                'education_levels' => $schoolData['education_levels'] ?? 'Montessori,Primary,Middle,Matric',
                'curriculum' => $schoolData['curriculum'] ?? 'Federal Board',
                'academic_year_start' => $schoolData['academic_year_start'] ?? 'April',
                'academic_year_end' => $schoolData['academic_year_end'] ?? 'March',
                'estimated_staff' => (string) ($schoolData['estimated_staff'] ?? '25'),
            ];
            foreach ($initialSettings as $sKey => $sVal) {
                Database::insert(
                    'INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
                    [$schoolId, $sKey, (string) $sVal]
                );
            }

            if (!empty($schoolData['website'])) {
                Database::execute('UPDATE schools SET website = ? WHERE id = ?', [$schoolData['website'], $schoolId]);
            }

            // Seed initial school branding
            try {
                Database::insert(
                    'INSERT INTO school_branding (school_id, primary_color, secondary_color, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
                    [$schoolId, $schoolData['primary_color'] ?? '#0b4f6c', $schoolData['secondary_color'] ?? '#01baef']
                );
            } catch (\Throwable) {
                // Ignore if already provisioned or table not ready
            }

            if ($startTrial) {
                $plan = Database::fetch('SELECT trial_days FROM plans WHERE id = ?', [$planId]);
                $trialDays = (int) ($plan['trial_days'] ?? 30);
                if ($trialDays <= 0) $trialDays = 30;
                SubscriptionService::startTrial($schoolId, $planId, $trialDays);
            }

            Database::insert(
                'INSERT INTO platform_notifications (user_id, school_id, type, title, message, is_read, created_at)
                 VALUES (NULL, ?, ?, ?, ?, 0, NOW())',
                [$schoolId, 'school.registered', 'New school provisioned', $schoolData['name'] . ' is ready on the platform.']
            );

            PlatformAudit::log('school.provision', 'onboarding', $schoolId, 'school', $schoolId, null, ['admin_user_id' => $userId]);
            Database::commit();
            return $schoolId;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    private static function cloneRolesAndPermissions(int $schoolId): void
    {
        $allPermissions = Database::fetchAll('SELECT id, slug FROM permissions');
        $permMap = [];
        foreach ($allPermissions as $p) {
            $permMap[$p['slug']] = (int) $p['id'];
        }

        $coreRoles = [
            ['name' => 'School Admin', 'slug' => 'school_admin', 'description' => 'Full administrative access', 'is_system' => 1],
            ['name' => 'Principal', 'slug' => 'principal', 'description' => 'Academic and institutional leadership', 'is_system' => 1],
            ['name' => 'Teacher', 'slug' => 'teacher', 'description' => 'Instruction and student evaluation', 'is_system' => 1],
            ['name' => 'Accountant', 'slug' => 'accountant', 'description' => 'Financial operations and fee collection', 'is_system' => 1],
            ['name' => 'Receptionist', 'slug' => 'receptionist', 'description' => 'Front desk and admissions', 'is_system' => 1],
            ['name' => 'Parent', 'slug' => 'parent', 'description' => 'Guardian access to student portal', 'is_system' => 1],
            ['name' => 'Student', 'slug' => 'student', 'description' => 'Student self-service portal', 'is_system' => 1],
        ];

        $rolePermSlugs = [
            'school_admin' => array_keys($permMap),
            'principal' => array_filter(array_keys($permMap), fn($s) => !in_array($s, ['assignments.grade'], true)),
            'teacher' => [
                'students.view', 'classes.view', 'attendance.students.mark', 'attendance.students.view',
                'assignments.create', 'assignments.grade', 'assignments.view', 'exams.view',
                'grades.manage', 'grades.view', 'reports.view', 'timetable.view', 'leave.request',
                'announcements.manage', 'teacher_assignments.view'
            ],
            'accountant' => [
                'finance.view', 'finance.manage', 'payroll.manage', 'payroll.approve',
                'reports.view', 'students.view', 'leave.request'
            ],
            'receptionist' => [
                'students.view', 'students.create', 'students.edit', 'admissions.manage',
                'reception.manage', 'announcements.manage', 'classes.view', 'leave.request'
            ],
            'parent' => [
                'parent.portal', 'assignments.view', 'exams.view', 'grades.view',
                'attendance.students.view', 'timetable.view'
            ],
            'student' => [
                'assignments.view', 'exams.view', 'grades.view',
                'attendance.students.view', 'timetable.view'
            ],
        ];

        foreach ($coreRoles as $r) {
            $newRoleId = Database::insert(
                'INSERT INTO roles (school_id, name, slug, description, is_system, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
                [$schoolId, $r['name'], $r['slug'], $r['description'], $r['is_system']]
            );

            $targetPermSlugs = $rolePermSlugs[$r['slug']] ?? [];
            foreach ($targetPermSlugs as $slug) {
                if (isset($permMap[$slug])) {
                    Database::insert(
                        'INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)',
                        [$newRoleId, $permMap[$slug]]
                    );
                }
            }
        }
    }

    private static function seedBasics(int $schoolId): void
    {
        Database::insert(
            'INSERT INTO academic_years (school_id, name, start_date, end_date, is_active, created_at, updated_at)
             VALUES (?, ?, ?, ?, 1, NOW(), NOW())',
            [$schoolId, date('Y') . '-' . (date('Y') + 1), date('Y') . '-04-01', (date('Y') + 1) . '-03-31']
        );
        foreach (['A+', 'A', 'B', 'C', 'D', 'F'] as $i => $g) {
            $mins = [90, 80, 70, 60, 50, 0];
            $maxs = [100, 89.99, 79.99, 69.99, 59.99, 49.99];
            Database::insert(
                'INSERT INTO grade_scales (school_id, grade, min_percentage, max_percentage, created_at)
                 VALUES (?, ?, ?, ?, NOW())',
                [$schoolId, $g, $mins[$i], $maxs[$i]]
            );
        }
        foreach (['Sick Leave', 'Casual Leave', 'Annual Leave', 'Unpaid Leave'] as $lt) {
            Database::insert(
                'INSERT INTO leave_types (school_id, name, is_paid, created_at) VALUES (?, ?, ?, NOW())',
                [$schoolId, $lt, $lt === 'Unpaid Leave' ? 0 : 1]
            );
        }
        foreach (['Academics', 'Administration', 'Finance', 'Human Resources'] as $d) {
            Database::insert(
                'INSERT INTO departments (school_id, name, status, created_at, updated_at) VALUES (?, ?, 1, NOW(), NOW())',
                [$schoolId, $d]
            );
        }
        foreach (['Principal', 'Teacher', 'HR Manager', 'Accountant', 'Receptionist'] as $des) {
            Database::insert(
                'INSERT INTO designations (school_id, name, status, created_at, updated_at) VALUES (?, ?, 1, NOW(), NOW())',
                [$schoolId, $des]
            );
        }
        foreach (['Midterm', 'Final', 'Quiz', 'Class Test'] as $et) {
            Database::insert(
                'INSERT INTO exam_types (school_id, name, created_at) VALUES (?, ?, NOW())',
                [$schoolId, $et]
            );
        }

        // Seed default timetable periods
        for ($i = 1; $i <= 7; $i++) {
            $start = sprintf('%02d:00:00', 7 + $i);
            $end = sprintf('%02d:45:00', 7 + $i);
            Database::insert(
                'INSERT INTO timetable_periods (school_id, period_number, start_time, end_time, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())',
                [$schoolId, $i, $start, $end]
            );
        }

        // Seed default core fee categories
        $defaultFees = [
            ['name' => 'Monthly Tuition Fee', 'code' => 'TUITION_MONTHLY', 'amount' => 500.00, 'freq' => 'monthly'],
            ['name' => 'Admission & Registration Fee', 'code' => 'ADMISSION_FEE', 'amount' => 1500.00, 'freq' => 'one_time'],
            ['name' => 'Examination & Testing Fee', 'code' => 'EXAM_FEE', 'amount' => 300.00, 'freq' => 'term'],
        ];
        foreach ($defaultFees as $df) {
            Database::insert(
                'INSERT INTO fee_categories (school_id, name, code, description, amount, frequency, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                [$schoolId, $df['name'], $df['code'], 'Standard institutional fee', $df['amount'], $df['freq']]
            );
        }
    }
}
