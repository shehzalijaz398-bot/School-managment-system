<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;
use Core\PlatformAuth;

final class BillingService
{
    public static function nextInvoiceNo(): string
    {
        $prefix = platform_setting('invoice_prefix', 'SAAS');
        $year = date('Y');
        $row = Database::fetch(
            'SELECT invoice_no FROM subscription_invoices WHERE invoice_no LIKE ? ORDER BY id DESC LIMIT 1',
            ["{$prefix}-{$year}-%"]
        );
        $seq = 1;
        if ($row && preg_match('/(\d+)$/', $row['invoice_no'], $m)) {
            $seq = (int) $m[1] + 1;
        }
        return sprintf('%s-%s-%04d', $prefix, $year, $seq);
    }

    public static function createInvoice(int $schoolId, array $data, array $items): int
    {
        Database::beginTransaction();
        try {
            $subtotal = 0.0;
            foreach ($items as $item) {
                $subtotal += (float) $item['amount'];
            }
            $discount = (float) ($data['discount'] ?? 0);
            $tax = (float) ($data['tax'] ?? 0);
            $total = $subtotal - $discount + $tax;
            $no = self::nextInvoiceNo();

            $id = Database::insert(
                'INSERT INTO subscription_invoices
                (school_id, subscription_id, invoice_no, billing_period_start, billing_period_end,
                 subtotal, discount, tax, total_amount, paid_amount, due_date, status, notes, created_by, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $schoolId,
                    $data['subscription_id'] ?? null,
                    $no,
                    $data['billing_period_start'],
                    $data['billing_period_end'],
                    $subtotal,
                    $discount,
                    $tax,
                    $total,
                    $data['due_date'],
                    'pending',
                    $data['notes'] ?? null,
                    PlatformAuth::id(),
                ]
            );
            foreach ($items as $item) {
                Database::insert(
                    'INSERT INTO subscription_invoice_items (invoice_id, description, amount, created_at) VALUES (?, ?, ?, NOW())',
                    [$id, $item['description'], $item['amount']]
                );
            }
            PlatformAudit::log('invoice.create', 'billing', $schoolId, 'subscription_invoice', $id);
            Database::commit();
            return $id;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public static function recordManualPayment(int $invoiceId, float $amount, string $method, ?string $reference, ?string $notes = null): int
    {
        Database::beginTransaction();
        try {
            $invoice = Database::fetch('SELECT * FROM subscription_invoices WHERE id = ? FOR UPDATE', [$invoiceId]);
            if (!$invoice) {
                throw new \RuntimeException('Invoice not found.');
            }
            $paymentId = Database::insert(
                'INSERT INTO subscription_payments
                (school_id, invoice_id, amount, currency, payment_method, payment_status, transaction_reference, paid_at, verified_by, notes, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, NOW(), NOW())',
                [
                    (int) $invoice['school_id'],
                    $invoiceId,
                    $amount,
                    'PKR',
                    $method,
                    'paid',
                    $reference,
                    PlatformAuth::id(),
                    $notes,
                ]
            );
            Database::insert(
                'INSERT INTO payment_transactions (school_id, payment_id, gateway, gateway_reference, amount, currency, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
                [(int) $invoice['school_id'], $paymentId, 'manual', $reference, $amount, 'PKR', 'paid']
            );

            $paid = (float) $invoice['paid_amount'] + $amount;
            $total = (float) $invoice['total_amount'];
            $status = $paid + 0.001 >= $total ? 'paid' : 'partial';
            Database::execute(
                'UPDATE subscription_invoices SET paid_amount = ?, status = ?, updated_at = NOW() WHERE id = ?',
                [$paid, $status, $invoiceId]
            );

            if ($status === 'paid') {
                $school = Database::fetch('SELECT * FROM schools WHERE id = ?', [(int) $invoice['school_id']]);
                if ($school && $school['plan_id']) {
                    SubscriptionService::activate((int) $invoice['school_id'], (int) $school['plan_id'], 'monthly');
                } else {
                    TenantService::setStatus((int) $invoice['school_id'], 'active', 1);
                }
            }

            PlatformAudit::log('payment.verify', 'billing', (int) $invoice['school_id'], 'subscription_payment', $paymentId, null, ['amount' => $amount]);
            Database::commit();
            return $paymentId;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }
}
