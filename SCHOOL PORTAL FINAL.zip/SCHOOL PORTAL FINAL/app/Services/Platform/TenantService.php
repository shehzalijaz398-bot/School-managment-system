<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;
use Core\PlatformAuth;

final class TenantService
{
    public static function generateSchoolCode(string $cityHint = ''): string
    {
        $prefix = 'SCH';
        if ($cityHint !== '') {
            $city = strtoupper(preg_replace('/[^A-Za-z]/', '', $cityHint) ?? '');
            $prefix = 'SCH-' . substr($city !== '' ? $city : 'XX', 0, 3);
        }
        do {
            $code = $prefix . '-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = Database::fetch('SELECT id FROM schools WHERE code = ? LIMIT 1', [$code]);
        } while ($exists);
        return $code;
    }

    public static function generateUuid(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    public static function createSchool(array $data): int
    {
        Database::beginTransaction();
        try {
            $code = $data['code'] ?? self::generateSchoolCode($data['city'] ?? '');
            $uuid = $data['school_uuid'] ?? self::generateUuid();

            $address = $data['address'] ?? null;
            if (empty($address)) {
                $addressParts = array_filter([
                    $data['house_number'] ?? '',
                    $data['street'] ?? '',
                    $data['area'] ?? '',
                    $data['city'] ?? '',
                    $data['province'] ?? '',
                    $data['country'] ?? ''
                ]);
                if (!empty($addressParts)) {
                    $address = implode(', ', $addressParts);
                }
            }

            $id = Database::insert(
                'INSERT INTO schools
                (school_uuid, name, code, email, website, phone, address, country, province, city, area, street, house_number, logo, timezone, currency,
                 plan_id, subscription_status, trial_ends_at, subscription_ends_at, notes, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $uuid,
                    $data['name'],
                    $code,
                    $data['email'] ?? null,
                    $data['website'] ?? null,
                    $data['phone'] ?? null,
                    $address,
                    $data['country'] ?? null,
                    $data['province'] ?? null,
                    $data['city'] ?? null,
                    $data['area'] ?? null,
                    $data['street'] ?? null,
                    $data['house_number'] ?? null,
                    $data['logo'] ?? null,
                    $data['timezone'] ?? 'Asia/Karachi',
                    $data['currency'] ?? 'PKR',
                    $data['plan_id'] ?? null,
                    $data['subscription_status'] ?? 'pending',
                    $data['trial_ends_at'] ?? null,
                    $data['subscription_ends_at'] ?? null,
                    $data['notes'] ?? null,
                    (int) ($data['status'] ?? 0),
                ]
            );

            Database::insert(
                'INSERT INTO school_branding (school_id, primary_color, secondary_color, created_at, updated_at)
                 VALUES (?, ?, ?, NOW(), NOW())',
                [$id, '#0b4f6c', '#01baef']
            );

            PlatformAudit::log('school.create', 'schools', $id, 'school', $id, null, ['code' => $code, 'name' => $data['name']]);
            Database::commit();
            return $id;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public static function setStatus(int $schoolId, string $subscriptionStatus, ?int $enabled = null): void
    {
        $old = Database::fetch('SELECT * FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
        if (!$old) {
            throw new \RuntimeException('School not found.');
        }
        $statusFlag = $enabled;
        if ($statusFlag === null) {
            $statusFlag = in_array($subscriptionStatus, ['trial', 'active', 'past_due'], true) ? 1 : 0;
        }
        Database::execute(
            'UPDATE schools SET subscription_status = ?, status = ?, updated_at = NOW() WHERE id = ?',
            [$subscriptionStatus, $statusFlag, $schoolId]
        );
        PlatformAudit::log('school.status', 'schools', $schoolId, 'school', $schoolId, [
            'subscription_status' => $old['subscription_status'],
            'status' => $old['status'],
        ], [
            'subscription_status' => $subscriptionStatus,
            'status' => $statusFlag,
        ]);
    }

    public static function list(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $sql = 'SELECT s.*, p.name AS plan_name,
                (SELECT email FROM users u WHERE u.school_id = s.id ORDER BY u.id ASC LIMIT 1) AS owner_email,
                (SELECT name FROM users u WHERE u.school_id = s.id ORDER BY u.id ASC LIMIT 1) AS owner_name,
                (SELECT COUNT(*) FROM students st WHERE st.school_id = s.id AND st.status = 1) AS students_count
                FROM schools s
                LEFT JOIN plans p ON p.id = s.plan_id
                WHERE s.deleted_at IS NULL';
        $params = [];
        if (!empty($filters['q'])) {
            $sql .= ' AND (s.name LIKE ? OR s.code LIKE ? OR s.email LIKE ? OR EXISTS (SELECT 1 FROM users u WHERE u.school_id = s.id AND (u.email LIKE ? OR u.name LIKE ?)))';
            $q = '%' . $filters['q'] . '%';
            $params = array_merge($params, [$q, $q, $q, $q, $q]);
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND s.subscription_status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['plan_id'])) {
            $sql .= ' AND s.plan_id = ?';
            $params[] = (int) $filters['plan_id'];
        }
        $sql .= ' ORDER BY s.created_at DESC';

        $count = (int) (Database::fetch('SELECT COUNT(*) AS c FROM (' . $sql . ') t', $params)['c'] ?? 0);
        $offset = max(0, ($page - 1) * $perPage);
        $items = Database::fetchAll($sql . " LIMIT {$perPage} OFFSET {$offset}", $params);
        return [
            'items' => $items,
            'data' => $items,
            'total' => $count,
            'page' => $page,
            'current_page' => $page,
            'pages' => (int) ceil(max(1, $count) / $perPage),
            'last_page' => (int) ceil(max(1, $count) / $perPage),
        ];
    }
}
