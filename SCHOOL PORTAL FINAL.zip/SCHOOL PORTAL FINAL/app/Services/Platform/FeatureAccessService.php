<?php

declare(strict_types=1);

namespace App\Services\Platform;

use Core\Database;
use Core\TenantContext;

final class FeatureAccessService
{
    /** @var array<int, array<string>> */
    private static array $cache = [];

    public static function featuresForSchool(?int $schoolId = null): array
    {
        $schoolId = $schoolId ?? TenantContext::schoolId();
        if (!$schoolId) {
            return [];
        }
        if (isset(self::$cache[$schoolId])) {
            return self::$cache[$schoolId];
        }

        $school = Database::fetch('SELECT plan_id FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
        if (!$school || empty($school['plan_id'])) {
            // Legacy / unbound tenants: do not block modules until a plan is assigned
            return self::$cache[$schoolId] = ['*'];
        }

        $rows = Database::fetchAll(
            'SELECT f.slug FROM features f
             INNER JOIN plan_features pf ON pf.feature_id = f.id
             WHERE pf.plan_id = ?',
            [(int) $school['plan_id']]
        );
        return self::$cache[$schoolId] = array_column($rows, 'slug');
    }

    public static function tenantHasFeature(string $featureSlug, ?int $schoolId = null): bool
    {
        $features = self::featuresForSchool($schoolId);
        if (in_array('*', $features, true)) {
            return true;
        }
        return in_array($featureSlug, $features, true);
    }

    public static function requireFeature(string $featureSlug): void
    {
        if (!self::tenantHasFeature($featureSlug)) {
            http_response_code(403);
            view('errors/403', [
                'title' => 'Feature Unavailable',
                'message' => 'This module is not included in your current subscription plan. Please upgrade.',
            ]);
            exit;
        }
    }

    public static function clearCache(): void
    {
        self::$cache = [];
    }
}
