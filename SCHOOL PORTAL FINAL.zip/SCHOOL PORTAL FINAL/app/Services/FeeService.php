<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\FeeInvoice;
use Core\Auth;
use Core\Database;
use Core\TenantGuard;

final class FeeService
{
    private FeeInvoice $invoiceModel;

    public function __construct()
    {
        $this->invoiceModel = new FeeInvoice();
        $this->ensureAdvancedFinanceSchema();
    }

    /**
     * Create a new student fee invoice with line items inside an atomic transaction.
     *
     * @param array<string, mixed> $data
     * @param array<int, array<string, mixed>> $items
     * @return int Created invoice ID
     */
    public function createInvoice(array $data, array $items): int
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for fee invoice creation.');
        }

        $studentId = (int) ($data['student_id'] ?? 0);
        if ($studentId <= 0) {
            throw new \InvalidArgumentException('Valid student ID is required.');
        }

        if (empty($items)) {
            throw new \InvalidArgumentException('At least one fee line item is required.');
        }

        $invoiceDate = (string) ($data['invoice_date'] ?? date('Y-m-d'));
        $dueDate = (string) ($data['due_date'] ?? date('Y-m-d', strtotime('+15 days')));
        if ($dueDate < $invoiceDate) {
            throw new \InvalidArgumentException('Invoice due date cannot be earlier than invoice date.');
        }

        // Verify student belongs to this tenant
        TenantGuard::enforce('students', $studentId, $schoolId);

        return Database::transaction(function () use ($schoolId, $studentId, $data, $items, $invoiceDate, $dueDate): int {
            $subtotal = 0.0;
            foreach ($items as $item) {
                $subtotal += max(0.0, (float) ($item['amount'] ?? 0));
            }

            if (isset($data['discount']) && (float)$data['discount'] < 0.0) {
                throw new \InvalidArgumentException('Discount cannot be negative.');
            }
            if (isset($data['late_fee']) && (float)$data['late_fee'] < 0.0) {
                throw new \InvalidArgumentException('Late fee cannot be negative.');
            }

            $discount = max(0.0, (float) ($data['discount'] ?? 0));
            if ($discount > $subtotal && $subtotal > 0) {
                throw new \InvalidArgumentException('Discount amount cannot exceed invoice subtotal.');
            }

            $lateFee = max(0.0, (float) ($data['late_fee'] ?? 0));
            $total = max(0.0, ($subtotal - $discount) + $lateFee);
            $title = trim((string) ($data['title'] ?? 'School Fee Invoice'));

            // Anti-duplicate submission guard (within last 5 seconds)
            $recent = Database::fetch(
                'SELECT id FROM student_fee_invoices 
                 WHERE school_id = ? AND student_id = ? AND title = ? AND total_amount = ? 
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND) LIMIT 1',
                [$schoolId, $studentId, $title, $total]
            );
            if ($recent) {
                throw new \RuntimeException('Duplicate invoice creation detected. Please wait a moment.');
            }

            $invoiceNo = $this->nextInvoiceNo($schoolId);
            $academicYearId = (int) ($data['academic_year_id'] ?? activeAcademicYearId());

            $id = Database::insert(
                'INSERT INTO student_fee_invoices
                (school_id, student_id, academic_year_id, invoice_no, title, invoice_date, due_date,
                 subtotal, discount, late_fee, total_amount, paid_amount, status, notes, created_by, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0.00, ?, ?, ?, NOW(), NOW())',
                [
                    $schoolId,
                    $studentId,
                    $academicYearId,
                    $invoiceNo,
                    $title,
                    $data['invoice_date'] ?? date('Y-m-d'),
                    $data['due_date'] ?? date('Y-m-d', strtotime('+15 days')),
                    $subtotal,
                    $discount,
                    $lateFee,
                    $total,
                    'unpaid',
                    $data['notes'] ?? null,
                    Auth::id(),
                ]
            );

            foreach ($items as $item) {
                $amount = max(0.0, (float) ($item['amount'] ?? 0));
                $catId = !empty($item['fee_category_id']) ? (int) $item['fee_category_id'] : null;

                if ($catId !== null) {
                    $cat = Database::fetch('SELECT id FROM fee_categories WHERE id = ? AND school_id = ?', [$catId, $schoolId]);
                    if (!$cat) {
                        $catId = null;
                    }
                }

                Database::insert(
                    'INSERT INTO student_fee_invoice_items 
                     (school_id, invoice_id, fee_category_id, description, amount, created_at)
                     VALUES (?, ?, ?, ?, ?, NOW())',
                    [
                        $schoolId,
                        $id,
                        $catId,
                        trim((string) ($item['description'] ?? 'Fee Item')),
                        $amount
                    ]
                );
            }

            auditLog('fee.invoice_create', 'finance', 'student_fee_invoices', $id, null, [
                'invoice_no' => $invoiceNo,
                'total' => $total,
                'student_id' => $studentId,
            ]);

            try {
                (new AccountingService())->postInvoiceJournalEntry($schoolId, $id);
            } catch (\Throwable $e) {
                // Accounting sync is non-blocking
            }

            return $id;
        });
    }

    /**
     * Update an unpaid invoice without payments.
     *
     * @param int $id
     * @param array<string, mixed> $data
     * @return bool
     */
    public function updateInvoice(int $id, array $data): bool
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('student_fee_invoices', $id, $schoolId);

        if ($this->invoiceModel->hasPayments($id)) {
            throw new \RuntimeException('Cannot modify an invoice that already has recorded payments.');
        }

        $existing = Database::fetch('SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ?', [$id, $schoolId]);
        if (!$existing) {
            throw new \RuntimeException('Invoice not found.');
        }

        $title = trim((string) ($data['title'] ?? $existing['title']));
        $dueDate = (string) ($data['due_date'] ?? $existing['due_date']);
        $notes = array_key_exists('notes', $data) ? $data['notes'] : $existing['notes'];

        Database::execute(
            'UPDATE student_fee_invoices 
             SET title = ?, due_date = ?, notes = ?, updated_at = NOW() 
             WHERE id = ? AND school_id = ?',
            [$title, $dueDate, $notes, $id, $schoolId]
        );

        auditLog('fee.invoice_update', 'finance', 'student_fee_invoices', $id, $existing, $data);
        return true;
    }

    /**
     * Delete an invoice and its items (only if no payments have been made).
     */
    public function deleteInvoice(int $id): bool
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('student_fee_invoices', $id, $schoolId);

        if ($this->invoiceModel->hasPayments($id)) {
            throw new \RuntimeException('Cannot delete an invoice with recorded payments. Please cancel the invoice instead.');
        }

        return Database::transaction(function () use ($id, $schoolId): bool {
            $existing = Database::fetch('SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ?', [$id, $schoolId]);
            if (!$existing) {
                return false;
            }

            Database::execute('DELETE FROM student_fee_invoice_items WHERE invoice_id = ? AND school_id = ?', [$id, $schoolId]);
            Database::execute('DELETE FROM student_fee_invoices WHERE id = ? AND school_id = ?', [$id, $schoolId]);

            auditLog('fee.invoice_delete', 'finance', 'student_fee_invoices', $id, $existing, null);
            return true;
        });
    }

    /**
     * Cancel an invoice safely.
     */
    public function cancelInvoice(int $id, ?string $reason = null): bool
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('student_fee_invoices', $id, $schoolId);

        $invoice = Database::fetch('SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ?', [$id, $schoolId]);
        if (!$invoice) {
            throw new \RuntimeException('Invoice not found.');
        }

        if ($invoice['status'] === 'cancelled') {
            return true;
        }

        $notes = $invoice['notes'] ?? '';
        if ($reason) {
            $notes = trim($notes . "\n[Cancelled: " . $reason . ' on ' . date('Y-m-d H:i') . ']');
        }

        Database::execute(
            'UPDATE student_fee_invoices SET status = "cancelled", notes = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$notes, $id, $schoolId]
        );

        auditLog('fee.invoice_cancel', 'finance', 'student_fee_invoices', $id, ['old_status' => $invoice['status']], ['status' => 'cancelled']);
        return true;
    }

    /**
     * Record a payment against an invoice with row-locking and idempotency guard.
     */
    public function recordPayment(
        int $invoiceId,
        float $amount,
        string $method,
        string $date,
        ?string $reference = null,
        ?string $notes = null
    ): int {
        if ($amount <= 0.0) {
            throw new \InvalidArgumentException('Payment amount must be greater than zero.');
        }

        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('student_fee_invoices', $invoiceId, $schoolId);

        return Database::transaction(function () use ($schoolId, $invoiceId, $amount, $method, $date, $reference, $notes): int {
            // Lock row FOR UPDATE to prevent race conditions
            $invoice = Database::fetch(
                'SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ? FOR UPDATE',
                [$invoiceId, $schoolId]
            );

            if (!$invoice) {
                throw new \RuntimeException('Invoice not found.');
            }

            if ($invoice['status'] === 'cancelled') {
                throw new \RuntimeException('Cannot record payment for a cancelled invoice.');
            }

            // Anti-duplicate submission check (within last 10 seconds)
            $recent = Database::fetch(
                'SELECT id FROM payments 
                 WHERE invoice_id = ? AND amount = ? AND school_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 SECOND)',
                [$invoiceId, $amount, $schoolId]
            );

            if ($recent) {
                throw new \RuntimeException('Duplicate payment submission detected. Please wait a moment.');
            }

            $currentPaid = (float) $invoice['paid_amount'];
            $totalAmount = (float) $invoice['total_amount'];
            $newPaid = $currentPaid + $amount;

            if ($newPaid > ($totalAmount + 0.01)) {
                $balance = max(0.0, $totalAmount - $currentPaid);
                throw new \RuntimeException("Payment amount exceeds outstanding balance of " . formatMoney($balance));
            }

            $newStatus = ($newPaid + 0.01 >= $totalAmount) ? 'paid' : 'partial';

            $receiptNo = $this->nextReceiptNo($schoolId);

            $paymentId = Database::insert(
                'INSERT INTO payments
                (school_id, invoice_id, student_id, receipt_no, amount, payment_method, status, payment_date, reference_no, notes, received_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, "completed", ?, ?, ?, ?, NOW())',
                [
                    $schoolId,
                    $invoiceId,
                    (int) $invoice['student_id'],
                    $receiptNo,
                    $amount,
                    $method,
                    $date,
                    $reference,
                    $notes,
                    Auth::id(),
                ]
            );

            Database::execute(
                'UPDATE student_fee_invoices 
                 SET paid_amount = ?, status = ?, updated_at = NOW() 
                 WHERE id = ? AND school_id = ?',
                [$newPaid, $newStatus, $invoiceId, $schoolId]
            );

            // Notify parent users associated with student
            $parents = Database::fetchAll(
                'SELECT u.id FROM users u
                 INNER JOIN student_parents sp ON sp.parent_id = u.parent_id AND sp.school_id = u.school_id
                 WHERE u.school_id = ? AND sp.student_id = ? AND u.status = 1',
                [$schoolId, (int) $invoice['student_id']]
            );

            foreach ($parents as $p) {
                notify_user(
                    $schoolId,
                    (int) $p['id'],
                    'finance',
                    'Fee payment received',
                    'Payment of ' . formatMoney($amount) . ' recorded. Receipt: ' . $receiptNo,
                    'payment',
                    $paymentId,
                    'parent/fees'
                );
            }

            auditLog('fee.payment', 'finance', 'payments', $paymentId, null, [
                'amount' => $amount,
                'invoice_id' => $invoiceId,
                'receipt_no' => $receiptNo,
            ]);

            try {
                (new AccountingService())->postPaymentJournalEntry($schoolId, $paymentId);
            } catch (\Throwable $e) {
                // Accounting sync is non-blocking
            }

            return $paymentId;
        });
    }

    /**
     * Reverses a fee payment and restores the invoice balance.
     *
     * @param int $paymentId
     * @param string|null $reason
     * @return bool
     */
    public function reversePayment(int $paymentId, ?string $reason = null): bool
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context.');
        }

        return Database::transaction(function () use ($schoolId, $paymentId, $reason): bool {
            $payment = Database::fetch('SELECT * FROM payments WHERE id = ? AND school_id = ?', [$paymentId, $schoolId]);
            if (!$payment) {
                throw new \RuntimeException('Payment record not found.');
            }

            $invoice = Database::fetch('SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ?', [(int) $payment['invoice_id'], $schoolId]);
            if (!$invoice) {
                throw new \RuntimeException('Associated fee invoice not found.');
            }

            $amount = (float) $payment['amount'];
            $newPaid = max(0.0, (float) $invoice['paid_amount'] - $amount);
            $totalAmount = (float) $invoice['total_amount'];

            $newStatus = 'unpaid';
            if ($newPaid >= $totalAmount && $totalAmount > 0) {
                $newStatus = 'paid';
            } elseif ($newPaid > 0) {
                $newStatus = 'partial';
            }

            Database::execute(
                'UPDATE student_fee_invoices SET paid_amount = ?, status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                [$newPaid, $newStatus, (int) $invoice['id'], $schoolId]
            );

            Database::execute('DELETE FROM payments WHERE id = ? AND school_id = ?', [$paymentId, $schoolId]);

            auditLog('fee.payment_reversed', 'finance', 'payments', $paymentId, [
                'amount' => $amount,
                'invoice_id' => $invoice['id'],
                'receipt_no' => $payment['receipt_no'] ?? null,
                'reason' => $reason,
            ]);

            return true;
        });
    }

    /**
     * Mass generate invoices for a list of students or an entire class.
     *
     * @param int $schoolId
     * @param array<int> $studentIds
     * @param string $title
     * @param string $dueDate
     * @param array<int, array<string, mixed>> $baseItems
     * @return int Number of invoices created
     */
    public function generateBatchInvoices(
        int $schoolId,
        array $studentIds,
        string $title,
        string $dueDate,
        array $baseItems
    ): int {
        return Database::transaction(function () use ($schoolId, $studentIds, $title, $dueDate, $baseItems): int {
            $count = 0;
            $routesMap = [];
            $routes = Database::fetchAll(
                "SELECT id, title, fare FROM transport_routes WHERE school_id = ? AND status = 'active'",
                [$schoolId]
            );
            foreach ($routes as $r) {
                $routesMap[(int) $r['id']] = $r;
            }

            $academicYearId = activeAcademicYearId();

            foreach ($studentIds as $studentId) {
                $studentId = (int) $studentId;
                $student = Database::fetch(
                    "SELECT id, transport_route_id FROM students WHERE id = ? AND school_id = ? AND status = 'active'",
                    [$studentId, $schoolId]
                );

                if (!$student) {
                    continue;
                }

                // Check for duplicate invoice title in the same academic year
                $exists = Database::fetch(
                    "SELECT id FROM student_fee_invoices WHERE student_id = ? AND school_id = ? AND academic_year_id = ? AND title = ? LIMIT 1",
                    [$studentId, $schoolId, $academicYearId, $title]
                );

                if ($exists) {
                    continue;
                }

                $items = $baseItems;

                if (!empty($student['transport_route_id']) && isset($routesMap[(int) $student['transport_route_id']])) {
                    $route = $routesMap[(int) $student['transport_route_id']];
                    if ((float) $route['fare'] > 0) {
                        $items[] = [
                            'description' => "Transport Fare - " . $route['title'],
                            'amount' => (float) $route['fare'],
                            'fee_category_id' => null,
                        ];
                    }
                }

                $this->createInvoice([
                    'student_id' => $studentId,
                    'academic_year_id' => $academicYearId,
                    'title' => $title,
                    'invoice_date' => date('Y-m-d'),
                    'due_date' => $dueDate,
                    'discount' => 0.00,
                    'notes' => 'Mass Generated Invoice',
                ], $items);

                $count++;
            }

            return $count;
        });
    }

    /**
     * Get running ledger balance for a student.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getStudentLedgerWithBalances(int $studentId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('students', $studentId, $schoolId);

        $entries = $this->invoiceModel->getStudentLedger($studentId);
        $runningBalance = 0.0;

        foreach ($entries as &$entry) {
            $debit = (float) $entry['debit'];
            $credit = (float) $entry['credit'];
            $runningBalance += ($debit - $credit);
            $entry['running_balance'] = $runningBalance;
        }
        unset($entry);

        return $entries;
    }

    /**
     * Date range collection analytics.
     *
     * @return array{collected: float, payments: int, outstanding: float}
     */
    public function collectionSummary(string $from, string $to): array
    {
        $schoolId = (int) Auth::schoolId();
        $row = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS collected, COUNT(*) AS payments
             FROM payments WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
            [$schoolId, $from, $to]
        );

        $outstanding = Database::fetch(
            'SELECT COALESCE(SUM(total_amount - paid_amount), 0) AS outstanding
             FROM student_fee_invoices WHERE school_id = ? AND status IN ("unpaid", "partial")',
            [$schoolId]
        );

        return [
            'collected' => (float) ($row['collected'] ?? 0),
            'payments' => (int) ($row['payments'] ?? 0),
            'outstanding' => (float) ($outstanding['outstanding'] ?? 0),
        ];
    }

    /**
     * Generate sequential invoice number under tenant isolation.
     */
    public function nextInvoiceNo(int $schoolId): string
    {
        $year = date('Y');
        $row = Database::fetch(
            'SELECT invoice_no FROM student_fee_invoices 
             WHERE school_id = ? AND invoice_no LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$schoolId, "INV-{$year}-%"]
        );

        $seq = 1;
        if ($row && preg_match('/(\d+)$/', (string) $row['invoice_no'], $m)) {
            $seq = ((int) $m[1]) + 1;
        }

        return sprintf('INV-%s-%04d', $year, $seq);
    }

    /**
     * Generate sequential receipt number under tenant isolation.
     */
    public function nextReceiptNo(int $schoolId): string
    {
        $year = date('Y');
        $row = Database::fetch(
            'SELECT receipt_no FROM payments 
             WHERE school_id = ? AND receipt_no LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$schoolId, "RCP-{$year}-%"]
        );

        $seq = 1;
        if ($row && preg_match('/(\d+)$/', (string) $row['receipt_no'], $m)) {
            $seq = ((int) $m[1]) + 1;
        }

        return sprintf('RCP-%s-%04d', $year, $seq);
    }

    /**
     * Ensure advanced finance schema tables exist.
     */
    public function ensureAdvancedFinanceSchema(): void
    {
        Database::execute('CREATE TABLE IF NOT EXISTS refund_transactions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            payment_id BIGINT UNSIGNED NOT NULL,
            invoice_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            refund_no VARCHAR(50) NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            reason VARCHAR(255) NOT NULL,
            refund_method ENUM("cash","bank","online","cheque","original_method") NOT NULL DEFAULT "original_method",
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_payment (school_id, payment_id),
            INDEX idx_school_invoice (school_id, invoice_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        Database::execute('CREATE TABLE IF NOT EXISTS fee_discounts (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(150) NOT NULL,
            code VARCHAR(50) NOT NULL,
            type ENUM("fixed", "percentage") NOT NULL DEFAULT "fixed",
            amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            description VARCHAR(255) NULL,
            status TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_status (school_id, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        Database::execute('CREATE TABLE IF NOT EXISTS student_scholarships (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            discount_id BIGINT UNSIGNED NOT NULL,
            academic_year_id BIGINT UNSIGNED NULL,
            remarks VARCHAR(255) NULL,
            status ENUM("active", "revoked") NOT NULL DEFAULT "active",
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_student (school_id, student_id),
            INDEX idx_school_discount (school_id, discount_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    /**
     * Generate sequential refund number.
     */
    public function nextRefundNo(int $schoolId): string
    {
        $year = date('Y');
        $row = Database::fetch(
            'SELECT refund_no FROM refund_transactions 
             WHERE school_id = ? AND refund_no LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$schoolId, "RFD-{$year}-%"]
        );

        $seq = 1;
        if ($row && preg_match('/(\d+)$/', (string) $row['refund_no'], $m)) {
            $seq = ((int) $m[1]) + 1;
        }

        return sprintf('RFD-%s-%04d', $year, $seq);
    }

    /**
     * Process an audited fee payment refund inside an atomic transaction.
     */
    public function refundPayment(int $paymentId, float $amount, string $reason, string $method = 'cash'): int
    {
        if ($amount <= 0.0) {
            throw new \InvalidArgumentException('Refund amount must be greater than zero.');
        }

        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for fee refund.');
        }

        return Database::transaction(function () use ($schoolId, $paymentId, $amount, $reason, $method): int {
            // Lock payment row
            $payment = Database::fetch(
                'SELECT * FROM payments WHERE id = ? AND school_id = ? FOR UPDATE',
                [$paymentId, $schoolId]
            );
            if (!$payment) {
                throw new \RuntimeException('Payment record not found.');
            }

            // Check previous refunds on this payment
            $priorRefundRow = Database::fetch(
                'SELECT COALESCE(SUM(amount), 0) AS total_refunded FROM refund_transactions WHERE payment_id = ? AND school_id = ?',
                [$paymentId, $schoolId]
            );
            $priorRefunded = (float) ($priorRefundRow['total_refunded'] ?? 0);
            $maxRefundable = (float) $payment['amount'] - $priorRefunded;

            if ($amount > ($maxRefundable + 0.01)) {
                throw new \RuntimeException("Refund amount of " . number_format($amount, 2) . " exceeds maximum refundable amount of " . number_format($maxRefundable, 2));
            }

            // Lock associated invoice
            $invoiceId = (int) $payment['invoice_id'];
            $invoice = Database::fetch(
                'SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ? FOR UPDATE',
                [$invoiceId, $schoolId]
            );
            if (!$invoice) {
                throw new \RuntimeException('Associated fee invoice not found.');
            }

            $refundNo = $this->nextRefundNo($schoolId);

            $refundId = (int) Database::insert(
                'INSERT INTO refund_transactions
                 (school_id, payment_id, invoice_id, student_id, refund_no, amount, reason, refund_method, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                [
                    $schoolId,
                    $paymentId,
                    $invoiceId,
                    (int) $payment['student_id'],
                    $refundNo,
                    $amount,
                    $reason,
                    $method,
                    Auth::id(),
                ]
            );

            // Update invoice paid_amount and status
            $newPaid = max(0.0, (float) $invoice['paid_amount'] - $amount);
            $newStatus = ($newPaid <= 0.01) ? 'unpaid' : 'partial';

            Database::execute(
                'UPDATE student_fee_invoices SET paid_amount = ?, status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                [$newPaid, $newStatus, $invoiceId, $schoolId]
            );

            // If fully refunded, mark payment as refunded
            if (($priorRefunded + $amount) >= ((float) $payment['amount'] - 0.01)) {
                Database::execute(
                    'UPDATE payments SET status = "refunded" WHERE id = ? AND school_id = ?',
                    [$paymentId, $schoolId]
                );
            }

            auditLog('fee.refund', 'finance', 'refund_transactions', $refundId, null, [
                'refund_no' => $refundNo,
                'payment_id' => $paymentId,
                'invoice_id' => $invoiceId,
                'amount' => $amount,
                'reason' => $reason,
            ]);

            try {
                (new AccountingService())->postRefundJournalEntry($schoolId, $refundId);
            } catch (\Throwable $e) {
                // Accounting sync is non-blocking
            }

            return $refundId;
        });
    }

    /**
     * Lists refund transactions.
     */
    public function getRefunds(int $schoolId, int $limit = 50): array
    {
        $this->ensureAdvancedFinanceSchema();
        return Database::fetchAll(
            'SELECT r.*, p.receipt_no, p.payment_method AS original_payment_method,
                    i.invoice_no, s.first_name, s.last_name, s.admission_no,
                    u.name AS processed_by_name
             FROM refund_transactions r
             JOIN payments p ON p.id = r.payment_id
             JOIN student_fee_invoices i ON i.id = r.invoice_id
             JOIN students s ON s.id = r.student_id
             LEFT JOIN users u ON u.id = r.created_by
             WHERE r.school_id = ?
             ORDER BY r.created_at DESC LIMIT ?',
            [$schoolId, $limit]
        );
    }

    /**
     * Payment reconciliation summary and ledger integrity check.
     */
    public function reconcilePayments(int $schoolId, string $from, string $to): array
    {
        $this->ensureAdvancedFinanceSchema();

        // 1. Collections by payment method
        $methods = Database::fetchAll(
            'SELECT payment_method, COUNT(id) AS transaction_count, COALESCE(SUM(amount), 0) AS total_amount
             FROM payments
             WHERE school_id = ? AND payment_date BETWEEN ? AND ? AND status != "failed"
             GROUP BY payment_method',
            [$schoolId, $from, $to]
        );

        $grossCollection = 0.0;
        $totalTransactions = 0;
        foreach ($methods as $m) {
            $grossCollection += (float) $m['total_amount'];
            $totalTransactions += (int) $m['transaction_count'];
        }

        // 2. Refunds in period
        $refundRow = Database::fetch(
            'SELECT COUNT(id) AS refund_count, COALESCE(SUM(amount), 0) AS total_refunds
             FROM refund_transactions
             WHERE school_id = ? AND DATE(created_at) BETWEEN ? AND ?',
            [$schoolId, $from, $to]
        );
        $totalRefunds = (float) ($refundRow['total_refunds'] ?? 0);
        $refundCount = (int) ($refundRow['refund_count'] ?? 0);

        $netCollection = round($grossCollection - $totalRefunds, 2);

        // 3. Ledger integrity scanner: detects discrepancy between invoice paid_amount and sum of actual payments
        $discrepancies = Database::fetchAll(
            'SELECT i.id, i.invoice_no, i.total_amount, i.paid_amount,
                    COALESCE(SUM(p.amount), 0) AS sum_payments,
                    COALESCE(r.sum_refunds, 0) AS sum_refunds,
                    (COALESCE(SUM(p.amount), 0) - COALESCE(r.sum_refunds, 0)) AS expected_paid
             FROM student_fee_invoices i
             LEFT JOIN payments p ON p.invoice_id = i.id AND p.status != "failed"
             LEFT JOIN (
                 SELECT invoice_id, SUM(amount) AS sum_refunds FROM refund_transactions WHERE school_id = ? GROUP BY invoice_id
             ) r ON r.invoice_id = i.id
             WHERE i.school_id = ?
             GROUP BY i.id
             HAVING ABS(i.paid_amount - expected_paid) > 0.05
             LIMIT 10',
            [$schoolId, $schoolId]
        );

        return [
            'from' => $from,
            'to' => $to,
            'methods' => $methods,
            'gross_collection' => $grossCollection,
            'total_transactions' => $totalTransactions,
            'total_refunds' => $totalRefunds,
            'refund_count' => $refundCount,
            'net_collection' => $netCollection,
            'discrepancies' => $discrepancies,
            'discrepancy_count' => count($discrepancies),
        ];
    }

    /**
     * Lists active fee discounts.
     */
    public function getDiscounts(int $schoolId): array
    {
        $this->ensureAdvancedFinanceSchema();
        return Database::fetchAll(
            'SELECT * FROM fee_discounts WHERE school_id = ? ORDER BY name ASC',
            [$schoolId]
        );
    }

    /**
     * Create a fee discount or scholarship policy.
     */
    public function createDiscount(int $schoolId, array $data): int
    {
        $this->ensureAdvancedFinanceSchema();
        $name = trim((string) ($data['name'] ?? ''));
        $code = strtoupper(trim((string) ($data['code'] ?? '')));
        $type = in_array($data['type'] ?? '', ['fixed', 'percentage'], true) ? $data['type'] : 'fixed';
        $amount = max(0.0, (float) ($data['amount'] ?? 0));
        $desc = trim((string) ($data['description'] ?? ''));

        if (empty($name) || empty($code)) {
            throw new \InvalidArgumentException('Discount name and code are required.');
        }

        return (int) Database::insert(
            'INSERT INTO fee_discounts (school_id, name, code, type, amount, description, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, 1, NOW())',
            [$schoolId, $name, $code, $type, $amount, $desc]
        );
    }

    /**
     * Award scholarship / fee concession to student.
     */
    public function awardScholarship(int $schoolId, int $studentId, int $discountId, ?string $remarks = null): int
    {
        $this->ensureAdvancedFinanceSchema();
        $ayId = activeAcademicYearId();

        return (int) Database::insert(
            'INSERT INTO student_scholarships (school_id, student_id, discount_id, academic_year_id, remarks, status, created_at)
             VALUES (?, ?, ?, ?, ?, "active", NOW())',
            [$schoolId, $studentId, $discountId, $ayId, $remarks]
        );
    }

    /**
     * Lists student scholarships.
     */
    public function getStudentScholarships(int $schoolId): array
    {
        $this->ensureAdvancedFinanceSchema();
        return Database::fetchAll(
            'SELECT sc.*, d.name AS discount_name, d.code AS discount_code, d.type AS discount_type, d.amount AS discount_amount,
                    s.first_name, s.last_name, s.admission_no, c.name AS class_name
             FROM student_scholarships sc
             JOIN fee_discounts d ON d.id = sc.discount_id
             JOIN students s ON s.id = sc.student_id
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE sc.school_id = ?
             ORDER BY sc.created_at DESC',
            [$schoolId]
        );
    }
}
