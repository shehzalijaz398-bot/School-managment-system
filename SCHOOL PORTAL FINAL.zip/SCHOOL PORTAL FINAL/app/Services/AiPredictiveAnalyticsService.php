<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * AiPredictiveAnalyticsService
 *
 * Computes institutional predictive estimates (Fee Collections, Attendance Risk, Academic Forecasting).
 * Strictly enforces data sufficiency checks and explicit uncertainty disclaimers.
 * Never presents statistical predictions as definitive facts.
 */
final class AiPredictiveAnalyticsService
{
    private const DISCLAIMER_BANNER = "⚠️ [PREDICTIVE_ESTIMATE]: This projection is a mathematical estimate derived from historical trend models. It is NOT a factual certainty and should be used strictly for institutional planning.";

    /**
     * Forecast fee collection velocity for the next 30 to 60 days.
     *
     * @param int $schoolId
     * @param int $forecastDays
     * @return array
     */
    public function predictFeeCollections(int $schoolId, int $forecastDays = 30): array
    {
        // 1. Fetch historical payment transactions in the last 90 days
        $ninetyDaysAgo = date('Y-m-d H:i:s', strtotime('-90 days'));
        $payments = Database::fetchAll("
            SELECT payment_date, amount
            FROM payments
            WHERE school_id = ? AND payment_date >= ? AND status = 'completed'
            ORDER BY payment_date ASC
        ", [$schoolId, $ninetyDaysAgo]);

        $sampleSize = count($payments);

        // 2. Data Sufficiency Check: Minimum 3 transactions required
        if ($sampleSize < 3) {
            return [
                'status' => 'insufficient_data',
                'sufficient_data' => false,
                'badge' => '[DATA_SPARSE_WARNING]',
                'title' => 'Fee Collection Forecast (Insufficient Data)',
                'message' => 'Insufficient historical fee collection transactions to formulate a statistically reliable revenue forecast. At least 3 recorded payments across 7+ days are required.',
                'projected_amount' => 0.00,
                'confidence_pct' => 0.0,
                'limitations' => [
                    'Historical transaction count is below minimum threshold (' . $sampleSize . ' < 3).',
                    'Projections without adequate payment histories produce unreliable variance.',
                ],
                'disclaimer' => self::DISCLAIMER_BANNER,
            ];
        }

        // 3. Compute daily velocity
        $totalCollected = 0.0;
        $dates = [];
        foreach ($payments as $p) {
            $amt = (float) ($p['amount'] ?? 0.0);
            $totalCollected += $amt;
            $d = substr((string) $p['payment_date'], 0, 10);
            $dates[$d] = true;
        }

        $activeDays = max(1, count($dates));
        $avgDailyCollection = $totalCollected / $activeDays;

        // Current outstanding overdue total to cap projection
        $outstanding = (float) Database::fetchValue("
            SELECT COALESCE(SUM(total_amount - paid_amount), 0.00)
            FROM student_fee_invoices
            WHERE school_id = ? AND status IN ('unpaid', 'partially_paid', 'partial')
        ", [$schoolId]);

        // Projected collections over forecastDays
        $rawProjection = $avgDailyCollection * ($forecastDays * (5 / 7)); // adjust for banking days
        $projectedAmount = round(min($outstanding, max(0.0, $rawProjection)), 2);

        // Confidence calculation: based on sample size and active days
        $confidence = min(88.0, 50.0 + ($sampleSize * 1.5) + ($activeDays * 0.8));

        return [
            'status' => 'success',
            'sufficient_data' => true,
            'badge' => '[PREDICTIVE_ESTIMATE]',
            'title' => "Fee Collection Projection ({$forecastDays}-Day Horizon)",
            'projected_amount' => $projectedAmount,
            'confidence_pct' => round($confidence, 1),
            'historical_sample_size' => $sampleSize,
            'active_collection_days' => $activeDays,
            'average_daily_velocity' => round($avgDailyCollection, 2),
            'outstanding_arrears_cap' => $outstanding,
            'explanation' => "Based on {$sampleSize} payment transactions across {$activeDays} active banking days in the last 90 days, historical collection velocity averages $" . number_format($avgDailyCollection, 2) . "/day. Assuming continuous velocity and existing overdue arrears, projected receipts over the next {$forecastDays} days are estimated at $" . number_format($projectedAmount, 2) . ".",
            'limitations' => [
                'Assumes fee collection policies and student enrollment remain static.',
                'Does not account for upcoming holiday closures, term breaks, or macroeconomic shifts.',
                'Subject to parent payment responsiveness to fee reminders.',
            ],
            'disclaimer' => self::DISCLAIMER_BANNER,
        ];
    }

    /**
     * Predict student attendance risk and identify cohorts likely to drop below 75%.
     *
     * @param int $schoolId
     * @return array
     */
    public function predictAttendanceRisk(int $schoolId): array
    {
        $sixtyDaysAgo = date('Y-m-d', strtotime('-60 days'));
        $students = Database::fetchAll("
            SELECT s.id, s.admission_no, s.first_name, s.last_name, c.name AS class_name,
                   COUNT(sa.id) AS total_recorded_days,
                   SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) AS present_count,
                   SUM(CASE WHEN sa.status = 'absent' THEN 1 ELSE 0 END) AS absent_count
            FROM students s
            JOIN student_attendance sa ON sa.student_id = s.id
            LEFT JOIN classes c ON c.id = s.class_id
            WHERE s.school_id = ? AND sa.attendance_date >= ?
            GROUP BY s.id, s.admission_no, s.first_name, s.last_name, c.name
            HAVING total_recorded_days >= 10
        ", [$schoolId, $sixtyDaysAgo]);

        if (empty($students)) {
            return [
                'status' => 'insufficient_data',
                'sufficient_data' => false,
                'badge' => '[DATA_SPARSE_WARNING]',
                'title' => 'Student Attendance Risk Forecast (Insufficient Data)',
                'message' => 'Insufficient longitudinal attendance logs (minimum 10 recorded school sessions per student required).',
                'at_risk_students' => [],
                'disclaimer' => self::DISCLAIMER_BANNER,
            ];
        }

        $atRisk = [];
        foreach ($students as $st) {
            $total = (int) $st['total_recorded_days'];
            $pres = (int) $st['present_count'];
            $rate = ($pres / $total) * 100;

            // If current attendance is between 65% and 80%, flag as at-risk of slipping below 75%
            if ($rate < 80.0) {
                $prob = round(100 - $rate + 10, 1);
                $atRisk[] = [
                    'student_id' => (int) $st['id'],
                    'admission_no' => $st['admission_no'],
                    'name' => "{$st['first_name']} {$st['last_name']}",
                    'class' => $st['class_name'] ?? 'General',
                    'current_rate' => round($rate, 1),
                    'projected_risk_score' => min(95.0, max(50.0, $prob)),
                    'severity' => $rate < 70 ? 'critical' : 'warning',
                ];
            }
        }

        return [
            'status' => 'success',
            'sufficient_data' => true,
            'badge' => '[PREDICTIVE_ESTIMATE]',
            'title' => 'Cohort Attendance Retention Risk Radar',
            'at_risk_count' => count($atRisk),
            'at_risk_students' => array_slice($atRisk, 0, 10),
            'confidence_pct' => 76.5,
            'limitations' => [
                'Medical leaves and approved excused absences are counted in statistical trends.',
                'Student personal circumstances may reverse absenteeism trajectory.',
            ],
            'disclaimer' => self::DISCLAIMER_BANNER,
        ];
    }

    /**
     * Predict academic remediation risk based on historical exam score distribution.
     *
     * @param int $schoolId
     * @return array
     */
    public function predictAcademicRisk(int $schoolId): array
    {
        $records = Database::fetchAll("
            SELECT em.student_id, s.first_name, s.last_name, c.name AS class_name,
                   COUNT(em.id) AS marks_count,
                   AVG(em.marks_obtained) AS avg_score
            FROM exam_marks em
            JOIN students s ON s.id = em.student_id
            LEFT JOIN classes c ON c.id = s.class_id
            WHERE em.school_id = ?
            GROUP BY em.student_id, s.first_name, s.last_name, c.name
            HAVING marks_count >= 2
        ", [$schoolId]);

        if (empty($records)) {
            return [
                'status' => 'insufficient_data',
                'sufficient_data' => false,
                'badge' => '[DATA_SPARSE_WARNING]',
                'title' => 'Academic Remedial Risk Radar (Insufficient Data)',
                'message' => 'Insufficient published examination grades to compute academic risk trajectories (minimum 2 graded assessments per student required).',
                'remedial_students' => [],
                'disclaimer' => self::DISCLAIMER_BANNER,
            ];
        }

        $remedial = [];
        foreach ($records as $r) {
            $avg = (float) $r['avg_score'];
            if ($avg < 50.0) {
                $remedial[] = [
                    'student_id' => (int) $r['student_id'],
                    'name' => "{$r['first_name']} {$r['last_name']}",
                    'class' => $r['class_name'] ?? 'Class',
                    'average_score' => round($avg, 1),
                    'remediation_priority' => $avg < 40.0 ? 'high' : 'medium',
                ];
            }
        }

        return [
            'status' => 'success',
            'sufficient_data' => true,
            'badge' => '[PREDICTIVE_ESTIMATE]',
            'title' => 'Academic Remedial Risk Radar',
            'remedial_count' => count($remedial),
            'remedial_students' => $remedial,
            'confidence_pct' => 82.0,
            'limitations' => [
                'Past scores do not factor in ongoing tutoring or subject difficulty variations.',
                'Predictions should only serve as an early alert for teacher intervention.',
            ],
            'disclaimer' => self::DISCLAIMER_BANNER,
        ];
    }
}
