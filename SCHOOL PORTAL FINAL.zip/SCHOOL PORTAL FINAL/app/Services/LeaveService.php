<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class LeaveService
{
    public function submit(int $employeeId, int $leaveTypeId, string $start, string $end, string $reason, ?string $attachment = null): int
    {
        return $this->submitStaff($employeeId, (int) Auth::id(), $leaveTypeId, $start, $end, $reason, $attachment);
    }

    public function submitStaff(
        int $employeeId,
        int $appliedByUserId,
        int $leaveTypeId,
        string $start,
        string $end,
        string $reason,
        ?string $attachment = null
    ): int {
        $startDt = new \DateTime($start);
        $endDt = new \DateTime($end);
        if ($endDt < $startDt) {
            throw new \RuntimeException('End date cannot be before start date.');
        }
        $days = (float) $startDt->diff($endDt)->days + 1;
        $schoolId = (int) Auth::schoolId();

        $id = Database::insert(
            'INSERT INTO leave_requests
            (school_id, applicant_type, employee_id, applied_by, leave_type_id, start_date, end_date, days, reason, attachment, status, created_at, updated_at)
             VALUES (?, "staff", ?, ?, ?, ?, ?, ?, ?, ?, "pending", NOW(), NOW())',
            [$schoolId, $employeeId, $appliedByUserId, $leaveTypeId, $start, $end, $days, $reason, $attachment]
        );

        // Notify Admins
        $admins = Database::fetchAll(
            'SELECT u.id FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.school_id = ? AND r.slug IN ("school_admin", "admin", "hr")',
            [$schoolId]
        );
        foreach ($admins as $adm) {
            notify_user(
                $schoolId,
                (int) $adm['id'],
                'leave_submitted',
                'Staff Leave Request',
                'A staff member submitted a leave request (' . $days . ' days).',
                'leave_requests',
                $id,
                'leave'
            );
        }

        auditLog('leave.submit_staff', 'leave', 'leave_requests', $id);
        return $id;
    }

    public function submitStudent(
        int $studentId,
        int $appliedByUserId,
        int $leaveTypeId,
        string $start,
        string $end,
        string $reason,
        ?string $attachment = null,
        ?int $academicYearId = null
    ): int {
        $startDt = new \DateTime($start);
        $endDt = new \DateTime($end);
        if ($endDt < $startDt) {
            throw new \RuntimeException('End date cannot be before start date.');
        }
        $days = (float) $startDt->diff($endDt)->days + 1;
        $schoolId = (int) Auth::schoolId();

        $student = Database::fetch(
            'SELECT s.*, c.name AS class_name, sec.name AS section_name 
             FROM students s 
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             WHERE s.id = ? AND s.school_id = ? LIMIT 1',
            [$studentId, $schoolId]
        );
        if (!$student) {
            throw new \RuntimeException('Student profile not found.');
        }

        $yearId = $academicYearId ?? $student['academic_year_id'] ?? activeAcademicYearId();

        $id = Database::insert(
            'INSERT INTO leave_requests
            (school_id, applicant_type, student_id, applied_by, academic_year_id, leave_type_id, start_date, end_date, days, reason, attachment, status, created_at, updated_at)
             VALUES (?, "student", ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending", NOW(), NOW())',
            [$schoolId, $studentId, $appliedByUserId, $yearId, $leaveTypeId, $start, $end, $days, $reason, $attachment]
        );

        $studentName = trim($student['first_name'] . ' ' . $student['last_name']);

        // Notify assigned teachers for this class/section
        if (!empty($student['class_id']) && !empty($student['section_id'])) {
            $teachers = Database::fetchAll(
                'SELECT DISTINCT u.id 
                 FROM teacher_assignments ta
                 INNER JOIN teachers t ON t.id = ta.teacher_id
                 INNER JOIN employees e ON e.id = t.employee_id
                 INNER JOIN users u ON u.employee_id = e.id
                 WHERE ta.school_id = ? AND ta.class_id = ? AND ta.section_id = ? AND ta.status = 1',
                [$schoolId, (int) $student['class_id'], (int) $student['section_id']]
            );
            foreach ($teachers as $t) {
                notify_user(
                    $schoolId,
                    (int) $t['id'],
                    'student_leave_request',
                    'Student Leave Request',
                    $studentName . ' (' . ($student['class_name'] ?? '') . ') requested leave for ' . $days . ' days.',
                    'leave_requests',
                    $id,
                    'leave'
                );
            }
        }

        // Also notify school admin
        $admins = Database::fetchAll(
            'SELECT u.id FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.school_id = ? AND r.slug IN ("school_admin", "admin")',
            [$schoolId]
        );
        foreach ($admins as $adm) {
            notify_user(
                $schoolId,
                (int) $adm['id'],
                'student_leave_request',
                'Student Leave Request',
                $studentName . ' submitted a leave request (' . $days . ' days).',
                'leave_requests',
                $id,
                'leave'
            );
        }

        auditLog('leave.submit_student', 'leave', 'leave_requests', $id);
        return $id;
    }

    public function review(int $id, string $status, ?string $notes = null, ?int $reviewerUserId = null): void
    {
        if (!in_array($status, ['approved', 'rejected'], true)) {
            throw new \InvalidArgumentException('Invalid leave status.');
        }

        $schoolId = (int) Auth::schoolId();
        $reviewerId = $reviewerUserId ?? (int) Auth::id();

        $leave = Database::fetch(
            'SELECT * FROM leave_requests WHERE id = ? AND school_id = ? LIMIT 1',
            [$id, $schoolId]
        );
        if (!$leave || $leave['status'] !== 'pending') {
            throw new \RuntimeException('Leave request not found or already processed.');
        }

        Database::beginTransaction();
        try {
            Database::execute(
                'UPDATE leave_requests SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_notes = ?, updated_at = NOW()
                 WHERE id = ? AND school_id = ?',
                [$status, $reviewerId, $notes, $id, $schoolId]
            );

            if ($status === 'approved') {
                $period = new \DatePeriod(
                    new \DateTime($leave['start_date']),
                    new \DateInterval('P1D'),
                    (new \DateTime($leave['end_date']))->modify('+1 day')
                );

                if ($leave['applicant_type'] === 'staff' && !empty($leave['employee_id'])) {
                    // Update/Insert staff_attendance
                    foreach ($period as $day) {
                        $date = $day->format('Y-m-d');
                        $exists = Database::fetch(
                            'SELECT id FROM staff_attendance WHERE school_id = ? AND employee_id = ? AND attendance_date = ? LIMIT 1',
                            [$schoolId, (int) $leave['employee_id'], $date]
                        );
                        if ($exists) {
                            Database::execute(
                                'UPDATE staff_attendance SET status = "leave", updated_by = ?, updated_at = NOW() WHERE id = ?',
                                [$reviewerId, (int) $exists['id']]
                            );
                        } else {
                            Database::insert(
                                'INSERT INTO staff_attendance (school_id, employee_id, attendance_date, status, marked_by, marked_at)
                                 VALUES (?, ?, ?, "leave", ?, NOW())',
                                [$schoolId, (int) $leave['employee_id'], $date, $reviewerId]
                            );
                        }
                    }
                } elseif ($leave['applicant_type'] === 'student' && !empty($leave['student_id'])) {
                    // Update/Insert student_attendance
                    $student = Database::fetch(
                        'SELECT * FROM students WHERE id = ? AND school_id = ? LIMIT 1',
                        [(int) $leave['student_id'], $schoolId]
                    );

                    if ($student) {
                        $yearId = $leave['academic_year_id'] ?? $student['academic_year_id'] ?? activeAcademicYearId();
                        $classId = (int) $student['class_id'];
                        $secId = (int) $student['section_id'];
                        $leaveReason = $leave['reason'] ? 'Leave: ' . mb_substr($leave['reason'], 0, 50) : 'Leave Approved';

                        foreach ($period as $day) {
                            $date = $day->format('Y-m-d');
                            $exists = Database::fetch(
                                'SELECT id FROM student_attendance WHERE school_id = ? AND student_id = ? AND attendance_date = ? LIMIT 1',
                                [$schoolId, (int) $student['id'], $date]
                            );
                            if ($exists) {
                                Database::execute(
                                    'UPDATE student_attendance SET status = "leave", remarks = ?, updated_by = ?, updated_at = NOW() WHERE id = ?',
                                    [$leaveReason, $reviewerId, (int) $exists['id']]
                                );
                            } else {
                                Database::insert(
                                    'INSERT INTO student_attendance (school_id, academic_year_id, student_id, class_id, section_id, attendance_date, status, remarks, marked_by, marked_at)
                                     VALUES (?, ?, ?, ?, ?, ?, "leave", ?, ?, NOW())',
                                    [$schoolId, $yearId, (int) $student['id'], $classId, $secId, $date, $leaveReason, $reviewerId]
                                );
                            }
                        }
                    }
                }
            }

            // Notify applicant
            if (!empty($leave['applied_by'])) {
                $statusUpper = ucfirst($status);
                $msg = "Your leave request for {$leave['start_date']} to {$leave['end_date']} has been {$status}.";
                if ($notes) {
                    $msg .= " Notes: {$notes}";
                }
                notify_user(
                    $schoolId,
                    (int) $leave['applied_by'],
                    'leave_reviewed',
                    "Leave Request {$statusUpper}",
                    $msg,
                    'leave_requests',
                    $id,
                    ($leave['applicant_type'] === 'student' ? 'portal/leaves' : 'leave')
                );
            }

            Database::commit();
            auditLog('leave.review', 'leave', 'leave_requests', $id, null, ['status' => $status, 'notes' => $notes]);
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function cancel(int $id, int $userId): void
    {
        $schoolId = (int) Auth::schoolId();
        $leave = Database::fetch(
            'SELECT * FROM leave_requests WHERE id = ? AND school_id = ? LIMIT 1',
            [$id, $schoolId]
        );

        if (!$leave) {
            throw new \RuntimeException('Leave request not found.');
        }
        if ($leave['status'] !== 'pending') {
            throw new \RuntimeException('Only pending leave requests can be cancelled.');
        }

        // Verify applicant or admin
        $isApplicant = ((int) $leave['applied_by'] === $userId);
        $isAdmin = hasPermission('leave.manage') || hasPermission('leave.approve');
        if (!$isApplicant && !$isAdmin) {
            throw new \RuntimeException('You are not authorized to cancel this request.');
        }

        Database::execute(
            'UPDATE leave_requests SET status = "cancelled", updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$id, $schoolId]
        );

        auditLog('leave.cancel', 'leave', 'leave_requests', $id);
    }
}
