<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class SystemHealthService
{
    /**
     * Compile comprehensive system diagnostics and operational telemetry.
     */
    public function getSystemHealthOverview(int $schoolId): array
    {
        $db = $this->checkDatabaseHealth();
        $storage = $this->checkStorageHealth();
        $php = $this->checkPhpRuntimeHealth();
        $automations = $this->checkAutomationQueueHealth($schoolId);
        $integrations = $this->checkIntegrationsHealth();
        $errors = $this->analyzeRecentErrorLogs();
        $slowQueries = $this->checkDatabaseIndexesAndSlowQueries();

        $activeAlerts = $this->getActiveAlerts($schoolId);
        if (($activeAlerts['critical_count'] ?? 0) > 0) $score -= 15;

        // Calculate overall system health index (0 - 100)
        $score = 100;
        if ($db['status'] !== 'operational') $score -= 30;
        if ($storage['writable_failures'] > 0) $score -= 20;
        if ($storage['disk_percent_used'] > 90) $score -= 15;
        if ($automations['failed_automations_24h'] > 0) $score -= 10;
        if ($errors['critical_count'] > 0) $score -= 15;
        if (($activeAlerts['critical_count'] ?? 0) > 0) $score -= 10;
        $overallStatus = ($score >= 85) ? 'healthy' : (($score >= 60) ? 'degraded' : 'critical');
        $cache = class_exists(\Core\Cache\CacheManager::class) ? \Core\Cache\CacheManager::stats() : ['status' => 'standby'];
        $queueWorker = $this->checkQueueWorkerHealth();

        return [
            'overall_status' => $overallStatus,
            'health_score' => max(0, $score),
            'database' => $db,
            'cache' => $cache,
            'queue_worker' => $queueWorker,
            'storage' => $storage,
            'php_runtime' => $php,
            'automations' => $automations,
            'integrations' => $integrations,
            'error_diagnostics' => $errors,
            'slow_queries' => $slowQueries,
            'alerts' => $activeAlerts,
            'checked_at' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * 1. Check Database Health & Connectivity
     */
    public function checkDatabaseHealth(): array
    {
        $start = microtime(true);
        try {
            $row = Database::fetch("SELECT 1 AS ping, VERSION() AS version, DATABASE() AS db_name");
            $latencyMs = round((microtime(true) - $start) * 1000, 2);

            // Fetch table count & database size
            $sizeRow = Database::fetch("
                SELECT 
                    COUNT(*) AS total_tables,
                    ROUND(SUM(data_length + index_length) / (1024 * 1024), 2) AS db_size_mb
                FROM information_schema.tables 
                WHERE table_schema = DATABASE()
            ");

            return [
                'status' => 'operational',
                'latency_ms' => $latencyMs,
                'version' => $row['version'] ?? 'Unknown',
                'database_name' => $row['db_name'] ?? 'school_portal',
                'db_name' => $row['db_name'] ?? 'school_portal',
                'total_tables' => (int)($sizeRow['total_tables'] ?? 0),
                'database_size_mb' => (float)($sizeRow['db_size_mb'] ?? 0.0),
                'db_size_mb' => (float)($sizeRow['db_size_mb'] ?? 0.0),
                'character_set' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'message' => "Database connection healthy ({$latencyMs}ms response time)."
            ];
        } catch (\Throwable $e) {
            return [
                'status' => 'error',
                'latency_ms' => 0.0,
                'version' => 'Unknown',
                'database_name' => 'Unknown',
                'db_name' => 'Unknown',
                'total_tables' => 0,
                'database_size_mb' => 0.0,
                'db_size_mb' => 0.0,
                'character_set' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'message' => 'Database connectivity failure: ' . $e->getMessage()
            ];
        }
    }

    /**
     * 2. Check Storage & File System Permissions
     */
    public function checkStorageHealth(): array
    {
        $baseDir = dirname(__DIR__, 2);
        $pathsToCheck = [
            'storage' => $baseDir . DIRECTORY_SEPARATOR . 'storage',
            'storage/backups' => $baseDir . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'backups',
            'storage/logs' => $baseDir . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'logs',
            'public/uploads' => $baseDir . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads',
        ];

        $results = [];
        $failures = 0;

        foreach ($pathsToCheck as $label => $path) {
            if (!is_dir($path)) {
                @mkdir($path, 0755, true);
            }

            $isWritable = is_writable($path);
            $isReadable = is_readable($path);
            if (!$isWritable) {
                $failures++;
            }

            $results[$label] = [
                'path' => $path,
                'exists' => is_dir($path),
                'readable' => $isReadable,
                'writable' => $isWritable,
                'status' => $isWritable ? 'writable' : 'read_only',
                'message' => $isWritable ? 'Accessible' : 'Write Permission Denied'
            ];
        }

        // Disk space
        $freeBytes = @disk_free_space($baseDir);
        $totalBytes = @disk_total_space($baseDir);

        $freeGb = ($freeBytes !== false) ? round($freeBytes / (1024 * 1024 * 1024), 2) : 0;
        $totalGb = ($totalBytes !== false) ? round($totalBytes / (1024 * 1024 * 1024), 2) : 0;
        $usedPercent = ($totalGb > 0) ? round((($totalGb - $freeGb) / $totalGb) * 100, 1) : 0;

        return [
            'writable_failures' => $failures,
            'paths' => $results,
            'disk_free_gb' => $freeGb,
            'disk_total_gb' => $totalGb,
            'disk_percent_used' => $usedPercent,
            'status' => ($failures === 0 && $usedPercent < 90) ? 'operational' : 'warning'
        ];
    }

    /**
     * 3. Check PHP Runtime & Security Posture
     */
    public function checkPhpRuntimeHealth(): array
    {
        $displayErrors = ini_get('display_errors');
        $displayErrorsSafe = empty($displayErrors) || strtolower((string)$displayErrors) === 'off' || $displayErrors === '0';

        $requiredExtensions = ['pdo', 'pdo_mysql', 'openssl', 'json', 'mbstring', 'curl'];
        $extStatus = [];
        foreach ($requiredExtensions as $ext) {
            $extStatus[$ext] = extension_loaded($ext);
        }

        return [
            'php_version' => PHP_VERSION,
            'memory_limit' => ini_get('memory_limit') ?: '512M',
            'max_execution_time' => (string)(ini_get('max_execution_time') ?: '30'),
            'upload_max_filesize' => ini_get('upload_max_filesize') ?: '20M',
            'post_max_size' => ini_get('post_max_size') ?: '25M',
            'display_errors' => $displayErrorsSafe ? 'Off (Secure)' : 'On (Warning)',
            'display_errors_secure' => $displayErrorsSafe,
            'extensions' => $extStatus,
            'session_cookie_httponly' => (bool)ini_get('session.cookie_httponly'),
            'session_cookie_samesite' => ini_get('session.cookie_samesite') ?: 'Lax',
        ];
    }

    /**
     * 4. Check Background Automations & Execution Health
     */
    public function checkAutomationQueueHealth(int $schoolId): array
    {
        try {
            $rulesCount = Database::fetch("SELECT COUNT(*) AS c FROM automation_rules WHERE school_id = ? AND is_active = 1", [$schoolId]);
            $logs24h = Database::fetch("
                SELECT 
                    COUNT(*) AS total_executed,
                    SUM(CASE WHEN execution_status = 'success' THEN 1 ELSE 0 END) AS success_count,
                    SUM(CASE WHEN execution_status = 'failed' THEN 1 ELSE 0 END) AS failed_count
                FROM automation_execution_logs 
                WHERE school_id = ? AND created_at >= (NOW() - INTERVAL 24 HOUR)
            ", [$schoolId]);

            $lastLog = Database::fetch("
                SELECT created_at, rule_code, execution_status 
                FROM automation_execution_logs 
                WHERE school_id = ? 
                ORDER BY id DESC LIMIT 1
            ", [$schoolId]);

            $totalExec = (int)($logs24h['total_executed'] ?? 0);
            $failedExec = (int)($logs24h['failed_count'] ?? 0);

            return [
                'active_rules_count' => (int)($rulesCount['c'] ?? 0),
                'total_executed_24h' => $totalExec,
                'executions_24h' => $totalExec,
                'success_automations_24h' => (int)($logs24h['success_count'] ?? 0),
                'failed_automations_24h' => $failedExec,
                'last_execution_time' => $lastLog['created_at'] ?? 'None recorded',
                'status' => ($failedExec === 0) ? 'operational' : 'warning'
            ];
        } catch (\Throwable $e) {
            return [
                'active_rules_count' => 0,
                'total_executed_24h' => 0,
                'executions_24h' => 0,
                'success_automations_24h' => 0,
                'failed_automations_24h' => 0,
                'last_execution_time' => 'N/A',
                'status' => 'not_configured'
            ];
        }
    }

    /**
     * Check Background Database Queue & Asynchronous Worker Health
     */
    public function checkQueueWorkerHealth(): array
    {
        try {
            $pending = (int) (Database::fetch("SELECT COUNT(*) as c FROM platform_jobs")['c'] ?? 0);
            $failed = (int) (Database::fetch("SELECT COUNT(*) as c FROM platform_failed_jobs")['c'] ?? 0);
            $lastRun = Database::fetch("SELECT completed_at, status, execution_time_ms FROM platform_job_runs ORDER BY id DESC LIMIT 1");

            return [
                'status' => ($failed > 10) ? 'warning' : 'operational',
                'pending_jobs' => $pending,
                'failed_jobs' => $failed,
                'last_run_time' => $lastRun['completed_at'] ?? 'None recorded',
                'last_run_status' => $lastRun['status'] ?? 'idle',
                'last_run_ms' => (float)($lastRun['execution_time_ms'] ?? 0.0),
            ];
        } catch (\Throwable $e) {
            return [
                'status' => 'not_configured',
                'pending_jobs' => 0,
                'failed_jobs' => 0,
                'last_run_time' => 'N/A',
                'last_run_status' => 'error',
                'last_run_ms' => 0.0,
            ];
        }
    }

    /**
     * 5. Check External Service Integrations
     */
    public function checkIntegrationsHealth(): array
    {
        // 1. Mail Service
        $smtpHost = env('SMTP_HOST', '');
        $mailConfigured = !empty($smtpHost) && $smtpHost !== 'localhost' && $smtpHost !== '127.0.0.1';

        // 2. SMS / WhatsApp
        $twilioSid = env('TWILIO_SID', '');
        $whatsappToken = env('WHATSAPP_TOKEN', '');
        $smsActive = !empty($twilioSid);
        $whatsappActive = !empty($whatsappToken);

        // 3. AI Provider
        $aiProvider = env('AI_PROVIDER', 'gemini');
        $geminiKey = env('GEMINI_API_KEY', '');
        $aiConfigured = !empty($geminiKey) && $geminiKey !== 'YOUR_GEMINI_API_KEY_HERE';

        $mailInfo = [
            'name' => 'Mail / SMTP Dispatcher',
            'configured' => $mailConfigured,
            'status' => $mailConfigured ? 'configured' : 'development_mode',
            'details' => $mailConfigured ? 'Live SMTP relay operational' : 'Local Sandbox Mode (Safe)',
            'badge' => $mailConfigured ? 'success' : 'info'
        ];

        $smsInfo = [
            'name' => 'SMS & WhatsApp Gateway',
            'configured' => ($smsActive || $whatsappActive),
            'status' => ($smsActive || $whatsappActive) ? 'live' : 'simulation_mode',
            'details' => ($smsActive || $whatsappActive) ? 'Gateways connected & verified' : 'Simulated / Safe Logging Mode',
            'badge' => ($smsActive || $whatsappActive) ? 'success' : 'info'
        ];

        $aiInfo = [
            'name' => 'Cloud AI Context Provider',
            'configured' => $aiConfigured,
            'status' => $aiConfigured ? 'configured' : 'not_configured',
            'details' => $aiConfigured ? 'Connected to Google Gemini AI Engine' : 'Standby / Local Context Fallback',
            'badge' => $aiConfigured ? 'success' : 'warning'
        ];

        return [
            'mail' => $mailInfo,
            'sms' => $smsInfo,
            'sms_whatsapp' => $smsInfo,
            'ai_gemini' => $aiInfo,
            'ai_assistant' => $aiInfo
        ];
    }

    /**
     * 6. Analyze Recent Application Errors (Zero Secret Leakage)
     */
    public function analyzeRecentErrorLogs(): array
    {
        $logDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'logs';
        $logFile = $logDir . DIRECTORY_SEPARATOR . 'app.log';

        if (!file_exists($logFile)) {
            // Check PHP error log if app.log not present
            $logFile = ini_get('error_log') ?: '';
        }

        if (empty($logFile) || !file_exists($logFile) || !is_readable($logFile)) {
            return [
                'log_file_present' => false,
                'recent_errors' => [],
                'recent_entries' => [],
                'total_logged_entries' => 0,
                'critical_count' => 0,
                'warning_count' => 0,
                'status' => 'clean',
                'diagnostics' => 'No critical error logs detected. System is running cleanly.'
            ];
        }

        $lines = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) {
            return [
                'log_file_present' => true,
                'recent_errors' => [],
                'recent_entries' => [],
                'total_logged_entries' => 0,
                'critical_count' => 0,
                'warning_count' => 0,
                'status' => 'clean',
                'diagnostics' => 'Error log file is empty.'
            ];
        }

        // Get last 30 lines
        $recentLines = array_slice($lines, -30);
        $recentErrors = [];
        $recentEntries = [];
        $critical = 0;
        $warnings = 0;

        foreach ($recentLines as $line) {
            // Scrub passwords, tokens, API keys, or student identifiers
            $sanitized = preg_replace('/(password|token|secret|key|api_key)=([^&\s]+)/i', '$1=********', $line);

            $isCrit = stripos($sanitized, 'fatal') !== false || stripos($sanitized, 'uncaught') !== false || stripos($sanitized, 'critical') !== false;
            $isWarn = stripos($sanitized, 'warning') !== false || stripos($sanitized, 'notice') !== false;

            if ($isCrit) $critical++;
            if ($isWarn) $warnings++;

            $level = $isCrit ? 'CRITICAL' : ($isWarn ? 'WARNING' : 'INFO');
            $msg = substr($sanitized, 0, 250);

            $recentErrors[] = [
                'raw' => $msg,
                'type' => strtolower($level)
            ];

            $recentEntries[] = [
                'timestamp' => date('Y-m-d H:i:s'),
                'level' => $level,
                'message' => $msg,
                'hint' => $isCrit ? 'Check application dependencies and configuration settings.' : 'Operational warning handled safely by runtime.'
            ];
        }

        return [
            'log_file_present' => true,
            'recent_errors' => array_reverse($recentErrors),
            'recent_entries' => array_reverse($recentEntries),
            'total_logged_entries' => count($lines),
            'critical_count' => $critical,
            'warning_count' => $warnings,
            'status' => ($critical > 0) ? 'critical_present' : (($warnings > 0) ? 'warnings_present' : 'clean'),
            'diagnostics' => ($critical === 0) ? 'Normal system operations without fatal exceptions.' : "{$critical} fatal or critical exceptions detected in recent logs."
        ];
    }

    /**
     * 7. Check Database Table Indexes & Schema Optimization
     */
    public function checkDatabaseIndexesAndSlowQueries(): array
    {
        $tables = [
            'students',
            'employees',
            'student_fee_invoices',
            'payments',
            'exams',
            'exam_marks',
            'student_attendance',
            'staff_attendance',
            'classes',
            'sections',
            'users'
        ];
        $indexResults = [];
        $tablesWithPk = 0;
        $totalTablesAnalyzed = 0;
        $missingPk = [];

        foreach ($tables as $tbl) {
            $tableExists = Database::fetch("SELECT COUNT(*) AS c FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?", [$tbl]);
            if ((int)($tableExists['c'] ?? 0) === 0) {
                continue;
            }

            $totalTablesAnalyzed++;
            $indexes = Database::fetchAll("SHOW INDEX FROM `{$tbl}`");
            $indexedCols = [];
            $hasPk = false;

            foreach ($indexes as $idx) {
                $indexedCols[] = $idx['Column_name'];
                if (($idx['Key_name'] ?? '') === 'PRIMARY') {
                    $hasPk = true;
                }
            }
            $indexedCols = array_unique($indexedCols);

            if ($hasPk) {
                $tablesWithPk++;
            } else {
                $missingPk[] = $tbl;
            }

            $hasSchoolId = in_array('school_id', $indexedCols, true);
            $indexResults[] = [
                'table' => $tbl,
                'has_primary_key' => $hasPk,
                'has_tenant_index' => $hasSchoolId,
                'indexed_columns' => $indexedCols,
                'status' => ($hasSchoolId && $hasPk) ? 'optimized' : 'needs_index'
            ];
        }

        return [
            'tables_analyzed' => $totalTablesAnalyzed,
            'total_tables' => $totalTablesAnalyzed,
            'tables_with_primary_keys' => $tablesWithPk,
            'missing_pk_tables' => $missingPk,
            'index_status' => $indexResults,
            'status' => empty($missingPk) ? 'good' : 'investigate'
        ];
    }

    /**
     * 8. Retrieve Active Actionable System Alerts
     */
    public function getActiveAlerts(?int $schoolId = null): array
    {
        try {
            $tableExists = Database::fetch("SELECT COUNT(*) as c FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'system_alerts'");
            if ((int)($tableExists['c'] ?? 0) === 0) {
                return ['open_count' => 0, 'critical_count' => 0, 'alerts' => []];
            }

            $sql = "SELECT id, school_id, alert_type, severity, title, occurrences, last_seen_at FROM system_alerts WHERE status = 'open'";
            $params = [];
            if ($schoolId !== null && $schoolId > 0) {
                $sql .= " AND (school_id = ? OR school_id = 0)";
                $params[] = $schoolId;
            }
            $sql .= " ORDER BY id DESC LIMIT 10";

            $alerts = Database::fetchAll($sql, $params);
            $critCount = count(array_filter($alerts, fn($a) => in_array(strtolower($a['severity']), ['critical', 'alert', 'emergency'], true)));

            return [
                'open_count' => count($alerts),
                'critical_count' => $critCount,
                'alerts' => $alerts
            ];
        } catch (\Throwable $e) {
            return ['open_count' => 0, 'critical_count' => 0, 'alerts' => []];
        }
    }
}
