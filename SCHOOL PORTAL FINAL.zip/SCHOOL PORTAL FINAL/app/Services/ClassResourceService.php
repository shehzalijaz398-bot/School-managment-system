<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;

final class ClassResourceService
{
    public function ensureSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS class_resources (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id INT UNSIGNED NOT NULL,
                class_id BIGINT UNSIGNED NOT NULL,
                section_id BIGINT UNSIGNED NULL,
                subject_id BIGINT UNSIGNED NULL,
                teacher_id BIGINT UNSIGNED NULL,
                title VARCHAR(191) NOT NULL,
                description TEXT NULL,
                file_path VARCHAR(255) NOT NULL,
                file_name VARCHAR(191) NOT NULL,
                file_size INT UNSIGNED NULL,
                file_type VARCHAR(100) NULL,
                download_count INT UNSIGNED NOT NULL DEFAULT 0,
                created_by BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_res_school_class (school_id, class_id),
                INDEX idx_res_subject (subject_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    /**
     * List resources for a class/section with optional subject filter.
     */
    public function getResourcesForClass(int $classId, ?int $sectionId, ?int $subjectId, int $schoolId): array
    {
        $this->ensureSchema();

        $sql = "
            SELECT r.*,
                   cls.name AS class_name,
                   sec.name AS section_name,
                   s.name AS subject_name,
                   s.code AS subject_code,
                   u.name AS uploader_name
            FROM class_resources r
            LEFT JOIN classes cls ON cls.id = r.class_id
            LEFT JOIN sections sec ON sec.id = r.section_id
            LEFT JOIN subjects s ON s.id = r.subject_id
            LEFT JOIN users u ON u.id = r.created_by
            WHERE r.school_id = :school_id AND r.class_id = :class_id
        ";
        $params = ['school_id' => $schoolId, 'class_id' => $classId];

        if ($sectionId) {
            $sql .= " AND (r.section_id = :section_id OR r.section_id IS NULL)";
            $params['section_id'] = $sectionId;
        }

        if ($subjectId) {
            $sql .= " AND r.subject_id = :subject_id";
            $params['subject_id'] = $subjectId;
        }

        $sql .= " ORDER BY r.created_at DESC";

        return Database::fetchAll($sql, $params);
    }

    /**
     * Upload and register a new learning resource.
     */
    public function createResource(int $schoolId, array $data, array $file, int $userId): int
    {
        $this->ensureSchema();

        $classId = (int) ($data['class_id'] ?? 0);
        $sectionId = !empty($data['section_id']) ? (int) $data['section_id'] : null;
        $subjectId = !empty($data['subject_id']) ? (int) $data['subject_id'] : null;
        $title = trim((string) ($data['title'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));

        if (!$classId || empty($title)) {
            throw new \InvalidArgumentException('Class and Resource Title are required.');
        }

        // Validate File
        if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
            throw new \InvalidArgumentException('Please attach a valid document or resource file.');
        }

        // 25MB max
        if ($file['size'] > 25 * 1024 * 1024) {
            throw new \InvalidArgumentException('Resource file cannot exceed 25MB.');
        }

        $allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'application/zip',
            'application/x-zip-compressed',
            'image/jpeg',
            'image/png',
            'image/webp',
            'text/plain',
        ];

        $filePath = upload_file($file, 'resources', $allowedTypes);
        $fileName = basename($file['name']);
        $fileSize = (int) $file['size'];
        $fileType = mime_content_type(public_path($filePath)) ?: ($file['type'] ?? 'application/octet-stream');

        // Check if teacher
        $teacher = Database::fetch("SELECT t.id FROM teachers t INNER JOIN users u ON u.employee_id = t.employee_id WHERE u.id = ? AND t.school_id = ? LIMIT 1", [$userId, $schoolId]);
        $teacherId = $teacher ? (int) $teacher['id'] : null;

        $id = Database::insert("
            INSERT INTO class_resources 
            (school_id, class_id, section_id, subject_id, teacher_id, title, description, file_path, file_name, file_size, file_type, download_count, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NOW(), NOW())
        ", [
            $schoolId,
            $classId,
            $sectionId,
            $subjectId,
            $teacherId,
            $title,
            $description,
            $filePath,
            $fileName,
            $fileSize,
            $fileType,
            $userId,
        ]);

        auditLog('resource.create', 'learning', 'class_resources', $id, null, [
            'class_id' => $classId,
            'title' => $title,
            'file_name' => $fileName,
        ]);

        return $id;
    }

    /**
     * Increment download count and return file path.
     */
    public function downloadResource(int $resourceId, int $schoolId): ?array
    {
        $this->ensureSchema();

        $res = Database::fetch("
            SELECT * FROM class_resources 
            WHERE id = ? AND school_id = ? LIMIT 1
        ", [$resourceId, $schoolId]);

        if (!$res) {
            return null;
        }

        Database::execute("
            UPDATE class_resources 
            SET download_count = download_count + 1 
            WHERE id = ?
        ", [$resourceId]);

        $res['download_count'] = (int)$res['download_count'] + 1;

        return $res;
    }

    /**
     * Delete resource and its file.
     */
    public function deleteResource(int $resourceId, int $schoolId, int $userId, bool $isAdmin): bool
    {
        $this->ensureSchema();

        $res = Database::fetch("SELECT * FROM class_resources WHERE id = ? AND school_id = ? LIMIT 1", [$resourceId, $schoolId]);
        if (!$res) {
            return false;
        }

        if (!$isAdmin && (int) $res['created_by'] !== $userId) {
            throw new \RuntimeException('Unauthorized to delete this resource.');
        }

        $realPath = public_path($res['file_path']);
        if (file_exists($realPath)) {
            @unlink($realPath);
        }

        Database::execute("DELETE FROM class_resources WHERE id = ?", [$resourceId]);

        auditLog('resource.delete', 'learning', 'class_resources', $resourceId);
        return true;
    }
}
