<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class DocumentService
{
    private static bool $schemaChecked = false;
    private const MAX_FILE_SIZE = 10485760; // 10 MB

    private const ALLOWED_EXTENSIONS = [
        'pdf', 'png', 'jpg', 'jpeg', 'docx', 'xlsx', 'csv', 'txt'
    ];

    private const FORBIDDEN_EXTENSIONS = [
        'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phps', 'exe',
        'sh', 'bat', 'cmd', 'js', 'html', 'htm', 'vbs', 'scr', 'svg', 'jar'
    ];

    private const ALLOWED_MIME_TYPES = [
        'application/pdf',
        'image/png',
        'image/jpeg',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/csv',
        'text/plain',
        'application/octet-stream' // fallback check against extension
    ];

    public function __construct()
    {
        $this->ensureSchema();
    }

    /**
     * Auto-provision document management, versioning, and workflow audit tables.
     */
    public function ensureSchema(): void
    {
        if (self::$schemaChecked) {
            return;
        }

        // 1. Core school_documents table
        Database::execute("
            CREATE TABLE IF NOT EXISTS school_documents (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                document_ref VARCHAR(64) NOT NULL,
                category VARCHAR(60) NOT NULL DEFAULT 'general',
                entity_type VARCHAR(50) NULL DEFAULT 'general',
                entity_id BIGINT UNSIGNED NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT NULL,
                file_name VARCHAR(255) NOT NULL,
                file_path VARCHAR(255) NOT NULL,
                file_size BIGINT UNSIGNED NOT NULL,
                mime_type VARCHAR(100) NOT NULL,
                file_hash VARCHAR(64) NOT NULL,
                version INT UNSIGNED NOT NULL DEFAULT 1,
                is_confidential TINYINT(1) NOT NULL DEFAULT 0,
                expiry_date DATE NULL,
                review_status ENUM('pending', 'under_review', 'approved', 'rejected') NOT NULL DEFAULT 'approved',
                reviewed_by BIGINT UNSIGNED NULL,
                reviewed_at DATETIME NULL,
                reviewer_notes TEXT NULL,
                verification_code VARCHAR(64) NULL,
                uploaded_by BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                UNIQUE KEY uq_sdoc_ref (document_ref),
                INDEX idx_sdoc_school (school_id),
                INDEX idx_sdoc_cat (school_id, category),
                INDEX idx_sdoc_entity (school_id, entity_type, entity_id),
                INDEX idx_sdoc_expiry (school_id, expiry_date),
                INDEX idx_sdoc_status (school_id, review_status),
                INDEX idx_sdoc_vcode (verification_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        // 2. document_versions table
        Database::execute("
            CREATE TABLE IF NOT EXISTS document_versions (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                document_id BIGINT UNSIGNED NOT NULL,
                school_id BIGINT UNSIGNED NOT NULL,
                version_number INT UNSIGNED NOT NULL,
                file_path VARCHAR(255) NOT NULL,
                file_name VARCHAR(255) NOT NULL,
                file_size BIGINT UNSIGNED NOT NULL,
                file_hash VARCHAR(64) NOT NULL,
                changelog TEXT NULL,
                uploaded_by BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL,
                INDEX idx_dver_doc (document_id),
                INDEX idx_dver_school (school_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        // 3. document_reviews table (workflow approval history)
        Database::execute("
            CREATE TABLE IF NOT EXISTS document_reviews (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                document_id BIGINT UNSIGNED NOT NULL,
                school_id BIGINT UNSIGNED NOT NULL,
                action ENUM('submitted', 'status_change', 'version_upload', 'reviewed', 'downloaded') NOT NULL,
                old_status VARCHAR(50) NULL,
                new_status VARCHAR(50) NULL,
                notes TEXT NULL,
                actor_id BIGINT UNSIGNED NOT NULL,
                actor_name VARCHAR(150) NOT NULL,
                created_at DATETIME NOT NULL,
                INDEX idx_drev_doc (document_id),
                INDEX idx_drev_school (school_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        // Ensure storage directory exists and has .htaccess guard
        $storageDir = dirname(__DIR__, 2) . '/storage/documents';
        if (!is_dir($storageDir)) {
            mkdir($storageDir, 0755, true);
        }
        $htaccess = $storageDir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "# Protect uploaded documents from execution\n<FilesMatch \"\\.(php|phtml|php3|php4|php5|php7|phps|exe|sh|bat|cmd|pl|py|cgi)$\">\n    Order Deny,Allow\n    Deny from all\n</FilesMatch>\nOptions -Indexes -ExecCGI\n");
        }

        self::$schemaChecked = true;
    }

    /**
     * Upload and register a new secure document.
     */
    public function uploadDocument(int $schoolId, int $userId, array $fileInfo, array $meta): array
    {
        $this->validateUpload($fileInfo);

        $category = trim(strtolower((string)($meta['category'] ?? 'general')));
        $allowedCats = ['student_record', 'staff_file', 'admission', 'certificate', 'administrative', 'legal_compliance', 'general'];
        if (!in_array($category, $allowedCats, true)) {
            $category = 'general';
        }

        $title = trim((string)($meta['title'] ?? ''));
        if ($title === '') {
            $title = pathinfo($fileInfo['name'] ?? 'Document', PATHINFO_FILENAME);
        }

        $entityType = !empty($meta['entity_type']) ? trim((string)$meta['entity_type']) : 'general';
        $entityId = !empty($meta['entity_id']) ? (int)$meta['entity_id'] : null;
        $description = !empty($meta['description']) ? trim((string)$meta['description']) : null;
        $isConfidential = !empty($meta['is_confidential']) ? 1 : 0;
        $expiryDate = !empty($meta['expiry_date']) ? trim((string)$meta['expiry_date']) : null;
        $initialStatus = !empty($meta['review_status']) && in_array($meta['review_status'], ['pending', 'under_review', 'approved', 'rejected'], true)
            ? $meta['review_status']
            : 'approved';

        $rawName = basename($fileInfo['name'] ?? 'upload.bin');
        $ext = strtolower(pathinfo($rawName, PATHINFO_EXTENSION));
        $fileSize = (int)($fileInfo['size'] ?? 0);
        $tmpPath = $fileInfo['tmp_name'] ?? '';

        // Compute SHA-256 integrity hash
        $fileHash = hash_file('sha256', $tmpPath) ?: hash('sha256', $rawName . time());

        // Target path in storage/documents/{school_id}/{category}/
        $subDir = "storage/documents/{$schoolId}/{$category}";
        $absSubDir = dirname(__DIR__, 2) . '/' . $subDir;
        if (!is_dir($absSubDir)) {
            mkdir($absSubDir, 0755, true);
        }

        $storedFileName = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $relPath = $subDir . '/' . $storedFileName;
        $absPath = $absSubDir . '/' . $storedFileName;

        if (is_uploaded_file($tmpPath)) {
            if (!move_uploaded_file($tmpPath, $absPath)) {
                throw new \RuntimeException('Failed to store uploaded document on disk.');
            }
        } else {
            // For programmatic tests or direct file copying
            if (!copy($tmpPath, $absPath)) {
                throw new \RuntimeException('Failed to save document file.');
            }
        }

        $docRef = 'DOC-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
        $vCode = 'V-' . strtoupper(bin2hex(random_bytes(5)));
        $mime = $this->detectMimeType($absPath, $rawName);

        $docId = Database::insert("
            INSERT INTO school_documents (
                school_id, document_ref, category, entity_type, entity_id,
                title, description, file_name, file_path, file_size,
                mime_type, file_hash, version, is_confidential, expiry_date,
                review_status, verification_code, uploaded_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, NOW(), NOW())
        ", [
            $schoolId, $docRef, $category, $entityType, $entityId,
            $title, $description, $rawName, $relPath, $fileSize,
            $mime, $fileHash, $isConfidential, $expiryDate,
            $initialStatus, $vCode, $userId
        ]);

        // Record Version 1 in document_versions
        Database::insert("
            INSERT INTO document_versions (
                document_id, school_id, version_number, file_path, file_name,
                file_size, file_hash, changelog, uploaded_by, created_at
            ) VALUES (?, ?, 1, ?, ?, ?, ?, 'Initial upload (v1.0)', ?, NOW())
        ", [
            $docId, $schoolId, $relPath, $rawName, $fileSize, $fileHash, $userId
        ]);

        // Record review submission action
        $actorName = $this->getActorName($userId);
        Database::insert("
            INSERT INTO document_reviews (
                document_id, school_id, action, old_status, new_status,
                notes, actor_id, actor_name, created_at
            ) VALUES (?, ?, 'submitted', NULL, ?, 'Document uploaded and registered in system.', ?, ?, NOW())
        ", [
            $docId, $schoolId, $initialStatus, $userId, $actorName
        ]);

        return [
            'id' => $docId,
            'document_ref' => $docRef,
            'title' => $title,
            'file_name' => $rawName,
            'file_path' => $relPath,
            'file_size' => $fileSize,
            'file_hash' => $fileHash,
            'category' => $category,
            'version' => 1,
            'review_status' => $initialStatus,
            'verification_code' => $vCode
        ];
    }

    /**
     * Upload a new version of an existing document.
     */
    public function uploadNewVersion(int $schoolId, int $userId, int $documentId, array $fileInfo, ?string $changelog = null): array
    {
        $this->validateUpload($fileInfo);

        $doc = Database::fetch("SELECT * FROM school_documents WHERE id = ? AND school_id = ? LIMIT 1", [$documentId, $schoolId]);
        if (!$doc) {
            throw new \RuntimeException('Document not found or access denied.');
        }

        $nextVersion = ((int)$doc['version']) + 1;
        $category = $doc['category'];
        $rawName = basename($fileInfo['name'] ?? 'version.bin');
        $ext = strtolower(pathinfo($rawName, PATHINFO_EXTENSION));
        $fileSize = (int)($fileInfo['size'] ?? 0);
        $tmpPath = $fileInfo['tmp_name'] ?? '';

        $fileHash = hash_file('sha256', $tmpPath) ?: hash('sha256', $rawName . time());

        $subDir = "storage/documents/{$schoolId}/{$category}";
        $absSubDir = dirname(__DIR__, 2) . '/' . $subDir;
        if (!is_dir($absSubDir)) {
            mkdir($absSubDir, 0755, true);
        }

        $storedFileName = time() . '_v' . $nextVersion . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $relPath = $subDir . '/' . $storedFileName;
        $absPath = $absSubDir . '/' . $storedFileName;

        if (is_uploaded_file($tmpPath)) {
            move_uploaded_file($tmpPath, $absPath);
        } else {
            copy($tmpPath, $absPath);
        }

        $mime = $this->detectMimeType($absPath, $rawName);
        $note = $changelog ?: "Uploaded version {$nextVersion}";

        // Update core document record
        Database::execute("
            UPDATE school_documents SET
                file_name = ?,
                file_path = ?,
                file_size = ?,
                mime_type = ?,
                file_hash = ?,
                version = ?,
                updated_at = NOW()
            WHERE id = ? AND school_id = ?
        ", [
            $rawName, $relPath, $fileSize, $mime, $fileHash, $nextVersion, $documentId, $schoolId
        ]);

        // Insert new version entry
        Database::insert("
            INSERT INTO document_versions (
                document_id, school_id, version_number, file_path, file_name,
                file_size, file_hash, changelog, uploaded_by, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ", [
            $documentId, $schoolId, $nextVersion, $relPath, $rawName, $fileSize, $fileHash, $note, $userId
        ]);

        // Audit review log
        $actorName = $this->getActorName($userId);
        Database::insert("
            INSERT INTO document_reviews (
                document_id, school_id, action, old_status, new_status,
                notes, actor_id, actor_name, created_at
            ) VALUES (?, ?, 'version_upload', ?, ?, ?, ?, ?, NOW())
        ", [
            $documentId, $schoolId, $doc['review_status'], $doc['review_status'],
            "New version v{$nextVersion} uploaded: {$note}", $userId, $actorName
        ]);

        return [
            'id' => $documentId,
            'version' => $nextVersion,
            'file_name' => $rawName,
            'file_path' => $relPath,
            'file_hash' => $fileHash
        ];
    }

    /**
     * Update review status and record approval trail.
     */
    public function updateReviewStatus(int $schoolId, int $userId, int $documentId, string $newStatus, ?string $notes = null): bool
    {
        $allowed = ['pending', 'under_review', 'approved', 'rejected'];
        if (!in_array($newStatus, $allowed, true)) {
            throw new \InvalidArgumentException('Invalid review status.');
        }

        $doc = Database::fetch("SELECT * FROM school_documents WHERE id = ? AND school_id = ? LIMIT 1", [$documentId, $schoolId]);
        if (!$doc) {
            return false;
        }

        $oldStatus = $doc['review_status'];

        Database::execute("
            UPDATE school_documents SET
                review_status = ?,
                reviewed_by = ?,
                reviewed_at = NOW(),
                reviewer_notes = ?,
                updated_at = NOW()
            WHERE id = ? AND school_id = ?
        ", [$newStatus, $userId, $notes, $documentId, $schoolId]);

        $actorName = $this->getActorName($userId);
        Database::insert("
            INSERT INTO document_reviews (
                document_id, school_id, action, old_status, new_status,
                notes, actor_id, actor_name, created_at
            ) VALUES (?, ?, 'status_change', ?, ?, ?, ?, ?, NOW())
        ", [$documentId, $schoolId, $oldStatus, $newStatus, $notes ?: "Status changed to {$newStatus}", $userId, $actorName]);

        return true;
    }

    /**
     * Query documents with filters, search, and pagination.
     */
    public function queryDocuments(int $schoolId, array $filters = []): array
    {
        $sql = "SELECT d.*, u.name as uploader_name, r.name as reviewer_name
                FROM school_documents d
                LEFT JOIN users u ON u.id = d.uploaded_by
                LEFT JOIN users r ON r.id = d.reviewed_by
                WHERE d.school_id = ?";
        $params = [$schoolId];

        if (!empty($filters['category']) && $filters['category'] !== 'all') {
            $sql .= " AND d.category = ?";
            $params[] = $filters['category'];
        }

        if (!empty($filters['review_status']) && $filters['review_status'] !== 'all') {
            $sql .= " AND d.review_status = ?";
            $params[] = $filters['review_status'];
        }

        if (isset($filters['is_confidential']) && $filters['is_confidential'] !== '') {
            $sql .= " AND d.is_confidential = ?";
            $params[] = (int)$filters['is_confidential'];
        }

        if (!empty($filters['entity_type'])) {
            $sql .= " AND d.entity_type = ?";
            $params[] = $filters['entity_type'];
        }

        if (!empty($filters['entity_id'])) {
            $sql .= " AND d.entity_id = ?";
            $params[] = (int)$filters['entity_id'];
        }

        if (!empty($filters['expiring_soon'])) {
            $days = (int)$filters['expiring_soon'];
            $sql .= " AND d.expiry_date IS NOT NULL AND d.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)";
            $params[] = $days;
        }

        if (!empty($filters['search'])) {
            $wild = '%' . trim((string)$filters['search']) . '%';
            $sql .= " AND (d.document_ref LIKE ? OR d.title LIKE ? OR d.file_name LIKE ? OR d.description LIKE ?)";
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }

        $sql .= " ORDER BY d.id DESC";

        if (!empty($filters['limit'])) {
            $limit = max(1, min(200, (int)$filters['limit']));
            $offset = max(0, (int)($filters['offset'] ?? 0));
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }

        return Database::fetchAll($sql, $params);
    }

    /**
     * Get document by reference code.
     */
    public function getDocumentByRef(int $schoolId, string $ref): ?array
    {
        $doc = Database::fetch("
            SELECT d.*, u.name as uploader_name, r.name as reviewer_name
            FROM school_documents d
            LEFT JOIN users u ON u.id = d.uploaded_by
            LEFT JOIN users r ON r.id = d.reviewed_by
            WHERE d.document_ref = ? AND d.school_id = ?
            LIMIT 1
        ", [$ref, $schoolId]);

        if (!$doc) {
            return null;
        }

        $doc['versions'] = $this->getVersions($schoolId, (int)$doc['id']);
        $doc['reviews'] = $this->getReviews($schoolId, (int)$doc['id']);

        return $doc;
    }

    /**
     * Get document by primary ID.
     */
    public function getDocumentById(int $schoolId, int $id): ?array
    {
        return Database::fetch("SELECT * FROM school_documents WHERE id = ? AND school_id = ? LIMIT 1", [$id, $schoolId]);
    }

    /**
     * Get version history for a document.
     */
    public function getVersions(int $schoolId, int $documentId): array
    {
        return Database::fetchAll("
            SELECT v.*, u.name as uploader_name
            FROM document_versions v
            LEFT JOIN users u ON u.id = v.uploaded_by
            WHERE v.document_id = ? AND v.school_id = ?
            ORDER BY v.version_number DESC
        ", [$documentId, $schoolId]);
    }

    /**
     * Get review audit history for a document.
     */
    public function getReviews(int $schoolId, int $documentId): array
    {
        return Database::fetchAll("
            SELECT * FROM document_reviews 
            WHERE document_id = ? AND school_id = ? 
            ORDER BY id DESC
        ", [$documentId, $schoolId]);
    }

    /**
     * Identify expiring documents within threshold days.
     */
    public function getExpiringDocuments(int $schoolId, int $daysAhead = 30): array
    {
        return Database::fetchAll("
            SELECT d.*, 
                   DATEDIFF(d.expiry_date, CURDATE()) as days_until_expiry,
                   CASE 
                       WHEN d.expiry_date < CURDATE() THEN 'expired'
                       ELSE 'expiring_soon'
                   END as expiry_state
            FROM school_documents d
            WHERE d.school_id = ?
              AND d.expiry_date IS NOT NULL
              AND d.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
            ORDER BY d.expiry_date ASC
        ", [$schoolId, $daysAhead]);
    }

    /**
     * Generate an official verifiable digital record with school branding.
     */
    public function generateDigitalRecord(int $schoolId, int $userId, string $type, int $studentId, array $options = []): array
    {
        $allowed = ['enrollment_confirmation', 'transcript', 'fee_receipt', 'bonafide', 'transfer'];
        if (!in_array($type, $allowed, true)) {
            throw new \InvalidArgumentException("Invalid record type: {$type}");
        }

        $student = Database::fetch("
            SELECT s.*, c.name as class_name, sec.name as section_name
            FROM students s
            LEFT JOIN classes c ON c.id = s.class_id
            LEFT JOIN sections sec ON sec.id = s.section_id
            WHERE s.id = ? AND s.school_id = ?
            LIMIT 1
        ", [$studentId, $schoolId]);

        if (!$student) {
            throw new \RuntimeException('Student record not found.');
        }

        $school = Database::fetch("SELECT * FROM schools WHERE id = ? LIMIT 1", [$schoolId]);
        $schoolName = $school['name'] ?? 'School Institution';

        $stName = trim($student['first_name'] . ' ' . $student['last_name']);
        $admNo = $student['admission_no'] ?? 'N/A';
        $cls = trim(($student['class_name'] ?? '') . ' ' . ($student['section_name'] ?? ''));

        $refNo = 'REC-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $vCode = 'V-' . strtoupper(bin2hex(random_bytes(4)));

        $titles = [
            'enrollment_confirmation' => 'Official Enrollment Confirmation',
            'transcript' => 'Official Academic Cumulative Transcript',
            'fee_receipt' => 'Official Fee Payment Statement',
            'bonafide' => 'Bonafide Student Certificate',
            'transfer' => 'Official School Leaving & Transfer Certificate'
        ];

        $title = $titles[$type] ?? 'Official Institutional Record';
        $content = '';

        if ($type === 'enrollment_confirmation') {
            $content = "This document confirms that {$stName} (Admission No: {$admNo}) is actively enrolled as a full-time student in Class {$cls} at {$schoolName} for the current academic session. Enrollment status is verified active.";
        } elseif ($type === 'transcript') {
            $content = "Official Cumulative Academic Transcript for {$stName} (Admission No: {$admNo}), Class {$cls}. The student has fulfilled all required curricular attendance and coursework milestones.";
        } elseif ($type === 'fee_receipt') {
            $fees = Database::fetch("
                SELECT SUM(total_amount) as billed, SUM(paid_amount) as paid 
                FROM student_fee_invoices 
                WHERE student_id = ? AND school_id = ?
            ", [$studentId, $schoolId]);
            $billed = number_format((float)($fees['billed'] ?? 0), 2);
            $paid = number_format((float)($fees['paid'] ?? 0), 2);
            $balance = number_format((float)(($fees['billed'] ?? 0) - ($fees['paid'] ?? 0)), 2);
            $content = "Official Fee Clearance Statement for {$stName} (Admission No: {$admNo}). Total Billed: ₹{$billed}, Total Paid: ₹{$paid}, Outstanding Balance: ₹{$balance}. Status verified against institutional ledger.";
        } else {
            $content = "This is an official credential issued by {$schoolName} certifying that {$stName} (Admission No: {$admNo}) has been a student in Class {$cls}.";
        }

        // Store generated digital certificate file as HTML/Text for instant viewing/printing
        $subDir = "storage/documents/{$schoolId}/certificate";
        $absSubDir = dirname(__DIR__, 2) . '/' . $subDir;
        if (!is_dir($absSubDir)) {
            mkdir($absSubDir, 0755, true);
        }

        $fileName = strtolower($type) . '_' . $studentId . '_' . time() . '.html';
        $relPath = $subDir . '/' . $fileName;
        $absPath = $absSubDir . '/' . $fileName;

        $docHtml = "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>{$title}</title></head><body><h2>{$schoolName}</h2><h3>{$title}</h3><p>Ref: {$refNo} | Verification: {$vCode}</p><hr><p>{$content}</p></body></html>";
        file_put_contents($absPath, $docHtml);

        $fileSize = filesize($absPath) ?: strlen($docHtml);
        $fileHash = hash('sha256', $docHtml);

        $docId = Database::insert("
            INSERT INTO school_documents (
                school_id, document_ref, category, entity_type, entity_id,
                title, description, file_name, file_path, file_size,
                mime_type, file_hash, version, is_confidential, expiry_date,
                review_status, verification_code, uploaded_by, created_at, updated_at
            ) VALUES (?, ?, 'certificate', 'student', ?, ?, ?, ?, ?, ?, 'text/html', ?, 1, 0, NULL, 'approved', ?, ?, NOW(), NOW())
        ", [
            $schoolId, $refNo, $studentId, $title, $content, $fileName,
            $relPath, $fileSize, $fileHash, $vCode, $userId
        ]);

        Database::insert("
            INSERT INTO document_versions (
                document_id, school_id, version_number, file_path, file_name,
                file_size, file_hash, changelog, uploaded_by, created_at
            ) VALUES (?, ?, 1, ?, ?, ?, ?, 'Generated official digital record', ?, NOW())
        ", [$docId, $schoolId, $relPath, $fileName, $fileSize, $fileHash, $userId]);

        return [
            'id' => $docId,
            'document_ref' => $refNo,
            'verification_code' => $vCode,
            'type' => $type,
            'title' => $title,
            'student_name' => $stName,
            'admission_no' => $admNo,
            'content' => $content,
            'file_path' => $relPath,
            'file_hash' => $fileHash
        ];
    }

    /**
     * Public or authenticated document verification by verification code or document reference.
     */
    public function verifyDocument(string $code): ?array
    {
        $code = trim($code);
        if ($code === '') {
            return null;
        }

        $doc = Database::fetch("
            SELECT d.*, s.name as school_name, s.code as school_code,
                   u.name as issuer_name,
                   CASE 
                       WHEN d.entity_type = 'student' THEN (SELECT CONCAT(first_name, ' ', last_name) FROM students WHERE id = d.entity_id)
                       WHEN d.entity_type = 'employee' THEN (SELECT CONCAT(first_name, ' ', last_name) FROM employees WHERE id = d.entity_id)
                       ELSE NULL
                   END as recipient_name
            FROM school_documents d
            INNER JOIN schools s ON s.id = d.school_id
            LEFT JOIN users u ON u.id = d.uploaded_by
            WHERE d.verification_code = ? OR d.document_ref = ?
            LIMIT 1
        ", [$code, $code]);

        return $doc ?: null;
    }

    /**
     * Delete document and all versions.
     */
    public function deleteDocument(int $schoolId, int $documentId): bool
    {
        $doc = Database::fetch("SELECT * FROM school_documents WHERE id = ? AND school_id = ? LIMIT 1", [$documentId, $schoolId]);
        if (!$doc) {
            return false;
        }

        // Delete physical files
        $versions = Database::fetchAll("SELECT file_path FROM document_versions WHERE document_id = ?", [$documentId]);
        foreach ($versions as $v) {
            $abs = dirname(__DIR__, 2) . '/' . $v['file_path'];
            if (file_exists($abs)) {
                @unlink($abs);
            }
        }
        $mainAbs = dirname(__DIR__, 2) . '/' . $doc['file_path'];
        if (file_exists($mainAbs)) {
            @unlink($mainAbs);
        }

        Database::execute("DELETE FROM document_reviews WHERE document_id = ?", [$documentId]);
        Database::execute("DELETE FROM document_versions WHERE document_id = ?", [$documentId]);
        Database::execute("DELETE FROM school_documents WHERE id = ? AND school_id = ?", [$documentId, $schoolId]);

        return true;
    }

    /**
     * Validate upload security (reject executables, validate size, prevent path traversal).
     */
    private function validateUpload(array $fileInfo): void
    {
        if (empty($fileInfo) || !isset($fileInfo['size']) || !isset($fileInfo['name'])) {
            throw new \InvalidArgumentException('No file uploaded or invalid file payload.');
        }

        if (($fileInfo['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('Upload error occurred (code ' . ($fileInfo['error'] ?? 0) . ').');
        }

        $size = (int)$fileInfo['size'];
        if ($size <= 0) {
            throw new \InvalidArgumentException('Uploaded file is empty (0 bytes).');
        }

        if ($size > self::MAX_FILE_SIZE) {
            throw new \InvalidArgumentException('File exceeds maximum upload limit of 10 MB.');
        }

        $rawName = basename($fileInfo['name']);
        if (preg_match('/(\.\.|\/|\\\\)/', $rawName)) {
            throw new \SecurityException('Path traversal attempt detected in file name.');
        }

        $ext = strtolower(pathinfo($rawName, PATHINFO_EXTENSION));

        // Strict rejection of forbidden script/executable extensions
        if (in_array($ext, self::FORBIDDEN_EXTENSIONS, true)) {
            throw new \SecurityException("Execution security error: Files with extension '.{$ext}' are strictly prohibited.");
        }

        if (!in_array($ext, self::ALLOWED_EXTENSIONS, true)) {
            throw new \InvalidArgumentException("Unsupported file type: '.{$ext}'. Allowed formats: " . implode(', ', self::ALLOWED_EXTENSIONS));
        }

        // Validate MIME type if file exists
        $tmp = $fileInfo['tmp_name'] ?? '';
        if ($tmp && file_exists($tmp)) {
            $mime = $this->detectMimeType($tmp, $rawName);
            if (!in_array($mime, self::ALLOWED_MIME_TYPES, true)) {
                // Check if text/plain or binary
                if (!str_starts_with($mime, 'text/') && !str_starts_with($mime, 'image/') && !str_starts_with($mime, 'application/')) {
                    throw new \SecurityException("Disallowed MIME type: {$mime}");
                }
            }
        }
    }

    private function detectMimeType(string $path, string $fileName): string
    {
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $path);
            finfo_close($finfo);
            if ($mime && $mime !== 'application/octet-stream') {
                return $mime;
            }
        }

        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $map = [
            'pdf' => 'application/pdf',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv' => 'text/csv',
            'txt' => 'text/plain',
            'html' => 'text/html'
        ];

        return $map[$ext] ?? 'application/octet-stream';
    }

    private function getActorName(int $userId): string
    {
        if ($userId <= 0) {
            return 'System Automated';
        }
        $u = Database::fetch("SELECT name FROM users WHERE id = ? LIMIT 1", [$userId]);
        return $u['name'] ?? 'Authorized User';
    }
}
