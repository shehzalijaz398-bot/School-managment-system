<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use InvalidArgumentException;

/**
 * MessageQueueService
 * High-throughput asynchronous message enqueuer for WhatsApp Cloud API, Twilio, SMTP, and Push.
 * Supports priority metric scheduling, batch multi-row inserts, and tenant boundary verification.
 */
final class MessageQueueService
{
    // Priority Metric Constants
    public const PRIORITY_URGENT = 1;   // OTP, Emergency alerts
    public const PRIORITY_HIGH   = 3;   // AI chatbot push replies, direct parent inquiries
    public const PRIORITY_NORMAL = 5;   // Daily homework diaries, attendance absent alerts
    public const PRIORITY_BULK   = 10;  // Mass fee reminders, general newsletters

    /**
     * Enqueue a single message.
     *
     * @param int $schoolId Tenant ID
     * @param string $channel 'whatsapp'|'sms'|'email'|'push'
     * @param string $recipient E.164 phone or email address
     * @param array $payload Structured message body, template parameters, attachments
     * @param string $messageType 'ai_push_response'|'homework_diary'|'fee_reminder'|'attendance_alert'|'general'
     * @param int $priority 1 (highest) to 10 (bulk)
     * @param string|null $subject Optional email/message title
     * @param string|null $recipientName
     * @param int|null $recipientId Linked student_id, user_id, or parent_id
     * @param string|null $recipientType 'student'|'parent'|'employee'|'user'
     * @param int $delaySeconds Seconds to delay availability
     * @param string $provider 'whatsapp_cloud'|'twilio'|'smtp'|'sendgrid'
     * @return int Enqueued record ID
     */
    public function enqueue(
        int $schoolId,
        string $channel,
        string $recipient,
        array $payload,
        string $messageType = 'general',
        int $priority = self::PRIORITY_NORMAL,
        ?string $subject = null,
        ?string $recipientName = null,
        ?int $recipientId = null,
        ?string $recipientType = null,
        int $delaySeconds = 0,
        string $provider = 'whatsapp_cloud'
    ): int {
        if ($schoolId <= 0) {
            throw new InvalidArgumentException('Valid tenant school context is required.');
        }

        $recipientClean = trim($recipient);
        if ($recipientClean === '') {
            throw new InvalidArgumentException('Recipient contact cannot be empty.');
        }

        $availableAt = date('Y-m-d H:i:s', time() + max(0, $delaySeconds));
        $payloadJson = json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);

        return Database::insert(
            'INSERT INTO message_queues (
                school_id, channel, provider, recipient, recipient_name, recipient_id, recipient_type,
                message_type, subject, payload, priority, status, attempts, max_attempts, available_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending", 0, 3, ?)',
            [
                $schoolId,
                $channel,
                $provider,
                $recipientClean,
                $recipientName,
                $recipientId,
                $recipientType,
                $messageType,
                $subject,
                $payloadJson,
                $priority,
                $availableAt
            ]
        );
    }

    /**
     * Efficiently enqueue a batch of messages in a single multi-row SQL INSERT transaction.
     * Perfect for mass homework diary broadcasts or fee reminder runs.
     *
     * @param int $schoolId Tenant ID
     * @param array<int, array{
     *   channel: string,
     *   recipient: string,
     *   payload: array,
     *   message_type?: string,
     *   priority?: int,
     *   subject?: string,
     *   recipient_name?: string,
     *   recipient_id?: int,
     *   recipient_type?: string,
     *   provider?: string
     * }> $messages
     * @return int Count of messages successfully enqueued
     */
    public function enqueueBatch(int $schoolId, array $messages): int
    {
        if ($schoolId <= 0 || empty($messages)) {
            return 0;
        }

        $now = date('Y-m-d H:i:s');
        $chunks = array_chunk($messages, 200);
        $totalEnqueued = 0;

        foreach ($chunks as $chunk) {
            $placeholders = [];
            $params = [];

            foreach ($chunk as $msg) {
                $recipient = trim((string) ($msg['recipient'] ?? ''));
                if ($recipient === '') {
                    continue;
                }

                $placeholders[] = '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending", 0, 3, ?)';
                $params[] = $schoolId;
                $params[] = $msg['channel'] ?? 'whatsapp';
                $params[] = $msg['provider'] ?? 'whatsapp_cloud';
                $params[] = $recipient;
                $params[] = $msg['recipient_name'] ?? null;
                $params[] = $msg['recipient_id'] ?? null;
                $params[] = $msg['recipient_type'] ?? null;
                $params[] = $msg['message_type'] ?? 'general';
                $params[] = $msg['subject'] ?? null;
                $params[] = json_encode($msg['payload'] ?? [], JSON_UNESCAPED_UNICODE);
                $params[] = (int) ($msg['priority'] ?? self::PRIORITY_NORMAL);
                $params[] = $now;
                $totalEnqueued++;
            }

            if (!empty($placeholders)) {
                $sql = 'INSERT INTO message_queues (
                    school_id, channel, provider, recipient, recipient_name, recipient_id, recipient_type,
                    message_type, subject, payload, priority, status, attempts, max_attempts, available_at
                ) VALUES ' . implode(', ', $placeholders);

                Database::execute($sql, $params);
            }
        }

        return $totalEnqueued;
    }

    /**
     * Get real-time queue health metrics and telemetry.
     */
    public function getQueueStats(?int $schoolId = null): array
    {
        $sql = 'SELECT status, COUNT(*) AS cnt, MIN(created_at) AS oldest 
                FROM message_queues';
        $params = [];

        if ($schoolId !== null && $schoolId > 0) {
            $sql .= ' WHERE school_id = ?';
            $params[] = $schoolId;
        }

        $sql .= ' GROUP BY status';
        $rows = Database::fetchAll($sql, $params);

        $stats = [
            'pending' => 0,
            'processing' => 0,
            'sent' => 0,
            'failed' => 0,
            'total' => 0,
        ];

        foreach ($rows as $r) {
            $st = (string) $r['status'];
            $cnt = (int) $r['cnt'];
            if (isset($stats[$st])) {
                $stats[$st] = $cnt;
            }
            $stats['total'] += $cnt;
        }

        return $stats;
    }
}
