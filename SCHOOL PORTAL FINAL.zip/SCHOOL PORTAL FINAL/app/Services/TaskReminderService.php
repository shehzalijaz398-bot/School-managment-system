<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;
use InvalidArgumentException;
use Throwable;

/**
 * TaskReminderService
 *
 * Provides high-level task management, productivity reminders, and workflow delegation:
 * - Staff task creation and status tracking
 * - Due date notifications and automated deadline warnings
 * - Dashboard integration for pending, overdue, and completed action items
 */
final class TaskReminderService
{
    private HrService $hrService;

    public function __construct()
    {
        $this->hrService = new HrService();
    }

    /**
     * Get tasks assigned to a specific user (or employee linked to user).
     *
     * @param int $schoolId School tenant ID
     * @param int $userId Authenticated user ID
     * @param array $filters Optional filters (status, priority, limit)
     * @return array List of task records
     */
    public function getUserTasks(int $schoolId, int $userId, array $filters = []): array
    {
        // Resolve employee ID for this user if available
        $user = Database::fetch("SELECT id, employee_id FROM users WHERE id = ? AND school_id = ? LIMIT 1", [$userId, $schoolId]);
        $employeeId = (int)($user['employee_id'] ?? 0);

        $sql = "
            SELECT t.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS assignee_name,
                   u.name AS assigner_name,
                   DATEDIFF(t.due_date, CURDATE()) AS days_remaining
            FROM staff_tasks t
            LEFT JOIN employees e ON e.id = t.assigned_to
            LEFT JOIN users u ON u.id = t.assigned_by
            WHERE t.school_id = ?
        ";
        $params = [$schoolId];

        if ($employeeId > 0) {
            $sql .= " AND (t.assigned_to = ? OR t.assigned_by = ?)";
            $params[] = $employeeId;
            $params[] = $userId;
        } else {
            $sql .= " AND t.assigned_by = ?";
            $params[] = $userId;
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND t.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['priority']) && $filters['priority'] !== 'all') {
            $sql .= " AND t.priority = ?";
            $params[] = $filters['priority'];
        }

        $sql .= " ORDER BY CASE WHEN t.status = 'pending' THEN 1 WHEN t.status = 'in_progress' THEN 2 ELSE 3 END, t.due_date ASC";

        if (!empty($filters['limit'])) {
            $sql .= " LIMIT " . (int)$filters['limit'];
        }

        return Database::fetchAll($sql, $params);
    }

    /**
     * Create a new staff task.
     *
     * @param int $schoolId School tenant ID
     * @param int $assignedByUserId Assigner user ID
     * @param array $data Task details
     * @return int Created task ID
     */
    public function createTask(int $schoolId, int $assignedByUserId, array $data): int
    {
        return $this->hrService->createStaffTask($schoolId, $data, $assignedByUserId);
    }

    /**
     * Toggle or update staff task status.
     *
     * @param int $schoolId School tenant ID
     * @param int $taskId Task ID
     * @param string|null $newStatus Optional explicit status ('completed', 'pending', etc.)
     * @return array Updated task status
     */
    public function toggleTaskStatus(int $schoolId, int $taskId, ?string $newStatus = null): array
    {
        $task = Database::fetch("SELECT * FROM staff_tasks WHERE id = ? AND school_id = ? LIMIT 1", [$taskId, $schoolId]);
        if (!$task) {
            throw new InvalidArgumentException("Task not found or access denied.");
        }

        if ($newStatus === null) {
            $newStatus = ($task['status'] === 'completed') ? 'pending' : 'completed';
        }

        $this->hrService->updateStaffTaskStatus($schoolId, $taskId, $newStatus);

        return [
            'success' => true,
            'task_id' => $taskId,
            'status' => $newStatus,
            'completed' => $newStatus === 'completed',
        ];
    }

    /**
     * Get summary counts of tasks for a school dashboard.
     */
    public function getTaskSummary(int $schoolId, ?int $userId = null): array
    {
        $sql = "
            SELECT 
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN status != 'completed' AND due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue,
                SUM(CASE WHEN status != 'completed' AND due_date = CURDATE() THEN 1 ELSE 0 END) AS due_today
            FROM staff_tasks
            WHERE school_id = ?
        ";
        $params = [$schoolId];

        if ($userId !== null) {
            $user = Database::fetch("SELECT employee_id FROM users WHERE id = ? AND school_id = ? LIMIT 1", [$userId, $schoolId]);
            $employeeId = (int)($user['employee_id'] ?? 0);
            if ($employeeId > 0) {
                $sql .= " AND (assigned_to = ? OR assigned_by = ?)";
                $params[] = $employeeId;
                $params[] = $userId;
            } else {
                $sql .= " AND assigned_by = ?";
                $params[] = $userId;
            }
        }

        $res = Database::fetch($sql, $params);
        return [
            'total' => (int)($res['total'] ?? 0),
            'pending' => (int)($res['pending'] ?? 0),
            'in_progress' => (int)($res['in_progress'] ?? 0),
            'completed' => (int)($res['completed'] ?? 0),
            'overdue' => (int)($res['overdue'] ?? 0),
            'due_today' => (int)($res['due_today'] ?? 0),
        ];
    }
}
