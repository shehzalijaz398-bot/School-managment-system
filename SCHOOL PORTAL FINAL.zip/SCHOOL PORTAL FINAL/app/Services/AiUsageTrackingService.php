<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;
use Throwable;

/**
 * AiUsageTrackingService
 *
 * Manages schema provisioning, AI token and request telemetry, tenant quotas,
 * response caching, and cost accounting.
 */
final class AiUsageTrackingService
{
    private static bool $schemaEnsured = false;

    public function __construct()
    {
        $this->ensureAiSchema();
    }

    /**
     * Idempotently provision all AI tables.
     */
    public function ensureAiSchema(): void
    {
        if (self::$schemaEnsured) {
            return;
        }

        try {
            // 1. AI Usage Logs
            Database::execute('CREATE TABLE IF NOT EXISTS ai_usage_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
                user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
                provider VARCHAR(50) NOT NULL DEFAULT "gemini",
                model VARCHAR(100) NOT NULL DEFAULT "gemini-1.5-flash",
                prompt_tokens INT UNSIGNED NOT NULL DEFAULT 0,
                completion_tokens INT UNSIGNED NOT NULL DEFAULT 0,
                total_tokens INT UNSIGNED NOT NULL DEFAULT 0,
                estimated_cost_usd DECIMAL(10,6) NOT NULL DEFAULT 0.000000,
                latency_ms DECIMAL(8,2) NOT NULL DEFAULT 0.00,
                status ENUM("success", "rate_limited", "blocked", "fallback", "failed") NOT NULL DEFAULT "success",
                query_intent VARCHAR(100) NULL,
                ip_address VARCHAR(45) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_school_date (school_id, created_at),
                INDEX idx_user_date (user_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

            // 2. Tenant AI Settings & Quotas
            Database::execute('CREATE TABLE IF NOT EXISTS ai_tenant_settings (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL UNIQUE,
                monthly_token_quota INT UNSIGNED NOT NULL DEFAULT 500000,
                current_month_tokens INT UNSIGNED NOT NULL DEFAULT 0,
                daily_request_limit INT UNSIGNED NOT NULL DEFAULT 200,
                data_retention_days INT UNSIGNED NOT NULL DEFAULT 30,
                pii_redaction_enabled TINYINT(1) NOT NULL DEFAULT 1,
                caching_enabled TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

            // 3. Smart Insights & Predictive Flags
            Database::execute('CREATE TABLE IF NOT EXISTS ai_smart_insights (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                category ENUM("attendance_risk", "fee_overdue", "timetable_clash", "grading_missing", "operational_bottleneck") NOT NULL,
                severity ENUM("info", "warning", "critical") NOT NULL DEFAULT "info",
                title VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                metric_payload JSON NULL,
                is_predictive TINYINT(1) NOT NULL DEFAULT 0,
                confidence_score DECIMAL(5,2) NULL,
                disclaimer TEXT NULL,
                status ENUM("active", "resolved", "dismissed") NOT NULL DEFAULT "active",
                detected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_school_status_cat (school_id, status, category)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

            // 4. Response Caching
            Database::execute('CREATE TABLE IF NOT EXISTS ai_response_cache (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                cache_key VARCHAR(64) NOT NULL,
                query_hash VARCHAR(64) NOT NULL,
                prompt_intent VARCHAR(100) NULL,
                response_content MEDIUMTEXT NOT NULL,
                tokens_used INT UNSIGNED NOT NULL DEFAULT 0,
                expires_at DATETIME NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_school_cache (school_id, cache_key),
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

            // 5. Conversation History & Retention
            Database::execute('CREATE TABLE IF NOT EXISTS ai_conversations (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                user_id BIGINT UNSIGNED NOT NULL,
                role VARCHAR(50) NOT NULL,
                session_key VARCHAR(100) NOT NULL,
                messages JSON NOT NULL,
                last_active_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_school_user (school_id, user_id),
                INDEX idx_last_active (last_active_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

            self::$schemaEnsured = true;
        } catch (Throwable $e) {
            StructuredLogger::error('Failed to ensure AI schema', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Get or create tenant settings record.
     */
    public function getTenantSettings(int $schoolId): array
    {
        $this->ensureAiSchema();

        $settings = Database::fetch('SELECT * FROM ai_tenant_settings WHERE school_id = ? LIMIT 1', [$schoolId]);
        if (!$settings) {
            Database::execute(
                'INSERT INTO ai_tenant_settings (school_id, monthly_token_quota, current_month_tokens, daily_request_limit, data_retention_days, pii_redaction_enabled, caching_enabled)
                 VALUES (?, 500000, 0, 200, 30, 1, 1)',
                [$schoolId]
            );
            $settings = Database::fetch('SELECT * FROM ai_tenant_settings WHERE school_id = ? LIMIT 1', [$schoolId]);
        }

        return $settings ?: [
            'school_id' => $schoolId,
            'monthly_token_quota' => 500000,
            'current_month_tokens' => 0,
            'daily_request_limit' => 200,
            'data_retention_days' => 30,
            'pii_redaction_enabled' => 1,
            'caching_enabled' => 1,
        ];
    }

    /**
     * Check if tenant is within quota limits.
     *
     * @param int $schoolId
     * @return array{allowed: bool, reason: string|null, quota_used_pct: float}
     */
    public function checkQuota(int $schoolId): array
    {
        if ($schoolId === 0) {
            return ['allowed' => true, 'reason' => null, 'quota_used_pct' => 0.0];
        }

        $settings = $this->getTenantSettings($schoolId);
        $monthlyQuota = (int) ($settings['monthly_token_quota'] ?? 500000);

        // Calculate actual current month tokens from logs
        $monthStart = date('Y-m-01 00:00:00');
        $row = Database::fetch(
            'SELECT COALESCE(SUM(total_tokens), 0) AS used_tokens,
                    COUNT(*) AS total_requests
             FROM ai_usage_logs
             WHERE school_id = ? AND created_at >= ?',
            [$schoolId, $monthStart]
        );

        $usedTokens = (int) ($row['used_tokens'] ?? 0);
        $pct = $monthlyQuota > 0 ? round(($usedTokens / $monthlyQuota) * 100, 2) : 0.0;

        if ($monthlyQuota > 0 && $usedTokens >= $monthlyQuota) {
            return [
                'allowed' => false,
                'reason' => "Monthly AI token budget of " . number_format($monthlyQuota) . " tokens reached for this institution.",
                'quota_used_pct' => $pct,
            ];
        }

        // Daily limit check
        $todayStart = date('Y-m-d 00:00:00');
        $dailyRequests = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM ai_usage_logs WHERE school_id = ? AND created_at >= ?',
            [$schoolId, $todayStart]
        );

        $dailyLimit = (int) ($settings['daily_request_limit'] ?? 200);
        if ($dailyLimit > 0 && $dailyRequests >= $dailyLimit) {
            return [
                'allowed' => false,
                'reason' => "Daily AI request threshold (" . number_format($dailyLimit) . " requests) exceeded. Resets at midnight.",
                'quota_used_pct' => $pct,
            ];
        }

        return [
            'allowed' => true,
            'reason' => null,
            'quota_used_pct' => $pct,
        ];
    }

    /**
     * Log an AI transaction into ai_usage_logs.
     */
    public function logUsage(
        int $schoolId,
        int $userId,
        string $provider,
        string $model,
        int $promptTokens,
        int $completionTokens,
        float $latencyMs,
        string $status = 'success',
        ?string $queryIntent = null,
        ?string $ipAddress = null
    ): void {
        $this->ensureAiSchema();

        $totalTokens = $promptTokens + $completionTokens;

        // Pricing estimate: $0.15 per million tokens for Gemini Flash / GPT-4o-mini
        $costPerToken = 0.00000015;
        $cost = round($totalTokens * $costPerToken, 6);

        try {
            Database::execute(
                'INSERT INTO ai_usage_logs (school_id, user_id, provider, model, prompt_tokens, completion_tokens, total_tokens, estimated_cost_usd, latency_ms, status, query_intent, ip_address)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $schoolId,
                    $userId,
                    $provider,
                    $model,
                    $promptTokens,
                    $completionTokens,
                    $totalTokens,
                    $cost,
                    $latencyMs,
                    $status,
                    $queryIntent,
                    $ipAddress ?: ($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'),
                ]
            );

            // Update current_month_tokens on settings
            if ($schoolId > 0 && $totalTokens > 0) {
                Database::execute(
                    'UPDATE ai_tenant_settings SET current_month_tokens = current_month_tokens + ? WHERE school_id = ?',
                    [$totalTokens, $schoolId]
                );
            }
        } catch (Throwable $e) {
            StructuredLogger::warning('Failed to log AI usage', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Retrieve cached response if active and unexpired.
     */
    public function getCachedResponse(int $schoolId, string $query, string $intent): ?string
    {
        $this->ensureAiSchema();

        $cacheKey = hash('sha256', $schoolId . ':' . strtolower(trim($query)) . ':' . $intent);
        $cached = Database::fetch(
            'SELECT response_content FROM ai_response_cache 
             WHERE school_id = ? AND cache_key = ? AND expires_at > NOW() LIMIT 1',
            [$schoolId, $cacheKey]
        );

        return $cached ? (string) $cached['response_content'] : null;
    }

    /**
     * Cache a response for future identical queries.
     */
    public function storeCachedResponse(int $schoolId, string $query, string $intent, string $content, int $ttlSeconds = 3600): void
    {
        $this->ensureAiSchema();

        $cacheKey = hash('sha256', $schoolId . ':' . strtolower(trim($query)) . ':' . $intent);
        $queryHash = hash('sha256', $query);
        $expiresAt = date('Y-m-d H:i:s', time() + $ttlSeconds);
        $tokens = (int) ceil(strlen($content) / 4);

        try {
            Database::execute(
                'INSERT INTO ai_response_cache (school_id, cache_key, query_hash, prompt_intent, response_content, tokens_used, expires_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE response_content = VALUES(response_content), expires_at = VALUES(expires_at), tokens_used = VALUES(tokens_used)',
                [$schoolId, $cacheKey, $queryHash, $intent, $content, $tokens, $expiresAt]
            );
        } catch (Throwable $e) {
            StructuredLogger::warning('Failed to store cached AI response', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Get aggregate telemetry metrics for an institution or platform.
     */
    public function getTelemetry(int $schoolId = 0): array
    {
        $this->ensureAiSchema();

        $where = $schoolId > 0 ? 'WHERE school_id = ?' : '';
        $params = $schoolId > 0 ? [$schoolId] : [];

        $stats = Database::fetch("
            SELECT COUNT(*) AS total_requests,
                   COALESCE(SUM(total_tokens), 0) AS total_tokens,
                   COALESCE(SUM(estimated_cost_usd), 0.000000) AS total_cost_usd,
                   COALESCE(AVG(latency_ms), 0.0) AS avg_latency_ms,
                   SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS success_count,
                   SUM(CASE WHEN status = 'fallback' THEN 1 ELSE 0 END) AS fallback_count,
                   SUM(CASE WHEN status = 'rate_limited' THEN 1 ELSE 0 END) AS rate_limited_count,
                   SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) AS blocked_count
            FROM ai_usage_logs {$where}
        ", $params) ?: [];

        $settings = $schoolId > 0 ? $this->getTenantSettings($schoolId) : [];

        return [
            'total_requests' => (int) ($stats['total_requests'] ?? 0),
            'total_tokens' => (int) ($stats['total_tokens'] ?? 0),
            'total_cost_usd' => (float) ($stats['total_cost_usd'] ?? 0.0),
            'avg_latency_ms' => round((float) ($stats['avg_latency_ms'] ?? 0.0), 1),
            'success_count' => (int) ($stats['success_count'] ?? 0),
            'fallback_count' => (int) ($stats['fallback_count'] ?? 0),
            'rate_limited_count' => (int) ($stats['rate_limited_count'] ?? 0),
            'blocked_count' => (int) ($stats['blocked_count'] ?? 0),
            'tenant_settings' => $settings,
        ];
    }
}
