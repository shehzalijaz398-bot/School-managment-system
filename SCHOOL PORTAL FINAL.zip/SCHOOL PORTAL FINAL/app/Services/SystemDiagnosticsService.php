<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;
use Core\Queue\DatabaseQueue;
use Throwable;

/**
 * SystemDiagnosticsService
 *
 * Enterprise health diagnostics, sanitized error logging, integration failure
 * tracking, orphaned record detection, and safe background task recovery.
 */
final class SystemDiagnosticsService
{
    private string $logPath;

    public function __construct(?string $logPath = null)
    {
        $this->logPath = $logPath ?? (dirname(__DIR__, 2) . '/storage/logs/system_errors.log');
    }

    /**
     * Sanitize sensitive credentials, API keys, passwords, and tokens from exception traces.
     */
    public function sanitizeException(Throwable $e): array
    {
        $msg = $e->getMessage();
        $trace = $e->getTraceAsString();

        $patterns = [
            '/(password|pwd|pass|secret|token|api_key|access_token|key|auth)\s*[:=]\s*["\']?[^"\'\s,;]+["\']?/i' => '$1: [REDACTED]',
            '/mysql:host=[^;]+;port=\d+;dbname=[^;]+;charset=[^;]+/i' => 'mysql:host=[HOST];port=[PORT];dbname=[DB]',
            '/bearer\s+[a-zA-Z0-9_\-\.]+/i' => 'Bearer [REDACTED_TOKEN]',
            '/sk-[a-zA-Z0-9]{20,}/' => 'sk-[REDACTED_API_KEY]',
            '/AIzaSy[a-zA-Z0-9_-]{33}/' => 'AIzaSy[REDACTED_API_KEY]',
        ];

        foreach ($patterns as $pattern => $replacement) {
            $msg = preg_replace($pattern, $replacement, $msg);
            $trace = preg_replace($pattern, $replacement, $trace);
        }

        return [
            'class' => get_class($e),
            'message' => $msg,
            'file' => basename($e->getFile()),
            'line' => $e->getLine(),
            'sanitized_trace' => $trace,
        ];
    }

    /**
     * Log structured error entry to persistent log file without exposing raw credentials or PII.
     */
    public function logStructuredError(Throwable $e, array $context = []): void
    {
        $sanitized = $this->sanitizeException($e);

        // Sanitize context array
        $cleanContext = [];
        $sensitiveKeys = ['password', 'secret', 'token', 'api_key', 'authorization', 'card_number', 'ssn'];
        foreach ($context as $k => $v) {
            $kLower = strtolower((string)$k);
            $isSensitive = false;
            foreach ($sensitiveKeys as $sk) {
                if (str_contains($kLower, $sk)) {
                    $isSensitive = true;
                    break;
                }
            }
            $cleanContext[$k] = $isSensitive ? '[REDACTED]' : (is_scalar($v) ? $v : json_encode($v));
        }

        $entry = [
            'timestamp' => date('c'),
            'tenant_id' => Auth::schoolId() ?? 0,
            'user_id' => Auth::id() ?? 0,
            'request_uri' => $_SERVER['REQUEST_URI'] ?? 'CLI',
            'http_method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI',
            'error_class' => $sanitized['class'],
            'message' => $sanitized['message'],
            'file' => $sanitized['file'],
            'line' => $sanitized['line'],
            'context' => $cleanContext,
        ];

        $logDir = dirname($this->logPath);
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        @file_put_contents(
            $this->logPath,
            json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n",
            FILE_APPEND | LOCK_EX
        );
    }

    /**
     * Perform comprehensive institutional health check and diagnostic audit.
     *
     * @param int $schoolId Current tenant ID
     * @return array Health metrics, orphan counts, queue status, and reconciliation checks.
     */
    public function runDiagnosticHealthAudit(int $schoolId): array
    {
        $startTime = microtime(true);
        $dbStatus = 'healthy';
        $dbLatencyMs = 0.0;

        try {
            $dbCheck = Database::fetch('SELECT 1 as alive');
            $dbLatencyMs = round((microtime(true) - $startTime) * 1000, 2);
            if (!$dbCheck || (int)$dbCheck['alive'] !== 1) {
                $dbStatus = 'degraded';
            }
        } catch (\Throwable $e) {
            $dbStatus = 'unreachable';
        }

        // 1. Queue Health & Failed Jobs
        $queueEngine = new DatabaseQueue();
        $pendingJobs = $queueEngine->count('default');
        $failedJobsCount = (int) (Database::fetch('SELECT COUNT(*) as c FROM platform_failed_jobs')['c'] ?? 0);

        // 2. Storage Directory Write Permissions
        $baseDir = dirname(__DIR__, 2);
        $storagePaths = [
            'storage/logs' => is_writable($baseDir . '/storage/logs'),
            'storage/documents' => is_writable($baseDir . '/storage/documents'),
            'storage/backups' => is_writable($baseDir . '/storage/backups'),
        ];

        // 3. Data Integrity & Orphaned Records Audit
        // Check A: Students assigned to non-existent classes
        $orphanedStudents = (int) (Database::fetch(
            'SELECT COUNT(*) as c FROM students s 
             LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
             WHERE s.school_id = ? AND s.class_id IS NOT NULL AND c.id IS NULL',
            [$schoolId]
        )['c'] ?? 0);

        // Check B: Fee invoices with non-existent student reference
        $orphanedInvoices = (int) (Database::fetch(
            'SELECT COUNT(*) as c FROM student_fee_invoices i 
             LEFT JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
             WHERE i.school_id = ? AND s.id IS NULL',
            [$schoolId]
        )['c'] ?? 0);

        // Check C: Payments with non-existent invoice reference
        $orphanedPayments = (int) (Database::fetch(
            'SELECT COUNT(*) as c FROM payments p 
             LEFT JOIN student_fee_invoices i ON i.id = p.invoice_id AND i.school_id = p.school_id
             WHERE p.school_id = ? AND i.id IS NULL',
            [$schoolId]
        )['c'] ?? 0);

        // 4. Financial Reconciliation Discrepancy Check
        // Compares invoice paid_amount with sum of actual payments minus refunds
        $discrepancyCount = (int) (Database::fetch(
            'SELECT COUNT(*) as c FROM (
                SELECT i.id, i.paid_amount,
                       COALESCE(SUM(p.amount), 0) - COALESCE(SUM(rt.amount), 0) AS calculated_paid
                FROM student_fee_invoices i
                LEFT JOIN payments p ON p.invoice_id = i.id AND p.school_id = i.school_id AND p.status != "cancelled"
                LEFT JOIN refund_transactions rt ON rt.invoice_id = i.id AND rt.school_id = i.school_id
                WHERE i.school_id = ?
                GROUP BY i.id, i.paid_amount
                HAVING ABS(i.paid_amount - calculated_paid) > 0.01
             ) as disc',
            [$schoolId]
        )['c'] ?? 0);

        $overallStatus = ($dbStatus === 'healthy' && $orphanedStudents === 0 && $orphanedInvoices === 0 && $discrepancyCount === 0)
            ? 'optimal'
            : 'attention_required';

        return [
            'status' => $overallStatus,
            'timestamp' => date('Y-m-d H:i:s'),
            'school_id' => $schoolId,
            'database' => [
                'status' => $dbStatus,
                'latency_ms' => $dbLatencyMs,
            ],
            'queue' => [
                'pending_jobs' => $pendingJobs,
                'failed_jobs' => $failedJobsCount,
                'status' => $failedJobsCount > 0 ? 'jobs_failing' : 'nominal',
            ],
            'storage_permissions' => $storagePaths,
            'integrity_checks' => [
                'orphaned_students' => $orphanedStudents,
                'orphaned_invoices' => $orphanedInvoices,
                'orphaned_payments' => $orphanedPayments,
                'financial_reconciliation_discrepancies' => $discrepancyCount,
            ],
        ];
    }
}
