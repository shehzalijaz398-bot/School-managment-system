<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Exam;
use Core\Auth;
use Core\Database;
use Core\TenantGuard;

final class ExamService
{
    private Exam $examModel;

    public function __construct()
    {
        $this->examModel = new Exam();
    }

    /**
     * Create a new exam entry with tenant boundary enforcement.
     *
     * @param array<string, mixed> $data
     * @return int
     */
    public function createExam(array $data): int
    {
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            throw new \RuntimeException('Invalid tenant context for exam creation.');
        }

        $classId = (int) ($data['class_id'] ?? 0);
        TenantGuard::enforce('classes', $classId, $schoolId);

        $typeId = !empty($data['exam_type_id']) ? (int) $data['exam_type_id'] : null;
        if ($typeId) {
            $typeExists = Database::fetch('SELECT id FROM exam_types WHERE id = ? AND school_id = ?', [$typeId, $schoolId]);
            if (!$typeExists) {
                $typeId = null;
            }
        }

        if (!$typeId) {
            $firstType = Database::fetch('SELECT id FROM exam_types WHERE school_id = ? LIMIT 1', [$schoolId]);
            if ($firstType) {
                $typeId = (int) $firstType['id'];
            } else {
                $typeId = Database::insert(
                    'INSERT INTO exam_types (school_id, name, created_at) VALUES (?, ?, NOW())',
                    [$schoolId, 'General Assessment']
                );
            }
        }

        $academicYearId = (int) ($data['academic_year_id'] ?? activeAcademicYearId());
        $name = trim((string) ($data['name'] ?? 'Exam'));

        $id = Database::insert(
            'INSERT INTO exams 
            (school_id, exam_type_id, academic_year_id, class_id, name, start_date, end_date, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $schoolId,
                $typeId,
                $academicYearId,
                $classId,
                $name,
                !empty($data['start_date']) ? $data['start_date'] : null,
                !empty($data['end_date']) ? $data['end_date'] : null,
                $data['status'] ?? 'scheduled',
            ]
        );

        auditLog('exam.create', 'exams', 'exams', $id, null, ['name' => $name, 'class_id' => $classId]);
        return $id;
    }

    /**
     * Update an existing exam record.
     *
     * @param int $id
     * @param array<string, mixed> $data
     * @return bool
     */
    public function updateExam(int $id, array $data): bool
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $id, $schoolId);

        $existing = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$id, $schoolId]);
        if (!$existing) {
            throw new \RuntimeException('Exam record not found.');
        }

        $classId = (int) ($data['class_id'] ?? $existing['class_id']);
        TenantGuard::enforce('classes', $classId, $schoolId);

        if ($classId !== (int) $existing['class_id'] && $this->examModel->hasRecordedMarks($id)) {
            throw new \RuntimeException('Cannot change exam class because student marks have already been recorded.');
        }

        $typeId = (int) ($data['exam_type_id'] ?? $existing['exam_type_id']);
        $typeExists = Database::fetch('SELECT id FROM exam_types WHERE id = ? AND school_id = ?', [$typeId, $schoolId]);
        if (!$typeExists) {
            throw new \RuntimeException('Invalid exam type specified.');
        }

        Database::execute(
            'UPDATE exams 
             SET exam_type_id = ?, class_id = ?, name = ?, start_date = ?, end_date = ?, status = ?, updated_at = NOW()
             WHERE id = ? AND school_id = ?',
            [
                $typeId,
                $classId,
                trim((string) $data['name']),
                !empty($data['start_date']) ? $data['start_date'] : null,
                !empty($data['end_date']) ? $data['end_date'] : null,
                $data['status'] ?? $existing['status'],
                $id,
                $schoolId,
            ]
        );

        auditLog('exam.update', 'exams', 'exams', $id, $existing, $data);
        return true;
    }

    /**
     * Delete an exam if no student marks are recorded.
     *
     * @param int $id
     * @return bool
     */
    public function deleteExam(int $id): bool
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $id, $schoolId);

        if ($this->examModel->hasRecordedMarks($id)) {
            throw new \RuntimeException('Cannot delete exam because marks have already been entered.');
        }

        return Database::transaction(function () use ($id, $schoolId): bool {
            $exam = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$id, $schoolId]);
            if (!$exam) {
                return false;
            }

            Database::execute('DELETE FROM exam_subjects WHERE exam_id = ? AND school_id = ?', [$id, $schoolId]);
            Database::execute('DELETE FROM exam_results_snapshot WHERE exam_id = ? AND school_id = ?', [$id, $schoolId]);
            Database::execute('DELETE FROM exams WHERE id = ? AND school_id = ?', [$id, $schoolId]);

            auditLog('exam.delete', 'exams', 'exams', $id, $exam, null);
            return true;
        });
    }

    /**
     * Save/update subject schedule for an exam.
     *
     * @param int $examId
     * @param array<int, array<string, mixed>> $timetableEntries
     * @return void
     */
    public function saveTimetable(int $examId, array $timetableEntries): void
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);

        Database::transaction(function () use ($examId, $schoolId, $timetableEntries): void {
            // Remove existing subjects that have no entered marks
            foreach ($timetableEntries as $entry) {
                $subjectId = (int) ($entry['subject_id'] ?? 0);
                if ($subjectId <= 0) {
                    continue;
                }

                TenantGuard::enforce('subjects', $subjectId, $schoolId);

                $examDate = !empty($entry['exam_date']) ? $entry['exam_date'] : null;
                $maxMarks = max(1.0, (float) ($entry['max_marks'] ?? 100));
                $passMarks = max(0.0, (float) ($entry['pass_marks'] ?? 33));

                $existing = Database::fetch(
                    'SELECT id FROM exam_subjects WHERE exam_id = ? AND subject_id = ? AND school_id = ?',
                    [$examId, $subjectId, $schoolId]
                );

                if ($existing) {
                    Database::execute(
                        'UPDATE exam_subjects 
                         SET exam_date = ?, max_marks = ?, pass_marks = ?
                         WHERE id = ? AND school_id = ?',
                        [$examDate, $maxMarks, $passMarks, (int) $existing['id'], $schoolId]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO exam_subjects (school_id, exam_id, subject_id, exam_date, max_marks, pass_marks, created_at)
                         VALUES (?, ?, ?, ?, ?, ?, NOW())',
                        [$schoolId, $examId, $subjectId, $examDate, $maxMarks, $passMarks]
                    );
                }
            }

            auditLog('exam.timetable_save', 'exams', 'exam_subjects', $examId);
        });
    }

    /**
     * Record student marks for an exam subject.
     *
     * @param int $examSubjectId
     * @param array<string|int, mixed> $marks Array mapping student_id to marks obtained
     * @param int $enteredBy User ID
     * @return void
     */
    public function saveMarks(int $examSubjectId, array $marks, int $enteredBy): void
    {
        $schoolId = (int) Auth::schoolId();
        $es = Database::fetch(
            'SELECT * FROM exam_subjects WHERE id = ? AND school_id = ? LIMIT 1',
            [$examSubjectId, $schoolId]
        );
        if (!$es) {
            throw new \RuntimeException('Exam subject not found.');
        }

        Database::transaction(function () use ($schoolId, $es, $examSubjectId, $marks, $enteredBy): void {
            $max = (float) $es['max_marks'];

            foreach ($marks as $studentId => $value) {
                $studentId = (int) $studentId;
                if ($value === '' || $value === null) {
                    continue;
                }

                if (!is_numeric($value)) {
                    throw new \InvalidArgumentException("Invalid marks value for student #{$studentId}. Numeric value expected.");
                }

                TenantGuard::enforce('students', $studentId, $schoolId);

                $obtained = (float) $value;
                if ($obtained < 0 || $obtained > $max) {
                    throw new \InvalidArgumentException("Marks ({$obtained}) out of range [0-{$max}] for student #{$studentId}");
                }

                $pct = $max > 0 ? ($obtained / $max) * 100 : 0.0;
                $grade = grade_from_percentage($pct, $schoolId);

                $existing = Database::fetch(
                    'SELECT id FROM exam_marks WHERE exam_subject_id = ? AND student_id = ? AND school_id = ? LIMIT 1',
                    [$examSubjectId, $studentId, $schoolId]
                );

                if ($existing) {
                    Database::execute(
                        'UPDATE exam_marks 
                         SET marks_obtained = ?, grade = ?, entered_by = ?, updated_at = NOW()
                         WHERE id = ? AND school_id = ?',
                        [$obtained, $grade, $enteredBy, (int) $existing['id'], $schoolId]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO exam_marks
                        (school_id, exam_id, exam_subject_id, student_id, marks_obtained, grade, entered_by, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                        [$schoolId, (int) $es['exam_id'], $examSubjectId, $studentId, $obtained, $grade, $enteredBy]
                    );
                }
            }

            auditLog('exam.marks_save', 'exams', 'exam_subjects', $examSubjectId, null, [
                'marks_count' => count($marks),
            ]);
        });
    }

    /**
     * Compute comprehensive student exam performance.
     *
     * @param int $examId
     * @param int $studentId
     * @return array<string, mixed>
     */
    public function studentResult(int $examId, int $studentId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);
        TenantGuard::enforce('students', $studentId, $schoolId);

        $rows = Database::fetchAll(
            'SELECT em.*, es.max_marks, es.pass_marks, s.name AS subject_name, s.code AS subject_code
             FROM exam_subjects es
             INNER JOIN subjects s ON s.id = es.subject_id AND s.school_id = es.school_id
             LEFT JOIN exam_marks em ON em.exam_subject_id = es.id AND em.student_id = ? AND em.school_id = es.school_id
             WHERE es.school_id = ? AND es.exam_id = ?
             ORDER BY es.exam_date ASC, s.name ASC',
            [$studentId, $schoolId, $examId]
        );

        $totalMax = 0.0;
        $totalObtained = 0.0;
        $passedAll = true;

        foreach ($rows as $r) {
            $maxMarks = (float) $r['max_marks'];
            $passMarks = (float) $r['pass_marks'];
            $obtained = (float) ($r['marks_obtained'] ?? 0.0);

            $totalMax += $maxMarks;
            $totalObtained += $obtained;

            if ($obtained < $passMarks) {
                $passedAll = false;
            }
        }

        $percentage = $totalMax > 0 ? round(($totalObtained / $totalMax) * 100, 2) : 0.0;
        $snapshot = $this->examModel->getStudentSnapshot($examId, $studentId);

        return [
            'subjects' => $rows,
            'total_max' => $totalMax,
            'total_obtained' => $totalObtained,
            'percentage' => $percentage,
            'grade' => grade_from_percentage($percentage, $schoolId),
            'passed' => $passedAll,
            'position' => $snapshot['class_position'] ?? null,
            'snapshot' => $snapshot,
        ];
    }

    /**
     * Calculate and snapshot class merit positions with standard competition ranking.
     *
     * @param int $examId
     * @param int $classId
     * @return array<int, array<string, mixed>>
     */
    public function calculateClassPositions(int $examId, int $classId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);
        TenantGuard::enforce('classes', $classId, $schoolId);

        $exam = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$examId, $schoolId]);
        if (!$exam) {
            throw new \RuntimeException('Exam not found.');
        }

        if ((int) $exam['class_id'] !== $classId) {
            throw new \InvalidArgumentException('The specified exam does not belong to the selected class.');
        }

        $students = Database::fetchAll(
            "SELECT id, section_id FROM students WHERE school_id = ? AND class_id = ? AND status = 'active'",
            [$schoolId, $classId]
        );

        if (empty($students)) {
            throw new \RuntimeException('No active students found in this class.');
        }

        $examSubjects = Database::fetchAll(
            'SELECT id, max_marks FROM exam_subjects WHERE school_id = ? AND exam_id = ?',
            [$schoolId, $examId]
        );

        if (empty($examSubjects)) {
            throw new \RuntimeException('Cannot calculate positions: No subjects configured for this exam.');
        }

        $subjectMaxMarks = [];
        $classMaxMarks = 0.0;
        foreach ($examSubjects as $es) {
            $maxM = (float) $es['max_marks'];
            $subjectMaxMarks[(int) $es['id']] = $maxM;
            $classMaxMarks += $maxM;
        }

        if ($classMaxMarks <= 0.0) {
            throw new \RuntimeException('Cannot calculate positions: Total maximum marks must be greater than zero.');
        }

        $marksData = Database::fetchAll(
            'SELECT m.student_id, m.exam_subject_id, m.marks_obtained
             FROM exam_marks m
             INNER JOIN students s ON s.id = m.student_id AND s.school_id = m.school_id
             WHERE m.school_id = ? AND m.exam_id = ? AND s.class_id = ?',
            [$schoolId, $examId, $classId]
        );

        $studentScores = [];
        foreach ($students as $st) {
            $studentScores[(int) $st['id']] = [
                'student_id' => (int) $st['id'],
                'section_id' => !empty($st['section_id']) ? (int) $st['section_id'] : null,
                'total_obtained' => 0.0,
                'total_max' => $classMaxMarks,
            ];
        }

        foreach ($marksData as $m) {
            $sId = (int) $m['student_id'];
            $obtained = (float) $m['marks_obtained'];

            if (isset($studentScores[$sId])) {
                $studentScores[$sId]['total_obtained'] += $obtained;
            }
        }

        $results = [];
        foreach ($studentScores as $sId => $data) {
            $max = $data['total_max'];
            $obtained = $data['total_obtained'];
            $percentage = $max > 0.0001 ? ($obtained / $max) * 100 : 0.0;

            $results[] = [
                'student_id' => $sId,
                'section_id' => $data['section_id'],
                'total_obtained' => round($obtained, 2),
                'total_max' => round($max, 2),
                'percentage' => round($percentage, 2),
            ];
        }

        // Sort descending by total marks obtained
        usort($results, function (array $a, array $b): int {
            return $b['total_obtained'] <=> $a['total_obtained'];
        });

        Database::transaction(function () use ($schoolId, $exam, $examId, $classId, &$results): void {
            Database::execute(
                'DELETE FROM exam_results_snapshot WHERE school_id = ? AND exam_id = ? AND class_id = ?',
                [$schoolId, $examId, $classId]
            );

            $currentRank = 1;
            $actualPosition = 1;
            $prevScore = -1.0;

            foreach ($results as $i => &$row) {
                if ($i > 0) {
                    if (abs($row['total_obtained'] - $prevScore) < 0.001) {
                        // Tie: same rank as previous
                    } else {
                        $currentRank = $actualPosition;
                    }
                }

                $row['class_position'] = $currentRank;

                Database::insert(
                    'INSERT INTO exam_results_snapshot 
                    (school_id, academic_year_id, exam_id, class_id, section_id, student_id, total_obtained_marks, total_max_marks, final_percentage, class_position, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "published", NOW(), NOW())',
                    [
                        $schoolId,
                        (int) $exam['academic_year_id'],
                        $examId,
                        $classId,
                        $row['section_id'],
                        $row['student_id'],
                        $row['total_obtained'],
                        $row['total_max'],
                        $row['percentage'],
                        $currentRank,
                    ]
                );

                $prevScore = (float) $row['total_obtained'];
                $actualPosition++;
            }
            unset($row);

            auditLog('exam.calculate_positions', 'exams', 'exam_results_snapshot', $examId, null, [
                'class_id' => $classId,
                'total_ranked' => count($results),
            ]);
        });

        return $results;
    }

    /**
     * Compile complete tabulation matrix for an entire class.
     *
     * @param int $examId
     * @param int $classId
     * @return array{subjects: array, students: array}
     */
    public function compileTabulationSheet(int $examId, int $classId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);
        TenantGuard::enforce('classes', $classId, $schoolId);

        $exam = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$examId, $schoolId]);
        if (!$exam) {
            throw new \RuntimeException('Exam not found.');
        }

        if ((int) $exam['class_id'] !== $classId) {
            throw new \InvalidArgumentException('The specified exam does not belong to the selected class.');
        }

        $subjects = Database::fetchAll(
            'SELECT es.*, s.name AS subject_name, s.code AS subject_code
             FROM exam_subjects es
             INNER JOIN subjects s ON s.id = es.subject_id AND s.school_id = es.school_id
             WHERE es.school_id = ? AND es.exam_id = ?
             ORDER BY es.exam_date ASC, s.name ASC',
            [$schoolId, $examId]
        );

        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.first_name, s.last_name, sec.name AS section_name,
                    snap.class_position, snap.total_obtained_marks, snap.final_percentage
             FROM students s
             LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
             LEFT JOIN exam_results_snapshot snap ON snap.student_id = s.id AND snap.exam_id = ? AND snap.school_id = s.school_id
             WHERE s.school_id = ? AND s.class_id = ? AND s.status = "active"
             ORDER BY COALESCE(snap.class_position, 9999) ASC, s.first_name ASC',
            [$examId, $schoolId, $classId]
        );

        $marksRows = Database::fetchAll(
            'SELECT em.student_id, em.exam_subject_id, em.marks_obtained, em.grade
             FROM exam_marks em
             WHERE em.school_id = ? AND em.exam_id = ?',
            [$schoolId, $examId]
        );

        $marksMap = [];
        foreach ($marksRows as $mr) {
            $marksMap[(int) $mr['student_id']][(int) $mr['exam_subject_id']] = $mr;
        }

        foreach ($students as &$stu) {
            $stu['marks'] = $marksMap[(int) $stu['id']] ?? [];
        }
        unset($stu);

        return [
            'subjects' => $subjects,
            'students' => $students,
        ];
    }

    /**
     * Publish exam results.
     */
    public function publish(int $examId): void
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);

        Database::execute(
            'UPDATE exams SET status = "published", updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$examId, $schoolId]
        );

        auditLog('exam.publish', 'exams', 'exams', $examId);
    }

    /**
     * Compile comprehensive factual academic insights for a student's exam performance.
     * Computes subject strengths, focus areas, GPA (4.0 scale), attendance correlation,
     * and a structured performance synthesis.
     *
     * @param int $examId
     * @param int $studentId
     * @return array<string, mixed>
     */
    public function compileAcademicInsights(int $examId, int $studentId): array
    {
        $schoolId = (int) Auth::schoolId();
        TenantGuard::enforce('exams', $examId, $schoolId);
        TenantGuard::enforce('students', $studentId, $schoolId);

        $exam = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$examId, $schoolId]);
        if (!$exam) {
            throw new \RuntimeException('Exam not found.');
        }

        $result = $this->studentResult($examId, $studentId);
        $subjects = $result['subjects'] ?? [];

        $strengths = [];
        $focusAreas = [];
        $gpaPoints = [];

        foreach ($subjects as $s) {
            $max = (float) ($s['max_marks'] ?? 100);
            $obtained = (float) ($s['marks_obtained'] ?? 0);
            $pct = $max > 0 ? round(($obtained / $max) * 100, 1) : 0.0;
            $name = (string) ($s['subject_name'] ?? 'Subject');

            // GPA on standard 4.0 scale
            if ($pct >= 85) {
                $point = 4.0;
            } elseif ($pct >= 75) {
                $point = 3.5;
            } elseif ($pct >= 65) {
                $point = 3.0;
            } elseif ($pct >= 55) {
                $point = 2.5;
            } elseif ($pct >= 50) {
                $point = 2.0;
            } elseif ($pct >= 40) {
                $point = 1.0;
            } else {
                $point = 0.0;
            }
            $gpaPoints[] = $point;

            $item = [
                'subject' => $name,
                'percentage' => $pct,
                'grade' => $s['grade'] ?? 'N/A',
                'obtained' => $obtained,
                'max' => $max,
            ];

            if ($pct >= 80) {
                $strengths[] = $item;
            } elseif ($pct < 60) {
                $focusAreas[] = $item;
            }
        }

        $gpa = count($gpaPoints) > 0 ? round(array_sum($gpaPoints) / count($gpaPoints), 2) : 0.0;

        // Attendance records correlation
        $attSummary = Database::fetchAll(
            'SELECT status, COUNT(*) as count FROM student_attendance WHERE school_id = ? AND student_id = ? GROUP BY status',
            [$schoolId, $studentId]
        );
        $totalDays = 0;
        $presentDays = 0;
        foreach ($attSummary as $att) {
            $c = (int) $att['count'];
            $totalDays += $c;
            if ($att['status'] === 'present' || $att['status'] === 'late') {
                $presentDays += $c;
            }
        }
        $attRate = $totalDays > 0 ? round(($presentDays / $totalDays) * 100, 1) : null;

        // Class benchmark & percentile
        $classId = (int) ($exam['class_id'] ?? 0);
        $rankRows = Database::fetchAll(
            'SELECT student_id, class_position, final_percentage FROM exam_results_snapshot WHERE school_id = ? AND exam_id = ? AND class_id = ? ORDER BY class_position ASC',
            [$schoolId, $examId, $classId]
        );
        $totalRanked = count($rankRows);
        $classPosition = $result['position'] ?? null;
        $percentile = null;
        if ($totalRanked > 0 && $classPosition) {
            $percentile = round((($totalRanked - (int) $classPosition + 1) / $totalRanked) * 100, 1);
        }

        // Deterministic synthesis commentary
        $comments = [];
        if (!empty($strengths)) {
            $sNames = implode(', ', array_map(fn($x) => $x['subject'], array_slice($strengths, 0, 3)));
            $comments[] = "Demonstrates strong subject mastery in {$sNames}.";
        }
        if (!empty($focusAreas)) {
            $fNames = implode(', ', array_map(fn($x) => $x['subject'], array_slice($focusAreas, 0, 3)));
            $comments[] = "Targeted academic remediation recommended in {$fNames}.";
        } else {
            $comments[] = "Consistent satisfactory marks across all evaluated disciplines.";
        }
        if ($attRate !== null) {
            if ($attRate >= 90) {
                $comments[] = "High attendance consistency ({$attRate}%) directly supports steady academic pacing.";
            } elseif ($attRate < 80) {
                $comments[] = "Attendance rate stands at {$attRate}%; improving classroom regularity will strengthen subject retention.";
            } else {
                $comments[] = "Attendance stands at {$attRate}%, meeting standard institutional thresholds.";
            }
        }
        $summaryText = implode(' ', $comments);

        return [
            'exam_id' => $examId,
            'student_id' => $studentId,
            'overall_percentage' => $result['percentage'] ?? 0.0,
            'overall_grade' => $result['grade'] ?? 'N/A',
            'gpa_4' => $gpa,
            'class_position' => $classPosition,
            'total_students_ranked' => $totalRanked,
            'percentile' => $percentile,
            'attendance_rate' => $attRate,
            'strengths' => $strengths,
            'focus_areas' => $focusAreas,
            'academic_synthesis' => $summaryText,
        ];
    }

    /**
     * Cross-Subject Comparative Performance Analysis
     */
    public function subjectPerformanceAnalysis(int $examId, ?int $classId = null): array
    {
        $schoolId = (int) Auth::schoolId();
        $exam = Database::fetch('SELECT * FROM exams WHERE id = ? AND school_id = ?', [$examId, $schoolId]);
        if (!$exam) {
            throw new \RuntimeException('Exam not found.');
        }

        $classFilter = $classId ?? ($exam['class_id'] ? (int) $exam['class_id'] : null);

        $examSubjects = Database::fetchAll(
            'SELECT es.*, sub.name AS subject_name, sub.code AS subject_code
             FROM exam_subjects es
             JOIN subjects sub ON sub.id = es.subject_id
             WHERE es.exam_id = ? AND es.school_id = ?
             ORDER BY sub.name ASC',
            [$examId, $schoolId]
        );

        $subjectStats = [];
        $overallPassed = 0;
        $overallTotalStudents = 0;

        foreach ($examSubjects as $es) {
            $esId = (int) $es['id'];
            $maxMarks = (float) $es['max_marks'];
            $passMarks = (float) $es['pass_marks'];

            $sql = 'SELECT m.*, s.first_name, s.last_name, s.admission_no, s.roll_no
                    FROM exam_marks m
                    JOIN students s ON s.id = m.student_id
                    WHERE m.exam_subject_id = ? AND m.school_id = ?';
            $params = [$esId, $schoolId];

            if ($classFilter) {
                $sql .= ' AND s.class_id = ?';
                $params[] = $classFilter;
            }

            $sql .= ' ORDER BY m.marks_obtained DESC';
            $marksRows = Database::fetchAll($sql, $params);

            $evaluatedCount = count($marksRows);
            if ($evaluatedCount === 0) {
                $subjectStats[] = [
                    'subject_id' => $es['subject_id'],
                    'subject_name' => $es['subject_name'],
                    'subject_code' => $es['subject_code'],
                    'max_marks' => $maxMarks,
                    'pass_marks' => $passMarks,
                    'evaluated_count' => 0,
                    'avg_marks' => 0.0,
                    'avg_percentage' => 0.0,
                    'highest_marks' => 0.0,
                    'highest_student' => 'N/A',
                    'lowest_marks' => 0.0,
                    'pass_count' => 0,
                    'pass_rate' => 0.0,
                    'grades' => ['A+' => 0, 'A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'F' => 0],
                    'health_status' => 'No Data',
                ];
                continue;
            }

            $sumMarks = 0.0;
            $passedCount = 0;
            $highest = $marksRows[0];
            $lowest = $marksRows[$evaluatedCount - 1];
            $grades = ['A+' => 0, 'A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'F' => 0];

            foreach ($marksRows as $m) {
                $val = (float) $m['marks_obtained'];
                $sumMarks += $val;
                if ($val >= $passMarks) {
                    $passedCount++;
                }

                $pct = $maxMarks > 0 ? ($val / $maxMarks) * 100 : 0.0;
                if ($pct >= 90) $grades['A+']++;
                elseif ($pct >= 80) $grades['A']++;
                elseif ($pct >= 70) $grades['B']++;
                elseif ($pct >= 60) $grades['C']++;
                elseif ($pct >= 50) $grades['D']++;
                else $grades['F']++;
            }

            $avgMarks = round($sumMarks / $evaluatedCount, 1);
            $avgPct = $maxMarks > 0 ? round(($avgMarks / $maxMarks) * 100, 1) : 0.0;
            $passRate = round(($passedCount / $evaluatedCount) * 100, 1);

            $health = 'Satisfactory';
            if ($passRate >= 90) {
                $health = 'Mastery';
            } elseif ($passRate < 60) {
                $health = 'Needs Intervention';
            }

            $subjectStats[] = [
                'subject_id' => $es['subject_id'],
                'subject_name' => $es['subject_name'],
                'subject_code' => $es['subject_code'],
                'max_marks' => $maxMarks,
                'pass_marks' => $passMarks,
                'evaluated_count' => $evaluatedCount,
                'avg_marks' => $avgMarks,
                'avg_percentage' => $avgPct,
                'highest_marks' => (float) $highest['marks_obtained'],
                'highest_student' => $highest['first_name'] . ' ' . $highest['last_name'],
                'lowest_marks' => (float) $lowest['marks_obtained'],
                'pass_count' => $passedCount,
                'pass_rate' => $passRate,
                'grades' => $grades,
                'health_status' => $health,
            ];

            $overallPassed += $passedCount;
            $overallTotalStudents += $evaluatedCount;
        }

        // Identify benchmark disciplines
        $sortedByAvg = $subjectStats;
        usort($sortedByAvg, fn($a, $b) => $b['avg_percentage'] <=> $a['avg_percentage']);
        $strongest = !empty($sortedByAvg) ? $sortedByAvg[0] : null;
        $weakest = !empty($sortedByAvg) ? $sortedByAvg[count($sortedByAvg) - 1] : null;

        $examPassRate = $overallTotalStudents > 0 ? round(($overallPassed / $overallTotalStudents) * 100, 1) : 100.0;

        return [
            'exam' => $exam,
            'class_id' => $classFilter,
            'total_subjects' => count($examSubjects),
            'overall_pass_rate' => $examPassRate,
            'strongest_subject' => $strongest,
            'weakest_subject' => $weakest,
            'subjects' => $subjectStats,
        ];
    }
}
