<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * SchoolOnboardingWizardService
 * 
 * Provides an enterprise guided multi-step onboarding wizard for educational institutions.
 * Allows new or existing schools to configure branding, academic sessions, class structures,
 * grading scales, fee policies, and staff roles with step validation, presets, and progress saving.
 */
final class SchoolOnboardingWizardService
{
    public const STEPS = [
        'profile' => [
            'key' => 'profile',
            'title' => 'Institutional Profile & Regional Settings',
            'subtitle' => 'Branding, timezone, currency, localization, and contact details',
            'order' => 1,
        ],
        'academic_sessions' => [
            'key' => 'academic_sessions',
            'title' => 'Academic Year & Terms',
            'subtitle' => 'Define active academic session, start/end dates, and assessment terms',
            'order' => 2,
        ],
        'classes_sections' => [
            'key' => 'classes_sections',
            'title' => 'Classes & Sections Hierarchy',
            'subtitle' => 'Configure grades, streams, and class sections',
            'order' => 3,
        ],
        'grading_rules' => [
            'key' => 'grading_rules',
            'title' => 'Grading Scales & Evaluation Rules',
            'subtitle' => 'Establish letter grades, GPA thresholds, and passing percentages',
            'order' => 4,
        ],
        'fee_structures' => [
            'key' => 'fee_structures',
            'title' => 'Fee Schedules & Categories',
            'subtitle' => 'Setup tuition, admission, exam fees, due days, and payment policies',
            'order' => 5,
        ],
        'staff_roles' => [
            'key' => 'staff_roles',
            'title' => 'Staff Roles & Departments',
            'subtitle' => 'Setup institutional departments and administrative role assignments',
            'order' => 6,
        ],
        'review' => [
            'key' => 'review',
            'title' => 'System Verification & Launch',
            'subtitle' => 'Review institutional readiness and finalize onboarding',
            'order' => 7,
        ],
    ];

    /**
     * Get or initialize the onboarding wizard state for a school.
     */
    public function getStatus(int $schoolId): array
    {
        $record = Database::fetch(
            'SELECT * FROM school_onboarding_wizard WHERE school_id = ? LIMIT 1',
            [$schoolId]
        );

        if (!$record) {
            $now = date('Y-m-d H:i:s');
            $id = Database::insert(
                'INSERT INTO school_onboarding_wizard 
                 (school_id, current_step, completed_steps, is_completed, progress_percentage, step_data, created_at, updated_at)
                 VALUES (?, "profile", "[]", 0, 0, "{}", ?, ?)',
                [$schoolId, $now, $now]
            );
            $record = Database::fetch(
                'SELECT * FROM school_onboarding_wizard WHERE id = ?',
                [$id]
            );
        }

        $completedSteps = json_decode((string)($record['completed_steps'] ?? '[]'), true) ?: [];
        $stepData = json_decode((string)($record['step_data'] ?? '{}'), true) ?: [];

        // Preload existing school data to pre-populate wizard fields
        $school = Database::fetch('SELECT * FROM schools WHERE id = ?', [$schoolId]);
        $branding = Database::fetch('SELECT * FROM school_branding WHERE school_id = ?', [$schoolId]);
        $activeYear = Database::fetch('SELECT * FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1', [$schoolId]);
        $classesCount = (int)(Database::fetch('SELECT COUNT(*) c FROM classes WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        $gradeScalesCount = (int)(Database::fetch('SELECT COUNT(*) c FROM grade_scales WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        $feeCategoriesCount = (int)(Database::fetch('SELECT COUNT(*) c FROM fee_categories WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        $rolesCount = (int)(Database::fetch('SELECT COUNT(*) c FROM roles WHERE school_id = ?', [$schoolId])['c'] ?? 0);

        // Auto-detect previously completed steps if not yet tracked
        $autoCompleted = [];
        if (!empty($school['name']) && !empty($school['timezone'])) {
            $autoCompleted[] = 'profile';
        }
        if ($activeYear) {
            $autoCompleted[] = 'academic_sessions';
        }
        if ($classesCount > 0) {
            $autoCompleted[] = 'classes_sections';
        }
        if ($gradeScalesCount > 0) {
            $autoCompleted[] = 'grading_rules';
        }
        if ($feeCategoriesCount > 0) {
            $autoCompleted[] = 'fee_structures';
        }
        if ($rolesCount > 0) {
            $autoCompleted[] = 'staff_roles';
        }

        $mergedCompleted = array_values(array_unique(array_merge($completedSteps, $autoCompleted)));
        $totalSteps = count(self::STEPS);
        $progressPct = (int)round((count($mergedCompleted) / $totalSteps) * 100);

        if ((int)$record['is_completed'] === 1) {
            $progressPct = 100;
        }

        return [
            'school_id' => $schoolId,
            'current_step' => $record['current_step'] ?? 'profile',
            'is_completed' => (bool)$record['is_completed'],
            'completed_at' => $record['completed_at'],
            'progress_percentage' => $progressPct,
            'completed_steps' => $mergedCompleted,
            'step_data' => $stepData,
            'steps' => self::STEPS,
            'institutional_summary' => [
                'school_name' => $school['name'] ?? '',
                'school_code' => $school['code'] ?? '',
                'timezone' => $school['timezone'] ?? 'UTC',
                'currency' => $school['currency'] ?? 'USD',
                'active_academic_year' => $activeYear['name'] ?? null,
                'total_classes' => $classesCount,
                'total_grade_scales' => $gradeScalesCount,
                'total_fee_categories' => $feeCategoriesCount,
                'primary_color' => $branding['primary_color'] ?? '#0b4f6c',
                'secondary_color' => $branding['secondary_color'] ?? '#01baef',
            ],
        ];
    }

    /**
     * Save progress and commit configuration for a specific wizard step.
     */
    public function saveStep(int $schoolId, string $stepKey, array $data, int $userId): array
    {
        if (!isset(self::STEPS[$stepKey]) && $stepKey !== 'review') {
            return ['success' => false, 'error' => "Invalid onboarding step: {$stepKey}."];
        }

        Database::beginTransaction();
        try {
            switch ($stepKey) {
                case 'profile':
                    $this->commitProfileStep($schoolId, $data);
                    break;
                case 'academic_sessions':
                    $this->commitAcademicSessionsStep($schoolId, $data);
                    break;
                case 'classes_sections':
                    $this->commitClassesSectionsStep($schoolId, $data);
                    break;
                case 'grading_rules':
                    $this->commitGradingRulesStep($schoolId, $data);
                    break;
                case 'fee_structures':
                    $this->commitFeeStructuresStep($schoolId, $data);
                    break;
                case 'staff_roles':
                    $this->commitStaffRolesStep($schoolId, $data);
                    break;
                case 'review':
                    // Just verification
                    break;
            }

            // Update wizard state in database
            $status = $this->getStatus($schoolId);
            $completedSteps = $status['completed_steps'];
            if (!in_array($stepKey, $completedSteps, true)) {
                $completedSteps[] = $stepKey;
            }

            $stepData = $status['step_data'];
            $stepData[$stepKey] = $data;

            // Determine next step
            $stepKeys = array_keys(self::STEPS);
            $currentIndex = array_search($stepKey, $stepKeys, true);
            $nextStep = ($currentIndex !== false && isset($stepKeys[$currentIndex + 1])) 
                ? $stepKeys[$currentIndex + 1] 
                : 'review';

            $progressPct = (int)round((count($completedSteps) / count(self::STEPS)) * 100);

            Database::execute(
                'UPDATE school_onboarding_wizard 
                 SET current_step = ?, completed_steps = ?, progress_percentage = ?, step_data = ?, updated_at = NOW()
                 WHERE school_id = ?',
                [
                    $nextStep,
                    json_encode(array_values($completedSteps)),
                    $progressPct,
                    json_encode($stepData),
                    $schoolId
                ]
            );

            // Audit log
            if (function_exists('auditLog')) {
                auditLog('onboarding.step_saved', 'school_onboarding', "Saved setup wizard step {$stepKey}", null, [
                    'step' => $stepKey,
                    'user_id' => $userId,
                    'school_id' => $schoolId,
                ]);
            }

            // Invalidate tenant cache
            \Core\Cache\CacheManager::flushTenant($schoolId);

            Database::commit();

            return [
                'success' => true,
                'message' => "Step '{$stepKey}' saved successfully.",
                'next_step' => $nextStep,
                'progress_percentage' => $progressPct,
            ];
        } catch (\Throwable $e) {
            Database::rollBack();
            return [
                'success' => false,
                'error' => 'Step configuration failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Apply a pre-built institutional curriculum & grading preset in one click.
     */
    public function applyPreset(int $schoolId, string $presetKey, int $userId): array
    {
        $presets = [
            'k12_standard' => [
                'name' => 'Standard K-12 Curriculum',
                'classes' => [
                    'Kindergarten', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 
                    'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'
                ],
                'sections' => ['A', 'B'],
                'grade_scales' => [
                    ['grade' => 'A+', 'min' => 90, 'max' => 100],
                    ['grade' => 'A',  'min' => 80, 'max' => 89.99],
                    ['grade' => 'B',  'min' => 70, 'max' => 79.99],
                    ['grade' => 'C',  'min' => 60, 'max' => 69.99],
                    ['grade' => 'D',  'min' => 50, 'max' => 59.99],
                    ['grade' => 'F',  'min' => 0,  'max' => 49.99],
                ],
                'fees' => [
                    ['name' => 'Annual Tuition Fee', 'code' => 'TUITION_ANNUAL', 'amount' => 1200.00, 'freq' => 'annually'],
                    ['name' => 'Monthly Tuition Fee', 'code' => 'TUITION_MONTHLY', 'amount' => 100.00, 'freq' => 'monthly'],
                    ['name' => 'Admission & Registration', 'code' => 'ADMISSION_FEE', 'amount' => 250.00, 'freq' => 'one_time'],
                    ['name' => 'Laboratory & STEM Fee', 'code' => 'STEM_LAB_FEE', 'amount' => 75.00, 'freq' => 'termly'],
                ]
            ],
            'primary_middle' => [
                'name' => 'Primary & Middle Elementary School',
                'classes' => [
                    'Early Years Nursery', 'Pre-K', 'Kindergarten', 
                    'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8'
                ],
                'sections' => ['Blue', 'Gold'],
                'grade_scales' => [
                    ['grade' => 'Exemplary', 'min' => 85, 'max' => 100],
                    ['grade' => 'Proficient', 'min' => 70, 'max' => 84.99],
                    ['grade' => 'Developing', 'min' => 55, 'max' => 69.99],
                    ['grade' => 'Emerging',   'min' => 0,  'max' => 54.99],
                ],
                'fees' => [
                    ['name' => 'Term Tuition Fee', 'code' => 'TUITION_TERM', 'amount' => 350.00, 'freq' => 'termly'],
                    ['name' => 'Activity & Art Supplies', 'code' => 'ART_SUPPLIES', 'amount' => 50.00, 'freq' => 'termly'],
                    ['name' => 'Registration Fee', 'code' => 'PRIMARY_REG_FEE', 'amount' => 150.00, 'freq' => 'one_time'],
                ]
            ],
            'higher_secondary' => [
                'name' => 'Senior Secondary & College Preparatory',
                'classes' => [
                    'Grade 9 (Freshman)', 'Grade 10 (Sophomore)', 'Grade 11 (Junior)', 'Grade 12 (Senior)'
                ],
                'sections' => ['Alpha', 'Beta'],
                'grade_scales' => [
                    ['grade' => 'A (4.0)', 'min' => 93, 'max' => 100],
                    ['grade' => 'A- (3.7)', 'min' => 90, 'max' => 92.99],
                    ['grade' => 'B+ (3.3)', 'min' => 87, 'max' => 89.99],
                    ['grade' => 'B (3.0)', 'min' => 83, 'max' => 86.99],
                    ['grade' => 'C (2.0)', 'min' => 73, 'max' => 82.99],
                    ['grade' => 'D (1.0)', 'min' => 60, 'max' => 72.99],
                    ['grade' => 'F (0.0)', 'min' => 0,  'max' => 59.99],
                ],
                'fees' => [
                    ['name' => 'Semester Tuition', 'code' => 'TUITION_SEMESTER', 'amount' => 850.00, 'freq' => 'termly'],
                    ['name' => 'Advanced Placement / Exam Fee', 'code' => 'AP_EXAM_FEE', 'amount' => 120.00, 'freq' => 'termly'],
                    ['name' => 'Campus Technology Fee', 'code' => 'TECH_FEE', 'amount' => 80.00, 'freq' => 'annually'],
                ]
            ],
        ];

        if (!isset($presets[$presetKey])) {
            return ['success' => false, 'error' => "Unknown preset: {$presetKey}."];
        }

        $preset = $presets[$presetKey];

        Database::beginTransaction();
        try {
            // 1. Classes & Sections
            foreach ($preset['classes'] as $idx => $className) {
                $cls = Database::fetch('SELECT id FROM classes WHERE school_id = ? AND name = ? LIMIT 1', [$schoolId, $className]);
                if (!$cls) {
                    $classId = (int)Database::insert(
                        'INSERT INTO classes (school_id, name, numeric_name, status, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())',
                        [$schoolId, $className, $idx + 1]
                    );
                } else {
                    $classId = (int)$cls['id'];
                }

                foreach ($preset['sections'] as $secName) {
                    $sec = Database::fetch('SELECT id FROM sections WHERE school_id = ? AND class_id = ? AND name = ? LIMIT 1', [$schoolId, $classId, $secName]);
                    if (!$sec) {
                        Database::insert(
                            'INSERT INTO sections (school_id, class_id, name, status, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())',
                            [$schoolId, $classId, $secName]
                        );
                    }
                }
            }

            // 2. Grade Scales
            foreach ($preset['grade_scales'] as $gs) {
                $existGs = Database::fetch('SELECT id FROM grade_scales WHERE school_id = ? AND grade = ? LIMIT 1', [$schoolId, $gs['grade']]);
                if (!$existGs) {
                    Database::insert(
                        'INSERT INTO grade_scales (school_id, grade, min_percentage, max_percentage, created_at) VALUES (?, ?, ?, ?, NOW())',
                        [$schoolId, $gs['grade'], $gs['min'], $gs['max']]
                    );
                }
            }

            // 3. Fee Categories
            foreach ($preset['fees'] as $fee) {
                $existFee = Database::fetch('SELECT id FROM fee_categories WHERE school_id = ? AND code = ? LIMIT 1', [$schoolId, $fee['code']]);
                if (!$existFee) {
                    $feeFreq = match (strtolower(trim((string)$fee['freq']))) {
                        'termly', 'term' => 'term',
                        'annually', 'annual' => 'annual',
                        'one_time' => 'one_time',
                        default => 'monthly',
                    };
                    Database::insert(
                        'INSERT INTO fee_categories (school_id, name, code, description, amount, frequency, status, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                        [$schoolId, $fee['name'], $fee['code'], "Standard preset: {$fee['name']}", $fee['amount'], $feeFreq]
                    );
                }
            }

            // Update completed steps
            $status = $this->getStatus($schoolId);
            $completed = array_unique(array_merge($status['completed_steps'], ['classes_sections', 'grading_rules', 'fee_structures']));
            $progressPct = (int)round((count($completed) / count(self::STEPS)) * 100);

            Database::execute(
                'UPDATE school_onboarding_wizard SET completed_steps = ?, progress_percentage = ?, updated_at = NOW() WHERE school_id = ?',
                [json_encode(array_values($completed)), $progressPct, $schoolId]
            );

            \Core\Cache\CacheManager::flushTenant($schoolId);
            Database::commit();

            return [
                'success' => true,
                'message' => "Successfully applied preset: {$preset['name']}.",
                'classes_count' => count($preset['classes']),
                'grade_scales_count' => count($preset['grade_scales']),
                'fees_count' => count($preset['fees']),
            ];
        } catch (\Throwable $e) {
            Database::rollBack();
            return ['success' => false, 'error' => 'Preset application failed: ' . $e->getMessage()];
        }
    }

    /**
     * Finalize setup wizard and mark school as ready.
     */
    public function completeWizard(int $schoolId, int $userId): array
    {
        $status = $this->getStatus($schoolId);

        // Require at least profile and academic sessions
        if (!in_array('profile', $status['completed_steps'], true) || !in_array('academic_sessions', $status['completed_steps'], true)) {
            return [
                'success' => false,
                'error' => 'Please complete institutional profile and academic sessions before final launch.',
            ];
        }

        $now = date('Y-m-d H:i:s');
        $allSteps = array_keys(self::STEPS);

        Database::execute(
            'UPDATE school_onboarding_wizard 
             SET is_completed = 1, current_step = "review", completed_steps = ?, progress_percentage = 100, completed_at = ?, updated_at = NOW()
             WHERE school_id = ?',
            [json_encode($allSteps), $now, $schoolId]
        );

        if (function_exists('auditLog')) {
            auditLog('onboarding.completed', 'school_onboarding', 'School onboarding wizard completed successfully', null, [
                'school_id' => $schoolId,
                'user_id' => $userId,
                'completed_at' => $now,
            ]);
        }

        \Core\Cache\CacheManager::flushTenant($schoolId);

        return [
            'success' => true,
            'message' => 'Congratulations! Your institution is fully configured and ready for live operations.',
            'completed_at' => $now,
        ];
    }

    private function commitProfileStep(int $schoolId, array $data): void
    {
        $name = trim((string)($data['school_name'] ?? ''));
        $code = trim((string)($data['school_code'] ?? ''));
        $email = trim((string)($data['email'] ?? ''));
        $phone = trim((string)($data['phone'] ?? ''));
        $address = trim((string)($data['address'] ?? ''));
        $timezone = trim((string)($data['timezone'] ?? 'UTC'));
        $currency = strtoupper(trim((string)($data['currency'] ?? 'USD')));
        $primaryColor = trim((string)($data['primary_color'] ?? '#0b4f6c'));
        $secondaryColor = trim((string)($data['secondary_color'] ?? '#01baef'));

        if ($name === '') {
            throw new \InvalidArgumentException('School name cannot be blank.');
        }

        // Update schools table
        Database::execute(
            'UPDATE schools 
             SET name = ?, code = COALESCE(NULLIF(?, ""), code), email = ?, phone = ?, address = ?, timezone = ?, currency = ?, updated_at = NOW()
             WHERE id = ?',
            [$name, $code, $email, $phone, $address, $timezone, $currency, $schoolId]
        );

        // Update branding table
        $branding = Database::fetch('SELECT id FROM school_branding WHERE school_id = ?', [$schoolId]);
        if ($branding) {
            Database::execute(
                'UPDATE school_branding SET primary_color = ?, secondary_color = ?, updated_at = NOW() WHERE school_id = ?',
                [$primaryColor, $secondaryColor, $schoolId]
            );
        } else {
            Database::insert(
                'INSERT INTO school_branding (school_id, primary_color, secondary_color, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
                [$schoolId, $primaryColor, $secondaryColor]
            );
        }

        // Update settings
        $settingsToSet = [
            'school_name' => $name,
            'school_email' => $email,
            'school_phone' => $phone,
            'school_address' => $address,
            'timezone' => $timezone,
            'currency' => $currency,
            'date_format' => $data['date_format'] ?? 'd M Y',
            'time_format' => $data['time_format'] ?? '12_hour',
            'theme_color' => $primaryColor,
        ];
        foreach ($settingsToSet as $k => $v) {
            $exist = Database::fetch('SELECT id FROM settings WHERE school_id = ? AND setting_key = ?', [$schoolId, $k]);
            if ($exist) {
                Database::execute('UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [(string)$v, (int)$exist['id']]);
            } else {
                Database::insert('INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())', [$schoolId, $k, (string)$v]);
            }
        }
    }

    private function commitAcademicSessionsStep(int $schoolId, array $data): void
    {
        $sessionName = trim((string)($data['session_name'] ?? ''));
        $startDate = trim((string)($data['start_date'] ?? ''));
        $endDate = trim((string)($data['end_date'] ?? ''));

        if ($sessionName === '' || $startDate === '' || $endDate === '') {
            throw new \InvalidArgumentException('Academic session name, start date, and end date are mandatory.');
        }

        // Deactivate previous active years if requested
        Database::execute('UPDATE academic_years SET is_active = 0, updated_at = NOW() WHERE school_id = ?', [$schoolId]);

        $year = Database::fetch('SELECT id FROM academic_years WHERE school_id = ? AND name = ? LIMIT 1', [$schoolId, $sessionName]);
        if ($year) {
            Database::execute(
                'UPDATE academic_years SET start_date = ?, end_date = ?, is_active = 1, updated_at = NOW() WHERE id = ?',
                [$startDate, $endDate, (int)$year['id']]
            );
            $yearId = (int)$year['id'];
        } else {
            $yearId = (int)Database::insert(
                'INSERT INTO academic_years (school_id, name, start_date, end_date, is_active, created_at, updated_at)
                 VALUES (?, ?, ?, ?, 1, NOW(), NOW())',
                [$schoolId, $sessionName, $startDate, $endDate]
            );
        }

        // Seed default terms if none exist
        $existingTerms = Database::fetch('SELECT COUNT(*) c FROM academic_terms WHERE academic_year_id = ?', [$yearId]);
        if ((int)($existingTerms['c'] ?? 0) === 0) {
            $sTime = strtotime($startDate);
            $eTime = strtotime($endDate);
            $diff = ($eTime - $sTime) / 3;

            $terms = [
                ['name' => 'Term 1 / Fall', 'start' => date('Y-m-d', (int)$sTime), 'end' => date('Y-m-d', (int)($sTime + $diff))],
                ['name' => 'Term 2 / Spring', 'start' => date('Y-m-d', (int)($sTime + $diff + 86400)), 'end' => date('Y-m-d', (int)($sTime + ($diff * 2)))],
                ['name' => 'Term 3 / Summer', 'start' => date('Y-m-d', (int)($sTime + ($diff * 2) + 86400)), 'end' => $endDate],
            ];

            foreach ($terms as $t) {
                Database::insert(
                    'INSERT INTO academic_terms (school_id, academic_year_id, name, start_date, end_date, is_active, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, 0, NOW(), NOW())',
                    [$schoolId, $yearId, $t['name'], $t['start'], $t['end']]
                );
            }
        }
    }

    private function commitClassesSectionsStep(int $schoolId, array $data): void
    {
        $rawClasses = $data['classes'] ?? [];
        if (is_string($rawClasses)) {
            // Can be newline or comma separated
            $rawClasses = array_filter(array_map('trim', preg_split('/[\r\n,]+/', $rawClasses)));
        }

        if (empty($rawClasses)) {
            throw new \InvalidArgumentException('Please supply at least one academic class.');
        }

        $defaultSections = ['A', 'B'];
        if (!empty($data['default_sections'])) {
            $defaultSections = is_array($data['default_sections']) 
                ? $data['default_sections'] 
                : array_filter(array_map('trim', explode(',', (string)$data['default_sections'])));
        }

        foreach (array_values($rawClasses) as $idx => $className) {
            $className = trim((string)$className);
            if ($className === '') continue;

            $cls = Database::fetch('SELECT id FROM classes WHERE school_id = ? AND name = ? LIMIT 1', [$schoolId, $className]);
            if (!$cls) {
                $classId = (int)Database::insert(
                    'INSERT INTO classes (school_id, name, numeric_name, status, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())',
                    [$schoolId, $className, $idx + 1]
                );
            } else {
                $classId = (int)$cls['id'];
            }

            foreach ($defaultSections as $sec) {
                $secName = trim((string)$sec);
                if ($secName === '') continue;
                $existSec = Database::fetch('SELECT id FROM sections WHERE school_id = ? AND class_id = ? AND name = ? LIMIT 1', [$schoolId, $classId, $secName]);
                if (!$existSec) {
                    Database::insert(
                        'INSERT INTO sections (school_id, class_id, name, status, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())',
                        [$schoolId, $classId, $secName]
                    );
                }
            }
        }
    }

    private function commitGradingRulesStep(int $schoolId, array $data): void
    {
        $system = trim((string)($data['grading_system'] ?? 'letter_grade'));
        $passPct = (float)($data['passing_percentage'] ?? 40.0);

        // Update settings
        Database::execute(
            'INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at)
             VALUES (?, "grading_system", ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()',
            [$schoolId, $system]
        );
        Database::execute(
            'INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at)
             VALUES (?, "passing_percentage", ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()',
            [$schoolId, (string)$passPct]
        );

        // Custom grade scale boundaries
        if (!empty($data['grade_scales']) && is_array($data['grade_scales'])) {
            Database::execute('DELETE FROM grade_scales WHERE school_id = ?', [$schoolId]);
            foreach ($data['grade_scales'] as $gs) {
                if (empty($gs['grade'])) continue;
                Database::insert(
                    'INSERT INTO grade_scales (school_id, grade, min_percentage, max_percentage, created_at)
                     VALUES (?, ?, ?, ?, NOW())',
                    [$schoolId, trim((string)$gs['grade']), (float)($gs['min_percentage'] ?? 0), (float)($gs['max_percentage'] ?? 100)]
                );
            }
        }
    }

    private function commitFeeStructuresStep(int $schoolId, array $data): void
    {
        $dueDay = (int)($data['fee_due_day'] ?? 7);
        if ($dueDay < 1 || $dueDay > 28) $dueDay = 7;

        Database::execute('UPDATE schools SET fee_due_day = ?, updated_at = NOW() WHERE id = ?', [$dueDay, $schoolId]);

        if (!empty($data['categories']) && is_array($data['categories'])) {
            foreach ($data['categories'] as $cat) {
                $name = trim((string)($cat['name'] ?? ''));
                $rawFreq = strtolower(trim((string)($cat['frequency'] ?? '')));
                $freq = match ($rawFreq) {
                    'termly', 'term' => 'term',
                    'annually', 'annual' => 'annual',
                    'one_time' => 'one_time',
                    default => 'monthly',
                };
                $amount = (float)($cat['amount'] ?? 0);

                $code = strtoupper(preg_replace('/[^A-Z0-9_]/', '_', $name));
                $exist = Database::fetch('SELECT id FROM fee_categories WHERE school_id = ? AND (name = ? OR code = ?) LIMIT 1', [$schoolId, $name, $code]);
                if ($exist) {
                    Database::execute(
                        'UPDATE fee_categories SET name = ?, code = ?, amount = ?, frequency = ?, updated_at = NOW() WHERE id = ?',
                        [$name, $code, $amount, $freq, (int)$exist['id']]
                    );
                } else {
                    Database::insert(
                        'INSERT INTO fee_categories (school_id, name, code, description, amount, frequency, status, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                        [$schoolId, $name, $code, "Onboarding configured: {$name}", $amount, $freq]
                    );
                }
            }
        }
    }

    private function commitStaffRolesStep(int $schoolId, array $data): void
    {
        // Departments
        $departments = $data['departments'] ?? ['Academics', 'Administration', 'Finance', 'Student Services'];
        if (is_string($departments)) {
            $departments = array_filter(array_map('trim', explode(',', $departments)));
        }

        foreach ($departments as $dept) {
            $deptName = trim((string)$dept);
            if ($deptName === '') continue;
            $existDept = Database::fetch('SELECT id FROM departments WHERE school_id = ? AND name = ? LIMIT 1', [$schoolId, $deptName]);
            if (!$existDept) {
                Database::insert(
                    'INSERT INTO departments (school_id, name, status, created_at, updated_at) VALUES (?, ?, 1, NOW(), NOW())',
                    [$schoolId, $deptName]
                );
            }
        }
    }
}
