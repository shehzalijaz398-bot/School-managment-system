<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * SchoolAnalyticsService
 *
 * Core engine for multi-tenant educational intelligence, trend analysis,
 * anomaly detection, and AI-driven executive synthesis.
 * Strictly enforces tenant boundaries and zero-trust data segregation.
 */
final class SchoolAnalyticsService
{
    private AiLlmService $llmService;

    public function __construct()
    {
        $this->llmService = new AiLlmService();
    }

    /**
     * Compile verified factual metrics, trend deltas, anomaly flags, and AI insights for a school tenant.
     *
     * @param int $schoolId Strictly bound school tenant ID
     * @param string $period 'last_30_days', 'this_term', 'this_year', or 'custom'
     * @param string|null $customStart
     * @param string|null $customEnd
     * @param string $role User role slug ('admin', 'school_admin', 'principal', 'teacher', 'accountant')
     * @return array Multi-dimensional analytical payload
     */
    public function compileSchoolAnalytics(
        int $schoolId,
        string $period = 'last_30_days',
        ?string $customStart = null,
        ?string $customEnd = null,
        string $role = 'school_admin',
        ?int $classId = null,
        ?int $teacherUserId = null
    ): array {
        // 1. Resolve Date Ranges for Current and Prior Comparison Periods
        $dates = $this->resolvePeriodDates($period, $customStart, $customEnd);
        $currentStart = $dates['current_start'];
        $currentEnd = $dates['current_end'];
        $compareStart = $dates['compare_start'];
        $compareEnd = $dates['compare_end'];

        // 2. Fetch Institutional Profile
        $school = Database::fetch(
            'SELECT id, name, code, city, country, subscription_status 
             FROM schools 
             WHERE id = ? AND deleted_at IS NULL LIMIT 1',
            [$schoolId]
        );
        $schoolName = $school['name'] ?? 'School #' . $schoolId;
        $schoolCode = $school['code'] ?? 'TENANT-' . $schoolId;

        // Teacher RBAC Scoping
        $teacherId = null;
        if ($role === 'teacher' && $teacherUserId !== null) {
            $teacherId = $this->resolveTeacherId($schoolId, $teacherUserId);
        }

        // Available classes for filtering based on role
        $classesList = $this->getAuthorizedClasses($schoolId, $role, $teacherId);
        $authorizedClassIds = array_column($classesList, 'id');

        // If a classId was requested, verify it is within authorized purview
        if ($classId !== null && $classId > 0) {
            if (!empty($authorizedClassIds) && !in_array($classId, $authorizedClassIds, true)) {
                $classId = null; // Reset to null if unauthorized
            }
        }

        // 3. Compile Verified Domain Metrics with Parameterized PDO Queries
        $attendanceData = $this->compileAttendanceMetrics($schoolId, $currentStart, $currentEnd, $compareStart, $compareEnd, $classId);
        
        // Strict Role-Based Financial Gating: Mask institutional financial ledger for non-administrative roles (e.g. teachers)
        $isFinanceAuthorized = in_array($role, ['admin', 'school_admin', 'principal', 'accountant', 'finance'], true);
        if ($isFinanceAuthorized) {
            $financeData = $this->compileFinanceMetrics($schoolId, $currentStart, $currentEnd, $compareStart, $compareEnd);
            $monthlyFinance = $this->compileMonthlyFinanceTrajectory($schoolId);
        } else {
            $financeData = [
                'has_sufficient_data' => false,
                'access_restricted' => true,
                'total_invoiced' => 0.0,
                'total_collected' => 0.0,
                'overdue_arrears' => 0.0,
                'collection_efficiency_rate' => 0.0,
                'overdue_invoices_count' => 0,
                'total_invoices_count' => 0,
                'revenue_growth_percentage' => 0.0,
                'reason' => 'Financial metrics are restricted to administrative and finance roles.',
            ];
            $monthlyFinance = [
                'access_restricted' => true,
                'history' => [],
                'projected_collection_30d' => 0.0,
            ];
        }

        $academicData        = $this->compileAcademicMetrics($schoolId, $currentStart, $currentEnd, $classId);
        $enrollmentData      = $this->compileEnrollmentMetrics($schoolId, $currentStart, $currentEnd, $classId);
        $staffData           = $this->compileStaffMetrics($schoolId);
        $staffAttendanceData = $this->compileStaffAttendanceMetrics($schoolId, $currentStart, $currentEnd);
        $cohortData          = $this->compileCohortBreakdown($schoolId, $currentStart, $currentEnd, $teacherId, $classId);

        // Granular Drilldown Datasets
        $feeCategoriesDrilldown = $this->getFeeCategoryDrilldown($schoolId, $currentStart, $currentEnd, $role);
        $subjectDetailsDrilldown = $this->getSubjectDrilldown($schoolId, $classId);
        $attendanceDefaulters   = $this->getAttendanceDefaulters($schoolId, $currentStart, $currentEnd, $classId, 75.0, $role, $teacherUserId);

        // 4. Deterministic Trend Analysis & Anomaly Detection
        $anomalies = $this->detectAnomalies($attendanceData, $financeData, $academicData);

        // 5. Predictive Risk Scoring & Targeted Pedagogical Insights
        $predictiveInsights = $this->generatePredictiveInsights($schoolId, $attendanceData, $financeData, $academicData, $cohortData, $role);

        // 6. Structure Verified Statistics
        $verifiedStats = [
            'attendance'       => $attendanceData,
            'finance'          => $financeData,
            'academics'        => $academicData,
            'enrollment'       => $enrollmentData,
            'staff'            => $staffData,
            'staff_attendance' => $staffAttendanceData,
            'cohorts'          => $cohortData,
            'monthly_finance'  => $monthlyFinance,
        ];

        // 7. Generate Role-Specific AI Executive Insight
        $aiInsight = $this->generateAiExecutiveInsight(
            schoolName: $schoolName,
            schoolCode: $schoolCode,
            periodName: $dates['label'],
            role: $role,
            stats: $verifiedStats,
            anomalies: $anomalies
        );

        return [
            'status' => 'success',
            'school_id' => $schoolId,
            'school_name' => $schoolName,
            'school_code' => $schoolCode,
            'data_source' => 'Institutional Production Database (Tenant #' . $schoolId . ')',
            'reporting_period' => [
                'key' => $period,
                'label' => $dates['label'],
                'current_start' => $currentStart,
                'current_end' => $currentEnd,
                'compare_start' => $compareStart,
                'compare_end' => $compareEnd,
            ],
            'selected_class_id' => $classId,
            'classes_list' => $classesList,
            'verified_statistics' => $verifiedStats,
            'drilldowns' => [
                'fee_categories' => $feeCategoriesDrilldown,
                'subject_details' => $subjectDetailsDrilldown,
                'attendance_defaulters' => $attendanceDefaulters,
            ],
            'anomalies' => $anomalies,
            'predictive_insights' => $predictiveInsights,
            'ai_interpretation' => $aiInsight,
            'generated_at' => date('Y-m-d H:i:s'),
        ];
    }

    /**
     * Compile platform-wide metrics and macro analytics for SaaS Super Administrators.
     * Strictly aggregated — zero individual student or guardian PII is processed.
     */
    public function compilePlatformAnalytics(string $period = '30d'): array
    {
        $days = match ($period) {
            '7d' => 7,
            '90d' => 90,
            '1y' => 365,
            default => 30,
        };

        $startDate = date('Y-m-d', strtotime("-{$days} days"));
        $compareStart = date('Y-m-d', strtotime('-' . ($days * 2) . ' days'));
        $compareEnd = $startDate;

        // 1. Institutional Tenant Counts
        $tenants = Database::fetch(
            'SELECT 
                COUNT(*) AS total_tenants,
                SUM(CASE WHEN subscription_status = "active" THEN 1 ELSE 0 END) AS active_tenants,
                SUM(CASE WHEN subscription_status = "trial" THEN 1 ELSE 0 END) AS trial_tenants,
                SUM(CASE WHEN subscription_status = "suspended" OR status = 0 THEN 1 ELSE 0 END) AS suspended_tenants,
                SUM(CASE WHEN subscription_status = "expired" THEN 1 ELSE 0 END) AS expired_tenants
             FROM schools 
             WHERE deleted_at IS NULL'
        );

        // 2. Subscription Financials
        $revCurrent = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS total 
             FROM subscription_payments 
             WHERE payment_status = "paid" AND paid_at >= ?',
            [$startDate]
        )['total'] ?? 0.0;

        $revPrior = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS total 
             FROM subscription_payments 
             WHERE payment_status = "paid" AND paid_at >= ? AND paid_at < ?',
            [$compareStart, $compareEnd]
        )['total'] ?? 0.0;

        $revCurrent = (float) $revCurrent;
        $revPrior = (float) $revPrior;
        $revDelta = $revPrior > 0 ? round((($revCurrent - $revPrior) / $revPrior) * 100, 1) : 0.0;

        // 3. Platform Student Capacity
        $studentsTotal = Database::fetch('SELECT COUNT(*) AS c FROM students WHERE status = "active"')['c'] ?? 0;
        $activeBackups = Database::fetch('SELECT COUNT(*) AS c, MAX(created_at) AS latest FROM platform_backups WHERE status = "completed"');

        // 4. Subscription Tier Breakdown
        $planDistribution = Database::fetchAll(
            'SELECT p.name, COUNT(s.id) AS school_count, p.monthly_price
             FROM schools s
             LEFT JOIN plans p ON p.id = s.plan_id
             WHERE s.deleted_at IS NULL
             GROUP BY p.id, p.name, p.monthly_price
             ORDER BY p.monthly_price DESC'
        );

        $verifiedStats = [
            'tenants' => [
                'total' => (int) ($tenants['total_tenants'] ?? 0),
                'active' => (int) ($tenants['active_tenants'] ?? 0),
                'trial' => (int) ($tenants['trial_tenants'] ?? 0),
                'suspended' => (int) ($tenants['suspended_tenants'] ?? 0),
                'expired' => (int) ($tenants['expired_tenants'] ?? 0),
            ],
            'revenue' => [
                'current_period_amount' => $revCurrent,
                'prior_period_amount' => $revPrior,
                'growth_percentage' => $revDelta,
            ],
            'platform_students' => (int) $studentsTotal,
            'vault' => [
                'completed_backups' => (int) ($activeBackups['c'] ?? 0),
                'latest_backup' => $activeBackups['latest'] ?? 'None',
            ],
            'plan_distribution' => $planDistribution,
        ];

        // Anomaly / Attention Flags
        $anomalies = [];
        if ((int) ($tenants['suspended_tenants'] ?? 0) > 0) {
            $anomalies[] = [
                'type' => 'warning',
                'title' => 'Suspended Tenants Present',
                'description' => "{$tenants['suspended_tenants']} school tenant(s) are currently marked suspended or deactivated.",
            ];
        }
        if ($revDelta < 0) {
            $anomalies[] = [
                'type' => 'critical',
                'title' => 'Revenue Contraction',
                'description' => "Subscription revenue declined by {$revDelta}% compared to prior {$days}-day cycle.",
            ];
        }

        // Generate Super Admin AI Executive Summary
        $aiInsight = $this->generatePlatformAiInsight($verifiedStats, $anomalies, $days);

        return [
            'status' => 'success',
            'scope' => 'platform',
            'tenant_id' => 0,
            'data_source' => 'SaaS Multi-Tenant Central Control Ledger',
            'reporting_period' => [
                'days' => $days,
                'start' => $startDate,
                'end' => date('Y-m-d'),
            ],
            'verified_statistics' => $verifiedStats,
            'anomalies' => $anomalies,
            'ai_interpretation' => $aiInsight,
            'generated_at' => date('Y-m-d H:i:s'),
        ];
    }

    /**
     * Resolve start and end dates for requested reporting period.
     */
    private function resolvePeriodDates(string $period, ?string $customStart, ?string $customEnd): array
    {
        $today = date('Y-m-d');

        switch ($period) {
            case 'last_30_days':
                $start = date('Y-m-d', strtotime('-30 days'));
                $end = $today;
                $compStart = date('Y-m-d', strtotime('-60 days'));
                $compEnd = date('Y-m-d', strtotime('-31 days'));
                $label = 'Last 30 Days';
                break;

            case 'this_term':
                // Typical academic term: ~90 days
                $start = date('Y-m-d', strtotime('-90 days'));
                $end = $today;
                $compStart = date('Y-m-d', strtotime('-180 days'));
                $compEnd = date('Y-m-d', strtotime('-91 days'));
                $label = 'Current Academic Term (90 Days)';
                break;

            case 'this_year':
                $start = date('Y-01-01');
                $end = $today;
                $compStart = date((date('Y') - 1) . '-01-01');
                $compEnd = date((date('Y') - 1) . '-12-31');
                $label = 'Academic Year ' . date('Y');
                break;

            case 'custom':
                $start = !empty($customStart) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $customStart) ? $customStart : date('Y-m-d', strtotime('-30 days'));
                $end = !empty($customEnd) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $customEnd) ? $customEnd : $today;
                $diffDays = max(1, (int) round((strtotime($end) - strtotime($start)) / 86400));
                $compStart = date('Y-m-d', strtotime("{$start} -{$diffDays} days"));
                $compEnd = date('Y-m-d', strtotime("{$start} -1 day"));
                $label = "Custom Range ({$start} to {$end})";
                break;

            default:
                $start = date('Y-m-d', strtotime('-30 days'));
                $end = $today;
                $compStart = date('Y-m-d', strtotime('-60 days'));
                $compEnd = date('Y-m-d', strtotime('-31 days'));
                $label = 'Last 30 Days';
                break;
        }

        return [
            'current_start' => $start,
            'current_end' => $end,
            'compare_start' => $compStart,
            'compare_end' => $compEnd,
            'label' => $label,
        ];
    }

    /**
     * Compute verified attendance metrics, daily trendline, and comparison deltas.
     */
    private function compileAttendanceMetrics(int $schoolId, string $start, string $end, string $compStart, string $compEnd, ?int $classId = null): array
    {
        $classJoin = '';
        $whereClass = '';
        $currParams = [$schoolId, $start, $end];
        $priorParams = [$schoolId, $compStart, $compEnd];
        $dailyParams = [$schoolId, $start, $end];

        if ($classId !== null && $classId > 0) {
            $classJoin = ' JOIN students st ON st.id = student_attendance.student_id AND st.school_id = student_attendance.school_id ';
            $whereClass = ' AND st.class_id = ? ';
            $currParams[] = $classId;
            $priorParams[] = $classId;
            $dailyParams[] = $classId;
        }

        // Current Period Aggregates
        $curr = Database::fetch(
            "SELECT 
                COUNT(*) AS total_records,
                SUM(CASE WHEN student_attendance.status = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN student_attendance.status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN student_attendance.status = 'late' THEN 1 ELSE 0 END) AS late_count,
                COUNT(DISTINCT student_attendance.attendance_date) AS recorded_school_days
             FROM student_attendance
             {$classJoin}
             WHERE student_attendance.school_id = ? AND student_attendance.attendance_date BETWEEN ? AND ? {$whereClass}",
            $currParams
        );

        // Comparison Period Aggregates
        $prior = Database::fetch(
            "SELECT 
                COUNT(*) AS total_records,
                SUM(CASE WHEN student_attendance.status = 'present' THEN 1 ELSE 0 END) AS present_count
             FROM student_attendance
             {$classJoin}
             WHERE student_attendance.school_id = ? AND student_attendance.attendance_date BETWEEN ? AND ? {$whereClass}",
            $priorParams
        );

        $totalRecs = (int) ($curr['total_records'] ?? 0);
        $presentCount = (int) ($curr['present_count'] ?? 0);
        $absentCount = (int) ($curr['absent_count'] ?? 0);
        $lateCount = (int) ($curr['late_count'] ?? 0);
        $schoolDays = (int) ($curr['recorded_school_days'] ?? 0);

        $currRate = $totalRecs > 0 ? round(($presentCount / $totalRecs) * 100, 2) : 0.0;
        $priorTotal = (int) ($prior['total_records'] ?? 0);
        $priorPresent = (int) ($prior['present_count'] ?? 0);
        $priorRate = $priorTotal > 0 ? round(($priorPresent / $priorTotal) * 100, 2) : 0.0;
        $delta = $priorTotal > 0 ? round($currRate - $priorRate, 2) : 0.0;

        // Daily trendline (last 30 active recorded school days in period)
        $dailySeries = Database::fetchAll(
            "SELECT student_attendance.attendance_date,
                    COUNT(*) AS total,
                    SUM(CASE WHEN student_attendance.status = 'present' THEN 1 ELSE 0 END) AS present
             FROM student_attendance
             {$classJoin}
             WHERE student_attendance.school_id = ? AND student_attendance.attendance_date BETWEEN ? AND ? {$whereClass}
             GROUP BY student_attendance.attendance_date
             ORDER BY student_attendance.attendance_date ASC
             LIMIT 30",
            $dailyParams
        );

        $dailyFormatted = [];
        foreach ($dailySeries as $row) {
            $tot = (int) $row['total'];
            $pres = (int) $row['present'];
            $rate = $tot > 0 ? round(($pres / $tot) * 100, 1) : 0.0;
            $dailyFormatted[] = [
                'date' => $row['attendance_date'],
                'rate' => $rate,
                'present' => $pres,
                'total' => $tot,
            ];
        }

        return [
            'has_sufficient_data' => ($schoolDays >= 3),
            'recorded_school_days' => $schoolDays,
            'total_record_entries' => $totalRecs,
            'present_count' => $presentCount,
            'absent_count' => $absentCount,
            'late_count' => $lateCount,
            'overall_attendance_rate' => $currRate,
            'prior_period_rate' => $priorRate,
            'percentage_delta' => $delta,
            'daily_trend' => $dailyFormatted,
        ];
    }

    /**
     * Compute verified fee invoicing, collections, overdue aging, and comparison deltas.
     */
    private function compileFinanceMetrics(int $schoolId, string $start, string $end, string $compStart, string $compEnd): array
    {
        // Current Period Invoices
        $invoices = Database::fetch(
            'SELECT 
                COALESCE(SUM(total_amount), 0) AS total_invoiced,
                COALESCE(SUM(paid_amount), 0) AS total_collected_on_invoices,
                COALESCE(SUM(CASE WHEN status IN ("unpaid", "partial") AND due_date < CURDATE() THEN (total_amount - paid_amount) ELSE 0 END), 0) AS overdue_arrears,
                COUNT(CASE WHEN status IN ("unpaid", "partial") AND due_date < CURDATE() THEN 1 END) AS overdue_count,
                COUNT(*) AS total_invoices_issued
             FROM student_fee_invoices
             WHERE school_id = ? AND invoice_date BETWEEN ? AND ? AND status != "cancelled"',
            [$schoolId, $start, $end]
        );

        // Payments collected within exact date range
        $payments = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS direct_collected, COUNT(*) AS count_payments
             FROM payments
             WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
            [$schoolId, $start, $end]
        );

        // Comparison Period Payments
        $priorPayments = Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS direct_collected
             FROM payments
             WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
            [$schoolId, $compStart, $compEnd]
        );

        $invoiced = round((float) ($invoices['total_invoiced'] ?? 0.0), 2);
        $collected = round((float) ($payments['direct_collected'] ?? 0.0), 2);
        $overdue = round((float) ($invoices['overdue_arrears'] ?? 0.0), 2);
        $overdueCount = (int) ($invoices['overdue_count'] ?? 0);
        $invoicesCount = (int) ($invoices['total_invoices_issued'] ?? 0);

        $priorCollected = round((float) ($priorPayments['direct_collected'] ?? 0.0), 2);
        $revenueDelta = $priorCollected > 0 ? round((($collected - $priorCollected) / $priorCollected) * 100, 1) : 0.0;
        $efficiencyRate = $invoiced > 0 ? round(($collected / $invoiced) * 100, 1) : ($collected > 0 ? 100.0 : 0.0);

        return [
            'has_sufficient_data' => ($invoicesCount > 0 || $collected > 0),
            'total_invoiced' => $invoiced,
            'total_collected' => $collected,
            'overdue_arrears' => $overdue,
            'overdue_invoices_count' => $overdueCount,
            'total_invoices_count' => $invoicesCount,
            'collection_efficiency_rate' => $efficiencyRate,
            'prior_period_collected' => $priorCollected,
            'revenue_growth_percentage' => $revenueDelta,
        ];
    }

    /**
     * Compute verified examination marks, pass rates, and subject distributions.
     */
    private function compileAcademicMetrics(int $schoolId, string $start, string $end, ?int $classId = null): array
    {
        $exams = Database::fetchAll(
            'SELECT e.id, e.name, e.academic_year_id, COUNT(em.id) AS marks_count
             FROM exams e
             LEFT JOIN exam_marks em ON em.exam_id = e.id AND em.school_id = e.school_id
             WHERE e.school_id = ? AND e.status = "published"
             GROUP BY e.id, e.name, e.academic_year_id
             ORDER BY e.id DESC LIMIT 5',
            [$schoolId]
        );

        if (empty($exams)) {
            return [
                'has_sufficient_data' => false,
                'published_exams_count' => 0,
                'total_marks_evaluated' => 0,
                'overall_pass_rate' => 0.0,
                'average_score_percentage' => 0.0,
                'subject_breakdown' => [],
            ];
        }

        $marksJoin = '';
        $marksWhere = '';
        $marksParams = [$schoolId];
        $subJoin = '';
        $subWhere = '';
        $subParams = [$schoolId];

        if ($classId !== null && $classId > 0) {
            $marksJoin = ' JOIN students st ON st.id = em.student_id AND st.school_id = em.school_id ';
            $marksWhere = ' AND st.class_id = ? ';
            $marksParams[] = $classId;

            $subJoin = ' JOIN students st ON st.id = em.student_id AND st.school_id = em.school_id ';
            $subWhere = ' AND st.class_id = ? ';
            $subParams[] = $classId;
        }

        // Aggregate marks across published exams
        $marksStats = Database::fetch(
            "SELECT 
                COUNT(*) AS total_marks_entries,
                AVG((em.marks_obtained / es.max_marks) * 100) AS avg_percentage,
                SUM(CASE WHEN (em.marks_obtained / es.max_marks) >= 0.40 THEN 1 ELSE 0 END) AS passing_entries
             FROM exam_marks em
             JOIN exams e ON e.id = em.exam_id AND e.school_id = em.school_id
             JOIN exam_subjects es ON es.id = em.exam_subject_id AND es.school_id = em.school_id
             {$marksJoin}
             WHERE em.school_id = ? AND e.status = 'published' {$marksWhere}",
            $marksParams
        );

        $totalMarks = (int) ($marksStats['total_marks_entries'] ?? 0);
        $passingMarks = (int) ($marksStats['passing_entries'] ?? 0);
        $avgScore = round((float) ($marksStats['avg_percentage'] ?? 0.0), 1);
        $passRate = $totalMarks > 0 ? round(($passingMarks / $totalMarks) * 100, 1) : 0.0;

        // Subject Breakdown
        $subjectRows = Database::fetchAll(
            "SELECT s.name AS subject_name,
                    COUNT(em.id) AS student_count,
                    AVG((em.marks_obtained / es.max_marks) * 100) AS subject_avg,
                    SUM(CASE WHEN (em.marks_obtained / es.max_marks) >= 0.40 THEN 1 ELSE 0 END) AS subject_pass
             FROM exam_marks em
             JOIN exams e ON e.id = em.exam_id AND e.school_id = em.school_id
             JOIN exam_subjects es ON es.id = em.exam_subject_id AND es.school_id = em.school_id
             JOIN subjects s ON s.id = es.subject_id AND s.school_id = em.school_id
             {$subJoin}
             WHERE em.school_id = ? AND e.status = 'published' {$subWhere}
             GROUP BY s.id, s.name
             ORDER BY subject_avg ASC LIMIT 8",
            $subParams
        );

        $subjectBreakdown = [];
        foreach ($subjectRows as $row) {
            $cnt = (int) $row['student_count'];
            $pss = (int) $row['subject_pass'];
            $subjectBreakdown[] = [
                'subject' => $row['subject_name'],
                'average_score' => round((float) $row['subject_avg'], 1),
                'pass_rate' => $cnt > 0 ? round(($pss / $cnt) * 100, 1) : 0.0,
                'candidates' => $cnt,
            ];
        }

        return [
            'has_sufficient_data' => ($totalMarks >= 5),
            'published_exams_count' => count($exams),
            'total_marks_evaluated' => $totalMarks,
            'overall_pass_rate' => $passRate,
            'average_score_percentage' => $avgScore,
            'subject_breakdown' => $subjectBreakdown,
        ];
    }

    /**
     * Compute verified student enrollment demographics and growth.
     */
    private function compileEnrollmentMetrics(int $schoolId, string $start, string $end, ?int $classId = null): array
    {
        $whereClass = '';
        $params = [$start . ' 00:00:00', $end . ' 23:59:59', $schoolId];
        if ($classId !== null && $classId > 0) {
            $whereClass = ' AND class_id = ? ';
            $params[] = $classId;
        }

        $counts = Database::fetch(
            "SELECT 
                COUNT(*) AS total_students,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_students,
                SUM(CASE WHEN gender = 'male' THEN 1 ELSE 0 END) AS male_students,
                SUM(CASE WHEN gender = 'female' THEN 1 ELSE 0 END) AS female_students,
                SUM(CASE WHEN created_at BETWEEN ? AND ? THEN 1 ELSE 0 END) AS new_admissions
             FROM students
             WHERE school_id = ? {$whereClass}",
            $params
        );

        return [
            'total_students' => (int) ($counts['total_students'] ?? 0),
            'active_students' => (int) ($counts['active_students'] ?? 0),
            'male_students' => (int) ($counts['male_students'] ?? 0),
            'female_students' => (int) ($counts['female_students'] ?? 0),
            'new_admissions_in_period' => (int) ($counts['new_admissions'] ?? 0),
        ];
    }

    /**
     * Compute staff and teacher operational presence.
     */
    private function compileStaffMetrics(int $schoolId): array
    {
        $staffCount = Database::fetch('SELECT COUNT(*) AS c FROM employees WHERE school_id = ?', [$schoolId]);
        $teacherCount = Database::fetch('SELECT COUNT(*) AS c FROM teachers WHERE school_id = ?', [$schoolId]);

        return [
            'total_staff' => (int) ($staffCount['c'] ?? 0),
            'active_teachers' => (int) ($teacherCount['c'] ?? 0),
        ];
    }

    /**
     * Deterministic Anomaly & Attention Flag Detection.
     */
    private function detectAnomalies(array $att, array $fin, array $acad): array
    {
        $anomalies = [];

        // 1. Attendance Anomaly: Low Overall Rate or Substantial Drop
        if ($att['has_sufficient_data']) {
            if ($att['overall_attendance_rate'] < 80.0) {
                $anomalies[] = [
                    'category' => 'attendance',
                    'severity' => 'critical',
                    'title' => 'Critical Attendance Deficit',
                    'message' => "Institutional attendance rate is currently at {$att['overall_attendance_rate']}%, which is below the mandatory 80% benchmark.",
                ];
            } elseif ($att['percentage_delta'] <= -5.0) {
                $anomalies[] = [
                    'category' => 'attendance',
                    'severity' => 'warning',
                    'title' => 'Negative Attendance Trend',
                    'message' => "Attendance declined by {$att['percentage_delta']}% compared to the prior comparison cycle.",
                ];
            }

            // Daily spike checks
            foreach ($att['daily_trend'] as $day) {
                if ($day['rate'] < 70.0 && $day['total'] >= 5) {
                    $anomalies[] = [
                        'category' => 'attendance',
                        'severity' => 'warning',
                        'title' => "Unusual Attendance Dip on {$day['date']}",
                        'message' => "Attendance plummeted to {$day['rate']}% on {$day['date']} ({$day['present']}/{$day['total']} students present).",
                    ];
                    break;
                }
            }
        }

        // 2. Financial Anomaly: High Overdue Arrears or Low Collection Efficiency
        if ($fin['has_sufficient_data']) {
            if ($fin['overdue_arrears'] > 50000.0 || $fin['overdue_invoices_count'] >= 10) {
                $anomalies[] = [
                    'category' => 'finance',
                    'severity' => 'critical',
                    'title' => 'High Overdue Receivables',
                    'message' => "{$fin['overdue_invoices_count']} overdue fee invoices totaling \${$fin['overdue_arrears']} require immediate cashier action.",
                ];
            } elseif ($fin['collection_efficiency_rate'] < 50.0 && $fin['total_invoiced'] > 0) {
                $anomalies[] = [
                    'category' => 'finance',
                    'severity' => 'warning',
                    'title' => 'Fee Collection Below Benchmark',
                    'message' => "Fee collection efficiency is at {$fin['collection_efficiency_rate']}%, reflecting delayed parent settlements.",
                ];
            }
        }

        // 3. Academic Anomaly: Low Subject Pass Rate
        if ($acad['has_sufficient_data'] && !empty($acad['subject_breakdown'])) {
            $lowestSubject = $acad['subject_breakdown'][0];
            if ($lowestSubject['pass_rate'] < 60.0) {
                $anomalies[] = [
                    'category' => 'academics',
                    'severity' => 'warning',
                    'title' => "Academic Remedial Need: {$lowestSubject['subject']}",
                    'message' => "{$lowestSubject['subject']} has a pass rate of only {$lowestSubject['pass_rate']}% (Class Average: {$lowestSubject['average_score']}%), indicating a need for curriculum reinforcement.",
                ];
            }
        }

        // If no negative anomalies found, add positive reinforcement
        if (empty($anomalies)) {
            $anomalies[] = [
                'category' => 'general',
                'severity' => 'positive',
                'title' => 'Operations Within Standard Tolerances',
                'message' => 'Attendance, fee collection, and academic indicators are operating within expected institutional baselines.',
            ];
        }

        return $anomalies;
    }

    /**
     * Generate Role-Specific AI Executive Insight via native LLM service.
     * Uses heuristic fallback derived from verified numbers if LLM keys are unconfigured.
     */
    private function generateAiExecutiveInsight(
        string $schoolName,
        string $schoolCode,
        string $periodName,
        string $role,
        array $stats,
        array $anomalies
    ): array {
        $att = $stats['attendance'];
        $fin = $stats['finance'];
        $acad = $stats['academics'];
        $enr = $stats['enrollment'];

        // Check if LLM provider has valid API key
        $hasKey = $this->llmService->hasApiKey('gemini') || $this->llmService->hasApiKey('openai');

        if (!$hasKey) {
            // Heuristic Rule-Based Synthesis: 100% grounded in verified statistics, zero fake figures!
            return $this->synthesizeHeuristicSchoolInsight($schoolName, $periodName, $role, $stats, $anomalies);
        }

        // System prompt with strict verification instructions
        $systemPrompt = <<<PROMPT
You are "CodeClove Analytics Copilot", an executive educational data analyst for {$schoolName} ({$schoolCode}).
Target User Role: {$role}
Reporting Period: {$periodName}

=== SECURITY & VERACITY MANDATE ===
1. Ground ALL observations strictly in the verified database metrics enclosed in <verified_metrics>.
2. Never invent student names, fake numbers, or unrecorded figures.
3. Distinguish verified database facts by prefixing official records with [VERIFIED_STATISTICS].
4. Prefix strategic suggestions and trend interpretations with [AI_INTERPRETATION].
5. Format the response into 4 distinct sections:
   - ### 📊 Executive Summary
   - ### 🔍 Key Trends & Behavioral Observations
   - ### ⚠️ Attention Areas & Remedial Priorities
   - ### 💡 Recommended Administrative Actions
PROMPT;

        $metricsContext = "<verified_metrics>\n"
            . "- Attendance: {$att['overall_attendance_rate']}% (Prior: {$att['prior_period_rate']}%, Delta: {$att['percentage_delta']}%, Days Recorded: {$att['recorded_school_days']})\n"
            . "- Financials: Invoiced \${$fin['total_invoiced']} | Collected \${$fin['total_collected']} | Overdue Arrears: \${$fin['overdue_arrears']} ({$fin['overdue_invoices_count']} invoices) | Efficiency: {$fin['collection_efficiency_rate']}%\n"
            . "- Academics: Pass Rate: {$acad['overall_pass_rate']}% | Average Score: {$acad['average_score_percentage']}% | Published Exams: {$acad['published_exams_count']}\n"
            . "- Enrollment: Total Active Students: {$enr['active_students']} | New Admissions: {$enr['new_admissions_in_period']}\n"
            . "- Detected Anomaly Count: " . count($anomalies) . "\n"
            . "</verified_metrics>";

        $userMessage = "Generate a concise, high-impact executive analytical brief for this {$periodName} cycle customized for my {$role} purview.";

        $completion = $this->llmService->complete($systemPrompt, [['role' => 'user', 'content' => $userMessage]]);

        if (!$completion['success'] || empty($completion['content'])) {
            return $this->synthesizeHeuristicSchoolInsight($schoolName, $periodName, $role, $stats, $anomalies);
        }

        return [
            'executive_summary' => $completion['content'],
            'is_ai_generated' => true,
            'provider' => $completion['provider'] ?? 'gemini',
            'model' => $completion['model'] ?? 'gemini-1.5-flash',
            'confidence' => 'verified_grounded',
        ];
    }

    /**
     * Heuristic synthesis engine when external cloud API is offline or unconfigured.
     * Strictly computes insights directly from the verified database figures without hallucinations.
     */
    private function synthesizeHeuristicSchoolInsight(
        string $schoolName,
        string $periodName,
        string $role,
        array $stats,
        array $anomalies
    ): array {
        $att = $stats['attendance'];
        $fin = $stats['finance'];
        $acad = $stats['academics'];
        $enr = $stats['enrollment'];

        $summary = "### 📊 Executive Summary ({$periodName})\n\n"
            . "[VERIFIED_STATISTICS] During this reporting period, **{$schoolName}** maintained an overall student attendance rate of **{$att['overall_attendance_rate']}%** over {$att['recorded_school_days']} recorded instructional days. ";

        if ($att['has_sufficient_data'] && $att['percentage_delta'] != 0.0) {
            $trendSign = $att['percentage_delta'] > 0 ? '+' : '';
            $summary .= "Attendance showed a **{$trendSign}{$att['percentage_delta']}%** variance compared to the prior comparison cycle. ";
        }

        $summary .= "\n\nOn the financial ledger, **\${$fin['total_collected']}** was collected against **\${$fin['total_invoiced']}** in tuition and fee billings (Collection Efficiency: **{$fin['collection_efficiency_rate']}%**). Outstanding overdue debt stands at **\${$fin['overdue_arrears']}** across {$fin['overdue_invoices_count']} pending invoices.\n\n";

        if ($acad['has_sufficient_data']) {
            $summary .= "Academic evaluations across {$acad['published_exams_count']} published examinations achieved an overall pass rate of **{$acad['overall_pass_rate']}%** with an institutional score average of **{$acad['average_score_percentage']}%**.\n\n";
        } else {
            $summary .= "*Note: Insufficient examination records in this period to establish full academic pass rate trends.*\n\n";
        }

        $summary .= "### 🔍 [AI_INTERPRETATION] Key Trends & Observations\n"
            . "- **Attendance Stability**: " . ($att['overall_attendance_rate'] >= 85.0 ? 'Consistent and robust student classroom presence.' : 'Attendance fluctuates below optimal 85% benchmarks; targeted student follow-up recommended.') . "\n"
            . "- **Receivables Aging**: " . ($fin['overdue_arrears'] > 25000.0 ? 'Overdue fee accumulation represents a primary cashflow bottleneck.' : 'Tuition receivables are well-managed within standard recovery cycles.') . "\n";

        if (!empty($acad['subject_breakdown'])) {
            $lowest = $acad['subject_breakdown'][0];
            $summary .= "- **Curriculum Spotlight**: {$lowest['subject']} demonstrates the highest remedial opportunity with a pass rate of {$lowest['pass_rate']}%.\n";
        }

        $summary .= "\n### 💡 Recommended Administrative Actions\n";
        if ($fin['overdue_invoices_count'] > 0) {
            $summary .= "1. **Issue Automated SMS & Email Reminders**: Send targeted reminder notices to the {$fin['overdue_invoices_count']} guardians with overdue balances.\n";
        }
        if ($att['overall_attendance_rate'] < 90.0) {
            $summary .= "2. **Review Class Absence Patterns**: Engage grade teachers to verify unexcused absences and offer student support.\n";
        }
        $summary .= "3. **Conduct Subject Remedial Sessions**: Reinforce subject areas with pass rates below 70% before final examinations.\n";

        return [
            'executive_summary' => $summary,
            'is_ai_generated' => false,
            'provider' => 'deterministic_heuristic_engine',
            'model' => 'verified_rules_v1',
            'confidence' => '100%_database_grounded',
        ];
    }

    /**
     * Generate Platform-Level AI Summary for Super Admin.
     */
    private function generatePlatformAiInsight(array $stats, array $anomalies, int $days): array
    {
        $ten = $stats['tenants'];
        $rev = $stats['revenue'];

        $summary = "### 🏢 SaaS Platform Executive Intelligence ({$days}-Day Cycle)\n\n"
            . "[VERIFIED_STATISTICS] Across all platform clusters, **{$ten['total']} total institutions** are provisioned ({$ten['active']} Active, {$ten['trial']} Onboarding Trials, {$ten['suspended']} Suspended).\n\n"
            . "Subscription billings totaled **\${$rev['current_period_amount']}** in the last {$days} days (Growth: **{$rev['growth_percentage']}%** vs prior cycle). Total active platform student capacity stands at **" . number_format($stats['platform_students']) . " students**.\n\n"
            . "### 🛡️ [AI_INTERPRETATION] Infrastructure & Platform Health\n"
            . "- Disaster Recovery Vault: {$stats['vault']['completed_backups']} verified automated encrypted snapshots on file (Latest: {$stats['vault']['latest_backup']}).\n"
            . "- Tenant Expansion: Trial conversion and plan tier upgrades represent key growth drivers for upcoming cycle.";

        return [
            'executive_summary' => $summary,
            'is_ai_generated' => false,
            'provider' => 'platform_engine',
            'model' => 'verified_platform_v1',
            'confidence' => '100%_database_grounded',
        ];
    }

    /**
     * Compute verified cohort & grade-level performance breakdown across all classes.
     */
    private function compileCohortBreakdown(int $schoolId, string $start, string $end, ?int $teacherId = null, ?int $classId = null): array
    {
        $query = 'SELECT c.id AS class_id, c.name AS class_name,
                         COUNT(DISTINCT s.id) AS student_count
                  FROM classes c
                  LEFT JOIN students s ON s.class_id = c.id AND s.school_id = c.school_id AND s.status = "active"
                  WHERE c.school_id = ?';
        $params = [$schoolId];

        if ($classId !== null && $classId > 0) {
            $query .= ' AND c.id = ? ';
            $params[] = $classId;
        } elseif ($teacherId !== null) {
            $query .= ' AND (c.id IN (SELECT class_id FROM teacher_assignments WHERE teacher_id = ? AND school_id = ?) OR c.id IN (SELECT class_id FROM timetables WHERE teacher_id = ? AND school_id = ?))';
            $params[] = $teacherId;
            $params[] = $schoolId;
            $params[] = $teacherId;
            $params[] = $schoolId;
        }

        $query .= ' GROUP BY c.id, c.name ORDER BY c.name ASC';
        $classes = Database::fetchAll($query, $params);

        $cohorts = [];
        foreach ($classes as $cls) {
            $classId = (int) $cls['class_id'];
            $studentCount = (int) $cls['student_count'];

            // Attendance for this class in period
            $att = Database::fetch(
                'SELECT 
                    COUNT(*) AS total_entries,
                    SUM(CASE WHEN sa.status = "present" THEN 1 ELSE 0 END) AS present_count
                 FROM student_attendance sa
                 JOIN students st ON st.id = sa.student_id AND st.school_id = sa.school_id
                 WHERE sa.school_id = ? AND st.class_id = ? AND sa.attendance_date BETWEEN ? AND ?',
                [$schoolId, $classId, $start, $end]
            );

            $attTotal = (int) ($att['total_entries'] ?? 0);
            $attPres = (int) ($att['present_count'] ?? 0);
            $attRate = $attTotal > 0 ? round(($attPres / $attTotal) * 100, 1) : 100.0;

            // Academic pass rate for this class
            $marks = Database::fetch(
                'SELECT 
                    COUNT(*) AS total_marks,
                    AVG((em.marks_obtained / es.max_marks) * 100) AS avg_score,
                    SUM(CASE WHEN (em.marks_obtained / es.max_marks) >= 0.40 THEN 1 ELSE 0 END) AS pass_count
                 FROM exam_marks em
                 JOIN exams e ON e.id = em.exam_id AND e.school_id = em.school_id
                 JOIN exam_subjects es ON es.id = em.exam_subject_id AND es.school_id = em.school_id
                 JOIN students st ON st.id = em.student_id AND st.school_id = em.school_id
                 WHERE em.school_id = ? AND st.class_id = ? AND e.status = "published"',
                [$schoolId, $classId]
            );

            $totalMarks = (int) ($marks['total_marks'] ?? 0);
            $passCount = (int) ($marks['pass_count'] ?? 0);
            $avgScore = round((float) ($marks['avg_score'] ?? 0.0), 1);
            $passRate = $totalMarks > 0 ? round(($passCount / $totalMarks) * 100, 1) : 0.0;

            // Risk category
            $riskCategory = 'normal';
            if ($attTotal >= 5 && $attRate < 80.0) {
                $riskCategory = 'attendance_risk';
            } elseif ($totalMarks >= 5 && $passRate < 60.0) {
                $riskCategory = 'academic_risk';
            }

            $cohorts[] = [
                'class_id' => $classId,
                'class_name' => $cls['class_name'],
                'student_count' => $studentCount,
                'attendance_rate' => $attRate,
                'recorded_attendance_entries' => $attTotal,
                'evaluations_count' => $totalMarks,
                'average_score' => $avgScore,
                'pass_rate' => $passRate,
                'risk_category' => $riskCategory,
            ];
        }

        return $cohorts;
    }

    /**
     * Compute verified monthly financial trajectory (Past 6 calendar months) and 30-day projection.
     */
    private function compileMonthlyFinanceTrajectory(int $schoolId): array
    {
        $months = [];
        for ($i = 5; $i >= 0; $i--) {
            $mStart = date('Y-m-01', strtotime("-{$i} months"));
            $mEnd = date('Y-m-t', strtotime("-{$i} months"));
            $mLabel = date('M Y', strtotime($mStart));

            $inv = Database::fetch(
                'SELECT COALESCE(SUM(total_amount), 0) AS invoiced
                 FROM student_fee_invoices
                 WHERE school_id = ? AND invoice_date BETWEEN ? AND ? AND status != "cancelled"',
                [$schoolId, $mStart, $mEnd]
            );

            $pay = Database::fetch(
                'SELECT COALESCE(SUM(amount), 0) AS collected
                 FROM payments
                 WHERE school_id = ? AND payment_date BETWEEN ? AND ?',
                [$schoolId, $mStart, $mEnd]
            );

            $invoiced = round((float) ($inv['invoiced'] ?? 0.0), 2);
            $collected = round((float) ($pay['collected'] ?? 0.0), 2);
            $eff = $invoiced > 0 ? round(($collected / $invoiced) * 100, 1) : ($collected > 0 ? 100.0 : 0.0);

            $months[] = [
                'month_key' => date('Y-m', strtotime($mStart)),
                'label' => $mLabel,
                'invoiced' => $invoiced,
                'collected' => $collected,
                'efficiency_rate' => $eff,
            ];
        }

        $recentCollected = 0.0;
        $count = 0;
        for ($k = 3; $k < 6; $k++) {
            if (isset($months[$k])) {
                $recentCollected += $months[$k]['collected'];
                $count++;
            }
        }
        $avgMonthlyVelocity = $count > 0 ? round($recentCollected / $count, 2) : 0.0;

        return [
            'access_restricted' => false,
            'history' => $months,
            'rolling_monthly_velocity' => $avgMonthlyVelocity,
            'projected_collection_30d' => $avgMonthlyVelocity,
        ];
    }

    /**
     * Compute verified staff attendance rate and presence metrics.
     */
    private function compileStaffAttendanceMetrics(int $schoolId, string $start, string $end): array
    {
        $agg = Database::fetch(
            'SELECT 
                COUNT(*) AS total_entries,
                SUM(CASE WHEN status = "present" THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN status = "absent" THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN status = "late" THEN 1 ELSE 0 END) AS late_count,
                COUNT(DISTINCT attendance_date) AS recorded_days
             FROM staff_attendance
             WHERE school_id = ? AND attendance_date BETWEEN ? AND ?',
            [$schoolId, $start, $end]
        );

        $total = (int) ($agg['total_entries'] ?? 0);
        $present = (int) ($agg['present_count'] ?? 0);
        $absent = (int) ($agg['absent_count'] ?? 0);
        $late = (int) ($agg['late_count'] ?? 0);
        $days = (int) ($agg['recorded_days'] ?? 0);
        $rate = $total > 0 ? round(($present / $total) * 100, 2) : 100.0;

        return [
            'has_sufficient_data' => ($days >= 1),
            'total_entries' => $total,
            'present_count' => $present,
            'absent_count' => $absent,
            'late_count' => $late,
            'recorded_days' => $days,
            'staff_attendance_rate' => $rate,
        ];
    }

    /**
     * Generate predictive risk scores and targeted pedagogical/operational recommendations.
     */
    private function generatePredictiveInsights(int $schoolId, array $att, array $fin, array $acad, array $cohorts, string $role): array
    {
        $insights = [];

        // 1. Academic Performance Support & Remedial Insights
        if (!empty($acad['subject_breakdown'])) {
            foreach ($acad['subject_breakdown'] as $sub) {
                if ($sub['pass_rate'] < 65.0) {
                    $insights[] = [
                        'type' => 'academic_remedial',
                        'severity' => ($sub['pass_rate'] < 50.0) ? 'high' : 'medium',
                        'target' => $sub['subject'],
                        'headline' => "Curriculum Intervention Recommended for {$sub['subject']}",
                        'evidence' => "[VERIFIED_STATISTICS] {$sub['subject']} pass rate is {$sub['pass_rate']}% across {$sub['candidates']} evaluated candidates (Subject Avg: {$sub['average_score']}%).",
                        'recommendation' => "[AI_INTERPRETATION] Organize weekly targeted problem-solving clinics and formative revision tests for {$sub['subject']}.",
                        'certainty' => ($sub['candidates'] >= 5) ? 'high' : 'provisional_low_sample',
                    ];
                }
            }
        }

        // 2. Attendance & Truancy Early Warnings
        if (!empty($cohorts)) {
            foreach ($cohorts as $coh) {
                if ($coh['recorded_attendance_entries'] >= 5 && $coh['attendance_rate'] < 82.0) {
                    $insights[] = [
                        'type' => 'attendance_retention',
                        'severity' => ($coh['attendance_rate'] < 75.0) ? 'high' : 'medium',
                        'target' => $coh['class_name'],
                        'headline' => "Attendance Alert for {$coh['class_name']}",
                        'evidence' => "[VERIFIED_STATISTICS] Cohort {$coh['class_name']} logged an attendance rate of {$coh['attendance_rate']}% over the evaluated reporting cycle.",
                        'recommendation' => "[AI_INTERPRETATION] Initiate student counseling outreach and verify guardian communication records for persistent absences.",
                        'certainty' => 'high',
                    ];
                }
            }
        }

        // 3. Financial Cashflow & Arrears Trajectory (Only if role authorized)
        if (empty($fin['access_restricted']) && !empty($fin['has_sufficient_data'])) {
            if ($fin['overdue_arrears'] > 10000.0) {
                $insights[] = [
                    'type' => 'cashflow_recovery',
                    'severity' => ($fin['overdue_arrears'] > 50000.0) ? 'high' : 'medium',
                    'target' => 'Tuition Receivables',
                    'headline' => 'Receivables Aging Acceleration Detected',
                    'evidence' => "[VERIFIED_STATISTICS] Overdue arrears reached \${$fin['overdue_arrears']} across {$fin['overdue_invoices_count']} invoices (Current Collection Efficiency: {$fin['collection_efficiency_rate']}%).",
                    'recommendation' => "[AI_INTERPRETATION] Trigger automated multi-channel payment reminders (SMS/Email) with flexible instalment options.",
                    'certainty' => 'high',
                ];
            }
        }

        // 4. Data Uncertainty / Sparse Warning
        if (empty($acad['has_sufficient_data'])) {
            $insights[] = [
                'type' => 'data_sufficiency_notice',
                'severity' => 'info',
                'target' => 'Academic Evaluations',
                'headline' => 'Insufficient Examination Records',
                'evidence' => "[VERIFIED_STATISTICS] Fewer than 5 examination mark entries recorded in current period.",
                'recommendation' => "[DATA_SPARSE_WARNING] Formal subject trajectory models deferred until mid-term grade reports are submitted.",
                'certainty' => 'provisional',
            ];
        }

        return $insights;
    }

    /**
     * Resolve teacher ID from user ID.
     */
    public function resolveTeacherId(int $schoolId, int $userId): ?int
    {
        $teacher = Database::fetch(
            'SELECT t.id 
             FROM teachers t 
             LEFT JOIN employees e ON e.id = t.employee_id AND e.school_id = t.school_id
             WHERE t.school_id = ? AND (e.email = (SELECT email FROM users WHERE id = ?) OR e.id = (SELECT employee_id FROM users WHERE id = ?)) 
             LIMIT 1',
            [$schoolId, $userId, $userId]
        );
        return $teacher ? (int) $teacher['id'] : null;
    }

    /**
     * Get authorized classes for a user based on their role.
     */
    public function getAuthorizedClasses(int $schoolId, string $role, ?int $teacherId = null): array
    {
        if ($role === 'teacher' && $teacherId !== null) {
            return Database::fetchAll(
                'SELECT DISTINCT c.id, c.name 
                 FROM classes c 
                 WHERE c.school_id = ? 
                   AND (c.id IN (SELECT class_id FROM teacher_assignments WHERE teacher_id = ? AND school_id = ?) 
                     OR c.id IN (SELECT class_id FROM timetables WHERE teacher_id = ? AND school_id = ?))
                 ORDER BY c.name ASC',
                [$schoolId, $teacherId, $schoolId, $teacherId, $schoolId]
            );
        }

        return Database::fetchAll(
            'SELECT id, name FROM classes WHERE school_id = ? ORDER BY name ASC',
            [$schoolId]
        );
    }

    /**
     * Fetch granular drill-down metrics for all students in a specific class cohort.
     */
    public function getStudentCohortDrilldown(
        int $schoolId,
        int $classId,
        string $period = 'last_30_days',
        ?string $customStart = null,
        ?string $customEnd = null,
        string $role = 'school_admin',
        ?int $teacherUserId = null
    ): array {
        // Validate class tenant ownership
        $class = Database::fetch('SELECT id, name FROM classes WHERE id = ? AND school_id = ? LIMIT 1', [$classId, $schoolId]);
        if (!$class) {
            return [
                'status' => 'error',
                'message' => 'Class cohort not found or unauthorized tenant context.',
                'students' => []
            ];
        }

        // Teacher RBAC verification
        $isTeacher = ($role === 'teacher');
        $teacherId = null;
        if ($isTeacher) {
            $teacherId = $this->resolveTeacherId($schoolId, (int)$teacherUserId);
            $authorizedClasses = $this->getAuthorizedClasses($schoolId, $role, $teacherId);
            $authIds = array_column($authorizedClasses, 'id');
            if (!in_array($classId, $authIds, true)) {
                return [
                    'status' => 'error',
                    'message' => 'Access Restricted: You are not authorized to view cohorts outside your assigned curriculum.',
                    'students' => []
                ];
            }
        }

        $dates = $this->resolvePeriodDates($period, $customStart, $customEnd);
        $start = $dates['current_start'];
        $end = $dates['current_end'];

        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.roll_no, s.first_name, s.last_name, s.gender, s.status,
                    sec.name AS section_name
             FROM students s
             LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
             WHERE s.school_id = ? AND s.class_id = ? AND s.status = "active"
             ORDER BY s.roll_no ASC, s.first_name ASC',
            [$schoolId, $classId]
        );

        $isFinanceAuthorized = in_array($role, ['admin', 'school_admin', 'principal', 'accountant', 'finance'], true);

        $drilldown = [];
        $totalAttRate = 0.0;
        $totalScore = 0.0;
        $evaluatedStudents = 0;
        $activeCount = count($students);

        foreach ($students as $st) {
            $sId = (int) $st['id'];
            $fullName = trim("{$st['first_name']} {$st['last_name']}");

            // Student attendance in period
            $att = Database::fetch(
                'SELECT 
                    COUNT(*) AS total_days,
                    SUM(CASE WHEN status = "present" THEN 1 ELSE 0 END) AS pres,
                    SUM(CASE WHEN status = "absent" THEN 1 ELSE 0 END) AS abs,
                    SUM(CASE WHEN status = "late" THEN 1 ELSE 0 END) AS lte
                 FROM student_attendance
                 WHERE school_id = ? AND student_id = ? AND attendance_date BETWEEN ? AND ?',
                [$schoolId, $sId, $start, $end]
            );

            $attTotal = (int) ($att['total_days'] ?? 0);
            $pres = (int) ($att['pres'] ?? 0);
            $abs = (int) ($att['abs'] ?? 0);
            $lte = (int) ($att['lte'] ?? 0);
            $attRate = $attTotal > 0 ? round(($pres / $attTotal) * 100, 1) : 100.0;
            $totalAttRate += $attRate;

            // Student academic evaluations
            $marks = Database::fetch(
                'SELECT 
                    COUNT(*) AS marks_count,
                    AVG((em.marks_obtained / es.max_marks) * 100) AS avg_pct,
                    SUM(CASE WHEN (em.marks_obtained / es.max_marks) >= 0.40 THEN 1 ELSE 0 END) AS passing
                 FROM exam_marks em
                 JOIN exams e ON e.id = em.exam_id AND e.school_id = em.school_id
                 JOIN exam_subjects es ON es.id = em.exam_subject_id AND es.school_id = em.school_id
                 WHERE em.school_id = ? AND em.student_id = ? AND e.status = "published"',
                [$schoolId, $sId]
            );

            $mCount = (int) ($marks['marks_count'] ?? 0);
            $avgPct = $mCount > 0 ? round((float) $marks['avg_pct'], 1) : null;
            $passCount = (int) ($marks['passing'] ?? 0);
            $passRate = $mCount > 0 ? round(($passCount / $mCount) * 100, 1) : null;
            if ($avgPct !== null) {
                $totalScore += $avgPct;
                $evaluatedStudents++;
            }

            // Fee balance if authorized
            $feeBalance = null;
            $isOverdue = false;
            if ($isFinanceAuthorized) {
                $fin = Database::fetch(
                    'SELECT 
                        COALESCE(SUM(total_amount - paid_amount), 0) AS balance_due,
                        COUNT(CASE WHEN status IN ("unpaid", "partial") AND due_date < CURDATE() THEN 1 END) AS overdue_count
                     FROM student_fee_invoices
                     WHERE school_id = ? AND student_id = ? AND status != "cancelled"',
                    [$schoolId, $sId]
                );
                $feeBalance = round((float) ($fin['balance_due'] ?? 0.0), 2);
                $isOverdue = (int) ($fin['overdue_count'] ?? 0) > 0;
            }

            // Determine Risk Badge
            $risk = 'normal';
            if ($attTotal >= 3 && $attRate < 80.0) {
                $risk = 'attendance_risk';
            } elseif ($mCount >= 2 && $avgPct !== null && $avgPct < 50.0) {
                $risk = 'academic_risk';
            } elseif ($isFinanceAuthorized && $feeBalance > 0 && $isOverdue) {
                $risk = 'fee_defaulter';
            }

            $drilldown[] = [
                'student_id' => $sId,
                'admission_no' => $st['admission_no'],
                'roll_no' => $st['roll_no'] ?? '-',
                'name' => $fullName,
                'section' => $st['section_name'] ?? 'A',
                'gender' => ucfirst($st['gender'] ?? 'unknown'),
                'attendance_rate' => $attRate,
                'present_days' => $pres,
                'absent_days' => $abs,
                'late_days' => $lte,
                'recorded_days' => $attTotal,
                'average_score' => $avgPct,
                'pass_rate' => $passRate,
                'evaluations_count' => $mCount,
                'fee_balance' => $feeBalance,
                'is_overdue' => $isOverdue,
                'risk_status' => $risk,
            ];
        }

        $classAvgAttendance = $activeCount > 0 ? round($totalAttRate / $activeCount, 1) : 100.0;
        $classAvgScore = $evaluatedStudents > 0 ? round($totalScore / $evaluatedStudents, 1) : 0.0;

        return [
            'status' => 'success',
            'class_id' => $classId,
            'class_name' => $class['name'],
            'student_count' => $activeCount,
            'class_average_attendance' => $classAvgAttendance,
            'class_average_score' => $classAvgScore,
            'evaluated_students' => $evaluatedStudents,
            'period' => $dates['label'],
            'finance_gated' => !$isFinanceAuthorized,
            'students' => $drilldown,
        ];
    }

    /**
     * Compute fee collections and overdue arrears broken down by fee category.
     */
    public function getFeeCategoryDrilldown(
        int $schoolId,
        string $start,
        string $end,
        string $role = 'school_admin'
    ): array {
        if (!in_array($role, ['admin', 'school_admin', 'principal', 'accountant', 'finance'], true)) {
            return [
                'access_restricted' => true,
                'reason' => 'Fee category financial metrics are restricted to administrative and accounts roles.',
                'categories' => []
            ];
        }

        $categories = Database::fetchAll(
            'SELECT 
                fc.id,
                fc.name,
                fc.frequency,
                COALESCE(SUM(ii.amount), 0) AS total_invoiced,
                COUNT(DISTINCT inv.id) AS invoices_count,
                COALESCE(SUM(CASE 
                    WHEN inv.status = "paid" THEN ii.amount 
                    WHEN inv.status = "partial" AND inv.total_amount > 0 THEN (ii.amount * (inv.paid_amount / inv.total_amount)) 
                    ELSE 0 END), 0) AS total_collected,
                COALESCE(SUM(CASE 
                    WHEN inv.status IN ("unpaid", "partial") AND inv.due_date < CURDATE() THEN 
                        (ii.amount - (CASE WHEN inv.status = "partial" AND inv.total_amount > 0 THEN (ii.amount * (inv.paid_amount / inv.total_amount)) ELSE 0 END))
                    ELSE 0 END), 0) AS overdue_arrears
             FROM fee_categories fc
             LEFT JOIN student_fee_invoice_items ii ON ii.fee_category_id = fc.id AND ii.school_id = fc.school_id
             LEFT JOIN student_fee_invoices inv ON inv.id = ii.invoice_id AND inv.school_id = ii.school_id 
                   AND inv.invoice_date BETWEEN ? AND ? AND inv.status != "cancelled"
             WHERE fc.school_id = ?
             GROUP BY fc.id, fc.name, fc.frequency
             ORDER BY total_invoiced DESC',
            [$start, $end, $schoolId]
        );

        $result = [];
        foreach ($categories as $cat) {
            $inv = round((float) $cat['total_invoiced'], 2);
            $col = round((float) $cat['total_collected'], 2);
            $over = round((float) $cat['overdue_arrears'], 2);
            $rate = $inv > 0 ? round(($col / $inv) * 100, 1) : ($col > 0 ? 100.0 : 0.0);

            $result[] = [
                'id' => (int) $cat['id'],
                'name' => $cat['name'],
                'frequency' => ucfirst($cat['frequency'] ?? 'one_time'),
                'total_invoiced' => $inv,
                'total_collected' => $col,
                'overdue_arrears' => $over,
                'collection_efficiency' => $rate,
                'invoices_count' => (int) $cat['invoices_count'],
            ];
        }

        return [
            'access_restricted' => false,
            'categories' => $result,
        ];
    }

    /**
     * Compute examination performance and score distributions per curriculum subject.
     */
    public function getSubjectDrilldown(int $schoolId, ?int $classId = null): array
    {
        $whereClass = '';
        $params = [$schoolId];
        if ($classId !== null && $classId > 0) {
            $whereClass = ' AND c.id = ? ';
            $params[] = $classId;
        }

        $rows = Database::fetchAll(
            "SELECT 
                s.id AS subject_id,
                s.name AS subject_name,
                c.name AS class_name,
                COUNT(em.id) AS candidate_count,
                AVG((em.marks_obtained / es.max_marks) * 100) AS avg_percentage,
                MAX((em.marks_obtained / es.max_marks) * 100) AS max_percentage,
                MIN((em.marks_obtained / es.max_marks) * 100) AS min_percentage,
                SUM(CASE WHEN (em.marks_obtained / es.max_marks) >= 0.40 THEN 1 ELSE 0 END) AS passing_candidates
             FROM subjects s
             JOIN exam_subjects es ON es.subject_id = s.id AND es.school_id = s.school_id
             JOIN exams e ON e.id = es.exam_id AND e.school_id = s.school_id
             JOIN exam_marks em ON em.exam_subject_id = es.id AND em.school_id = s.school_id
             JOIN classes c ON c.id = e.class_id AND c.school_id = s.school_id
             WHERE s.school_id = ? AND e.status = 'published' {$whereClass}
             GROUP BY s.id, s.name, c.id, c.name
             ORDER BY avg_percentage ASC",
            $params
        );

        $details = [];
        foreach ($rows as $r) {
            $cnt = (int) $r['candidate_count'];
            $pss = (int) $r['passing_candidates'];
            $avg = round((float) $r['avg_percentage'], 1);
            $passRate = $cnt > 0 ? round(($pss / $cnt) * 100, 1) : 0.0;

            $details[] = [
                'subject_id' => (int) $r['subject_id'],
                'subject_name' => $r['subject_name'],
                'class_name' => $r['class_name'],
                'candidate_count' => $cnt,
                'average_score' => $avg,
                'highest_score' => round((float) $r['max_percentage'], 1),
                'lowest_score' => round((float) $r['min_percentage'], 1),
                'pass_rate' => $passRate,
                'passing_candidates' => $pss,
                'failing_candidates' => max(0, $cnt - $pss),
                'needs_support' => ($passRate < 65.0),
            ];
        }

        return $details;
    }

    /**
     * Identify students suffering chronic absenteeism below specified benchmark.
     */
    public function getAttendanceDefaulters(
        int $schoolId,
        string $start,
        string $end,
        ?int $classId = null,
        float $threshold = 75.0,
        string $role = 'school_admin',
        ?int $teacherUserId = null
    ): array {
        $teacherId = null;
        $classFilter = '';
        $params = [$schoolId, $start, $end];

        if ($classId !== null && $classId > 0) {
            $classFilter = ' AND s.class_id = ? ';
            $params[] = $classId;
        } elseif ($role === 'teacher' && $teacherUserId !== null) {
            $teacherId = $this->resolveTeacherId($schoolId, $teacherUserId);
            $classFilter = ' AND (s.class_id IN (SELECT class_id FROM teacher_assignments WHERE teacher_id = ? AND school_id = ?) 
                                 OR s.class_id IN (SELECT class_id FROM timetables WHERE teacher_id = ? AND school_id = ?)) ';
            $params[] = $teacherId;
            $params[] = $schoolId;
            $params[] = $teacherId;
            $params[] = $schoolId;
        }

        $rows = Database::fetchAll(
            "SELECT 
                s.id, s.admission_no, s.roll_no, s.first_name, s.last_name, s.phone,
                c.name AS class_name,
                COUNT(sa.id) AS total_days,
                SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) AS present_days,
                SUM(CASE WHEN sa.status = 'absent' THEN 1 ELSE 0 END) AS absent_days,
                SUM(CASE WHEN sa.status = 'late' THEN 1 ELSE 0 END) AS late_days
             FROM students s
             JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
             JOIN student_attendance sa ON sa.student_id = s.id AND sa.school_id = s.school_id
             WHERE s.school_id = ? AND s.status = 'active' AND sa.attendance_date BETWEEN ? AND ? {$classFilter}
             GROUP BY s.id, s.admission_no, s.roll_no, s.first_name, s.last_name, s.phone, c.name
             HAVING COUNT(sa.id) >= 3 AND ((SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) / COUNT(sa.id)) * 100) < ?
             ORDER BY ((SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) / COUNT(sa.id)) * 100) ASC LIMIT 20",
            array_merge($params, [$threshold])
        );

        $isStaff = in_array($role, ['admin', 'school_admin', 'principal', 'teacher'], true);
        $defaulters = [];
        foreach ($rows as $r) {
            $tot = (int) $r['total_days'];
            $pres = (int) $r['present_days'];
            $abs = (int) $r['absent_days'];
            $rate = $tot > 0 ? round(($pres / $tot) * 100, 1) : 0.0;

            $defaulters[] = [
                'student_id' => (int) $r['id'],
                'admission_no' => $r['admission_no'],
                'roll_no' => $r['roll_no'] ?? '-',
                'name' => trim("{$r['first_name']} {$r['last_name']}"),
                'class_name' => $r['class_name'],
                'recorded_days' => $tot,
                'present_days' => $pres,
                'absent_days' => $abs,
                'late_days' => (int) $r['late_days'],
                'attendance_rate' => $rate,
                'phone' => $isStaff ? ($r['phone'] ?? 'Unlisted') : '[CONFIDENTIAL]',
            ];
        }

        return $defaulters;
    }

    /**
     * Export verified school analytics report as structured CSV with Excel UTF-8 BOM.
     */
    public function exportSchoolAnalyticsCsv(int $schoolId, string $period, ?string $start, ?string $end, string $role, ?int $classId = null): string
    {
        $data = $this->compileSchoolAnalytics($schoolId, $period, $start, $end, $role, $classId);
        $periodInfo = $data['reporting_period'];
        $stats = $data['verified_statistics'];
        $att = $stats['attendance'];
        $fin = $stats['finance'];
        $acad = $stats['academics'];
        $staff = $stats['staff'];
        $staffAtt = $stats['staff_attendance'] ?? [];
        $cohorts = $stats['cohorts'] ?? [];
        $drilldowns = $data['drilldowns'] ?? [];

        $out = fopen('php://temp', 'r+');

        // Output UTF-8 BOM for Microsoft Excel compatibility
        fwrite($out, "\xEF\xBB\xBF");

        // Header / School Info
        fputcsv($out, ['=== CODECLOVE ENTERPRISE SCHOOL ANALYTICS REPORT ===']);
        fputcsv($out, ['School Name', $data['school_name']]);
        fputcsv($out, ['School Code', $data['school_code']]);
        fputcsv($out, ['Reporting Period', $periodInfo['label']]);
        fputcsv($out, ['Date Range', $periodInfo['current_start'] . ' to ' . $periodInfo['current_end']]);
        fputcsv($out, ['Comparison Period', $periodInfo['compare_start'] . ' to ' . $periodInfo['compare_end']]);
        fputcsv($out, ['Data Source', $data['data_source']]);
        fputcsv($out, ['Generated At', $data['generated_at']]);
        fputcsv($out, ['User Role Purview', strtoupper(str_replace('_', ' ', $role))]);
        fputcsv($out, []);

        // 1. Attendance Summary
        fputcsv($out, ['--- STUDENT ATTENDANCE METRICS ---']);
        fputcsv($out, ['Overall Attendance Rate (%)', $att['overall_attendance_rate']]);
        fputcsv($out, ['Prior Period Rate (%)', $att['prior_period_rate']]);
        fputcsv($out, ['Percentage Delta (%)', $att['percentage_delta']]);
        fputcsv($out, ['Present Entries', $att['present_count']]);
        fputcsv($out, ['Absent Entries', $att['absent_count']]);
        fputcsv($out, ['Late Entries', $att['late_count']]);
        fputcsv($out, ['Recorded School Days', $att['recorded_school_days']]);
        fputcsv($out, []);

        // 2. Staff Attendance Summary
        fputcsv($out, ['--- STAFF ATTENDANCE METRICS ---']);
        fputcsv($out, ['Total Staff Headcount', $staff['total_staff']]);
        fputcsv($out, ['Active Teachers', $staff['active_teachers']]);
        fputcsv($out, ['Staff Attendance Rate (%)', $staffAtt['staff_attendance_rate'] ?? 0.0]);
        fputcsv($out, ['Staff Recorded Days', $staffAtt['recorded_days'] ?? 0]);
        fputcsv($out, []);

        // 3. Financial Metrics (Role-Gated)
        fputcsv($out, ['--- FINANCIAL OVERVIEW (ROLE-RESTRICTED) ---']);
        if (!empty($fin['access_restricted'])) {
            fputcsv($out, ['Status', 'ACCESS RESTRICTED (Confidential Institutional Data)']);
        } else {
            fputcsv($out, ['Total Invoiced ($)', $fin['total_invoiced']]);
            fputcsv($out, ['Total Collected ($)', $fin['total_collected']]);
            fputcsv($out, ['Collection Efficiency Rate (%)', $fin['collection_efficiency_rate']]);
            fputcsv($out, ['Overdue Arrears ($)', $fin['overdue_arrears']]);
            fputcsv($out, ['Overdue Invoices Count', $fin['overdue_invoices_count']]);
            fputcsv($out, []);

            // Fee Category Breakdown
            if (!empty($drilldowns['fee_categories']['categories'])) {
                fputcsv($out, ['Fee Category', 'Frequency', 'Total Invoiced ($)', 'Total Collected ($)', 'Efficiency (%)', 'Overdue Arrears ($)']);
                foreach ($drilldowns['fee_categories']['categories'] as $cat) {
                    fputcsv($out, [$cat['name'], $cat['frequency'], $cat['total_invoiced'], $cat['total_collected'], $cat['collection_efficiency'], $cat['overdue_arrears']]);
                }
            }
        }
        fputcsv($out, []);

        // 4. Academic Performance
        fputcsv($out, ['--- ACADEMIC PERFORMANCE & SUBJECT BREAKDOWN ---']);
        fputcsv($out, ['Overall Pass Rate (%)', $acad['overall_pass_rate']]);
        fputcsv($out, ['Institutional Average Score (%)', $acad['average_score_percentage']]);
        fputcsv($out, ['Total Marks Evaluated', $acad['total_marks_evaluated']]);
        fputcsv($out, ['Subject', 'Average Score (%)', 'Pass Rate (%)', 'Candidates Evaluated']);
        foreach ($acad['subject_breakdown'] as $sb) {
            fputcsv($out, [$sb['subject'], $sb['average_score'], $sb['pass_rate'], $sb['candidates']]);
        }
        fputcsv($out, []);

        // 5. Cohort Breakdown
        fputcsv($out, ['--- COHORT & GRADE-LEVEL PERFORMANCE ---']);
        fputcsv($out, ['Class Name', 'Enrolled Students', 'Attendance Rate (%)', 'Avg Score (%)', 'Pass Rate (%)', 'Risk Status']);
        foreach ($cohorts as $ch) {
            fputcsv($out, [$ch['class_name'], $ch['student_count'], $ch['attendance_rate'], $ch['average_score'], $ch['pass_rate'], strtoupper($ch['risk_category'])]);
        }
        fputcsv($out, []);

        // 6. Attendance Defaulters List
        if (!empty($drilldowns['attendance_defaulters'])) {
            fputcsv($out, ['--- CHRONIC ATTENDANCE DEFAULTERS (< 75%) ---']);
            fputcsv($out, ['Admission No', 'Student Name', 'Class', 'Recorded Days', 'Present Days', 'Absent Days', 'Attendance Rate (%)']);
            foreach ($drilldowns['attendance_defaulters'] as $def) {
                fputcsv($out, [$def['admission_no'], $def['name'], $def['class_name'], $def['recorded_days'], $def['present_days'], $def['absent_days'], $def['attendance_rate']]);
            }
        }

        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);
        return $csv ?: '';
    }

    /**
     * Generate an executive printable report HTML for browser printing / PDF export.
     */
    public function generatePrintableReportHtml(
        int $schoolId,
        string $period = 'last_30_days',
        ?string $customStart = null,
        ?string $customEnd = null,
        string $role = 'school_admin',
        ?int $classId = null
    ): string {
        $data = $this->compileSchoolAnalytics($schoolId, $period, $customStart, $customEnd, $role, $classId);
        $p = $data['reporting_period'];
        $stats = $data['verified_statistics'];
        $att = $stats['attendance'];
        $fin = $stats['finance'];
        $acad = $stats['academics'];
        $staff = $stats['staff'];
        $cohorts = $stats['cohorts'];
        $ai = $data['ai_interpretation'];
        $predictions = $data['predictive_insights'];
        $isFinGated = !empty($fin['access_restricted']);

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= e($data['school_name']) ?> — Executive Business Intelligence Report</title>
    <style>
        @page { size: A4; margin: 15mm; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; color: #1e293b; background: #fff; line-height: 1.5; font-size: 12px; margin: 0; padding: 20px; }
        .report-header { border-bottom: 2px solid #2563eb; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
        .brand-title { font-size: 20px; font-weight: 800; color: #1e293b; margin: 0 0 4px 0; }
        .brand-sub { font-size: 12px; color: #64748b; margin: 0; }
        .meta-box { text-align: right; font-size: 11px; color: #475569; }
        .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase; }
        .badge-verified { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .badge-ai { background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; }
        .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; }
        .kpi-card { border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; background: #f8fafc; }
        .kpi-title { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
        .kpi-val { font-size: 18px; font-weight: 800; color: #0f172a; margin-bottom: 2px; }
        .kpi-sub { font-size: 10px; color: #64748b; }
        .section-title { font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; margin: 16px 0 8px 0; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
        th { background: #f1f5f9; color: #334155; font-weight: 700; text-align: left; padding: 6px 8px; border: 1px solid #e2e8f0; }
        td { padding: 6px 8px; border: 1px solid #e2e8f0; color: #1e293b; }
        .text-end { text-align: right; }
        .ai-brief { background: #fbfbfe; border-left: 4px solid #4f46e5; border-radius: 4px; padding: 12px; margin-bottom: 16px; font-size: 11.5px; }
        .signoff-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 40px; padding-top: 20px; border-top: 1px dashed #cbd5e1; font-size: 11px; text-align: center; }
        .sign-line { border-top: 1px solid #475569; margin: 40px 10px 4px 10px; }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 15px; text-align: right;">
        <button onclick="window.print()" style="padding: 8px 16px; background: #2563eb; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">
            Print / Save as PDF
        </button>
    </div>

    <div class="report-header">
        <div>
            <h1 class="brand-title"><?= e($data['school_name']) ?></h1>
            <p class="brand-sub">Institution Code: <strong><?= e($data['school_code']) ?></strong> · Executive Business Intelligence Report</p>
        </div>
        <div class="meta-box">
            <div>Reporting Period: <strong><?= e($p['label']) ?></strong></div>
            <div>Date Range: <strong><?= e($p['current_start']) ?> to <?= e($p['current_end']) ?></strong></div>
            <div>Data Provenance: <strong><?= e($data['data_source']) ?></strong></div>
            <div>Certified At: <strong><?= e($data['generated_at']) ?></strong></div>
        </div>
    </div>

    <!-- Executive Brief -->
    <div class="ai-brief">
        <div style="font-weight: 800; margin-bottom: 6px; color: #312e81;">
            EXECUTIVE INTELLIGENCE SYNTHESIS <span class="badge badge-verified">[VERIFIED_STATISTICS] Grounded</span> <span class="badge badge-ai">[AI_INTERPRETATION]</span>
        </div>
        <div><?= nl2br(e($ai['executive_summary'] ?? '')) ?></div>
    </div>

    <!-- KPI Cards -->
    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-title">Student Attendance</div>
            <div class="kpi-val"><?= (float)($att['overall_attendance_rate'] ?? 0.0) ?>%</div>
            <div class="kpi-sub"><?= (int)($att['present_count'] ?? 0) ?> Present (<?= (int)($att['recorded_school_days'] ?? 0) ?> Days)</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-title">Staff Presence</div>
            <div class="kpi-val"><?= (float)($stats['staff_attendance']['staff_attendance_rate'] ?? 100.0) ?>%</div>
            <div class="kpi-sub"><?= (int)($staff['total_staff'] ?? 0) ?> Total Faculty Headcount</div>
        </div>
        <?php if (!$isFinGated): ?>
        <div class="kpi-card">
            <div class="kpi-title">Tuition Collected</div>
            <div class="kpi-val">$<?= number_format((float)($fin['total_collected'] ?? 0.0), 2) ?></div>
            <div class="kpi-sub"><?= (float)($fin['collection_efficiency_rate'] ?? 0.0) ?>% Collection Rate</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-title">Overdue Receivables</div>
            <div class="kpi-val" style="color: #dc2626;">$<?= number_format((float)($fin['overdue_arrears'] ?? 0.0), 2) ?></div>
            <div class="kpi-sub"><?= (int)($fin['overdue_invoices_count'] ?? 0) ?> Unpaid Overdue Invoices</div>
        </div>
        <?php else: ?>
        <div class="kpi-card">
            <div class="kpi-title">Overall Pass Rate</div>
            <div class="kpi-val"><?= (float)($acad['overall_pass_rate'] ?? 0.0) ?>%</div>
            <div class="kpi-sub"><?= (int)($acad['total_marks_evaluated'] ?? 0) ?> Evaluations</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-title">Curriculum Standing</div>
            <div class="kpi-val"><?= (float)($acad['average_score_percentage'] ?? 0.0) ?>%</div>
            <div class="kpi-sub">Institutional Average Score</div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Cohort Table -->
    <div class="section-title">Cohort &amp; Grade-Level Performance Breakdown</div>
    <table>
        <thead>
            <tr>
                <th>Cohort / Class</th>
                <th class="text-end">Enrolled Pupils</th>
                <th class="text-end">Attendance Rate (%)</th>
                <th class="text-end">Average Score (%)</th>
                <th class="text-end">Pass Rate (%)</th>
                <th>Risk Classification</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cohorts as $c): ?>
            <tr>
                <td><strong><?= e($c['class_name']) ?></strong></td>
                <td class="text-end"><?= (int)$c['student_count'] ?></td>
                <td class="text-end"><?= $c['attendance_rate'] ?>%</td>
                <td class="text-end"><?= $c['average_score'] ?>%</td>
                <td class="text-end"><?= $c['pass_rate'] ?>%</td>
                <td><span class="badge" style="background:#f1f5f9; color:#334155;"><?= strtoupper(e($c['risk_category'])) ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Subject Breakdown -->
    <?php if (!empty($acad['subject_breakdown'])): ?>
    <div class="section-title">Subject Academic Performance</div>
    <table>
        <thead>
            <tr>
                <th>Subject</th>
                <th class="text-end">Candidates</th>
                <th class="text-end">Average Score (%)</th>
                <th class="text-end">Pass Rate (%)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($acad['subject_breakdown'] as $sb): ?>
            <tr>
                <td><?= e($sb['subject']) ?></td>
                <td class="text-end"><?= (int)$sb['candidates'] ?></td>
                <td class="text-end"><?= $sb['average_score'] ?>%</td>
                <td class="text-end"><strong><?= $sb['pass_rate'] ?>%</strong></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Predictive Interventions -->
    <?php if (!empty($predictions)): ?>
    <div class="section-title">Predictive Insights &amp; Early Interventions</div>
    <table>
        <thead>
            <tr>
                <th>Area</th>
                <th>Verified Supporting Evidence</th>
                <th>Recommended Action</th>
                <th>Priority</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($predictions as $pred): ?>
            <tr>
                <td><strong><?= e($pred['headline']) ?></strong></td>
                <td><?= e($pred['evidence']) ?></td>
                <td><?= e($pred['recommendation']) ?></td>
                <td><span class="badge badge-verified"><?= strtoupper(e($pred['severity'])) ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Official Sign-off -->
    <div class="signoff-grid">
        <div>
            <div class="sign-line"></div>
            <strong>Prepared By</strong><br>
            <span>Analytics &amp; Data Officer</span>
        </div>
        <div>
            <div class="sign-line"></div>
            <strong>Reviewed By</strong><br>
            <span>Director of Academics</span>
        </div>
        <div>
            <div class="sign-line"></div>
            <strong>Institutional Approval</strong><br>
            <span>School Principal / Head of School</span>
        </div>
    </div>
</body>
</html>
        <?php
        return (string) ob_get_clean();
    }
}

