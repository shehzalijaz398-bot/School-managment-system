<?php

declare(strict_types=1);

namespace App\Services;

/**
 * MailService — thin wrapper around PHP mail().
 *
 * SECURITY RULES (enforced here):
 *  - Plain-text passwords are NEVER passed to any method in this class.
 *  - Passwords are NEVER included in any email body or subject line.
 *  - All user-supplied strings are sanitised before being embedded in headers.
 */
final class MailService
{
    public const WELCOME_SUBJECT = 'Your School Portal Account';

    // ---------------------------------------------------------------------------
    //  Public API
    // ---------------------------------------------------------------------------

    /**
     * Send a registration verification link to the applicant.
     *
     * @param string $to        Recipient email address.
     * @param string $name      Recipient display name.
     * @param string $verifyUrl Full verification URL (contains token, never password).
     */
    public static function sendVerification(string $to, string $name, string $verifyUrl): void
    {
        $platformName = platform_setting('platform_name', 'School Portal');
        $subject      = "Verify your email — {$platformName}";

        $body  = self::textLine("Dear {$name},");
        $body .= self::textLine('');
        $body .= self::textLine("Thank you for registering with {$platformName}.");
        $body .= self::textLine('Please verify your email address by clicking the link below:');
        $body .= self::textLine('');
        $body .= self::textLine($verifyUrl);
        $body .= self::textLine('');
        $body .= self::textLine('This link will remain active. If you did not register, please ignore this email.');
        $body .= self::textLine('');
        $body .= self::textLine("— {$platformName} Team");

        self::send($to, $subject, $body);
    }

    /**
     * Send a welcome email after the school has been fully provisioned.
     *
     * Contains: School Name, School Code, login email, login page URL.
     * Does NOT contain the plain-text password.
     *
     * @param string $to         Admin email address.
     * @param string $name       Admin display name.
     * @param string $schoolName Provisioned school name.
     * @param string $schoolCode Unique school code (e.g. SCH-LHR-A1B2C3). Fetched from DB after provisioning.
     * @param string $loginUrl   URL of the unified login page.
     */
    public static function sendWelcome(
        string $to,
        string $name,
        string $schoolName,
        string $schoolCode,
        string $loginUrl
    ): void {
        $subject = self::WELCOME_SUBJECT;

        self::send($to, $subject, self::welcomeMessage($name, $to, $schoolName, $schoolCode, $loginUrl));
    }

    /** Build the welcome message used by sendWelcome(). */
    public static function welcomeMessage(
        string $name,
        string $to,
        string $schoolName,
        string $schoolCode,
        string $loginUrl
    ): string {
        $platformName = platform_setting('platform_name', 'School Portal');

        $body  = self::textLine("Dear {$name},");
        $body .= self::textLine('');
        $body .= self::textLine("Welcome to {$platformName}! Your school has been successfully registered and activated.");
        $body .= self::textLine('');
        $body .= self::textLine('--- YOUR ACCOUNT DETAILS ---');
        $body .= self::textLine('');
        $body .= self::textLine("School Name : {$schoolName}");
        $body .= self::textLine("School Code : {$schoolCode}");
        $body .= self::textLine("Login Email : {$to}");
        $body .= self::textLine("Login Page  : {$loginUrl}");
        $body .= self::textLine('');
        $body .= self::textLine('--- HOW TO LOG IN ---');
        $body .= self::textLine('');
        $body .= self::textLine(
            'Use your School Code, Email and the password you created during registration to log in.'
        );
        $body .= self::textLine('');
        $body .= self::textLine('If you have any questions, please contact our support team.');
        $body .= self::textLine('');
        $body .= self::textLine("— {$platformName} Team");

        return $body;
    }

    // ---------------------------------------------------------------------------
    //  Private helpers
    // ---------------------------------------------------------------------------

    /**
     * Low-level send wrapper.  Uses PHP mail() which on XAMPP routes through
     * sendmail/SMTP as configured in php.ini.  Failures are logged but never
     * surfaced to the end user — a mail error must never block registration.
     */
    private static function send(string $to, string $subject, string $body): void
    {
        // Sanitise header values — strip CR/LF to prevent header injection.
        $to      = self::sanitiseHeader($to);
        $subject = self::sanitiseHeader($subject);

        $fromEmail = self::sanitiseHeader(
            platform_setting('mail_from_address', 'noreply@schoolportal.local')
        );
        $fromName  = self::sanitiseHeader(
            platform_setting('platform_name', 'School Portal')
        );

        $headers  = "From: {$fromName} <{$fromEmail}>\r\n";
        $headers .= "Reply-To: {$fromEmail}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "X-Mailer: SchoolPortal/PHP\r\n";

        $sent = @mail($to, $subject, $body, $headers);

        if (!$sent) {
            error_log("[MailService] mail() failed — to={$to} subject={$subject}");
        }
    }

    /** Strip CR / LF from header values to prevent injection. */
    private static function sanitiseHeader(string $value): string
    {
        return str_replace(["\r", "\n"], '', $value);
    }

    /** Return a single line terminated with CRLF. */
    private static function textLine(string $text): string
    {
        return $text . "\r\n";
    }
}
