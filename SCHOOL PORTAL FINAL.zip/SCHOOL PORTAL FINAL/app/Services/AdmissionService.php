<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Admission;
use App\Models\Student;
use Core\Auth;
use Core\Database;

final class AdmissionService
{
    public function create(array $data): int
    {
        $model = new Admission();
        $id = $model->create([
            'school_id' => Auth::schoolId(),
            'inquiry_id' => $data['inquiry_id'] ?? null,
            'application_no' => $model->nextApplicationNo(),
            'student_name' => $data['student_name'],
            'gender' => $data['gender'] ?? null,
            'date_of_birth' => $data['date_of_birth'] ?? null,
            'parent_name' => $data['parent_name'] ?? null,
            'parent_phone' => $data['parent_phone'] ?? null,
            'parent_email' => $data['parent_email'] ?? null,
            'class_id' => $data['class_id'] ?? null,
            'section_id' => $data['section_id'] ?? null,
            'status' => $data['status'] ?? 'application',
            'notes' => $data['notes'] ?? null,
            'created_by' => Auth::id(),
        ]);
        auditLog('admission.create', 'admissions', 'admissions', $id, null, $data);
        return $id;
    }

    public function updateStatus(int $id, string $status): void
    {
        $allowed = ['inquiry', 'application', 'documents', 'review', 'approved', 'fee_pending', 'enrolled', 'rejected'];
        if (!in_array($status, $allowed, true)) {
            throw new \InvalidArgumentException('Invalid admission status.');
        }
        $model = new Admission();
        $old = $model->find($id);
        if (!$old) {
            throw new \RuntimeException('Admission not found.');
        }
        $model->update($id, ['status' => $status]);
        auditLog('admission.status', 'admissions', 'admissions', $id, ['status' => $old['status']], ['status' => $status]);
    }

    /**
     * Document Verification Workflow.
     * Validates applicant mandatory credentials (Birth Cert, Leaving Cert, Guardian ID, Health).
     */
    public function verifyDocuments(int $id, array $verifiedItems, ?string $notes = null): array
    {
        $schoolId = (int) Auth::schoolId();
        $adm = Database::fetch('SELECT * FROM admissions WHERE id = ? AND school_id = ?', [$id, $schoolId]);
        if (!$adm) {
            throw new \RuntimeException('Admission application not found.');
        }

        $standardDocs = [
            'birth_certificate' => 'Birth Certificate / Form-B',
            'previous_report_card' => 'Previous School Leaving / Report Card',
            'guardian_cnic' => 'Parent / Guardian National ID',
            'immunization_record' => 'Health & Immunization Record',
        ];

        $docPayload = [];
        $allVerified = true;
        foreach ($standardDocs as $key => $label) {
            $isVerified = !empty($verifiedItems[$key]);
            $docPayload[$key] = [
                'label' => $label,
                'verified' => $isVerified,
                'verified_at' => $isVerified ? date('Y-m-d H:i:s') : null,
            ];
            if (!$isVerified) {
                $allVerified = false;
            }
        }

        $newStatus = $allVerified ? 'review' : 'documents';
        $jsonDocs = json_encode($docPayload, JSON_UNESCAPED_SLASHES);

        static $migrated = false;
        if (!$migrated) {
            try {
                Database::execute('ALTER TABLE admissions MODIFY COLUMN documents_path TEXT NULL');
            } catch (\Throwable $ignored) {}
            $migrated = true;
        }

        Database::execute(
            'UPDATE admissions SET documents_path = ?, status = ?, notes = COALESCE(?, notes), updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$jsonDocs, $newStatus, $notes, $id, $schoolId]
        );

        auditLog('admission.verify_documents', 'admissions', 'admissions', $id, ['old_status' => $adm['status']], [
            'status' => $newStatus,
            'verified_items' => array_keys(array_filter($verifiedItems)),
        ]);

        // Connect document verification to Document Management workflow
        try {
            $docService = new DocumentService();
            $existingDoc = Database::fetch("SELECT id FROM school_documents WHERE school_id = ? AND entity_type = 'admission' AND entity_id = ? LIMIT 1", [$schoolId, $id]);
            $applicantName = $adm['student_name'] ?? 'Applicant';
            if ($existingDoc) {
                $docService->updateReviewStatus($schoolId, (int)Auth::id(), (int)$existingDoc['id'], $allVerified ? 'approved' : 'under_review', $notes);
            } else {
                $appNo = $adm['application_no'] ?? ('ADM-' . $id);
                $ref = 'DOC-ADM-' . $id . '-' . strtoupper(bin2hex(random_bytes(3)));
                $vCode = 'V-' . strtoupper(bin2hex(random_bytes(4)));
                Database::insert("
                    INSERT INTO school_documents (
                        school_id, document_ref, category, entity_type, entity_id,
                        title, description, file_name, file_path, file_size,
                        mime_type, file_hash, version, is_confidential, expiry_date,
                        review_status, verification_code, uploaded_by, created_at, updated_at
                    ) VALUES (?, ?, 'admission', 'admission', ?, ?, ?, 'admission_dossier.json', 'storage/documents/admission_dossier.json', ?, 'application/json', ?, 1, 0, NULL, ?, ?, ?, NOW(), NOW())
                ", [
                    $schoolId, $ref, $id,
                    "Admission Dossier: {$applicantName} ({$appNo})",
                    $notes ?: "Verified admission credentials for {$applicantName}",
                    strlen($jsonDocs), hash('sha256', $jsonDocs),
                    $allVerified ? 'approved' : 'under_review', $vCode, (int)Auth::id()
                ]);
            }
        } catch (\Throwable $ignored) {}

        return [
            'success' => true,
            'all_verified' => $allVerified,
            'status' => $newStatus,
            'documents' => $docPayload,
        ];
    }

    public function enroll(int $admissionId): int
    {
        $schoolId = (int) Auth::schoolId();
        Database::beginTransaction();
        try {
            $adm = Database::fetch(
                'SELECT * FROM admissions WHERE id = ? AND school_id = ? LIMIT 1',
                [$admissionId, $schoolId]
            );
            if (!$adm) {
                throw new \RuntimeException('Admission not found.');
            }
            if (!in_array($adm['status'], ['approved', 'fee_pending'], true)) {
                throw new \RuntimeException('Admission must be approved before enrollment.');
            }

            $parts = preg_split('/\s+/', trim($adm['student_name']), 2);
            $first = $parts[0] ?? 'Student';
            $last = $parts[1] ?? '';

            $studentModel = new Student();
            $admissionNo = $studentModel->nextAdmissionNo();

            $studentId = Database::insert(
                'INSERT INTO students
                (school_id, admission_no, first_name, last_name, gender, date_of_birth, class_id, section_id,
                 academic_year_id, phone, admission_date, emergency_contact, emergency_phone, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $schoolId,
                    $admissionNo,
                    $first,
                    $last,
                    $adm['gender'],
                    $adm['date_of_birth'],
                    $adm['class_id'],
                    $adm['section_id'],
                    activeAcademicYearId(),
                    $adm['parent_phone'],
                    date('Y-m-d'),
                    $adm['parent_name'],
                    $adm['parent_phone'],
                    'active',
                ]
            );

            Database::insert(
                'INSERT INTO student_academic_history
                (school_id, student_id, academic_year_id, class_id, section_id, result_status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, NOW())',
                [$schoolId, $studentId, activeAcademicYearId(), $adm['class_id'], $adm['section_id'], 'enrolled']
            );

            // End-to-End Cross-Module Linkage: Ensure parent record & relationship link in student_parents
            if (!empty($adm['parent_name']) || !empty($adm['parent_phone'])) {
                $pPhone = trim((string) ($adm['parent_phone'] ?? ''));
                $pName = trim((string) ($adm['parent_name'] ?? 'Guardian'));
                $pEmail = !empty($adm['parent_email']) ? trim((string) $adm['parent_email']) : null;

                $parent = null;
                if ($pPhone !== '') {
                    $parent = Database::fetch('SELECT id FROM parents WHERE school_id = ? AND phone = ? LIMIT 1', [$schoolId, $pPhone]);
                }
                if (!$parent && $pEmail !== null) {
                    $parent = Database::fetch('SELECT id FROM parents WHERE school_id = ? AND email = ? LIMIT 1', [$schoolId, $pEmail]);
                }

                $parentId = 0;
                if ($parent) {
                    $parentId = (int) $parent['id'];
                } else {
                    $pParts = preg_split('/\s+/', $pName, 2);
                    $pFirst = $pParts[0] ?? 'Parent';
                    $pLast = $pParts[1] ?? '';
                    $parentId = (int) Database::insert(
                        'INSERT INTO parents (school_id, first_name, last_name, phone, email, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())',
                        [$schoolId, $pFirst, $pLast, $pPhone ?: null, $pEmail]
                    );
                }

                if ($parentId > 0) {
                    $alreadyLinked = Database::fetch('SELECT id FROM student_parents WHERE school_id = ? AND student_id = ? AND parent_id = ? LIMIT 1', [$schoolId, $studentId, $parentId]);
                    if (!$alreadyLinked) {
                        Database::insert(
                            'INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES (?, ?, ?, "Parent/Guardian", 1, NOW())',
                            [$schoolId, $studentId, $parentId]
                        );
                    }
                }
            }

            Database::execute(
                'UPDATE admissions SET status = ?, student_id = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                ['enrolled', $studentId, $admissionId, $schoolId]
            );

            // End-to-End Cross-Module Linkage: Auto-generate initial Admission/Enrollment Fee Invoice
            try {
                $categories = Database::fetchAll(
                    "SELECT id, name, amount FROM fee_categories WHERE school_id = ? AND status = 1 AND frequency IN ('one_time', 'monthly') ORDER BY id ASC LIMIT 2",
                    [$schoolId]
                );
                if (!empty($categories)) {
                    $totalInvoiceAmt = 0.0;
                    foreach ($categories as $cat) {
                        $totalInvoiceAmt += (float) $cat['amount'];
                    }
                    $invDate = date('Y-m-d');
                    $dueDate = date('Y-m-d', strtotime('+15 days'));
                    $invNo = 'INV-ADM-' . date('Ym') . '-' . str_pad((string) $studentId, 4, '0', STR_PAD_LEFT);

                    $yearId = activeAcademicYearId();
                    $invoiceId = (int) Database::insert(
                        'INSERT INTO student_fee_invoices (school_id, student_id, academic_year_id, invoice_no, title, invoice_date, due_date, subtotal, discount, late_fee, total_amount, paid_amount, status, created_at, updated_at)
                         VALUES (?, ?, ?, ?, "Admission & Enrollment Fee", ?, ?, ?, 0.00, 0.00, ?, 0.00, "unpaid", NOW(), NOW())',
                        [$schoolId, $studentId, $yearId, $invNo, $invDate, $dueDate, $totalInvoiceAmt, $totalInvoiceAmt]
                    );

                    foreach ($categories as $cat) {
                        Database::insert(
                            'INSERT INTO student_fee_invoice_items (school_id, invoice_id, fee_category_id, description, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                            [$schoolId, $invoiceId, (int) $cat['id'], $cat['name'] . ' (Enrollment Fee)', (float) $cat['amount']]
                        );
                    }

                    // Send enrollment notification to parent
                    if ($parentId > 0) {
                        $parentUser = Database::fetch('SELECT user_id FROM parents WHERE id = ? AND school_id = ?', [$parentId, $schoolId]);
                        $pUserId = (int) ($parentUser['user_id'] ?? 0);
                        if ($pUserId > 0) {
                            Database::insert(
                                'INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                                 VALUES (?, ?, "admission.enrolled", "Welcome to the Institution!", ?, "/portal/finance", 0, NOW())',
                                [
                                    $schoolId,
                                    $pUserId,
                                    "Congratulations! {$first} {$last} has been enrolled (Admission #{$admissionNo}). Initial fee invoice #{$invNo} (" . formatMoney($totalInvoiceAmt) . ") has been issued.",
                                ]
                            );
                        }
                    }
                }
            } catch (\Throwable $e) {
                // Non-fatal for enrollment transaction
            }

            Database::commit();
            auditLog('admission.enroll', 'admissions', 'students', $studentId, null, ['admission_no' => $admissionNo]);
            return $studentId;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }
}

