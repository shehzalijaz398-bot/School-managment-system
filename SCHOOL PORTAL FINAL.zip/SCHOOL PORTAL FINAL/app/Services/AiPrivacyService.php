<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;

/**
 * AiPrivacyService
 *
 * Enforces zero-trust privacy guardrails, PII redaction, data minimization,
 * multi-tenant boundaries, and conversation lifecycle retention management.
 */
final class AiPrivacyService
{
    /**
     * Redact all sensitive PII (Personally Identifiable Information) and secrets
     * from prompts, contexts, and diagnostics before sending to external LLM providers.
     *
     * @param string $text
     * @return string Scrubbed text
     */
    public function redactPii(string $text): string
    {
        if (trim($text) === '') {
            return '';
        }

        // 1. Secrets & API Keys
        $text = preg_replace('/(AIza[0-9A-Za-z\-_]{30,50}|sk-[a-zA-Z0-9_\-]{20,}|bearer\s+[a-zA-Z0-9_\-\.]{25,})/i', '[REDACTED_SECRET]', $text);

        // 2. Credit Card / Debit Card Numbers (13 to 19 digits with optional spaces or dashes)
        $text = preg_replace('/\b(?:\d{4}[ -]?){3}\d{1,4}\b/', '[REDACTED_CARD]', $text);

        // 3. National Identity Numbers (CNIC: 12345-1234567-1, SSN: 123-45-6789)
        $text = preg_replace('/\b\d{5}-\d{7}-\d\b/', '[REDACTED_CNIC]', $text);
        $text = preg_replace('/\b\d{3}-\d{2}-\d{4}\b/', '[REDACTED_SSN]', $text);

        // 4. Email Addresses
        $text = preg_replace('/[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+/i', '[REDACTED_EMAIL]', $text);

        // 5. Phone Numbers (International and localized formats)
        $text = preg_replace_callback('/(\+?\d{1,3}[-.\s]?)?(\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}\b/', function ($matches) {
            $match = trim($matches[0]);
            // Filter out short numbers like year dates (e.g. 2024, 2025) or normal IDs
            $digitsOnly = preg_replace('/\D/', '', $match);
            if (strlen($digitsOnly) >= 7 && strlen($digitsOnly) <= 15) {
                // If it looks like a 4-digit year or currency, don't redact
                if (strlen($digitsOnly) === 4) {
                    return $match;
                }
                return '[REDACTED_PHONE]';
            }
            return $match;
        }, $text);

        return $text;
    }

    /**
     * Minimize data before LLM dispatch.
     * Takes raw table rows and transforms them into an aggregated, pseudonymized summary
     * preventing unnecessary exposure of individual demographic details.
     */
    public function minimizeStudentRecords(array $students): array
    {
        $minimized = [];
        foreach ($students as $s) {
            $minimized[] = [
                'id' => $s['id'] ?? null,
                'pseudonym' => 'Student #' . ($s['id'] ?? 'N/A'),
                'class' => $s['class_name'] ?? ($s['class'] ?? 'N/A'),
                'section' => $s['section_name'] ?? ($s['section'] ?? 'N/A'),
                'status' => $s['status'] ?? 'active',
            ];
        }
        return $minimized;
    }

    /**
     * Strictly verify that every record or ID belongs exclusively to the tenant's school ID.
     *
     * @param int $tenantSchoolId Authenticated user's school ID
     * @param array<int> $recordSchoolIds Array of school_ids from fetched database rows
     * @return bool True if strictly isolated, false if foreign tenant data detected
     */
    public function verifyTenantIsolation(int $tenantSchoolId, array $recordSchoolIds): bool
    {
        if ($tenantSchoolId === 0) {
            // Super admin platform context
            return true;
        }

        foreach ($recordSchoolIds as $schoolId) {
            if ((int) $schoolId !== $tenantSchoolId) {
                StructuredLogger::alert('Cross-school data leakage blocked by AiPrivacyService', [
                    'tenant_school_id' => $tenantSchoolId,
                    'foreign_school_id' => $schoolId,
                ]);
                return false;
            }
        }

        return true;
    }

    /**
     * Purge conversation records older than the configured data retention window.
     *
     * @param int $schoolId Tenant school ID (0 for all schools)
     * @param int $retentionDays Days after which conversations expire (default: 30)
     * @return int Number of deleted conversation rows
     */
    public function purgeExpiredConversations(int $schoolId = 0, int $retentionDays = 30): int
    {
        $cutoff = date('Y-m-d H:i:s', strtotime("-{$retentionDays} days"));

        try {
            if ($schoolId > 0) {
                $count = Database::execute(
                    'DELETE FROM ai_conversations WHERE school_id = ? AND last_active_at < ?',
                    [$schoolId, $cutoff]
                );
            } else {
                $count = Database::execute(
                    'DELETE FROM ai_conversations WHERE last_active_at < ?',
                    [$cutoff]
                );
            }

            // Also purge old usage logs older than 180 days to keep database lean
            $usageCutoff = date('Y-m-d H:i:s', strtotime('-180 days'));
            Database::execute('DELETE FROM ai_usage_logs WHERE created_at < ?', [$usageCutoff]);

            // Also purge expired cache entries
            Database::execute('DELETE FROM ai_response_cache WHERE expires_at < NOW()');

            return (int) $count;
        } catch (\Throwable $e) {
            // If table does not exist yet, return 0
            return 0;
        }
    }
}
