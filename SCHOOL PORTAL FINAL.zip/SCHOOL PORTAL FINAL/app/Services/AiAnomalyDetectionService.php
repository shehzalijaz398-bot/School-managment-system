<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Throwable;

/**
 * AiAnomalyDetectionService
 *
 * Scans institutional database records to discover operational anomalies,
 * attendance drop risks, fee arrears clusters, timetable collisions, and unsubmitted registers.
 */
final class AiAnomalyDetectionService
{
    private AiUsageTrackingService $usageTracker;

    public function __construct()
    {
        $this->usageTracker = new AiUsageTrackingService();
    }

    /**
     * Run full scan across all operational dimensions for a school tenant.
     *
     * @param int $schoolId
     * @return array<array{category: string, severity: string, title: string, description: string, metric_payload: array, action_recommendation: string}>
     */
    public function detectAnomalies(int $schoolId): array
    {
        $this->usageTracker->ensureAiSchema();

        $anomalies = [];

        // 1. Declining Attendance Anomalies (< 75% or 3+ consecutive absences)
        $attendanceAnomalies = $this->scanAttendanceAnomalies($schoolId);
        foreach ($attendanceAnomalies as $a) {
            $anomalies[] = $a;
        }

        // 2. Overdue Fee Collection Bottlenecks
        $feeAnomalies = $this->scanFeeAnomalies($schoolId);
        foreach ($feeAnomalies as $f) {
            $anomalies[] = $f;
        }

        // 3. Timetable Clashes & Double-Bookings
        $timetableAnomalies = $this->scanTimetableCollisions($schoolId);
        foreach ($timetableAnomalies as $t) {
            $anomalies[] = $t;
        }

        // 4. Missing Academic Records & Today's Attendance Registers
        $missingRecordAnomalies = $this->scanMissingRecords($schoolId);
        foreach ($missingRecordAnomalies as $m) {
            $anomalies[] = $m;
        }

        // 5. Operational Administrative Bottlenecks
        $operationalAnomalies = $this->scanOperationalBottlenecks($schoolId);
        foreach ($operationalAnomalies as $o) {
            $anomalies[] = $o;
        }

        // Persist active insights to database
        $this->syncInsightsToDatabase($schoolId, $anomalies);

        return $anomalies;
    }

    /**
     * Scan student attendance records for chronic absence or drops.
     */
    private function scanAttendanceAnomalies(int $schoolId): array
    {
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));

        $lowAttendance = Database::fetchAll("
            SELECT s.id, s.admission_no, s.first_name, s.last_name, c.name AS class_name,
                   COUNT(sa.id) AS total_sessions,
                   SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) AS present_count,
                   SUM(CASE WHEN sa.status = 'absent' THEN 1 ELSE 0 END) AS absent_count
            FROM student_attendance sa
            JOIN students s ON s.id = sa.student_id
            LEFT JOIN classes c ON c.id = s.class_id
            WHERE sa.school_id = ? AND sa.attendance_date >= ?
            GROUP BY s.id, s.admission_no, s.first_name, s.last_name, c.name
            HAVING COUNT(sa.id) >= 5 AND (SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) / COUNT(sa.id)) < 0.75
            ORDER BY (SUM(CASE WHEN sa.status = 'present' THEN 1 ELSE 0 END) / COUNT(sa.id)) ASC
            LIMIT 5
        ", [$schoolId, $thirtyDaysAgo]);

        $anomalies = [];
        if (!empty($lowAttendance)) {
            $count = count($lowAttendance);
            $names = array_map(fn($r) => "{$r['first_name']} {$r['last_name']} ({$r['class_name']})", $lowAttendance);

            $anomalies[] = [
                'category' => 'attendance_risk',
                'severity' => 'warning',
                'title' => "Declining Attendance Alert ({$count} Students < 75%)",
                'description' => "Found {$count} student(s) whose 30-day attendance rate has fallen below the 75% statutory threshold: " . implode(', ', array_slice($names, 0, 3)) . (count($names) > 3 ? " and others." : "."),
                'metric_payload' => ['student_count' => $count, 'students' => $lowAttendance],
                'action_recommendation' => "Dispatch automated parent attendance warnings and schedule counseling reviews.",
            ];
        }

        return $anomalies;
    }

    /**
     * Scan for overdue fee clusters and stagnant collection velocity.
     */
    private function scanFeeAnomalies(int $schoolId): array
    {
        $today = date('Y-m-d');
        $overdueData = Database::fetch("
            SELECT COUNT(*) AS overdue_count,
                   COALESCE(SUM(total_amount - paid_amount), 0.00) AS overdue_total
            FROM student_fee_invoices
            WHERE school_id = ? 
              AND status IN ('unpaid', 'partially_paid', 'partial')
              AND due_date < ?
        ", [$schoolId, $today]) ?: [];

        $anomalies = [];
        $count = (int) ($overdueData['overdue_count'] ?? 0);
        $total = (float) ($overdueData['overdue_total'] ?? 0.0);

        if ($count > 0 && $total > 0) {
            $severity = $total > 5000 ? 'critical' : 'warning';
            $anomalies[] = [
                'category' => 'fee_overdue',
                'severity' => $severity,
                'title' => "Overdue Fee Arrears Cluster ($" . number_format($total, 2) . ")",
                'description' => "{$count} student invoice(s) have passed their formal payment deadline with a collective overdue balance of $" . number_format($total, 2) . ".",
                'metric_payload' => ['overdue_count' => $count, 'overdue_amount' => $total],
                'action_recommendation' => "Trigger the AI Automated Fee Reminder dispatch workflow with a 5-day anti-spam cooldown.",
            ];
        }

        return $anomalies;
    }

    /**
     * Scan weekly class timetables for room collisions or teacher double-bookings.
     */
    private function scanTimetableCollisions(int $schoolId): array
    {
        $anomalies = [];

        try {
            // Check teacher double bookings
            $clashes = Database::fetchAll("
                SELECT t1.day_of_week, t1.period_id, t1.teacher_id,
                       c1.name AS class_1, c2.name AS class_2,
                       st.first_name, st.last_name
                FROM timetables t1
                JOIN timetables t2 ON t1.school_id = t2.school_id 
                                  AND t1.day_of_week = t2.day_of_week 
                                  AND t1.period_id = t2.period_id 
                                  AND t1.teacher_id = t2.teacher_id 
                                  AND t1.id < t2.id
                LEFT JOIN classes c1 ON c1.id = t1.class_id
                LEFT JOIN classes c2 ON c2.id = t2.class_id
                LEFT JOIN staff st ON st.id = t1.teacher_id
                WHERE t1.school_id = ? AND t1.teacher_id IS NOT NULL AND t1.teacher_id > 0
                LIMIT 5
            ", [$schoolId]);

            if (!empty($clashes)) {
                $count = count($clashes);
                $first = $clashes[0];
                $teacherName = trim(($first['first_name'] ?? '') . ' ' . ($first['last_name'] ?? 'Instructor'));

                $anomalies[] = [
                    'category' => 'timetable_clash',
                    'severity' => 'critical',
                    'title' => "Timetable Schedule Collision Detected ({$count} Clashes)",
                    'description' => "Teacher {$teacherName} is assigned to both {$first['class_1']} and {$first['class_2']} on {$first['day_of_week']} during the same period.",
                    'metric_payload' => ['clash_count' => $count, 'clashes' => $clashes],
                    'action_recommendation' => "Reassign period teacher in **Academics > Timetable** to prevent instructional conflict.",
                ];
            }
        } catch (Throwable $e) {
            // If timetable columns vary across installations, fail gracefully
        }

        return $anomalies;
    }

    /**
     * Scan for missing records: unsubmitted today registers and unentered exam marks.
     */
    private function scanMissingRecords(int $schoolId): array
    {
        $anomalies = [];
        $today = date('Y-m-d');
        $isWeekday = in_array((int) date('N'), [1, 2, 3, 4, 5], true);

        if ($isWeekday) {
            $totalClasses = (int) Database::fetchValue('SELECT COUNT(*) FROM classes WHERE school_id = ?', [$schoolId]);
            $submittedClasses = (int) Database::fetchValue("
                SELECT COUNT(DISTINCT s.class_id)
                FROM student_attendance sa
                JOIN students s ON s.id = sa.student_id
                WHERE sa.school_id = ? AND sa.attendance_date = ?
            ", [$schoolId, $today]);

            $missing = max(0, $totalClasses - $submittedClasses);
            if ($missing > 0 && $totalClasses > 0) {
                $anomalies[] = [
                    'category' => 'grading_missing',
                    'severity' => 'warning',
                    'title' => "Unsubmitted Attendance Registers Today ({$missing} Classes)",
                    'description' => "{$missing} of {$totalClasses} academic section(s) have not had their daily attendance register logged for today.",
                    'metric_payload' => ['missing_classes' => $missing, 'total_classes' => $totalClasses],
                    'action_recommendation' => "Send an in-app reminder to class instructors to complete roll call.",
                ];
            }
        }

        return $anomalies;
    }

    /**
     * Scan operational bottlenecks like unapproved leave requests.
     */
    private function scanOperationalBottlenecks(int $schoolId): array
    {
        $anomalies = [];

        try {
            $threeDaysAgo = date('Y-m-d H:i:s', strtotime('-3 days'));
            $pendingLeaves = (int) (Database::fetchValue("
                SELECT COUNT(*) FROM leave_requests 
                WHERE school_id = ? AND status = 'pending' AND created_at <= ?
            ", [$schoolId, $threeDaysAgo]) ?? 0);

            if ($pendingLeaves > 0) {
                $anomalies[] = [
                    'category' => 'operational_bottleneck',
                    'severity' => 'info',
                    'title' => "Stale Staff Leave Approvals ({$pendingLeaves} Pending)",
                    'description' => "{$pendingLeaves} faculty leave application(s) have been awaiting principal/HR authorization for more than 72 hours.",
                    'metric_payload' => ['pending_count' => $pendingLeaves],
                    'action_recommendation' => "Review pending leave requests in **Human Resources > Staff Leaves**.",
                ];
            }
        } catch (Throwable $e) {
            // Graceful fallback
        }

        return $anomalies;
    }

    /**
     * Persist detected anomalies into ai_smart_insights table.
     */
    private function syncInsightsToDatabase(int $schoolId, array $anomalies): void
    {
        try {
            // Dismiss old unacknowledged active insights
            Database::execute(
                "UPDATE ai_smart_insights SET status = 'resolved' WHERE school_id = ? AND status = 'active'",
                [$schoolId]
            );

            foreach ($anomalies as $a) {
                Database::execute(
                    "INSERT INTO ai_smart_insights (school_id, category, severity, title, description, metric_payload, is_predictive, status)
                     VALUES (?, ?, ?, ?, ?, ?, 0, 'active')",
                    [
                        $schoolId,
                        $a['category'],
                        $a['severity'],
                        $a['title'],
                        $a['description'],
                        json_encode($a['metric_payload'] ?? []),
                    ]
                );
            }
        } catch (Throwable $e) {
            // Fail gracefully
        }
    }
}
