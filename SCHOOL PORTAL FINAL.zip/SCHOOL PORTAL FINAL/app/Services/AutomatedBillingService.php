<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;
use Core\Logger\StructuredLogger;
use Throwable;

/**
 * AutomatedBillingService
 *
 * Automated recurring fee generation engine:
 * - Scans active students across classes
 * - Calculates fee items from active fee categories
 * - Generates student_fee_invoices and invoice items with strict idempotency
 * - Automatically dispatches notifications to parents
 */
final class AutomatedBillingService
{
    /**
     * Generate monthly recurring fee invoices for active students.
     *
     * @param int $schoolId School tenant ID
     * @param string $billingMonth Format 'YYYY-MM' (e.g. '2026-11')
     * @param int|null $classId Optional class filter
     * @return array Summary of generated invoices
     */
    public function generateRecurringInvoices(int $schoolId, string $billingMonth, ?int $classId = null): array
    {
        // 1. Fetch active fee categories for recurring monthly/term billing
        $feeCategories = Database::fetchAll("
            SELECT * FROM fee_categories 
            WHERE school_id = ? AND status = 1 AND frequency IN ('monthly', 'term')
        ", [$schoolId]);

        if (empty($feeCategories)) {
            return [
                'success' => false,
                'invoices_created' => 0,
                'total_billed' => 0.0,
                'message' => 'No active monthly or term fee categories configured for this institution.',
            ];
        }

        // Calculate standard monthly amount per student
        $standardAmount = 0.0;
        foreach ($feeCategories as $cat) {
            $standardAmount += (float)$cat['amount'];
        }

        // 2. Fetch active students
        $studentSql = "SELECT id, class_id, first_name, last_name, admission_no FROM students WHERE school_id = ? AND status = 'active'";
        $params = [$schoolId];
        if ($classId !== null) {
            $studentSql .= " AND class_id = ?";
            $params[] = $classId;
        }
        $students = Database::fetchAll($studentSql, $params);

        if (empty($students)) {
            return [
                'success' => true,
                'invoices_created' => 0,
                'total_billed' => 0.0,
                'message' => 'No active students found matching criteria.',
            ];
        }

        $dueDate = date('Y-m-d', strtotime("{$billingMonth}-10")); // Due on 10th of the month
        $invoiceDate = date('Y-m-d', strtotime("{$billingMonth}-01"));

        $createdCount = 0;
        $skippedCount = 0;
        $totalBilled = 0.0;

        foreach ($students as $st) {
            $studentId = (int)$st['id'];

            // Idempotency Check: Don't create duplicate invoice if one already exists for this student in this month
            $existing = Database::fetch("
                SELECT id FROM student_fee_invoices 
                WHERE school_id = ? AND student_id = ? 
                AND DATE_FORMAT(invoice_date, '%Y-%m') = ?
                LIMIT 1
            ", [$schoolId, $studentId, $billingMonth]);

            if ($existing) {
                $skippedCount++;
                continue;
            }

            $invoiceNo = 'INV-' . str_replace('-', '', $billingMonth) . '-' . str_pad((string)$studentId, 4, '0', STR_PAD_LEFT);

            Database::beginTransaction();
            try {
                $invoiceId = (int) Database::insert("
                    INSERT INTO student_fee_invoices 
                    (school_id, student_id, invoice_no, total_amount, paid_amount, status, invoice_date, due_date, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 0.00, 'unpaid', ?, ?, NOW(), NOW())
                ", [$schoolId, $studentId, $invoiceNo, $standardAmount, $invoiceDate, $dueDate]);

                // Insert items
                foreach ($feeCategories as $cat) {
                    Database::insert("
                        INSERT INTO student_fee_invoice_items 
                        (invoice_id, fee_category_id, description, amount)
                        VALUES (?, ?, ?, ?)
                    ", [$invoiceId, (int)$cat['id'], $cat['name'] . " - " . date('M Y', strtotime($invoiceDate)), (float)$cat['amount']]);
                }

                Database::commit();
                $createdCount++;
                $totalBilled += $standardAmount;

                // Notify parent if linked
                $this->notifyParent($schoolId, $studentId, $invoiceNo, $standardAmount, $dueDate);
            } catch (Throwable $e) {
                Database::rollBack();
                if (class_exists(StructuredLogger::class)) {
                    StructuredLogger::error("Failed to generate recurring invoice for student {$studentId}: " . $e->getMessage());
                }
            }
        }

        if (class_exists(StructuredLogger::class)) {
            StructuredLogger::info("Automated recurring billing completed", [
                'school_id' => $schoolId,
                'billing_month' => $billingMonth,
                'invoices_created' => $createdCount,
                'total_billed' => $totalBilled,
                'skipped_existing' => $skippedCount,
            ]);
        }

        return [
            'success'          => true,
            'billing_month'    => $billingMonth,
            'invoices_created' => $createdCount,
            'total_billed'     => $totalBilled,
            'skipped_existing' => $skippedCount,
            'message'          => "Generated {$createdCount} recurring invoices ({$skippedCount} skipped, total: " . formatMoney($totalBilled) . ").",
        ];
    }

    /**
     * Dispatch automated fee reminders to parents of students with overdue invoices.
     *
     * @param int $schoolId School tenant ID
     * @return array Summary of dispatched reminders
     */
    public function dispatchOverdueFeeReminders(int $schoolId): array
    {
        $overdueInvoices = Database::fetchAll("
            SELECT i.id, i.invoice_no, i.student_id, i.total_amount, i.paid_amount, i.due_date,
                   CONCAT(s.first_name, ' ', s.last_name) AS student_name
            FROM student_fee_invoices i
            JOIN students s ON s.id = i.student_id
            WHERE i.school_id = ? 
              AND i.status IN ('unpaid', 'partially_paid', 'partial')
              AND i.due_date < CURDATE()
        ", [$schoolId]);

        $notifiedCount = 0;
        $totalOverdueAmount = 0.0;
        $uniqueStudents = [];

        foreach ($overdueInvoices as $inv) {
            $balance = (float)$inv['total_amount'] - (float)$inv['paid_amount'];
            $totalOverdueAmount += $balance;
            $uniqueStudents[$inv['student_id']] = true;

            $parents = Database::fetchAll("
                SELECT p.user_id FROM student_parents sp
                JOIN parents p ON p.id = sp.parent_id
                WHERE sp.student_id = ? AND p.user_id IS NOT NULL
            ", [(int)$inv['student_id']]);

            foreach ($parents as $p) {
                $userId = (int)$p['user_id'];
                if ($userId > 0) {
                    Database::insert("
                        INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                        VALUES (?, ?, 'fee.overdue_reminder', 'Overdue Fee Notice', ?, '/portal/finance', 0, NOW())
                    ", [
                        $schoolId,
                        $userId,
                        "Friendly reminder: Fee invoice #{$inv['invoice_no']} for {$inv['student_name']} (" . formatMoney($balance) . ") was due on {$inv['due_date']}. Please settle at your earliest convenience.",
                    ]);
                    $notifiedCount++;
                }
            }
        }

        if (class_exists(StructuredLogger::class)) {
            StructuredLogger::info("Automated overdue fee reminders dispatched", [
                'school_id' => $schoolId,
                'overdue_invoices' => count($overdueInvoices),
                'unique_students' => count($uniqueStudents),
                'reminders_sent' => $notifiedCount,
                'total_overdue' => $totalOverdueAmount,
            ]);
        }

        return [
            'success' => true,
            'overdue_invoices_count' => count($overdueInvoices),
            'unique_students_count' => count($uniqueStudents),
            'reminders_sent' => $notifiedCount,
            'total_overdue' => $totalOverdueAmount,
            'message' => "Dispatched {$notifiedCount} fee reminder(s) for " . count($overdueInvoices) . " overdue invoice(s) totaling " . formatMoney($totalOverdueAmount) . ".",
        ];
    }

    private function notifyParent(int $schoolId, int $studentId, string $invoiceNo, float $amount, string $dueDate): void
    {
        try {
            $parents = Database::fetchAll("
                SELECT p.user_id FROM student_parents sp
                JOIN parents p ON p.id = sp.parent_id
                WHERE sp.student_id = ? AND p.user_id IS NOT NULL
            ", [$studentId]);

            foreach ($parents as $p) {
                $userId = (int)$p['user_id'];
                if ($userId > 0) {
                    Database::insert("
                        INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                        VALUES (?, ?, 'fee.invoice', 'New Fee Invoice Generated', ?, '/portal/finance', 0, NOW())
                    ", [
                        $schoolId,
                        $userId,
                        "Invoice #{$invoiceNo} for " . formatMoney($amount) . " is now generated. Due date: {$dueDate}.",
                    ]);
                }
            }
        } catch (Throwable $e) {
            // Notification dispatch is non-blocking
        }
    }
}

