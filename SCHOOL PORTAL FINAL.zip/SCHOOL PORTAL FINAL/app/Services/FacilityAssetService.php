<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class FacilityAssetService
{
    public function __construct()
    {
        $this->ensureSchema();
    }

    /**
     * Auto-provisions tenant-isolated schema for campus facilities,
     * room reservations, fixed asset lifecycle, custody logs, and work orders.
     */
    public function ensureSchema(): void
    {
        static $provisioned = false;
        if ($provisioned) {
            return;
        }

        try {
            // 1. Campus Facilities & Rooms
            Database::execute("CREATE TABLE IF NOT EXISTS campus_facilities (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                facility_code VARCHAR(64) NOT NULL,
                name VARCHAR(191) NOT NULL,
                facility_type ENUM('auditorium', 'laboratory', 'computer_lab', 'conference_room', 'smart_classroom', 'sports_facility', 'library_hall', 'other') NOT NULL DEFAULT 'smart_classroom',
                building_block VARCHAR(100) NULL,
                floor VARCHAR(50) NULL,
                capacity INT UNSIGNED NOT NULL DEFAULT 30,
                hourly_rate DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                amenities_json TEXT NULL,
                status ENUM('available', 'under_maintenance', 'inactive') NOT NULL DEFAULT 'available',
                rules_notes TEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_fac_school (school_id, status),
                INDEX idx_fac_code (school_id, facility_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 2. Facility & Room Reservations
            Database::execute("CREATE TABLE IF NOT EXISTS facility_bookings (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                facility_id BIGINT UNSIGNED NOT NULL,
                booking_ref VARCHAR(64) NOT NULL,
                title VARCHAR(191) NOT NULL,
                purpose TEXT NULL,
                start_time DATETIME NOT NULL,
                end_time DATETIME NOT NULL,
                expected_attendees INT UNSIGNED NOT NULL DEFAULT 0,
                status ENUM('pending', 'confirmed', 'rejected', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
                requested_by_user_id BIGINT UNSIGNED NOT NULL,
                reviewer_user_id BIGINT UNSIGNED NULL,
                reviewer_remarks TEXT NULL,
                conflict_override TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_bk_school_time (school_id, facility_id, start_time, end_time),
                INDEX idx_bk_ref (school_id, booking_ref)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 3. Fixed Asset Registry & Depreciation
            Database::execute("CREATE TABLE IF NOT EXISTS fixed_assets (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                asset_tag VARCHAR(64) NOT NULL,
                name VARCHAR(191) NOT NULL,
                category ENUM('it_hardware', 'lab_equipment', 'classroom_furniture', 'av_multimedia', 'sports_gear', 'transport_vehicle', 'general') NOT NULL DEFAULT 'general',
                serial_number VARCHAR(100) NULL,
                barcode VARCHAR(100) NULL,
                facility_id BIGINT UNSIGNED NULL,
                purchase_date DATE NOT NULL,
                purchase_cost DECIMAL(12,2) NOT NULL,
                salvage_value DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                useful_life_years INT UNSIGNED NOT NULL DEFAULT 5,
                depreciation_method ENUM('straight_line', 'reducing_balance', 'none') NOT NULL DEFAULT 'straight_line',
                status ENUM('in_service', 'under_maintenance', 'decommissioned', 'disposed') NOT NULL DEFAULT 'in_service',
                assigned_to_user_id BIGINT UNSIGNED NULL,
                notes TEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_ast_school (school_id, status),
                INDEX idx_ast_tag (school_id, asset_tag)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 4. Asset Custody & Checkout Ledger
            Database::execute("CREATE TABLE IF NOT EXISTS asset_custody_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                asset_id BIGINT UNSIGNED NOT NULL,
                action ENUM('checkout', 'checkin', 'transfer', 'audit') NOT NULL DEFAULT 'checkout',
                assigned_to_type ENUM('staff', 'student', 'department', 'facility') NOT NULL DEFAULT 'staff',
                assigned_to_id BIGINT UNSIGNED NULL,
                assigned_to_name VARCHAR(191) NOT NULL,
                condition_state ENUM('excellent', 'good', 'fair', 'damaged') NOT NULL DEFAULT 'good',
                expected_return_date DATE NULL,
                actual_return_date DATE NULL,
                logged_by_user_id BIGINT UNSIGNED NOT NULL,
                remarks TEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_cust_school_asset (school_id, asset_id),
                INDEX idx_cust_action (school_id, action)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // 5. Facility & Asset Maintenance Work Orders
            Database::execute("CREATE TABLE IF NOT EXISTS facility_work_orders (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                work_order_no VARCHAR(64) NOT NULL,
                title VARCHAR(191) NOT NULL,
                description TEXT NULL,
                facility_id BIGINT UNSIGNED NULL,
                asset_id BIGINT UNSIGNED NULL,
                category ENUM('electrical', 'plumbing', 'hvac', 'carpentry', 'it_hardware', 'structural', 'general') NOT NULL DEFAULT 'general',
                priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
                status ENUM('open', 'in_progress', 'on_hold', 'completed', 'cancelled') NOT NULL DEFAULT 'open',
                assigned_technician VARCHAR(191) NULL,
                technician_phone VARCHAR(50) NULL,
                estimated_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                actual_cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                scheduled_date DATE NULL,
                completed_at DATETIME NULL,
                resolution_notes TEXT NULL,
                reported_by_user_id BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_wo_school_status (school_id, status, priority),
                INDEX idx_wo_num (school_id, work_order_no)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (\Throwable $e) {
            error_log("FacilityAssetService schema provisioning error: " . $e->getMessage());
        }

        $provisioned = true;
    }

    // =========================================================================
    // 1. CAMPUS FACILITIES CRUD
    // =========================================================================

    public function listFacilities(int $schoolId, ?string $type = null, ?string $status = null, ?string $search = null): array
    {
        $this->ensureSchema();
        $query = "SELECT f.*, 
                         (SELECT COUNT(*) FROM facility_bookings b WHERE b.facility_id = f.id AND b.school_id = f.school_id AND b.status IN ('confirmed', 'pending') AND b.end_time >= NOW()) AS active_bookings_count,
                         (SELECT COUNT(*) FROM fixed_assets a WHERE a.facility_id = f.id AND a.school_id = f.school_id AND a.status = 'in_service') AS assets_count
                  FROM campus_facilities f
                  WHERE f.school_id = ?";
        $params = [$schoolId];

        if ($type !== null && $type !== '' && $type !== 'all') {
            $query .= " AND f.facility_type = ?";
            $params[] = $type;
        }

        if ($status !== null && $status !== '' && $status !== 'all') {
            $query .= " AND f.status = ?";
            $params[] = $status;
        }

        if ($search !== null && $search !== '') {
            $query .= " AND (f.name LIKE ? OR f.facility_code LIKE ? OR f.building_block LIKE ?)";
            $wild = '%' . $search . '%';
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }

        $query .= " ORDER BY f.building_block ASC, f.name ASC";
        return Database::fetchAll($query, $params);
    }

    public function getFacility(int $schoolId, int $facilityId): ?array
    {
        $this->ensureSchema();
        return Database::fetch(
            "SELECT * FROM campus_facilities WHERE id = ? AND school_id = ? LIMIT 1",
            [$facilityId, $schoolId]
        );
    }

    public function createFacility(int $schoolId, array $data): int
    {
        $this->ensureSchema();
        $code = trim((string)($data['facility_code'] ?? ''));
        if ($code === '') {
            $code = 'FAC-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        }

        $amenities = $data['amenities'] ?? [];
        if (is_array($amenities)) {
            $amenitiesJson = json_encode(array_values(array_filter($amenities)));
        } else {
            $amenitiesJson = json_encode([]);
        }

        return (int) Database::insert(
            "INSERT INTO campus_facilities 
            (school_id, facility_code, name, facility_type, building_block, floor, capacity, hourly_rate, amenities_json, status, rules_notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
            [
                $schoolId,
                $code,
                trim((string)($data['name'] ?? 'Facility')),
                $data['facility_type'] ?? 'smart_classroom',
                trim((string)($data['building_block'] ?? '')),
                trim((string)($data['floor'] ?? '')),
                max(1, (int)($data['capacity'] ?? 30)),
                (float)($data['hourly_rate'] ?? 0.0),
                $amenitiesJson,
                $data['status'] ?? 'available',
                trim((string)($data['rules_notes'] ?? '')),
            ]
        );
    }

    public function updateFacility(int $schoolId, int $facilityId, array $data): bool
    {
        $this->ensureSchema();
        $amenities = $data['amenities'] ?? [];
        if (is_array($amenities)) {
            $amenitiesJson = json_encode(array_values(array_filter($amenities)));
        } else {
            $amenitiesJson = json_encode([]);
        }

        return Database::execute(
            "UPDATE campus_facilities SET
                facility_code = ?,
                name = ?,
                facility_type = ?,
                building_block = ?,
                floor = ?,
                capacity = ?,
                hourly_rate = ?,
                amenities_json = ?,
                status = ?,
                rules_notes = ?,
                updated_at = NOW()
            WHERE id = ? AND school_id = ?",
            [
                trim((string)($data['facility_code'] ?? '')),
                trim((string)($data['name'] ?? '')),
                $data['facility_type'] ?? 'smart_classroom',
                trim((string)($data['building_block'] ?? '')),
                trim((string)($data['floor'] ?? '')),
                max(1, (int)($data['capacity'] ?? 30)),
                (float)($data['hourly_rate'] ?? 0.0),
                $amenitiesJson,
                $data['status'] ?? 'available',
                trim((string)($data['rules_notes'] ?? '')),
                $facilityId,
                $schoolId,
            ]
        ) > 0;
    }

    public function deleteFacility(int $schoolId, int $facilityId): bool
    {
        $this->ensureSchema();
        return Database::execute(
            "DELETE FROM campus_facilities WHERE id = ? AND school_id = ?",
            [$facilityId, $schoolId]
        ) > 0;
    }

    // =========================================================================
    // 2. FACILITY & ROOM RESERVATION ENGINE WITH CONFLICT DETECTION
    // =========================================================================

    /**
     * Checks if a proposed time slot conflicts with an existing booking in the same facility.
     * Returns the conflicting booking record, or null if free.
     */
    public function checkBookingConflict(int $schoolId, int $facilityId, string $startTime, string $endTime, ?int $excludeBookingId = null): ?array
    {
        $this->ensureSchema();
        $query = "SELECT b.*, f.name AS facility_name, u.name AS booked_by_name
                  FROM facility_bookings b
                  JOIN campus_facilities f ON f.id = b.facility_id
                  LEFT JOIN users u ON u.id = b.requested_by_user_id
                  WHERE b.school_id = ?
                    AND b.facility_id = ?
                    AND b.status IN ('confirmed', 'pending')
                    AND b.start_time < ?
                    AND b.end_time > ?";
        $params = [$schoolId, $facilityId, $endTime, $startTime];

        if ($excludeBookingId !== null) {
            $query .= " AND b.id != ?";
            $params[] = $excludeBookingId;
        }

        $query .= " LIMIT 1";
        return Database::fetch($query, $params);
    }

    public function createBooking(int $schoolId, array $data, int $userId): array
    {
        $this->ensureSchema();
        $facilityId = (int)($data['facility_id'] ?? 0);
        $facility = $this->getFacility($schoolId, $facilityId);
        if (!$facility) {
            return ['success' => false, 'error' => 'Selected facility was not found.'];
        }

        $startTime = date('Y-m-d H:i:s', strtotime((string)($data['start_time'] ?? '')));
        $endTime = date('Y-m-d H:i:s', strtotime((string)($data['end_time'] ?? '')));

        if (strtotime($endTime) <= strtotime($startTime)) {
            return ['success' => false, 'error' => 'End time must be chronologically after the start time.'];
        }

        // Conflict check
        $conflictOverride = !empty($data['conflict_override']);
        if (!$conflictOverride) {
            $conflict = $this->checkBookingConflict($schoolId, $facilityId, $startTime, $endTime);
            if ($conflict) {
                return [
                    'success' => false,
                    'error' => "Booking collision! '{$conflict['facility_name']}' is already reserved for '{$conflict['title']}' from {$conflict['start_time']} to {$conflict['end_time']}.",
                    'conflict' => $conflict,
                ];
            }
        }

        $bookingRef = 'BKG-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

        $bookingId = (int) Database::insert(
            "INSERT INTO facility_bookings 
            (school_id, facility_id, booking_ref, title, purpose, start_time, end_time, expected_attendees, status, requested_by_user_id, conflict_override, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, NOW(), NOW())",
            [
                $schoolId,
                $facilityId,
                $bookingRef,
                trim((string)($data['title'] ?? 'Room Reservation')),
                trim((string)($data['purpose'] ?? '')),
                $startTime,
                $endTime,
                max(0, (int)($data['expected_attendees'] ?? 0)),
                $userId,
                $conflictOverride ? 1 : 0,
            ]
        );

        return [
            'success' => true,
            'booking_id' => $bookingId,
            'booking_ref' => $bookingRef,
        ];
    }

    public function listBookings(int $schoolId, ?int $facilityId = null, ?string $status = null, ?string $date = null, int $limit = 50): array
    {
        $this->ensureSchema();
        $query = "SELECT b.*, f.name AS facility_name, f.facility_code, f.building_block, u.name AS requester_name, u.email AS requester_email
                  FROM facility_bookings b
                  JOIN campus_facilities f ON f.id = b.facility_id
                  LEFT JOIN users u ON u.id = b.requested_by_user_id
                  WHERE b.school_id = ?";
        $params = [$schoolId];

        if ($facilityId !== null && $facilityId > 0) {
            $query .= " AND b.facility_id = ?";
            $params[] = $facilityId;
        }

        if ($status !== null && $status !== '' && $status !== 'all') {
            $query .= " AND b.status = ?";
            $params[] = $status;
        }

        if ($date !== null && $date !== '') {
            $query .= " AND DATE(b.start_time) = ?";
            $params[] = $date;
        }

        $query .= " ORDER BY b.start_time DESC LIMIT " . $limit;
        return Database::fetchAll($query, $params);
    }

    public function updateBookingStatus(int $schoolId, int $bookingId, string $status, ?string $remarks, int $reviewerUserId): bool
    {
        $this->ensureSchema();
        $allowed = ['pending', 'confirmed', 'rejected', 'completed', 'cancelled'];
        if (!in_array($status, $allowed, true)) {
            return false;
        }

        return Database::execute(
            "UPDATE facility_bookings SET
                status = ?,
                reviewer_remarks = ?,
                reviewer_user_id = ?,
                updated_at = NOW()
            WHERE id = ? AND school_id = ?",
            [$status, $remarks, $reviewerUserId, $bookingId, $schoolId]
        ) > 0;
    }

    // =========================================================================
    // 3. FIXED ASSET LIFECYCLE & DEPRECIATION ACCOUNTING
    // =========================================================================

    /**
     * Calculates depreciation and Net Book Value (NBV) deterministically.
     */
    public function calculateDepreciation(array $asset, ?string $asOfDate = null): array
    {
        $cost = (float)($asset['purchase_cost'] ?? 0.0);
        $salvage = (float)($asset['salvage_value'] ?? 0.0);
        $usefulYears = max(1, (int)($asset['useful_life_years'] ?? 5));
        $method = (string)($asset['depreciation_method'] ?? 'straight_line');

        $purchaseDateStr = (string)($asset['purchase_date'] ?? date('Y-m-d'));
        $purchaseTime = strtotime($purchaseDateStr);
        $evalTime = $asOfDate ? strtotime($asOfDate) : time();

        if ($evalTime <= $purchaseTime) {
            return [
                'cost' => $cost,
                'salvage_value' => $salvage,
                'useful_life_years' => $usefulYears,
                'elapsed_years' => 0.0,
                'annual_depreciation' => 0.0,
                'accumulated_depreciation' => 0.0,
                'net_book_value' => $cost,
            ];
        }

        $elapsedSeconds = $evalTime - $purchaseTime;
        $elapsedYears = round($elapsedSeconds / (365.25 * 86400), 2);
        $depreciableBase = max(0.0, $cost - $salvage);

        if ($method === 'none') {
            return [
                'cost' => $cost,
                'salvage_value' => $salvage,
                'useful_life_years' => $usefulYears,
                'elapsed_years' => $elapsedYears,
                'annual_depreciation' => 0.0,
                'accumulated_depreciation' => 0.0,
                'net_book_value' => $cost,
            ];
        }

        if ($method === 'reducing_balance') {
            // Standard Reducing Balance rate: double declining rate capped or (1 - (salvage/cost)^(1/n))
            $rate = ($cost > 0 && $salvage > 0) ? (1.0 - pow($salvage / $cost, 1.0 / $usefulYears)) : (2.0 / $usefulYears);
            $rate = min(0.40, max(0.10, $rate));

            $bookValue = $cost;
            for ($yr = 1; $yr <= floor($elapsedYears); $yr++) {
                $dep = $bookValue * $rate;
                $bookValue = max($salvage, $bookValue - $dep);
            }
            $partial = $elapsedYears - floor($elapsedYears);
            if ($partial > 0 && $bookValue > $salvage) {
                $dep = ($bookValue * $rate) * $partial;
                $bookValue = max($salvage, $bookValue - $dep);
            }

            $accumulated = round($cost - $bookValue, 2);
            $annualDep = round($bookValue * $rate, 2);

            return [
                'cost' => $cost,
                'salvage_value' => $salvage,
                'useful_life_years' => $usefulYears,
                'elapsed_years' => $elapsedYears,
                'annual_depreciation' => $annualDep,
                'accumulated_depreciation' => $accumulated,
                'net_book_value' => round($bookValue, 2),
            ];
        }

        // Straight-line method
        $annualDep = round($depreciableBase / $usefulYears, 2);
        $accumulated = min($depreciableBase, round($annualDep * $elapsedYears, 2));
        $netBookValue = round(max($salvage, $cost - $accumulated), 2);

        return [
            'cost' => $cost,
            'salvage_value' => $salvage,
            'useful_life_years' => $usefulYears,
            'elapsed_years' => $elapsedYears,
            'annual_depreciation' => $annualDep,
            'accumulated_depreciation' => $accumulated,
            'net_book_value' => $netBookValue,
        ];
    }

    public function createAsset(int $schoolId, array $data): int
    {
        $this->ensureSchema();
        $assetTag = trim((string)($data['asset_tag'] ?? ''));
        if ($assetTag === '') {
            $assetTag = 'AST-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        }

        $facilityId = !empty($data['facility_id']) ? (int)$data['facility_id'] : null;

        return (int) Database::insert(
            "INSERT INTO fixed_assets
            (school_id, asset_tag, name, category, serial_number, barcode, facility_id, purchase_date, purchase_cost, salvage_value, useful_life_years, depreciation_method, status, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
            [
                $schoolId,
                $assetTag,
                trim((string)($data['name'] ?? 'Asset Item')),
                $data['category'] ?? 'general',
                trim((string)($data['serial_number'] ?? '')),
                trim((string)($data['barcode'] ?? '')),
                $facilityId,
                $data['purchase_date'] ?? date('Y-m-d'),
                max(0.0, (float)($data['purchase_cost'] ?? 0.0)),
                max(0.0, (float)($data['salvage_value'] ?? 0.0)),
                max(1, (int)($data['useful_life_years'] ?? 5)),
                $data['depreciation_method'] ?? 'straight_line',
                $data['status'] ?? 'in_service',
                trim((string)($data['notes'] ?? '')),
            ]
        );
    }

    public function listAssets(int $schoolId, ?string $category = null, ?string $status = null, ?string $search = null): array
    {
        $this->ensureSchema();
        $query = "SELECT a.*, f.name AS facility_name, f.building_block, u.name AS assigned_user_name
                  FROM fixed_assets a
                  LEFT JOIN campus_facilities f ON f.id = a.facility_id
                  LEFT JOIN users u ON u.id = a.assigned_to_user_id
                  WHERE a.school_id = ?";
        $params = [$schoolId];

        if ($category !== null && $category !== '' && $category !== 'all') {
            $query .= " AND a.category = ?";
            $params[] = $category;
        }

        if ($status !== null && $status !== '' && $status !== 'all') {
            $query .= " AND a.status = ?";
            $params[] = $status;
        }

        if ($search !== null && $search !== '') {
            $query .= " AND (a.name LIKE ? OR a.asset_tag LIKE ? OR a.serial_number LIKE ?)";
            $wild = '%' . $search . '%';
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }

        $query .= " ORDER BY a.id DESC";
        $rows = Database::fetchAll($query, $params);

        // Augment with live depreciation calculations
        foreach ($rows as &$r) {
            $dep = $this->calculateDepreciation($r);
            $r['calculated_net_book_value'] = $dep['net_book_value'];
            $r['accumulated_depreciation'] = $dep['accumulated_depreciation'];
            $r['annual_depreciation'] = $dep['annual_depreciation'];
        }
        unset($r);

        return $rows;
    }

    public function getAsset(int $schoolId, int $assetId): ?array
    {
        $this->ensureSchema();
        $asset = Database::fetch(
            "SELECT a.*, f.name AS facility_name, u.name AS assigned_user_name
             FROM fixed_assets a
             LEFT JOIN campus_facilities f ON f.id = a.facility_id
             LEFT JOIN users u ON u.id = a.assigned_to_user_id
             WHERE a.id = ? AND a.school_id = ? LIMIT 1",
            [$assetId, $schoolId]
        );

        if ($asset) {
            $dep = $this->calculateDepreciation($asset);
            $asset['depreciation'] = $dep;
        }

        return $asset;
    }

    public function updateAsset(int $schoolId, int $assetId, array $data): bool
    {
        $this->ensureSchema();
        $facilityId = !empty($data['facility_id']) ? (int)$data['facility_id'] : null;

        return Database::execute(
            "UPDATE fixed_assets SET
                asset_tag = ?,
                name = ?,
                category = ?,
                serial_number = ?,
                barcode = ?,
                facility_id = ?,
                purchase_date = ?,
                purchase_cost = ?,
                salvage_value = ?,
                useful_life_years = ?,
                depreciation_method = ?,
                status = ?,
                notes = ?,
                updated_at = NOW()
            WHERE id = ? AND school_id = ?",
            [
                trim((string)($data['asset_tag'] ?? '')),
                trim((string)($data['name'] ?? '')),
                $data['category'] ?? 'general',
                trim((string)($data['serial_number'] ?? '')),
                trim((string)($data['barcode'] ?? '')),
                $facilityId,
                $data['purchase_date'] ?? date('Y-m-d'),
                max(0.0, (float)($data['purchase_cost'] ?? 0.0)),
                max(0.0, (float)($data['salvage_value'] ?? 0.0)),
                max(1, (int)($data['useful_life_years'] ?? 5)),
                $data['depreciation_method'] ?? 'straight_line',
                $data['status'] ?? 'in_service',
                trim((string)($data['notes'] ?? '')),
                $assetId,
                $schoolId,
            ]
        ) > 0;
    }

    public function deleteAsset(int $schoolId, int $assetId): bool
    {
        $this->ensureSchema();
        return Database::execute("DELETE FROM fixed_assets WHERE id = ? AND school_id = ?", [$assetId, $schoolId]) > 0;
    }

    // =========================================================================
    // 4. ASSET CUSTODY & CHECKOUT LEDGER
    // =========================================================================

    public function checkoutAsset(
        int $schoolId,
        int $assetId,
        string $assignedToType,
        ?int $assignedToId,
        string $assignedToName,
        string $condition,
        ?string $expectedReturnDate,
        int $userId,
        ?string $remarks = null
    ): array {
        $this->ensureSchema();
        $asset = $this->getAsset($schoolId, $assetId);
        if (!$asset) {
            return ['success' => false, 'error' => 'Asset not found.'];
        }

        if ($asset['status'] === 'decommissioned' || $asset['status'] === 'disposed') {
            return ['success' => false, 'error' => 'Cannot check out a decommissioned or disposed asset.'];
        }

        Database::beginTransaction();
        try {
            $logId = (int) Database::insert(
                "INSERT INTO asset_custody_logs 
                (school_id, asset_id, action, assigned_to_type, assigned_to_id, assigned_to_name, condition_state, expected_return_date, logged_by_user_id, remarks, created_at)
                VALUES (?, ?, 'checkout', ?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $schoolId,
                    $assetId,
                    $assignedToType,
                    $assignedToId,
                    $assignedToName,
                    $condition,
                    $expectedReturnDate ?: null,
                    $userId,
                    $remarks,
                ]
            );

            Database::execute(
                "UPDATE fixed_assets SET assigned_to_user_id = ?, status = 'in_service', updated_at = NOW() WHERE id = ? AND school_id = ?",
                [$assignedToType === 'staff' ? $assignedToId : null, $assetId, $schoolId]
            );

            Database::commit();
            return ['success' => true, 'log_id' => $logId];
        } catch (\Throwable $e) {
            Database::rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function checkinAsset(
        int $schoolId,
        int $assetId,
        string $condition,
        int $userId,
        ?string $remarks = null
    ): array {
        $this->ensureSchema();
        $asset = $this->getAsset($schoolId, $assetId);
        if (!$asset) {
            return ['success' => false, 'error' => 'Asset not found.'];
        }

        Database::beginTransaction();
        try {
            $logId = (int) Database::insert(
                "INSERT INTO asset_custody_logs 
                (school_id, asset_id, action, assigned_to_type, assigned_to_name, condition_state, actual_return_date, logged_by_user_id, remarks, created_at)
                VALUES (?, ?, 'checkin', 'facility', 'Campus Asset Pool', ?, CURDATE(), ?, ?, NOW())",
                [
                    $schoolId,
                    $assetId,
                    $condition,
                    $userId,
                    $remarks,
                ]
            );

            $newStatus = ($condition === 'damaged') ? 'under_maintenance' : 'in_service';

            Database::execute(
                "UPDATE fixed_assets SET assigned_to_user_id = NULL, status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
                [$newStatus, $assetId, $schoolId]
            );

            Database::commit();
            return ['success' => true, 'log_id' => $logId, 'new_status' => $newStatus];
        } catch (\Throwable $e) {
            Database::rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getAssetCustodyLogs(int $schoolId, int $assetId): array
    {
        $this->ensureSchema();
        return Database::fetchAll(
            "SELECT c.*, u.name AS logged_by_name
             FROM asset_custody_logs c
             LEFT JOIN users u ON u.id = c.logged_by_user_id
             WHERE c.school_id = ? AND c.asset_id = ?
             ORDER BY c.created_at DESC",
            [$schoolId, $assetId]
        );
    }

    // =========================================================================
    // 5. FACILITY & ASSET WORK ORDERS / MAINTENANCE
    // =========================================================================

    public function createWorkOrder(int $schoolId, array $data, int $userId): int
    {
        $this->ensureSchema();
        $woNo = 'WO-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        $facilityId = !empty($data['facility_id']) ? (int)$data['facility_id'] : null;
        $assetId = !empty($data['asset_id']) ? (int)$data['asset_id'] : null;
        $priority = $data['priority'] ?? 'medium';

        $woId = (int) Database::insert(
            "INSERT INTO facility_work_orders
            (school_id, work_order_no, title, description, facility_id, asset_id, category, priority, status, assigned_technician, technician_phone, estimated_cost, scheduled_date, reported_by_user_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?, ?, NOW(), NOW())",
            [
                $schoolId,
                $woNo,
                trim((string)($data['title'] ?? 'Maintenance Request')),
                trim((string)($data['description'] ?? '')),
                $facilityId,
                $assetId,
                $data['category'] ?? 'general',
                $priority,
                trim((string)($data['assigned_technician'] ?? '')),
                trim((string)($data['technician_phone'] ?? '')),
                max(0.0, (float)($data['estimated_cost'] ?? 0.0)),
                !empty($data['scheduled_date']) ? $data['scheduled_date'] : null,
                $userId,
            ]
        );

        // If asset is linked and work order is high or urgent priority, put asset in under_maintenance
        if ($assetId && in_array($priority, ['high', 'urgent'], true)) {
            Database::execute("UPDATE fixed_assets SET status = 'under_maintenance', updated_at = NOW() WHERE id = ? AND school_id = ?", [$assetId, $schoolId]);
        }

        return $woId;
    }

    public function listWorkOrders(int $schoolId, ?string $status = null, ?string $priority = null, ?string $category = null, int $limit = 50): array
    {
        $this->ensureSchema();
        $query = "SELECT w.*, f.name AS facility_name, a.name AS asset_name, a.asset_tag, u.name AS reporter_name
                  FROM facility_work_orders w
                  LEFT JOIN campus_facilities f ON f.id = w.facility_id
                  LEFT JOIN fixed_assets a ON a.id = w.asset_id
                  LEFT JOIN users u ON u.id = w.reported_by_user_id
                  WHERE w.school_id = ?";
        $params = [$schoolId];

        if ($status !== null && $status !== '' && $status !== 'all') {
            $query .= " AND w.status = ?";
            $params[] = $status;
        }

        if ($priority !== null && $priority !== '' && $priority !== 'all') {
            $query .= " AND w.priority = ?";
            $params[] = $priority;
        }

        if ($category !== null && $category !== '' && $category !== 'all') {
            $query .= " AND w.category = ?";
            $params[] = $category;
        }

        $query .= " ORDER BY CASE w.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END, w.created_at DESC LIMIT " . $limit;
        return Database::fetchAll($query, $params);
    }

    public function updateWorkOrderStatus(int $schoolId, int $woId, string $status, float $actualCost, ?string $resolutionNotes): bool
    {
        $this->ensureSchema();
        $allowed = ['open', 'in_progress', 'on_hold', 'completed', 'cancelled'];
        if (!in_array($status, $allowed, true)) {
            return false;
        }

        $completedAt = ($status === 'completed') ? date('Y-m-d H:i:s') : null;

        $updated = Database::execute(
            "UPDATE facility_work_orders SET
                status = ?,
                actual_cost = ?,
                resolution_notes = ?,
                completed_at = COALESCE(?, completed_at),
                updated_at = NOW()
            WHERE id = ? AND school_id = ?",
            [$status, $actualCost, $resolutionNotes, $completedAt, $woId, $schoolId]
        ) > 0;

        // If completed and linked to asset, return asset to in_service
        if ($updated && $status === 'completed') {
            $wo = Database::fetch("SELECT asset_id FROM facility_work_orders WHERE id = ? AND school_id = ? LIMIT 1", [$woId, $schoolId]);
            if (!empty($wo['asset_id'])) {
                Database::execute("UPDATE fixed_assets SET status = 'in_service', updated_at = NOW() WHERE id = ? AND school_id = ?", [(int)$wo['asset_id'], $schoolId]);
            }
        }

        return $updated;
    }

    // =========================================================================
    // 6. METRICS & TELEMETRY
    // =========================================================================

    public function getMetrics(int $schoolId): array
    {
        $this->ensureSchema();

        $facilities = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) AS available_count,
                    SUM(capacity) AS total_capacity
             FROM campus_facilities WHERE school_id = ?",
            [$schoolId]
        );

        $bookings = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status = 'confirmed' AND start_time >= NOW() THEN 1 ELSE 0 END) AS upcoming_confirmed,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count
             FROM facility_bookings WHERE school_id = ?",
            [$schoolId]
        );

        $assets = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(purchase_cost) AS total_cost,
                    SUM(CASE WHEN status = 'in_service' THEN 1 ELSE 0 END) AS in_service_count,
                    SUM(CASE WHEN status = 'under_maintenance' THEN 1 ELSE 0 END) AS under_maintenance_count
             FROM fixed_assets WHERE school_id = ?",
            [$schoolId]
        );

        // Calculate live Net Book Value of all assets
        $allAssets = Database::fetchAll("SELECT * FROM fixed_assets WHERE school_id = ? AND status != 'disposed'", [$schoolId]);
        $totalBookValue = 0.0;
        foreach ($allAssets as $ast) {
            $dep = $this->calculateDepreciation($ast);
            $totalBookValue += (float)$dep['net_book_value'];
        }

        $workOrders = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status IN ('open', 'in_progress') THEN 1 ELSE 0 END) AS active_orders,
                    SUM(CASE WHEN priority = 'urgent' AND status IN ('open', 'in_progress') THEN 1 ELSE 0 END) AS urgent_orders,
                    SUM(CASE WHEN status = 'completed' AND completed_at >= DATE_FORMAT(NOW(), '%Y-%m-01') THEN actual_cost ELSE 0 END) AS mtd_spend
             FROM facility_work_orders WHERE school_id = ?",
            [$schoolId]
        );

        return [
            'facilities_total' => (int)($facilities['total'] ?? 0),
            'facilities_available' => (int)($facilities['available_count'] ?? 0),
            'facilities_capacity' => (int)($facilities['total_capacity'] ?? 0),
            'bookings_total' => (int)($bookings['total'] ?? 0),
            'bookings_upcoming' => (int)($bookings['upcoming_confirmed'] ?? 0),
            'bookings_pending' => (int)($bookings['pending_count'] ?? 0),
            'assets_total' => (int)($assets['total'] ?? 0),
            'assets_original_cost' => (float)($assets['total_cost'] ?? 0.0),
            'assets_net_book_value' => round($totalBookValue, 2),
            'assets_in_service' => (int)($assets['in_service_count'] ?? 0),
            'assets_under_maintenance' => (int)($assets['under_maintenance_count'] ?? 0),
            'work_orders_total' => (int)($workOrders['total'] ?? 0),
            'work_orders_active' => (int)($workOrders['active_orders'] ?? 0),
            'work_orders_urgent' => (int)($workOrders['urgent_orders'] ?? 0),
            'work_orders_mtd_spend' => (float)($workOrders['mtd_spend'] ?? 0.0),
        ];
    }
}
