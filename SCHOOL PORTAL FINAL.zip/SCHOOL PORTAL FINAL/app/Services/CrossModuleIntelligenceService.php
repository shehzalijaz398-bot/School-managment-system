<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

/**
 * CrossModuleIntelligenceService
 * 
 * Non-destructive intelligence and operational health scanner.
 * Scans relational consistency across Attendance, Finance, Admissions, Exams, Timetables,
 * and Student Records, generating evidence-based alerts and actionable recommendations.
 */
final class CrossModuleIntelligenceService
{
    /**
     * Run full intelligence audit and compute institutional health scorecard.
     */
    public function auditSchool(int $schoolId): array
    {
        $alerts = [];

        // 1. Module Inconsistency Audits
        $attendanceAlerts = $this->auditAttendance($schoolId);
        $financeAlerts = $this->auditFinanceAndAdmissions($schoolId);
        $examAlerts = $this->auditExamsAndGrading($schoolId);
        $timetableAlerts = $this->auditTimetableAndFaculty($schoolId);
        $recordAlerts = $this->auditStudentAndGuardianRecords($schoolId);
        $setupAlerts = $this->auditSetupCompleteness($schoolId);

        $alerts = array_merge(
            $attendanceAlerts,
            $financeAlerts,
            $examAlerts,
            $timetableAlerts,
            $recordAlerts,
            $setupAlerts
        );

        // 2. Scorecard Calculation
        $criticalCount = count(array_filter($alerts, fn($a) => $a['severity'] === 'critical'));
        $warningCount = count(array_filter($alerts, fn($a) => $a['severity'] === 'warning'));
        $infoCount = count(array_filter($alerts, fn($a) => $a['severity'] === 'info'));

        // Compute weighted health score (base 100, -12 per critical, -4 per warning, -1 per info)
        $rawScore = 100 - ($criticalCount * 12) - ($warningCount * 4) - ($infoCount * 1);
        $healthScore = max(10, min(100, $rawScore));

        $statusTier = match (true) {
            $healthScore >= 90 => 'optimal',
            $healthScore >= 75 => 'good',
            $healthScore >= 50 => 'needs_attention',
            default => 'critical',
        };

        // Module Breakdown Scores
        $moduleScores = [
            'setup' => $this->calculateModuleScore($setupAlerts),
            'records' => $this->calculateModuleScore($recordAlerts),
            'attendance' => $this->calculateModuleScore($attendanceAlerts),
            'finance' => $this->calculateModuleScore($financeAlerts),
            'exams' => $this->calculateModuleScore($examAlerts),
            'timetable' => $this->calculateModuleScore($timetableAlerts),
        ];

        // Fetch quick institutional counts
        $totalStudents = (int)(Database::fetch('SELECT COUNT(*) c FROM students WHERE school_id = ? AND status = "active"', [$schoolId])['c'] ?? 0);
        $totalStaff = (int)(Database::fetch('SELECT COUNT(*) c FROM employees WHERE school_id = ? AND status = "active"', [$schoolId])['c'] ?? 0);
        $totalClasses = (int)(Database::fetch('SELECT COUNT(*) c FROM classes WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        $activeYear = Database::fetch('SELECT name FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1', [$schoolId]);

        return [
            'school_id' => $schoolId,
            'health_score' => $healthScore,
            'status_tier' => $statusTier,
            'critical_count' => $criticalCount,
            'warning_count' => $warningCount,
            'info_count' => $infoCount,
            'total_alerts' => count($alerts),
            'module_scores' => $moduleScores,
            'alerts' => $alerts,
            'summary' => [
                'total_active_students' => $totalStudents,
                'total_active_staff' => $totalStaff,
                'total_classes' => $totalClasses,
                'academic_year' => $activeYear['name'] ?? 'Not Configured',
                'audited_at' => date('Y-m-d H:i:s'),
            ],
        ];
    }

    private function calculateModuleScore(array $moduleAlerts): int
    {
        $crit = count(array_filter($moduleAlerts, fn($a) => $a['severity'] === 'critical'));
        $warn = count(array_filter($moduleAlerts, fn($a) => $a['severity'] === 'warning'));
        $score = 100 - ($crit * 25) - ($warn * 10);
        return max(20, min(100, $score));
    }

    /**
     * 1. Attendance consistency check
     */
    private function auditAttendance(int $schoolId): array
    {
        $alerts = [];

        // Check active students with zero attendance logs in the last 30 days
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
        $ghostStudents = Database::fetchAll("
            SELECT s.id, s.first_name, s.last_name, s.admission_no, c.name as class_name
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.school_id = ? AND s.status = 'active'
              AND s.id NOT IN (
                  SELECT DISTINCT student_id FROM student_attendance 
                  WHERE school_id = ? AND attendance_date >= ?
              )
            LIMIT 10
        ", [$schoolId, $schoolId, $thirtyDaysAgo]);

        $totalGhostCount = (int)(Database::fetch("
            SELECT COUNT(*) c FROM students s
            WHERE s.school_id = ? AND s.status = 'active'
              AND s.id NOT IN (
                  SELECT DISTINCT student_id FROM student_attendance 
                  WHERE school_id = ? AND attendance_date >= ?
              )
        ", [$schoolId, $schoolId, $thirtyDaysAgo])['c'] ?? 0);

        if ($totalGhostCount > 0) {
            $samples = array_map(fn($s) => "{$s['first_name']} {$s['last_name']} ({$s['admission_no']}, Class: {$s['class_name']})", array_slice($ghostStudents, 0, 5));
            $alerts[] = [
                'module' => 'attendance',
                'severity' => $totalGhostCount > 20 ? 'critical' : 'warning',
                'title' => 'Active Students Without Attendance Records (Last 30 Days)',
                'description' => "{$totalGhostCount} active students have zero logged attendance entries for the past month. This may indicate unsubmitted classroom registers or phantom enrollments.",
                'evidence_count' => $totalGhostCount,
                'evidence_samples' => $samples,
                'recommended_action' => 'Submit pending attendance registers or verify enrollment statuses.',
                'action_url' => url('attendance/students'),
            ];
        }

        return $alerts;
    }

    /**
     * 2. Finance and Admissions consistency check
     */
    private function auditFinanceAndAdmissions(int $schoolId): array
    {
        $alerts = [];

        // Find active students who have NO fee invoices generated
        $studentsWithoutInvoices = Database::fetchAll("
            SELECT s.id, s.first_name, s.last_name, s.admission_no, c.name as class_name
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.school_id = ? AND s.status = 'active'
              AND s.id NOT IN (SELECT DISTINCT student_id FROM student_fee_invoices WHERE school_id = ?)
            LIMIT 10
        ", [$schoolId, $schoolId]);

        $countWithoutInvoices = (int)(Database::fetch("
            SELECT COUNT(*) c FROM students s
            WHERE s.school_id = ? AND s.status = 'active'
              AND s.id NOT IN (SELECT DISTINCT student_id FROM student_fee_invoices WHERE school_id = ?)
        ", [$schoolId, $schoolId])['c'] ?? 0);

        if ($countWithoutInvoices > 0) {
            $samples = array_map(fn($s) => "{$s['first_name']} {$s['last_name']} ({$s['admission_no']})", array_slice($studentsWithoutInvoices, 0, 5));
            $alerts[] = [
                'module' => 'finance',
                'severity' => $countWithoutInvoices > 10 ? 'critical' : 'warning',
                'title' => 'Enrolled Students Missing Fee Invoices',
                'description' => "{$countWithoutInvoices} active students currently have no fee billing records or invoices on file.",
                'evidence_count' => $countWithoutInvoices,
                'evidence_samples' => $samples,
                'recommended_action' => 'Generate term fee invoices via Finance Batch Generator.',
                'action_url' => url('finance/fees/batch'),
            ];
        }

        // Find unpaid invoices that have matching payments logged in payments table
        $mismatchedInvoices = Database::fetchAll("
            SELECT i.id, i.invoice_no, i.total_amount, i.paid_amount, i.status,
                   COALESCE(SUM(p.amount), 0) as ledger_sum
            FROM student_fee_invoices i
            LEFT JOIN payments p ON p.invoice_id = i.id
            WHERE i.school_id = ? AND i.status != 'cancelled'
            GROUP BY i.id
            HAVING (i.status = 'unpaid' AND ledger_sum >= i.total_amount AND i.total_amount > 0)
                OR (ABS(i.paid_amount - ledger_sum) > 0.01)
            LIMIT 10
        ", [$schoolId]);

        if (!empty($mismatchedInvoices)) {
            $samples = array_map(fn($inv) => "Inv #{$inv['invoice_no']} (Status: {$inv['status']}, Total: {$inv['total_amount']}, Recorded Paid: {$inv['paid_amount']}, Ledger Sum: {$inv['ledger_sum']})", array_slice($mismatchedInvoices, 0, 5));
            $alerts[] = [
                'module' => 'finance',
                'severity' => 'critical',
                'title' => 'Invoice Ledger Balance Discrepancy',
                'description' => count($mismatchedInvoices) . ' invoices have discrepancies between recorded paid amounts and actual payment receipts, or remain marked unpaid despite receipt records.',
                'evidence_count' => count($mismatchedInvoices),
                'evidence_samples' => $samples,
                'recommended_action' => 'Open Finance Reconciliation to audit payment transactions.',
                'action_url' => url('finance/reconciliation'),
            ];
        }

        return $alerts;
    }

    /**
     * 3. Exams & Grading consistency check
     */
    private function auditExamsAndGrading(int $schoolId): array
    {
        $alerts = [];

        // Check published/completed exams with missing student marks
        $examsWithMissingMarks = Database::fetchAll("
            SELECT e.id, e.name, c.name as class_name,
                   COUNT(s.id) as missing_count
            FROM exams e
            JOIN classes c ON e.class_id = c.id
            JOIN students s ON s.class_id = c.id AND s.school_id = e.school_id AND s.status = 'active'
            LEFT JOIN exam_marks em ON em.exam_id = e.id AND em.student_id = s.id
            WHERE e.school_id = ? AND e.status IN ('published', 'completed') AND em.id IS NULL
            GROUP BY e.id, e.name, c.name
            HAVING missing_count > 0
            LIMIT 10
        ", [$schoolId]);

        if (!empty($examsWithMissingMarks)) {
            $totalMissing = array_sum(array_column($examsWithMissingMarks, 'missing_count'));
            $samples = array_map(fn($ex) => "{$ex['name']} - {$ex['class_name']}: {$ex['missing_count']} students unassigned", array_slice($examsWithMissingMarks, 0, 5));
            $alerts[] = [
                'module' => 'exams',
                'severity' => 'warning',
                'title' => 'Published Examinations With Incomplete Marks',
                'description' => count($examsWithMissingMarks) . " completed/published examinations have {$totalMissing} total missing student scores.",
                'evidence_count' => count($examsWithMissingMarks),
                'evidence_samples' => $samples,
                'recommended_action' => 'Enter missing scores in the Examination Marks Entry screen.',
                'action_url' => url('exams'),
            ];
        }

        // Verify grade scales configuration
        $scalesCount = (int)(Database::fetch('SELECT COUNT(*) c FROM grade_scales WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        if ($scalesCount === 0) {
            $alerts[] = [
                'module' => 'exams',
                'severity' => 'critical',
                'title' => 'No Academic Grading Scale Configured',
                'description' => 'Institution has zero grade scale tiers defined. Report cards and grade boundaries cannot be computed accurately.',
                'evidence_count' => 1,
                'evidence_samples' => ['Missing grade scale rules (e.g. A+, A, B, C, D, F)'],
                'recommended_action' => 'Configure Grade Scales in Institutional Settings or run Setup Wizard.',
                'action_url' => url('onboarding/wizard'),
            ];
        }

        return $alerts;
    }

    /**
     * 4. Timetable and Faculty coverage
     */
    private function auditTimetableAndFaculty(int $schoolId): array
    {
        $alerts = [];

        // Check timetable slots without an assigned instructor
        $slotsWithoutTeacher = Database::fetchAll("
            SELECT t.id, c.name as class_name, sub.name as subject_name, t.day_of_week
            FROM timetables t
            JOIN classes c ON t.class_id = c.id
            JOIN subjects sub ON t.subject_id = sub.id
            WHERE t.school_id = ? AND (t.teacher_id IS NULL OR t.teacher_id = 0)
            LIMIT 10
        ", [$schoolId]);

        if (!empty($slotsWithoutTeacher)) {
            $samples = array_map(fn($s) => "Class: {$s['class_name']}, Subject: {$s['subject_name']}, Day: {$s['day_of_week']}", array_slice($slotsWithoutTeacher, 0, 5));
            $alerts[] = [
                'module' => 'timetable',
                'severity' => 'warning',
                'title' => 'Timetable Schedule Slots Without Assigned Teacher',
                'description' => count($slotsWithoutTeacher) . ' scheduled class timetable periods have no faculty member assigned.',
                'evidence_count' => count($slotsWithoutTeacher),
                'evidence_samples' => $samples,
                'recommended_action' => 'Assign instructors in the Timetable Schedule Builder.',
                'action_url' => url('timetable'),
            ];
        }

        // Check for double-booked instructors
        $conflicts = Database::fetchAll("
            SELECT t1.teacher_id, u.name as teacher_name, t1.day_of_week, t1.period_id,
                   COUNT(*) as slot_count
            FROM timetables t1
            JOIN users u ON t1.teacher_id = u.id
            WHERE t1.school_id = ? AND t1.teacher_id > 0
            GROUP BY t1.teacher_id, t1.day_of_week, t1.period_id
            HAVING slot_count > 1
            LIMIT 10
        ", [$schoolId]);

        if (!empty($conflicts)) {
            $samples = array_map(fn($cf) => "Teacher {$cf['teacher_name']} has {$cf['slot_count']} overlapping sessions on {$cf['day_of_week']}", array_slice($conflicts, 0, 5));
            $alerts[] = [
                'module' => 'timetable',
                'severity' => 'critical',
                'title' => 'Instructor Timetable Schedule Overlaps Detected',
                'description' => count($conflicts) . ' timetable conflicts found where a teacher is double-booked across multiple classes during the same period.',
                'evidence_count' => count($conflicts),
                'evidence_samples' => $samples,
                'recommended_action' => 'Resolve schedule conflicts in Timetable Conflict Manager.',
                'action_url' => url('timetable/conflicts'),
            ];
        }

        return $alerts;
    }

    /**
     * 5. Student & Guardian Records Integrity
     */
    private function auditStudentAndGuardianRecords(int $schoolId): array
    {
        $alerts = [];

        // Active students without an assigned section
        $studentsWithoutSection = Database::fetchAll("
            SELECT s.id, s.first_name, s.last_name, s.admission_no, c.name as class_name
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.school_id = ? AND s.status = 'active' AND (s.section_id IS NULL OR s.section_id = 0)
            LIMIT 10
        ", [$schoolId]);

        if (!empty($studentsWithoutSection)) {
            $samples = array_map(fn($s) => "{$s['first_name']} {$s['last_name']} ({$s['admission_no']}, Class: {$s['class_name']})", array_slice($studentsWithoutSection, 0, 5));
            $alerts[] = [
                'module' => 'records',
                'severity' => 'warning',
                'title' => 'Enrolled Students Unassigned to Class Sections',
                'description' => count($studentsWithoutSection) . ' active students are enrolled in a grade level but lack section placement.',
                'evidence_count' => count($studentsWithoutSection),
                'evidence_samples' => $samples,
                'recommended_action' => 'Assign students to designated class sections in Student Directory.',
                'action_url' => url('students'),
            ];
        }

        // Active students missing emergency phone numbers
        $studentsWithoutContact = Database::fetchAll("
            SELECT s.id, s.first_name, s.last_name, s.admission_no
            FROM students s
            WHERE s.school_id = ? AND s.status = 'active'
              AND (s.phone IS NULL OR TRIM(s.phone) = '')
              AND (s.emergency_phone IS NULL OR TRIM(s.emergency_phone) = '')
            LIMIT 10
        ", [$schoolId]);

        if (!empty($studentsWithoutContact)) {
            $samples = array_map(fn($s) => "{$s['first_name']} {$s['last_name']} ({$s['admission_no']})", array_slice($studentsWithoutContact, 0, 5));
            $alerts[] = [
                'module' => 'records',
                'severity' => 'info',
                'title' => 'Student Records Missing Guardian Emergency Contact',
                'description' => count($studentsWithoutContact) . ' active students have no phone number or linked guardian profile.',
                'evidence_count' => count($studentsWithoutContact),
                'evidence_samples' => $samples,
                'recommended_action' => 'Update student contact info or link parents via Parents portal.',
                'action_url' => url('parents'),
            ];
        }

        return $alerts;
    }

    /**
     * 6. Setup Completeness & Integration Health
     */
    private function auditSetupCompleteness(int $schoolId): array
    {
        $alerts = [];

        // Check active academic session
        $activeYear = Database::fetch('SELECT id, name FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1', [$schoolId]);
        if (!$activeYear) {
            $alerts[] = [
                'module' => 'setup',
                'severity' => 'critical',
                'title' => 'Missing Active Academic Session',
                'description' => 'Institution has no active academic year enabled. Term management, promotions, and attendance tracking require an active session.',
                'evidence_count' => 1,
                'evidence_samples' => ['No academic year marked is_active = 1'],
                'recommended_action' => 'Create or activate an academic session in Academic Sessions.',
                'action_url' => url('academic-sessions'),
            ];
        }

        // Check fee categories
        $feeCatCount = (int)(Database::fetch('SELECT COUNT(*) c FROM fee_categories WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        if ($feeCatCount === 0) {
            $alerts[] = [
                'module' => 'setup',
                'severity' => 'warning',
                'title' => 'Fee Categories Not Yet Configured',
                'description' => 'No fee categories (tuition, transport, admission, etc.) exist in the institutional fee schedule.',
                'evidence_count' => 1,
                'evidence_samples' => ['Zero fee category records'],
                'recommended_action' => 'Configure fee types in Finance Setup.',
                'action_url' => url('finance/fee-types'),
            ];
        }

        // Check pending tasks
        try {
            $overdueTasks = Database::fetchAll("
                SELECT id, title, due_date FROM task_center_items
                WHERE school_id = ? AND status = 'pending' AND due_date < CURDATE()
                LIMIT 5
            ", [$schoolId]);
            if (!empty($overdueTasks)) {
                $samples = array_map(fn($t) => "Task: {$t['title']} (Due: {$t['due_date']})", $overdueTasks);
                $alerts[] = [
                    'module' => 'setup',
                    'severity' => 'info',
                    'title' => 'Overdue Operational Tasks in Task Center',
                    'description' => count($overdueTasks) . ' pending institutional tasks have passed their target deadline.',
                    'evidence_count' => count($overdueTasks),
                    'evidence_samples' => $samples,
                    'recommended_action' => 'Review and resolve pending items in Central Task Center.',
                    'action_url' => url('tasks'),
                ];
            }
        } catch (\Throwable) {
            // Table might not exist in isolated setups
        }

        return $alerts;
    }
}
