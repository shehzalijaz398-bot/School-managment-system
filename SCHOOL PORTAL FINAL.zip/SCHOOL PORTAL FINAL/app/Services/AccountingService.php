<?php

declare(strict_types=1);

namespace App\Services;

use Core\Auth;
use Core\Database;
use Core\Logger\StructuredLogger;
use Core\TenantGuard;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

/**
 * Enterprise Accounting & Financial Automation Service
 *
 * Implements:
 * - Double-entry bookkeeping system (Chart of Accounts, Journal Entries, Ledger Items)
 * - Trial Balance, Balance Sheet, Income Statement (P&L), and General Ledger
 * - Automated double-entry hooks for Invoices, Payments, Refunds, and Expenses
 * - Class-wise Fee Structures & Installment plans
 * - Student Concessions, Waivers & Dynamic Late Fee Rules
 * - Payment Vouchers & Budget Variance Tracking
 * - Automated Fee Due/Overdue Reminders with Duplicate Prevention & Delivery History
 */
final class AccountingService
{
    public function __construct()
    {
        $this->ensureAccountingSchema();
    }

    /**
     * Provision all accounting, budgeting, and fee structure tables idempotently.
     */
    public function ensureAccountingSchema(): void
    {
        // 1. Chart of Accounts
        Database::execute('CREATE TABLE IF NOT EXISTS chart_of_accounts (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            code VARCHAR(20) NOT NULL,
            name VARCHAR(150) NOT NULL,
            type ENUM("asset", "liability", "equity", "revenue", "expense") NOT NULL,
            parent_id BIGINT UNSIGNED NULL,
            opening_balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            current_balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            is_system TINYINT(1) NOT NULL DEFAULT 0,
            status TINYINT(1) NOT NULL DEFAULT 1,
            description VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_school_code (school_id, code),
            INDEX idx_school_type (school_id, type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 2. Journal Entries
        Database::execute('CREATE TABLE IF NOT EXISTS journal_entries (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            entry_no VARCHAR(50) NOT NULL,
            entry_date DATE NOT NULL,
            reference_type ENUM("invoice", "payment", "refund", "expense", "voucher", "payroll", "manual") NOT NULL DEFAULT "manual",
            reference_id BIGINT UNSIGNED NULL,
            description VARCHAR(255) NOT NULL,
            total_debit DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            total_credit DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            status ENUM("draft", "posted", "reversed") NOT NULL DEFAULT "posted",
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_date (school_id, entry_date),
            INDEX idx_school_ref (school_id, reference_type, reference_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 3. Journal Entry Items
        Database::execute('CREATE TABLE IF NOT EXISTS journal_entry_items (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            journal_entry_id BIGINT UNSIGNED NOT NULL,
            account_id BIGINT UNSIGNED NOT NULL,
            debit DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            credit DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            narration VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_journal (journal_entry_id),
            INDEX idx_account (account_id),
            INDEX idx_school_account (school_id, account_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 4. Fee Structures (Class-wise fees & installments)
        Database::execute('CREATE TABLE IF NOT EXISTS fee_structures (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            academic_year_id BIGINT UNSIGNED NULL,
            class_id BIGINT UNSIGNED NOT NULL,
            fee_category_id BIGINT UNSIGNED NOT NULL,
            title VARCHAR(150) NOT NULL,
            amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            installment_no INT UNSIGNED NOT NULL DEFAULT 1,
            due_month TINYINT UNSIGNED NULL,
            status TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_class (school_id, class_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 5. Student Fee Adjustments (Concessions, Waivers, Special Discounts)
        Database::execute('CREATE TABLE IF NOT EXISTS student_fee_adjustments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            academic_year_id BIGINT UNSIGNED NULL,
            fee_category_id BIGINT UNSIGNED NULL,
            adjustment_type ENUM("concession", "scholarship", "waiver", "special_discount", "custom_charge") NOT NULL,
            calculation_type ENUM("fixed", "percentage") NOT NULL DEFAULT "fixed",
            value DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            reason VARCHAR(255) NOT NULL,
            approved_by BIGINT UNSIGNED NULL,
            status ENUM("pending", "approved", "rejected") NOT NULL DEFAULT "approved",
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_student (school_id, student_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 6. Dynamic Late Fee Rules
        Database::execute('CREATE TABLE IF NOT EXISTS fee_late_rules (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            grace_period_days INT UNSIGNED NOT NULL DEFAULT 7,
            rule_type ENUM("fixed", "daily_rate", "percentage") NOT NULL DEFAULT "fixed",
            amount DECIMAL(12,2) NOT NULL DEFAULT 50.00,
            max_late_fee DECIMAL(12,2) NOT NULL DEFAULT 500.00,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_school_late_rule (school_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 7. Payment Vouchers
        Database::execute('CREATE TABLE IF NOT EXISTS payment_vouchers (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            voucher_no VARCHAR(50) NOT NULL,
            voucher_type ENUM("expense", "vendor_payment", "salary_advance", "refund", "petty_cash", "other") NOT NULL DEFAULT "expense",
            payee_name VARCHAR(150) NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            payment_method ENUM("cash", "bank", "cheque", "online") NOT NULL DEFAULT "cash",
            account_id BIGINT UNSIGNED NULL,
            reference_no VARCHAR(100) NULL,
            description TEXT NULL,
            supporting_doc_path VARCHAR(255) NULL,
            status ENUM("draft", "approved", "paid", "cancelled") NOT NULL DEFAULT "approved",
            approved_by BIGINT UNSIGNED NULL,
            paid_at DATETIME NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_status (school_id, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 8. Expense Categories
        Database::execute('CREATE TABLE IF NOT EXISTS expense_categories (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(150) NOT NULL,
            code VARCHAR(50) NOT NULL,
            account_id BIGINT UNSIGNED NULL,
            description VARCHAR(255) NULL,
            status TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_school_name (school_id, name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 9. School Budgets & Department Allocations
        Database::execute('CREATE TABLE IF NOT EXISTS school_budgets (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            academic_year_id BIGINT UNSIGNED NULL,
            category_id BIGINT UNSIGNED NULL,
            department VARCHAR(100) NOT NULL DEFAULT "General",
            fiscal_year VARCHAR(20) NOT NULL,
            allocated_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            spent_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            notes TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_school_year (school_id, fiscal_year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 10. Fee Reminder Logs (Duplicate Prevention & Audit History)
        Database::execute('CREATE TABLE IF NOT EXISTS fee_reminder_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            invoice_id BIGINT UNSIGNED NOT NULL,
            student_id BIGINT UNSIGNED NOT NULL,
            parent_id BIGINT UNSIGNED NULL,
            channel ENUM("sms", "email", "whatsapp", "in_app") NOT NULL DEFAULT "in_app",
            recipient_contact VARCHAR(150) NULL,
            amount_due DECIMAL(12,2) NOT NULL,
            due_date DATE NOT NULL,
            status ENUM("sent", "delivered", "failed", "skipped_duplicate") NOT NULL DEFAULT "sent",
            sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_invoice (invoice_id),
            INDEX idx_school_sent (school_id, sent_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 11. Fee Reminder Settings
        Database::execute('CREATE TABLE IF NOT EXISTS fee_reminder_settings (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            school_id BIGINT UNSIGNED NOT NULL,
            reminder_type ENUM("before_due", "on_due_day", "after_due_overdue") NOT NULL,
            days_offset INT NOT NULL DEFAULT 3,
            channel ENUM("sms", "email", "whatsapp", "in_app") NOT NULL DEFAULT "whatsapp",
            template_body TEXT NULL,
            min_interval_days INT NOT NULL DEFAULT 5,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_school_reminder_type (school_id, reminder_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // 12. Non-breaking extensions to expenses table
        $this->ensureExpensesColumns();
    }

    /**
     * Safely add missing columns to expenses table.
     */
    private function ensureExpensesColumns(): void
    {
        try {
            $cols = Database::fetchAll("DESCRIBE `expenses`");
            $colNames = array_column($cols, 'Field');

            if (!in_array('status', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `status` ENUM('pending', 'approved', 'rejected', 'paid') NOT NULL DEFAULT 'approved' AFTER `amount`");
            }
            if (!in_array('approved_by', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `approved_by` BIGINT UNSIGNED NULL AFTER `status`");
            }
            if (!in_array('approved_at', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `approved_at` DATETIME NULL AFTER `approved_by`");
            }
            if (!in_array('attachment_path', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `attachment_path` VARCHAR(255) NULL AFTER `notes`");
            }
            if (!in_array('voucher_no', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `voucher_no` VARCHAR(50) NULL AFTER `reference_no`");
            }
            if (!in_array('category_id', $colNames, true)) {
                Database::execute("ALTER TABLE `expenses` ADD COLUMN `category_id` BIGINT UNSIGNED NULL AFTER `category`");
            }
        } catch (Throwable $e) {
            // Already present or table locked; ignore
        }
    }

    /**
     * Seed standard Chart of Accounts for a school tenant if not present.
     */
    public function seedDefaultChartOfAccounts(int $schoolId): void
    {
        $existing = Database::fetch('SELECT COUNT(*) AS c FROM chart_of_accounts WHERE school_id = ?', [$schoolId]);
        if (((int) ($existing['c'] ?? 0)) > 0) {
            return;
        }

        $standardAccounts = [
            // ASSETS (1000)
            ['1010', 'Cash in Hand', 'asset', 'Main physical cash repository at school accounts desk', 0.00],
            ['1020', 'Main Operating Bank Account', 'asset', 'Primary institutional checking account', 0.00],
            ['1030', 'Petty Cash Desk', 'asset', 'Daily administrative petty cash drawer', 0.00],
            ['1050', 'Accounts Receivable (Student Fees)', 'asset', 'Total outstanding student tuition and fee receivables', 0.00],
            // LIABILITIES (2000)
            ['2010', 'Accounts Payable (Vendors)', 'liability', 'Short-term liabilities to book/uniform/utility vendors', 0.00],
            ['2020', 'Unearned Fee Revenue (Advances)', 'liability', 'Advance fee prepayments from parents prior to term start', 0.00],
            ['2030', 'Student Security & Caution Deposits', 'liability', 'Refundable security deposits collected at admission', 0.00],
            // EQUITY (3000)
            ['3010', 'General Operating Fund / Retained Earnings', 'equity', 'Accumulated operational surplus across terms', 0.00],
            ['3020', 'School Capital Endowment', 'equity', 'Founding institutional capital endowment', 0.00],
            // REVENUE (4000)
            ['4010', 'Tuition Fee Revenue', 'revenue', 'Academic tuition fee collections', 0.00],
            ['4020', 'Admission & Registration Fees', 'revenue', 'New student enrollment and registration fees', 0.00],
            ['4030', 'Examination & Assessment Fees', 'revenue', 'Term examinations and evaluation fees', 0.00],
            ['4040', 'Transport & Commute Revenue', 'revenue', 'Student bus transport collections', 0.00],
            ['4050', 'Miscellaneous & Facility Income', 'revenue', 'Library fines, sports day fees, and hall rent', 0.00],
            // EXPENSES (5000)
            ['5010', 'Faculty & Staff Payroll Expense', 'expense', 'Monthly teacher and staff salaries and benefits', 0.00],
            ['5020', 'Building Rent & Campus Lease', 'expense', 'Physical campus premises rent and lease', 0.00],
            ['5030', 'Utilities (Power, Water, Telecom)', 'expense', 'Electricity, high-speed internet, and water bills', 0.00],
            ['5040', 'Educational Supplies & Textbooks', 'expense', 'Curriculum books, stationery, science lab consumables', 0.00],
            ['5050', 'Administrative & Office Operating Expense', 'expense', 'Printing, audit, legal, and operational overhead', 0.00],
            ['5060', 'Vehicle Maintenance & Bus Fuel', 'expense', 'School bus diesel, servicing, and transport maintenance', 0.00],
            ['5070', 'Scholarships & Fee Concessions Given', 'expense', 'Institutional discounts, merit scholarships and sibling waivers', 0.00],
            ['5080', 'Bank & Gateway Merchant Surcharges', 'expense', 'Card processing fees, payment gateway commissions', 0.00],
        ];

        foreach ($standardAccounts as $acc) {
            Database::execute(
                'INSERT INTO chart_of_accounts 
                 (school_id, code, name, type, description, opening_balance, current_balance, is_system, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, NOW())
                 ON DUPLICATE KEY UPDATE name = VALUES(name)',
                [$schoolId, $acc[0], $acc[1], $acc[2], $acc[3], $acc[4], $acc[4]]
            );
        }

        // Seed default late fee rule
        Database::execute(
            'INSERT IGNORE INTO fee_late_rules (school_id, grace_period_days, rule_type, amount, max_late_fee, is_active, created_at)
             VALUES (?, 7, "fixed", 50.00, 500.00, 1, NOW())',
            [$schoolId]
        );
    }

    /**
     * Get account by code under tenant isolation.
     */
    public function getAccountByCode(int $schoolId, string $code): ?array
    {
        $acc = Database::fetch(
            'SELECT * FROM chart_of_accounts WHERE school_id = ? AND code = ? LIMIT 1',
            [$schoolId, $code]
        );
        return $acc ?: null;
    }

    /**
     * Get all accounts for a school.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getChartOfAccounts(int $schoolId): array
    {
        $this->seedDefaultChartOfAccounts($schoolId);
        return Database::fetchAll(
            'SELECT * FROM chart_of_accounts WHERE school_id = ? AND status = 1 ORDER BY code ASC',
            [$schoolId]
        );
    }

    /**
     * Generate next sequential Journal Entry number (JE-YYYY-XXXX).
     */
    public function nextJournalEntryNo(int $schoolId): string
    {
        $year = date('Y');
        $row = Database::fetch(
            'SELECT entry_no FROM journal_entries 
             WHERE school_id = ? AND entry_no LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$schoolId, "JE-{$year}-%"]
        );

        $seq = 1;
        if ($row && preg_match('/(\d+)$/', (string) $row['entry_no'], $m)) {
            $seq = ((int) $m[1]) + 1;
        }

        return sprintf('JE-%s-%04d', $year, $seq);
    }

    /**
     * Record a Double-Entry Journal Entry with strict mathematical validation:
     * sum(debits) === sum(credits).
     *
     * @param int $schoolId
     * @param array<string, mixed> $entry
     * @param array<int, array<string, mixed>> $items
     * @return int Created Journal Entry ID
     */
    public function recordJournalEntry(int $schoolId, array $entry, array $items): int
    {
        if ($schoolId <= 0) {
            throw new InvalidArgumentException('Invalid tenant context for journal entry.');
        }

        if (count($items) < 2) {
            throw new InvalidArgumentException('A double-entry journal entry must have at least two line items (debit and credit).');
        }

        return Database::transaction(function () use ($schoolId, $entry, $items): int {
            $totalDebit = 0.0;
            $totalCredit = 0.0;

            foreach ($items as $item) {
                $d = round((float) ($item['debit'] ?? 0), 2);
                $c = round((float) ($item['credit'] ?? 0), 2);

                if ($d < 0 || $c < 0) {
                    throw new InvalidArgumentException('Journal line amounts cannot be negative.');
                }
                if ($d > 0 && $c > 0) {
                    throw new InvalidArgumentException('A single journal item line cannot contain both debit and credit amounts.');
                }

                $totalDebit += $d;
                $totalCredit += $c;
            }

            // Mathematical Balance Invariant Check (within 1 cent rounding guard)
            if (abs($totalDebit - $totalCredit) > 0.01) {
                throw new RuntimeException(sprintf(
                    'Double-entry balance check failed! Total Debits ($%.2f) do not equal Total Credits ($%.2f). Discrepancy: $%.2f',
                    $totalDebit,
                    $totalCredit,
                    abs($totalDebit - $totalCredit)
                ));
            }

            $entryNo = !empty($entry['entry_no']) ? (string) $entry['entry_no'] : $this->nextJournalEntryNo($schoolId);
            $entryDate = !empty($entry['entry_date']) ? (string) $entry['entry_date'] : date('Y-m-d');
            $refType = (string) ($entry['reference_type'] ?? 'manual');
            $refId = !empty($entry['reference_id']) ? (int) $entry['reference_id'] : null;
            $desc = trim((string) ($entry['description'] ?? 'General Journal Entry'));
            $userId = Auth::id() ?: ($entry['created_by'] ?? null);

            $journalId = (int) Database::insert(
                'INSERT INTO journal_entries 
                 (school_id, entry_no, entry_date, reference_type, reference_id, description, total_debit, total_credit, status, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, "posted", ?, NOW())',
                [$schoolId, $entryNo, $entryDate, $refType, $refId, $desc, $totalDebit, $totalCredit, $userId]
            );

            // Insert line items and adjust current account balances
            foreach ($items as $item) {
                $accountId = (int) $item['account_id'];
                $debit = round((float) ($item['debit'] ?? 0), 2);
                $credit = round((float) ($item['credit'] ?? 0), 2);
                $narration = trim((string) ($item['narration'] ?? $desc));

                // Verify account belongs to tenant
                $acc = Database::fetch(
                    'SELECT id, type, current_balance FROM chart_of_accounts WHERE id = ? AND school_id = ?',
                    [$accountId, $schoolId]
                );
                if (!$acc) {
                    throw new RuntimeException("Account #{$accountId} not found in Chart of Accounts for this institution.");
                }

                Database::insert(
                    'INSERT INTO journal_entry_items 
                     (school_id, journal_entry_id, account_id, debit, credit, narration, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, NOW())',
                    [$schoolId, $journalId, $accountId, $debit, $credit, $narration]
                );

                // Update account running balance:
                // Normal debit balance (Assets, Expenses): +debit -credit
                // Normal credit balance (Liabilities, Equity, Revenue): +credit -debit
                $type = $acc['type'];
                if ($type === 'asset' || $type === 'expense') {
                    $delta = $debit - $credit;
                } else {
                    $delta = $credit - $debit;
                }

                Database::execute(
                    'UPDATE chart_of_accounts SET current_balance = current_balance + ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                    [$delta, $accountId, $schoolId]
                );
            }

            auditLog('accounting.journal_entry', 'finance', 'journal_entries', $journalId, null, [
                'entry_no' => $entryNo,
                'total' => $totalDebit,
                'ref_type' => $refType,
                'ref_id' => $refId,
            ]);

            return $journalId;
        });
    }

    /**
     * Automated Double-Entry Hook: Post journal entry for student fee invoice creation.
     * DR: Accounts Receivable (1050)
     * DR: Concessions / Scholarships (5070) [if discount applied]
     * CR: Tuition Fee Revenue (4010) [for subtotal]
     */
    public function postInvoiceJournalEntry(int $schoolId, int $invoiceId): ?int
    {
        $this->seedDefaultChartOfAccounts($schoolId);

        $inv = Database::fetch(
            'SELECT * FROM student_fee_invoices WHERE id = ? AND school_id = ?',
            [$invoiceId, $schoolId]
        );
        if (!$inv) {
            return null;
        }

        // Avoid duplicate journal posting for this invoice
        $existing = Database::fetch(
            'SELECT id FROM journal_entries WHERE school_id = ? AND reference_type = "invoice" AND reference_id = ? LIMIT 1',
            [$schoolId, $invoiceId]
        );
        if ($existing) {
            return (int) $existing['id'];
        }

        $arAccount = $this->getAccountByCode($schoolId, '1050'); // Accounts Receivable
        $revenueAccount = $this->getAccountByCode($schoolId, '4010'); // Tuition Revenue
        $concessionAccount = $this->getAccountByCode($schoolId, '5070'); // Scholarships/Discounts

        if (!$arAccount || !$revenueAccount || !$concessionAccount) {
            return null;
        }

        $subtotal = (float) $inv['subtotal'];
        $discount = (float) $inv['discount'];
        $lateFee = (float) $inv['late_fee'];
        $total = (float) $inv['total_amount'];

        $items = [];
        // 1. DR: Accounts Receivable for the net payable invoice total
        $items[] = [
            'account_id' => $arAccount['id'],
            'debit' => $total,
            'credit' => 0.00,
            'narration' => "Tuition Receivable for Invoice #{$inv['invoice_no']}",
        ];

        // 2. DR: Concessions / Discounts expense if student received a discount
        if ($discount > 0.00) {
            $items[] = [
                'account_id' => $concessionAccount['id'],
                'debit' => $discount,
                'credit' => 0.00,
                'narration' => "Fee discount awarded on Invoice #{$inv['invoice_no']}",
            ];
        }

        // 3. CR: Revenue for Subtotal + Late Fee
        $totalRevenue = $subtotal + $lateFee;
        $items[] = [
            'account_id' => $revenueAccount['id'],
            'debit' => 0.00,
            'credit' => $totalRevenue,
            'narration' => "Tuition fee revenue recognized on Invoice #{$inv['invoice_no']}",
        ];

        return $this->recordJournalEntry($schoolId, [
            'entry_date' => $inv['invoice_date'],
            'reference_type' => 'invoice',
            'reference_id' => $invoiceId,
            'description' => "Recognize tuition fees for Invoice #{$inv['invoice_no']}",
        ], $items);
    }

    /**
     * Automated Double-Entry Hook: Post journal entry for fee payment collection.
     * DR: Cash in Hand (1010) or Main Bank Account (1020)
     * CR: Accounts Receivable (1050)
     */
    public function postPaymentJournalEntry(int $schoolId, int $paymentId): ?int
    {
        $this->seedDefaultChartOfAccounts($schoolId);

        $pmt = Database::fetch(
            'SELECT p.*, i.invoice_no FROM payments p 
             LEFT JOIN student_fee_invoices i ON i.id = p.invoice_id
             WHERE p.id = ? AND p.school_id = ?',
            [$paymentId, $schoolId]
        );
        if (!$pmt) {
            return null;
        }

        $existing = Database::fetch(
            'SELECT id FROM journal_entries WHERE school_id = ? AND reference_type = "payment" AND reference_id = ? LIMIT 1',
            [$schoolId, $paymentId]
        );
        if ($existing) {
            return (int) $existing['id'];
        }

        $targetCashCode = in_array($pmt['payment_method'], ['bank', 'card', 'online'], true) ? '1020' : '1010';
        $cashAccount = $this->getAccountByCode($schoolId, $targetCashCode);
        $arAccount = $this->getAccountByCode($schoolId, '1050');

        if (!$cashAccount || !$arAccount) {
            return null;
        }

        $amount = (float) $pmt['amount'];
        $receiptNo = $pmt['receipt_no'] ?? 'RCP-' . $paymentId;
        $invNo = $pmt['invoice_no'] ?? 'N/A';

        $items = [
            [
                'account_id' => $cashAccount['id'],
                'debit' => $amount,
                'credit' => 0.00,
                'narration' => "Payment collected via {$pmt['payment_method']} (Receipt: {$receiptNo}) for Inv #{$invNo}",
            ],
            [
                'account_id' => $arAccount['id'],
                'debit' => 0.00,
                'credit' => $amount,
                'narration' => "Settle student receivable for Inv #{$invNo}",
            ],
        ];

        return $this->recordJournalEntry($schoolId, [
            'entry_date' => $pmt['payment_date'] ?? date('Y-m-d'),
            'reference_type' => 'payment',
            'reference_id' => $paymentId,
            'description' => "Fee collection receipt #{$receiptNo}",
        ], $items);
    }

    /**
     * Automated Double-Entry Hook: Post journal entry for refund disbursement.
     * DR: Tuition Fee Revenue / Refund Clearing (4010)
     * CR: Cash in Hand (1010) or Main Bank Account (1020)
     */
    public function postRefundJournalEntry(int $schoolId, int $refundId): ?int
    {
        $this->seedDefaultChartOfAccounts($schoolId);

        $ref = Database::fetch(
            'SELECT * FROM refund_transactions WHERE id = ? AND school_id = ?',
            [$refundId, $schoolId]
        );
        if (!$ref) {
            return null;
        }

        $existing = Database::fetch(
            'SELECT id FROM journal_entries WHERE school_id = ? AND reference_type = "refund" AND reference_id = ? LIMIT 1',
            [$schoolId, $refundId]
        );
        if ($existing) {
            return (int) $existing['id'];
        }

        $targetCashCode = in_array($ref['refund_method'], ['bank', 'online'], true) ? '1020' : '1010';
        $cashAccount = $this->getAccountByCode($schoolId, $targetCashCode);
        $revenueAccount = $this->getAccountByCode($schoolId, '4010');

        if (!$cashAccount || !$revenueAccount) {
            return null;
        }

        $amount = (float) $ref['amount'];
        $refundNo = $ref['refund_no'] ?? 'RFD-' . $refundId;

        $items = [
            [
                'account_id' => $revenueAccount['id'],
                'debit' => $amount,
                'credit' => 0.00,
                'narration' => "Fee revenue reversed due to refund #{$refundNo}: {$ref['reason']}",
            ],
            [
                'account_id' => $cashAccount['id'],
                'debit' => 0.00,
                'credit' => $amount,
                'narration' => "Cash/Bank disbursed for refund #{$refundNo}",
            ],
        ];

        return $this->recordJournalEntry($schoolId, [
            'entry_date' => date('Y-m-d', strtotime((string) $ref['created_at'])),
            'reference_type' => 'refund',
            'reference_id' => $refundId,
            'description' => "Student fee refund voucher #{$refundNo}",
        ], $items);
    }

    /**
     * Automated Double-Entry Hook: Post journal entry for operating expense.
     * DR: Specific Expense Account (5010..5080)
     * CR: Cash (1010) or Bank (1020)
     */
    public function postExpenseJournalEntry(int $schoolId, int $expenseId): ?int
    {
        $this->seedDefaultChartOfAccounts($schoolId);

        $exp = Database::fetch(
            'SELECT * FROM expenses WHERE id = ? AND school_id = ?',
            [$expenseId, $schoolId]
        );
        if (!$exp) {
            return null;
        }

        $existing = Database::fetch(
            'SELECT id FROM journal_entries WHERE school_id = ? AND reference_type = "expense" AND reference_id = ? LIMIT 1',
            [$schoolId, $expenseId]
        );
        if ($existing) {
            return (int) $existing['id'];
        }

        // Map category keyword to chart of accounts
        $cat = strtolower((string) ($exp['category'] ?? ''));
        $expenseCode = '5050'; // Default admin expense
        if (str_contains($cat, 'salary') || str_contains($cat, 'payroll') || str_contains($cat, 'wage')) {
            $expenseCode = '5010';
        } elseif (str_contains($cat, 'rent') || str_contains($cat, 'lease') || str_contains($cat, 'building')) {
            $expenseCode = '5020';
        } elseif (str_contains($cat, 'utility') || str_contains($cat, 'electric') || str_contains($cat, 'power') || str_contains($cat, 'internet')) {
            $expenseCode = '5030';
        } elseif (str_contains($cat, 'book') || str_contains($cat, 'stationery') || str_contains($cat, 'supply')) {
            $expenseCode = '5040';
        } elseif (str_contains($cat, 'transport') || str_contains($cat, 'fuel') || str_contains($cat, 'diesel') || str_contains($cat, 'vehicle')) {
            $expenseCode = '5060';
        }

        $expenseAccount = $this->getAccountByCode($schoolId, $expenseCode);
        $targetCashCode = in_array(strtolower((string) ($exp['payment_method'] ?? '')), ['bank', 'cheque', 'transfer', 'online'], true) ? '1020' : '1010';
        $cashAccount = $this->getAccountByCode($schoolId, $targetCashCode);

        if (!$expenseAccount || !$cashAccount) {
            return null;
        }

        $amount = (float) $exp['amount'];
        $title = $exp['title'] ?? 'Operational Expenditure';

        $items = [
            [
                'account_id' => $expenseAccount['id'],
                'debit' => $amount,
                'credit' => 0.00,
                'narration' => "Expense: {$title} ({$exp['category']})",
            ],
            [
                'account_id' => $cashAccount['id'],
                'debit' => 0.00,
                'credit' => $amount,
                'narration' => "Settled via {$exp['payment_method']} Ref: {$exp['reference_no']}",
            ],
        ];

        return $this->recordJournalEntry($schoolId, [
            'entry_date' => $exp['expense_date'] ?? date('Y-m-d'),
            'reference_type' => 'expense',
            'reference_id' => $expenseId,
            'description' => "Expense voucher: {$title}",
        ], $items);
    }

    /**
     * Compute Trial Balance: Sum of all account debits and credits across the ledger.
     * Proves accounting balance integrity: Total Debits === Total Credits.
     *
     * @param int $schoolId
     * @param string|null $asOfDate Format 'YYYY-MM-DD'
     * @return array{accounts: array, total_debit: float, total_credit: float, is_balanced: bool, discrepancy: float}
     */
    public function getTrialBalance(int $schoolId, ?string $asOfDate = null): array
    {
        $this->seedDefaultChartOfAccounts($schoolId);
        $dateLimit = $asOfDate ?: date('Y-m-d');

        $sql = 'SELECT a.id, a.code, a.name, a.type, a.opening_balance,
                       COALESCE(SUM(i.debit), 0) AS period_debit,
                       COALESCE(SUM(i.credit), 0) AS period_credit
                FROM chart_of_accounts a
                LEFT JOIN journal_entry_items i ON i.account_id = a.id AND i.school_id = a.school_id
                LEFT JOIN journal_entries j ON j.id = i.journal_entry_id AND j.entry_date <= ? AND j.status = "posted"
                WHERE a.school_id = ? AND a.status = 1
                GROUP BY a.id
                ORDER BY a.code ASC';

        $rows = Database::fetchAll($sql, [$dateLimit, $schoolId]);

        $accounts = [];
        $totalDebit = 0.0;
        $totalCredit = 0.0;

        foreach ($rows as $r) {
            $type = $r['type'];
            $pDebit = (float) $r['period_debit'];
            $pCredit = (float) $r['period_credit'];
            $opening = (float) $r['opening_balance'];

            $debitBalance = 0.0;
            $creditBalance = 0.0;

            if ($type === 'asset' || $type === 'expense') {
                $net = $opening + ($pDebit - $pCredit);
                if ($net >= 0) {
                    $debitBalance = $net;
                } else {
                    $creditBalance = abs($net);
                }
            } else {
                $net = $opening + ($pCredit - $pDebit);
                if ($net >= 0) {
                    $creditBalance = $net;
                } else {
                    $debitBalance = abs($net);
                }
            }

            $accounts[] = [
                'id' => (int) $r['id'],
                'code' => $r['code'],
                'name' => $r['name'],
                'type' => $r['type'],
                'debit_balance' => round($debitBalance, 2),
                'credit_balance' => round($creditBalance, 2),
            ];

            $totalDebit += $debitBalance;
            $totalCredit += $creditBalance;
        }

        $totalDebit = round($totalDebit, 2);
        $totalCredit = round($totalCredit, 2);
        $discrepancy = round(abs($totalDebit - $totalCredit), 2);
        $isBalanced = ($discrepancy <= 0.01);

        return [
            'as_of_date' => $dateLimit,
            'accounts' => $accounts,
            'total_debit' => $totalDebit,
            'total_credit' => $totalCredit,
            'is_balanced' => $isBalanced,
            'discrepancy' => $discrepancy,
        ];
    }

    /**
     * Compute Balance Sheet:
     * Assets = Liabilities + Equity (including net operating surplus).
     *
     * @param int $schoolId
     * @param string|null $asOfDate
     * @return array{assets: array, total_assets: float, liabilities: array, total_liabilities: float, equity: array, total_equity: float, net_surplus: float, is_balanced: bool}
     */
    public function getBalanceSheet(int $schoolId, ?string $asOfDate = null): array
    {
        $tb = $this->getTrialBalance($schoolId, $asOfDate);
        $accounts = $tb['accounts'];

        $assets = [];
        $liabilities = [];
        $equity = [];
        $totalAssets = 0.0;
        $totalLiabilities = 0.0;
        $totalEquity = 0.0;

        $totalRevenue = 0.0;
        $totalExpense = 0.0;

        foreach ($accounts as $a) {
            if ($a['type'] === 'asset') {
                $bal = $a['debit_balance'] - $a['credit_balance'];
                $assets[] = array_merge($a, ['balance' => $bal]);
                $totalAssets += $bal;
            } elseif ($a['type'] === 'liability') {
                $bal = $a['credit_balance'] - $a['debit_balance'];
                $liabilities[] = array_merge($a, ['balance' => $bal]);
                $totalLiabilities += $bal;
            } elseif ($a['type'] === 'equity') {
                $bal = $a['credit_balance'] - $a['debit_balance'];
                $equity[] = array_merge($a, ['balance' => $bal]);
                $totalEquity += $bal;
            } elseif ($a['type'] === 'revenue') {
                $totalRevenue += ($a['credit_balance'] - $a['debit_balance']);
            } elseif ($a['type'] === 'expense') {
                $totalExpense += ($a['debit_balance'] - $a['credit_balance']);
            }
        }

        // Net Operating Surplus / Deficit from period operations
        $netSurplus = round($totalRevenue - $totalExpense, 2);

        // Add Net Surplus to Equity section
        $equity[] = [
            'id' => 0,
            'code' => 'SURPLUS',
            'name' => 'Current Period Net Operating Surplus / (Deficit)',
            'type' => 'equity',
            'debit_balance' => 0.00,
            'credit_balance' => $netSurplus,
            'balance' => $netSurplus,
        ];
        $totalEquityWithSurplus = round($totalEquity + $netSurplus, 2);

        $totalAssets = round($totalAssets, 2);
        $totalLiabilities = round($totalLiabilities, 2);
        $totalClaims = round($totalLiabilities + $totalEquityWithSurplus, 2);
        $isBalanced = (abs($totalAssets - $totalClaims) <= 0.02);

        return [
            'as_of_date' => $tb['as_of_date'],
            'assets' => $assets,
            'total_assets' => $totalAssets,
            'liabilities' => $liabilities,
            'total_liabilities' => $totalLiabilities,
            'equity' => $equity,
            'total_equity' => $totalEquityWithSurplus,
            'net_surplus' => $netSurplus,
            'total_claims' => $totalClaims,
            'is_balanced' => $isBalanced,
        ];
    }

    /**
     * General Ledger for a specific account with running balance.
     *
     * @param int $schoolId
     * @param int $accountId
     * @param string|null $from
     * @param string|null $to
     * @return array{account: array, lines: array, opening_balance: float, closing_balance: float}
     */
    public function getGeneralLedger(int $schoolId, int $accountId, ?string $from = null, ?string $to = null): array
    {
        $account = Database::fetch(
            'SELECT * FROM chart_of_accounts WHERE id = ? AND school_id = ?',
            [$accountId, $schoolId]
        );
        if (!$account) {
            throw new RuntimeException('Account not found in Chart of Accounts.');
        }

        $from = $from ?: date('Y-m-01');
        $to = $to ?: date('Y-m-d');

        // Opening balance calculation prior to $from date
        $prior = Database::fetch(
            'SELECT COALESCE(SUM(i.debit), 0) AS prior_debit, COALESCE(SUM(i.credit), 0) AS prior_credit
             FROM journal_entry_items i
             JOIN journal_entries j ON j.id = i.journal_entry_id
             WHERE i.account_id = ? AND i.school_id = ? AND j.entry_date < ? AND j.status = "posted"',
            [$accountId, $schoolId, $from]
        );

        $type = $account['type'];
        $baseOpening = (float) $account['opening_balance'];
        if ($type === 'asset' || $type === 'expense') {
            $openingBalance = $baseOpening + ((float)$prior['prior_debit'] - (float)$prior['prior_credit']);
        } else {
            $openingBalance = $baseOpening + ((float)$prior['prior_credit'] - (float)$prior['prior_debit']);
        }

        // Transactions in period
        $lines = Database::fetchAll(
            'SELECT i.*, j.entry_no, j.entry_date, j.reference_type, j.reference_id, j.description AS entry_description
             FROM journal_entry_items i
             JOIN journal_entries j ON j.id = i.journal_entry_id
             WHERE i.account_id = ? AND i.school_id = ? AND j.entry_date BETWEEN ? AND ? AND j.status = "posted"
             ORDER BY j.entry_date ASC, i.id ASC',
            [$accountId, $schoolId, $from, $to]
        );

        $running = $openingBalance;
        foreach ($lines as &$line) {
            $d = (float) $line['debit'];
            $c = (float) $line['credit'];
            if ($type === 'asset' || $type === 'expense') {
                $running += ($d - $c);
            } else {
                $running += ($c - $d);
            }
            $line['running_balance'] = round($running, 2);
        }
        unset($line);

        return [
            'account' => $account,
            'from' => $from,
            'to' => $to,
            'opening_balance' => round($openingBalance, 2),
            'closing_balance' => round($running, 2),
            'lines' => $lines,
        ];
    }

    /**
     * Create a Class-wise Fee Structure row.
     */
    public function createFeeStructure(int $schoolId, array $data): int
    {
        $classId = (int) ($data['class_id'] ?? 0);
        $catId = (int) ($data['fee_category_id'] ?? 0);
        $amount = max(0.0, (float) ($data['amount'] ?? 0));
        $title = trim((string) ($data['title'] ?? 'Tuition Fee'));
        $installmentNo = max(1, (int) ($data['installment_no'] ?? 1));
        $dueMonth = !empty($data['due_month']) ? (int) $data['due_month'] : null;
        $ayId = (int) ($data['academic_year_id'] ?? (activeAcademicYearId() ?: 0));

        TenantGuard::enforce('classes', $classId, $schoolId);
        TenantGuard::enforce('fee_categories', $catId, $schoolId);

        return (int) Database::insert(
            'INSERT INTO fee_structures 
             (school_id, academic_year_id, class_id, fee_category_id, title, amount, installment_no, due_month, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())',
            [$schoolId, $ayId, $classId, $catId, $title, $amount, $installmentNo, $dueMonth]
        );
    }

    /**
     * List fee structures for a school.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getFeeStructures(int $schoolId, ?int $classId = null): array
    {
        $sql = 'SELECT fs.*, c.name AS class_name, fc.name AS category_name, fc.code AS category_code
                FROM fee_structures fs
                JOIN classes c ON c.id = fs.class_id
                JOIN fee_categories fc ON fc.id = fs.fee_category_id
                WHERE fs.school_id = ?';
        $params = [$schoolId];

        if ($classId !== null) {
            $sql .= ' AND fs.class_id = ?';
            $params[] = $classId;
        }

        $sql .= ' ORDER BY c.name ASC, fs.installment_no ASC';
        return Database::fetchAll($sql, $params);
    }

    /**
     * Record a student-specific fee adjustment (Concession, Sibling Waiver, Special Scholarship).
     */
    public function recordStudentAdjustment(int $schoolId, array $data): int
    {
        $studentId = (int) ($data['student_id'] ?? 0);
        TenantGuard::enforce('students', $studentId, $schoolId);

        $adjType = in_array($data['adjustment_type'] ?? '', ['concession', 'scholarship', 'waiver', 'special_discount', 'custom_charge'], true)
            ? $data['adjustment_type'] : 'concession';
        $calcType = in_array($data['calculation_type'] ?? '', ['fixed', 'percentage'], true) ? $data['calculation_type'] : 'fixed';
        $val = max(0.0, (float) ($data['value'] ?? 0));
        $reason = trim((string) ($data['reason'] ?? 'Approved fee concession'));
        $catId = !empty($data['fee_category_id']) ? (int) $data['fee_category_id'] : null;
        $ayId = (int) ($data['academic_year_id'] ?? (activeAcademicYearId() ?: 0));

        return (int) Database::insert(
            'INSERT INTO student_fee_adjustments
             (school_id, student_id, academic_year_id, fee_category_id, adjustment_type, calculation_type, value, reason, approved_by, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "approved", NOW())',
            [$schoolId, $studentId, $ayId, $catId, $adjType, $calcType, $val, $reason, Auth::id()]
        );
    }

    /**
     * Calculate comprehensive dynamic fee estimate for a student factoring in:
     * - Base Class fee structures
     * - Transport Route fares
     * - Active scholarships and concessions
     *
     * @return array{items: array, subtotal: float, discount: float, transport: float, net_total: float}
     */
    public function calculateStudentFeeEstimate(int $schoolId, int $studentId): array
    {
        TenantGuard::enforce('students', $studentId, $schoolId);

        $student = Database::fetch(
            'SELECT s.*, c.name AS class_name, tr.fare AS transport_fare, tr.title AS route_title
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN transport_routes tr ON tr.id = s.transport_route_id AND tr.school_id = s.school_id
             WHERE s.id = ? AND s.school_id = ?',
            [$studentId, $schoolId]
        );

        if (!$student) {
            throw new RuntimeException('Student record not found.');
        }

        $classId = (int) $student['class_id'];
        $feeStructures = Database::fetchAll(
            'SELECT fs.*, fc.name AS category_name FROM fee_structures fs
             JOIN fee_categories fc ON fc.id = fs.fee_category_id
             WHERE fs.school_id = ? AND fs.class_id = ? AND fs.status = 1',
            [$schoolId, $classId]
        );

        // Fallback to active fee_categories if no specific class structure configured
        if (empty($feeStructures)) {
            $catRows = Database::fetchAll(
                'SELECT id AS fee_category_id, name AS category_name, name AS title, amount 
                 FROM fee_categories WHERE school_id = ? AND status = 1 AND frequency IN ("monthly", "term")',
                [$schoolId]
            );
            $feeStructures = $catRows;
        }

        $items = [];
        $subtotal = 0.0;
        foreach ($feeStructures as $fs) {
            $amt = (float) $fs['amount'];
            $subtotal += $amt;
            $items[] = [
                'fee_category_id' => $fs['fee_category_id'],
                'description' => $fs['title'] ?? $fs['category_name'],
                'amount' => $amt,
            ];
        }

        // Add Transport if enrolled
        $transportFare = (float) ($student['transport_fare'] ?? 0);
        if ($transportFare > 0.0) {
            $items[] = [
                'fee_category_id' => null,
                'description' => 'Transport Commute: ' . ($student['route_title'] ?? 'Standard Route'),
                'amount' => $transportFare,
            ];
            $subtotal += $transportFare;
        }

        // Calculate student adjustments & scholarships
        $totalDiscount = 0.0;
        $adjustments = Database::fetchAll(
            'SELECT * FROM student_fee_adjustments WHERE school_id = ? AND student_id = ? AND status = "approved"',
            [$schoolId, $studentId]
        );
        foreach ($adjustments as $adj) {
            $val = (float) $adj['value'];
            if ($adj['calculation_type'] === 'percentage') {
                $disc = round(($subtotal * $val) / 100.0, 2);
            } else {
                $disc = $val;
            }
            $totalDiscount += $disc;
        }

        // Check scholarships catalog
        $scholarships = Database::fetchAll(
            'SELECT sc.*, d.amount, d.type FROM student_scholarships sc
             JOIN fee_discounts d ON d.id = sc.discount_id
             WHERE sc.school_id = ? AND sc.student_id = ? AND sc.status = "active"',
            [$schoolId, $studentId]
        );
        foreach ($scholarships as $sch) {
            $val = (float) $sch['amount'];
            if ($sch['type'] === 'percentage') {
                $disc = round(($subtotal * $val) / 100.0, 2);
            } else {
                $disc = $val;
            }
            $totalDiscount += $disc;
        }

        $totalDiscount = min($totalDiscount, $subtotal);
        $netTotal = round(max(0.0, $subtotal - $totalDiscount), 2);

        return [
            'student_id' => $studentId,
            'student_name' => trim("{$student['first_name']} {$student['last_name']}"),
            'admission_no' => $student['admission_no'],
            'class_name' => $student['class_name'] ?? 'Unassigned',
            'items' => $items,
            'subtotal' => round($subtotal, 2),
            'discount' => round($totalDiscount, 2),
            'transport' => round($transportFare, 2),
            'net_total' => $netTotal,
        ];
    }

    /**
     * Dynamic Late Fee Calculation & Application Engine.
     * Evaluates overdue invoices past grace period and applies late fee based on tenant policy.
     *
     * @return array{processed_count: int, total_late_fees_applied: float, invoice_ids: array}
     */
    public function applyDynamicLateFees(int $schoolId): array
    {
        $rule = Database::fetch(
            'SELECT * FROM fee_late_rules WHERE school_id = ? AND is_active = 1 LIMIT 1',
            [$schoolId]
        );

        $graceDays = (int) ($rule['grace_period_days'] ?? 7);
        $ruleType = $rule['rule_type'] ?? 'fixed';
        $baseAmount = (float) ($rule['amount'] ?? 50.00);
        $maxLateFee = (float) ($rule['max_late_fee'] ?? 500.00);

        // Find overdue invoices where due_date + grace_period has passed and late_fee == 0
        $overdueInvoices = Database::fetchAll(
            'SELECT id, invoice_no, total_amount, subtotal, discount, late_fee, due_date, DATEDIFF(CURDATE(), due_date) AS days_overdue
             FROM student_fee_invoices
             WHERE school_id = ? 
               AND status IN ("unpaid", "partial") 
               AND due_date < DATE_SUB(CURDATE(), INTERVAL ? DAY)
               AND late_fee = 0.00
             LIMIT 100',
            [$schoolId, $graceDays]
        );

        $appliedCount = 0;
        $totalLateFeeApplied = 0.0;
        $appliedIds = [];

        foreach ($overdueInvoices as $inv) {
            $daysOverdue = max(1, (int) $inv['days_overdue'] - $graceDays);
            $calculatedLateFee = 0.0;

            if ($ruleType === 'fixed') {
                $calculatedLateFee = $baseAmount;
            } elseif ($ruleType === 'daily_rate') {
                $calculatedLateFee = min($maxLateFee, $baseAmount * $daysOverdue);
            } elseif ($ruleType === 'percentage') {
                $calculatedLateFee = min($maxLateFee, round(((float)$inv['subtotal'] * $baseAmount) / 100.0, 2));
            }

            if ($calculatedLateFee <= 0.0) {
                continue;
            }

            $invId = (int) $inv['id'];
            $newTotal = round((float)$inv['total_amount'] + $calculatedLateFee, 2);

            Database::execute(
                'UPDATE student_fee_invoices 
                 SET late_fee = ?, total_amount = ?, updated_at = NOW() 
                 WHERE id = ? AND school_id = ?',
                [$calculatedLateFee, $newTotal, $invId, $schoolId]
            );

            // Add line item to invoice
            Database::insert(
                'INSERT INTO student_fee_invoice_items (school_id, invoice_id, fee_category_id, description, amount, created_at)
                 VALUES (?, ?, NULL, ?, ?, NOW())',
                [$schoolId, $invId, "Late Payment Surcharge ({$daysOverdue} days past grace)", $calculatedLateFee]
            );

            $appliedCount++;
            $totalLateFeeApplied += $calculatedLateFee;
            $appliedIds[] = $invId;
        }

        return [
            'processed_count' => $appliedCount,
            'total_late_fees_applied' => round($totalLateFeeApplied, 2),
            'invoice_ids' => $appliedIds,
        ];
    }

    /**
     * Dispatch Fee Due & Overdue Reminders with Duplicate Prevention & Delivery History.
     * Prevents duplicate spamming: Will not dispatch if reminder sent within `min_interval_days`.
     *
     * @return array{dispatched: int, skipped_duplicates: int, failed: int}
     */
    public function dispatchAutomatedReminders(int $schoolId, bool $force = false): array
    {
        $settings = Database::fetchAll(
            'SELECT * FROM fee_reminder_settings WHERE school_id = ? AND is_active = 1',
            [$schoolId]
        );

        $minInterval = 5; // Default minimum 5 days between reminders
        foreach ($settings as $st) {
            if (!empty($st['min_interval_days'])) {
                $minInterval = (int) $st['min_interval_days'];
            }
        }

        // Find unpaid or partially paid invoices with balance > 0
        $invoices = Database::fetchAll(
            'SELECT i.id, i.invoice_no, i.student_id, i.total_amount, i.paid_amount, i.due_date,
                    s.first_name, s.last_name, s.phone AS student_phone
             FROM student_fee_invoices i
             JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
             WHERE i.school_id = ? AND i.status IN ("unpaid", "partial") AND (i.total_amount - i.paid_amount) > 0.05
             ORDER BY i.due_date ASC LIMIT 200',
            [$schoolId]
        );

        $dispatched = 0;
        $skipped = 0;
        $failed = 0;

        foreach ($invoices as $inv) {
            $invId = (int) $inv['id'];
            $studentId = (int) $inv['student_id'];
            $balance = (float)$inv['total_amount'] - (float)$inv['paid_amount'];

            // Duplicate prevention check: Was a reminder logged in last X days?
            if (!$force) {
                $recentLog = Database::fetch(
                    'SELECT id FROM fee_reminder_logs 
                     WHERE school_id = ? AND invoice_id = ? AND sent_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                     LIMIT 1',
                    [$schoolId, $invId, $minInterval]
                );
                if ($recentLog) {
                    $skipped++;
                    continue;
                }
            }

            // Find parent user
            $parent = Database::fetch(
                'SELECT p.id AS parent_id, p.phone, p.first_name, p.last_name, u.id AS user_id
                 FROM student_parents sp
                 JOIN parents p ON p.id = sp.parent_id AND p.school_id = sp.school_id
                 LEFT JOIN users u ON u.parent_id = p.id AND u.school_id = p.school_id
                 WHERE sp.student_id = ? AND sp.school_id = ? LIMIT 1',
                [$studentId, $schoolId]
            );

            $contact = !empty($parent['phone']) ? $parent['phone'] : ($inv['student_phone'] ?? 'Portal Account');
            $parentId = !empty($parent['parent_id']) ? (int) $parent['parent_id'] : null;
            $studentName = trim("{$inv['first_name']} {$inv['last_name']}");

            try {
                // Log in-app notification if parent user exists
                if (!empty($parent['user_id'])) {
                    Database::insert(
                        'INSERT INTO notifications (school_id, user_id, type, title, message, url, is_read, created_at)
                         VALUES (?, ?, "fee.reminder", "Fee Due Reminder", ?, "/portal/finance", 0, NOW())',
                        [
                            $schoolId,
                            (int) $parent['user_id'],
                            "Reminder: Outstanding tuition balance of " . formatMoney($balance) . " for {$studentName} (Invoice #{$inv['invoice_no']}) is due on {$inv['due_date']}.",
                        ]
                    );
                }

                // Record delivery log
                Database::insert(
                    'INSERT INTO fee_reminder_logs 
                     (school_id, invoice_id, student_id, parent_id, channel, recipient_contact, amount_due, due_date, status, sent_at)
                     VALUES (?, ?, ?, ?, "in_app", ?, ?, ?, "sent", NOW())',
                    [$schoolId, $invId, $studentId, $parentId, $contact, $balance, $inv['due_date']]
                );

                $dispatched++;
            } catch (Throwable $e) {
                $failed++;
            }
        }

        return [
            'dispatched' => $dispatched,
            'skipped_duplicates' => $skipped,
            'failed' => $failed,
        ];
    }

    /**
     * Create a formal Payment / Disbursement Voucher with optional document attachment.
     */
    public function createPaymentVoucher(int $schoolId, array $data): int
    {
        $amount = (float) ($data['amount'] ?? 0);
        if ($amount <= 0.0) {
            throw new InvalidArgumentException('Payment voucher amount must be greater than zero.');
        }

        $payee = trim((string) ($data['payee_name'] ?? ''));
        if (empty($payee)) {
            throw new InvalidArgumentException('Payee name is required.');
        }

        $year = date('Y');
        $row = Database::fetch(
            'SELECT voucher_no FROM payment_vouchers 
             WHERE school_id = ? AND voucher_no LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$schoolId, "VCH-{$year}-%"]
        );
        $seq = 1;
        if ($row && preg_match('/(\d+)$/', (string) $row['voucher_no'], $m)) {
            $seq = ((int) $m[1]) + 1;
        }
        $voucherNo = sprintf('VCH-%s-%04d', $year, $seq);

        $vType = in_array($data['voucher_type'] ?? '', ['expense', 'vendor_payment', 'salary_advance', 'refund', 'petty_cash', 'other'], true)
            ? $data['voucher_type'] : 'expense';
        $method = in_array($data['payment_method'] ?? '', ['cash', 'bank', 'cheque', 'online'], true) ? $data['payment_method'] : 'cash';
        $desc = trim((string) ($data['description'] ?? ''));
        $ref = trim((string) ($data['reference_no'] ?? ''));
        $docPath = $data['supporting_doc_path'] ?? null;
        $accountId = !empty($data['account_id']) ? (int) $data['account_id'] : null;

        return (int) Database::insert(
            'INSERT INTO payment_vouchers 
             (school_id, voucher_no, voucher_type, payee_name, amount, payment_method, account_id, reference_no, description, supporting_doc_path, status, approved_by, paid_at, created_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "approved", ?, NOW(), ?, NOW())',
            [$schoolId, $voucherNo, $vType, $payee, $amount, $method, $accountId, $ref, $desc, $docPath, Auth::id(), Auth::id()]
        );
    }

    /**
     * Compute real-time Budget vs Actual Expense variance.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getBudgetVarianceReport(int $schoolId, ?string $fiscalYear = null): array
    {
        $year = $fiscalYear ?: date('Y') . '-' . (date('Y') + 1);

        $budgets = Database::fetchAll(
            'SELECT b.*, c.name AS category_name, c.code AS category_code
             FROM school_budgets b
             LEFT JOIN expense_categories c ON c.id = b.category_id AND c.school_id = b.school_id
             WHERE b.school_id = ? AND b.fiscal_year = ?
             ORDER BY b.department ASC, b.allocated_amount DESC',
            [$schoolId, $year]
        );

        // Aggregate actual expenses for each category in fiscal year
        foreach ($budgets as &$b) {
            $catId = (int) ($b['category_id'] ?? 0);
            $spent = 0.0;
            if ($catId > 0) {
                $sum = Database::fetch(
                    'SELECT COALESCE(SUM(amount), 0) AS s FROM expenses 
                     WHERE school_id = ? AND (category_id = ? OR category = ?)',
                    [$schoolId, $catId, $b['category_name']]
                );
                $spent = (float) ($sum['s'] ?? 0);
            }

            $allocated = (float) $b['allocated_amount'];
            $variance = $allocated - $spent;
            $percentUsed = $allocated > 0 ? round(($spent / $allocated) * 100, 1) : 0.0;

            $b['actual_spent'] = $spent;
            $b['variance'] = $variance;
            $b['percent_used'] = $percentUsed;
            $b['is_over_budget'] = ($spent > $allocated);
        }
        unset($b);

        return $budgets;
    }
}
