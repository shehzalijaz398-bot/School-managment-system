<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Employee;
use App\Models\User;
use Core\Auth;
use Core\Database;

final class HrService
{
    /**
     * Ensure all advanced enterprise HR tables and indexes exist.
     */
    public function ensureAdvancedHrSchema(): void
    {
        // 1. Staff Shifts
        Database::execute("
            CREATE TABLE IF NOT EXISTS staff_shifts (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                name VARCHAR(100) NOT NULL,
                code VARCHAR(50) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                late_grace_minutes INT UNSIGNED NOT NULL DEFAULT 15,
                half_day_threshold_minutes INT UNSIGNED NOT NULL DEFAULT 240,
                is_default TINYINT(1) NOT NULL DEFAULT 0,
                status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_shift_school (school_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 2. School Institutional & Holiday Calendars
        Database::execute("
            CREATE TABLE IF NOT EXISTS school_holidays (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                name VARCHAR(150) NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                type ENUM('national', 'religious', 'institutional', 'academic') NOT NULL DEFAULT 'institutional',
                is_recurring TINYINT(1) NOT NULL DEFAULT 0,
                description TEXT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_holiday_school_date (school_id, start_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 3. Staff Leave Balances & Allocation Quotas
        Database::execute("
            CREATE TABLE IF NOT EXISTS staff_leave_balances (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                employee_id BIGINT UNSIGNED NOT NULL,
                leave_type_id BIGINT UNSIGNED NOT NULL,
                year INT UNSIGNED NOT NULL,
                allocated_days DECIMAL(5,1) NOT NULL DEFAULT 0.0,
                used_days DECIMAL(5,1) NOT NULL DEFAULT 0.0,
                pending_days DECIMAL(5,1) NOT NULL DEFAULT 0.0,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                UNIQUE KEY uq_emp_leave_year (school_id, employee_id, leave_type_id, year),
                INDEX idx_leave_bal_emp (employee_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 4. Staff Performance Reviews & Competency Ratings
        Database::execute("
            CREATE TABLE IF NOT EXISTS staff_performance_reviews (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                employee_id BIGINT UNSIGNED NOT NULL,
                reviewer_id BIGINT UNSIGNED NOT NULL,
                review_period VARCHAR(100) NOT NULL,
                review_date DATE NOT NULL,
                overall_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
                pedagogy_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
                punctuality_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
                compliance_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
                teamwork_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
                strengths TEXT NULL,
                growth_areas TEXT NULL,
                goals TEXT NULL,
                status ENUM('draft', 'submitted', 'approved') NOT NULL DEFAULT 'approved',
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_perf_emp (school_id, employee_id),
                INDEX idx_perf_date (school_id, review_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 5. Staff Professional Development & Training Records
        Database::execute("
            CREATE TABLE IF NOT EXISTS staff_trainings (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                employee_id BIGINT UNSIGNED NOT NULL,
                title VARCHAR(200) NOT NULL,
                provider VARCHAR(150) NOT NULL,
                category VARCHAR(100) NOT NULL DEFAULT 'Pedagogy',
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                hours DECIMAL(5,1) NOT NULL DEFAULT 1.0,
                cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                certificate_ref VARCHAR(150) NULL,
                status ENUM('enrolled', 'completed', 'certified') NOT NULL DEFAULT 'completed',
                notes TEXT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_train_emp (school_id, employee_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 6. Role-Based Staff Tasks & Delegated Deadlines
        Database::execute("
            CREATE TABLE IF NOT EXISTS staff_tasks (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT NULL,
                assigned_to BIGINT UNSIGNED NOT NULL,
                assigned_by BIGINT UNSIGNED NOT NULL,
                due_date DATE NOT NULL,
                priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
                status ENUM('pending', 'in_progress', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
                completion_notes TEXT NULL,
                completed_at DATETIME NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_task_assignee (school_id, assigned_to, status),
                INDEX idx_task_due (school_id, due_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 7. Employee Academic Qualifications
        Database::execute("
            CREATE TABLE IF NOT EXISTS employee_qualifications (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                employee_id BIGINT UNSIGNED NOT NULL,
                degree_title VARCHAR(150) NOT NULL,
                institution VARCHAR(200) NOT NULL,
                passing_year INT UNSIGNED NOT NULL,
                grade_or_gpa VARCHAR(50) NULL,
                document_path VARCHAR(255) NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_qual_emp (school_id, employee_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 8. Employee Employment Contracts
        Database::execute("
            CREATE TABLE IF NOT EXISTS employee_contracts (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                employee_id BIGINT UNSIGNED NOT NULL,
                contract_type ENUM('permanent', 'contract', 'probation', 'visiting') NOT NULL DEFAULT 'permanent',
                start_date DATE NOT NULL,
                end_date DATE NULL,
                basic_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                notice_period_days INT UNSIGNED NOT NULL DEFAULT 30,
                terms TEXT NULL,
                document_path VARCHAR(255) NULL,
                status ENUM('active', 'expired', 'terminated') NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                INDEX idx_contract_emp (school_id, employee_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // 9. Add shift_id to employees table if missing
        try {
            $colExists = Database::fetch("
                SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'employees' AND COLUMN_NAME = 'shift_id'
            ");
            if (!$colExists) {
                Database::execute("ALTER TABLE employees ADD COLUMN shift_id BIGINT UNSIGNED NULL AFTER designation_id");
            }
        } catch (\Throwable $e) {
            // Ignore if already present
        }
    }

    public function hireCandidate(int $candidateId, array $options = []): int
    {
        $schoolId = (int) Auth::schoolId();
        $this->ensureAdvancedHrSchema();

        Database::beginTransaction();
        try {
            $candidate = Database::fetch(
                'SELECT * FROM candidates WHERE id = ? AND school_id = ? LIMIT 1',
                [$candidateId, $schoolId]
            );
            if (!$candidate) {
                throw new \RuntimeException('Candidate not found.');
            }
            if ($candidate['status'] === 'hired') {
                throw new \RuntimeException('Candidate already hired.');
            }

            $empModel = new Employee();
            $code = $empModel->nextCode();

            $employeeId = Database::insert(
                'INSERT INTO employees
                (school_id, employee_code, first_name, last_name, email, phone, department_id, designation_id,
                 joining_date, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $schoolId,
                    $code,
                    $candidate['first_name'],
                    $candidate['last_name'],
                    $candidate['email'],
                    $candidate['phone'],
                    $candidate['department_id'],
                    $options['designation_id'] ?? null,
                    $options['joining_date'] ?? date('Y-m-d'),
                    'active',
                ]
            );

            if (!empty($options['as_teacher'])) {
                Database::insert(
                    'INSERT INTO teachers (school_id, employee_id, qualification, specialization, experience_years, status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())',
                    [
                        $schoolId,
                        $employeeId,
                        $options['qualification'] ?? null,
                        $options['specialization'] ?? null,
                        (int) ($options['experience_years'] ?? 0),
                    ]
                );
            }

            $basic = (float) ($options['basic_salary'] ?? 0);
            if ($basic > 0) {
                Database::insert(
                    'INSERT INTO salary_structures
                    (school_id, employee_id, basic_salary, house_allowance, transport_allowance, other_allowance, deductions, effective_from, status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                    [
                        $schoolId,
                        $employeeId,
                        $basic,
                        (float) ($options['house_allowance'] ?? 0),
                        (float) ($options['transport_allowance'] ?? 0),
                        (float) ($options['other_allowance'] ?? 0),
                        (float) ($options['deductions'] ?? 0),
                        $options['joining_date'] ?? date('Y-m-d'),
                    ]
                );

                // Auto-create initial contract record
                Database::insert(
                    'INSERT INTO employee_contracts (school_id, employee_id, contract_type, start_date, basic_salary, notice_period_days, status, created_at, updated_at)
                     VALUES (?, ?, "permanent", ?, ?, 30, "active", NOW(), NOW())',
                    [$schoolId, $employeeId, $options['joining_date'] ?? date('Y-m-d'), $basic]
                );
            }

            Database::execute(
                'UPDATE candidates SET status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
                ['hired', $candidateId, $schoolId]
            );

            $financeUsers = (new User())->byRoleSlug('finance');
            foreach ($financeUsers as $fu) {
                notify_user(
                    $schoolId,
                    (int) $fu['id'],
                    'hr',
                    'New employee ready for payroll',
                    $candidate['first_name'] . ' ' . $candidate['last_name'] . ' (' . $code . ') hired. Please set up payroll.',
                    'employee',
                    $employeeId,
                    'finance/payroll'
                );
            }

            Database::commit();
            auditLog('hr.hire', 'hr', 'employees', $employeeId, null, [
                'candidate_id' => $candidateId,
                'employee_code' => $code,
            ]);
            return $employeeId;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function pendingActionsCount(): int
    {
        $schoolId = (int) Auth::schoolId();
        $this->ensureAdvancedHrSchema();

        $leaves = Database::fetch(
            'SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND status = ?',
            [$schoolId, 'pending']
        );
        $candidates = Database::fetch(
            'SELECT COUNT(*) AS c FROM candidates WHERE school_id = ? AND status IN ("interview","selected")',
            [$schoolId]
        );
        $tasks = Database::fetch(
            'SELECT COUNT(*) AS c FROM staff_tasks WHERE school_id = ? AND status = "pending" AND due_date <= CURDATE()',
            [$schoolId]
        );
        $payroll = Database::fetch(
            'SELECT COUNT(*) AS c FROM payroll WHERE school_id = ? AND status IN ("draft","pending")',
            [$schoolId]
        );

        return (int)($leaves['c'] ?? 0) + (int)($candidates['c'] ?? 0) + (int)($tasks['c'] ?? 0) + (int)($payroll['c'] ?? 0);
    }

    /**
     * Compute real-time executive HR Dashboard Metrics.
     */
    public function getHrDashboardMetrics(int $schoolId, array $filters = []): array
    {
        $this->ensureAdvancedHrSchema();

        $deptFilter = !empty($filters['department_id']) ? "AND e.department_id = " . (int)$filters['department_id'] : "";
        $month = !empty($filters['month']) ? $filters['month'] : date('Y-m');

        // 1. Staff Headcount & Status Distribution
        $headcountRow = Database::fetch("
            SELECT 
                COUNT(*) AS total_staff,
                SUM(CASE WHEN e.status = 'active' THEN 1 ELSE 0 END) AS active_staff,
                SUM(CASE WHEN e.status = 'on_leave' THEN 1 ELSE 0 END) AS on_leave_staff,
                SUM(CASE WHEN e.status = 'inactive' OR e.status = 'resigned' OR e.status = 'terminated' THEN 1 ELSE 0 END) AS inactive_staff
            FROM employees e
            WHERE e.school_id = ? {$deptFilter}
        ", [$schoolId]);

        // 2. Today's Staff Attendance
        $today = date('Y-m-d');
        $attRow = Database::fetch("
            SELECT 
                COUNT(*) AS marked_total,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN status = 'half_day' THEN 1 ELSE 0 END) AS half_day_count
            FROM staff_attendance 
            WHERE school_id = ? AND attendance_date = ?
        ", [$schoolId, $today]);

        $totalActive = max(1, (int)($headcountRow['active_staff'] ?? 0));
        $presentEffective = (int)($attRow['present_count'] ?? 0) + (int)($attRow['late_count'] ?? 0);
        $todayAttRate = ($totalActive > 0) ? round(($presentEffective / $totalActive) * 100, 1) : 0.0;

        // 3. Leave Metrics
        $leaveMetrics = Database::fetch("
            SELECT 
                COUNT(*) AS total_leaves_recorded,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_approvals,
                SUM(CASE WHEN status = 'approved' AND start_date LIKE ? THEN 1 ELSE 0 END) AS approved_this_month
            FROM leave_requests 
            WHERE school_id = ?
        ", [$month . '%', $schoolId]);

        // 4. Payroll Standing
        $payrollMetrics = Database::fetch("
            SELECT 
                COUNT(*) AS payroll_records_count,
                COALESCE(SUM(CASE WHEN status = 'paid' THEN net_salary ELSE 0 END), 0) AS total_disbursed,
                COALESCE(SUM(CASE WHEN status IN ('draft', 'pending', 'approved') THEN net_salary ELSE 0 END), 0) AS total_pending_payout,
                COALESCE(AVG(basic_salary), 0) AS avg_basic_salary
            FROM payroll 
            WHERE school_id = ? AND payroll_month = ?
        ", [$schoolId, $month]);

        // 5. Staff Tasks & Reminders
        $taskMetrics = Database::fetch("
            SELECT 
                COUNT(*) AS total_tasks,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress_tasks,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_tasks,
                SUM(CASE WHEN status != 'completed' AND due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue_tasks
            FROM staff_tasks 
            WHERE school_id = ?
        ", [$schoolId]);

        // 6. Performance Evaluation Average
        $perfMetrics = Database::fetch("
            SELECT 
                COUNT(*) AS total_reviews,
                COALESCE(AVG(overall_rating), 5.0) AS avg_faculty_rating
            FROM staff_performance_reviews 
            WHERE school_id = ?
        ", [$schoolId]);

        // 7. Department Distribution
        $departments = Database::fetchAll("
            SELECT d.id, d.name, COUNT(e.id) AS staff_count
            FROM departments d
            LEFT JOIN employees e ON e.department_id = d.id AND e.school_id = d.school_id AND e.status = 'active'
            WHERE d.school_id = ?
            GROUP BY d.id, d.name
            ORDER BY staff_count DESC, d.name ASC
        ", [$schoolId]);

        // 8. Recent 5 Pending Leave Requests
        $pendingLeaves = Database::fetchAll("
            SELECT lr.*, CONCAT(e.first_name, ' ', e.last_name) AS staff_name, e.employee_code,
                   lt.name AS leave_type_name, d.name AS department_name
            FROM leave_requests lr
            JOIN employees e ON e.id = lr.employee_id
            LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
            LEFT JOIN departments d ON d.id = e.department_id
            WHERE lr.school_id = ? AND lr.status = 'pending'
            ORDER BY lr.created_at ASC LIMIT 5
        ", [$schoolId]);

        // 9. Upcoming Holidays
        $upcomingHolidays = Database::fetchAll("
            SELECT * FROM school_holidays 
            WHERE school_id = ? AND end_date >= CURDATE()
            ORDER BY start_date ASC LIMIT 5
        ", [$schoolId]);

        return [
            'headcount'        => $headcountRow,
            'attendance_today' => $attRow,
            'attendance_rate'  => $todayAttRate,
            'leave_metrics'    => $leaveMetrics,
            'payroll_metrics'  => $payrollMetrics,
            'task_metrics'     => $taskMetrics,
            'perf_metrics'     => $perfMetrics,
            'departments'      => $departments,
            'pending_leaves'   => $pendingLeaves,
            'upcoming_holidays'=> $upcomingHolidays,
            'selected_month'   => $month
        ];
    }

    /**
     * Shifts Management
     */
    public function getShifts(int $schoolId): array
    {
        $this->ensureAdvancedHrSchema();
        return Database::fetchAll("
            SELECT s.*, 
                   (SELECT COUNT(*) FROM employees e WHERE e.shift_id = s.id AND e.school_id = s.school_id) AS assigned_staff
            FROM staff_shifts s
            WHERE s.school_id = ?
            ORDER BY s.is_default DESC, s.name ASC
        ", [$schoolId]);
    }

    public function saveShift(int $schoolId, array $data): int
    {
        $this->ensureAdvancedHrSchema();
        $name = trim((string)($data['name'] ?? ''));
        $code = strtoupper(trim((string)($data['code'] ?? '')));
        $startTime = $data['start_time'] ?? '08:00:00';
        $endTime = $data['end_time'] ?? '15:00:00';
        $lateGrace = (int)($data['late_grace_minutes'] ?? 15);
        $halfDay = (int)($data['half_day_threshold_minutes'] ?? 240);
        $isDefault = !empty($data['is_default']) ? 1 : 0;
        $id = !empty($data['id']) ? (int)$data['id'] : 0;

        if ($name === '' || $code === '') {
            throw new \InvalidArgumentException('Shift name and code are required.');
        }

        if ($isDefault) {
            Database::execute("UPDATE staff_shifts SET is_default = 0 WHERE school_id = ?", [$schoolId]);
        }

        if ($id > 0) {
            Database::execute("
                UPDATE staff_shifts 
                SET name = ?, code = ?, start_time = ?, end_time = ?, late_grace_minutes = ?, half_day_threshold_minutes = ?, is_default = ?, updated_at = NOW()
                WHERE id = ? AND school_id = ?
            ", [$name, $code, $startTime, $endTime, $lateGrace, $halfDay, $isDefault, $id, $schoolId]);
            auditLog('shift.update', 'hr', 'staff_shifts', $id);
            return $id;
        }

        $newId = Database::insert("
            INSERT INTO staff_shifts 
            (school_id, name, code, start_time, end_time, late_grace_minutes, half_day_threshold_minutes, is_default, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())
        ", [$schoolId, $name, $code, $startTime, $endTime, $lateGrace, $halfDay, $isDefault]);

        auditLog('shift.create', 'hr', 'staff_shifts', $newId);
        return $newId;
    }

    public function assignShift(int $schoolId, int $employeeId, int $shiftId): bool
    {
        $this->ensureAdvancedHrSchema();
        Database::execute(
            "UPDATE employees SET shift_id = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
            [$shiftId, $employeeId, $schoolId]
        );
        auditLog('shift.assign', 'hr', 'employees', $employeeId, null, ['shift_id' => $shiftId]);
        return true;
    }

    /**
     * Holidays Management
     */
    public function getHolidays(int $schoolId, ?string $year = null): array
    {
        $this->ensureAdvancedHrSchema();
        $sql = "SELECT * FROM school_holidays WHERE school_id = ?";
        $params = [$schoolId];
        if ($year) {
            $sql .= " AND (start_date LIKE ? OR end_date LIKE ?)";
            $params[] = "{$year}%";
            $params[] = "{$year}%";
        }
        $sql .= " ORDER BY start_date ASC";
        return Database::fetchAll($sql, $params);
    }

    public function saveHoliday(int $schoolId, array $data): int
    {
        $this->ensureAdvancedHrSchema();
        $name = trim((string)($data['name'] ?? ''));
        $startDate = $data['start_date'] ?? date('Y-m-d');
        $endDate = $data['end_date'] ?? $startDate;
        $type = in_array($data['type'] ?? '', ['national', 'religious', 'institutional', 'academic'], true) ? $data['type'] : 'institutional';
        $desc = trim((string)($data['description'] ?? ''));
        $recurring = !empty($data['is_recurring']) ? 1 : 0;
        $id = !empty($data['id']) ? (int)$data['id'] : 0;

        if ($name === '') {
            throw new \InvalidArgumentException('Holiday name is required.');
        }

        if ($id > 0) {
            Database::execute("
                UPDATE school_holidays 
                SET name = ?, start_date = ?, end_date = ?, type = ?, is_recurring = ?, description = ?, updated_at = NOW()
                WHERE id = ? AND school_id = ?
            ", [$name, $startDate, $endDate, $type, $recurring, $desc, $id, $schoolId]);
            auditLog('holiday.update', 'hr', 'school_holidays', $id);
            return $id;
        }

        $newId = Database::insert("
            INSERT INTO school_holidays (school_id, name, start_date, end_date, type, is_recurring, description, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ", [$schoolId, $name, $startDate, $endDate, $type, $recurring, $desc]);

        auditLog('holiday.create', 'hr', 'school_holidays', $newId);
        return $newId;
    }

    public function deleteHoliday(int $schoolId, int $holidayId): bool
    {
        $this->ensureAdvancedHrSchema();
        Database::execute("DELETE FROM school_holidays WHERE id = ? AND school_id = ?", [$holidayId, $schoolId]);
        auditLog('holiday.delete', 'hr', 'school_holidays', $holidayId);
        return true;
    }

    /**
     * Leave Balances Management
     */
    public function getLeaveBalances(int $schoolId, int $employeeId, ?int $year = null): array
    {
        $this->ensureAdvancedHrSchema();
        $year = $year ?: (int)date('Y');

        return Database::fetchAll("
            SELECT lt.id AS leave_type_id, lt.name AS leave_type_name, lt.is_paid,
                   COALESCE(b.allocated_days, 15.0) AS allocated_days,
                   COALESCE(b.used_days, 0.0) AS used_days,
                   COALESCE(b.pending_days, 0.0) AS pending_days,
                   (COALESCE(b.allocated_days, 15.0) - COALESCE(b.used_days, 0.0) - COALESCE(b.pending_days, 0.0)) AS remaining_days
            FROM leave_types lt
            LEFT JOIN staff_leave_balances b ON b.leave_type_id = lt.id 
                 AND b.employee_id = ? AND b.year = ? AND b.school_id = ?
            WHERE (lt.school_id = ? OR lt.school_id IS NULL) 
              AND (lt.category = 'staff' OR lt.category = 'all')
            ORDER BY lt.name ASC
        ", [$employeeId, $year, $schoolId, $schoolId]);
    }

    public function allocateLeaveBalance(int $schoolId, int $employeeId, int $leaveTypeId, float $allocatedDays, int $year): void
    {
        $this->ensureAdvancedHrSchema();
        Database::execute("
            INSERT INTO staff_leave_balances 
            (school_id, employee_id, leave_type_id, year, allocated_days, used_days, pending_days, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 0.0, 0.0, NOW(), NOW())
            ON DUPLICATE KEY UPDATE allocated_days = VALUES(allocated_days), updated_at = NOW()
        ", [$schoolId, $employeeId, $leaveTypeId, $year, $allocatedDays]);
    }

    /**
     * Staff Performance Reviews
     */
    public function getPerformanceReviews(int $schoolId, ?int $employeeId = null): array
    {
        $this->ensureAdvancedHrSchema();
        $sql = "
            SELECT r.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name, e.employee_code,
                   d.name AS department_name, des.name AS designation_name,
                   u.name AS reviewer_name
            FROM staff_performance_reviews r
            JOIN employees e ON e.id = r.employee_id
            LEFT JOIN departments d ON d.id = e.department_id
            LEFT JOIN designations des ON des.id = e.designation_id
            LEFT JOIN users u ON u.id = r.reviewer_id
            WHERE r.school_id = ?
        ";
        $params = [$schoolId];
        if ($employeeId) {
            $sql .= " AND r.employee_id = ?";
            $params[] = $employeeId;
        }
        $sql .= " ORDER BY r.review_date DESC, r.id DESC";
        return Database::fetchAll($sql, $params);
    }

    public function createPerformanceReview(int $schoolId, array $data, int $reviewerId): int
    {
        $this->ensureAdvancedHrSchema();
        $empId = (int)($data['employee_id'] ?? 0);
        $period = trim((string)($data['review_period'] ?? 'Annual Evaluation ' . date('Y')));
        $date = $data['review_date'] ?? date('Y-m-d');
        $pedagogy = max(1.0, min(5.0, (float)($data['pedagogy_rating'] ?? 5.0)));
        $punctuality = max(1.0, min(5.0, (float)($data['punctuality_rating'] ?? 5.0)));
        $compliance = max(1.0, min(5.0, (float)($data['compliance_rating'] ?? 5.0)));
        $teamwork = max(1.0, min(5.0, (float)($data['teamwork_rating'] ?? 5.0)));
        $overall = round(($pedagogy + $punctuality + $compliance + $teamwork) / 4, 2);

        $strengths = trim((string)($data['strengths'] ?? ''));
        $growth = trim((string)($data['growth_areas'] ?? ''));
        $goals = trim((string)($data['goals'] ?? ''));

        if (!$empId) {
            throw new \InvalidArgumentException('Employee is required.');
        }

        $id = Database::insert("
            INSERT INTO staff_performance_reviews 
            (school_id, employee_id, reviewer_id, review_period, review_date, overall_rating, pedagogy_rating, punctuality_rating, compliance_rating, teamwork_rating, strengths, growth_areas, goals, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved', NOW(), NOW())
        ", [$schoolId, $empId, $reviewerId, $period, $date, $overall, $pedagogy, $punctuality, $compliance, $teamwork, $strengths, $growth, $goals]);

        auditLog('staff_performance.create', 'hr', 'staff_performance_reviews', $id, null, [
            'employee_id' => $empId,
            'overall_rating' => $overall
        ]);

        return $id;
    }

    /**
     * Professional Development & Trainings
     */
    public function getStaffTrainings(int $schoolId, ?int $employeeId = null): array
    {
        $this->ensureAdvancedHrSchema();
        $sql = "
            SELECT t.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name, e.employee_code,
                   d.name AS department_name
            FROM staff_trainings t
            JOIN employees e ON e.id = t.employee_id
            LEFT JOIN departments d ON d.id = e.department_id
            WHERE t.school_id = ?
        ";
        $params = [$schoolId];
        if ($employeeId) {
            $sql .= " AND t.employee_id = ?";
            $params[] = $employeeId;
        }
        $sql .= " ORDER BY t.start_date DESC";
        return Database::fetchAll($sql, $params);
    }

    public function recordStaffTraining(int $schoolId, array $data): int
    {
        $this->ensureAdvancedHrSchema();
        $empId = (int)($data['employee_id'] ?? 0);
        $title = trim((string)($data['title'] ?? ''));
        $provider = trim((string)($data['provider'] ?? 'Internal Academy'));
        $category = trim((string)($data['category'] ?? 'Pedagogy'));
        $startDate = $data['start_date'] ?? date('Y-m-d');
        $endDate = $data['end_date'] ?? $startDate;
        $hours = (float)($data['hours'] ?? 8.0);
        $cost = (float)($data['cost'] ?? 0.0);
        $certRef = trim((string)($data['certificate_ref'] ?? ''));
        $status = in_array($data['status'] ?? '', ['enrolled', 'completed', 'certified'], true) ? $data['status'] : 'completed';
        $notes = trim((string)($data['notes'] ?? ''));

        if (!$empId || $title === '') {
            throw new \InvalidArgumentException('Employee and training title are required.');
        }

        $id = Database::insert("
            INSERT INTO staff_trainings 
            (school_id, employee_id, title, provider, category, start_date, end_date, hours, cost, certificate_ref, status, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ", [$schoolId, $empId, $title, $provider, $category, $startDate, $endDate, $hours, $cost, $certRef, $status, $notes]);

        auditLog('staff_training.record', 'hr', 'staff_trainings', $id, null, ['employee_id' => $empId, 'title' => $title]);
        return $id;
    }

    /**
     * Staff Tasks Management
     */
    public function getStaffTasks(int $schoolId, array $filters = []): array
    {
        $this->ensureAdvancedHrSchema();
        $sql = "
            SELECT t.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS assignee_name, e.employee_code,
                   d.name AS department_name,
                   u.name AS assigner_name
            FROM staff_tasks t
            JOIN employees e ON e.id = t.assigned_to
            LEFT JOIN departments d ON d.id = e.department_id
            LEFT JOIN users u ON u.id = t.assigned_by
            WHERE t.school_id = ?
        ";
        $params = [$schoolId];

        if (!empty($filters['employee_id'])) {
            $sql .= " AND t.assigned_to = ?";
            $params[] = (int)$filters['employee_id'];
        }
        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $sql .= " AND t.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['priority']) && $filters['priority'] !== 'all') {
            $sql .= " AND t.priority = ?";
            $params[] = $filters['priority'];
        }

        $sql .= " ORDER BY CASE WHEN t.status = 'pending' THEN 1 WHEN t.status = 'in_progress' THEN 2 ELSE 3 END, t.due_date ASC";
        return Database::fetchAll($sql, $params);
    }

    public function createStaffTask(int $schoolId, array $data, int $assignedBy): int
    {
        $this->ensureAdvancedHrSchema();
        $title = trim((string)($data['title'] ?? ''));
        $desc = trim((string)($data['description'] ?? ''));
        $assignee = (int)($data['assigned_to'] ?? 0);
        $dueDate = $data['due_date'] ?? date('Y-m-d', strtotime('+3 days'));
        $priority = in_array($data['priority'] ?? '', ['low', 'medium', 'high', 'urgent'], true) ? $data['priority'] : 'medium';

        if ($title === '' || !$assignee) {
            throw new \InvalidArgumentException('Task title and assigned staff member are required.');
        }

        $id = Database::insert("
            INSERT INTO staff_tasks 
            (school_id, title, description, assigned_to, assigned_by, due_date, priority, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())
        ", [$schoolId, $title, $desc, $assignee, $assignedBy, $dueDate, $priority]);

        // Notify assigned employee user if available
        $empUser = Database::fetch("SELECT u.id FROM users u JOIN employees e ON e.id = u.employee_id WHERE e.id = ? AND e.school_id = ? LIMIT 1", [$assignee, $schoolId]);
        if ($empUser) {
            notify_user(
                $schoolId,
                (int)$empUser['id'],
                'task',
                'New Task Assigned',
                "You have been assigned: {$title}. Deadline: {$dueDate}.",
                'staff_tasks',
                $id,
                'hr/tasks'
            );
        }

        auditLog('staff_task.create', 'hr', 'staff_tasks', $id, null, ['title' => $title, 'assigned_to' => $assignee]);
        return $id;
    }

    public function updateStaffTaskStatus(int $schoolId, int $taskId, string $status, ?string $notes = null): bool
    {
        $this->ensureAdvancedHrSchema();
        if (!in_array($status, ['pending', 'in_progress', 'completed', 'cancelled'], true)) {
            throw new \InvalidArgumentException('Invalid task status.');
        }

        $completedAt = ($status === 'completed') ? date('Y-m-d H:i:s') : null;

        Database::execute("
            UPDATE staff_tasks 
            SET status = ?, completion_notes = COALESCE(?, completion_notes), completed_at = ?, updated_at = NOW()
            WHERE id = ? AND school_id = ?
        ", [$status, $notes, $completedAt, $taskId, $schoolId]);

        auditLog('staff_task.status_update', 'hr', 'staff_tasks', $taskId, null, ['status' => $status]);
        return true;
    }

    /**
     * Staff Qualifications & Contracts
     */
    public function addQualification(int $schoolId, int $employeeId, array $data): int
    {
        $this->ensureAdvancedHrSchema();
        $title = trim((string)($data['degree_title'] ?? ''));
        $inst = trim((string)($data['institution'] ?? ''));
        $year = (int)($data['passing_year'] ?? date('Y'));
        $grade = trim((string)($data['grade_or_gpa'] ?? ''));
        $doc = $data['document_path'] ?? null;

        if ($title === '' || $inst === '') {
            throw new \InvalidArgumentException('Degree title and institution are required.');
        }

        $id = Database::insert("
            INSERT INTO employee_qualifications (school_id, employee_id, degree_title, institution, passing_year, grade_or_gpa, document_path, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ", [$schoolId, $employeeId, $title, $inst, $year, $grade, $doc]);

        auditLog('qualification.add', 'hr', 'employee_qualifications', $id, null, ['degree' => $title]);
        return $id;
    }

    public function addContract(int $schoolId, int $employeeId, array $data): int
    {
        $this->ensureAdvancedHrSchema();
        $type = in_array($data['contract_type'] ?? '', ['permanent', 'contract', 'probation', 'visiting'], true) ? $data['contract_type'] : 'permanent';
        $start = $data['start_date'] ?? date('Y-m-d');
        $end = !empty($data['end_date']) ? $data['end_date'] : null;
        $salary = (float)($data['basic_salary'] ?? 0.0);
        $notice = (int)($data['notice_period_days'] ?? 30);
        $terms = trim((string)($data['terms'] ?? ''));
        $doc = $data['document_path'] ?? null;

        $id = Database::insert("
            INSERT INTO employee_contracts (school_id, employee_id, contract_type, start_date, end_date, basic_salary, notice_period_days, terms, document_path, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())
        ", [$schoolId, $employeeId, $type, $start, $end, $salary, $notice, $terms, $doc]);

        auditLog('contract.add', 'hr', 'employee_contracts', $id, null, ['type' => $type, 'salary' => $salary]);
        return $id;
    }

    /**
     * Retrieve Comprehensive 360-Degree Staff Profile
     */
    public function getStaffFullProfile(int $schoolId, int $employeeId): ?array
    {
        $this->ensureAdvancedHrSchema();

        $employee = Database::fetch("
            SELECT e.*, d.name AS department_name, des.name AS designation_name,
                   sh.name AS shift_name, sh.start_time AS shift_start, sh.end_time AS shift_end,
                   u.id AS user_id, u.email AS user_email, u.phone AS user_phone, u.status AS user_status,
                   r.name AS role_name, r.slug AS role_slug
            FROM employees e
            LEFT JOIN departments d ON d.id = e.department_id AND d.school_id = e.school_id
            LEFT JOIN designations des ON des.id = e.designation_id AND des.school_id = e.school_id
            LEFT JOIN staff_shifts sh ON sh.id = e.shift_id AND sh.school_id = e.school_id
            LEFT JOIN users u ON u.employee_id = e.id AND u.school_id = e.school_id
            LEFT JOIN roles r ON r.id = u.role_id
            WHERE e.id = ? AND e.school_id = ? LIMIT 1
        ", [$employeeId, $schoolId]);

        if (!$employee) {
            return null;
        }

        $qualifications = Database::fetchAll("SELECT * FROM employee_qualifications WHERE employee_id = ? AND school_id = ? ORDER BY passing_year DESC", [$employeeId, $schoolId]);
        $contracts = Database::fetchAll("SELECT * FROM employee_contracts WHERE employee_id = ? AND school_id = ? ORDER BY start_date DESC", [$employeeId, $schoolId]);
        $reviews = Database::fetchAll("SELECT * FROM staff_performance_reviews WHERE employee_id = ? AND school_id = ? ORDER BY review_date DESC", [$employeeId, $schoolId]);
        $trainings = Database::fetchAll("SELECT * FROM staff_trainings WHERE employee_id = ? AND school_id = ? ORDER BY start_date DESC", [$employeeId, $schoolId]);
        $tasks = Database::fetchAll("SELECT * FROM staff_tasks WHERE assigned_to = ? AND school_id = ? ORDER BY due_date ASC", [$employeeId, $schoolId]);
        $leaveBalances = $this->getLeaveBalances($schoolId, $employeeId);
        $salaryStructure = Database::fetch("SELECT * FROM salary_structures WHERE employee_id = ? AND school_id = ? AND status = 1 LIMIT 1", [$employeeId, $schoolId]);

        return [
            'employee'         => $employee,
            'qualifications'   => $qualifications,
            'contracts'        => $contracts,
            'reviews'          => $reviews,
            'trainings'        => $trainings,
            'tasks'            => $tasks,
            'leave_balances'   => $leaveBalances,
            'salary_structure' => $salaryStructure
        ];
    }
}
