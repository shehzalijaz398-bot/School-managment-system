<?php

declare(strict_types=1);

namespace App\Services;

use Core\Database;

final class DataImportExportService
{
    /**
     * Get entity schema specification, required fields, and sample rows.
     */
    public function getEntityDefinition(string $entity): array
    {
        $definitions = [
            'students' => [
                'label' => 'Students Directory',
                'headers' => ['first_name', 'last_name', 'admission_no', 'gender', 'date_of_birth', 'class_name', 'section_name', 'parent_email', 'phone', 'address'],
                'required' => ['first_name', 'gender'],
                'sample' => [
                    ['first_name' => 'John', 'last_name' => 'Doe', 'admission_no' => 'ADM-2026-001', 'gender' => 'male', 'date_of_birth' => '2012-05-14', 'class_name' => 'Grade 7', 'section_name' => 'A', 'parent_email' => 'parent.doe@gmail.com', 'phone' => '555-0101', 'address' => '123 Academic Way'],
                    ['first_name' => 'Sarah', 'last_name' => 'Smith', 'admission_no' => 'ADM-2026-002', 'gender' => 'female', 'date_of_birth' => '2012-08-22', 'class_name' => 'Grade 7', 'section_name' => 'B', 'parent_email' => 'parent.smith@gmail.com', 'phone' => '555-0102', 'address' => '456 Scholars Blvd']
                ]
            ],
            'staff' => [
                'label' => 'Staff & Faculty',
                'headers' => ['first_name', 'last_name', 'employee_id', 'email', 'phone', 'gender', 'designation', 'department', 'role'],
                'required' => ['first_name', 'email'],
                'sample' => [
                    ['first_name' => 'Arthur', 'last_name' => 'Pendelton', 'employee_id' => 'EMP-101', 'email' => 'a.pendelton@school.edu', 'phone' => '555-0201', 'gender' => 'male', 'designation' => 'Senior Instructor', 'department' => 'Science', 'role' => 'teacher'],
                    ['first_name' => 'Clara', 'last_name' => 'Oswald', 'employee_id' => 'EMP-102', 'email' => 'c.oswald@school.edu', 'phone' => '555-0202', 'gender' => 'female', 'designation' => 'Staff Accountant', 'department' => 'Finance', 'role' => 'accountant']
                ]
            ],
            'classes' => [
                'label' => 'Academic Classes',
                'headers' => ['name', 'numeric_level', 'stream'],
                'required' => ['name'],
                'sample' => [
                    ['name' => 'Grade 1', 'numeric_level' => '1', 'stream' => 'General'],
                    ['name' => 'Grade 2', 'numeric_level' => '2', 'stream' => 'General'],
                    ['name' => 'Grade 11 Science', 'numeric_level' => '11', 'stream' => 'Pre-Engineering']
                ]
            ],
            'subjects' => [
                'label' => 'Curriculum Subjects',
                'headers' => ['name', 'code', 'type'],
                'required' => ['name', 'code'],
                'sample' => [
                    ['name' => 'Advanced Mathematics', 'code' => 'MATH-301', 'type' => 'core'],
                    ['name' => 'Physics Laboratory', 'code' => 'PHY-201', 'type' => 'core'],
                    ['name' => 'Art & Digital Design', 'code' => 'ART-101', 'type' => 'elective']
                ]
            ],
            'fees' => [
                'label' => 'Fee Invoices & Billing',
                'headers' => ['student_admission_no', 'fee_title', 'amount', 'due_date'],
                'required' => ['student_admission_no', 'fee_title', 'amount', 'due_date'],
                'sample' => [
                    ['student_admission_no' => 'ADM-2026-001', 'fee_title' => 'Term 1 Tuition Fee', 'amount' => '450.00', 'due_date' => '2026-11-15'],
                    ['student_admission_no' => 'ADM-2026-002', 'fee_title' => 'Laboratory Equipment Fee', 'amount' => '120.00', 'due_date' => '2026-11-20']
                ]
            ]
        ];

        return $definitions[$entity] ?? throw new \InvalidArgumentException("Unsupported import/export entity: {$entity}");
    }

    /**
     * Generate downloadable CSV template string.
     */
    public function generateCsvTemplate(string $entity): string
    {
        $def = $this->getEntityDefinition($entity);
        $output = fopen('php://temp', 'r+');

        // Write header row
        fputcsv($output, $def['headers']);

        // Write sample data rows
        foreach ($def['sample'] as $row) {
            $orderedRow = [];
            foreach ($def['headers'] as $h) {
                $orderedRow[] = $row[$h] ?? '';
            }
            fputcsv($output, $orderedRow);
        }

        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);

        return (string) $csv;
    }

    /**
     * Column Header Synonym Dictionary for intelligent external CSV mapping.
     */
    public const COLUMN_SYNONYMS = [
        'first_name' => ['first_name', 'firstname', 'first name', 'student_name', 'student name', 'learner name', 'given name', 'forename'],
        'last_name' => ['last_name', 'lastname', 'last name', 'surname', 'family name'],
        'admission_no' => ['admission_no', 'admission no', 'admission_number', 'admission number', 'roll_no', 'roll no', 'reg_no', 'reg no', 'student_id', 'student id'],
        'gender' => ['gender', 'sex'],
        'date_of_birth' => ['date_of_birth', 'dob', 'date of birth', 'birthdate', 'birth_date'],
        'class_name' => ['class_name', 'class', 'grade', 'grade level', 'standard', 'year_group'],
        'section_name' => ['section_name', 'section', 'division', 'stream', 'group'],
        'parent_email' => ['parent_email', 'parent email', 'guardian_email', 'guardian email', 'father_email', 'mother_email'],
        'phone' => ['phone', 'contact', 'mobile', 'telephone', 'phone_number', 'phone number', 'cell'],
        'address' => ['address', 'residence', 'street address', 'home_address'],
        'employee_id' => ['employee_id', 'employee id', 'employee_code', 'emp_code', 'staff_id', 'staff id'],
        'email' => ['email', 'email_address', 'staff_email', 'work_email'],
        'designation' => ['designation', 'job_title', 'title', 'position', 'role_title'],
        'department' => ['department', 'dept', 'faculty', 'division'],
        'role' => ['role', 'system_role', 'user_role'],
        'name' => ['name', 'title', 'class_name', 'subject_name'],
        'numeric_level' => ['numeric_level', 'level', 'numeric_name', 'grade_num'],
        'code' => ['code', 'subject_code', 'course_code'],
        'type' => ['type', 'subject_type', 'category'],
        'student_admission_no' => ['student_admission_no', 'admission_no', 'student_id', 'admission_number'],
        'fee_title' => ['fee_title', 'title', 'fee_name', 'description'],
        'amount' => ['amount', 'fee_amount', 'fee', 'charge', 'total'],
        'due_date' => ['due_date', 'due date', 'expiry_date', 'deadline'],
    ];

    /**
     * Automatically map uploaded CSV headers to canonical entity fields.
     */
    public function autoDetectColumnMapping(string $entity, array $rawHeaders): array
    {
        $def = $this->getEntityDefinition($entity);
        $mapping = [];

        foreach ($rawHeaders as $rawH) {
            $normH = strtolower(trim((string)$rawH));
            $mappedField = null;

            // Direct match
            if (in_array($normH, $def['headers'], true)) {
                $mappedField = $normH;
            } else {
                // Check synonym dictionary
                foreach (self::COLUMN_SYNONYMS as $canonical => $synonyms) {
                    if (in_array($canonical, $def['headers'], true) && in_array($normH, $synonyms, true)) {
                        $mappedField = $canonical;
                        break;
                    }
                }
            }

            if ($mappedField !== null && !in_array($mappedField, $mapping, true)) {
                $mapping[$rawH] = $mappedField;
            }
        }

        return $mapping;
    }

    /**
     * Parse CSV, validate fields, check database duplicates, and generate preview report.
     * Supports intelligent column mapping and dry-run validation.
     */
    public function parseAndValidateCsv(int $schoolId, string $entity, string $csvContent, array $customMapping = []): array
    {
        $def = $this->getEntityDefinition($entity);
        $lines = preg_split("/\r\n|\n|\r/", trim($csvContent));
        if (empty($lines)) {
            return [
                'valid' => false,
                'error' => 'The provided file content is empty.'
            ];
        }

        $headerRow = str_getcsv(array_shift($lines));
        $rawHeaders = array_map(fn($h) => trim((string)$h), $headerRow);

        // Resolve Column Mapping
        $effectiveMapping = !empty($customMapping) ? $customMapping : $this->autoDetectColumnMapping($entity, $rawHeaders);

        // Check if required canonical columns are mapped
        $mappedCanonicals = array_values($effectiveMapping);
        $missingHeaders = array_diff($def['required'], $mappedCanonicals);
        if (!empty($missingHeaders)) {
            return [
                'valid' => false,
                'error' => 'Missing mandatory CSV columns or mappings: ' . implode(', ', $missingHeaders),
                'detected_mapping' => $effectiveMapping,
                'raw_headers' => $rawHeaders,
                'required_fields' => $def['required']
            ];
        }

        $validRows = [];
        $duplicateRows = [];
        $errorRows = [];
        $seenFileKeys = [];

        // Preload tenant lookup sets for duplicate detection
        $existingRecords = $this->loadExistingTenantKeys($schoolId, $entity);

        $rowIdx = 1; // 1-indexed (row 1 was header)
        foreach ($lines as $line) {
            $rowIdx++;
            if (trim($line) === '') {
                continue;
            }

            $rawColumns = str_getcsv($line);
            $padded = array_pad($rawColumns, count($rawHeaders), '');
            $rawAssoc = array_combine($rawHeaders, array_slice($padded, 0, count($rawHeaders)));

            // Map to canonical fields using effectiveMapping
            $record = [];
            foreach ($effectiveMapping as $rawH => $canonicalField) {
                $record[$canonicalField] = trim((string)($rawAssoc[$rawH] ?? ''));
            }

            // Fill empty strings for any expected fields not mapped
            foreach ($def['headers'] as $h) {
                if (!isset($record[$h])) {
                    $record[$h] = '';
                }
            }

            // 1. Check required fields
            $rowErrors = [];
            foreach ($def['required'] as $reqField) {
                if (empty($record[$reqField])) {
                    $rowErrors[] = "Mandatory field '{$reqField}' is empty.";
                }
            }

            // 2. Entity-specific field validation
            if ($entity === 'students') {
                if (!empty($record['gender']) && !in_array(strtolower($record['gender']), ['male', 'female', 'other'], true)) {
                    $rowErrors[] = "Invalid gender '{$record['gender']}'. Must be male, female, or other.";
                }
                if (!empty($record['date_of_birth']) && !strtotime($record['date_of_birth'])) {
                    $rowErrors[] = "Invalid date format for date_of_birth: '{$record['date_of_birth']}'.";
                }
            } elseif ($entity === 'staff') {
                if (!empty($record['email']) && !filter_var($record['email'], FILTER_VALIDATE_EMAIL)) {
                    $rowErrors[] = "Invalid email format: '{$record['email']}'.";
                }
            } elseif ($entity === 'fees') {
                if (!empty($record['amount']) && !is_numeric($record['amount'])) {
                    $rowErrors[] = "Fee amount must be numeric: '{$record['amount']}'.";
                }
                if (!empty($record['due_date']) && !strtotime($record['due_date'])) {
                    $rowErrors[] = "Invalid due_date format: '{$record['due_date']}'.";
                }
            }

            if (!empty($rowErrors)) {
                $errorRows[] = [
                    'row_number' => $rowIdx,
                    'record' => $record,
                    'errors' => $rowErrors
                ];
                continue;
            }

            // 3. Duplicate Detection
            $uniqueKey = $this->extractEntityUniqueKey($entity, $record);
            if ($uniqueKey !== '') {
                if (isset($seenFileKeys[$uniqueKey])) {
                    $duplicateRows[] = [
                        'row_number' => $rowIdx,
                        'record' => $record,
                        'reason' => "Duplicate entry in CSV file (Key: {$uniqueKey})"
                    ];
                    continue;
                }
                $seenFileKeys[$uniqueKey] = true;

                if (isset($existingRecords[$uniqueKey])) {
                    $duplicateRows[] = [
                        'row_number' => $rowIdx,
                        'record' => $record,
                        'reason' => "Record already exists in institution database (Key: {$uniqueKey})"
                    ];
                    continue;
                }
            }

            $validRows[] = [
                'row_number' => $rowIdx,
                'record' => $record
            ];
        }

        return [
            'valid' => true,
            'entity' => $entity,
            'total_rows_scanned' => count($lines),
            'valid_count' => count($validRows),
            'duplicate_count' => count($duplicateRows),
            'error_count' => count($errorRows),
            'valid_rows' => $validRows,
            'duplicate_rows' => $duplicateRows,
            'error_rows' => $errorRows,
            'column_mapping_applied' => $effectiveMapping,
            'raw_headers' => $rawHeaders,
            'can_commit' => count($validRows) > 0
        ];
    }

    /**
     * Transactional commit: Execute import in an atomic database transaction.
     * Never silently overwrites existing records.
     */
    public function commitImport(
        int $schoolId,
        string $entity,
        array $validRows,
        int $importedBy,
        bool $skipDuplicates = true
    ): array {
        if (empty($validRows)) {
            return [
                'success' => false,
                'imported_count' => 0,
                'message' => 'No valid rows provided for commit.'
            ];
        }

        $imported = 0;
        $insertedIds = [];

        Database::beginTransaction();
        try {
            foreach ($validRows as $item) {
                $rec = $item['record'] ?? $item;

                if ($entity === 'students') {
                    // Resolve class and section IDs if names provided
                    $classId = null;
                    if (!empty($rec['class_name'])) {
                        $cls = Database::fetch("SELECT id FROM classes WHERE school_id = ? AND name = ? LIMIT 1", [$schoolId, $rec['class_name']]);
                        $classId = $cls ? (int)$cls['id'] : (int)Database::insert("INSERT INTO classes (school_id, name, created_at, updated_at) VALUES (?, ?, NOW(), NOW())", [$schoolId, $rec['class_name']]);
                    }

                    $sectionId = null;
                    if (!empty($rec['section_name']) && $classId) {
                        $sec = Database::fetch("SELECT id FROM sections WHERE school_id = ? AND class_id = ? AND name = ? LIMIT 1", [$schoolId, $classId, $rec['section_name']]);
                        $sectionId = $sec ? (int)$sec['id'] : (int)Database::insert("INSERT INTO sections (school_id, class_id, name, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())", [$schoolId, $classId, $rec['section_name']]);
                    }

                    $admNo = !empty($rec['admission_no']) ? $rec['admission_no'] : 'ADM-' . date('Y') . '-' . sprintf('%04d', random_int(1000, 9999));
                    $dob = !empty($rec['date_of_birth']) ? date('Y-m-d', strtotime($rec['date_of_birth'])) : null;

                    $id = Database::insert("
                        INSERT INTO students 
                        (school_id, class_id, section_id, admission_no, first_name, last_name, gender, date_of_birth, phone, address, status, admission_date, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', CURDATE(), NOW(), NOW())
                    ", [
                        $schoolId,
                        $classId,
                        $sectionId,
                        $admNo,
                        $rec['first_name'],
                        $rec['last_name'] ?? '',
                        strtolower($rec['gender'] ?? 'other'),
                        $dob,
                        $rec['phone'] ?? null,
                        $rec['address'] ?? null
                    ]);

                    $insertedIds[] = $id;
                    $imported++;

                } elseif ($entity === 'staff') {
                    $empCode = !empty($rec['employee_code']) ? $rec['employee_code'] : (!empty($rec['employee_id']) ? $rec['employee_id'] : 'EMP-' . sprintf('%04d', random_int(1000, 9999)));

                    // Resolve department if name provided
                    $deptId = null;
                    if (!empty($rec['department'])) {
                        $dept = Database::fetch("SELECT id FROM departments WHERE school_id = ? AND name = ? LIMIT 1", [$schoolId, $rec['department']]);
                        $deptId = $dept ? (int)$dept['id'] : null;
                    }

                    // Resolve designation if name provided
                    $desigId = null;
                    if (!empty($rec['designation'])) {
                        $desig = Database::fetch("SELECT id FROM designations WHERE school_id = ? AND name = ? LIMIT 1", [$schoolId, $rec['designation']]);
                        $desigId = $desig ? (int)$desig['id'] : null;
                    }

                    $id = Database::insert("
                        INSERT INTO employees 
                        (school_id, employee_code, first_name, last_name, gender, phone, email, department_id, designation_id, status, joining_date, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', CURDATE(), NOW(), NOW())
                    ", [
                        $schoolId,
                        $empCode,
                        $rec['first_name'],
                        $rec['last_name'] ?? '',
                        strtolower($rec['gender'] ?? 'other'),
                        $rec['phone'] ?? null,
                        $rec['email'] ?? null,
                        $deptId,
                        $desigId
                    ]);

                    $insertedIds[] = $id;
                    $imported++;

                } elseif ($entity === 'classes') {
                    $id = Database::insert("
                        INSERT INTO classes (school_id, name, numeric_name, status, created_at, updated_at)
                        VALUES (?, ?, ?, 1, NOW(), NOW())
                    ", [
                        $schoolId,
                        $rec['name'],
                        !empty($rec['numeric_level']) ? (int)$rec['numeric_level'] : 1
                    ]);

                    $insertedIds[] = $id;
                    $imported++;

                } elseif ($entity === 'subjects') {
                    $id = Database::insert("
                        INSERT INTO subjects (school_id, name, code, type, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, 1, NOW(), NOW())
                    ", [
                        $schoolId,
                        $rec['name'],
                        strtoupper($rec['code']),
                        strtolower($rec['type'] ?? 'core')
                    ]);

                    $insertedIds[] = $id;
                    $imported++;

                } elseif ($entity === 'fees') {
                    $stu = Database::fetch("SELECT id FROM students WHERE school_id = ? AND admission_no = ? LIMIT 1", [$schoolId, $rec['student_admission_no']]);
                    if (!$stu) {
                        continue;
                    }

                    $invNo = 'INV-' . date('Y') . '-' . sprintf('%05d', random_int(10000, 99999));
                    $amount = (float)$rec['amount'];
                    $dueDate = date('Y-m-d', strtotime($rec['due_date']));

                    $id = Database::insert("
                        INSERT INTO student_fee_invoices 
                        (school_id, student_id, invoice_no, title, subtotal, total_amount, paid_amount, status, due_date, invoice_date, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, 0.00, 'unpaid', ?, CURDATE(), NOW(), NOW())
                    ", [
                        $schoolId,
                        (int)$stu['id'],
                        $invNo,
                        $rec['fee_title'],
                        $amount,
                        $amount,
                        $dueDate
                    ]);

                    $insertedIds[] = $id;
                    $imported++;
                }
            }

            // Record job in bulk_import_jobs
            $jobId = (int) Database::insert(
                'INSERT INTO bulk_import_jobs 
                 (school_id, user_id, entity, file_name, total_rows, processed_rows, success_count, error_count, status, error_summary, imported_record_ids, is_rolled_back, created_at, completed_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 0, "completed", "", ?, 0, NOW(), NOW())',
                [
                    $schoolId,
                    $importedBy,
                    $entity,
                    "manual_bulk_{$entity}_" . date('Ymd_His'),
                    count($validRows),
                    count($validRows),
                    $imported,
                    json_encode($insertedIds)
                ]
            );

            Database::commit();

            if (function_exists('auditLog')) {
                auditLog('data.bulk_imported', 'data_management', $entity, $imported, null, [
                    'entity' => $entity,
                    'imported_count' => $imported,
                    'imported_by' => $importedBy,
                    'job_id' => $jobId
                ]);
            }

            return [
                'success' => true,
                'job_id' => $jobId,
                'imported_count' => $imported,
                'inserted_ids' => $insertedIds,
                'message' => "Successfully imported {$imported} {$entity} records into institution catalog."
            ];

        } catch (\Throwable $e) {
            Database::rollBack();
            return [
                'success' => false,
                'imported_count' => 0,
                'error' => 'Database transaction failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Safe Rollback: Transactionally rollback an imported batch if no foreign child dependencies exist.
     */
    public function rollbackImport(int $schoolId, int $jobId, int $userId): array
    {
        $job = Database::fetch(
            'SELECT * FROM bulk_import_jobs WHERE id = ? AND school_id = ? LIMIT 1',
            [$jobId, $schoolId]
        );

        if (!$job) {
            return [
                'success' => false,
                'error' => 'Import batch job not found or does not belong to your institution.'
            ];
        }

        if ((int)$job['is_rolled_back'] === 1) {
            return [
                'success' => false,
                'error' => 'This import batch has already been rolled back.'
            ];
        }

        $rawIds = json_decode((string)($job['imported_record_ids'] ?? '[]'), true) ?: [];
        if (empty($rawIds)) {
            return [
                'success' => false,
                'error' => 'No record IDs logged for this batch to rollback.'
            ];
        }

        $entity = $job['entity'];
        Database::beginTransaction();
        try {
            $deletedCount = 0;
            $blockedReasons = [];

            if ($entity === 'students') {
                foreach ($rawIds as $sId) {
                    $hasPayments = (int)(Database::fetch('SELECT COUNT(*) c FROM payments WHERE student_id = ?', [$sId])['c'] ?? 0);
                    $hasMarks = (int)(Database::fetch('SELECT COUNT(*) c FROM exam_marks WHERE student_id = ?', [$sId])['c'] ?? 0);
                    $hasAttendance = (int)(Database::fetch('SELECT COUNT(*) c FROM student_attendance WHERE student_id = ?', [$sId])['c'] ?? 0);

                    if ($hasPayments > 0 || $hasMarks > 0 || $hasAttendance > 0) {
                        $blockedReasons[] = "Student ID {$sId} has operational activity (Payments: {$hasPayments}, Marks: {$hasMarks}, Attendance: {$hasAttendance})";
                        continue;
                    }

                    // Delete unpaid fee invoices created for this student
                    Database::execute('DELETE FROM student_fee_invoices WHERE student_id = ? AND school_id = ? AND paid_amount = 0', [$sId, $schoolId]);
                    Database::execute('DELETE FROM students WHERE id = ? AND school_id = ?', [$sId, $schoolId]);
                    $deletedCount++;
                }
            } elseif ($entity === 'staff') {
                foreach ($rawIds as $eId) {
                    Database::execute('DELETE FROM employees WHERE id = ? AND school_id = ?', [$eId, $schoolId]);
                    $deletedCount++;
                }
            } elseif ($entity === 'classes') {
                foreach ($rawIds as $cId) {
                    $hasStudents = (int)(Database::fetch('SELECT COUNT(*) c FROM students WHERE class_id = ?', [$cId])['c'] ?? 0);
                    if ($hasStudents > 0) {
                        $blockedReasons[] = "Class ID {$cId} has {$hasStudents} students enrolled";
                        continue;
                    }
                    Database::execute('DELETE FROM sections WHERE class_id = ? AND school_id = ?', [$cId, $schoolId]);
                    Database::execute('DELETE FROM classes WHERE id = ? AND school_id = ?', [$cId, $schoolId]);
                    $deletedCount++;
                }
            } elseif ($entity === 'subjects') {
                foreach ($rawIds as $subId) {
                    Database::execute('DELETE FROM subjects WHERE id = ? AND school_id = ?', [$subId, $schoolId]);
                    $deletedCount++;
                }
            } elseif ($entity === 'fees') {
                foreach ($rawIds as $invId) {
                    $hasPayments = (int)(Database::fetch('SELECT COUNT(*) c FROM payments WHERE invoice_id = ?', [$invId])['c'] ?? 0);
                    if ($hasPayments > 0) {
                        $blockedReasons[] = "Invoice ID {$invId} has received payments";
                        continue;
                    }
                    Database::execute('DELETE FROM student_fee_invoices WHERE id = ? AND school_id = ?', [$invId, $schoolId]);
                    $deletedCount++;
                }
            }

            if ($deletedCount === 0 && !empty($blockedReasons)) {
                Database::rollBack();
                return [
                    'success' => false,
                    'error' => 'Rollback blocked by child dependencies: ' . implode('; ', array_slice($blockedReasons, 0, 3)),
                    'blocked_reasons' => $blockedReasons
                ];
            }

            // Mark job rolled back
            Database::execute(
                'UPDATE bulk_import_jobs SET is_rolled_back = 1, rolled_back_at = NOW(), status = "completed" WHERE id = ? AND school_id = ?',
                [$jobId, $schoolId]
            );

            if (function_exists('auditLog')) {
                auditLog('data.bulk_rollback', 'data_management', "Rolled back {$deletedCount} {$entity} records from Job #{$jobId}", null, [
                    'job_id' => $jobId,
                    'school_id' => $schoolId,
                    'user_id' => $userId,
                    'deleted_count' => $deletedCount,
                ]);
            }

            Database::commit();

            return [
                'success' => true,
                'deleted_count' => $deletedCount,
                'blocked_count' => count($blockedReasons),
                'message' => "Successfully rolled back {$deletedCount} {$entity} records." . (!empty($blockedReasons) ? ' (' . count($blockedReasons) . ' records retained due to active dependencies)' : ''),
            ];
        } catch (\Throwable $e) {
            Database::rollBack();
            return [
                'success' => false,
                'error' => 'Rollback transaction failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get historical import batches for this institution.
     */
    public function getImportHistory(int $schoolId, int $limit = 25): array
    {
        return Database::fetchAll(
            'SELECT j.*, u.name as user_name, u.email as user_email
             FROM bulk_import_jobs j
             LEFT JOIN users u ON j.user_id = u.id
             WHERE j.school_id = ?
             ORDER BY j.id DESC
             LIMIT ?',
            [$schoolId, $limit]
        );
    }

    /**
     * Export tenant data to clean CSV string with tenant isolation guarantee.
     */
    public function exportDataToCsv(int $schoolId, string $entity): array
    {
        $def = $this->getEntityDefinition($entity);
        $filename = "export_{$entity}_tenant_{$schoolId}_" . date('Ymd_His') . ".csv";

        $output = fopen('php://temp', 'r+');
        fputcsv($output, $def['headers']);

        $rowsCount = 0;

        if ($entity === 'students') {
            $rows = Database::fetchAll("
                SELECT s.first_name, s.last_name, s.admission_no, s.gender, s.date_of_birth,
                       c.name AS class_name, sec.name AS section_name, s.phone, s.address
                FROM students s
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
                LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
                WHERE s.school_id = ?
                ORDER BY s.id ASC
            ", [$schoolId]);

            foreach ($rows as $r) {
                fputcsv($output, [
                    $r['first_name'],
                    $r['last_name'],
                    $r['admission_no'],
                    $r['gender'],
                    $r['date_of_birth'],
                    $r['class_name'] ?? '',
                    $r['section_name'] ?? '',
                    '', // parent_email
                    $r['phone'] ?? '',
                    $r['address'] ?? ''
                ]);
                $rowsCount++;
            }

        } elseif ($entity === 'staff') {
            $rows = Database::fetchAll("
                SELECT e.first_name, e.last_name, e.employee_code, e.email, e.phone, e.gender,
                       des.name AS designation, d.name AS department
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id AND d.school_id = e.school_id
                LEFT JOIN designations des ON des.id = e.designation_id AND des.school_id = e.school_id
                WHERE e.school_id = ?
                ORDER BY e.id ASC
            ", [$schoolId]);

            foreach ($rows as $r) {
                fputcsv($output, [
                    $r['first_name'],
                    $r['last_name'],
                    $r['employee_code'],
                    $r['email'],
                    $r['phone'] ?? '',
                    $r['gender'],
                    $r['designation'] ?? '',
                    $r['department'] ?? '',
                    'Staff'
                ]);
                $rowsCount++;
            }

        } elseif ($entity === 'classes') {
            $rows = Database::fetchAll("SELECT name, numeric_name FROM classes WHERE school_id = ? ORDER BY id ASC", [$schoolId]);
            foreach ($rows as $r) {
                fputcsv($output, [$r['name'], $r['numeric_name'] ?? 1, 'General']);
                $rowsCount++;
            }

        } elseif ($entity === 'subjects') {
            $rows = Database::fetchAll("SELECT name, code, type FROM subjects WHERE school_id = ? ORDER BY id ASC", [$schoolId]);
            foreach ($rows as $r) {
                fputcsv($output, [$r['name'], $r['code'], $r['type'] ?? 'core']);
                $rowsCount++;
            }

        } elseif ($entity === 'fees') {
            $rows = Database::fetchAll("
                SELECT s.admission_no, fi.title, fi.total_amount, fi.due_date
                FROM student_fee_invoices fi
                INNER JOIN students s ON s.id = fi.student_id AND s.school_id = fi.school_id
                WHERE fi.school_id = ?
                ORDER BY fi.id DESC
            ", [$schoolId]);

            foreach ($rows as $r) {
                fputcsv($output, [$r['admission_no'], $r['title'], $r['total_amount'], $r['due_date']]);
                $rowsCount++;
            }
        }

        rewind($output);
        $csvString = stream_get_contents($output);
        fclose($output);

        return [
            'filename' => $filename,
            'csv_content' => (string)$csvString,
            'rows_exported' => $rowsCount,
            'size_bytes' => strlen((string)$csvString)
        ];
    }

    /**
     * Helper to preload existing duplicate-detection keys for the school tenant.
     */
    private function loadExistingTenantKeys(int $schoolId, string $entity): array
    {
        $keys = [];

        if ($entity === 'students') {
            $admissions = Database::fetchAll("SELECT admission_no FROM students WHERE school_id = ? AND admission_no IS NOT NULL", [$schoolId]);
            foreach ($admissions as $a) {
                $keys[strtolower(trim($a['admission_no']))] = true;
            }
        } elseif ($entity === 'staff') {
            $empIds = Database::fetchAll("SELECT employee_code, email FROM employees WHERE school_id = ?", [$schoolId]);
            foreach ($empIds as $e) {
                if (!empty($e['employee_code'])) {
                    $keys[strtolower(trim($e['employee_code']))] = true;
                }
                if (!empty($e['email'])) {
                    $keys[strtolower(trim($e['email']))] = true;
                }
            }
        } elseif ($entity === 'classes') {
            $classes = Database::fetchAll("SELECT name FROM classes WHERE school_id = ?", [$schoolId]);
            foreach ($classes as $c) {
                $keys[strtolower(trim($c['name']))] = true;
            }
        } elseif ($entity === 'subjects') {
            $subjects = Database::fetchAll("SELECT code FROM subjects WHERE school_id = ?", [$schoolId]);
            foreach ($subjects as $s) {
                $keys[strtolower(trim($s['code']))] = true;
            }
        }

        return $keys;
    }

    /**
     * Extract duplicate-checking key from record.
     */
    private function extractEntityUniqueKey(string $entity, array $record): string
    {
        if ($entity === 'students') {
            return !empty($record['admission_no']) ? strtolower(trim($record['admission_no'])) : '';
        } elseif ($entity === 'staff') {
            if (!empty($record['employee_id'])) return strtolower(trim($record['employee_id']));
            if (!empty($record['email'])) return strtolower(trim($record['email']));
        } elseif ($entity === 'classes') {
            return !empty($record['name']) ? strtolower(trim($record['name'])) : '';
        } elseif ($entity === 'subjects') {
            return !empty($record['code']) ? strtolower(trim($record['code'])) : '';
        }

        return '';
    }
}
