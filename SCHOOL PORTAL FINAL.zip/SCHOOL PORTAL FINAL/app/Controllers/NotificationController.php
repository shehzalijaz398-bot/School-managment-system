<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Notification;
use Core\Auth;
use Core\Controller;

final class NotificationController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $model = new Notification();
        $this->view('notifications/index', [
            'title' => 'Notifications',
            'notifications' => $model->forUser($this->userId()),
        ]);
    }

    public function markRead(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        (new Notification())->markRead((int) $id, $this->userId());
        back();
    }

    public function markAll(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        (new Notification())->markAllRead($this->userId());
        flash('success', 'All notifications marked read.');
        redirect(url('notifications'));
    }

    public function unreadCount(): void
    {
        Auth::requireLogin();
        $this->json(['count' => (new Notification())->unreadCount($this->userId())]);
    }

    public function apiRecent(): void
    {
        Auth::requireLogin();
        $model = new Notification();
        $notifications = $model->recentUnread($this->userId(), 6);
        $count = $model->unreadCount($this->userId());

        $formatted = array_map(function ($n) {
            return [
                'id' => (int) $n['id'],
                'type' => $n['type'],
                'title' => $n['title'],
                'message' => $n['message'],
                'link' => !empty($n['link']) ? url($n['link']) : null,
                'is_read' => (bool) $n['is_read'],
                'created_at' => date('M j, g:i a', strtotime($n['created_at'])),
            ];
        }, $notifications);

        $this->json([
            'status' => 'success',
            'unread_count' => $count,
            'notifications' => $formatted,
        ]);
    }

    public function markReadAjax(string $id): void
    {
        Auth::requireLogin();
        (new Notification())->markRead((int) $id, $this->userId());
        $this->json(['status' => 'success']);
    }

    public function preferences(): void
    {
        Auth::requireLogin();
        $model = new Notification();
        $prefs = $model->getPreferences($this->userId(), $this->schoolId());

        $this->view('notifications/preferences', [
            'title' => 'Notification Preferences',
            'preferences' => $prefs,
        ]);
    }

    public function updatePreferences(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();

        $model = new Notification();
        $model->savePreferences($this->userId(), $this->schoolId(), $_POST);

        flash('success', 'Notification preferences saved successfully.');
        redirect(url('notifications/preferences'));
    }
}
