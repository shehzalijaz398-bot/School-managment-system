<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\AutomationRuleEngine;
use App\Services\WorkflowEngineService;
use Core\Controller;

final class AutomationController extends Controller
{
    private AutomationRuleEngine $engine;
    private WorkflowEngineService $workflowEngine;

    public function __construct()
    {
        parent::__construct();
        $this->engine = new AutomationRuleEngine();
        $this->workflowEngine = new WorkflowEngineService();
    }

    public function index(): void
    {
        requirePermission('settings.view');
        $schoolId = (int) $this->schoolId();

        $rules = $this->engine->getRules($schoolId);
        $metrics = $this->engine->getMetrics($schoolId);
        $logs = $this->engine->getExecutionLogs($schoolId, 30);
        $chains = $this->workflowEngine->getApprovalChains($schoolId);

        $this->view('automations/index', [
            'title' => 'Workflow Automation Engine & Builder',
            'rules' => $rules,
            'metrics' => $metrics,
            'logs' => $logs,
            'chains' => $chains,
        ]);
    }

    public function create(): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();

        try {
            $name = trim((string) ($_POST['name'] ?? ''));
            $category = trim((string) ($_POST['category'] ?? 'general'));
            $trigger = trim((string) ($_POST['trigger_event'] ?? 'fee.overdue_scan'));
            $desc = trim((string) ($_POST['description'] ?? ''));
            $actionType = trim((string) ($_POST['action_type'] ?? 'notify_admin'));
            $cooldown = max(0, (int) ($_POST['cooldown_hours'] ?? 24));
            $isActive = !empty($_POST['is_active']) ? 1 : 0;

            $conditions = [];
            if (!empty($_POST['condition_key']) && isset($_POST['condition_value'])) {
                $conditions[trim((string) $_POST['condition_key'])] = is_numeric($_POST['condition_value']) ? (int) $_POST['condition_value'] : trim((string) $_POST['condition_value']);
            } elseif (!empty($_POST['conditions_json'])) {
                $conditions = json_decode((string) $_POST['conditions_json'], true) ?: [];
            }

            $actionParams = [
                'title' => trim((string) ($_POST['action_title'] ?? 'Workflow Notification')),
                'type' => 'automation.' . $category,
            ];
            if (!empty($_POST['channel'])) {
                $actionParams['channels'] = is_array($_POST['channel']) ? $_POST['channel'] : [$_POST['channel']];
            }

            $ruleId = $this->engine->createRule($schoolId, [
                'name' => $name,
                'category' => $category,
                'trigger_event' => $trigger,
                'description' => $desc,
                'conditions' => $conditions,
                'action_type' => $actionType,
                'action_params' => $actionParams,
                'cooldown_hours' => $cooldown,
                'is_active' => $isActive,
            ]);

            flash('success', "Workflow rule '{$name}' created successfully (Rule #{$ruleId}).");
        } catch (\Throwable $e) {
            flash('error', 'Failed to create automation rule: ' . $e->getMessage());
        }

        redirect(url('automations'));
    }

    public function update(string $id): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $ruleId = (int) $id;

        try {
            $this->engine->updateRule($ruleId, $schoolId, $_POST);
            flash('success', 'Workflow rule updated successfully.');
        } catch (\Throwable $e) {
            flash('error', 'Failed to update rule: ' . $e->getMessage());
        }

        redirect(url('automations'));
    }

    public function delete(string $id): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $ruleId = (int) $id;

        $deleted = $this->engine->deleteRule($ruleId, $schoolId);
        if ($deleted) {
            flash('success', 'Workflow rule removed successfully.');
        } else {
            flash('error', 'Rule not found or could not be removed.');
        }

        redirect(url('automations'));
    }

    public function toggle(string $id): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $ruleId = (int) $id;
        $isActive = !empty($_POST['is_active']);

        $success = $this->engine->toggleRule($ruleId, $schoolId, $isActive);

        if ($success) {
            flash('success', 'Automation rule state updated successfully.');
        } else {
            flash('error', 'Failed to update automation rule.');
        }

        redirect(url('automations'));
    }

    public function preview(string $id): void
    {
        requirePermission('settings.view');
        $schoolId = (int) $this->schoolId();
        $ruleId = (int) $id;

        try {
            $preview = $this->engine->previewRule($ruleId, $schoolId);
            $this->json(['success' => true, 'data' => $preview]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'error' => $e->getMessage()], 404);
        }
    }

    public function aiSuggest(): void
    {
        requirePermission('settings.edit');

        $raw = file_get_contents('php://input');
        $input = json_decode($raw, true) ?: $_POST;
        $prompt = trim((string) ($input['prompt'] ?? ''));

        if ($prompt === '') {
            $this->json(['success' => false, 'error' => 'Workflow description prompt cannot be empty.'], 422);
            return;
        }

        $suggestion = $this->engine->suggestWorkflow($prompt);
        $this->json([
            'success' => true,
            'suggestion' => $suggestion,
            'message' => 'AI workflow proposal generated. Review and confirm before activating.',
        ]);
    }

    public function saveApprovalChain(): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $entityType = trim((string) ($_POST['entity_type'] ?? ''));
        $name = trim((string) ($_POST['name'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));

        if ($entityType === '' || $name === '') {
            flash('error', 'Entity type and approval chain name are required.');
            redirect(url('automations'));
            return;
        }

        $stages = [];
        $rawStages = $_POST['stages'] ?? [];
        if (is_array($rawStages)) {
            $order = 1;
            foreach ($rawStages as $s) {
                if (!empty($s['name']) && !empty($s['role'])) {
                    $stages[] = [
                        'stage' => $order++,
                        'name' => trim((string) $s['name']),
                        'role' => trim((string) $s['role']),
                    ];
                }
            }
        }

        if (empty($stages)) {
            $stages = [
                ['stage' => 1, 'name' => 'Department Review', 'role' => 'admin']
            ];
        }

        $this->workflowEngine->saveApprovalChain($schoolId, $entityType, $name, $stages, $description);

        flash('success', "Approval chain for '{$entityType}' configured successfully.");
        redirect(url('automations'));
    }

    public function runNow(): void
    {
        requirePermission('settings.edit');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $summary = $this->engine->runScheduledAutomations($schoolId);

        flash(
            'success',
            "Automation cycle executed: {$summary['total_actions']} action(s) performed ({$summary['fee_reminders_sent']} fee reminders, {$summary['truancy_alerts_sent']} truancy alerts, {$summary['leave_escalations_sent']} leave escalations)."
        );

        redirect(url('automations'));
    }
}
