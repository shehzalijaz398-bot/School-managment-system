<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\SchoolAnalyticsService;
use Core\Auth;
use Core\Controller;
use Core\PlatformAuth;

/**
 * SchoolAnalyticsController
 *
 * Serves the AI-powered School Analytics module with role-based access controls,
 * tenant isolation, dynamic date filtering, and verified trend summaries.
 */
final class SchoolAnalyticsController extends Controller
{
    private SchoolAnalyticsService $analyticsService;

    public function __construct()
    {
        parent::__construct();
        $this->analyticsService = new SchoolAnalyticsService();
    }

    /**
     * School Tenant Analytics View.
     * Route: GET /analytics/school
     */
    public function index(): void
    {
        // 1. Super Admin Redirection to Platform Analytics Cockpit
        if (class_exists('\\Core\\PlatformAuth') && PlatformAuth::check()) {
            $this->platformIndex();
            return;
        }

        // 2. Strict Authentication & Role Gate
        if (!Auth::check() || !Auth::schoolId()) {
            redirect('login');
            return;
        }

        $allowedRoles = ['admin', 'school_admin', 'principal', 'teacher', 'accountant', 'finance'];
        $roleSlug = Auth::roleSlug() ?? 'school_admin';
        if (!in_array($roleSlug, $allowedRoles, true)) {
            flash('error', 'Access restricted to authorized institutional personnel.');
            redirect('dashboard');
            return;
        }

        $schoolId = (int) Auth::schoolId();
        $period = trim((string) ($_GET['period'] ?? 'last_30_days'));
        $customStart = !empty($_GET['start_date']) ? trim((string) $_GET['start_date']) : null;
        $customEnd = !empty($_GET['end_date']) ? trim((string) $_GET['end_date']) : null;
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;

        $analytics = $this->analyticsService->compileSchoolAnalytics(
            schoolId: $schoolId,
            period: $period,
            customStart: $customStart,
            customEnd: $customEnd,
            role: $roleSlug,
            classId: $classId,
            teacherUserId: (int) Auth::id()
        );

        $this->view('analytics/school', [
            'title' => 'School Analytics & AI Insights',
            'analytics' => $analytics,
            'role' => $roleSlug,
            'activePeriod' => $period,
            'customStart' => $customStart,
            'customEnd' => $customEnd,
            'selectedClassId' => $classId,
        ]);
    }

    /**
     * AJAX JSON API Endpoint for Dynamic Period Filtering & Insights.
     * Route: GET /api/v1/analytics/school-insights
     */
    public function apiInsights(): void
    {
        if (class_exists('\\Core\\PlatformAuth') && PlatformAuth::check()) {
            $period = trim((string) ($_GET['period'] ?? '30d'));
            $data = $this->analyticsService->compilePlatformAnalytics($period);
            $this->json($data, 200);
            return;
        }

        if (!Auth::check() || !Auth::schoolId()) {
            $this->json(['status' => 'error', 'message' => 'Authentication required.'], 401);
            return;
        }

        $schoolId = (int) Auth::schoolId();
        $roleSlug = Auth::roleSlug() ?? 'school_admin';
        $period = trim((string) ($_GET['period'] ?? 'last_30_days'));
        $customStart = !empty($_GET['start_date']) ? trim((string) $_GET['start_date']) : null;
        $customEnd = !empty($_GET['end_date']) ? trim((string) $_GET['end_date']) : null;
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;

        $payload = $this->analyticsService->compileSchoolAnalytics(
            schoolId: $schoolId,
            period: $period,
            customStart: $customStart,
            customEnd: $customEnd,
            role: $roleSlug,
            classId: $classId,
            teacherUserId: (int) Auth::id()
        );

        $this->json($payload, 200);
    }

    /**
     * AJAX JSON Endpoint for Student-Level Cohort Drilldown.
     * Route: GET /analytics/cohort-drilldown
     */
    public function cohortDrilldown(): void
    {
        if (!Auth::check() || !Auth::schoolId()) {
            $this->json(['status' => 'error', 'message' => 'Authentication required.'], 401);
            return;
        }

        $allowedRoles = ['admin', 'school_admin', 'principal', 'teacher', 'accountant', 'finance'];
        $roleSlug = Auth::roleSlug() ?? 'school_admin';
        if (!in_array($roleSlug, $allowedRoles, true)) {
            $this->json(['status' => 'error', 'message' => 'Access restricted.'], 403);
            return;
        }

        $classId = isset($_GET['class_id']) ? (int) $_GET['class_id'] : 0;
        if ($classId <= 0) {
            $this->json(['status' => 'error', 'message' => 'Valid class_id parameter is required.'], 400);
            return;
        }

        $schoolId = (int) Auth::schoolId();
        $period = trim((string) ($_GET['period'] ?? 'last_30_days'));
        $customStart = !empty($_GET['start_date']) ? trim((string) $_GET['start_date']) : null;
        $customEnd = !empty($_GET['end_date']) ? trim((string) $_GET['end_date']) : null;

        $drilldown = $this->analyticsService->getStudentCohortDrilldown(
            schoolId: $schoolId,
            classId: $classId,
            period: $period,
            customStart: $customStart,
            customEnd: $customEnd,
            role: $roleSlug,
            teacherUserId: (int) Auth::id()
        );

        $this->json($drilldown, 200);
    }

    /**
     * Platform Super Administrator Analytics View.
     * Route: GET /superadmin/analytics
     */
    public function platformIndex(): void
    {
        if (!class_exists('\\Core\\PlatformAuth') || !PlatformAuth::check()) {
            redirect('login');
            return;
        }

        PlatformAuth::requirePermission('platform.dashboard');

        $period = trim((string) ($_GET['period'] ?? '30d'));
        $analytics = $this->analyticsService->compilePlatformAnalytics($period);

        $this->view('platform/analytics/index', [
            'title' => 'Platform AI Analytics & Macro Intelligence',
            'analytics' => $analytics,
            'activePeriod' => $period,
        ], 'platform/layouts/app');
    }

    /**
     * Export school analytics report (CSV, JSON, or Print/PDF HTML).
     * Route: GET /analytics/export
     */
    public function export(): void
    {
        if (!Auth::check() || !Auth::schoolId()) {
            redirect('login');
            return;
        }

        $allowedRoles = ['admin', 'school_admin', 'principal', 'teacher', 'accountant', 'finance'];
        $roleSlug = Auth::roleSlug() ?? 'school_admin';
        if (!in_array($roleSlug, $allowedRoles, true)) {
            flash('error', 'Access restricted.');
            redirect('dashboard');
            return;
        }

        $schoolId = (int) Auth::schoolId();
        $period = trim((string) ($_GET['period'] ?? 'last_30_days'));
        $customStart = !empty($_GET['start_date']) ? trim((string) $_GET['start_date']) : null;
        $customEnd = !empty($_GET['end_date']) ? trim((string) $_GET['end_date']) : null;
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $format = strtolower(trim((string) ($_GET['format'] ?? 'csv')));

        // Print / Executive PDF HTML export
        if ($format === 'print' || $format === 'pdf') {
            $html = $this->analyticsService->generatePrintableReportHtml(
                schoolId: $schoolId,
                period: $period,
                customStart: $customStart,
                customEnd: $customEnd,
                role: $roleSlug,
                classId: $classId
            );
            header('Content-Type: text/html; charset=UTF-8');
            header('Pragma: no-cache');
            header('Expires: 0');
            echo $html;
            exit;
        }

        if ($format === 'json') {
            $data = $this->analyticsService->compileSchoolAnalytics(
                schoolId: $schoolId,
                period: $period,
                customStart: $customStart,
                customEnd: $customEnd,
                role: $roleSlug,
                classId: $classId,
                teacherUserId: (int) Auth::id()
            );
            $filename = 'analytics_report_' . $schoolId . '_' . date('Ymd_His') . '.json';
            header('Content-Type: application/json; charset=UTF-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            exit;
        }

        // CSV export
        $csv = $this->analyticsService->exportSchoolAnalyticsCsv(
            schoolId: $schoolId,
            period: $period,
            start: $customStart,
            end: $customEnd,
            role: $roleSlug,
            classId: $classId
        );

        $filename = 'analytics_report_' . $schoolId . '_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $csv;
        exit;
    }
}
