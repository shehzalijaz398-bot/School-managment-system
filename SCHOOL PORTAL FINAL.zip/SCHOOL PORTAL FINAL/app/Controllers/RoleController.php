<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class RoleController extends Controller
{
    public function index(): void
    {
        requirePermission('settings.manage');

        // Support legacy accounts table view via query param ?view=accounts
        if (($_GET['view'] ?? '') === 'accounts') {
            (new UserController())->index();
            return;
        }

        $schoolId = (int) $this->schoolId();

        // 1. Fetch all roles for this school
        $roles = Database::fetchAll(
            'SELECT r.*, COUNT(rp.permission_id) AS capability_count
             FROM roles r
             LEFT JOIN role_permissions rp ON rp.role_id = r.id
             WHERE r.school_id = ? OR r.school_id IS NULL
             GROUP BY r.id
             ORDER BY CASE 
                WHEN r.slug = "academic_manager" THEN 1
                WHEN r.slug = "accountant" THEN 2
                WHEN r.slug = "administrator" THEN 3
                WHEN r.slug = "admissions_officer" THEN 4
                WHEN r.slug = "hr_manager" THEN 5
                WHEN r.slug = "owner" THEN 6
                WHEN r.slug = "read_only_staff" THEN 7
                WHEN r.slug = "receptionist" THEN 8
                WHEN r.slug = "teacher" THEN 9
                ELSE 10
             END, r.name ASC',
            [$schoolId]
        );

        // 2. Identify active selected role
        $selectedRoleId = isset($_GET['role_id']) ? (int) $_GET['role_id'] : 0;
        $activeRole = null;
        if ($selectedRoleId > 0) {
            foreach ($roles as $r) {
                if ((int) $r['id'] === $selectedRoleId) {
                    $activeRole = $r;
                    break;
                }
            }
        }
        if (!$activeRole && !empty($roles)) {
            $activeRole = $roles[0];
            $selectedRoleId = (int) $activeRole['id'];
        }

        // 3. Fetch all capabilities grouped by module
        $rawPerms = Database::fetchAll(
            'SELECT * FROM permissions ORDER BY 
             CASE 
                WHEN module = "Academics" THEN 1
                WHEN module = "Students & Admissions" THEN 2
                WHEN module = "Settings & System" THEN 3
                WHEN module = "Staff & HR" THEN 4
                WHEN module = "Finance" THEN 5
                WHEN module = "Attendance" THEN 6
                ELSE 7
             END, id ASC'
        );

        $groupedPerms = [];
        foreach ($rawPerms as $p) {
            $cat = $p['module'] ?: 'General';
            if (!isset($groupedPerms[$cat])) {
                $groupedPerms[$cat] = [];
            }
            $groupedPerms[$cat][] = $p;
        }

        // 4. Fetch permissions granted to the active role
        $activePermIds = [];
        if ($activeRole) {
            $rows = Database::fetchAll(
                'SELECT permission_id FROM role_permissions WHERE role_id = ?',
                [(int) $activeRole['id']]
            );
            $activePermIds = array_map('intval', array_column($rows, 'permission_id'));
        }

        // 5. Calculate category stats for active role (e.g. 26/27)
        $categoryStats = [];
        foreach ($groupedPerms as $cat => $permsList) {
            $totalInCat = count($permsList);
            $grantedInCat = 0;
            foreach ($permsList as $p) {
                if (in_array((int) $p['id'], $activePermIds, true)) {
                    $grantedInCat++;
                }
            }
            $categoryStats[$cat] = [
                'granted' => $grantedInCat,
                'total' => $totalInCat,
            ];
        }

        $this->view('roles/index', [
            'title' => 'Roles & Permissions',
            'roles' => $roles,
            'activeRole' => $activeRole,
            'groupedPerms' => $groupedPerms,
            'activePermIds' => $activePermIds,
            'categoryStats' => $categoryStats,
        ]);
    }

    public function update(int $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        $role = Database::fetch(
            'SELECT * FROM roles WHERE id = ? AND (school_id = ? OR school_id IS NULL) LIMIT 1',
            [$id, $schoolId]
        );

        if (!$role) {
            flash('error', 'Role not found.');
            redirect(url('staff/roles'));
            return;
        }

        $roleName = trim($_POST['name'] ?? $role['name']);
        $roleDesc = trim($_POST['description'] ?? ($role['description'] ?? ''));

        // System lock protection: do not rename immutable owner
        if ($role['slug'] !== 'owner') {
            Database::execute(
                'UPDATE roles SET name = ?, description = ?, updated_at = NOW() WHERE id = ?',
                [$roleName, $roleDesc, $id]
            );
        }

        // Update capabilities
        $submittedPerms = $_POST['permissions'] ?? [];
        if (!is_array($submittedPerms)) {
            $submittedPerms = [];
        }

        // Owner always maintains all permissions
        if ($role['slug'] === 'owner') {
            $allPermIds = Database::fetchAll('SELECT id FROM permissions');
            $submittedPerms = array_column($allPermIds, 'id');
        }

        Database::beginTransaction();
        try {
            Database::execute('DELETE FROM role_permissions WHERE role_id = ?', [$id]);
            foreach ($submittedPerms as $permId) {
                $pId = (int) $permId;
                if ($pId > 0) {
                    Database::insert(
                        'INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)',
                        [$id, $pId]
                    );
                }
            }
            Database::commit();
            flash('success', 'Capabilities and role details updated successfully.');
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', 'Failed to update capabilities: ' . $e->getMessage());
        }

        redirect(url('staff/roles?role_id=' . $id));
    }

    public function store(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');

        if ($name === '') {
            flash('error', 'Role name cannot be empty.');
            redirect(url('staff/roles'));
            return;
        }

        $slug = strtolower(preg_replace('/[^A-Za-z0-9_]/', '_', trim($name)));
        // Append random suffix if slug collision
        $slugCheck = Database::fetch(
            'SELECT id FROM roles WHERE slug = ? AND school_id = ? LIMIT 1',
            [$slug, $schoolId]
        );
        if ($slugCheck) {
            $slug .= '_' . substr(bin2hex(random_bytes(3)), 0, 4);
        }

        $newRoleId = Database::insert(
            'INSERT INTO roles (school_id, name, slug, description, is_system, created_at, updated_at) VALUES (?, ?, ?, ?, 0, NOW(), NOW())',
            [$schoolId, $name, $slug, $desc]
        );

        flash('success', 'New role created. You can now configure its capability map.');
        redirect(url('staff/roles?role_id=' . $newRoleId));
    }

    public function destroy(int $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        $role = Database::fetch(
            'SELECT * FROM roles WHERE id = ? AND school_id = ? LIMIT 1',
            [$id, $schoolId]
        );

        if (!$role || (int)$role['is_system'] === 1) {
            flash('error', 'System protected roles cannot be deleted.');
            redirect(url('staff/roles'));
            return;
        }

        // Check if users are assigned to this role
        $usersWithRole = Database::fetch(
            'SELECT COUNT(*) as cnt FROM users WHERE role_id = ? AND school_id = ?',
            [$id, $schoolId]
        );
        if ($usersWithRole && (int)$usersWithRole['cnt'] > 0) {
            flash('error', 'Cannot delete role because staff users are currently assigned to it.');
            redirect(url('staff/roles?role_id=' . $id));
            return;
        }

        Database::execute('DELETE FROM role_permissions WHERE role_id = ?', [$id]);
        Database::execute('DELETE FROM roles WHERE id = ?', [$id]);

        flash('success', 'Role deleted successfully.');
        redirect(url('staff/roles'));
    }
}
