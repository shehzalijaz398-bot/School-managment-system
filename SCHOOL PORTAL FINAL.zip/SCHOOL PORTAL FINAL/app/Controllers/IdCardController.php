<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class IdCardController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS tenant_id_card_designs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                card_type VARCHAR(20) NOT NULL,
                primary_color VARCHAR(15) NOT NULL DEFAULT '#0b4f6c',
                secondary_color VARCHAR(15) NOT NULL DEFAULT '#01baef',
                enable_qr TINYINT(1) NOT NULL DEFAULT 1,
                header_text VARCHAR(100) NULL,
                template_json TEXT NULL,
                updated_at DATETIME NOT NULL,
                UNIQUE KEY unique_design (school_id, card_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function index(): void
    {
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        $role = Auth::roleSlug();
        
        $designStudent = Database::fetch("SELECT * FROM tenant_id_card_designs WHERE school_id = ? AND card_type = 'student'", [$schoolId]) ?: [
            'primary_color' => '#0b4f6c', 'secondary_color' => '#01baef', 'enable_qr' => 1, 'header_text' => 'STUDENT IDENTIFICATION'
        ];
        
        $designStaff = Database::fetch("SELECT * FROM tenant_id_card_designs WHERE school_id = ? AND card_type = 'staff'", [$schoolId]) ?: [
            'primary_color' => '#1a1a1a', 'secondary_color' => '#dc3545', 'enable_qr' => 1, 'header_text' => 'FACULTY BADGE'
        ];

        $users = [];
        
        if (in_array($role, ['admin', 'school_admin', 'superadmin', 'principal', 'hr'], true)) {
            // Can view directory of all
            $users = Database::fetchAll("
                SELECT u.id, u.name, r.slug as role, u.email 
                FROM users u 
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE u.school_id = ? AND u.status = 1
                ORDER BY r.slug ASC, u.name ASC
            ", [$schoolId]);
        } else {
            // See only self
            $users = Database::fetchAll("
                SELECT u.id, u.name, r.slug as role, u.email 
                FROM users u 
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE u.id = ? AND u.school_id = ?
            ", [$user['id'], $schoolId]);
        }

        $this->view('identity/cards_dashboard', [
            'title' => 'Enterprise Smart Badging Hub',
            'designStudent' => $designStudent,
            'designStaff' => $designStaff,
            'users' => $users,
            'role' => $role
        ]);
    }

    public function config(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $this->initSchema();
        $schoolId = Auth::schoolId();
        
        $cardType = $_POST['card_type'] ?? 'student';
        $primaryColor = $_POST['primary_color'] ?? '#000000';
        $secondaryColor = $_POST['secondary_color'] ?? '#ffffff';
        $enableQr = (int)($_POST['enable_qr'] ?? 0);
        $headerText = $_POST['header_text'] ?? 'ID CARD';

        Database::execute("
            INSERT INTO tenant_id_card_designs (school_id, card_type, primary_color, secondary_color, enable_qr, header_text, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE 
                primary_color = VALUES(primary_color),
                secondary_color = VALUES(secondary_color),
                enable_qr = VALUES(enable_qr),
                header_text = VALUES(header_text),
                updated_at = NOW()
        ", [$schoolId, $cardType, $primaryColor, $secondaryColor, $enableQr, $headerText]);

        flash('success', "Custom {$cardType} template matrix overridden successfully.");
        redirect(url('identity/cards'));
    }

    public function download(string $targetId): void
    {
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        $currRole = Auth::roleSlug();
        
        // Validation scope
        if (!in_array($currRole, ['admin', 'school_admin', 'superadmin', 'principal', 'hr'], true) && (int)Auth::id() !== (int)$targetId) {
            abort(403);
        }

        $targetUser = Database::fetch("
            SELECT u.*, r.slug as role_slug 
            FROM users u 
            LEFT JOIN roles r ON r.id = u.role_id
            WHERE u.id = ? AND u.school_id = ? LIMIT 1
        ", [(int)$targetId, $schoolId]);
        if (!$targetUser) abort(404);

        $role = $targetUser['role_slug'] ?? 'student';
        $isStaff = in_array($role, ['teacher', 'admin', 'school_admin', 'principal', 'superadmin', 'hr', 'finance', 'staff'], true);
        $cardType = $isStaff ? 'staff' : 'student';

        $design = Database::fetch("SELECT * FROM tenant_id_card_designs WHERE school_id = ? AND card_type = ?", [$schoolId, $cardType]);
        if (!$design) {
            $design = [
                'primary_color' => $isStaff ? '#1a1a1a' : '#0b4f6c', 
                'secondary_color' => $isStaff ? '#dc3545' : '#01baef', 
                'enable_qr' => 1, 
                'header_text' => $isStaff ? 'FACULTY BADGE' : 'STUDENT IDENTIFICATION'
            ];
        }

        // ROLE-BASED DYNAMIC PAYLOAD INJECTION
        $payload = [];
        if ($isStaff) {
            $staffData = Database::fetch("
                SELECT e.employee_code, e.joining_date, d.title as designation 
                FROM employees e 
                LEFT JOIN designations d ON d.id = e.designation_id 
                WHERE (e.id = ? OR e.id = (SELECT employee_id FROM users WHERE id = ?)) AND e.school_id = ? LIMIT 1",
                [(int)($targetUser['employee_id'] ?? 0), (int)$targetId, $schoolId]
            );
            $payload = [
                'name' => $targetUser['name'],
                'subtitle' => $staffData['designation'] ?? ucfirst($role),
                'field1_label' => 'EMP CODE',
                'field1_value' => $staffData['employee_code'] ?? 'N/A',
                'field2_label' => 'JOINED',
                'field2_value' => $staffData['joining_date'] ?? 'N/A',
                'field3_label' => 'ROLE',
                'field3_value' => ucfirst($role),
            ];
        } else {
            $studentData = Database::fetch("
                SELECT s.admission_no, s.roll_no, s.blood_group, c.name as class_name, p.phone as parent_phone
                FROM students s
                LEFT JOIN classes c ON s.class_id = c.id
                LEFT JOIN parents p ON s.parent_id = p.id
                WHERE s.user_id = ? AND s.school_id = ?
            ", [(int)$targetId, $schoolId]);
            
            $payload = [
                'name' => $targetUser['name'],
                'subtitle' => 'Class: ' . ($studentData['class_name'] ?? 'N/A'),
                'field1_label' => 'ROLL NO',
                'field1_value' => $studentData['roll_no'] ?? 'N/A',
                'field2_label' => 'BLOOD GRP',
                'field2_value' => $studentData['blood_group'] ?? 'O+',
                'field3_label' => 'EMERGENCY',
                'field3_value' => $studentData['parent_phone'] ?? 'N/A',
            ];
        }

        // AUTOMATED ACCESS LOG LINKAGE (QR String)
        $qrData = '';
        if ($design['enable_qr']) {
            $rawToken = $schoolId . ':' . $targetId . ':' . time();
            $hash = hash('sha256', $rawToken . app_config('app.key', 'secret'));
            $qrData = "https://app.schoolportal.local/gate/verify/" . substr($hash, 0, 16);
        }

        // Output Raw HTML view (suitable for print to PDF dynamically)
        // Normally we'd use dompdf or similar, but instructions say "browser PDF output exports".
        // So we just render a dedicated view.
        $this->view('identity/render_card', [
            'design' => $design,
            'payload' => $payload,
            'qrData' => $qrData,
            'user' => $targetUser
        ], 'layouts/guest');
    }
}
