<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\Employee;
use App\Models\Section;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use App\Services\AttendanceService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class AttendanceController extends Controller
{
    public function studentForm(): void
    {
        requirePermission('attendance.students.mark');
        $classes = (new ClassModel())->withSections();
        $classId = (int) ($_GET['class_id'] ?? 0);
        $sectionId = isset($_GET['section_id']) ? (int) $_GET['section_id'] : 0;
        $date = $_GET['date'] ?? date('Y-m-d');
        $students = [];
        $existing = [];
        $remarks = [];

        if (!$classId && !empty($classes)) {
            if (isRole('teacher')) {
                $teacher = (new Teacher())->findByUserId((int) Auth::id());
                $assigned = Database::fetch('SELECT class_id, section_id FROM teacher_assignments WHERE school_id = ? AND teacher_id = ? AND status = 1 LIMIT 1', [$this->schoolId(), (int) ($teacher['id'] ?? 0)]);
                if ($assigned) {
                    $classId = (int) $assigned['class_id'];
                    $sectionId = (int) $assigned['section_id'];
                } else {
                    $classId = (int) $classes[0]['id'];
                }
            } else {
                $classId = (int) $classes[0]['id'];
                if (!empty($classes[0]['sections'])) {
                    $sectionId = (int) $classes[0]['sections'][0]['id'];
                }
            }
        }

        // Available sections for chosen class
        $availableSections = [];
        foreach ($classes as $c) {
            if ((int) $c['id'] === $classId) {
                $availableSections = $c['sections'] ?? [];
                break;
            }
        }

        if ($classId) {
            // Teachers may only mark assigned classes
            if (isRole('teacher')) {
                $teacher = (new Teacher())->findByUserId((int) Auth::id());
                $ok = Database::fetch(
                    'SELECT id FROM teacher_assignments WHERE school_id = ? AND teacher_id = ? AND class_id = ? AND status = 1 LIMIT 1',
                    [$this->schoolId(), (int) ($teacher['id'] ?? 0), $classId]
                );
                if (!$ok) {
                    flash('error', 'You can only mark attendance for assigned classes.');
                    redirect(url('attendance/students'));
                }
            }

            $students = (new Student())->byClassSection($classId, $sectionId);

            $sql = 'SELECT student_id, status, remarks FROM student_attendance WHERE school_id = ? AND class_id = ? AND attendance_date = ?';
            $params = [$this->schoolId(), $classId, $date];
            if ($sectionId > 0) {
                $sql .= ' AND section_id = ?';
                $params[] = $sectionId;
            }
            $rows = Database::fetchAll($sql, $params);
            foreach ($rows as $r) {
                $existing[(int) $r['student_id']] = $r['status'];
                if (!empty($r['remarks'])) {
                    $remarks[(int) $r['student_id']] = $r['remarks'];
                }
            }
        }

        // Summary Calculations
        $isSubmitted = !empty($existing);
        $totalCount = count($students);
        $presentCount = 0;
        $lateCount = 0;
        $absentCount = 0;
        $halfCount = 0;
        $leaveCount = 0;

        foreach ($students as $st) {
            $sid = (int) $st['id'];
            $stStatus = $existing[$sid] ?? ($isSubmitted ? 'present' : 'present');
            if ($stStatus === 'present') $presentCount++;
            elseif ($stStatus === 'late') $lateCount++;
            elseif ($stStatus === 'absent') $absentCount++;
            elseif ($stStatus === 'half_day') $halfCount++;
            elseif ($stStatus === 'leave' || $stStatus === 'excused') $leaveCount++;
        }

        $effectivePresent = $presentCount + $lateCount + ($halfCount * 0.5);
        $ratePct = $totalCount > 0 ? round(($effectivePresent / $totalCount) * 100) : 0;

        $this->view('attendance/students', [
            'title'             => 'Student Attendance',
            'classes'           => $classes,
            'availableSections' => $availableSections,
            'students'          => $students,
            'existing'          => $existing,
            'remarks'           => $remarks,
            'classId'           => $classId,
            'sectionId'         => $sectionId,
            'date'              => $date,
            'isSubmitted'       => $isSubmitted,
            'summary'           => [
                'total'    => $totalCount,
                'present'  => $presentCount,
                'late'     => $lateCount,
                'absent'   => $absentCount,
                'half'     => $halfCount,
                'leave'    => $leaveCount,
                'rate_pct' => $ratePct,
            ]
        ]);
    }

    public function studentStore(): void
    {
        requirePermission('attendance.students.mark');
        $this->requireCsrf();
        $classId = (int) $_POST['class_id'];
        $sectionId = (int) ($_POST['section_id'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');
        $statuses = $_POST['status'] ?? [];
        $remarks = $_POST['remarks'] ?? [];
        try {
            (new AttendanceService())->markStudentAttendance($classId, $sectionId, $date, $statuses, $this->userId(), $remarks);
            flash('success', 'Student attendance recorded successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('attendance/students?class_id=' . $classId . '&section_id=' . $sectionId . '&date=' . urlencode($date)));
    }

    public function staffForm(): void
    {
        requirePermission('attendance.staff.mark');
        $date = $_GET['date'] ?? date('Y-m-d');
        $selectedDept = $_GET['dept'] ?? '';
        $selectedRole = $_GET['role'] ?? '';
        $search = trim($_GET['q'] ?? '');

        // Dropdown choices
        $departments = Database::fetchAll(
            'SELECT DISTINCT name FROM departments WHERE school_id = ? AND name IS NOT NULL AND name != "" ORDER BY name ASC',
            [$this->schoolId()]
        );
        $roles = Database::fetchAll(
            'SELECT DISTINCT name FROM roles WHERE (school_id = ? OR school_id IS NULL) AND name IS NOT NULL AND name != "" ORDER BY name ASC',
            [$this->schoolId()]
        );

        // Fetch all active employees for this school
        $sql = 'SELECT e.*, d.name AS department_name, des.name AS designation_name, r.name AS role_name
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN users u ON u.employee_id = e.id
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE e.school_id = ? AND e.status = "active"';
        $params = [$this->schoolId()];

        if ($selectedDept !== '') {
            $sql .= ' AND d.name = ?';
            $params[] = $selectedDept;
        }
        if ($selectedRole !== '') {
            $sql .= ' AND r.name = ?';
            $params[] = $selectedRole;
        }
        if ($search !== '') {
            $sql .= ' AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ?)';
            $wildcard = '%' . $search . '%';
            $params[] = $wildcard;
            $params[] = $wildcard;
            $params[] = $wildcard;
        }

        $sql .= ' ORDER BY e.first_name ASC, e.last_name ASC';
        $employees = Database::fetchAll($sql, $params);

        // Fetch attendance records for this date
        $rows = Database::fetchAll(
            'SELECT employee_id, status, remarks FROM staff_attendance WHERE school_id = ? AND attendance_date = ?',
            [$this->schoolId(), $date]
        );
        $existing = [];
        $existingRemarks = [];
        foreach ($rows as $r) {
            $existing[(int) $r['employee_id']] = $r['status'];
            $existingRemarks[(int) $r['employee_id']] = $r['remarks'] ?? '';
        }

        // Calculate KPI metrics across all school employees for this date
        $allActiveCount = (int) (Database::fetch(
            'SELECT COUNT(*) as cnt FROM employees WHERE school_id = ? AND status = "active"',
            [$this->schoolId()]
        )['cnt'] ?? count($employees));

        $stats = Database::fetchAll(
            'SELECT status, COUNT(*) as cnt FROM staff_attendance WHERE school_id = ? AND attendance_date = ? GROUP BY status',
            [$this->schoolId(), $date]
        );
        $statCounts = [
            'present' => 0,
            'late' => 0,
            'absent' => 0,
            'half_day' => 0,
            'leave' => 0,
            'holiday' => 0,
        ];
        foreach ($stats as $s) {
            if (isset($statCounts[$s['status']])) {
                $statCounts[$s['status']] = (int) $s['cnt'];
            }
        }

        $isSubmitted = count($rows) > 0;
        $totalStaff = $allActiveCount;
        $presentCount = $statCounts['present'];
        $lateCount = $statCounts['late'];
        $absentCount = $statCounts['absent'];
        $halfDayCount = $statCounts['half_day'];
        $leaveCount = $statCounts['leave'];

        $effectiveAttendees = $presentCount + $lateCount + ($halfDayCount * 0.5);
        $rate = $totalStaff > 0 ? (int) round(($effectiveAttendees / $totalStaff) * 100) : 0;

        // Navigation dates
        $prevDate = date('Y-m-d', strtotime($date . ' -1 day'));
        $nextDate = date('Y-m-d', strtotime($date . ' +1 day'));
        $todayDate = date('Y-m-d');

        $this->view('attendance/staff', [
            'title' => 'Staff Attendance',
            'employees' => $employees,
            'existing' => $existing,
            'existingRemarks' => $existingRemarks,
            'date' => $date,
            'prevDate' => $prevDate,
            'nextDate' => $nextDate,
            'todayDate' => $todayDate,
            'departments' => $departments,
            'roles' => $roles,
            'selectedDept' => $selectedDept,
            'selectedRole' => $selectedRole,
            'search' => $search,
            'currentEmployeeId' => Auth::user()['employee_id'] ?? null,
            'isSubmitted' => $isSubmitted,
            'totalStaff' => $totalStaff,
            'presentCount' => $presentCount,
            'lateCount' => $lateCount,
            'absentCount' => $absentCount,
            'halfDayCount' => $halfDayCount,
            'leaveCount' => $leaveCount,
            'rate' => $rate,
        ]);
    }

    public function staffStore(): void
    {
        requirePermission('attendance.staff.mark');
        $this->requireCsrf();
        $date = $_POST['date'] ?? date('Y-m-d');
        $statuses = $_POST['status'] ?? [];
        $remarks = $_POST['remarks'] ?? [];
        try {
            (new AttendanceService())->markStaffAttendance($date, $statuses, $this->userId(), $remarks);
            flash('success', 'Staff attendance saved successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('attendance/staff?date=' . urlencode($date)));
    }

    public function studentReport(): void
    {
        if (\Core\Auth::roleSlug() === 'student') {
            (new StudentPortalController())->attendance();
            return;
        }
        requirePermission('attendance.students.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $classId = (int) ($_GET['class_id'] ?? 0);
        $sectionId = (int) ($_GET['section_id'] ?? 0);
        $rows = [];
        if ($classId && $sectionId) {
            $rows = (new AttendanceService())->classReport($classId, $sectionId, $from, $to);
        }
        $this->view('attendance/student_report', [
            'title' => 'Attendance Report',
            'rows' => $rows,
            'classes' => (new ClassModel())->withSections(),
            'from' => $from,
            'to' => $to,
            'classId' => $classId,
            'sectionId' => $sectionId,
        ]);
    }
}
