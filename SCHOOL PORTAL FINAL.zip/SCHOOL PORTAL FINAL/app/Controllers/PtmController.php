<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class PtmController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS ptm_appointments (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                academic_year_id INT NULL,
                teacher_id INT NOT NULL,
                student_id INT NOT NULL,
                parent_id INT NULL,
                meeting_date DATE NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                virtual_link VARCHAR(255) NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'scheduled',
                notes TEXT NULL,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function index(): void
    {
        requirePermission('appointments.manage');
        $this->initSchema();

        $schoolId = Auth::schoolId();
        
        $teachers = Database::fetchAll("
            SELECT t.id, CONCAT(e.first_name, ' ', e.last_name) as name 
            FROM teachers t 
            INNER JOIN employees e ON e.id = t.employee_id 
            WHERE t.school_id = ? 
            ORDER BY e.first_name ASC
        ", [$schoolId]);
        
        $classes = Database::fetchAll("SELECT id, name FROM classes WHERE school_id = ? ORDER BY id ASC", [$schoolId]);
        
        // Students for frontend selection mapping
        $students = Database::fetchAll("SELECT id, class_id, CONCAT(first_name, ' ', last_name) as name FROM students WHERE school_id = ? AND (status = 'active' OR status = 1) ORDER BY first_name ASC", [$schoolId]);

        $appointments = Database::fetchAll("
            SELECT a.*, 
                   CONCAT(s.first_name, ' ', s.last_name) as student_name,
                   CONCAT(e.first_name, ' ', e.last_name) as teacher_name
            FROM ptm_appointments a
            LEFT JOIN students s ON a.student_id = s.id
            LEFT JOIN teachers t ON a.teacher_id = t.id
            LEFT JOIN employees e ON e.id = t.employee_id
            WHERE a.school_id = ? 
            ORDER BY a.meeting_date DESC, a.start_time DESC
        ", [$schoolId]);

        $this->view('ptm/index', [
            'title' => 'Virtual Parent-Teacher Consultations',
            'teachers' => $teachers,
            'classes' => $classes,
            'students' => $students,
            'appointments' => $appointments
        ]);
    }

    public function bookSlot(): void
    {
        requirePermission('appointments.manage');
        $this->requireCsrf();
        $this->initSchema();
        
        $schoolId = Auth::schoolId();
        
        $teacherId = (int)($_POST['teacher_id'] ?? 0);
        $studentId = (int)($_POST['student_id'] ?? 0);
        $meetingDate = $_POST['meeting_date'] ?? '';
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $notes = trim($_POST['notes'] ?? '');

        if (!$teacherId || !$studentId || !$meetingDate || !$startTime || !$endTime) {
            flash('error', 'All scheduling dimensions are strictly required for binding.');
            redirect(url('ptm/schedule'));
            return;
        }

        // Conflict Validation Rule - Same Virtual Appointment
        $overlapPtm = Database::fetch("
            SELECT id FROM ptm_appointments 
            WHERE school_id = ? AND teacher_id = ? AND meeting_date = ? 
            AND status != 'cancelled'
            AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
        ", [$schoolId, $teacherId, $meetingDate, $startTime, $startTime, $endTime, $endTime]);
        
        if ($overlapPtm) {
            flash('error', 'CRITICAL OVERLAP: The selected educator is already assigned to a virtual session during this temporal block.');
            redirect(url('ptm/schedule'));
            return;
        }

        // Conflict Validation Rule - Timetable Overlap
        $dayOfWeek = date('w', strtotime($meetingDate)); // 0-6
        // Timetable architecture check
        try {
            $overlapTimetable = Database::fetch("
                SELECT id FROM timetable 
                WHERE school_id = ? AND teacher_id = ? AND day_of_week = ? 
                AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
            ", [$schoolId, $teacherId, $dayOfWeek, $startTime, $startTime, $endTime, $endTime]);

            if ($overlapTimetable) {
                flash('warning', 'TIMETABLE CONFLICT: The selected educator has an active academic class schedule mapping during this exact period.');
                redirect(url('ptm/schedule'));
                return;
            }
        } catch (\Throwable $e) {
            // Timetable schema might differ slightly or not exist yet, catch strictly to allow fallback PTM binding
        }

        // Virtual Link Auto-Generation (Cryptographic random room)
        $virtualLink = 'https://meet.schoolportal.local/room/ptm-' . bin2hex(random_bytes(6));

        Database::insert("
            INSERT INTO ptm_appointments (school_id, teacher_id, student_id, meeting_date, start_time, end_time, virtual_link, status, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, NOW())
        ", [$schoolId, $teacherId, $studentId, $meetingDate, $startTime, $endTime, $virtualLink, $notes]);

        // Notification Alert Integration
        // To Teacher
        Database::insert("
            INSERT INTO notifications (school_id, user_id, title, message, type, is_read, created_at)
            VALUES (?, ?, ?, ?, 'ptm_alert', 0, NOW())
        ", [$schoolId, $teacherId, 'Virtual PTM Scheduled', "A new parent-teacher consultation is mapped on {$meetingDate} at {$startTime}."]);

        // To Parent
        $parent = Database::fetch("SELECT parent_id FROM students WHERE id = ? AND school_id = ?", [$studentId, $schoolId]);
        if ($parent && !empty($parent['parent_id'])) {
            Database::insert("
                INSERT INTO notifications (school_id, user_id, title, message, type, is_read, created_at)
                VALUES (?, ?, ?, ?, 'ptm_alert', 0, NOW())
            ", [$schoolId, $parent['parent_id'], 'PTM Scheduled', "Virtual consultation room booked for your child on {$meetingDate} at {$startTime}. Access Link: {$virtualLink}"]);
        }

        flash('success', 'Virtual PTM Slot successfully mapped, verified, and secured.');
        redirect(url('ptm/schedule'));
    }

    public function updateStatus(string $id): void
    {
        requirePermission('appointments.manage');
        $this->requireCsrf();
        
        $schoolId = Auth::schoolId();
        $status = $_POST['status'] ?? 'scheduled';
        
        if (!in_array($status, ['scheduled', 'completed', 'cancelled'])) {
            flash('error', 'Invalid status mapping override.');
            redirect(url('ptm/schedule'));
            return;
        }
        
        Database::execute("UPDATE ptm_appointments SET status = ? WHERE id = ? AND school_id = ?", [$status, (int)$id, $schoolId]);
        
        flash('success', "Consultation execution state successfully mutated to {$status}.");
        redirect(url('ptm/schedule'));
    }
}
