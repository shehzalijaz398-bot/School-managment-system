<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\Employee;
use App\Models\Section;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use App\Services\AttendanceService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class ClassController extends Controller
{
    public function index(): void
    {
        requirePermission('classes.view');
        $this->ensureAcademicSchema();
        $this->view('classes/index', [
            'title' => 'Classes & Sections',
            'classes' => (new ClassModel())->withSections(),
            'subjects' => (new Subject())->all('name ASC'),
        ]);
    }

    public function sections(): void
    {
        requirePermission('classes.view');
        $this->ensureAcademicSchema();
        
        $sections = Database::fetchAll(
            'SELECT s.*, 
                    c.name AS class_name,
                    c.numeric_name AS class_numeric_name,
                    e.first_name AS teacher_first, e.last_name AS teacher_last,
                    (SELECT COUNT(*) FROM students st WHERE st.section_id = s.id AND st.school_id = s.school_id AND st.status IN ("active", "enrolled")) AS student_count
             FROM sections s
             INNER JOIN classes c ON c.id = s.class_id
             LEFT JOIN teachers t ON t.id = s.class_teacher_id
             LEFT JOIN employees e ON e.id = t.employee_id
             WHERE s.school_id = ?
             ORDER BY c.numeric_name ASC, c.name ASC, s.name ASC',
            [$this->schoolId()]
        );

        $classes = (new ClassModel())->all('numeric_name ASC, name ASC');
        $teachers = (new Teacher())->listAll();

        $this->view('academic/sections', [
            'title' => 'Sections',
            'sections' => $sections,
            'classes' => $classes,
            'teachers' => $teachers,
        ]);
    }

    public function subjects(): void
    {
        if (session('user_role') === 'student' || session('role_name') === 'student') {
            (new StudentPortalController())->academics();
            return;
        }
        requirePermission('classes.view');
        $this->ensureAcademicSchema();
        
        $subjects = Database::fetchAll(
            'SELECT s.*, 
                    (SELECT COUNT(DISTINCT cs.class_id) FROM class_subjects cs WHERE cs.subject_id = s.id AND cs.school_id = s.school_id) AS mapped_classes_count
             FROM subjects s
             WHERE s.school_id = ?
             ORDER BY s.name ASC',
            [$this->schoolId()]
        );

        $classes = (new ClassModel())->all('numeric_name ASC, name ASC');

        $this->view('academic/subjects', [
            'title' => 'Subjects',
            'subjects' => $subjects,
            'classes' => $classes,
        ]);
    }

    public function storeClass(): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, ['name' => 'required|max:100']);
        (new ClassModel())->create([
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ''),
            'numeric_name' => (int) ($_POST['numeric_name'] ?? 0),
            'class_teacher_id' => !empty($_POST['class_teacher_id']) ? (int) $_POST['class_teacher_id'] : null,
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : 1,
        ]);
        flash('success', 'Class created successfully.');
        redirect(url('classes'));
    }

    public function editClass(string $id): void
    {
        requirePermission('classes.manage');
        $class = (new ClassModel())->find((int) $id);
        if (!$class || $class['school_id'] !== $this->schoolId()) {
            flash('error', 'Class not found.');
            redirect(url('classes'));
        }
        $sections = Database::fetchAll("SELECT * FROM sections WHERE class_id = ? AND school_id = ? ORDER BY name ASC", [(int)$id, $this->schoolId()]);
        
        $allSubjects = (new Subject())->all('name ASC');
        $classSubjectsRaw = Database::fetchAll("SELECT subject_id FROM class_subjects WHERE class_id = ? AND school_id = ?", [(int)$id, $this->schoolId()]);
        $classSubjectIds = array_column($classSubjectsRaw, 'subject_id');

        $this->view('classes/edit', [
            'title' => 'Edit Class & Sections',
            'class' => $class,
            'sections' => $sections,
            'teachers' => (new Teacher())->listAll(),
            'allSubjects' => $allSubjects,
            'classSubjectIds' => $classSubjectIds,
        ]);
    }

    public function updateClass(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $class = (new ClassModel())->find((int) $id);
        if (!$class || $class['school_id'] !== $this->schoolId()) {
            flash('error', 'Class not found.');
            redirect(url('classes'));
        }

        $data = $this->validate($_POST, ['name' => 'required|max:100']);
        (new ClassModel())->update((int) $id, [
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ($class['code'] ?? '')),
            'numeric_name' => (int) ($_POST['numeric_name'] ?? ($class['numeric_name'] ?? 0)),
            'class_teacher_id' => !empty($_POST['class_teacher_id']) ? (int) $_POST['class_teacher_id'] : ($class['class_teacher_id'] ?? null),
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : (int) ($class['status'] ?? 1),
        ]);

        if (isset($_POST['sections']) && is_array($_POST['sections'])) {
            foreach ($_POST['sections'] as $secId => $secData) {
                // Verify section belongs to this class and school
                $section = (new Section())->find((int) $secId);
                if ($section && $section['class_id'] == $id && $section['school_id'] === $this->schoolId()) {
                    (new Section())->update((int) $secId, [
                        'name' => $secData['name'] ?? $section['name'],
                        'capacity' => (int) ($secData['capacity'] ?? 40),
                        'class_teacher_id' => !empty($secData['class_teacher_id']) ? (int) $secData['class_teacher_id'] : null,
                    ]);
                }
            }
        }

        // Sync subjects
        Database::execute("DELETE FROM class_subjects WHERE class_id = ? AND school_id = ?", [(int)$id, $this->schoolId()]);
        if (!empty($_POST['subject_ids']) && is_array($_POST['subject_ids'])) {
            foreach ($_POST['subject_ids'] as $subId) {
                $subId = (int) $subId;
                if ($subId > 0) {
                    Database::execute("INSERT IGNORE INTO class_subjects (school_id, class_id, subject_id, created_at) VALUES (?, ?, ?, NOW())", [$this->schoolId(), (int)$id, $subId]);
                }
            }
        }

        flash('success', 'Class and Sections updated successfully.');
        redirect(url('classes'));
    }

    public function destroyClass(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $class = (new ClassModel())->find((int) $id);
        if ($class && $class['school_id'] === $this->schoolId()) {
            $studentsCount = (int) (Database::fetch(
                "SELECT COUNT(*) as cnt FROM students WHERE class_id = ? AND school_id = ?",
                [(int) $id, $this->schoolId()]
            )['cnt'] ?? 0);

            if ($studentsCount > 0) {
                flash('error', "Cannot delete {$class['name']} because {$studentsCount} students are currently enrolled in it.");
                redirect(url('classes'));
                return;
            }

            Database::execute("DELETE FROM sections WHERE class_id = ? AND school_id = ?", [(int)$id, $this->schoolId()]);
            Database::execute("DELETE FROM class_subjects WHERE class_id = ? AND school_id = ?", [(int)$id, $this->schoolId()]);
            (new ClassModel())->delete((int) $id);
            flash('success', 'Class deleted successfully.');
        } else {
            flash('error', 'Class not found.');
        }
        redirect(url('classes'));
    }

    public function storeSection(): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'class_id' => 'required|integer',
            'name' => 'required|max:50',
        ]);
        (new Section())->create([
            'class_id' => (int) $data['class_id'],
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ''),
            'capacity' => (int) ($_POST['capacity'] ?? 40),
            'class_teacher_id' => !empty($_POST['class_teacher_id']) ? (int) $_POST['class_teacher_id'] : null,
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : 1,
        ]);
        flash('success', 'Section created successfully.');
        redirect(url('sections'));
    }

    public function editSection(string $id): void
    {
        requirePermission('classes.manage');
        $section = (new Section())->find((int) $id);
        if (!$section || $section['school_id'] !== $this->schoolId()) {
            flash('error', 'Section not found.');
            redirect(url('sections'));
        }
        $this->view('academic/section_edit', [
            'title' => 'Edit Section',
            'section' => $section,
            'classes' => (new ClassModel())->all('name ASC'),
            'teachers' => (new Teacher())->listAll(),
        ]);
    }

    public function updateSection(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $section = (new Section())->find((int) $id);
        if (!$section || (int)$section['school_id'] !== (int)$this->schoolId()) {
            flash('error', 'Section not found.');
            redirect(url('sections'));
            return;
        }

        $data = $this->validate($_POST, [
            'class_id' => 'required|integer',
            'name' => 'required|max:50',
        ]);

        $class = (new ClassModel())->find((int) $data['class_id']);
        if (!$class || (int)$class['school_id'] !== (int)$this->schoolId()) {
            flash('error', 'Invalid class selected.');
            redirect(url('sections'));
            return;
        }

        $teacherId = !empty($_POST['class_teacher_id']) ? (int) $_POST['class_teacher_id'] : null;

        (new Section())->update((int) $id, [
            'class_id' => (int) $data['class_id'],
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ($section['code'] ?? '')),
            'capacity' => (int) ($_POST['capacity'] ?? 40),
            'class_teacher_id' => $teacherId,
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : (int)($section['status'] ?? 1),
        ]);
        auditLog('section.update', 'academic', 'sections', (int) $id);
        flash('success', 'Section updated successfully.');
        redirect(url('sections'));
    }

    public function destroySection(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $section = (new Section())->find((int) $id);
        if ($section && (int)$section['school_id'] === (int)$this->schoolId()) {
            $studentCount = (int) (Database::fetch(
                "SELECT COUNT(*) as cnt FROM students WHERE section_id = ? AND school_id = ?",
                [(int) $id, $this->schoolId()]
            )['cnt'] ?? 0);

            if ($studentCount > 0) {
                flash('error', "Cannot delete section '{$section['name']}' because {$studentCount} students are currently assigned to it.");
                redirect(url('sections'));
                return;
            }

            (new Section())->delete((int) $id);
            flash('success', 'Section deleted successfully.');
        } else {
            flash('error', 'Section not found.');
        }
        redirect(url('sections'));
    }

    public function storeSubject(): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, ['name' => 'required|max:150']);
        (new Subject())->create([
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ''),
            'type' => in_array($_POST['type'] ?? '', ['core', 'elective', 'other']) ? $_POST['type'] : 'core',
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : 1,
        ]);
        flash('success', 'Subject created successfully.');
        redirect(url('subjects'));
    }

    public function updateSubject(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $subject = (new Subject())->find((int) $id);
        if (!$subject || (int)$subject['school_id'] !== (int)$this->schoolId()) {
            flash('error', 'Subject not found.');
            redirect(url('subjects'));
            return;
        }

        $data = $this->validate($_POST, ['name' => 'required|max:150']);
        (new Subject())->update((int) $id, [
            'name' => trim($data['name']),
            'code' => trim($_POST['code'] ?? ($subject['code'] ?? '')),
            'type' => in_array($_POST['type'] ?? '', ['core', 'elective', 'other']) ? $_POST['type'] : ($subject['type'] ?? 'core'),
            'status' => isset($_POST['status']) ? (int) $_POST['status'] : (int)($subject['status'] ?? 1),
        ]);
        flash('success', 'Subject updated successfully.');
        redirect(url('subjects'));
    }

    public function destroySubject(string $id): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $subject = (new Subject())->find((int) $id);
        if ($subject && (int)$subject['school_id'] === (int)$this->schoolId()) {
            $assignmentCount = (int) (Database::fetch(
                "SELECT COUNT(*) as cnt FROM assignments WHERE subject_id = ? AND school_id = ?",
                [(int) $id, $this->schoolId()]
            )['cnt'] ?? 0);

            if ($assignmentCount > 0) {
                flash('error', "Cannot delete subject '{$subject['name']}' because it is linked to {$assignmentCount} assignments.");
                redirect(url('subjects'));
                return;
            }

            Database::execute("DELETE FROM class_subjects WHERE subject_id = ? AND school_id = ?", [(int) $id, $this->schoolId()]);
            Database::execute("DELETE FROM teacher_assignments WHERE subject_id = ? AND school_id = ?", [(int) $id, $this->schoolId()]);
            (new Subject())->delete((int) $id);
            flash('success', 'Subject deleted successfully.');
        } else {
            flash('error', 'Subject not found.');
        }
        redirect(url('subjects'));
    }

    public function storeSubjectAjax(): void
    {
        requirePermission('classes.manage');
        $this->requireCsrf();
        $name = trim($_POST['name'] ?? '');
        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Subject name is required.']);
            exit;
        }

        // Check if exists
        $existing = Database::query("SELECT id FROM subjects WHERE school_id = ? AND name = ?", [$this->schoolId(), $name])->fetch();
        if ($existing) {
            echo json_encode(['success' => true, 'id' => $existing['id'], 'name' => $name]);
            exit;
        }

        $id = (new Subject())->create([
            'name' => $name,
            'type' => 'core',
            'status' => 1,
        ]);

        echo json_encode(['success' => true, 'id' => $id, 'name' => $name]);
        exit;
    }

    private function ensureAcademicSchema(): void
    {
        try {
            Database::execute("
                CREATE TABLE IF NOT EXISTS class_subjects (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    school_id BIGINT UNSIGNED NOT NULL,
                    class_id BIGINT UNSIGNED NOT NULL,
                    subject_id BIGINT UNSIGNED NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY uq_class_subject (school_id, class_id, subject_id),
                    KEY idx_cs_class (class_id),
                    KEY idx_cs_subject (subject_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");

            // Ensure code and class_teacher_id exist on classes
            $classCols = array_column(Database::fetchAll("DESCRIBE classes"), 'Field');
            if (!in_array('code', $classCols, true)) {
                Database::execute("ALTER TABLE classes ADD COLUMN code VARCHAR(50) NULL DEFAULT NULL AFTER name");
            }
            if (!in_array('class_teacher_id', $classCols, true)) {
                Database::execute("ALTER TABLE classes ADD COLUMN class_teacher_id BIGINT UNSIGNED NULL DEFAULT NULL AFTER numeric_name");
            }

            // Ensure code exists on sections
            $secCols = array_column(Database::fetchAll("DESCRIBE sections"), 'Field');
            if (!in_array('code', $secCols, true)) {
                Database::execute("ALTER TABLE sections ADD COLUMN code VARCHAR(50) NULL DEFAULT NULL AFTER name");
            }
        } catch (\Throwable $e) {
            // Already configured or exists
        }
    }
}
