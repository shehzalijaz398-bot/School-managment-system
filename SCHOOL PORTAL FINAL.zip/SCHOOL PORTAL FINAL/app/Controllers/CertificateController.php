<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class CertificateController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $type = trim((string)($_GET['type'] ?? ''));
        $q = trim((string)($_GET['q'] ?? ''));

        // Fetch Certificates
        $sql = 'SELECT c.*, 
                       CASE 
                           WHEN c.recipient_type = "student" THEN CONCAT(s.first_name, " ", s.last_name)
                           ELSE CONCAT(e.first_name, " ", e.last_name)
                       END AS recipient_name,
                       s.admission_no,
                       cl.name AS class_name,
                       sec.name AS section_name,
                       u.name AS issuer_name
                FROM certificates c
                LEFT JOIN students s ON s.id = c.student_id
                LEFT JOIN classes cl ON cl.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN employees e ON e.id = c.employee_id
                LEFT JOIN users u ON u.id = c.issued_by
                WHERE c.school_id = ?';
        $params = [$schoolId];

        if ($type !== '') {
            $sql .= ' AND c.type = ?';
            $params[] = $type;
        }
        if ($q !== '') {
            $sql .= ' AND (c.certificate_no LIKE ? OR c.title LIKE ? OR c.verification_code LIKE ?)';
            $wild = '%' . $q . '%';
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }
        $sql .= ' ORDER BY c.id DESC';
        $certificates = Database::fetchAll($sql, $params);

        // Fetch students & employees for issuance dropdowns
        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.first_name, s.last_name, cl.name as class_name, sec.name as section_name 
             FROM students s 
             LEFT JOIN classes cl ON cl.id = s.class_id 
             LEFT JOIN sections sec ON sec.id = s.section_id 
             WHERE s.school_id = ? ORDER BY s.first_name ASC',
            [$schoolId]
        );

        $employees = Database::fetchAll(
            'SELECT e.id, e.employee_code, e.first_name, e.last_name, des.name as designation 
             FROM employees e 
             LEFT JOIN designations des ON des.id = e.designation_id 
             WHERE e.school_id = ? ORDER BY e.first_name ASC',
            [$schoolId]
        );

        // Stats
        $totalIssued = count($certificates);
        $totalTc = count(array_filter($certificates, fn($c) => $c['type'] === 'transfer'));
        $totalBonafide = count(array_filter($certificates, fn($c) => $c['type'] === 'bonafide'));
        $totalCharacter = count(array_filter($certificates, fn($c) => $c['type'] === 'character'));

        $this->view('certificates/index', [
            'title' => 'Certificates & Documents Generation',
            'certificates' => $certificates,
            'students' => $students,
            'employees' => $employees,
            'stats' => [
                'total' => $totalIssued,
                'tc' => $totalTc,
                'bonafide' => $totalBonafide,
                'character' => $totalCharacter,
            ],
            'filters' => [
                'type' => $type,
                'q' => $q,
            ],
        ]);
    }

    public function generate(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $type = in_array($_POST['type'] ?? '', ['transfer', 'character', 'bonafide', 'experience', 'merit'], true) ? $_POST['type'] : 'bonafide';
        $recipientType = ($_POST['recipient_type'] ?? 'student') === 'staff' ? 'staff' : 'student';
        $studentId = ($recipientType === 'student') ? (int)($_POST['student_id'] ?? 0) : null;
        $employeeId = ($recipientType === 'staff') ? (int)($_POST['employee_id'] ?? 0) : null;
        $title = trim((string)($_POST['title'] ?? ''));
        $content = trim((string)($_POST['content'] ?? ''));
        $issueDate = trim((string)($_POST['issue_date'] ?? date('Y-m-d')));

        if ($recipientType === 'student' && !$studentId) {
            flash('error', 'Please select a student.');
            redirect(url('certificates'));
        }
        if ($recipientType === 'staff' && !$employeeId) {
            flash('error', 'Please select a staff member.');
            redirect(url('certificates'));
        }

        // Generate Prefix and unique certificate number
        $prefix = strtoupper(substr($type, 0, 3));
        $certNo = $prefix . '-' . date('Y') . '-' . str_pad((string)rand(100, 9999), 4, '0', STR_PAD_LEFT);
        $vCode = 'V-' . strtoupper(bin2hex(random_bytes(4)));

        if ($title === '') {
            $title = ucwords(str_replace('_', ' ', $type)) . ' Certificate';
        }

        // If content is empty, generate standard formal template
        if ($content === '') {
            if ($recipientType === 'student') {
                $st = Database::fetch('SELECT s.*, c.name as class_name, sec.name as section_name FROM students s LEFT JOIN classes c ON c.id = s.class_id LEFT JOIN sections sec ON sec.id = s.section_id WHERE s.id = ?', [$studentId]);
                $stName = $st ? ($st['first_name'] . ' ' . $st['last_name']) : 'Student';
                $adm = $st['admission_no'] ?? '';
                $cls = ($st['class_name'] ?? '') . ' ' . ($st['section_name'] ?? '');

                if ($type === 'transfer') {
                    $content = "This is to certify that {$stName}, bearing Admission No. {$adm}, was a regular student of this school in Class {$cls}. All school fee dues have been cleared up to date. His/Her conduct and character during the period of study has been satisfactory. He/She is leaving the school on parent's request.";
                } elseif ($type === 'character') {
                    $content = "This is to certify that {$stName}, Admission No. {$adm}, of Class {$cls}, is known to us as a student of good moral character, disciplined attitude, and polite conduct.";
                } else {
                    $content = "This is to certify that {$stName}, Admission No. {$adm}, is a bonafide student of this institution currently pursuing studies in Class {$cls} for Academic Session " . date('Y') . ".";
                }
            } else {
                $emp = Database::fetch('SELECT e.*, d.name as designation FROM employees e LEFT JOIN designations d ON d.id = e.designation_id WHERE e.id = ?', [$employeeId]);
                $empName = $emp ? ($emp['first_name'] . ' ' . $emp['last_name']) : 'Employee';
                $desig = $emp['designation'] ?? 'Staff Member';
                $joined = $emp['joining_date'] ? date('M d, Y', strtotime($emp['joining_date'])) : 'joining date';
                $content = "This is to certify that {$empName} has been employed with our institution as {$desig} since {$joined}. During their tenure, they have displayed exemplary commitment, professional competence, and positive conduct.";
            }
        }

        $id = Database::insert(
            'INSERT INTO certificates 
             (school_id, certificate_no, type, recipient_type, student_id, employee_id, title, content, issue_date, issued_by, verification_code, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "issued", NOW(), NOW())',
            [$schoolId, $certNo, $type, $recipientType, $studentId, $employeeId, $title, $content, $issueDate, (int)Auth::id(), $vCode]
        );

        flash('success', 'Certificate generated successfully. Certificate No: ' . $certNo);
        redirect(url('certificates/print/' . $id));
    }

    public function print(string $id): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $cert = Database::fetch(
            'SELECT c.*, 
                    CASE 
                        WHEN c.recipient_type = "student" THEN CONCAT(s.first_name, " ", s.last_name)
                        ELSE CONCAT(e.first_name, " ", e.last_name)
                    END AS recipient_name,
                    s.admission_no,
                    s.roll_no,
                    s.date_of_birth,
                    s.gender,
                    cl.name AS class_name,
                    sec.name AS section_name,
                    e.employee_code,
                    des.name as designation,
                    u.name AS issuer_name
             FROM certificates c
             LEFT JOIN students s ON s.id = c.student_id
             LEFT JOIN classes cl ON cl.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             LEFT JOIN employees e ON e.id = c.employee_id
             LEFT JOIN designations des ON des.id = e.designation_id
             LEFT JOIN users u ON u.id = c.issued_by
             WHERE c.id = ? AND c.school_id = ? LIMIT 1',
            [(int)$id, $schoolId]
        );

        if (!$cert) {
            flash('error', 'Certificate not found.');
            redirect(url('certificates'));
        }

        $school = Database::fetch('SELECT * FROM schools WHERE id = ? LIMIT 1', [$schoolId]);

        $this->view('certificates/print', [
            'certificate' => $cert,
            'school' => $school,
        ]);
    }

    public function verify(string $code): void
    {
        $cert = Database::fetch(
            'SELECT c.*, s.name as school_name, s.code as school_code,
                    CASE 
                        WHEN c.recipient_type = "student" THEN CONCAT(st.first_name, " ", st.last_name)
                        ELSE CONCAT(e.first_name, " ", e.last_name)
                    END AS recipient_name
             FROM certificates c
             INNER JOIN schools s ON s.id = c.school_id
             LEFT JOIN students st ON st.id = c.student_id
             LEFT JOIN employees e ON e.id = c.employee_id
             WHERE c.verification_code = ? LIMIT 1',
            [$code]
        );

        $this->view('certificates/verify', [
            'certificate' => $cert,
            'code' => $code,
        ]);
    }
}
