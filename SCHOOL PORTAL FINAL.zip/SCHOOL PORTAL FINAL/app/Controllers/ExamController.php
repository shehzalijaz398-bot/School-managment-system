<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\Exam;
use App\Models\Student;
use App\Models\Subject;
use App\Services\ExamService;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\TenantGuard;

final class ExamController extends Controller
{
    private ExamService $examService;
    private Exam $examModel;

    public function __construct()
    {
        $this->examService = new ExamService();
        $this->examModel = new Exam();
    }

    public function index(): void
    {
        requirePermission('exams.view');
        $schoolId = $this->schoolId();

        $this->view('exams/index', [
            'title' => 'Exams',
            'exams' => $this->examModel->listAll(),
            'types' => Database::fetchAll('SELECT * FROM exam_types WHERE school_id = ? ORDER BY name ASC', [$schoolId]),
            'classes' => (new ClassModel())->all('numeric_name ASC'),
            'subjects' => (new Subject())->all('name ASC'),
        ]);
    }

    public function store(): void
    {
        requirePermission('exams.manage');
        $this->requireCsrf();

        $data = $this->validate($_POST, [
            'name' => 'required|max:191',
            'class_id' => 'required|integer',
        ]);

        try {
            $id = $this->examService->createExam([
                'name' => $data['name'],
                'class_id' => (int) $data['class_id'],
                'academic_year_id' => activeAcademicYearId(),
                'status' => 'scheduled',
            ]);

            flash('success', 'Exam created! Please configure the subject timetable.');
            redirect(url('exams/' . $id . '/timetable'));
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('exams'));
        }
    }

    public function edit(string $id): void
    {
        requirePermission('exams.manage');
        $this->authorizeTenantResource('exams', (int) $id);

        $exam = $this->examModel->findByIdWithDetails((int) $id);
        if (!$exam) {
            flash('error', 'Exam not found.');
            redirect(url('exams'));
            return;
        }

        $this->view('exams/form', [
            'title' => 'Edit Exam',
            'exam' => $exam,
            'types' => Database::fetchAll('SELECT * FROM exam_types WHERE school_id = ? ORDER BY name ASC', [$this->schoolId()]),
            'classes' => (new ClassModel())->all('numeric_name ASC'),
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('exams.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('exams', (int) $id);

        $data = $this->validate($_POST, [
            'name' => 'required|max:191',
            'exam_type_id' => 'required|integer',
            'class_id' => 'required|integer',
            'status' => 'required|in:scheduled,ongoing,completed,published',
        ]);

        try {
            $this->examService->updateExam((int) $id, [
                'name' => $data['name'],
                'exam_type_id' => (int) $data['exam_type_id'],
                'class_id' => (int) $data['class_id'],
                'start_date' => !empty($_POST['start_date']) ? $_POST['start_date'] : null,
                'end_date' => !empty($_POST['end_date']) ? $_POST['end_date'] : null,
                'status' => $data['status'],
            ]);

            flash('success', 'Exam updated successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('exams'));
    }

    public function destroy(string $id): void
    {
        requirePermission('exams.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('exams', (int) $id);

        try {
            $this->examService->deleteExam((int) $id);
            flash('success', 'Exam deleted successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('exams'));
    }

    public function marks(string $id): void
    {
        requirePermission('grades.manage');
        $this->authorizeTenantResource('exams', (int) $id);

        $exam = $this->examModel->find((int) $id);
        if (!$exam) {
            flash('error', 'Exam not found.');
            redirect(url('exams'));
            return;
        }

        $subjects = $this->examModel->subjects((int) $id);
        $examSubjectId = (int) ($_GET['exam_subject_id'] ?? ($subjects[0]['id'] ?? 0));
        $students = (new Student())->list(null, 'active', (int) $exam['class_id']);

        $marks = [];
        if ($examSubjectId > 0) {
            $rows = Database::fetchAll(
                'SELECT student_id, marks_obtained, grade 
                 FROM exam_marks 
                 WHERE school_id = ? AND exam_subject_id = ?',
                [$this->schoolId(), $examSubjectId]
            );
            foreach ($rows as $r) {
                $marks[(int) $r['student_id']] = $r;
            }
        }

        $this->view('exams/marks', [
            'title' => 'Enter Marks',
            'exam' => $exam,
            'subjects' => $subjects,
            'examSubjectId' => $examSubjectId,
            'students' => $students,
            'marks' => $marks,
        ]);
    }

    public function storeMarks(string $id): void
    {
        requirePermission('grades.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('exams', (int) $id);

        $examSubjectId = (int) ($_POST['exam_subject_id'] ?? 0);
        if ($examSubjectId <= 0) {
            flash('error', 'Invalid exam subject.');
            redirect(url('exams/' . $id . '/marks'));
            return;
        }

        try {
            $this->examService->saveMarks($examSubjectId, $_POST['marks'] ?? [], $this->userId());
            flash('success', 'Marks recorded successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('exams/' . $id . '/marks?exam_subject_id=' . $examSubjectId));
    }

    public function reportCard(string $examId, string $studentId): void
    {
        requirePermission('grades.view');
        $this->authorizeTenantResource('exams', (int) $examId);
        $this->authorizeTenantResource('students', (int) $studentId);

        $studentIdInt = (int) $studentId;
        if (isRole('parent')) {
            $parentId = (int) (Auth::user()['parent_id'] ?? 0);
            if (!(new \App\Models\ParentModel())->ownsStudent($parentId, $studentIdInt)) {
                http_response_code(403);
                view('errors/403', ['title' => 'Forbidden']);
                return;
            }
        }

        $result = $this->examService->studentResult((int) $examId, $studentIdInt);
        $student = (new Student())->findDetailed($studentIdInt);
        $exam = $this->examModel->find((int) $examId);
        $insights = $this->examService->compileAcademicInsights((int) $examId, $studentIdInt);

        $this->view('exams/report_card', [
            'title' => 'Report Card',
            'result' => $result,
            'student' => $student,
            'exam' => $exam,
            'insights' => $insights,
        ], 'layouts/print');
    }

    public function timetable(string $id): void
    {
        requirePermission('exams.manage');
        $this->authorizeTenantResource('exams', (int) $id);

        $exam = $this->examModel->find((int) $id);
        if (!$exam) {
            flash('error', 'Exam not found.');
            redirect(url('exams'));
            return;
        }

        $classSubjectsRaw = Database::fetchAll(
            'SELECT s.* FROM subjects s
             INNER JOIN class_subjects cs ON cs.subject_id = s.id AND cs.school_id = s.school_id
             WHERE cs.class_id = ? AND cs.school_id = ?
             ORDER BY s.name ASC',
            [(int) $exam['class_id'], $this->schoolId()]
        );

        $existing = $this->examModel->subjects((int) $id);

        $this->view('exams/timetable', [
            'title' => 'Build Timetable',
            'exam' => $exam,
            'subjects' => $classSubjectsRaw,
            'existing' => $existing,
        ]);
    }

    public function saveTimetable(string $id): void
    {
        requirePermission('exams.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('exams', (int) $id);

        $subjectIds = $_POST['subject_ids'] ?? [];
        $dates = $_POST['dates'] ?? [];
        $maxMarks = $_POST['max_marks'] ?? [];
        $passMarks = $_POST['pass_marks'] ?? [];

        $timetableEntries = [];
        foreach ($subjectIds as $index => $subjectId) {
            if (empty($subjectId) || empty($dates[$index])) {
                continue;
            }

            $timetableEntries[] = [
                'subject_id' => (int) $subjectId,
                'exam_date' => $dates[$index],
                'max_marks' => (float) ($maxMarks[$index] ?? 100),
                'pass_marks' => (float) ($passMarks[$index] ?? 40),
            ];
        }

        try {
            $this->examService->saveTimetable((int) $id, $timetableEntries);
            flash('success', 'Timetable saved successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('exams'));
    }

    public function printTimetable(string $id): void
    {
        requirePermission('exams.view');
        $this->authorizeTenantResource('exams', (int) $id);

        $exam = $this->examModel->find((int) $id);
        if (!$exam) {
            flash('error', 'Exam not found.');
            redirect(url('exams'));
            return;
        }

        $timetable = $this->examModel->subjects((int) $id);
        $school = Database::fetch('SELECT * FROM schools WHERE id = ?', [$this->schoolId()]);

        $this->view('exams/print_timetable', [
            'title' => 'Print Timetable',
            'exam' => $exam,
            'timetable' => $timetable,
            'school' => $school,
        ], 'layouts/print');
    }

    public function analyticsIndex(): void
    {
        requirePermission('exams.manage');
        $schoolId = $this->schoolId();

        $exams = $this->examModel->listAll();
        $classes = (new ClassModel())->all('numeric_name ASC');

        $examId = (int) ($_GET['exam_id'] ?? 0);
        $classId = (int) ($_GET['class_id'] ?? 0);

        $snapshots = [];
        if ($examId > 0 && $classId > 0) {
            $snapshots = $this->examModel->getClassSnapshotResults($examId, $classId);
        }

        $this->view('exams/analytics', [
            'title' => 'Exam Analytics Engine',
            'exams' => $exams,
            'classes' => $classes,
            'examId' => $examId,
            'classId' => $classId,
            'snapshots' => $snapshots,
        ]);
    }

    public function processPositions(): void
    {
        requirePermission('exams.manage');
        $this->requireCsrf();

        $examId = (int) ($_POST['exam_id'] ?? 0);
        $classId = (int) ($_POST['class_id'] ?? 0);

        if ($examId <= 0 || $classId <= 0) {
            flash('error', 'Exam and Class are required.');
            redirect(url('exams/analytics'));
            return;
        }

        $this->authorizeTenantResource('exams', $examId);
        $this->authorizeTenantResource('classes', $classId);

        try {
            $results = $this->examService->calculateClassPositions($examId, $classId);
            flash('success', 'Merit positions generated successfully for ' . count($results) . ' students.');
        } catch (\Throwable $e) {
            flash('error', 'Position generation failed: ' . $e->getMessage());
        }

        redirect(url("exams/analytics?exam_id={$examId}&class_id={$classId}"));
    }

    public function streamReportCard(string $studentId): void
    {
        requirePermission('exams.manage');
        $this->authorizeTenantResource('students', (int) $studentId);

        $examId = (int) ($_GET['exam_id'] ?? 0);
        if ($examId <= 0) {
            flash('error', 'Valid Exam is required.');
            redirect(url('exams/analytics'));
            return;
        }

        $this->authorizeTenantResource('exams', $examId);

        $result = $this->examService->studentResult($examId, (int) $studentId);
        $student = (new Student())->findDetailed((int) $studentId);
        $exam = $this->examModel->find($examId);
        $insights = $this->examService->compileAcademicInsights($examId, (int) $studentId);

        $this->view('exams/report_card', [
            'title' => 'Report Card',
            'result' => $result,
            'student' => $student,
            'exam' => $exam,
            'insights' => $insights,
        ], 'layouts/print');
    }

    public function subjectAnalysis(string $id): void
    {
        requirePermission('grades.view');
        $examId = (int) $id;
        $this->authorizeTenantResource('exams', $examId);

        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        if ($classId) {
            $this->authorizeTenantResource('classes', $classId);
        }

        $analysis = $this->examService->subjectPerformanceAnalysis($examId, $classId);
        $classes = (new \App\Models\ClassModel())->all('numeric_name ASC');

        $this->view('exams/subject_analysis', [
            'title' => 'Subject-Wise Performance Analysis — ' . ($analysis['exam']['name'] ?? 'Exam'),
            'analysis' => $analysis,
            'examId' => $examId,
            'classId' => $classId,
            'classes' => $classes,
        ]);
    }
}
