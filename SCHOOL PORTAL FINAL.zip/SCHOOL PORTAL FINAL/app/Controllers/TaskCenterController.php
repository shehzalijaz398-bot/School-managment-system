<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\TaskReminderService;
use App\Services\WorkflowEngineService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class TaskCenterController extends Controller
{
    private TaskReminderService $taskService;
    private WorkflowEngineService $workflowService;

    public function __construct()
    {
        parent::__construct();
        $this->taskService = new TaskReminderService();
        $this->workflowService = new WorkflowEngineService();
    }

    /**
     * Unified Central Task & Operational Center.
     */
    public function index(): void
    {
        Auth::requireLogin();
        $userId = (int) $this->userId();
        $schoolId = (int) $this->schoolId();

        // Resolve user role slug
        $userRow = Database::fetch(
            'SELECT u.*, r.slug AS role_slug FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.id = ?',
            [$userId]
        );
        $roleSlug = (string) ($userRow['role_slug'] ?? 'user');

        $filterStatus = $_GET['status'] ?? 'all';
        $filterPriority = $_GET['priority'] ?? 'all';

        // 1. User Assigned & Created Tasks
        $tasks = $this->taskService->getUserTasks($schoolId, $userId, [
            'status' => $filterStatus,
            'priority' => $filterPriority,
        ]);
        $summary = $this->taskService->getTaskSummary($schoolId, $userId);

        // 2. Pending Approvals Awaiting this User/Role
        $pendingApprovals = $this->workflowService->listPendingForUser($schoolId, $userId, $roleSlug, 10);

        // 3. Operational Reminders & Deadlines
        $operationalReminders = $this->getOperationalReminders($schoolId, $userId, $roleSlug, (int) ($userRow['employee_id'] ?? 0));

        // 4. Employees for Task Assignment (if authorized to assign)
        $employees = [];
        if (hasPermission('hr.manage') || isRole('admin') || isRole('principal') || isRole('owner')) {
            $employees = Database::fetchAll(
                'SELECT e.id, e.first_name, e.last_name, COALESCE(d.name, "") AS designation 
                 FROM employees e 
                 LEFT JOIN designations d ON d.id = e.designation_id 
                 WHERE e.school_id = ? AND e.status = "active" 
                 ORDER BY e.first_name ASC',
                [$schoolId]
            );
        }

        $this->view('tasks/index', [
            'title' => 'Central Task Center & Action Items',
            'tasks' => $tasks,
            'summary' => $summary,
            'pendingApprovals' => $pendingApprovals,
            'operationalReminders' => $operationalReminders,
            'employees' => $employees,
            'filterStatus' => $filterStatus,
            'filterPriority' => $filterPriority,
            'roleSlug' => $roleSlug,
        ]);
    }

    /**
     * Create a new task.
     */
    public function create(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();

        $userId = (int) $this->userId();
        $schoolId = (int) $this->schoolId();

        $title = trim((string) ($_POST['title'] ?? ''));
        if ($title === '') {
            flash('error', 'Task title is required.');
            back();
            return;
        }

        $assignedTo = (int) ($_POST['assigned_to'] ?? 0);
        // If not assigned to someone else, assign to self employee if available, or first active employee
        if ($assignedTo <= 0) {
            $user = Database::fetch('SELECT employee_id FROM users WHERE id = ?', [$userId]);
            $assignedTo = (int) ($user['employee_id'] ?? 0);
            if ($assignedTo <= 0) {
                $firstEmp = Database::fetch('SELECT id FROM employees WHERE school_id = ? LIMIT 1', [$schoolId]);
                $assignedTo = (int) ($firstEmp['id'] ?? 1);
            }
        }

        $dueDate = !empty($_POST['due_date']) ? (string) $_POST['due_date'] : date('Y-m-d', strtotime('+3 days'));
        $priority = in_array($_POST['priority'] ?? '', ['low', 'medium', 'high', 'urgent'], true)
            ? (string) $_POST['priority']
            : 'medium';

        try {
            $taskId = $this->taskService->createTask($schoolId, $userId, [
                'title' => $title,
                'description' => trim((string) ($_POST['description'] ?? '')),
                'assigned_to' => $assignedTo,
                'due_date' => $dueDate,
                'priority' => $priority,
                'status' => 'pending',
            ]);

            flash('success', "Task #{$taskId} created successfully.");
        } catch (\Throwable $e) {
            flash('error', 'Failed to create task: ' . $e->getMessage());
        }

        redirect(url('tasks'));
    }

    /**
     * Toggle task status (pending -> completed -> pending).
     */
    public function toggle(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $taskId = (int) $id;

        try {
            $res = $this->taskService->toggleTaskStatus($schoolId, $taskId);

            if ($this->isAjax()) {
                $this->json(['success' => true, 'data' => $res]);
                return;
            }

            $st = $res['completed'] ? 'marked as completed' : 're-opened';
            flash('success', "Task #{$taskId} has been {$st}.");
        } catch (\Throwable $e) {
            if ($this->isAjax()) {
                $this->json(['success' => false, 'error' => $e->getMessage()], 422);
                return;
            }
            flash('error', $e->getMessage());
        }

        redirect(url('tasks'));
    }

    /**
     * API: Get current user tasks and pending action items.
     */
    public function apiTasks(): void
    {
        Auth::requireLogin();
        $userId = (int) $this->userId();
        $schoolId = (int) $this->schoolId();

        $userRow = Database::fetch(
            'SELECT u.*, r.slug AS role_slug FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.id = ?',
            [$userId]
        );
        $roleSlug = (string) ($userRow['role_slug'] ?? 'user');

        $tasks = $this->taskService->getUserTasks($schoolId, $userId, ['limit' => 10]);
        $summary = $this->taskService->getTaskSummary($schoolId, $userId);
        $approvals = $this->workflowService->listPendingForUser($schoolId, $userId, $roleSlug, 5);

        $this->json([
            'success' => true,
            'summary' => $summary,
            'tasks' => $tasks,
            'pending_approvals' => $approvals,
        ]);
    }

    /**
     * Helper to compute dynamic role-specific operational reminders.
     */
    private function getOperationalReminders(int $schoolId, int $userId, string $roleSlug, int $employeeId): array
    {
        $reminders = [];

        // Teacher check: unsubmitted attendance for assigned classes
        if ($employeeId > 0) {
            $unmarked = Database::fetchAll(
                'SELECT sec.id, sec.name AS section_name, c.name AS class_name
                 FROM sections sec
                 JOIN classes c ON c.id = sec.class_id
                 JOIN teachers t ON t.id = sec.class_teacher_id
                 WHERE sec.school_id = ? AND t.employee_id = ?
                   AND sec.id NOT IN (
                       SELECT DISTINCT section_id FROM student_attendance
                       WHERE school_id = ? AND attendance_date = CURDATE()
                   )',
                [$schoolId, $employeeId, $schoolId]
            );

            foreach ($unmarked as $u) {
                $reminders[] = [
                    'type' => 'attendance_due',
                    'badge' => 'Attendance',
                    'badge_class' => 'bg-warning-subtle text-warning border border-warning-subtle',
                    'title' => "Mark Today's Attendance: {$u['class_name']} - {$u['section_name']}",
                    'desc' => "Register has not been submitted for today.",
                    'action_url' => url('attendance/students?section_id=' . $u['id']),
                    'action_label' => 'Mark Register',
                ];
            }
        }

        // Administrative / Finance checks
        if (in_array($roleSlug, ['admin', 'super_admin', 'owner', 'principal', 'accountant'], true)) {
            $overdueCount = Database::fetch(
                'SELECT COUNT(*) AS c FROM student_fee_invoices WHERE school_id = ? AND status IN ("unpaid", "partial") AND due_date < CURDATE()',
                [$schoolId]
            );
            $c = (int) ($overdueCount['c'] ?? 0);
            if ($c > 0) {
                $reminders[] = [
                    'type' => 'fee_overdue',
                    'badge' => 'Finance',
                    'badge_class' => 'bg-danger-subtle text-danger border border-danger-subtle',
                    'title' => "{$c} Overdue Student Fee Invoice(s)",
                    'desc' => "Fee notices or payment follow-ups required.",
                    'action_url' => url('finance/invoices?status=overdue'),
                    'action_label' => 'View Invoices',
                ];
            }
        }

        return $reminders;
    }
}
