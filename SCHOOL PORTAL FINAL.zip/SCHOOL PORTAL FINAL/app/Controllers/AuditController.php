<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Admission;
use App\Models\Announcement;
use App\Models\AuditLog;
use App\Models\ClassModel;
use App\Models\LeaveRequest;
use App\Models\Notification;
use App\Models\Teacher;
use App\Models\Timetable;
use App\Models\User;
use App\Services\AdmissionService;
use App\Services\LeaveService;
use App\Services\ReportService;
use App\Services\TimetableService;
use Core\Auth;
use Core\Controller;
use Core\Database;
final class AuditController extends Controller
{
    public function index(): void
    {
        requirePermission('audit.view');
        $module = $_GET['module'] ?? null;
        $this->view('audit/index', [
            'title' => 'Activity Center',
            'logs' => (new AuditLog())->recent(100, $module ?: null),
            'module' => $module,
        ]);
    }
}
