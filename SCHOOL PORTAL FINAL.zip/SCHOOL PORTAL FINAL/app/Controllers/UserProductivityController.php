<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\UserProductivityService;
use Core\Auth;
use Core\Controller;

final class UserProductivityController extends Controller
{
    private UserProductivityService $service;

    public function __construct()
    {
        $this->service = new UserProductivityService();
    }

    /**
     * Web handler: Save widget preferences from Dashboard modal.
     * POST /dashboard/save-widgets
     */
    public function saveDashboardWidgets(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();

        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();
        $widgets = $_POST['widgets'] ?? [];

        $this->service->saveDashboardWidgets($userId, $schoolId, is_array($widgets) ? $widgets : []);

        if ($this->isAjax()) {
            $this->json(['success' => true, 'message' => 'Dashboard widgets updated successfully.']);
            return;
        }

        flash('success', 'Dashboard layout updated successfully.');
        back();
    }

    /**
     * API: Get user preferences.
     * GET /api/v1/user/preferences
     */
    public function getPreferences(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $widgets = $this->service->getDashboardWidgets($userId, $schoolId);
        $recent = $this->service->getRecentRecords($userId, $schoolId);

        $this->json([
            'success' => true,
            'data' => [
                'dashboard_widgets' => $widgets,
                'recent_records' => $recent
            ]
        ]);
    }

    /**
     * API: Save user preferences.
     * POST /api/v1/user/preferences
     */
    public function savePreferences(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;

        if (isset($data['dashboard_widgets']) && is_array($data['dashboard_widgets'])) {
            $this->service->saveDashboardWidgets($userId, $schoolId, $data['dashboard_widgets']);
        }

        if (isset($data['key']) && isset($data['value'])) {
            $this->service->setPreference($userId, $schoolId, (string)$data['key'], is_string($data['value']) ? $data['value'] : json_encode($data['value']));
        }

        $this->json(['success' => true, 'message' => 'Preferences saved successfully.']);
    }

    /**
     * API: Get recent records.
     * GET /api/v1/user/recent-records
     */
    public function getRecentRecords(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $records = $this->service->getRecentRecords($userId, $schoolId);
        $this->json(['success' => true, 'data' => $records]);
    }

    /**
     * API: Record visited item into recent records.
     * POST /api/v1/user/recent-records
     */
    public function addRecentRecord(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;

        if (empty($data['title']) || empty($data['url'])) {
            $this->json(['success' => false, 'error' => 'Title and URL are required.'], 422);
            return;
        }

        $updated = $this->service->addRecentRecord($userId, $schoolId, $data);
        $this->json(['success' => true, 'data' => $updated]);
    }

    /**
     * API: Get saved filters for an entity.
     * GET /api/v1/user/saved-filters
     */
    public function getSavedFilters(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();
        $entity = $_GET['entity'] ?? 'students';

        $filters = $this->service->getSavedFilters($userId, $schoolId, $entity);
        $this->json(['success' => true, 'data' => $filters]);
    }

    /**
     * API: Save filter for an entity.
     * POST /api/v1/user/saved-filters
     */
    public function saveFilter(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;

        $entity = trim((string)($data['entity'] ?? 'students'));
        $name = trim((string)($data['name'] ?? ''));
        $criteria = is_array($data['criteria'] ?? null) ? $data['criteria'] : [];

        if ($name === '') {
            $this->json(['success' => false, 'error' => 'Filter name is required.'], 422);
            return;
        }

        $saved = $this->service->saveFilter($userId, $schoolId, $entity, $name, $criteria);
        $this->json(['success' => true, 'data' => $saved]);
    }

    /**
     * API: Delete saved filter.
     * POST /api/v1/user/saved-filters/delete
     */
    public function deleteFilter(): void
    {
        Auth::requireLogin();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();

        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;
        $entity = trim((string)($data['entity'] ?? 'students'));
        $filterId = trim((string)($data['id'] ?? ''));

        $deleted = $this->service->deleteSavedFilter($userId, $schoolId, $filterId, $entity);
        $this->json(['success' => $deleted]);
    }

    private function isAjax(): bool
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}
