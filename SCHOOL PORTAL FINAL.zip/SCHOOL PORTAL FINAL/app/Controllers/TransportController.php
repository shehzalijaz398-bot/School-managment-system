<?php
declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class TransportController extends Controller
{
    public function index(): void
    {
        requirePermission('transport.view');
        $schoolId = $this->schoolId();

        $vehicles = Database::fetchAll("SELECT * FROM transport_vehicles WHERE school_id = ? ORDER BY vehicle_no", [$schoolId]);
        $drivers = Database::fetchAll("SELECT * FROM transport_drivers WHERE school_id = ? ORDER BY name", [$schoolId]);
        
        $routes = Database::fetchAll(
            "SELECT r.*, v.vehicle_no, d.name AS driver_name, 
            (SELECT COUNT(id) FROM students WHERE transport_route_id = r.id AND status = 'active') AS assigned_students 
            FROM transport_routes r 
            LEFT JOIN transport_vehicles v ON r.vehicle_id = v.id 
            LEFT JOIN transport_drivers d ON r.driver_id = d.id 
            WHERE r.school_id = ? ORDER BY r.title",
            [$schoolId]
        );

        $students = Database::fetchAll(
            "SELECT s.id, s.first_name, s.last_name, s.admission_no, c.name as class_name, sec.name as section_name, r.title as route_title 
            FROM students s 
            LEFT JOIN classes c ON s.class_id = c.id 
            LEFT JOIN sections sec ON s.section_id = sec.id 
            LEFT JOIN transport_routes r ON s.transport_route_id = r.id 
            WHERE s.school_id = ? AND s.status = 'active' ORDER BY s.first_name, s.last_name",
            [$schoolId]
        );

        $this->view('transport/index', [
            'title' => 'Transport Management',
            'vehicles' => $vehicles,
            'drivers' => $drivers,
            'routes' => $routes,
            'students' => $students
        ]);
    }

    public function storeVehicle(): void
    {
        requirePermission('transport.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $data = $this->validate($_POST, [
            'vehicle_no' => 'required|max:50',
            'model' => 'required|max:100',
            'capacity' => 'required|integer',
            'status' => 'required|in:active,inactive,maintenance'
        ]);

        Database::execute(
            "INSERT INTO transport_vehicles (school_id, vehicle_no, model, capacity, status) VALUES (?, ?, ?, ?, ?)",
            [$schoolId, $data['vehicle_no'], $data['model'], (int)$data['capacity'], $data['status']]
        );

        flash('success', 'Vehicle registered successfully.');
        redirect(url('transport'));
    }

    public function storeDriver(): void
    {
        requirePermission('transport.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $data = $this->validate($_POST, [
            'name' => 'required|max:100',
            'phone' => 'required|max:50',
            'license_no' => 'required|max:100',
            'salary' => 'required|numeric',
            'status' => 'required|in:active,inactive'
        ]);

        Database::execute(
            "INSERT INTO transport_drivers (school_id, name, phone, license_no, salary, status) VALUES (?, ?, ?, ?, ?, ?)",
            [$schoolId, $data['name'], $data['phone'], $data['license_no'], (float)$data['salary'], $data['status']]
        );

        flash('success', 'Driver registered successfully.');
        redirect(url('transport'));
    }

    public function storeRoute(): void
    {
        requirePermission('transport.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $data = $this->validate($_POST, [
            'title' => 'required|max:255',
            'start_point' => 'required|max:255',
            'end_point' => 'required|max:255',
            'fare' => 'required|numeric',
            'status' => 'required|in:active,inactive'
        ]);

        $vehicleId = !empty($_POST['vehicle_id']) ? (int)$_POST['vehicle_id'] : null;
        $driverId = !empty($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;

        Database::execute(
            "INSERT INTO transport_routes (school_id, title, start_point, end_point, vehicle_id, driver_id, fare, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [$schoolId, $data['title'], $data['start_point'], $data['end_point'], $vehicleId, $driverId, (float)$data['fare'], $data['status']]
        );

        flash('success', 'Route registered successfully.');
        redirect(url('transport'));
    }

    public function assignStudent(): void
    {
        requirePermission('transport.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $studentId = (int)$_POST['student_id'];
        $routeId = !empty($_POST['transport_route_id']) ? (int)$_POST['transport_route_id'] : null;

        $student = Database::fetch("SELECT id FROM students WHERE id = ? AND school_id = ?", [$studentId, $schoolId]);
        if (!$student) {
            flash('error', 'Student not found.');
            redirect(url('transport'));
            return;
        }

        if ($routeId) {
            $route = Database::fetch("SELECT id FROM transport_routes WHERE id = ? AND school_id = ?", [$routeId, $schoolId]);
            if (!$route) {
                flash('error', 'Route not found.');
                redirect(url('transport'));
                return;
            }
        }

        Database::execute(
            "UPDATE students SET transport_route_id = ? WHERE id = ? AND school_id = ?",
            [$routeId, $studentId, $schoolId]
        );

        flash('success', 'Transport assignment updated.');
        redirect(url('transport'));
    }

    public function logVehicleExpense(int $vehicleId, float $amount, string $type): void
    {
        requirePermission('transport.manage');
        $schoolId = $this->schoolId();

        $vehicle = Database::fetch("SELECT vehicle_no FROM transport_vehicles WHERE id = ? AND school_id = ?", [$vehicleId, $schoolId]);
        
        if ($vehicle) {
            Database::execute(
                "INSERT INTO expenses (school_id, title, category, amount, expense_date, notes, created_by, created_at, updated_at) 
                 VALUES (?, ?, ?, ?, CURDATE(), ?, ?, NOW(), NOW())",
                [
                    $schoolId,
                    "Vehicle Maintenance - {$vehicle['vehicle_no']} ($type)",
                    "Transport",
                    $amount,
                    "System auto-generated transport expense",
                    $this->userId()
                ]
            );
        }
    }
}
