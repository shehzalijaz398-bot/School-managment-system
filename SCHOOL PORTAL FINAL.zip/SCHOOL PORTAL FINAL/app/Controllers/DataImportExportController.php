<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\DataImportExportService;
use Core\Controller;

final class DataImportExportController extends Controller
{
    /**
     * Data Import & Export Console
     */
    public function index(): void
    {
        requirePermission('settings.manage');
        $activeEntity = in_array($_GET['entity'] ?? '', ['students', 'staff', 'classes', 'subjects', 'fees'], true) ? $_GET['entity'] : 'students';

        $schoolId = (int)$this->schoolId();
        $service = new DataImportExportService();
        $def = $service->getEntityDefinition($activeEntity);
        $history = $service->getImportHistory($schoolId, 15);

        $this->view('admin/data/index', [
            'title' => 'Data Import & Export Center',
            'active_entity' => $activeEntity,
            'definition' => $def,
            'history' => $history,
            'preview' => $_SESSION['import_preview'] ?? null
        ]);

        unset($_SESSION['import_preview']);
    }

    /**
     * Download entity CSV template
     */
    public function downloadTemplate(string $entity): void
    {
        requirePermission('settings.manage');
        $validEntities = ['students', 'staff', 'classes', 'subjects', 'fees'];
        if (!in_array($entity, $validEntities, true)) {
            flash('error', 'Invalid entity requested.');
            redirect(url('admin/data'));
            return;
        }

        $service = new DataImportExportService();
        $csvContent = $service->generateCsvTemplate($entity);
        $filename = "template_{$entity}_" . date('Ymd') . ".csv";

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($csvContent));
        header('Cache-Control: no-cache, no-store, must-revalidate');

        echo $csvContent;
        exit;
    }

    /**
     * Preview and validate CSV before import
     */
    public function previewImport(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $entity = in_array($_POST['entity'] ?? '', ['students', 'staff', 'classes', 'subjects', 'fees'], true) ? $_POST['entity'] : 'students';

        if (empty($_FILES['csv_file']['tmp_name']) || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
            flash('error', 'Please choose a valid CSV file to upload.');
            redirect(url("admin/data?entity={$entity}"));
            return;
        }

        $content = file_get_contents($_FILES['csv_file']['tmp_name']);
        if ($content === false || trim($content) === '') {
            flash('error', 'The uploaded file is empty or unreadable.');
            redirect(url("admin/data?entity={$entity}"));
            return;
        }

        $customMapping = [];
        if (!empty($_POST['column_mapping'])) {
            $customMapping = is_array($_POST['column_mapping']) 
                ? $_POST['column_mapping'] 
                : (json_decode((string)$_POST['column_mapping'], true) ?: []);
        }

        $service = new DataImportExportService();
        $preview = $service->parseAndValidateCsv($schoolId, $entity, $content, $customMapping);

        if (!$preview['valid']) {
            flash('error', $preview['error'] ?? 'CSV validation failed.');
            redirect(url("admin/data?entity={$entity}"));
            return;
        }

        $_SESSION['import_preview'] = $preview;
        flash('info', "Scan complete: {$preview['valid_count']} valid rows ready for import, {$preview['duplicate_count']} duplicates detected, {$preview['error_count']} errors found.");
        redirect(url("admin/data?entity={$entity}#preview"));
    }

    /**
     * Safe Rollback of an imported batch
     */
    public function rollback(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();
        $jobId = (int)$id;

        $service = new DataImportExportService();
        $result = $service->rollbackImport($schoolId, $jobId, $userId);

        if ($result['success']) {
            flash('success', $result['message']);
        } else {
            flash('error', $result['error'] ?? 'Rollback failed.');
        }

        redirect(url('admin/data'));
    }

    /**
     * Commit validated import rows in atomic database transaction
     */
    public function commitImport(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();
        $entity = in_array($_POST['entity'] ?? '', ['students', 'staff', 'classes', 'subjects', 'fees'], true) ? $_POST['entity'] : 'students';

        $rawRowsJson = $_POST['valid_rows_json'] ?? '';
        $rows = json_decode($rawRowsJson, true);

        if (empty($rows) || !is_array($rows)) {
            flash('error', 'No valid rows found to commit.');
            redirect(url("admin/data?entity={$entity}"));
            return;
        }

        $service = new DataImportExportService();
        $result = $service->commitImport($schoolId, $entity, $rows, $userId, true);

        if ($result['success']) {
            flash('success', $result['message']);
        } else {
            flash('error', $result['error'] ?? 'Import failed.');
        }

        redirect(url("admin/data?entity={$entity}"));
    }

    /**
     * Export tenant data to CSV stream
     */
    public function exportData(string $entity): void
    {
        requirePermission('settings.manage');
        $validEntities = ['students', 'staff', 'classes', 'subjects', 'fees'];
        if (!in_array($entity, $validEntities, true)) {
            flash('error', 'Invalid export entity requested.');
            redirect(url('admin/data'));
            return;
        }

        $schoolId = (int)$this->schoolId();
        $service = new DataImportExportService();
        $export = $service->exportDataToCsv($schoolId, $entity);

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $export['filename'] . '"');
        header('Content-Length: ' . $export['size_bytes']);
        header('Cache-Control: no-cache, no-store, must-revalidate');

        echo $export['csv_content'];
        exit;
    }
}
