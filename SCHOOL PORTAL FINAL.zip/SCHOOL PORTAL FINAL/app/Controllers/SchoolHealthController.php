<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\CrossModuleIntelligenceService;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

/**
 * SchoolHealthController
 * 
 * Provides an actionable Institutional Health Center & Cross-Module Intelligence Console.
 * Monitors system setup completeness, missing records, cross-module discrepancies,
 * and provides evidence-based remediation recommendations.
 */
final class SchoolHealthController extends Controller
{
    private CrossModuleIntelligenceService $intelligenceService;

    public function __construct()
    {
        parent::__construct();
        $this->intelligenceService = new CrossModuleIntelligenceService();
    }

    /**
     * School Health Center Dashboard for School Administrators.
     * Route: GET /school/health
     */
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int)$this->schoolId();

        $audit = $this->intelligenceService->auditSchool($schoolId);
        $school = Database::fetch('SELECT name, code FROM schools WHERE id = ?', [$schoolId]);

        $this->view('school/health', [
            'title' => 'School Health & Intelligence Center',
            'audit' => $audit,
            'school' => $school,
            'is_platform_view' => false,
        ]);
    }

    /**
     * Real-time JSON health metrics API.
     * Route: GET /api/v1/school/health-metrics
     */
    public function apiHealthMetrics(): void
    {
        if (class_exists('\\Core\\PlatformAuth') && PlatformAuth::check()) {
            $schoolId = isset($_GET['school_id']) ? (int)$_GET['school_id'] : 0;
            if ($schoolId <= 0) {
                $this->json(['error' => 'school_id parameter is required for platform audit.'], 400);
                return;
            }
        } else {
            if (!Auth::check() || !Auth::schoolId()) {
                $this->json(['error' => 'Authentication required.'], 401);
                return;
            }
            $schoolId = (int)Auth::schoolId();
        }

        $audit = $this->intelligenceService->auditSchool($schoolId);
        $this->json($audit, 200);
    }

    /**
     * Super Admin platform view of an individual school's health scorecard.
     * Route: GET /superadmin/schools/{id}/health
     */
    public function platformSchoolHealth(string $id): void
    {
        PlatformAuth::requirePermission('platform.schools.view');
        $schoolId = (int)$id;

        $school = Database::fetch('SELECT id, name, code, subscription_status FROM schools WHERE id = ?', [$schoolId]);
        if (!$school) {
            flash('error', 'Institution not found.');
            redirect(url('superadmin/schools'));
            return;
        }

        $audit = $this->intelligenceService->auditSchool($schoolId);

        $this->view('school/health', [
            'title' => "Health Diagnostics — {$school['name']}",
            'audit' => $audit,
            'school' => $school,
            'is_platform_view' => true,
        ], 'platform/layouts/app');
    }
}
