<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;

final class TimetablePeriodController extends Controller
{
    public function index(): void
    {
        requirePermission('timetable.view');
        
        $periods = Database::fetchAll('SELECT * FROM timetable_periods WHERE school_id = ? ORDER BY period_number', [$this->schoolId()]);
        
        $this->view('timetable/periods', [
            'title' => 'Manage Periods',
            'periods' => $periods
        ]);
    }

    public function store(): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();

        $name = trim($_POST['name'] ?? '');
        $periodNumber = (int)($_POST['period_number'] ?? 0);
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $type = $_POST['type'] ?? 'Regular';

        if (!$name || !$startTime || !$endTime || !$periodNumber) {
            flash('error', 'All fields are required.');
            redirect(url('timetable/periods'));
        }

        Database::insert(
            'INSERT INTO timetable_periods (school_id, name, period_number, start_time, end_time, type, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
            [$this->schoolId(), $name, $periodNumber, $startTime, $endTime, $type]
        );

        flash('success', 'Period created successfully.');
        redirect(url('timetable/periods'));
    }

    public function update(string $id): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();

        $name = trim($_POST['name'] ?? '');
        $periodNumber = (int)($_POST['period_number'] ?? 0);
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $type = $_POST['type'] ?? 'Regular';

        Database::execute(
            'UPDATE timetable_periods SET name = ?, period_number = ?, start_time = ?, end_time = ?, type = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$name, $periodNumber, $startTime, $endTime, $type, (int)$id, $this->schoolId()]
        );

        flash('success', 'Period updated successfully.');
        redirect(url('timetable/periods'));
    }

    public function destroy(string $id): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();

        Database::execute('DELETE FROM timetable_periods WHERE id = ? AND school_id = ?', [(int)$id, $this->schoolId()]);
        flash('success', 'Period deleted successfully.');
        redirect(url('timetable/periods'));
    }
}
