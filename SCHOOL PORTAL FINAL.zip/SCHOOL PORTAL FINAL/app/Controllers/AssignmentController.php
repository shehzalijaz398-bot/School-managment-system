<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Assignment;
use App\Models\ClassModel;
use App\Models\ParentModel;
use App\Models\Section;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use App\Services\AssignmentService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class AssignmentController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $role = Auth::roleSlug();

        if ($role === 'student') {
            redirect(url('portal/assignments'));
        }
        if ($role === 'parent') {
            redirect(url('parent/assignments'));
        }

        requirePermission('assignments.view');

        $schoolId = (int) $this->schoolId();
        $teacherId = null;
        $teacher = null;
        if (isRole('teacher')) {
            $teacher = (new Teacher())->findByUserId((int) Auth::id());
            $teacherId = $teacher ? (int) $teacher['id'] : 0;
        }

        $assignmentModel = new Assignment();

        $filters = [
            'class_id' => (int) ($_GET['class_id'] ?? 0),
            'section_id' => (int) ($_GET['section_id'] ?? 0),
            'subject_id' => (int) ($_GET['subject_id'] ?? 0),
            'status' => trim((string) ($_GET['status'] ?? '')),
            'date' => trim((string) ($_GET['date'] ?? '')),
            'q' => trim((string) ($_GET['q'] ?? '')),
        ];

        $assignments = $assignmentModel->listForSchool($teacherId, $filters);
        $stats = $assignmentModel->getStats($teacherId);

        $classes = (new ClassModel())->withSections();
        $subjects = (new Subject())->all('name ASC');

        $this->view('assignments/index', [
            'title' => 'Home Tasks & Daily Diary',
            'assignments' => $assignments,
            'stats' => $stats,
            'classes' => $classes,
            'subjects' => $subjects,
            'filters' => $filters,
            'isTeacher' => isRole('teacher'),
            'teacher' => $teacher,
        ]);
    }

    public function create(): void
    {
        requirePermission('assignments.create');
        $schoolId = (int) $this->schoolId();

        $classes = (new ClassModel())->withSections();
        $subjects = (new Subject())->all('name ASC');

        // Map class_id to assigned subjects
        $classSubjectsRaw = Database::fetchAll("SELECT class_id, subject_id FROM class_subjects WHERE school_id = ?", [$schoolId]);
        $classSubjectsMap = [];
        foreach ($classSubjectsRaw as $row) {
            $classSubjectsMap[(int)$row['class_id']][] = (int)$row['subject_id'];
        }

        $mode = $_GET['mode'] ?? 'diary';

        $this->view('assignments/form', [
            'title' => ($mode === 'assignment') ? 'Create Graded Assignment' : 'Post Daily School Diary (Home Tasks)',
            'mode' => $mode,
            'classes' => $classes,
            'subjects' => $subjects,
            'classSubjectsMap' => $classSubjectsMap,
        ]);
    }

    public function store(): void
    {
        requirePermission('assignments.create');
        $this->requireCsrf();

        $schoolId = (int) $this->schoolId();
        $teacher = (new Teacher())->findByUserId((int) Auth::id());
        $teacherId = $teacher ? (int)$teacher['id'] : 0;
        $service = new AssignmentService();

        $mode = $_POST['mode'] ?? 'diary';

        if ($mode === 'assignment') {
            // Single Graded Assignment / Project
            $classId = (int) ($_POST['class_id'] ?? 0);
            $sectionId = (int) ($_POST['section_id'] ?? 0);
            $subjectId = (int) ($_POST['subject_id'] ?? 0);
            $title = trim((string) ($_POST['title'] ?? ''));
            $dueDate = trim((string) ($_POST['due_date'] ?? ''));

            if (!$classId || !$sectionId || !$subjectId || !$title || !$dueDate) {
                flash('error', 'Please fill in all required fields (Class, Section, Subject, Title, Due Date).');
                redirect(url('assignments/create?mode=assignment'));
            }

            $attachmentPath = null;
            if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                try {
                    $attachmentPath = upload_file($_FILES['attachment'], 'assignments', [
                        'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/zip', 'text/plain'
                    ]);
                } catch (\Throwable $e) {
                    flash('error', 'Attachment upload failed: ' . $e->getMessage());
                    redirect(url('assignments/create?mode=assignment'));
                }
            }

            try {
                $service->create($teacherId, [
                    'class_id' => $classId,
                    'section_id' => $sectionId,
                    'subject_id' => $subjectId,
                    'title' => $title,
                    'description' => $_POST['description'] ?? null,
                    'assigned_date' => $_POST['assigned_date'] ?? date('Y-m-d'),
                    'due_date' => $dueDate,
                    'max_marks' => (float) ($_POST['max_marks'] ?? 100),
                    'attachment' => $attachmentPath,
                    'status' => $_POST['status'] ?? 'published',
                ]);
                flash('success', 'Assignment published successfully!');
            } catch (\Throwable $e) {
                flash('error', $e->getMessage());
            }

            redirect(url('assignments'));
        }

        // Daily Diary Batch Submission
        $classId = (int) ($_POST['class_id'] ?? 0);
        $sectionId = (int) ($_POST['section_id'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');
        $tasks = $_POST['tasks'] ?? [];

        if (!$classId || !$sectionId) {
            flash('error', 'Class and Section are required.');
            redirect(url('assignments/create'));
        }

        try {
            $count = $service->createDailyDiary($teacherId, $classId, $sectionId, $date, $tasks);
            if ($count > 0) {
                flash('success', "Daily Diary published successfully for {$count} subjects.");
            } else {
                flash('error', 'No tasks were entered. Diary was not created.');
            }
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('assignments'));
    }

    public function show(string $id): void
    {
        requirePermission('assignments.view');
        $this->authorizeTenantResource('assignments', (int) $id);
        $schoolId = (int) $this->schoolId();

        $assignment = Database::fetch(
            'SELECT a.*, c.name AS class_name, sec.name AS section_name, s.name AS subject_name,
                    CONCAT(e.first_name, " ", e.last_name) AS teacher_name
             FROM assignments a
             INNER JOIN classes c ON c.id = a.class_id
             INNER JOIN sections sec ON sec.id = a.section_id
             INNER JOIN subjects s ON s.id = a.subject_id
             LEFT JOIN teachers t ON t.id = a.teacher_id
             LEFT JOIN employees e ON e.id = t.employee_id
             WHERE a.id = ? AND a.school_id = ? LIMIT 1',
            [(int) $id, $schoolId]
        );

        if (!$assignment) {
            flash('error', 'Assignment not found.');
            redirect(url('assignments'));
        }

        $submissions = (new Assignment())->submissions((int) $id);

        $totalStudents = count($submissions);
        $submittedCount = count(array_filter($submissions, fn($s) => in_array($s['submission_status'], ['submitted', 'graded', 'late'], true)));
        $gradedCount = count(array_filter($submissions, fn($s) => $s['submission_status'] === 'graded'));
        $pendingCount = $totalStudents - $submittedCount;

        $this->view('assignments/show', [
            'title' => $assignment['title'],
            'assignment' => $assignment,
            'submissions' => $submissions,
            'stats' => [
                'total' => $totalStudents,
                'submitted' => $submittedCount,
                'graded' => $gradedCount,
                'pending' => $pendingCount,
            ]
        ]);
    }

    public function grade(string $id): void
    {
        requirePermission('assignments.grade');
        $this->requireCsrf();

        try {
            (new AssignmentService())->grade(
                (int) $id,
                (float) $_POST['marks'],
                $_POST['teacher_comment'] ?? null
            );
            flash('success', 'Submission graded successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        back();
    }

    public function edit(string $id): void
    {
        requirePermission('assignments.manage');
        $this->authorizeTenantResource('assignments', (int) $id);
        $schoolId = (int) $this->schoolId();

        $assignment = Database::fetch(
            'SELECT a.*, c.name AS class_name, sec.name AS section_name, s.name AS subject_name 
             FROM assignments a
             INNER JOIN classes c ON c.id = a.class_id
             INNER JOIN sections sec ON sec.id = a.section_id
             INNER JOIN subjects s ON s.id = a.subject_id
             WHERE a.id = ? AND a.school_id = ? LIMIT 1',
            [(int) $id, $schoolId]
        );

        if (!$assignment) {
            flash('error', 'Assignment not found.');
            redirect(url('assignments'));
        }

        $classes = (new ClassModel())->withSections();
        $subjects = (new Subject())->all('name ASC');

        $this->view('assignments/form_edit', [
            'title' => 'Edit Assignment: ' . $assignment['title'],
            'assignment' => $assignment,
            'classes' => $classes,
            'subjects' => $subjects,
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('assignments.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('assignments', (int) $id);

        $schoolId = (int) $this->schoolId();
        $assignment = Database::fetch('SELECT * FROM assignments WHERE id = ? AND school_id = ? LIMIT 1', [(int) $id, $schoolId]);
        if (!$assignment) {
            flash('error', 'Assignment not found.');
            redirect(url('assignments'));
        }

        $title = trim((string) ($_POST['title'] ?? ''));
        $dueDate = trim((string) ($_POST['due_date'] ?? ''));
        $assignedDate = trim((string) ($_POST['assigned_date'] ?? $assignment['assigned_date']));
        $maxMarks = (float) ($_POST['max_marks'] ?? 0);
        $status = $_POST['status'] ?? 'published';
        $description = $_POST['description'] ?? null;
        $classId = (int) ($_POST['class_id'] ?? $assignment['class_id']);
        $sectionId = (int) ($_POST['section_id'] ?? $assignment['section_id']);
        $subjectId = (int) ($_POST['subject_id'] ?? $assignment['subject_id']);

        if (!$title || !$dueDate) {
            flash('error', 'Title and Due Date are required.');
            redirect(url('assignments/' . $id . '/edit'));
        }

        $attachmentPath = $assignment['attachment'];
        if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            try {
                $attachmentPath = upload_file($_FILES['attachment'], 'assignments', [
                    'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'application/zip', 'text/plain'
                ]);
            } catch (\Throwable $e) {
                flash('error', 'Attachment upload failed: ' . $e->getMessage());
                redirect(url('assignments/' . $id . '/edit'));
            }
        }

        Database::execute(
            'UPDATE assignments 
             SET title = ?, description = ?, assigned_date = ?, due_date = ?, max_marks = ?, status = ?, attachment = ?, class_id = ?, section_id = ?, subject_id = ?, updated_at = NOW()
             WHERE id = ? AND school_id = ?',
            [$title, $description, $assignedDate, $dueDate, $maxMarks, $status, $attachmentPath, $classId, $sectionId, $subjectId, (int) $id, $schoolId]
        );

        auditLog('assignment.update', 'assignments', 'assignments', (int) $id);
        flash('success', 'Assignment updated successfully.');
        redirect(url('assignments'));
    }

    public function destroy(string $id): void
    {
        requirePermission('assignments.manage');
        $this->requireCsrf();
        $this->authorizeTenantResource('assignments', (int) $id);

        $schoolId = (int) $this->schoolId();
        $assignment = Database::fetch('SELECT * FROM assignments WHERE id = ? AND school_id = ? LIMIT 1', [(int) $id, $schoolId]);
        if (!$assignment) {
            flash('error', 'Assignment not found.');
            redirect(url('assignments'));
        }

        // Delete submissions and attached files
        $submissions = Database::fetchAll('SELECT attachment FROM assignment_submissions WHERE assignment_id = ?', [(int) $id]);
        foreach ($submissions as $sub) {
            if (!empty($sub['attachment'])) {
                $f = public_path($sub['attachment']);
                if (file_exists($f)) {
                    @unlink($f);
                }
            }
        }
        Database::execute('DELETE FROM assignment_submissions WHERE assignment_id = ?', [(int) $id]);

        // Delete assignment attachment if exists
        if (!empty($assignment['attachment'])) {
            $f = public_path($assignment['attachment']);
            if (file_exists($f)) {
                @unlink($f);
            }
        }

        Database::execute('DELETE FROM assignments WHERE id = ? AND school_id = ?', [(int) $id, $schoolId]);

        auditLog('assignment.delete', 'assignments', 'assignments', (int) $id);
        flash('success', 'Assignment/task deleted successfully.');
        redirect(url('assignments'));
    }

    public function portalAssignments(): void
    {
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();
        $schoolId = (int) $this->schoolId();

        $student = null;
        $children = [];
        $selectedStudentId = 0;

        if ($role === 'parent') {
            $parentId = (int) ($user['parent_id'] ?? 0);
            if (!$parentId && !empty($user['email'])) {
                $pRow = Database::fetch('SELECT id FROM parents WHERE email = ? AND school_id = ? LIMIT 1', [$user['email'], $schoolId]);
                $parentId = (int) ($pRow['id'] ?? 0);
            }
            $children = (new ParentModel())->children($parentId);
            $selectedStudentId = (int) ($_GET['student_id'] ?? ($_SESSION['selected_student_id'] ?? ($children[0]['id'] ?? 0)));

            if ($selectedStudentId) {
                $_SESSION['selected_student_id'] = $selectedStudentId;
                $student = Database::fetch(
                    'SELECT s.*, c.name AS class_name, sec.name AS section_name 
                     FROM students s
                     LEFT JOIN classes c ON c.id = s.class_id
                     LEFT JOIN sections sec ON sec.id = s.section_id
                     WHERE s.id = ? AND s.school_id = ? LIMIT 1',
                    [$selectedStudentId, $schoolId]
                );
            }
        } else {
            // Student
            $student = Database::fetch(
                'SELECT s.*, c.name AS class_name, sec.name AS section_name 
                 FROM students s
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 WHERE s.user_id = ? AND s.school_id = ? LIMIT 1',
                [Auth::id(), $schoolId]
            );
            $selectedStudentId = (int) ($student['id'] ?? 0);
        }

        if (!$student) {
            flash('error', 'Student profile not linked to this account.');
            redirect(url('dashboard'));
        }

        $activeTab = $_GET['tab'] ?? 'diary';
        $filterStatus = $_GET['status'] ?? null;
        $selectedDate = $_GET['date'] ?? date('Y-m-d');

        $assignmentModel = new Assignment();
        $assignments = $assignmentModel->forStudent($selectedStudentId, $filterStatus ?: null);

        // Group into Daily Diary tasks vs Graded Projects
        $diaryTasks = array_filter($assignments, fn($a) => (float)$a['max_marks'] == 0 || str_starts_with($a['title'], 'Daily Task') || str_starts_with($a['title'], 'Home Task'));
        $projectAssignments = array_filter($assignments, fn($a) => (float)$a['max_marks'] > 0);

        // Stats
        $pendingCount = count(array_filter($projectAssignments, fn($a) => in_array($a['submission_status'], ['pending', null], true)));
        $submittedCount = count(array_filter($projectAssignments, fn($a) => in_array($a['submission_status'], ['submitted', 'late'], true)));
        $gradedCount = count(array_filter($projectAssignments, fn($a) => $a['submission_status'] === 'graded'));

        $this->view('portal/student_assignments', [
            'title' => 'Home Tasks & Daily Diary',
            'isParent' => ($role === 'parent'),
            'student' => $student,
            'children' => $children,
            'selectedStudentId' => $selectedStudentId,
            'activeTab' => $activeTab,
            'selectedDate' => $selectedDate,
            'diaryTasks' => $diaryTasks,
            'projectAssignments' => $projectAssignments,
            'allAssignments' => $assignments,
            'stats' => [
                'total' => count($projectAssignments),
                'pending' => $pendingCount,
                'submitted' => $submittedCount,
                'graded' => $gradedCount,
            ]
        ]);
    }

    public function submitWork(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $role = Auth::roleSlug();
        $schoolId = (int) $this->schoolId();

        $studentId = (int) ($_POST['student_id'] ?? 0);
        if (!$studentId && $role === 'student') {
            $st = Database::fetch('SELECT id FROM students WHERE user_id = ? AND school_id = ? LIMIT 1', [Auth::id(), $schoolId]);
            $studentId = (int) ($st['id'] ?? 0);
        }

        if (!$studentId) {
            flash('error', 'Student profile could not be identified.');
            back();
        }

        $content = trim((string) ($_POST['content'] ?? ''));
        $attachmentPath = null;

        if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            try {
                $attachmentPath = upload_file($_FILES['attachment'], 'submissions', [
                    'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'text/plain', 'application/zip'
                ]);
            } catch (\Throwable $e) {
                flash('error', 'Upload failed: ' . $e->getMessage());
                back();
            }
        }

        if ($content === '' && !$attachmentPath) {
            flash('error', 'Please provide either written content or an uploaded document.');
            back();
        }

        try {
            (new AssignmentService())->submitStudentWork((int) $id, $studentId, $content, $attachmentPath);
            flash('success', 'Homework submitted successfully! Your teacher has been notified.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        back();
    }
}
