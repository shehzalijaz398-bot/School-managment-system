<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\IntegrationService;
use Core\ApiContext;
use Core\Database;

final class SchoolOperationsApiController
{
    /**
     * Standard JSON responder helper
     */
    private function respond(int $statusCode, array $payload): void
    {
        if (!headers_sent()) {
            http_response_code($statusCode);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    /**
     * GET /api/v1/students
     * Scoped list of students with pagination and class filters
     */
    public function listStudents(): void
    {
        $tenantId = ApiContext::tenantId();
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = max(5, min(100, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;

        $sql = "
            SELECT s.id, s.school_id, s.admission_no, s.roll_no, s.first_name, s.last_name,
                   s.gender, s.date_of_birth, s.phone, s.status, s.admission_date,
                   c.name AS class_name, sec.name AS section_name
            FROM students s
            LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
            LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
            WHERE s.school_id = ?
        ";
        $params = [$tenantId];

        if (!empty($_GET['class_id'])) {
            $sql .= " AND s.class_id = ?";
            $params[] = (int)$_GET['class_id'];
        }

        if (!empty($_GET['search'])) {
            $sql .= " AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ?)";
            $q = '%' . trim($_GET['search']) . '%';
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $totalRow = Database::fetch(str_replace("s.id, s.school_id, s.admission_no, s.roll_no, s.first_name, s.last_name,
                   s.gender, s.date_of_birth, s.phone, s.status, s.admission_date,
                   c.name AS class_name, sec.name AS section_name", "COUNT(*) as c", $sql), $params);
        $total = (int)($totalRow['c'] ?? 0);

        $sql .= " ORDER BY s.id DESC LIMIT {$limit} OFFSET {$offset}";
        $items = Database::fetchAll($sql, $params);

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => $items,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => max(1, (int)ceil($total / $limit))
            ]
        ]);
    }

    /**
     * POST /api/v1/students
     * Create student with schema validation and webhook dispatch
     */
    public function createStudent(): void
    {
        $tenantId = ApiContext::tenantId();
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;

        $firstName = trim((string)($data['first_name'] ?? ''));
        $lastName = trim((string)($data['last_name'] ?? ''));
        $gender = strtolower(trim((string)($data['gender'] ?? 'other')));
        $classId = !empty($data['class_id']) ? (int)$data['class_id'] : null;
        $sectionId = !empty($data['section_id']) ? (int)$data['section_id'] : null;

        if ($firstName === '') {
            $this->respond(422, [
                'success' => false,
                'status' => 422,
                'error' => ['code' => 'VALIDATION_FAILED', 'message' => 'The first_name field is required.']
            ]);
            return;
        }

        $admNo = !empty($data['admission_no']) ? trim($data['admission_no']) : 'ADM-' . date('Y') . '-' . sprintf('%04d', random_int(1000, 9999));

        // Check duplicate admission_no for tenant
        $exists = Database::fetch("SELECT id FROM students WHERE school_id = ? AND admission_no = ? LIMIT 1", [$tenantId, $admNo]);
        if ($exists) {
            $this->respond(409, [
                'success' => false,
                'status' => 409,
                'error' => ['code' => 'DUPLICATE_RECORD', 'message' => "A student with admission_no '{$admNo}' already exists in this school."]
            ]);
            return;
        }

        $id = Database::insert("
            INSERT INTO students (school_id, class_id, section_id, admission_no, first_name, last_name, gender, status, admission_date, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'active', CURDATE(), NOW(), NOW())
        ", [$tenantId, $classId, $sectionId, $admNo, $firstName, $lastName, $gender]);

        // Dispatch Webhook Event
        (new IntegrationService())->dispatchWebhookEvent($tenantId, 'student.admitted', [
            'student_id' => $id,
            'admission_no' => $admNo,
            'name' => "{$firstName} {$lastName}",
            'admitted_at' => date('Y-m-d H:i:s')
        ]);

        $this->respond(201, [
            'success' => true,
            'status' => 201,
            'data' => [
                'student_id' => $id,
                'admission_no' => $admNo,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'status' => 'active'
            ]
        ]);
    }

    /**
     * GET /api/v1/attendance
     * Query tenant attendance records with date filters
     */
    public function queryAttendance(): void
    {
        $tenantId = ApiContext::tenantId();
        $date = !empty($_GET['date']) ? date('Y-m-d', strtotime((string)$_GET['date'])) : date('Y-m-d');

        $rows = Database::fetchAll("
            SELECT a.id, a.student_id, s.admission_no, s.first_name, s.last_name,
                   c.name AS class_name, a.status, a.attendance_date AS date, a.remarks
            FROM student_attendance a
            INNER JOIN students s ON s.id = a.student_id AND s.school_id = a.school_id
            LEFT JOIN classes c ON c.id = a.class_id
            WHERE a.school_id = ? AND a.attendance_date = ?
            ORDER BY s.first_name ASC
        ", [$tenantId, $date]);

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'date' => $date,
            'total' => count($rows),
            'data' => $rows
        ]);
    }

    /**
     * POST /api/v1/attendance
     * Record student attendance with duplicate prevention
     */
    public function recordAttendance(): void
    {
        $tenantId = ApiContext::tenantId();
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: $_POST;

        $studentId = (int)($data['student_id'] ?? 0);
        $status = strtolower(trim((string)($data['status'] ?? 'present')));
        $date = !empty($data['date']) ? date('Y-m-d', strtotime((string)$data['date'])) : date('Y-m-d');
        $remarks = trim((string)($data['remarks'] ?? 'API logged'));

        if ($studentId <= 0 || !in_array($status, ['present', 'absent', 'late', 'excused'], true)) {
            $this->respond(422, [
                'success' => false,
                'status' => 422,
                'error' => ['code' => 'INVALID_PAYLOAD', 'message' => 'Valid student_id and status (present, absent, late, excused) required.']
            ]);
            return;
        }

        // Verify student belongs to this tenant
        $stu = Database::fetch("SELECT id, admission_no, first_name, last_name, class_id, section_id FROM students WHERE id = ? AND school_id = ? LIMIT 1", [$studentId, $tenantId]);
        if (!$stu) {
            $this->respond(404, [
                'success' => false,
                'status' => 404,
                'error' => ['code' => 'STUDENT_NOT_FOUND', 'message' => 'Student not found in this institution.']
            ]);
            return;
        }

        // Upsert attendance
        $existing = Database::fetch("SELECT id FROM student_attendance WHERE school_id = ? AND student_id = ? AND attendance_date = ? LIMIT 1", [$tenantId, $studentId, $date]);
        if ($existing) {
            Database::execute("UPDATE student_attendance SET status = ?, remarks = ?, updated_at = NOW() WHERE id = ?", [$status, $remarks, (int)$existing['id']]);
            $attendanceId = (int)$existing['id'];
        } else {
            $attendanceId = Database::insert("
                INSERT INTO student_attendance (school_id, student_id, class_id, section_id, status, attendance_date, remarks, marked_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW())
            ", [$tenantId, $studentId, $stu['class_id'], $stu['section_id'], $status, $date, $remarks]);
        }

        // Dispatch Webhook Event
        (new IntegrationService())->dispatchWebhookEvent($tenantId, 'attendance.marked', [
            'student_id' => $studentId,
            'admission_no' => $stu['admission_no'],
            'student_name' => "{$stu['first_name']} {$stu['last_name']}",
            'date' => $date,
            'status' => $status
        ]);

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => [
                'attendance_id' => $attendanceId,
                'student_id' => $studentId,
                'date' => $date,
                'status' => $status
            ]
        ]);
    }

    /**
     * GET /api/v1/finance/invoices
     * Query tenant fee invoices
     */
    public function listInvoices(): void
    {
        $tenantId = ApiContext::tenantId();
        $status = $_GET['status'] ?? 'all';

        $sql = "
            SELECT fi.id, fi.invoice_no AS invoice_number, fi.student_id, s.admission_no, s.first_name, s.last_name,
                   fi.title, fi.total_amount, fi.paid_amount, (fi.total_amount - fi.paid_amount) AS balance,
                   fi.status, fi.due_date, fi.created_at
            FROM student_fee_invoices fi
            INNER JOIN students s ON s.id = fi.student_id AND s.school_id = fi.school_id
            WHERE fi.school_id = ?
        ";
        $params = [$tenantId];

        if ($status !== 'all') {
            $sql .= " AND fi.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY fi.id DESC LIMIT 50";
        $rows = Database::fetchAll($sql, $params);

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'total' => count($rows),
            'data' => $rows
        ]);
    }

    /**
     * GET /api/v1/exams/results
     * Query exam results
     */
    public function examResults(): void
    {
        $tenantId = ApiContext::tenantId();
        $examId = !empty($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;

        $sql = "
            SELECT er.id, er.exam_id, e.name AS exam_title, er.student_id, s.admission_no,
                   s.first_name, s.last_name, sub.name AS subject_name, sub.code AS subject_code,
                   er.marks_obtained, es.max_marks AS total_marks, er.grade
            FROM exam_marks er
            INNER JOIN exams e ON e.id = er.exam_id AND e.school_id = ?
            INNER JOIN students s ON s.id = er.student_id AND s.school_id = ?
            LEFT JOIN exam_subjects es ON es.id = er.exam_subject_id
            LEFT JOIN subjects sub ON sub.id = es.subject_id
            WHERE er.school_id = ?
        ";
        $params = [$tenantId, $tenantId, $tenantId];

        if ($examId > 0) {
            $sql .= " AND er.exam_id = ?";
            $params[] = $examId;
        }

        $sql .= " ORDER BY er.id DESC LIMIT 100";
        $rows = Database::fetchAll($sql, $params);

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'total' => count($rows),
            'data' => $rows
        ]);
    }
}
