<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\AiAnalyticsService;
use Core\Controller;
use Core\TenantGuard;

/**
 * AiAnalyticsController
 * Secure REST API controller for Machine Learning tensor pipelines and student intelligence.
 */
final class AiAnalyticsController extends Controller
{
    /**
     * GET /api/v1/analytics/student-ml-dataset/{id}
     * Returns a normalized multi-dimensional ML dataset for predictive models.
     */
    public function studentMlDataset(string $id): void
    {
        $studentId = (int) $id;
        $schoolId = $this->schoolId();

        // Strict Tenant Isolation Guard: Prevents IDOR and cross-school data leak
        $student = $this->authorizeTenantResource('students', $studentId);

        try {
            $service = new AiAnalyticsService();
            $dataset = $service->compileStudentDataset($schoolId, $studentId);

            $this->json($dataset, 200);
        } catch (\Throwable $e) {
            $this->json([
                'status' => 'error',
                'message' => $e->getMessage(),
                'code' => 500,
            ], 500);
        }
    }
}
