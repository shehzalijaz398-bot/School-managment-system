<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use Core\Database;
use Core\Security\JwtService;

final class AuthApiController
{
    /**
     * Issue Stateless JWT Bearer Token for Mobile Apps and IoT Scanners.
     * Route: POST /api/v1/auth/token
     */
    public function issueToken(): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        $raw = file_get_contents('php://input');
        $input = json_decode($raw, true) ?: $_POST;

        $email = strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');
        $schoolCode = strtoupper(trim((string) ($input['school_code'] ?? '')));

        if (empty($email) || empty($password)) {
            $this->respond(400, [
                'success' => false,
                'status' => 400,
                'error' => ['code' => 'BAD_REQUEST', 'message' => 'Email and password are required.']
            ]);
            return;
        }

        // 1. Resolve school tenant
        $school = null;
        if (!empty($schoolCode)) {
            $school = Database::fetch(
                'SELECT * FROM schools WHERE UPPER(code) = ? AND deleted_at IS NULL LIMIT 1',
                [$schoolCode]
            );
            if (!$school) {
                $this->respond(404, [
                    'success' => false,
                    'status' => 404,
                    'error' => ['code' => 'TENANT_NOT_FOUND', 'message' => 'Invalid school access code.']
                ]);
                return;
            }
        }

        // 2. Fetch user
        $query = 'SELECT u.*, r.slug AS role_slug, s.id AS school_id, s.status AS school_status, s.subscription_status
                  FROM users u
                  JOIN roles r ON r.id = u.role_id
                  JOIN schools s ON s.id = u.school_id
                  WHERE u.email = ? AND s.deleted_at IS NULL';
        $params = [$email];

        if ($school) {
            $query .= ' AND u.school_id = ?';
            $params[] = (int) $school['id'];
        }

        $user = Database::fetch($query, $params);

        if (!$user || !password_verify($password, $user['password'])) {
            $this->respond(401, [
                'success' => false,
                'status' => 401,
                'error' => ['code' => 'INVALID_CREDENTIALS', 'message' => 'Invalid email or password.']
            ]);
            return;
        }

        if ((int) ($user['status'] ?? 0) !== 1 || (int) ($user['school_status'] ?? 0) !== 1) {
            $this->respond(403, [
                'success' => false,
                'status' => 403,
                'error' => ['code' => 'ACCOUNT_INACTIVE', 'message' => 'User account or school subscription is inactive.']
            ]);
            return;
        }

        // Resolve student ID if role is student
        $studentId = null;
        if ($user['role_slug'] === 'student') {
            $studentRow = Database::fetch(
                'SELECT id FROM students WHERE user_id = ? AND school_id = ? LIMIT 1',
                [(int) $user['id'], (int) $user['school_id']]
            );
            $studentId = $studentRow ? (int) $studentRow['id'] : null;
        }

        // 3. Generate Stateless JWT
        $payload = [
            'sub'        => (int) $user['id'],
            'tenant_id'  => (int) $user['school_id'],
            'role'       => $user['role_slug'],
            'email'      => $user['email'],
            'student_id' => $studentId,
        ];

        $token = JwtService::encode($payload, 86400 * 7); // 7-day token

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => [
                'token_type' => 'Bearer',
                'access_token' => $token,
                'expires_in' => 86400 * 7,
                'user' => [
                    'id' => (int) $user['id'],
                    'email' => $user['email'],
                    'first_name' => $user['first_name'] ?? '',
                    'last_name' => $user['last_name'] ?? '',
                    'role' => $user['role_slug'],
                    'school_id' => (int) $user['school_id'],
                    'student_id' => $studentId,
                ],
            ],
            'meta' => [
                'timestamp' => date('c'),
            ],
        ]);
    }

    private function respond(int $status, array $data): void
    {
        http_response_code($status);
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }
}
