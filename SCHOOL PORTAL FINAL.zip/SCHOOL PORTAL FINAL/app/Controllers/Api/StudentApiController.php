<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use Core\ApiContext;
use Core\Database;

final class StudentApiController
{
    /**
     * Normalized Student Profile Resource
     * Route: GET /api/v1/student/profile
     */
    public function profile(): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        $tenantId = ApiContext::tenantId();
        $userId = ApiContext::userId();
        $studentId = ApiContext::studentId();

        // Strict Tenant Isolation Query
        $sql = 'SELECT s.id AS student_id, s.school_id, s.admission_no, s.roll_no, 
                       s.first_name, s.last_name, s.gender, s.date_of_birth, s.email, s.phone,
                       s.address, s.admission_date, s.medical_note, s.emergency_contact, s.emergency_phone,
                       s.profile_image, s.status AS enrollment_status,
                       c.id AS class_id, c.name AS class_name,
                       sec.id AS section_id, sec.name AS section_name,
                       ay.id AS academic_year_id, ay.name AS academic_year_name,
                       sch.name AS school_name, sch.code AS school_code
                FROM students s
                INNER JOIN schools sch ON sch.id = s.school_id
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
                LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
                LEFT JOIN academic_years ay ON ay.id = s.academic_year_id AND ay.school_id = s.school_id
                WHERE s.school_id = ? ';

        $params = [$tenantId];
        if ($studentId) {
            $sql .= 'AND s.id = ? LIMIT 1';
            $params[] = $studentId;
        } else {
            $sql .= 'AND s.user_id = ? LIMIT 1';
            $params[] = $userId;
        }

        $student = Database::fetch($sql, $params);

        if (!$student) {
            $this->respond(404, [
                'success' => false,
                'status' => 404,
                'error' => [
                    'code' => 'STUDENT_NOT_FOUND',
                    'message' => 'No active student record found matching this account context.'
                ]
            ]);
            return;
        }

        // Fetch parent/guardian information if linked
        $parents = Database::fetchAll(
            'SELECT p.id, p.first_name, p.last_name, p.phone, p.email, sp.relationship AS relation
             FROM student_parents sp
             JOIN parents p ON p.id = sp.parent_id
             WHERE sp.student_id = ? AND sp.school_id = ?',
            [(int) $student['student_id'], $tenantId]
        );

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => [
                'id' => (int) $student['student_id'],
                'admission_no' => $student['admission_no'],
                'roll_no' => $student['roll_no'],
                'full_name' => trim("{$student['first_name']} {$student['last_name']}"),
                'first_name' => $student['first_name'],
                'last_name' => $student['last_name'],
                'gender' => $student['gender'],
                'date_of_birth' => $student['date_of_birth'],
                'contact' => [
                    'email' => $student['email'],
                    'phone' => $student['phone'],
                    'address' => $student['address'],
                    'emergency_contact' => $student['emergency_contact'],
                    'emergency_phone' => $student['emergency_phone'],
                ],
                'academic' => [
                    'class' => [
                        'id' => $student['class_id'] ? (int) $student['class_id'] : null,
                        'name' => $student['class_name'],
                    ],
                    'section' => [
                        'id' => $student['section_id'] ? (int) $student['section_id'] : null,
                        'name' => $student['section_name'],
                    ],
                    'academic_year' => [
                        'id' => $student['academic_year_id'] ? (int) $student['academic_year_id'] : null,
                        'name' => $student['academic_year_name'],
                    ],
                    'enrollment_status' => $student['enrollment_status'],
                    'admission_date' => $student['admission_date'],
                ],
                'institution' => [
                    'school_id' => (int) $student['school_id'],
                    'school_name' => $student['school_name'],
                    'school_code' => $student['school_code'],
                ],
                'guardians' => array_map(fn($p) => [
                    'id' => (int) $p['id'],
                    'name' => trim("{$p['first_name']} {$p['last_name']}"),
                    'relation' => $p['relation'] ?? 'Guardian',
                    'phone' => $p['phone'],
                    'email' => $p['email'],
                ], $parents),
            ],
            'meta' => [
                'timestamp' => date('c'),
                'tenant_id' => $tenantId,
            ],
        ]);
    }

    /**
     * Normalized Student Attendance Resource
     * Route: GET /api/v1/student/attendance
     */
    public function attendance(): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        $tenantId = ApiContext::tenantId();
        $userId = ApiContext::userId();
        $studentId = ApiContext::studentId();

        // Resolve student_id if not present in token claim
        if (!$studentId) {
            $row = Database::fetch(
                'SELECT id FROM students WHERE user_id = ? AND school_id = ? LIMIT 1',
                [$userId, $tenantId]
            );
            $studentId = $row ? (int) $row['id'] : null;
        }

        if (!$studentId) {
            $this->respond(404, [
                'success' => false,
                'status' => 404,
                'error' => ['code' => 'STUDENT_NOT_FOUND', 'message' => 'Student record not found.']
            ]);
            return;
        }

        // Date range filters (default to current month)
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');

        // Fetch attendance records bounded strictly by tenant
        $records = Database::fetchAll(
            'SELECT attendance_date, status, remarks, marked_at
             FROM student_attendance
             WHERE school_id = ? AND student_id = ? AND attendance_date BETWEEN ? AND ?
             ORDER BY attendance_date DESC',
            [$tenantId, $studentId, $startDate, $endDate]
        );

        // Aggregate Metrics
        $totalRecorded = count($records);
        $present = 0;
        $absent = 0;
        $late = 0;
        $excused = 0;

        foreach ($records as $r) {
            match ($r['status']) {
                'present' => $present++,
                'absent' => $absent++,
                'late' => $late++,
                'excused', 'leave' => $excused++,
                default => null,
            };
        }

        $presentPercentage = $totalRecorded > 0 ? round(($present / $totalRecorded) * 100, 1) : 0.0;

        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => [
                'date_range' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                ],
                'summary' => [
                    'total_recorded_days' => $totalRecorded,
                    'present_days' => $present,
                    'absent_days' => $absent,
                    'late_days' => $late,
                    'excused_days' => $excused,
                    'attendance_percentage' => $presentPercentage,
                ],
                'records' => array_map(fn($r) => [
                    'date' => $r['attendance_date'],
                    'status' => $r['status'],
                    'remarks' => $r['remarks'],
                    'marked_at' => $r['marked_at'],
                ], $records),
            ],
            'meta' => [
                'timestamp' => date('c'),
                'tenant_id' => $tenantId,
                'student_id' => $studentId,
            ],
        ]);
    }

    private function respond(int $status, array $data): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }
}
