<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use Core\ApiContext;
use Core\Database;

final class AttendanceScanApiController
{
    /**
     * Ingest Real-Time Hardware Scans from Biometric/RFID IoT Attendance Devices
     * Route: POST /api/v1/attendance/scan
     */
    public function scan(): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        $tenantId = ApiContext::tenantId();

        $raw = file_get_contents('php://input');
        $input = json_decode($raw, true) ?: $_POST;

        $identifier = trim((string) ($input['student_barcode'] ?? ($input['admission_no'] ?? ($input['rfid_card'] ?? ''))));
        $deviceSerial = trim((string) ($input['device_serial'] ?? 'IOT-GATE-01'));
        $direction = strtolower(trim((string) ($input['direction'] ?? 'in')));
        $punchTime = !empty($input['timestamp']) ? date('Y-m-d H:i:s', strtotime((string)$input['timestamp'])) : date('Y-m-d H:i:s');
        $attendanceDate = date('Y-m-d', strtotime($punchTime));

        if (empty($identifier)) {
            $this->respond(422, [
                'success' => false,
                'status' => 422,
                'error' => [
                    'code' => 'UNPROCESSABLE_ENTITY',
                    'message' => 'Missing student identifier (student_barcode or admission_no required).'
                ]
            ]);
            return;
        }

        // 1. Resolve student strictly within tenant boundary (Prevents cross-tenant scanning)
        $student = Database::fetch(
            'SELECT s.id, s.school_id, s.first_name, s.last_name, s.admission_no, s.class_id, s.section_id, s.status,
                    c.name AS class_name, sec.name AS section_name
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = s.school_id
             LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = s.school_id
             WHERE s.school_id = ? AND (s.admission_no = ? OR s.roll_no = ?)
             LIMIT 1',
            [$tenantId, $identifier, $identifier]
        );

        if (!$student) {
            $this->respond(404, [
                'success' => false,
                'status' => 404,
                'error' => [
                    'code' => 'STUDENT_NOT_FOUND',
                    'message' => "Student identifier '{$identifier}' does not match any registered student in this school tenant."
                ]
            ]);
            return;
        }

        if ($student['status'] !== 'active') {
            $this->respond(403, [
                'success' => false,
                'status' => 403,
                'error' => [
                    'code' => 'STUDENT_INACTIVE',
                    'message' => "Student enrollment status is '{$student['status']}'. Punch rejected."
                ]
            ]);
            return;
        }

        // 2. Resolve Active Academic Year
        $academicYear = Database::fetch(
            'SELECT id FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1',
            [$tenantId]
        );
        $academicYearId = $academicYear ? (int) $academicYear['id'] : 1;

        $markedBy = ApiContext::userId() ?? 1;

        // 3. Atomically upsert attendance record
        $existing = Database::fetch(
            'SELECT id, status FROM student_attendance 
             WHERE school_id = ? AND student_id = ? AND attendance_date = ? 
             LIMIT 1',
            [$tenantId, (int) $student['id'], $attendanceDate]
        );

        $actionTaken = 'recorded';
        $statusRecorded = 'present';
        $remarks = "IoT Biometric Punch [Device: {$deviceSerial}, Dir: {$direction}, Time: " . date('H:i:s', strtotime($punchTime)) . "]";

        if ($existing) {
            Database::execute(
                'UPDATE student_attendance 
                 SET status = ?, remarks = CONCAT(COALESCE(remarks, ""), " | ", ?), updated_at = NOW() 
                 WHERE id = ? AND school_id = ?',
                [$statusRecorded, $remarks, (int) $existing['id'], $tenantId]
            );
            $actionTaken = 'updated';
            $attendanceId = (int) $existing['id'];
        } else {
            $attendanceId = Database::insert(
                'INSERT INTO student_attendance (school_id, academic_year_id, student_id, class_id, section_id, attendance_date, status, remarks, marked_by, marked_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                [
                    $tenantId,
                    $academicYearId,
                    (int) $student['id'],
                    (int) ($student['class_id'] ?? 1),
                    (int) ($student['section_id'] ?? 1),
                    $attendanceDate,
                    $statusRecorded,
                    $remarks,
                    $markedBy,
                    $punchTime
                ]
            );
        }

        // Return real-time confirmation receipt to the IoT device
        $this->respond(200, [
            'success' => true,
            'status' => 200,
            'data' => [
                'action' => $actionTaken,
                'attendance_id' => $attendanceId,
                'punch' => [
                    'direction' => $direction,
                    'timestamp' => $punchTime,
                    'device_serial' => $deviceSerial,
                ],
                'student' => [
                    'id' => (int) $student['id'],
                    'admission_no' => $student['admission_no'],
                    'full_name' => trim("{$student['first_name']} {$student['last_name']}"),
                    'class' => $student['class_name'] ?? 'N/A',
                    'section' => $student['section_name'] ?? 'N/A',
                ],
                'attendance_status' => $statusRecorded,
            ],
            'meta' => [
                'timestamp' => date('c'),
                'tenant_id' => $tenantId,
            ],
        ]);
    }

    private function respond(int $status, array $data): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }
}
