<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class GlobalSearchController extends Controller
{
    public function search(): void
    {
        Auth::requireLogin();
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            $this->json(['results' => []], 403);
            return;
        }

        $query = trim((string) ($_GET['q'] ?? ''));
        if (mb_strlen($query) < 2) {
            $this->json(['results' => []]);
            return;
        }

        $categorized = $this->searchData($query, $schoolId);
        $flat = [];
        foreach ($categorized as $items) {
            foreach ($items as $item) {
                $flat[] = $item;
            }
        }

        $this->json(['results' => $flat]);
    }

    /**
     * Search tenant database across students, staff, invoices, admissions, and classes.
     * Strictly isolates all queries to the provided $schoolId.
     *
     * @param string $query
     * @param int $schoolId
     * @return array<string, array<int, array<string, mixed>>>
     */
    public function searchData(string $query, int $schoolId): array
    {
        $term = '%' . $query . '%';
        $results = [
            'students' => [],
            'staff' => [],
            'invoices' => [],
            'admissions' => [],
            'classes' => [],
        ];

        // 1. Search Students
        $students = Database::fetchAll(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no, s.roll_no, c.name AS class_name
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE s.school_id = ? AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ?)
             LIMIT 5',
            [$schoolId, $term, $term, $term, $term]
        );
        foreach ($students as $st) {
            $fullName = trim($st['first_name'] . ' ' . $st['last_name']);
            $meta = "Adm: {$st['admission_no']}" . ($st['class_name'] ? " · {$st['class_name']}" : '');
            $results['students'][] = [
                'id' => (int) $st['id'],
                'category' => 'Students',
                'title' => $fullName,
                'subtitle' => $meta,
                'url' => url("students/{$st['id']}"),
                'icon' => 'graduation-cap',
                'badge' => 'Student',
                'badge_color' => 'primary',
            ];
        }

        // 2. Search Staff & Faculty
        $staff = Database::fetchAll(
            'SELECT e.id, e.first_name, e.last_name, e.employee_code, d.name AS department_name, des.name AS designation_name
             FROM employees e
             LEFT JOIN departments d ON d.id = e.department_id
             LEFT JOIN designations des ON des.id = e.designation_id
             WHERE e.school_id = ? AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ?)
             LIMIT 4',
            [$schoolId, $term, $term, $term]
        );
        foreach ($staff as $emp) {
            $name = trim($emp['first_name'] . ' ' . $emp['last_name']);
            $meta = ($emp['designation_name'] ?: 'Staff') . ($emp['employee_code'] ? " · Code: {$emp['employee_code']}" : '');
            $results['staff'][] = [
                'id' => (int) $emp['id'],
                'category' => 'Staff & Faculty',
                'title' => $name,
                'subtitle' => $meta,
                'url' => url("staff/{$emp['id']}"),
                'icon' => 'briefcase',
                'badge' => 'Faculty',
                'badge_color' => 'success',
            ];
        }

        // 3. Search Fee Invoices
        $invoices = Database::fetchAll(
            'SELECT i.id, i.invoice_no, i.total_amount, i.status, s.first_name, s.last_name
             FROM student_fee_invoices i
             JOIN students s ON s.id = i.student_id
             WHERE i.school_id = ? AND (i.invoice_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)
             LIMIT 4',
            [$schoolId, $term, $term, $term]
        );
        foreach ($invoices as $inv) {
            $stName = trim($inv['first_name'] . ' ' . $inv['last_name']);
            $meta = "{$stName} · " . strtoupper($inv['status']) . " · " . formatMoney((float) $inv['total_amount']);
            $results['invoices'][] = [
                'id' => (int) $inv['id'],
                'category' => 'Fee Invoices',
                'title' => "Invoice #{$inv['invoice_no']}",
                'subtitle' => $meta,
                'url' => url("finance/invoices?q=" . urlencode($inv['invoice_no'])),
                'icon' => 'receipt',
                'badge' => 'Finance',
                'badge_color' => 'warning',
            ];
        }

        // 4. Search Admissions
        $admissions = Database::fetchAll(
            'SELECT id, application_no, student_name, status FROM admissions
             WHERE school_id = ? AND (student_name LIKE ? OR application_no LIKE ?)
             LIMIT 3',
            [$schoolId, $term, $term]
        );
        foreach ($admissions as $adm) {
            $results['admissions'][] = [
                'id' => (int) $adm['id'],
                'category' => 'Admissions',
                'title' => $adm['student_name'],
                'subtitle' => "App #{$adm['application_no']} · " . ucfirst($adm['status']),
                'url' => url("admissions?search=" . urlencode($adm['application_no'])),
                'icon' => 'user-plus',
                'badge' => 'Admission',
                'badge_color' => 'info',
            ];
        }

        // 5. Search Classes
        $classes = Database::fetchAll(
            'SELECT id, name FROM classes WHERE school_id = ? AND name LIKE ? LIMIT 3',
            [$schoolId, $term]
        );
        foreach ($classes as $cls) {
            $results['classes'][] = [
                'id' => (int) $cls['id'],
                'category' => 'Classes',
                'title' => $cls['name'],
                'subtitle' => "Academic Class Record",
                'url' => url("classes"),
                'icon' => 'book-open',
                'badge' => 'Class',
                'badge_color' => 'secondary',
            ];
        }

        return $results;
    }
}
