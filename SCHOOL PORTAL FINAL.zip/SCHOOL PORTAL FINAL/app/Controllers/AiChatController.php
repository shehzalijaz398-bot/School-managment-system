<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\AiContextService;
use App\Services\AiLlmService;
use Core\Auth;
use Core\Controller;

/**
 * AiChatController
 *
 * REST API Controller for the multi-tenant contextual AI Chatbot engine.
 * Strictly enforces Auth::schoolId() tenant boundary and user role permissions
 * to prevent unauthorized data exposure.
 */
final class AiChatController extends Controller
{
    private AiContextService $contextService;
    private AiLlmService $llmService;
    private \App\Services\AiWorkflowActionService $workflowService;
    private \App\Services\AiUsageTrackingService $usageTracker;
    private \App\Services\AiPrivacyService $privacyService;
    private \App\Services\AiReportService $reportService;
    private \App\Services\AiAnomalyDetectionService $anomalyService;
    private \App\Services\AiPredictiveAnalyticsService $predictiveService;
    private \App\Services\AiProductivityService $productivityService;

    public function __construct()
    {
        parent::__construct();
        $this->contextService = new AiContextService();
        $this->llmService = new AiLlmService();
        $this->workflowService = new \App\Services\AiWorkflowActionService();
        $this->usageTracker = new \App\Services\AiUsageTrackingService();
        $this->privacyService = new \App\Services\AiPrivacyService();
        $this->reportService = new \App\Services\AiReportService();
        $this->anomalyService = new \App\Services\AiAnomalyDetectionService();
        $this->predictiveService = new \App\Services\AiPredictiveAnalyticsService();
        $this->productivityService = new \App\Services\AiProductivityService();
    }

    /**
     * Standard JSON AJAX Chat Endpoint.
     * Route: POST /api/ai/chat
     */
    public function chat(): void
    {
        $startTime = microtime(true);
        $auth = $this->authenticateAjaxUser();

        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];
        $roleSlug = (string) $auth['role_slug'];

        // Check user-level rate limiting
        $this->enforceRateLimit($userId, $auth['type']);

        // Check tenant monthly AI token budget & daily limits
        $quotaCheck = $this->usageTracker->checkQuota($schoolId);
        if (!$quotaCheck['allowed']) {
            $this->json([
                'success' => false,
                'status' => 429,
                'error' => $quotaCheck['reason'] ?? 'AI token limit reached.',
                'quota_used_pct' => $quotaCheck['quota_used_pct'] ?? 100.0,
            ], 429);
            return;
        }

        // Read and validate JSON payload or form POST
        $payload = $this->readJsonInput();
        $prompt = trim((string) ($payload['prompt'] ?? ''));
        $history = is_array($payload['history'] ?? null) ? $payload['history'] : [];
        $providerOverride = !empty($payload['provider']) ? (string) $payload['provider'] : null;

        if ($prompt === '') {
            $this->json([
                'success' => false,
                'error' => 'Chat prompt cannot be empty.',
            ], 422);
            return;
        }

        // Scrub sensitive PII (phones, cards, CNIC/SSN, emails) before processing
        $prompt = $this->privacyService->redactPii($prompt);

        if (mb_strlen($prompt) > 1000) {
            $this->json([
                'success' => false,
                'error' => 'Prompt exceeds maximum allowed length of 1000 characters.',
            ], 422);
            return;
        }

        // Check for authorized consequential workflow actions requiring confirmation
        $actionIntent = $this->workflowService->detectActionableIntent($prompt, $roleSlug);
        if ($actionIntent !== null && $auth['type'] === 'school' && $schoolId > 0) {
            $proposal = $this->workflowService->buildProposal($actionIntent['action'], $schoolId, $userId, $actionIntent['params']);

            auditLog('ai.action_proposed', [
                'user_id' => $userId,
                'role' => $roleSlug,
                'action' => $actionIntent['action'],
                'school_id' => $schoolId,
                'ip' => client_ip(),
            ]);

            $this->json([
                'success' => true,
                'reply' => $proposal['reply'],
                'confirmation_required' => true,
                'action' => $proposal['action'],
                'action_title' => $proposal['action_title'],
                'summary' => $proposal['summary'],
                'preview_data' => $proposal['preview_data'],
                'confirmation_token' => $proposal['confirmation_token'],
                'expires_in_seconds' => $proposal['expires_in_seconds'],
                'metadata' => [
                    'school_id' => $schoolId,
                    'role' => $roleSlug,
                    'timestamp' => date('c'),
                ],
            ]);
            return;
        }

        // Intercept mutation attempts and sensitive destructive actions
        if ($this->detectSensitiveMutation($prompt)) {
            if ($auth['type'] === 'platform') {
                \App\Services\Platform\PlatformAudit::log('mutation_blocked', 'ai_assistant', null, 'platform_user', $userId);
            } else {
                auditLog('ai.mutation_blocked', [
                    'user_id' => $userId,
                    'role' => $roleSlug,
                    'ip' => client_ip(),
                ]);
            }

            $this->json([
                'success' => true,
                'reply' => "⚠️ **Action Blocked by Security Guardrails**\n\nAs a secure read-only AI Assistant, I am strictly prohibited from creating, updating, or deleting database records, modifying student fees, changing grades, or altering system state.\n\nPlease perform these administrative changes directly through the authorized portal forms with verified credentials.",
                'metadata' => [
                    'security_event' => 'mutation_blocked',
                    'role' => $roleSlug,
                    'school_id' => $schoolId,
                    'timestamp' => date('c'),
                ],
            ]);
            return;
        }

        // 1. Prepare conversation turn history (bounded to last 6 turns)
        $sanitizedHistory = $this->sanitizeHistory($history);

        // 2. Contextual Prompt Assembly (RAG-lite) strictly scoped to tenant & role
        $contextResult = $this->contextService->assembleContext(
            schoolId: $schoolId,
            userId: $userId,
            roleSlug: $roleSlug,
            userQuery: $prompt,
            history: $sanitizedHistory
        );

        $sanitizedHistory[] = [
            'role' => 'user',
            'content' => $prompt,
        ];

        $isAdmin = in_array($roleSlug, ['admin', 'super_admin', 'platform_super_admin'], true);

        // 3. Dispatch to LLM service (Gemini / OpenAI / Context Engine)
        $llmResult = $this->llmService->complete(
            systemPrompt: $contextResult['system_prompt'],
            messages: $sanitizedHistory,
            overrideProvider: $providerOverride,
            isAdmin: $isAdmin
        );

        $latency = round((microtime(true) - $startTime) * 1000, 2);

        // Record AI token usage and cost accounting
        $promptTokens = (int) ($llmResult['usage']['promptTokenCount'] ?? $llmResult['usage']['prompt_tokens'] ?? (int) ceil(strlen($contextResult['system_prompt']) / 4));
        $completionTokens = (int) ($llmResult['usage']['candidatesTokenCount'] ?? $llmResult['usage']['completion_tokens'] ?? (int) ceil(strlen($llmResult['content'] ?? '') / 4));

        $this->usageTracker->logUsage(
            schoolId: $schoolId,
            userId: $userId,
            provider: (string) ($llmResult['provider'] ?? 'gemini'),
            model: (string) ($llmResult['model'] ?? 'gemini-1.5-flash'),
            promptTokens: $promptTokens,
            completionTokens: $completionTokens,
            latencyMs: (float) $latency,
            status: ($llmResult['success'] ?? true) ? 'success' : 'failed',
            queryIntent: (string) ($contextResult['intents'][0] ?? 'general'),
            ipAddress: $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        );

        // Generate contextual follow-up questions
        $activeSubject = $contextResult['metadata']['active_subject'] ?? null;
        $followUps = $this->generateFollowUps($contextResult['intents'], $roleSlug, $prompt, $activeSubject);

        // Determine if response contains verified institutional database data
        $isVerifiedRecord = !empty($contextResult['intents']) && !in_array('general', $contextResult['intents'], true);

        // Append assistant response to history
        $sanitizedHistory[] = [
            'role' => 'assistant',
            'content' => $llmResult['content'],
            'follow_ups' => $followUps,
            'verified' => $isVerifiedRecord,
            'timestamp' => date('c'),
        ];

        // Store bounded session history isolated by tenant and user
        $sessionKey = 'ai_chat_history_' . $schoolId . '_' . $userId;
        $_SESSION[$sessionKey] = array_slice($sanitizedHistory, -20);
        $_SESSION['ai_chat_history'] = $_SESSION[$sessionKey];

        // 4. Return structured JSON response
        $this->json([
            'success' => true,
            'reply' => $llmResult['content'],
            'configured' => $llmResult['configured'] ?? true,
            'follow_ups' => $followUps,
            'verified_record' => $isVerifiedRecord,
            'metadata' => [
                'school_id' => $schoolId,
                'role' => $roleSlug,
                'purview' => $contextResult['purview'],
                'intents' => $contextResult['intents'],
                'active_subject' => $activeSubject,
                'provider' => $llmResult['provider'],
                'model' => $llmResult['model'],
                'latency_ms' => $latency,
                'timestamp' => date('c'),
            ],
        ]);
    }

    /**
     * Execute an authorized consequential AI action after user confirmation.
     * Route: POST /api/ai/action/execute
     */
    public function executeAction(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];

        $payload = $this->readJsonInput();
        $token = trim((string) ($payload['confirmation_token'] ?? $payload['token'] ?? ''));

        if ($token === '') {
            $this->json([
                'success' => false,
                'error' => 'Confirmation token is required.',
            ], 422);
            return;
        }

        $result = $this->workflowService->verifyAndExecute($token, $schoolId, $userId);

        if (!($result['success'] ?? false)) {
            $this->json([
                'success' => false,
                'error' => $result['error'] ?? 'Execution failed.',
            ], 400);
            return;
        }

        $this->json([
            'success' => true,
            'message' => $result['message'] ?? 'Action executed successfully.',
            'action' => $result['action'] ?? '',
            'executed_at' => $result['executed_at'] ?? date('c'),
            'data' => $result['data'] ?? [],
        ]);
    }

    /**
     * Server-Sent Events (SSE) Streaming Chat Endpoint.
     * Route: POST /api/ai/chat/stream
     */
    public function stream(): void
    {
        $auth = $this->authenticateAjaxUser();

        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];
        $roleSlug = (string) $auth['role_slug'];

        $this->enforceRateLimit($userId, $auth['type']);

        $payload = $this->readJsonInput();
        $prompt = trim((string) ($payload['prompt'] ?? ''));
        $history = is_array($payload['history'] ?? null) ? $payload['history'] : [];
        $providerOverride = !empty($payload['provider']) ? (string) $payload['provider'] : null;

        if ($prompt === '') {
            $this->json(['success' => false, 'error' => 'Prompt required.'], 422);
            return;
        }

        // Disable output buffering for live streaming
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');
        @ini_set('implicit_flush', '1');
        while (ob_get_level() > 0) {
            ob_end_flush();
        }
        ob_implicit_flush(true);

        header('Content-Type: text/event-stream; charset=utf-8');
        header('Cache-Control: no-cache, no-transform');
        header('Connection: keep-alive');
        header('X-Accel-Buffering: no');

        // Check mutation attempt
        if ($this->detectSensitiveMutation($prompt)) {
            if ($auth['type'] === 'platform') {
                \App\Services\Platform\PlatformAudit::log('mutation_blocked', 'ai_assistant', null, 'platform_user', $userId);
            } else {
                auditLog('ai.mutation_blocked', ['user_id' => $userId, 'role' => $roleSlug, 'ip' => client_ip()]);
            }
            $blockedMsg = "⚠️ **Action Blocked**: As a secure read-only AI Assistant, I am strictly prohibited from modifying student records, deleting data, or altering financial ledgers.";
            echo "data: " . json_encode(['type' => 'chunk', 'text' => $blockedMsg]) . "\n\n";
            echo "data: " . json_encode(['type' => 'done']) . "\n\n";
            flush();
            exit;
        }

        $sanitizedHistory = $this->sanitizeHistory($history);

        $contextResult = $this->contextService->assembleContext(
            schoolId: $schoolId,
            userId: $userId,
            roleSlug: $roleSlug,
            userQuery: $prompt,
            history: $sanitizedHistory
        );

        $sanitizedHistory[] = ['role' => 'user', 'content' => $prompt];

        // Send metadata preamble
        $metaEvent = [
            'type' => 'meta',
            'role' => $roleSlug,
            'purview' => $contextResult['purview'],
            'intents' => $contextResult['intents'],
        ];
        echo "data: " . json_encode($metaEvent) . "\n\n";
        flush();

        $isAdmin = in_array($roleSlug, ['admin', 'super_admin', 'platform_super_admin'], true);

        // Stream text chunks
        $this->llmService->stream(
            systemPrompt: $contextResult['system_prompt'],
            messages: $sanitizedHistory,
            onChunk: function (string $chunk) {
                echo "data: " . json_encode(['type' => 'chunk', 'text' => $chunk]) . "\n\n";
                flush();
            },
            overrideProvider: $providerOverride,
            isAdmin: $isAdmin
        );

        echo "data: " . json_encode(['type' => 'done']) . "\n\n";
        flush();
        exit;
    }

    /**
     * Contextual Quick Prompt Suggestions Endpoint.
     * Route: GET /api/ai/chat/suggestions
     */
    public function suggestions(): void
    {
        $auth = $this->authenticateAjaxUser();
        $role = $auth['role_slug'];

        $suggestions = match ($role) {
            'super_admin', 'superadmin' => [
                ['icon' => 'server', 'text' => "Show platform school counts and active subscriptions"],
                ['icon' => 'shield-check', 'text' => "What is the automated backup vault status?"],
                ['icon' => 'layers', 'text' => "List available subscription tiers and pricing"],
                ['icon' => 'search', 'text' => "Search school status for Lincoln High"],
            ],
            'parent' => [
                ['icon' => 'credit-card', 'text' => "Is my child's fee paid?"],
                ['icon' => 'calendar', 'text' => "What is my child's attendance record?"],
                ['icon' => 'book-open', 'text' => "Are there any pending assignments due?"],
                ['icon' => 'file-text', 'text' => "Show recent fee invoice receipts"],
            ],
            'student' => [
                ['icon' => 'credit-card', 'text' => "Check my pending fee balance"],
                ['icon' => 'check-circle', 'text' => "What is my attendance percentage?"],
                ['icon' => 'clipboard', 'text' => "List my homework assignments"],
                ['icon' => 'clock', 'text' => "What is today's class schedule?"],
            ],
            'teacher' => [
                ['icon' => 'calendar', 'text' => "Show my class schedule today"],
                ['icon' => 'users', 'text' => "How many students are enrolled in my class?"],
                ['icon' => 'file-plus', 'text' => "Guide me on creating a new assignment"],
                ['icon' => 'check-square', 'text' => "How do I submit today's attendance?"],
            ],
            default => [
                ['icon' => 'trending-up', 'text' => "Summarize our school operational trends and areas needing attention"],
                ['icon' => 'dollar-sign', 'text' => "Show total fee collection summary"],
                ['icon' => 'alert-triangle', 'text' => "What is the overdue fee arrears total?"],
                ['icon' => 'users', 'text' => "How many total students are currently enrolled?"],
                ['icon' => 'user-check', 'text' => "Look up student Jose's fee record"],
            ],
        };

        $this->json([
            'success' => true,
            'role' => $role,
            'suggestions' => $suggestions,
        ]);
    }

    /**
     * Get Session Conversation History for authenticated user.
     * Route: GET /api/ai/chat/history
     */
    public function history(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];

        $sessionKey = 'ai_chat_history_' . $schoolId . '_' . $userId;
        $history = $_SESSION[$sessionKey] ?? [];

        $this->json([
            'success' => true,
            'role' => $auth['role_slug'],
            'school_id' => $schoolId,
            'user_id' => $userId,
            'history' => is_array($history) ? $history : [],
        ]);
    }

    /**
     * Start a fresh conversation (reset session history).
     * Route: POST /api/ai/chat/new
     */
    public function newConversation(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];

        $sessionKey = 'ai_chat_history_' . $schoolId . '_' . $userId;
        unset($_SESSION[$sessionKey], $_SESSION['ai_chat_history']);

        $this->json([
            'success' => true,
            'message' => 'New conversation initialized.',
            'timestamp' => date('c'),
        ]);
    }

    /**
     * Clear Chat Session.
     * Route: POST /api/ai/chat/clear
     */
    public function clearHistory(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];

        $sessionKey = 'ai_chat_history_' . $schoolId . '_' . $userId;
        unset($_SESSION[$sessionKey], $_SESSION['ai_chat_history']);

        $this->json(['success' => true, 'message' => 'Chat history cleared.']);
    }

    /**
     * Submit user feedback on AI responses (Helpful / Unhelpful / Inaccurate).
     * Route: POST /api/ai/chat/feedback
     */
    public function feedback(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];
        $roleSlug = (string) $auth['role_slug'];

        $payload = $this->readJsonInput();
        $rating = strtolower(trim((string) ($payload['rating'] ?? 'helpful')));
        $comment = mb_substr(trim((string) ($payload['comment'] ?? '')), 0, 500);
        $promptPreview = mb_substr(trim((string) ($payload['prompt'] ?? '')), 0, 150);

        $allowedRatings = ['helpful', 'unhelpful', 'inaccurate', 'positive', 'negative'];
        if (!in_array($rating, $allowedRatings, true)) {
            $rating = 'helpful';
        }

        // Privacy-compliant audit log without leaking student sensitive PII
        if ($auth['type'] === 'platform') {
            \App\Services\Platform\PlatformAudit::log('feedback_' . $rating, 'ai_assistant', null, 'platform_user', $userId);
        } else {
            auditLog('ai.feedback_' . $rating, [
                'rating' => $rating,
                'has_comment' => ($comment !== ''),
                'prompt_snippet' => $promptPreview,
                'role' => $roleSlug,
            ]);
        }

        $this->json([
            'success' => true,
            'message' => 'Thank you for your feedback! Your rating helps improve response quality.',
            'rating' => $rating,
        ]);
    }

    /**
     * Generate context-aware follow-up question suggestions based on intents, role, and active subject.
     */
    private function generateFollowUps(array $intents, string $role, string $prompt, ?string $subject = null): array
    {
        $target = $subject ?: 'student';

        // 1. Fee questions
        if (in_array('fees', $intents, true)) {
            return match ($role) {
                'parent' => [
                    $subject ? "Show fee breakdown for {$target}" : "Show itemized fee invoice breakdown",
                    "When is the next fee payment due date?",
                    "How do I download fee receipts?",
                ],
                'student' => [
                    "What is my total pending fee balance?",
                    "Show my latest paid invoice receipt",
                    "What online payment methods are accepted?",
                ],
                'super_admin', 'superadmin' => [
                    "Compare platform subscription revenues",
                    "Show schools with pending renewals",
                    "List available pricing plan tiers",
                ],
                default => [
                    $subject ? "View all payment history for {$target}" : "Show top fee defaulters list",
                    "What is the total overdue fee collection?",
                    "How many unpaid fee invoices remain?",
                ],
            };
        }

        // 2. Attendance questions
        if (in_array('attendance', $intents, true)) {
            return match ($role) {
                'parent' => [
                    $subject ? "Show {$target}'s 30-day attendance record" : "What is my child's attendance percentage?",
                    "Were there any unexcused absences recorded?",
                    "How do I submit an excused leave request?",
                ],
                'student' => [
                    "What is my total attendance percentage this term?",
                    "How many days was I marked present?",
                    "What is the minimum attendance requirement?",
                ],
                'teacher' => [
                    "How do I submit today's attendance register?",
                    "Which students were marked absent today?",
                    "Show class attendance summary report",
                ],
                default => [
                    "Show staff and teacher attendance today",
                    "Which class has the lowest attendance rate?",
                    "Generate student attendance summary report",
                ],
            };
        }

        // 3. Exam questions
        if (in_array('exams', $intents, true)) {
            return match ($role) {
                'parent', 'student' => [
                    $subject ? "Show subject-wise exam grades for {$target}" : "Show subject-wise exam marks breakdown",
                    "What was the highest score achieved in class?",
                    "When are upcoming term exam dates scheduled?",
                ],
                default => [
                    "Show overall class examination pass rate",
                    "Which subjects need academic remedial support?",
                    "List all published term examinations",
                ],
            };
        }

        // 4. Timetable questions
        if (in_array('timetable', $intents, true)) {
            return match ($role) {
                'teacher' => [
                    "What is my next assigned teaching period?",
                    "Which classroom room is my next class in?",
                    "Show my complete weekly schedule",
                ],
                default => [
                    "What is tomorrow's class timetable schedule?",
                    "Who is the assigned teacher for Period 1?",
                    "What time does the school day end?",
                ],
            };
        }

        // 5. Analytics questions
        if (in_array('analytics', $intents, true)) {
            return match ($role) {
                'super_admin', 'superadmin' => [
                    "Compare platform subscription growth across tiers",
                    "What is our active tenant capacity utilization?",
                    "Show backup vault verification timestamps",
                ],
                'teacher' => [
                    "Which curriculum subjects have the lowest pass rate?",
                    "How does class attendance compare to last month?",
                    "Show academic areas needing remedial focus",
                ],
                default => [
                    "What are our key operational anomalies this period?",
                    "How does current attendance compare to prior cycle?",
                    "What is our fee collection efficiency rate?",
                ],
            };
        }

        // 6. Super Admin Platform
        if (in_array($role, ['super_admin', 'superadmin'], true)) {
            return [
                "What is the automated backup vault status?",
                "Show platform school counts and active subscriptions",
                "List available subscription plans and limits",
            ];
        }

        // Default General Suggestions
        return match ($role) {
            'parent' => [
                "Is my child's fee paid?",
                "What is my child's attendance record?",
                "Show pending homework assignments due",
            ],
            'student' => [
                "Check my pending fee balance",
                "What is my current attendance percentage?",
                "What is today's class schedule?",
            ],
            'teacher' => [
                "Show my class schedule today",
                "How many students are enrolled in my class?",
                "Guide me on creating a new assignment",
            ],
            default => [
                "What is the overall fee collection overview?",
                "How many students are currently enrolled?",
                "Show institutional staff and faculty metrics",
            ],
        };
    }

    /**
     * Strict Authentication and Multi-Tenant Check for AJAX requests.
     * Supports both tenant school users and SaaS platform superadmins.
     *
     * @return array{type: string, user_id: int, school_id: int, role_slug: string}
     */
    private function authenticateAjaxUser(): array
    {
        // 1. School portal authenticated user
        if (Auth::check() && Auth::schoolId()) {
            return [
                'type' => 'school',
                'user_id' => (int) Auth::id(),
                'school_id' => (int) Auth::schoolId(),
                'role_slug' => (string) (Auth::roleSlug() ?? 'school_admin'),
            ];
        }

        // 2. Platform Super Admin authenticated user
        if (class_exists('\\Core\\PlatformAuth') && \Core\PlatformAuth::check()) {
            $user = \Core\PlatformAuth::user();
            return [
                'type' => 'platform',
                'user_id' => (int) ($user['id'] ?? 1),
                'school_id' => 0,
                'role_slug' => 'super_admin',
            ];
        }

        $this->json([
            'success' => false,
            'status' => 401,
            'error' => 'Authentication required. Please refresh or log in again.',
        ], 401);
        exit;
    }

    /**
     * Intercept destructive actions, state modifications, credential fishing, and prompt injections.
     */
    private function detectSensitiveMutation(string $prompt): bool
    {
        $patterns = [
            // Destructive SQL and state modification
            '/\b(delete|drop|truncate|erase|remove|destroy)\b.*\b(database|table|student|students|fee|fees|invoice|record|records|user|users|parent|parents|mark|marks|grade|grades|school|schools)\b/i',
            '/\b(update|change|alter|modify|set|reset|reduce|waive)\b.*\b(fee|fees|invoice|invoices|amount|balance|due|mark|marks|grade|salary|payment|status|password)\b/i',
            '/\b(insert|create|add)\b.*\b(student|fee|invoice|payment|admin|user|table)\b/i',
            '/\b(drop\s+table|delete\s+from|update\s+\w+\s+set|insert\s+into|alter\s+table)\b/i',
            // SQL Injection and schema exfiltration attempts
            '/\b(union\s+select|information_schema|load_file|into\s+outfile|into\s+dumpfile|select\s+.*\s+from\s+(users|students|schools|passwords|audit_logs))\b/i',
            // Credential, password, and secret token fishing
            '/\b(show|reveal|display|tell|print|dump|extract|give|leak)\b.*\b(password|passwords|hash|hashes|api[_-]?key|secret|credentials|token|private[_-]?key|session_id|cookie)\b/i',
            // Prompt injection and jailbreak bypass attempts
            '/\b(ignore|disregard|forget|bypass|override)\s+(previous|prior|above|all)\s+(instructions|prompt|rules|constraints|guardrails)\b/i',
            '/\b(you\s+are\s+now|act\s+as|simulate)\s+(root|superadmin|dan|unrestricted|godmode|jailbreak)\b/i',
            '/\b(system\s+prompt|reveal\s+instructions|show\s+system\s+instruction)\b/i',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $prompt)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Enforce rate limit (max 25 requests per minute per user).
     */
    private function enforceRateLimit(int $userId, string $authType = 'school'): void
    {
        $key = 'ai_rate_' . $userId;
        $now = time();
        $record = $_SESSION[$key] ?? ['count' => 0, 'start' => $now];

        if (($now - $record['start']) > 60) {
            $record = ['count' => 1, 'start' => $now];
        } else {
            $record['count']++;
            if ($record['count'] > 25) {
                if ($authType === 'platform') {
                    \App\Services\Platform\PlatformAudit::log('rate_limited', 'ai_assistant', null, 'platform_user', $userId);
                } else {
                    auditLog('ai.rate_limited', ['user_id' => $userId, 'ip' => client_ip()]);
                }
                $this->json([
                    'success' => false,
                    'status' => 429,
                    'error' => 'Too many AI requests. Please wait a moment before trying again.',
                ], 429);
                exit;
            }
        }

        $_SESSION[$key] = $record;
    }

    /**
     * Safely read JSON payload or standard POST variables.
     */
    private function readJsonInput(): array
    {
        $raw = file_get_contents('php://input');
        if (!empty($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return $_POST;
    }

    /**
     * Sanitize and bound conversation turns.
     */
    private function sanitizeHistory(array $history): array
    {
        $clean = [];
        // Keep at most last 6 messages
        $slice = array_slice($history, -6);
        foreach ($slice as $item) {
            if (!is_array($item)) {
                continue;
            }
            $role = ($item['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
            $content = trim((string) ($item['content'] ?? ''));
            if ($content !== '') {
                $clean[] = [
                    'role' => $role,
                    'content' => mb_substr($content, 0, 1000),
                ];
            }
        }
        return $clean;
    }

    /**
     * Generate Natural Language Executive Report.
     * Route: POST /api/ai/reports/generate
     */
    public function generateReport(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $userId = (int) $auth['user_id'];
        $roleSlug = (string) $auth['role_slug'];

        $payload = $this->readJsonInput();
        $query = trim((string) ($payload['query'] ?? $payload['prompt'] ?? 'overview'));

        $report = $this->reportService->generateReport($schoolId, $userId, $roleSlug, $query);

        auditLog('ai.report_generated', [
            'report_type' => $report['report_type'] ?? 'overview',
            'user_id' => $userId,
            'school_id' => $schoolId,
        ]);

        $this->json($report);
    }

    /**
     * Get Smart Operational Anomalies & Insights.
     * Route: GET /api/ai/insights
     */
    public function insights(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];

        $anomalies = $this->anomalyService->detectAnomalies($schoolId);

        $this->json([
            'success' => true,
            'school_id' => $schoolId,
            'total_anomalies' => count($anomalies),
            'anomalies' => $anomalies,
            'scanned_at' => date('c'),
        ]);
    }

    /**
     * Get Predictive Analytics (Fee collections, attendance risk, academic radar).
     * Route: GET /api/ai/predictive/forecasts
     */
    public function forecasts(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];

        $days = (int) ($_GET['days'] ?? 30);
        $days = max(7, min(90, $days));

        $feeForecast = $this->predictiveService->predictFeeCollections($schoolId, $days);
        $attendanceRisk = $this->predictiveService->predictAttendanceRisk($schoolId);
        $academicRisk = $this->predictiveService->predictAcademicRisk($schoolId);

        $this->json([
            'success' => true,
            'school_id' => $schoolId,
            'fee_forecast' => $feeForecast,
            'attendance_risk' => $attendanceRisk,
            'academic_risk' => $academicRisk,
            'generated_at' => date('c'),
        ]);
    }

    /**
     * AI Productivity Suite: Draft official announcements or meeting notes.
     * Route: POST /api/ai/productivity/draft
     */
    public function draftProductivity(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];

        $payload = $this->readJsonInput();
        $type = (string) ($payload['type'] ?? 'general');
        $topic = trim((string) ($payload['topic'] ?? 'Institutional Notice'));
        $target = (string) ($payload['target_audience'] ?? 'all');
        $details = is_array($payload['details'] ?? null) ? $payload['details'] : [];

        $draft = $this->productivityService->draftAnnouncement($schoolId, $type, $topic, $target, $details);

        $this->json([
            'success' => true,
            'draft' => $draft,
        ]);
    }

    /**
     * AI Productivity Suite: Explain system error or provide workflow guide.
     * Route: POST /api/ai/productivity/explain
     */
    public function explainError(): void
    {
        $auth = $this->authenticateAjaxUser();
        $roleSlug = (string) $auth['role_slug'];

        $payload = $this->readJsonInput();
        $mode = (string) ($payload['mode'] ?? 'error');

        if ($mode === 'workflow') {
            $workflowKey = (string) ($payload['workflow_key'] ?? 'general');
            $guide = $this->productivityService->guideWorkflow($workflowKey, $roleSlug);
            $this->json(['success' => true, 'guide' => $guide]);
            return;
        }

        $errorMsg = (string) ($payload['error_message'] ?? 'General error');
        $context = !empty($payload['context']) ? (string) $payload['context'] : null;

        $explanation = $this->productivityService->explainSystemError($errorMsg, $context);
        $this->json(['success' => true, 'explanation' => $explanation]);
    }

    /**
     * AI Telemetry & Token Accounting.
     * Route: GET /api/ai/telemetry
     */
    public function telemetry(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];

        $telemetry = $this->usageTracker->getTelemetry($schoolId);

        $this->json([
            'success' => true,
            'school_id' => $schoolId,
            'telemetry' => $telemetry,
        ]);
    }

    /**
     * Test Provider Connectivity (Admin tool).
     * Route: POST /api/ai/provider/test
     */
    public function testProvider(): void
    {
        $auth = $this->authenticateAjaxUser();
        $roleSlug = (string) $auth['role_slug'];

        if (!in_array($roleSlug, ['admin', 'school_admin', 'super_admin', 'superadmin', 'platform_super_admin'], true)) {
            $this->json(['success' => false, 'error' => 'Unauthorized. Administrative role required.'], 403);
            return;
        }

        $payload = $this->readJsonInput();
        $provider = !empty($payload['provider']) ? (string) $payload['provider'] : null;

        $result = $this->llmService->testProviderConnectivity($provider);

        $this->json([
            'success' => true,
            'result' => $result,
        ]);
    }

    /**
     * Purge Expired AI Conversations (Privacy & Retention Control).
     * Route: POST /api/ai/privacy/purge
     */
    public function purgeRetention(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];
        $roleSlug = (string) $auth['role_slug'];

        if (!in_array($roleSlug, ['admin', 'school_admin', 'super_admin', 'superadmin'], true)) {
            $this->json(['success' => false, 'error' => 'Unauthorized.'], 403);
            return;
        }

        $payload = $this->readJsonInput();
        $days = (int) ($payload['retention_days'] ?? 30);
        $days = max(7, min(365, $days));

        $purged = $this->privacyService->purgeExpiredConversations($schoolId, $days);

        $this->json([
            'success' => true,
            'message' => "Purged {$purged} expired AI conversation records older than {$days} days.",
            'purged_count' => $purged,
        ]);
    }

    /**
     * Interactive Cockpit View.
     * Route: GET /school/ai-intelligence
     */
    public function cockpit(): void
    {
        $auth = $this->authenticateAjaxUser();
        $schoolId = (int) $auth['school_id'];

        $telemetry = $this->usageTracker->getTelemetry($schoolId);
        $anomalies = $this->anomalyService->detectAnomalies($schoolId);
        $feeForecast = $this->predictiveService->predictFeeCollections($schoolId, 30);
        $attendanceRisk = $this->predictiveService->predictAttendanceRisk($schoolId);
        $connectivity = $this->llmService->testProviderConnectivity();

        $this->view('ai/intelligence_cockpit', [
            'telemetry' => $telemetry,
            'anomalies' => $anomalies,
            'feeForecast' => $feeForecast,
            'attendanceRisk' => $attendanceRisk,
            'connectivity' => $connectivity,
        ]);
    }
}
