<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class DeveloperController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS tenant_webhooks (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                target_url VARCHAR(500) NOT NULL,
                secret_token VARCHAR(255) NOT NULL,
                active_events JSON NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        Database::execute("
            CREATE TABLE IF NOT EXISTS tenant_webhook_logs (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                webhook_id BIGINT NOT NULL,
                event_type VARCHAR(100) NOT NULL,
                payload JSON NOT NULL,
                response_code INT DEFAULT NULL,
                status VARCHAR(20) NOT NULL,
                attempted_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function webhookIndex(): void
    {
        requirePermission('settings.manage');
        $this->initSchema();

        $schoolId = Auth::schoolId();
        
        $webhooks = Database::fetchAll("SELECT * FROM tenant_webhooks WHERE school_id = ? ORDER BY id DESC", [$schoolId]);
        
        $logs = Database::fetchAll("
            SELECT l.*, w.target_url 
            FROM tenant_webhook_logs l
            JOIN tenant_webhooks w ON w.id = l.webhook_id
            WHERE l.school_id = ? 
            ORDER BY l.id DESC LIMIT 20
        ", [$schoolId]);

        $this->view('developer/webhooks', [
            'title' => 'Developer Portal & API Webhooks',
            'webhooks' => $webhooks,
            'logs' => $logs
        ]);
    }

    public function storeWebhook(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $this->initSchema();
        
        $targetUrl = filter_var($_POST['target_url'] ?? '', FILTER_VALIDATE_URL);
        $events = $_POST['events'] ?? [];
        
        if (!$targetUrl) {
            flash('error', 'Valid Endpoint URL is required.');
            redirect(url('developer/webhooks'));
            return;
        }

        if (empty($events)) {
            flash('error', 'Select at least one event subscription vector.');
            redirect(url('developer/webhooks'));
            return;
        }

        $secretToken = 'whsec_' . bin2hex(random_bytes(24));

        Database::insert(
            "INSERT INTO tenant_webhooks (school_id, target_url, secret_token, active_events, status, created_at) VALUES (?, ?, ?, ?, 'active', NOW())",
            [Auth::schoolId(), $targetUrl, json_encode($events), $secretToken]
        );

        flash('success', 'Enterprise Webhook Endpoint successfully registered and armed.');
        redirect(url('developer/webhooks'));
    }

    public function destroyWebhook(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        
        Database::execute("DELETE FROM tenant_webhooks WHERE id = ? AND school_id = ?", [(int)$id, Auth::schoolId()]);
        Database::execute("DELETE FROM tenant_webhook_logs WHERE webhook_id = ? AND school_id = ?", [(int)$id, Auth::schoolId()]);
        
        flash('success', 'Webhook configuration permanently destroyed.');
        redirect(url('developer/webhooks'));
    }
    
    /**
     * Automated Dispatch Hook Engine
     * Executes natively to process events and push payloads via cURL buffers.
     */
    public static function dispatch(string $event, array $payloadData): void
    {
        $schoolId = Auth::schoolId();
        if (!$schoolId) return;

        $webhooks = Database::fetchAll("SELECT * FROM tenant_webhooks WHERE school_id = ? AND status = 'active'", [$schoolId]);
        
        foreach ($webhooks as $webhook) {
            $events = json_decode($webhook['active_events'], true) ?? [];
            
            if (in_array($event, $events) || in_array('all', $events)) {
                
                $payload = json_encode([
                    'id' => 'evt_' . bin2hex(random_bytes(16)),
                    'type' => $event,
                    'created' => time(),
                    'data' => $payloadData
                ]);

                // Cryptographic Signature Rules
                $signature = hash_hmac('sha256', $payload, $webhook['secret_token']);
                
                // Optimized cURL timeout buffer
                $ch = curl_init($webhook['target_url']);
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $payload,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 3, // Fast 3s execution timeout limit
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/json',
                        'X-SaaS-Signature: ' . $signature,
                        'User-Agent: SaaS-Webhook-Engine/1.0'
                    ]
                ]);

                curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                $status = ($httpCode >= 200 && $httpCode < 300) ? 'delivered' : 'failed';
                
                Database::insert(
                    "INSERT INTO tenant_webhook_logs (school_id, webhook_id, event_type, payload, response_code, status, attempted_at)
                     VALUES (?, ?, ?, ?, ?, ?, NOW())",
                    [$schoolId, $webhook['id'], $event, $payload, $httpCode, $status]
                );
            }
        }
    }
}
