<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class InventoryController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $tab = trim((string)($_GET['tab'] ?? 'items'));
        $q = trim((string)($_GET['q'] ?? ''));
        $catId = (int)($_GET['category_id'] ?? 0);
        $status = trim((string)($_GET['status'] ?? ''));

        // Categories & Suppliers
        $categories = Database::fetchAll(
            'SELECT c.*, (SELECT COUNT(*) FROM inventory_items i WHERE i.category_id = c.id AND i.school_id = ?) AS item_count 
             FROM inventory_categories c WHERE c.school_id = ? ORDER BY c.name ASC',
            [$schoolId, $schoolId]
        );

        $suppliers = Database::fetchAll(
            'SELECT s.*, (SELECT COUNT(*) FROM inventory_transactions t WHERE t.supplier_id = s.id AND t.school_id = ?) AS transaction_count 
             FROM inventory_suppliers s WHERE s.school_id = ? ORDER BY s.name ASC',
            [$schoolId, $schoolId]
        );

        // KPI Stats
        $totalItems = (int)(Database::fetch('SELECT COUNT(*) AS c FROM inventory_items WHERE school_id = ? AND status = "active"', [$schoolId])['c'] ?? 0);
        $valuation = (float)(Database::fetch('SELECT SUM(quantity * unit_price) AS v FROM inventory_items WHERE school_id = ? AND status = "active"', [$schoolId])['v'] ?? 0.0);
        $lowStock = (int)(Database::fetch('SELECT COUNT(*) AS c FROM inventory_items WHERE school_id = ? AND status = "active" AND quantity <= min_threshold', [$schoolId])['c'] ?? 0);
        $txCount = (int)(Database::fetch('SELECT COUNT(*) AS c FROM inventory_transactions WHERE school_id = ? AND created_at >= DATE_FORMAT(NOW(), "%Y-%m-01")', [$schoolId])['c'] ?? 0);

        // Fetch Items
        $itemsQuery = 'SELECT i.*, c.name AS category_name 
                       FROM inventory_items i 
                       LEFT JOIN inventory_categories c ON c.id = i.category_id 
                       WHERE i.school_id = ?';
        $itemParams = [$schoolId];

        if ($catId > 0) {
            $itemsQuery .= ' AND i.category_id = ?';
            $itemParams[] = $catId;
        }
        if ($status !== '') {
            $itemsQuery .= ' AND i.status = ?';
            $itemParams[] = $status;
        }
        if ($q !== '') {
            $itemsQuery .= ' AND (i.name LIKE ? OR i.item_code LIKE ? OR i.location LIKE ?)';
            $wild = '%' . $q . '%';
            $itemParams[] = $wild;
            $itemParams[] = $wild;
            $itemParams[] = $wild;
        }
        $itemsQuery .= ' ORDER BY i.id DESC';
        $items = Database::fetchAll($itemsQuery, $itemParams);

        // Fetch Transactions
        $transactions = Database::fetchAll(
            'SELECT t.*, i.name AS item_name, i.item_code, i.unit, s.name AS supplier_name, u.name AS user_name 
             FROM inventory_transactions t
             INNER JOIN inventory_items i ON i.id = t.item_id
             LEFT JOIN inventory_suppliers s ON s.id = t.supplier_id
             LEFT JOIN users u ON u.id = t.created_by
             WHERE t.school_id = ?
             ORDER BY t.created_at DESC LIMIT 100',
            [$schoolId]
        );

        $this->view('inventory/index', [
            'title' => 'Inventory & Asset Management',
            'tab' => $tab,
            'items' => $items,
            'categories' => $categories,
            'suppliers' => $suppliers,
            'transactions' => $transactions,
            'stats' => [
                'total_items' => $totalItems,
                'valuation' => $valuation,
                'low_stock' => $lowStock,
                'tx_count' => $txCount,
            ],
            'filters' => [
                'q' => $q,
                'category_id' => $catId,
                'status' => $status,
            ],
        ]);
    }

    public function storeItem(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        $itemCode = trim((string)($_POST['item_code'] ?? ''));
        $catId = (int)($_POST['category_id'] ?? 0) ?: null;
        $unit = trim((string)($_POST['unit'] ?? 'pcs')) ?: 'pcs';
        $unitPrice = (float)($_POST['unit_price'] ?? 0.0);
        $quantity = (int)($_POST['quantity'] ?? 0);
        $minThreshold = (int)($_POST['min_threshold'] ?? 5);
        $location = trim((string)($_POST['location'] ?? ''));

        if ($name === '') {
            flash('error', 'Item name is required.');
            redirect(url('inventory?tab=items'));
        }

        if ($itemCode === '') {
            $itemCode = 'ITM-' . strtoupper(bin2hex(random_bytes(3)));
        }

        $id = Database::insert(
            'INSERT INTO inventory_items (school_id, category_id, item_code, name, unit, unit_price, quantity, min_threshold, location, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "active", NOW(), NOW())',
            [$schoolId, $catId, $itemCode, $name, $unit, $unitPrice, $quantity, $minThreshold, $location]
        );

        // Record initial intake transaction if quantity > 0
        if ($quantity > 0) {
            Database::insert(
                'INSERT INTO inventory_transactions (school_id, item_id, type, quantity, unit_price, total_price, reference_no, notes, created_by, created_at) 
                 VALUES (?, ?, "in", ?, ?, ?, "OPENING-STOCK", "Initial stock intake on creation", ?, NOW())',
                [$schoolId, $id, $quantity, $unitPrice, ($quantity * $unitPrice), (int)Auth::id()]
            );
        }

        flash('success', 'Inventory item added successfully.');
        redirect(url('inventory?tab=items'));
    }

    public function updateItem(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();
        $itemId = (int) $id;

        $name = trim((string)($_POST['name'] ?? ''));
        $itemCode = trim((string)($_POST['item_code'] ?? ''));
        $catId = (int)($_POST['category_id'] ?? 0) ?: null;
        $unit = trim((string)($_POST['unit'] ?? 'pcs')) ?: 'pcs';
        $unitPrice = (float)($_POST['unit_price'] ?? 0.0);
        $minThreshold = (int)($_POST['min_threshold'] ?? 5);
        $location = trim((string)($_POST['location'] ?? ''));
        $status = in_array($_POST['status'] ?? '', ['active', 'discontinued'], true) ? $_POST['status'] : 'active';

        Database::execute(
            'UPDATE inventory_items 
             SET name = ?, item_code = ?, category_id = ?, unit = ?, unit_price = ?, min_threshold = ?, location = ?, status = ?, updated_at = NOW() 
             WHERE id = ? AND school_id = ?',
            [$name, $itemCode, $catId, $unit, $unitPrice, $minThreshold, $location, $status, $itemId, $schoolId]
        );

        flash('success', 'Item details updated.');
        redirect(url('inventory?tab=items'));
    }

    public function destroyItem(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        Database::execute('DELETE FROM inventory_items WHERE id = ? AND school_id = ?', [(int)$id, $schoolId]);
        flash('success', 'Item removed from inventory.');
        redirect(url('inventory?tab=items'));
    }

    public function storeTransaction(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $itemId = (int)($_POST['item_id'] ?? 0);
        $type = in_array($_POST['type'] ?? '', ['in', 'out'], true) ? $_POST['type'] : 'in';
        $quantity = (int)($_POST['quantity'] ?? 0);
        $supplierId = (int)($_POST['supplier_id'] ?? 0) ?: null;
        $unitPrice = (float)($_POST['unit_price'] ?? 0.0);
        $refNo = trim((string)($_POST['reference_no'] ?? ''));
        $notes = trim((string)($_POST['notes'] ?? ''));
        $issuedToType = in_array($_POST['issued_to_type'] ?? '', ['staff', 'student', 'department', 'general'], true) ? $_POST['issued_to_type'] : null;

        if (!$itemId || $quantity <= 0) {
            flash('error', 'Valid item and positive quantity required.');
            redirect(url('inventory?tab=transactions'));
        }

        $item = Database::fetch('SELECT * FROM inventory_items WHERE id = ? AND school_id = ? LIMIT 1', [$itemId, $schoolId]);
        if (!$item) {
            flash('error', 'Item not found.');
            redirect(url('inventory?tab=transactions'));
        }

        if ($type === 'out' && $item['quantity'] < $quantity) {
            flash('error', 'Insufficient stock! Available quantity is only ' . $item['quantity'] . ' ' . $item['unit']);
            redirect(url('inventory?tab=transactions'));
        }

        $unitPrice = ($unitPrice > 0) ? $unitPrice : (float)$item['unit_price'];
        $totalPrice = $unitPrice * $quantity;

        Database::beginTransaction();
        try {
            Database::insert(
                'INSERT INTO inventory_transactions 
                 (school_id, item_id, supplier_id, type, quantity, unit_price, total_price, reference_no, issued_to_type, notes, created_by, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                [$schoolId, $itemId, $supplierId, $type, $quantity, $unitPrice, $totalPrice, $refNo, $issuedToType, $notes, (int)Auth::id()]
            );

            // Update item stock level
            $newQty = ($type === 'in') ? ($item['quantity'] + $quantity) : ($item['quantity'] - $quantity);
            Database::execute('UPDATE inventory_items SET quantity = ?, updated_at = NOW() WHERE id = ?', [$newQty, $itemId]);

            Database::commit();
            flash('success', 'Stock ' . strtoupper($type) . ' transaction recorded. New balance: ' . $newQty . ' ' . $item['unit']);
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', 'Transaction error: ' . $e->getMessage());
        }

        redirect(url('inventory?tab=transactions'));
    }

    public function storeSupplier(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        $person = trim((string)($_POST['contact_person'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $address = trim((string)($_POST['address'] ?? ''));

        if ($name === '') {
            flash('error', 'Supplier name required.');
            redirect(url('inventory?tab=suppliers'));
        }

        Database::insert(
            'INSERT INTO inventory_suppliers (school_id, name, contact_person, phone, email, address, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [$schoolId, $name, $person, $phone, $email, $address]
        );

        flash('success', 'Supplier registered.');
        redirect(url('inventory?tab=suppliers'));
    }

    public function storeCategory(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        $desc = trim((string)($_POST['description'] ?? ''));

        if ($name === '') {
            flash('error', 'Category name required.');
            redirect(url('inventory?tab=categories'));
        }

        Database::insert(
            'INSERT INTO inventory_categories (school_id, name, description, created_at, updated_at) 
             VALUES (?, ?, ?, NOW(), NOW())',
            [$schoolId, $name, $desc]
        );

        flash('success', 'Inventory category created.');
        redirect(url('inventory?tab=categories'));
    }

    public function exportCsv(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $items = Database::fetchAll(
            'SELECT i.item_code, i.name, c.name AS category_name, i.unit, i.quantity, i.unit_price, (i.quantity * i.unit_price) AS total_val, i.min_threshold, i.location, i.status 
             FROM inventory_items i 
             LEFT JOIN inventory_categories c ON c.id = i.category_id 
             WHERE i.school_id = ? ORDER BY i.name ASC',
            [$schoolId]
        );

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=inventory_report_' . date('Ymd_His') . '.csv');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Item Code', 'Item Name', 'Category', 'Unit', 'Stock Qty', 'Unit Price', 'Total Valuation', 'Min Threshold', 'Location', 'Status']);
        foreach ($items as $r) {
            fputcsv($out, [
                $r['item_code'],
                $r['name'],
                $r['category_name'] ?? 'Uncategorized',
                $r['unit'],
                $r['quantity'],
                number_format((float)$r['unit_price'], 2),
                number_format((float)$r['total_val'], 2),
                $r['min_threshold'],
                $r['location'] ?? '',
                ucfirst($r['status']),
            ]);
        }
        fclose($out);
        exit;
    }
}
