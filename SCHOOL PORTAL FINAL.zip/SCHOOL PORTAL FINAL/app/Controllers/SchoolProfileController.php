<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;

final class SchoolProfileController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $role = Auth::roleSlug();
        if ($role === 'student' || $role === 'parent') {
            (new StudentPortalController())->profile();
            return;
        }
        if (hasPermission('settings.manage')) {
            redirect(url('settings'));
            return;
        }
        redirect(url('dashboard'));
    }

    public function update(): void
    {
        Auth::requireLogin();
        requirePermission('settings.manage');
        redirect(url('settings'));
    }
}
