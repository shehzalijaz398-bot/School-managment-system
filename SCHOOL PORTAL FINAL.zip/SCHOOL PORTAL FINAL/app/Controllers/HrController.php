<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Candidate;
use App\Models\Employee;
use App\Models\LeaveRequest;
use App\Models\PayrollModel;
use App\Services\HrService;
use App\Services\PayrollService;
use Core\Controller;
use Core\Database;

final class HrController extends Controller
{
    public function employees(): void
    {
        requirePermission('employees.manage');
        
        $schoolId = $this->schoolId();
        $roles = Database::fetchAll("SELECT * FROM roles WHERE (school_id IS NULL OR school_id = ?) ORDER BY name", [$schoolId]);

        $search = trim($_GET['q'] ?? ($_GET['search'] ?? ''));
        $status = $_GET['status'] ?? '';
        $roleFilter = $_GET['role'] ?? '';
        $departmentId = isset($_GET['department_id']) && $_GET['department_id'] !== '' ? (int)$_GET['department_id'] : null;

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = isset($_GET['limit']) && in_array((int)$_GET['limit'], [10, 25, 50, 100], true) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        $sql = 'SELECT e.*, d.name AS department, des.name AS designation, 
                       u.id as user_id, u.email as portal_email, r.name as role_name, r.slug as role_slug
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN users u ON u.employee_id = e.id AND u.school_id = e.school_id
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE e.school_id = ?';
        $params = [$schoolId];

        if ($search !== '') {
            $sql .= ' AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ? OR e.email LIKE ? OR e.phone LIKE ? OR des.name LIKE ? OR d.name LIKE ?)';
            $q = "%$search%";
            $params = array_merge($params, [$q, $q, $q, $q, $q, $q, $q]);
        }
        
        if ($status !== '' && $status !== 'all') {
            $sql .= ' AND e.status = ?';
            $params[] = $status;
        }
        
        if ($roleFilter !== '' && $roleFilter !== 'all') {
            $sql .= ' AND (r.slug = ? OR r.name = ?)';
            $params[] = $roleFilter;
            $params[] = $roleFilter;
        }

        if ($departmentId !== null) {
            $sql .= ' AND e.department_id = ?';
            $params[] = $departmentId;
        }

        // Count total
        $countSql = str_replace(
            'e.*, d.name AS department, des.name AS designation, 
                       u.id as user_id, u.email as portal_email, r.name as role_name, r.slug as role_slug',
            'COUNT(DISTINCT e.id) AS total',
            $sql
        );
        $totalRow = Database::fetch($countSql, $params);
        $total = (int)($totalRow['total'] ?? 0);
        $totalPages = max(1, (int)ceil($total / $limit));

        $sort = $_GET['sort'] ?? 'name';
        $dir = (isset($_GET['dir']) && strtolower($_GET['dir']) === 'desc') ? 'DESC' : 'ASC';
        $orderClause = match ($sort) {
            'joined_on' => "e.joining_date {$dir}",
            'code' => "e.employee_code {$dir}",
            'status' => "e.status {$dir}, e.first_name ASC",
            default => "e.first_name {$dir}, e.last_name {$dir}"
        };

        $sql .= " ORDER BY {$orderClause} LIMIT {$limit} OFFSET {$offset}";
        $employees = Database::fetchAll($sql, $params);

        $startRecord = $total > 0 ? ($offset + 1) : 0;
        $endRecord = min($offset + $limit, $total);

        $this->view('hr/employees', [
            'title' => 'Staff Directory',
            'employees' => $employees,
            'departments' => Database::fetchAll('SELECT * FROM departments WHERE school_id = ? ORDER BY name', [$schoolId]),
            'designations' => Database::fetchAll('SELECT * FROM designations WHERE school_id = ? ORDER BY name', [$schoolId]),
            'roles' => $roles,
            'filters' => ['q' => $search, 'status' => $status, 'role' => $roleFilter, 'department_id' => $departmentId],
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => $totalPages,
            'startRecord' => $startRecord,
            'endRecord' => $endRecord,
            'sort' => $sort,
            'dir' => strtolower($dir),
        ]);
    }

    public function showEmployee(string $id): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $empId = (int) $id;

        $employee = Database::fetch(
            'SELECT e.*, d.name AS department_name, des.name AS designation_name,
                    u.id AS user_id, u.email AS user_email, u.phone AS user_phone, u.status AS user_status,
                    r.name AS role_name, r.slug AS role_slug
             FROM employees e
             LEFT JOIN departments d ON d.id = e.department_id AND d.school_id = e.school_id
             LEFT JOIN designations des ON des.id = e.designation_id AND des.school_id = e.school_id
             LEFT JOIN users u ON u.employee_id = e.id AND u.school_id = e.school_id
             LEFT JOIN roles r ON r.id = u.role_id
             WHERE e.id = ? AND e.school_id = ? LIMIT 1',
            [$empId, $schoolId]
        );

        if (!$employee) {
            flash('error', 'Staff member not found.');
            redirect(url('staff'));
            return;
        }

        // Attendance stats in last 90 days
        $attRows = Database::fetchAll(
            'SELECT status, COUNT(*) AS count FROM staff_attendance 
             WHERE employee_id = ? AND school_id = ? AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
             GROUP BY status',
            [$empId, $schoolId]
        );
        $attCounts = ['present' => 0, 'absent' => 0, 'late' => 0, 'half_day' => 0];
        $totalAtt = 0;
        foreach ($attRows as $ar) {
            $st = $ar['status'];
            $c = (int) $ar['count'];
            $attCounts[$st] = $c;
            $totalAtt += $c;
        }
        $presentCount = $attCounts['present'] + $attCounts['late'];
        $attRate = $totalAtt > 0 ? round(($presentCount / $totalAtt) * 100, 1) : 100.0;

        // Recent payroll records
        $payrolls = Database::fetchAll(
            'SELECT * FROM payroll WHERE employee_id = ? AND school_id = ? ORDER BY month DESC LIMIT 6',
            [$empId, $schoolId]
        );

        // Recent leaves
        $leaves = Database::fetchAll(
            'SELECT lr.*, lt.name AS leave_type_name
             FROM leave_requests lr
             LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
             WHERE lr.employee_id = ? AND lr.school_id = ?
             ORDER BY lr.created_at DESC LIMIT 6',
            [$empId, $schoolId]
        );

        // Assigned classes if teacher
        $teacher = Database::fetch(
            'SELECT * FROM teachers WHERE employee_id = ? AND school_id = ? LIMIT 1',
            [$empId, $schoolId]
        );
        $timetableSlots = [];
        if ($teacher) {
            $timetableSlots = Database::fetchAll(
                'SELECT tt.*, c.name AS class_name, sec.name AS section_name, sub.name AS subject_name,
                        tp.name AS period_name, tp.start_time, tp.end_time
                 FROM timetables tt
                 JOIN classes c ON c.id = tt.class_id
                 LEFT JOIN sections sec ON sec.id = tt.section_id
                 JOIN subjects sub ON sub.id = tt.subject_id
                 JOIN timetable_periods tp ON tp.id = tt.period_id
                 WHERE tt.teacher_id = ? AND tt.school_id = ?
                 ORDER BY tt.day_of_week ASC, tp.period_number ASC',
                [(int)$teacher['id'], $schoolId]
            );
        }

        // Activity & Audit Timeline
        $timelineLogs = Database::fetchAll(
            'SELECT a.*, u.name AS author_name, r.name AS author_role
             FROM audit_logs a
             LEFT JOIN users u ON u.id = a.user_id
             LEFT JOIN roles r ON r.id = u.role_id
             WHERE a.school_id = ? AND (
                 (a.entity_type = "employees" AND a.entity_id = ?) OR
                 (a.entity_type = "staff" AND a.entity_id = ?) OR
                 (a.user_id = ?)
             )
             ORDER BY a.created_at DESC LIMIT 20',
            [$schoolId, $empId, $empId, (int) ($employee['user_id'] ?? 0)]
        );

        $hrService = new HrService();
        $fullProfile = $hrService->getStaffFullProfile($schoolId, $empId);

        $this->view('hr/show', [
            'title' => trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')) . ' — Staff Profile',
            'employee' => $fullProfile['employee'] ?? $employee,
            'attendance_rate' => $attRate,
            'attendance_counts' => $attCounts,
            'total_attendance_days' => $totalAtt,
            'payrolls' => $payrolls,
            'leaves' => $leaves,
            'teacher' => $teacher,
            'timetableSlots' => $timetableSlots,
            'timeline_logs' => $timelineLogs,
            'qualifications' => $fullProfile['qualifications'] ?? [],
            'contracts' => $fullProfile['contracts'] ?? [],
            'reviews' => $fullProfile['reviews'] ?? [],
            'trainings' => $fullProfile['trainings'] ?? [],
            'tasks' => $fullProfile['tasks'] ?? [],
            'leave_balances' => $fullProfile['leave_balances'] ?? [],
            'salary_structure' => $fullProfile['salary_structure'] ?? null,
        ]);
    }

    public function createEmployee(): void
    {
        requirePermission('employees.manage');
        $schoolId = $this->schoolId();

        $departments = Database::fetchAll('SELECT * FROM departments WHERE school_id = ? ORDER BY name ASC', [$schoolId]);
        $designations = Database::fetchAll('SELECT * FROM designations WHERE school_id = ? ORDER BY name ASC', [$schoolId]);
        $roles = Database::fetchAll("SELECT * FROM roles WHERE (school_id IS NULL OR school_id = ?) ORDER BY name ASC", [$schoolId]);

        $nextCode = (new Employee())->nextCode();

        $this->view('hr/create', [
            'title'        => 'Add New Staff',
            'departments'  => $departments,
            'designations' => $designations,
            'roles'        => $roles,
            'nextCode'     => $nextCode,
        ]);
    }

    public function storeEmployee(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'first_name' => 'required|max:100',
            'last_name'  => 'required|max:100',
            'email'      => 'required|email|max:191',
        ]);

        $model = new Employee();
        $code = !empty($_POST['employee_code']) ? trim((string)$_POST['employee_code']) : $model->nextCode();

        // Department mapping
        $departmentId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

        // Designation mapping (handle select or custom title)
        $designationId = !empty($_POST['designation_id']) ? (int)$_POST['designation_id'] : null;
        if (!$designationId && !empty($_POST['designation_title'])) {
            $desName = trim((string)$_POST['designation_title']);
            $existingDes = Database::fetch('SELECT id FROM designations WHERE name = ? AND school_id = ? LIMIT 1', [$desName, $this->schoolId()]);
            if ($existingDes) {
                $designationId = (int)$existingDes['id'];
            } else {
                $designationId = Database::insert(
                    'INSERT INTO designations (school_id, name, status, created_at, updated_at) VALUES (?, ?, 1, NOW(), NOW())',
                    [$this->schoolId(), $desName]
                );
            }
        }

        // Full name with middle name
        $middleName = trim((string)($_POST['middle_name'] ?? ''));
        $firstName = $data['first_name'];
        if ($middleName !== '') {
            $firstName .= ' ' . $middleName;
        }

        // Address aggregation
        $addressParts = array_filter([
            $_POST['street_address'] ?? '',
            $_POST['city'] ?? '',
            $_POST['state'] ?? '',
            $_POST['zip'] ?? '',
            $_POST['country'] ?? ''
        ]);
        $fullAddress = !empty($addressParts) ? implode(', ', $addressParts) : ($_POST['address'] ?? null);

        // Emergency Contact string
        $emergencyParts = array_filter([
            $_POST['emergency_contact_name'] ?? '',
            $_POST['emergency_contact_relation'] ?? '',
            $_POST['emergency_contact_phone'] ?? ''
        ]);
        $emergencyContact = !empty($emergencyParts) ? implode(' - ', $emergencyParts) : ($_POST['emergency_contact'] ?? null);

        // Dates
        $dob = !empty($_POST['date_of_birth']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['date_of_birth']))) : null;
        $joinedDate = !empty($_POST['joining_date']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['joining_date']))) : date('Y-m-d');

        $payload = [
            'employee_code'   => $code,
            'first_name'      => $firstName,
            'last_name'       => $data['last_name'],
            'email'           => $data['email'],
            'phone'           => $_POST['phone'] ?? null,
            'gender'          => $_POST['gender'] ?? null,
            'address'         => $fullAddress,
            'date_of_birth'   => $dob,
            'department_id'   => $departmentId,
            'designation_id'  => $designationId,
            'employment_type' => $_POST['employment_model'] ?? ($_POST['employment_type'] ?? 'Full-time'),
            'joining_date'    => $joinedDate,
            'emergency_contact' => $emergencyContact,
            'status'          => !empty($_POST['status']) ? $_POST['status'] : 'active',
        ];

        if (!empty($_FILES['profile_image']['name'])) {
            $payload['profile_image'] = upload_file($_FILES['profile_image'], 'profiles', app_config('upload.allowed_images'));
        }

        $id = $model->create($payload);

        // Create user account if requested or if role is selected
        $createAccount = !empty($_POST['create_user_account']) || !empty($_POST['role_id']);
        $credentials = null;
        if ($createAccount) {
            $roleId = !empty($_POST['role_id']) ? (int)$_POST['role_id'] : null;
            if (!$roleId) {
                $staffRole = Database::fetch("SELECT id FROM roles WHERE slug IN ('accountant', 'finance', 'teacher', 'staff') AND (school_id IS NULL OR school_id = ?) ORDER BY id DESC LIMIT 1", [$this->schoolId()]);
                $roleId = (int)($staffRole['id'] ?? 0);
            }

            if ($roleId > 0 && !empty($data['email'])) {
                $rawPassword = !empty($_POST['password']) ? trim((string)$_POST['password']) : 'Staff@123';
                $roleRow = Database::fetch("SELECT * FROM roles WHERE id = ?", [$roleId]);
                $school = currentSchool();

                $existingUser = Database::fetch('SELECT id FROM users WHERE email = ? AND school_id = ? LIMIT 1', [$data['email'], $this->schoolId()]);
                if (!$existingUser) {
                    $userId = (new \App\Models\User())->create([
                        'school_id'   => $this->schoolId(),
                        'role_id'     => $roleId,
                        'employee_id' => $id,
                        'name'        => $firstName . ' ' . $data['last_name'],
                        'email'       => $data['email'],
                        'phone'       => $_POST['phone'] ?? null,
                        'password'    => password_hash($rawPassword, PASSWORD_DEFAULT),
                        'status'      => 1
                    ]);
                } else {
                    Database::execute(
                        'UPDATE users SET role_id = ?, employee_id = ?, password = ?, status = 1, updated_at = NOW() WHERE id = ?',
                        [$roleId, $id, password_hash($rawPassword, PASSWORD_DEFAULT), $existingUser['id']]
                    );
                    $userId = (int)$existingUser['id'];
                }

                $credentials = [
                    'user_id'       => $userId,
                    'staff_id'      => $id,
                    'name'          => $firstName . ' ' . $data['last_name'],
                    'employee_code' => $code,
                    'email'         => $data['email'],
                    'password'      => $rawPassword,
                    'role_name'     => $roleRow['name'] ?? 'Staff',
                    'role_slug'     => $roleRow['slug'] ?? 'staff',
                    'school_name'   => $school['name'] ?? 'School Portal',
                    'school_code'   => $school['code'] ?? '',
                    'login_url'     => url('login'),
                    'is_accountant' => in_array($roleRow['slug'] ?? '', ['accountant', 'finance'], true),
                    'timestamp'     => date('d M Y, h:i A'),
                ];
                $_SESSION['new_staff_credentials'] = $credentials;
            }
        }

        auditLog('employee.create', 'hr', 'employees', $id);
        if ($credentials) {
            flash('success', "Staff member added successfully! Login credentials generated for {$credentials['name']} ({$credentials['role_name']}).");
        } else {
            flash('success', 'Staff member added successfully.');
        }
        redirect(url('staff'));
    }

    public function resetStaffPassword(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();
        $employee = (new Employee())->find((int) $id);
        if (!$employee || (int)$employee['school_id'] !== (int)$schoolId) {
            flash('error', 'Staff member not found.');
            redirect(url('staff'));
            return;
        }

        $email = trim($_POST['email'] ?? $employee['email'] ?? '');
        if (empty($email)) {
            flash('error', 'Staff member does not have a valid email address for login.');
            redirect(url('staff'));
            return;
        }

        $rawPassword = !empty($_POST['password']) ? trim((string)$_POST['password']) : 'Staff@' . rand(100, 999);
        $roleId = !empty($_POST['role_id']) ? (int)$_POST['role_id'] : null;

        // Check if user already exists
        $user = Database::fetch('SELECT * FROM users WHERE (employee_id = ? OR email = ?) AND school_id = ? LIMIT 1', [$id, $email, $schoolId]);
        if ($user) {
            $effectiveRoleId = $roleId ?: (int)$user['role_id'];
            Database::execute(
                'UPDATE users SET password = ?, role_id = ?, email = ?, status = 1, updated_at = NOW() WHERE id = ?',
                [password_hash($rawPassword, PASSWORD_DEFAULT), $effectiveRoleId, $email, $user['id']]
            );
            $userId = (int)$user['id'];
        } else {
            if (!$roleId) {
                $defaultRole = Database::fetch("SELECT id FROM roles WHERE slug IN ('accountant', 'finance', 'staff', 'teacher') AND (school_id IS NULL OR school_id = ?) ORDER BY id DESC LIMIT 1", [$schoolId]);
                $roleId = (int)($defaultRole['id'] ?? 0);
            }
            $userId = (new \App\Models\User())->create([
                'school_id'   => $schoolId,
                'role_id'     => $roleId,
                'employee_id' => (int)$id,
                'name'        => trim($employee['first_name'] . ' ' . $employee['last_name']),
                'email'       => $email,
                'phone'       => $employee['phone'] ?? null,
                'password'    => password_hash($rawPassword, PASSWORD_DEFAULT),
                'status'      => 1
            ]);
            $effectiveRoleId = $roleId;
        }

        $roleRow = Database::fetch("SELECT * FROM roles WHERE id = ?", [$effectiveRoleId]);
        $school = currentSchool();

        $_SESSION['new_staff_credentials'] = [
            'user_id'       => $userId,
            'staff_id'      => $id,
            'name'          => trim($employee['first_name'] . ' ' . $employee['last_name']),
            'employee_code' => $employee['employee_code'] ?? '',
            'email'         => $email,
            'password'      => $rawPassword,
            'role_name'     => $roleRow['name'] ?? 'Staff',
            'role_slug'     => $roleRow['slug'] ?? 'staff',
            'school_name'   => $school['name'] ?? 'School Portal',
            'school_code'   => $school['code'] ?? '',
            'login_url'     => url('login'),
            'is_accountant' => in_array($roleRow['slug'] ?? '', ['accountant', 'finance'], true),
            'timestamp'     => date('d M Y, h:i A'),
            'is_reset'      => true,
        ];

        auditLog('employee.password_reset', 'hr', 'employees', (int)$id);
        flash('success', "Password successfully updated for {$employee['first_name']} {$employee['last_name']}! Login credentials are shown below.");
        redirect(url('staff'));
    }

    public function editEmployee(string $id): void
    {
        requirePermission('employees.manage');
        $employee = (new Employee())->find((int) $id);
        if (!$employee || $employee['school_id'] !== $this->schoolId()) {
            flash('error', 'Employee not found.');
            redirect(url('hr/employees'));
        }
        $this->view('hr/employee_edit', [
            'title' => 'Edit Employee',
            'employee' => $employee,
            'departments' => Database::fetchAll('SELECT * FROM departments WHERE school_id = ?', [$this->schoolId()]),
            'designations' => Database::fetchAll('SELECT * FROM designations WHERE school_id = ?', [$this->schoolId()]),
        ]);
    }

    public function updateEmployee(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $employee = (new Employee())->find((int) $id);
        if (!$employee || $employee['school_id'] !== $this->schoolId()) {
            flash('error', 'Employee not found.');
            redirect(url('hr/employees'));
        }
        $data = $this->validate($_POST, [
            'first_name' => 'required',
            'last_name' => 'required',
        ]);
        (new Employee())->update((int) $id, [
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $_POST['email'] ?? null,
            'phone' => $_POST['phone'] ?? null,
            'gender' => $_POST['gender'] ?? null,
            'department_id' => !empty($_POST['department_id']) ? $_POST['department_id'] : null,
            'designation_id' => !empty($_POST['designation_id']) ? $_POST['designation_id'] : null,
            'joining_date' => !empty($_POST['joining_date']) ? $_POST['joining_date'] : date('Y-m-d'),
            'status' => $_POST['status'] ?? 'active',
        ]);
        auditLog('employee.update', 'hr', 'employees', (int) $id);
        flash('success', 'Employee updated.');
        redirect(url('hr/employees'));
    }

    public function destroyEmployee(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $employee = (new Employee())->find((int) $id);
        if (!$employee || $employee['school_id'] !== $this->schoolId()) {
            flash('error', 'Employee not found.');
            redirect(url('hr/employees'));
        }
        (new Employee())->update((int) $id, [
            'status' => 'inactive',
        ]);
        auditLog('employee.deactivate', 'hr', 'employees', (int) $id);
        flash('success', 'Employee deactivated successfully.');
        redirect(url('hr/employees'));
    }

    public function candidates(): void
    {
        requirePermission('recruitment.manage');
        $this->view('hr/candidates', [
            'title' => 'Recruitment',
            'candidates' => (new Candidate())->listAll(),
            'departments' => Database::fetchAll('SELECT * FROM departments WHERE school_id = ?', [$this->schoolId()]),
        ]);
    }

    public function storeCandidate(): void
    {
        requirePermission('recruitment.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'first_name' => 'required',
            'last_name' => 'required',
            'position_applied' => 'required',
        ]);
        $id = (new Candidate())->create([
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $_POST['email'] ?? null,
            'phone' => $_POST['phone'] ?? null,
            'position_applied' => $data['position_applied'],
            'department_id' => $_POST['department_id'] ?: null,
            'status' => $_POST['status'] ?? 'applied',
            'notes' => $_POST['notes'] ?? null,
        ]);
        auditLog('candidate.create', 'hr', 'candidates', $id);
        flash('success', 'Candidate added.');
        redirect(url('hr/candidates'));
    }

    public function updateCandidateStatus(string $id): void
    {
        requirePermission('recruitment.manage');
        $this->requireCsrf();
        (new Candidate())->update((int) $id, ['status' => $_POST['status']]);
        flash('success', 'Candidate status updated.');
        redirect(url('hr/candidates'));
    }

    public function hire(string $id): void
    {
        requirePermission('recruitment.manage');
        $this->requireCsrf();
        try {
            $empId = (new HrService())->hireCandidate((int) $id, [
                'as_teacher' => !empty($_POST['as_teacher']),
                'basic_salary' => (float) ($_POST['basic_salary'] ?? 0),
                'house_allowance' => (float) ($_POST['house_allowance'] ?? 0),
                'transport_allowance' => (float) ($_POST['transport_allowance'] ?? 0),
                'joining_date' => $_POST['joining_date'] ?? date('Y-m-d'),
                'designation_id' => $_POST['designation_id'] ?: null,
            ]);
            flash('success', 'Candidate hired as employee #' . $empId . '. Finance has been notified.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('hr/candidates'));
    }

    public function leaves(): void
    {
        requirePermission('leave.manage');
        $this->view('hr/leaves', [
            'title' => 'Leave Requests',
            'leaves' => (new LeaveRequest())->listAll(),
        ]);
    }
    public function payrollAutomationForm(): void
    {
        requirePermission('payroll.manage');
        $schoolId = $this->schoolId();
        
        $months = [];
        for ($i = 0; $i < 6; $i++) {
            $months[] = date('Y-m', strtotime("-$i months"));
        }
        
        $employees = \Core\Database::fetchAll("SELECT id FROM employees WHERE school_id = ? AND status = 'active'", [$schoolId]);
        
        $this->view('hr/payroll_automation', [
            'title' => 'Automated Payroll Engine',
            'months' => $months,
            'active_employees' => count($employees)
        ]);
    }

    public function processMassPayroll(): void
    {
        requirePermission('payroll.manage');
        $this->requireCsrf();

        $month = trim((string) ($_POST['payroll_month'] ?? date('Y-m')));
        $deductionPerDay = (float) ($_POST['deduction_per_day'] ?? 0.0);
        $bonusMultiplier = (float) ($_POST['bonus_multiplier'] ?? 1.0);

        if ($month === '') {
            flash('error', 'Payroll month is required.');
            redirect(url('hr/payroll/auto-generate'));
            return;
        }

        try {
            $result = (new PayrollService())->generateMonthlyPayroll($month, $deductionPerDay, $bonusMultiplier);
            flash('success', "Mass Payroll calculated successfully! Processed {$result['processed']} records. Skipped {$result['skipped']} existing.");
        } catch (\Throwable $e) {
            flash('error', 'Error generating payroll: ' . $e->getMessage());
        }

        redirect(url('hr/payroll/auto-generate'));
    }

    public function streamPayslipPdf(string $id): void
    {
        requirePermission('payroll.manage');
        $this->authorizeTenantResource('payroll', (int) $id);

        try {
            $data = (new PayrollService())->getPayslipDetails((int) $id);

            $this->view('hr/payslip_pdf', [
                'title' => 'Payslip - ' . $data['payroll']['payroll_month'],
                'payroll' => $data['payroll'],
                'items' => $data['items'],
                'school' => $data['school'],
            ], 'layouts/print');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('finance/payroll'));
        }
    }

    public function exportStaffCsv(): void
    {
        requirePermission('employees.manage');
        $schoolId = $this->schoolId();

        $sql = 'SELECT e.employee_code, e.first_name, e.last_name, 
                       des.name AS designation, d.name AS department, 
                       e.email, e.phone, r.name AS role_name, e.joining_date, e.status
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN users u ON u.employee_id = e.id AND u.school_id = e.school_id
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE e.school_id = ? ORDER BY e.first_name, e.last_name';
        $rows = Database::fetchAll($sql, [$schoolId]);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="staff_directory_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Employee Code', 'First Name', 'Last Name', 'Designation', 'Department', 'Email', 'Phone', 'System Role', 'Joined On', 'Status']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['employee_code'],
                $r['first_name'],
                $r['last_name'],
                $r['designation'] ?? 'Staff',
                $r['department'] ?? 'General',
                $r['email'] ?? '',
                $r['phone'] ?? '',
                $r['role_name'] ?? 'No Access',
                $r['joining_date'] ?? '',
                ucfirst($r['status'])
            ]);
        }
        fclose($out);
        exit;
    }

    public function bulkActionStaff(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();

        $action = $_POST['action'] ?? '';
        $rawIds = $_POST['staff_ids'] ?? [];
        if (!is_array($rawIds) || empty($rawIds)) {
            flash('error', 'No staff members selected.');
            redirect(url('staff'));
            return;
        }

        $ids = array_map('intval', $rawIds);
        $schoolId = $this->schoolId();
        $model = new Employee();

        if ($action === 'status') {
            $newStatus = $_POST['bulk_status'] ?? 'active';
            $valid = ['active', 'inactive', 'suspended', 'terminated', 'on_leave'];
            if (!in_array($newStatus, $valid, true)) {
                flash('error', 'Invalid status specified.');
                redirect(url('staff'));
                return;
            }

            $count = 0;
            foreach ($ids as $eId) {
                $emp = Database::fetch('SELECT id FROM employees WHERE id = ? AND school_id = ?', [$eId, $schoolId]);
                if ($emp) {
                    $model->update($eId, ['status' => $newStatus]);
                    $count++;
                }
            }
            flash('success', "Updated status for {$count} staff member(s) to " . ucfirst($newStatus) . ".");
        } elseif ($action === 'deactivate') {
            $count = 0;
            foreach ($ids as $eId) {
                $emp = Database::fetch('SELECT id FROM employees WHERE id = ? AND school_id = ?', [$eId, $schoolId]);
                if ($emp) {
                    $model->update($eId, ['status' => 'inactive']);
                    $count++;
                }
            }
            flash('success', "Deactivated {$count} staff member(s).");
        }

        redirect(url('staff'));
    }

    public function bulkImportStaff(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();

        if (empty($_FILES['csv_file']['tmp_name']) || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
            flash('error', 'Please upload a valid CSV file.');
            redirect(url('staff'));
            return;
        }

        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if (!$handle) {
            flash('error', 'Unable to read the uploaded CSV file.');
            redirect(url('staff'));
            return;
        }

        $header = fgetcsv($handle);
        if (!$header) {
            fclose($handle);
            flash('error', 'The CSV file is empty.');
            redirect(url('staff'));
            return;
        }

        $header = array_map(fn($h) => strtolower(trim($h)), $header);
        $schoolId = $this->schoolId();
        $model = new Employee();
        $imported = 0;

        while (($row = fgetcsv($handle)) !== false) {
            if (empty(array_filter($row))) continue;
            $record = array_combine($header, array_pad($row, count($header), ''));
            if (!$record) continue;

            $first = trim($record['first_name'] ?? '');
            $last = trim($record['last_name'] ?? '');
            if ($first === '') continue;

            $code = trim($record['employee_code'] ?? '');
            if ($code === '' || Database::fetch('SELECT id FROM employees WHERE employee_code = ? AND school_id = ?', [$code, $schoolId])) {
                $code = $model->nextCode();
            }

            $model->create([
                'employee_code' => $code,
                'first_name' => $first,
                'last_name' => $last,
                'email' => trim($record['email'] ?? ''),
                'phone' => trim($record['phone'] ?? ''),
                'joining_date' => trim($record['joining_date'] ?? date('Y-m-d')),
                'status' => 'active',
            ]);
            $imported++;
        }

        fclose($handle);
        flash('success', "Successfully imported {$imported} staff members.");
        redirect(url('staff'));
    }

    public function salaryStructures(): void
    {
        requirePermission('payroll.manage');
        $schoolId = $this->schoolId();

        $structures = Database::fetchAll(
            'SELECT ss.*, e.employee_code, e.first_name, e.last_name, d.name AS department, des.name AS designation
             FROM salary_structures ss
             INNER JOIN employees e ON e.id = ss.employee_id AND e.school_id = ss.school_id
             LEFT JOIN departments d ON d.id = e.department_id
             LEFT JOIN designations des ON des.id = e.designation_id
             WHERE ss.school_id = ?
             ORDER BY e.first_name ASC',
            [$schoolId]
        );

        $employees = Database::fetchAll(
            'SELECT id, employee_code, first_name, last_name FROM employees WHERE school_id = ? AND status = "active" ORDER BY first_name ASC',
            [$schoolId]
        );

        $this->view('hr/salary_structures', [
            'title' => 'Staff Salary Structures',
            'structures' => $structures,
            'employees' => $employees,
        ]);
    }

    public function storeSalaryStructure(): void
    {
        requirePermission('payroll.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $employeeId = (int) ($_POST['employee_id'] ?? 0);
        $basic = max(0.0, (float) ($_POST['basic_salary'] ?? 0));
        $house = max(0.0, (float) ($_POST['house_allowance'] ?? 0));
        $transport = max(0.0, (float) ($_POST['transport_allowance'] ?? 0));
        $other = max(0.0, (float) ($_POST['other_allowance'] ?? 0));
        $deductions = max(0.0, (float) ($_POST['deductions'] ?? 0));
        $effective = !empty($_POST['effective_from']) ? $_POST['effective_from'] : date('Y-m-d');

        if ($employeeId <= 0 || $basic <= 0) {
            flash('error', 'Select a valid employee and enter a positive basic salary.');
            redirect(url('hr/salary-structures'));
            return;
        }

        $existing = Database::fetch('SELECT id FROM salary_structures WHERE employee_id = ? AND school_id = ?', [$employeeId, $schoolId]);
        if ($existing) {
            Database::execute(
                'UPDATE salary_structures 
                 SET basic_salary = ?, house_allowance = ?, transport_allowance = ?, other_allowance = ?, deductions = ?, effective_from = ?, status = 1, updated_at = NOW()
                 WHERE id = ? AND school_id = ?',
                [$basic, $house, $transport, $other, $deductions, $effective, (int) $existing['id'], $schoolId]
            );
            auditLog('salary_structure.update', 'hr', 'salary_structures', (int) $existing['id']);
            flash('success', 'Salary structure updated successfully.');
        } else {
            $id = Database::insert(
                'INSERT INTO salary_structures
                 (school_id, employee_id, basic_salary, house_allowance, transport_allowance, other_allowance, deductions, effective_from, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                [$schoolId, $employeeId, $basic, $house, $transport, $other, $deductions, $effective]
            );
            auditLog('salary_structure.create', 'hr', 'salary_structures', $id);
            flash('success', 'Salary structure created successfully.');
        }

        redirect(url('hr/salary-structures'));
    }

    public function destroySalaryStructure(string $id): void
    {
        requirePermission('payroll.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();

        $structure = Database::fetch('SELECT id FROM salary_structures WHERE id = ? AND school_id = ?', [(int) $id, $schoolId]);
        if (!$structure) {
            flash('error', 'Salary structure not found.');
            redirect(url('hr/salary-structures'));
            return;
        }

        Database::execute('DELETE FROM salary_structures WHERE id = ? AND school_id = ?', [(int) $id, $schoolId]);
        auditLog('salary_structure.delete', 'hr', 'salary_structures', (int) $id);
        flash('success', 'Salary structure deleted.');
        redirect(url('hr/salary-structures'));
    }

    /**
     * Executive HR & Staff Management Dashboard
     */
    public function dashboard(): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $hrService = new HrService();
        $metrics = $hrService->getHrDashboardMetrics($schoolId, $_GET);

        $this->view('hr/dashboard', [
            'title'   => 'HR & Staff Operations Dashboard',
            'metrics' => $metrics,
            'filters' => [
                'department_id' => $_GET['department_id'] ?? '',
                'month'         => $_GET['month'] ?? date('Y-m'),
            ],
        ]);
    }

    /**
     * Shift Management
     */
    public function shifts(): void
    {
        requirePermission('employees.manage');
        $schoolId = (int) $this->schoolId();
        $hrService = new HrService();
        $shifts = $hrService->getShifts($schoolId);
        $employees = Database::fetchAll("SELECT id, first_name, last_name, employee_code, shift_id FROM employees WHERE school_id = ? AND status = 'active' ORDER BY first_name ASC", [$schoolId]);

        $this->view('hr/shifts', [
            'title'     => 'Staff Shifts & Work Timings',
            'shifts'    => $shifts,
            'employees' => $employees,
        ]);
    }

    public function storeShift(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            (new HrService())->saveShift($schoolId, $_POST);
            flash('success', 'Staff shift configured successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('hr/shifts'));
    }

    public function assignShift(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        $empId = (int) ($_POST['employee_id'] ?? 0);
        $shiftId = (int) ($_POST['shift_id'] ?? 0);

        if ($empId > 0 && $shiftId > 0) {
            (new HrService())->assignShift($schoolId, $empId, $shiftId);
            flash('success', 'Shift assigned to staff member successfully.');
        } else {
            flash('error', 'Select a valid staff member and shift.');
        }

        redirect(url('hr/shifts'));
    }

    /**
     * Institutional & School Holiday Calendar
     */
    public function holidays(): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $year = $_GET['year'] ?? date('Y');
        $holidays = (new HrService())->getHolidays($schoolId, $year);

        $this->view('hr/holidays', [
            'title'    => 'Holiday & Academic Breaks Calendar',
            'holidays' => $holidays,
            'year'     => $year,
        ]);
    }

    public function storeHoliday(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            (new HrService())->saveHoliday($schoolId, $_POST);
            flash('success', 'Holiday record saved successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('hr/holidays'));
    }

    public function destroyHoliday(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        (new HrService())->deleteHoliday($schoolId, (int) $id);
        flash('success', 'Holiday removed from calendar.');
        redirect(url('hr/holidays'));
    }

    /**
     * Staff Performance Reviews & Evaluations
     */
    public function performance(): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $hrService = new HrService();
        $empFilter = !empty($_GET['employee_id']) ? (int) $_GET['employee_id'] : null;

        $reviews = $hrService->getPerformanceReviews($schoolId, $empFilter);
        $employees = Database::fetchAll("SELECT id, first_name, last_name, employee_code FROM employees WHERE school_id = ? AND status = 'active' ORDER BY first_name ASC", [$schoolId]);

        $this->view('hr/performance', [
            'title'            => 'Staff Performance & Appraisals',
            'reviews'          => $reviews,
            'employees'        => $employees,
            'selectedEmployee' => $empFilter,
        ]);
    }

    public function storePerformanceReview(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $reviewerId = (int) $this->userId();

        try {
            (new HrService())->createPerformanceReview($schoolId, $_POST, $reviewerId);
            flash('success', 'Staff performance review recorded successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('hr/performance'));
    }

    /**
     * Staff Trainings & Professional Development
     */
    public function trainings(): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $empFilter = !empty($_GET['employee_id']) ? (int) $_GET['employee_id'] : null;

        $trainings = (new HrService())->getStaffTrainings($schoolId, $empFilter);
        $employees = Database::fetchAll("SELECT id, first_name, last_name, employee_code FROM employees WHERE school_id = ? AND status = 'active' ORDER BY first_name ASC", [$schoolId]);

        $this->view('hr/trainings', [
            'title'            => 'Professional Development & Training',
            'trainings'        => $trainings,
            'employees'        => $employees,
            'selectedEmployee' => $empFilter,
        ]);
    }

    public function storeTraining(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            (new HrService())->recordStaffTraining($schoolId, $_POST);
            flash('success', 'Professional development training record added.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('hr/trainings'));
    }

    /**
     * Role-Based Tasks & Deadlines
     */
    public function tasks(): void
    {
        requirePermission('employees.view');
        $schoolId = (int) $this->schoolId();
        $tasks = (new HrService())->getStaffTasks($schoolId, $_GET);
        $employees = Database::fetchAll("SELECT id, first_name, last_name, employee_code FROM employees WHERE school_id = ? AND status = 'active' ORDER BY first_name ASC", [$schoolId]);

        $this->view('hr/tasks', [
            'title'     => 'Staff Tasks & Delegated Workflows',
            'tasks'     => $tasks,
            'employees' => $employees,
            'filters'   => [
                'employee_id' => $_GET['employee_id'] ?? '',
                'status'      => $_GET['status'] ?? '',
                'priority'    => $_GET['priority'] ?? '',
            ],
        ]);
    }

    public function storeTask(): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $userId = (int) $this->userId();

        try {
            (new HrService())->createStaffTask($schoolId, $_POST, $userId);
            flash('success', 'Staff task assigned and dispatched.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('hr/tasks'));
    }

    public function updateTaskStatus(string $id): void
    {
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $status = $_POST['status'] ?? 'completed';
        $notes = $_POST['completion_notes'] ?? null;

        try {
            (new HrService())->updateStaffTaskStatus($schoolId, (int) $id, $status, $notes);
            flash('success', 'Task status updated.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        back();
    }

    /**
     * Qualification & Contract additions for employee profile
     */
    public function storeQualification(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $empId = (int) $id;

        try {
            $data = $_POST;
            if (!empty($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
                $data['document_path'] = upload_file($_FILES['document'], 'staff_docs', [
                    'application/pdf', 'image/jpeg', 'image/png'
                ]);
            }
            (new HrService())->addQualification($schoolId, $empId, $data);
            flash('success', 'Academic qualification added to staff record.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url("hr/employees/{$empId}?tab=qualifications"));
    }

    public function storeContract(string $id): void
    {
        requirePermission('employees.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $empId = (int) $id;

        try {
            $data = $_POST;
            if (!empty($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
                $data['document_path'] = upload_file($_FILES['document'], 'staff_contracts', [
                    'application/pdf', 'image/jpeg', 'image/png'
                ]);
            }
            (new HrService())->addContract($schoolId, $empId, $data);
            flash('success', 'Employment contract added.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url("hr/employees/{$empId}?tab=contracts"));
    }
}

