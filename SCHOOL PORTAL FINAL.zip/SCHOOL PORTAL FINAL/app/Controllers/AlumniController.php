<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class AlumniController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $tab = trim((string)($_GET['tab'] ?? 'members'));
        $year = (int)($_GET['year'] ?? 0);
        $q = trim((string)($_GET['q'] ?? ''));

        // Fetch Alumni
        $sql = 'SELECT a.*, s.first_name, s.last_name, s.admission_no as st_adm 
                FROM alumni_members a 
                LEFT JOIN students s ON s.id = a.student_id 
                WHERE a.school_id = ?';
        $params = [$schoolId];

        if ($year > 0) {
            $sql .= ' AND a.passing_year = ?';
            $params[] = $year;
        }
        if ($q !== '') {
            $sql .= ' AND (a.name LIKE ? OR a.current_profession LIKE ? OR a.organization LIKE ? OR a.higher_education LIKE ?)';
            $wild = '%' . $q . '%';
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }
        $sql .= ' ORDER BY a.passing_year DESC, a.name ASC';
        $alumni = Database::fetchAll($sql, $params);

        // Fetch Alumni Events
        $events = Database::fetchAll(
            'SELECT * FROM alumni_events WHERE school_id = ? ORDER BY event_date DESC',
            [$schoolId]
        );

        // Distinct years
        $years = Database::fetchAll(
            'SELECT DISTINCT passing_year FROM alumni_members WHERE school_id = ? ORDER BY passing_year DESC',
            [$schoolId]
        );

        // Students for dropdown
        $students = Database::fetchAll(
            'SELECT id, admission_no, first_name, last_name FROM students WHERE school_id = ? ORDER BY first_name ASC',
            [$schoolId]
        );

        // KPI stats
        $totalAlumni = (int)(Database::fetch('SELECT COUNT(*) AS c FROM alumni_members WHERE school_id = ?', [$schoolId])['c'] ?? 0);
        $totalBatches = count($years);
        $upcomingEvents = (int)(Database::fetch('SELECT COUNT(*) AS c FROM alumni_events WHERE school_id = ? AND event_date >= NOW() AND status = "upcoming"', [$schoolId])['c'] ?? 0);

        $this->view('alumni/index', [
            'title' => 'Alumni Association Network',
            'tab' => $tab,
            'alumni' => $alumni,
            'events' => $events,
            'years' => array_column($years, 'passing_year'),
            'students' => $students,
            'stats' => [
                'total_alumni' => $totalAlumni,
                'total_batches' => $totalBatches,
                'upcoming_events' => $upcomingEvents,
            ],
            'filters' => [
                'year' => $year,
                'q' => $q,
            ],
        ]);
    }

    public function storeMember(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        $studentId = (int)($_POST['student_id'] ?? 0) ?: null;
        $admissionNo = trim((string)($_POST['admission_no'] ?? ''));
        $passingYear = (int)($_POST['passing_year'] ?? date('Y'));
        $email = trim((string)($_POST['email'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $profession = trim((string)($_POST['current_profession'] ?? ''));
        $organization = trim((string)($_POST['organization'] ?? ''));
        $higherEd = trim((string)($_POST['higher_education'] ?? ''));
        $linkedin = trim((string)($_POST['linkedin_url'] ?? ''));

        if ($name === '') {
            flash('error', 'Alumni name is required.');
            redirect(url('alumni?tab=members'));
        }

        Database::insert(
            'INSERT INTO alumni_members 
             (school_id, student_id, name, admission_no, passing_year, email, phone, current_profession, organization, higher_education, linkedin_url, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active", NOW(), NOW())',
            [$schoolId, $studentId, $name, $admissionNo, $passingYear, $email, $phone, $profession, $organization, $higherEd, $linkedin]
        );

        flash('success', 'Alumni member registered successfully.');
        redirect(url('alumni?tab=members'));
    }

    public function storeEvent(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $title = trim((string)($_POST['title'] ?? ''));
        $eventDate = trim((string)($_POST['event_date'] ?? ''));
        $venue = trim((string)($_POST['venue'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $email = trim((string)($_POST['contact_email'] ?? ''));

        if ($title === '' || $eventDate === '') {
            flash('error', 'Event title and date are required.');
            redirect(url('alumni?tab=events'));
        }

        Database::insert(
            'INSERT INTO alumni_events 
             (school_id, title, event_date, venue, description, contact_email, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, "upcoming", NOW(), NOW())',
            [$schoolId, $title, $eventDate, $venue, $description, $email]
        );

        flash('success', 'Alumni event published.');
        redirect(url('alumni?tab=events'));
    }

    public function exportCsv(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $rows = Database::fetchAll(
            'SELECT name, admission_no, passing_year, email, phone, current_profession, organization, higher_education, linkedin_url 
             FROM alumni_members WHERE school_id = ? ORDER BY passing_year DESC',
            [$schoolId]
        );

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=alumni_directory_' . date('Ymd_His') . '.csv');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Alumni Name', 'Admission No', 'Graduation Year', 'Email', 'Phone', 'Profession', 'Organization', 'Higher Education', 'LinkedIn']);
        foreach ($rows as $r) {
            fputcsv($out, $r);
        }
        fclose($out);
        exit;
    }
}
