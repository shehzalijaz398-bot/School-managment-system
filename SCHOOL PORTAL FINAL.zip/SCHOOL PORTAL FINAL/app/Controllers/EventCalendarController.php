<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class EventCalendarController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $category = trim((string)($_GET['category'] ?? ''));
        $month = trim((string)($_GET['month'] ?? date('Y-m')));

        // Fetch events for selected month/year
        $sql = 'SELECT e.*, u.name as creator_name 
                FROM school_events e 
                LEFT JOIN users u ON u.id = e.created_by 
                WHERE e.school_id = ?';
        $params = [$schoolId];

        if ($category !== '') {
            $sql .= ' AND e.category = ?';
            $params[] = $category;
        }

        if ($month !== '') {
            $sql .= ' AND (DATE_FORMAT(e.start_date, "%Y-%m") = ? OR DATE_FORMAT(e.end_date, "%Y-%m") = ?)';
            $params[] = $month;
            $params[] = $month;
        }

        $sql .= ' ORDER BY e.start_date ASC, e.start_time ASC';
        $events = Database::fetchAll($sql, $params);

        // All events for counts
        $allEvents = Database::fetchAll('SELECT category, start_date, end_date FROM school_events WHERE school_id = ?', [$schoolId]);
        
        $totalEvents = count($allEvents);
        $totalHolidays = count(array_filter($allEvents, fn($e) => $e['category'] === 'holiday'));
        $totalExams = count(array_filter($allEvents, fn($e) => $e['category'] === 'exam'));
        $totalSports = count(array_filter($allEvents, fn($e) => $e['category'] === 'sports'));

        $this->view('events/index', [
            'title' => 'Academic Calendar & School Events',
            'events' => $events,
            'currentMonth' => $month,
            'selectedCategory' => $category,
            'stats' => [
                'total' => $totalEvents,
                'holidays' => $totalHolidays,
                'exams' => $totalExams,
                'sports' => $totalSports,
            ],
        ]);
    }

    public function store(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $title = trim((string)($_POST['title'] ?? ''));
        $category = in_array($_POST['category'] ?? '', ['academic', 'holiday', 'sports', 'cultural', 'exam', 'meeting', 'general'], true) ? $_POST['category'] : 'general';
        $startDate = trim((string)($_POST['start_date'] ?? ''));
        $endDate = trim((string)($_POST['end_date'] ?? '')) ?: $startDate;
        $startTime = trim((string)($_POST['start_time'] ?? '')) ?: null;
        $endTime = trim((string)($_POST['end_time'] ?? '')) ?: null;
        $venue = trim((string)($_POST['venue'] ?? ''));
        $audience = in_array($_POST['audience'] ?? '', ['all', 'teachers', 'students', 'parents', 'staff'], true) ? $_POST['audience'] : 'all';
        $description = trim((string)($_POST['description'] ?? ''));
        $color = trim((string)($_POST['color'] ?? '#4f46e5'));

        if ($title === '' || $startDate === '') {
            flash('error', 'Event title and start date are required.');
            redirect(url('calendar'));
        }

        Database::insert(
            'INSERT INTO school_events 
             (school_id, title, category, start_date, end_date, start_time, end_time, venue, audience, description, color, created_by, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [$schoolId, $title, $category, $startDate, $endDate, $startTime, $endTime, $venue, $audience, $description, $color, (int)Auth::id()]
        );

        flash('success', 'Event scheduled successfully on calendar.');
        redirect(url('calendar'));
    }

    public function destroy(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        Database::execute('DELETE FROM school_events WHERE id = ? AND school_id = ?', [(int)$id, $schoolId]);
        flash('success', 'Event removed from calendar.');
        redirect(url('calendar'));
    }
}
