<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use Core\Controller;
use Core\Database;

final class ReceptionController extends Controller
{
    public function index(): void
    {
        requirePermission('reception.manage');
        $this->view('reception/index', [
            'title' => 'Reception Desk',
            'inquiries' => Database::fetchAll('SELECT * FROM admission_inquiries WHERE school_id = ? ORDER BY created_at DESC LIMIT 50', [$this->schoolId()]),
            'visitors' => Database::fetchAll('SELECT * FROM visitors WHERE school_id = ? ORDER BY check_in DESC LIMIT 50', [$this->schoolId()]),
            'classes' => (new ClassModel())->all('numeric_name ASC'),
        ]);
    }

    public function storeInquiry(): void
    {
        requirePermission('reception.manage');
        $this->requireCsrf();
        Database::insert(
            'INSERT INTO admission_inquiries (school_id, student_name, parent_name, phone, email, interested_class_id, notes, status, handled_by, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $this->schoolId(),
                $_POST['student_name'],
                $_POST['parent_name'] ?? null,
                $_POST['phone'] ?? null,
                $_POST['email'] ?? null,
                $_POST['interested_class_id'] ?: null,
                $_POST['notes'] ?? null,
                'new',
                $this->userId(),
            ]
        );
        flash('success', 'Inquiry recorded.');
        redirect(url('reception'));
    }

    public function storeVisitor(): void
    {
        requirePermission('reception.manage');
        $this->requireCsrf();
        Database::insert(
            'INSERT INTO visitors (school_id, visitor_name, purpose, phone, person_to_meet, check_in, notes, recorded_by, created_at)
             VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, NOW())',
            [
                $this->schoolId(),
                $_POST['visitor_name'],
                $_POST['purpose'] ?? null,
                $_POST['phone'] ?? null,
                $_POST['person_to_meet'] ?? null,
                $_POST['notes'] ?? null,
                $this->userId(),
            ]
        );
        flash('success', 'Visitor logged.');
        redirect(url('reception'));
    }

    public function checkoutVisitor(string $id): void
    {
        requirePermission('reception.manage');
        $this->requireCsrf();
        $visitor = Database::fetch('SELECT id FROM visitors WHERE id = ? AND school_id = ?', [$id, $this->schoolId()]);
        if (!$visitor) {
            flash('error', 'Visitor not found.');
        } else {
            Database::execute('UPDATE visitors SET check_out = NOW() WHERE id = ?', [$id]);
            flash('success', 'Visitor checked out.');
        }
        redirect(url('reception'));
    }

    public function updateInquiryStatus(string $id): void
    {
        requirePermission('reception.manage');
        $this->requireCsrf();
        $inquiry = Database::fetch('SELECT id FROM admission_inquiries WHERE id = ? AND school_id = ?', [$id, $this->schoolId()]);
        if (!$inquiry) {
            flash('error', 'Inquiry not found.');
        } else {
            $status = in_array($_POST['status'], ['new','contacted','converted','closed']) ? $_POST['status'] : 'new';
            Database::execute('UPDATE admission_inquiries SET status = ?, updated_at = NOW() WHERE id = ?', [$status, $id]);
            flash('success', 'Inquiry status updated.');
        }
        redirect(url('reception'));
    }
}
