<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ParentModel;
use App\Models\Student;
use App\Models\Teacher;
use App\Services\ParentTeacherMessageService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class ParentTeacherMessageController extends Controller
{
    private ParentTeacherMessageService $messageService;

    public function __construct()
    {
        $this->messageService = new ParentTeacherMessageService();
    }

    public function index(): void
    {
        Auth::requireLogin();
        $userId = (int) Auth::id();
        $role = Auth::roleSlug();
        $schoolId = (int) Auth::schoolId();

        $conversations = $this->messageService->getConversations($userId, $role, $schoolId);

        // Fetch teachers available for child or classes (for starting new threads)
        $children = [];
        $teachers = [];

        if ($role === 'parent') {
            $user = Auth::user();
            $parentId = (int) ($user['parent_id'] ?? 0);
            if ($parentId) {
                $children = (new ParentModel())->children($parentId);
            }
            // Fetch teachers of this school
            $teachers = Database::fetchAll("
                SELECT t.id, CONCAT(e.first_name, ' ', e.last_name) AS name, e.email, e.designation
                FROM teachers t
                INNER JOIN employees e ON e.id = t.employee_id
                WHERE t.school_id = ? AND (t.status = 1 OR t.status = 'active')
                ORDER BY e.first_name ASC
            ", [$schoolId]);
        }

        $this->view('portal/messages/index', [
            'title' => 'Parent-Teacher Messages',
            'conversations' => $conversations,
            'role' => $role,
            'children' => $children,
            'teachers' => $teachers,
        ]);
    }

    public function show(string $id): void
    {
        Auth::requireLogin();
        $userId = (int) Auth::id();
        $role = Auth::roleSlug();
        $schoolId = (int) Auth::schoolId();
        $convId = (int) $id;

        $thread = $this->messageService->getConversationThread($convId, $userId, $role, $schoolId);
        if (!$thread) {
            flash('error', 'Conversation not found or access denied.');
            redirect(url('parent/messages'));
            return;
        }

        $this->view('portal/messages/show', [
            'title' => 'Message Thread — ' . ($thread['conversation']['subject'] ?? 'Conversation'),
            'thread' => $thread,
            'role' => $role,
        ]);
    }

    public function store(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $userId = (int) Auth::id();
        $role = Auth::roleSlug();
        $schoolId = (int) Auth::schoolId();

        if ($role !== 'parent' && !in_array($role, ['admin', 'principal', 'teacher'], true)) {
            flash('error', 'Only parents, teachers, and administrators can initiate conversations.');
            back();
            return;
        }

        $studentId = (int) ($_POST['student_id'] ?? 0);
        $teacherId = (int) ($_POST['teacher_id'] ?? 0);
        $subject = trim((string) ($_POST['subject'] ?? ''));
        $initialMessage = trim((string) ($_POST['message'] ?? ''));

        if (!$studentId || !$teacherId || empty($subject) || empty($initialMessage)) {
            flash('error', 'Please fill in all required fields (Child, Teacher, Subject, Message).');
            back();
            return;
        }

        $parentId = 0;
        if ($role === 'parent') {
            $user = Auth::user();
            $parentId = (int) ($user['parent_id'] ?? 0);
        } else {
            // Find parent for student
            $parent = Database::fetch("
                SELECT p.id FROM parents p
                INNER JOIN student_parents sp ON sp.parent_id = p.id
                WHERE sp.student_id = ? LIMIT 1
            ", [$studentId]);
            $parentId = $parent ? (int) $parent['id'] : 0;
        }

        if (!$parentId) {
            flash('error', 'No parent record found for this student.');
            back();
            return;
        }

        $attachmentPath = null;
        if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            try {
                $attachmentPath = upload_file($_FILES['attachment'], 'messages', [
                    'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'text/plain'
                ]);
            } catch (\Throwable $e) {
                flash('error', 'Attachment upload failed: ' . $e->getMessage());
                back();
                return;
            }
        }

        try {
            $convId = $this->messageService->startConversation(
                $schoolId,
                $parentId,
                $teacherId,
                $studentId,
                $subject,
                $initialMessage,
                $userId,
                $role,
                $attachmentPath
            );

            flash('success', 'Conversation initiated successfully. The teacher has been notified.');
            redirect(url("parent/messages/{$convId}"));
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            back();
        }
    }

    public function reply(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $userId = (int) Auth::id();
        $role = Auth::roleSlug();
        $schoolId = (int) Auth::schoolId();
        $convId = (int) $id;

        $message = trim((string) ($_POST['message'] ?? ''));
        if (empty($message)) {
            flash('error', 'Message cannot be empty.');
            back();
            return;
        }

        $attachmentPath = null;
        if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            try {
                $attachmentPath = upload_file($_FILES['attachment'], 'messages', [
                    'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'text/plain'
                ]);
            } catch (\Throwable $e) {
                flash('error', 'Attachment upload failed: ' . $e->getMessage());
                back();
                return;
            }
        }

        try {
            $this->messageService->sendReply(
                $convId,
                $userId,
                $role,
                $message,
                $schoolId,
                $attachmentPath
            );

            flash('success', 'Reply sent successfully.');
            redirect(url("parent/messages/{$convId}"));
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            back();
        }
    }
}
