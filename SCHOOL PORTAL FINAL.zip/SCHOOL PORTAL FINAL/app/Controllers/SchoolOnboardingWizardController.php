<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\SchoolOnboardingWizardService;
use Core\Controller;
use Core\Database;

/**
 * SchoolOnboardingWizardController
 * 
 * Interactive Multi-Step Setup Wizard for School Administrators.
 * Guides institution setup through profile, academic calendar, classes, grading, fees, and roles.
 */
final class SchoolOnboardingWizardController extends Controller
{
    private SchoolOnboardingWizardService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new SchoolOnboardingWizardService();
    }

    /**
     * Display setup wizard console.
     * Route: GET /onboarding/wizard
     */
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int)$this->schoolId();

        $status = $this->service->getStatus($schoolId);
        $activeStep = trim((string)($_GET['step'] ?? $status['current_step']));
        if (!isset(SchoolOnboardingWizardService::STEPS[$activeStep]) && $activeStep !== 'review') {
            $activeStep = 'profile';
        }

        // Fetch auxiliary data for wizard step forms
        $academicYears = Database::fetchAll('SELECT * FROM academic_years WHERE school_id = ? ORDER BY id DESC', [$schoolId]);
        $classes = Database::fetchAll('SELECT * FROM classes WHERE school_id = ? ORDER BY id ASC', [$schoolId]);
        $gradeScales = Database::fetchAll('SELECT * FROM grade_scales WHERE school_id = ? ORDER BY min_percentage DESC', [$schoolId]);
        $feeCategories = Database::fetchAll('SELECT * FROM fee_categories WHERE school_id = ? ORDER BY id ASC', [$schoolId]);
        $departments = Database::fetchAll('SELECT * FROM departments WHERE school_id = ? ORDER BY name ASC', [$schoolId]);
        $roles = Database::fetchAll('SELECT * FROM roles WHERE school_id = ? ORDER BY id ASC', [$schoolId]);

        $this->view('onboarding/wizard', [
            'title' => 'School Quick Setup Wizard',
            'status' => $status,
            'active_step' => $activeStep,
            'academic_years' => $academicYears,
            'classes' => $classes,
            'grade_scales' => $gradeScales,
            'fee_categories' => $feeCategories,
            'departments' => $departments,
            'roles' => $roles,
        ]);
    }

    /**
     * Save progress for a specific wizard step.
     * Route: POST /onboarding/wizard/save-step
     */
    public function saveStep(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();

        $stepKey = trim((string)($_POST['step_key'] ?? ''));
        $stepData = $_POST;
        unset($stepData['csrf_token'], $stepData['step_key']);

        $result = $this->service->saveStep($schoolId, $stepKey, $stepData, $userId);

        if ($this->isAjax()) {
            $this->json($result, $result['success'] ? 200 : 400);
            return;
        }

        if ($result['success']) {
            flash('success', $result['message']);
            redirect(url("onboarding/wizard?step={$result['next_step']}"));
        } else {
            flash('error', $result['error'] ?? 'Failed to save setup step.');
            redirect(url("onboarding/wizard?step={$stepKey}"));
        }
    }

    /**
     * Apply 1-click curriculum & grading preset.
     * Route: POST /onboarding/wizard/apply-preset
     */
    public function applyPreset(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();

        $presetKey = trim((string)($_POST['preset_key'] ?? 'k12_standard'));
        $result = $this->service->applyPreset($schoolId, $presetKey, $userId);

        if ($this->isAjax()) {
            $this->json($result, $result['success'] ? 200 : 400);
            return;
        }

        if ($result['success']) {
            flash('success', $result['message']);
        } else {
            flash('error', $result['error'] ?? 'Failed to apply preset.');
        }

        redirect(url('onboarding/wizard?step=classes_sections'));
    }

    /**
     * Complete and finalize setup wizard.
     * Route: POST /onboarding/wizard/complete
     */
    public function complete(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();

        $result = $this->service->completeWizard($schoolId, $userId);

        if ($this->isAjax()) {
            $this->json($result, $result['success'] ? 200 : 400);
            return;
        }

        if ($result['success']) {
            flash('success', $result['message']);
            redirect(url('dashboard'));
        } else {
            flash('error', $result['error'] ?? 'Setup validation incomplete.');
            redirect(url('onboarding/wizard?step=review'));
        }
    }

    /**
     * API Status Endpoint
     * Route: GET /api/v1/onboarding/status
     */
    public function statusJson(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int)$this->schoolId();
        $status = $this->service->getStatus($schoolId);
        $this->json($status, 200);
    }
}
