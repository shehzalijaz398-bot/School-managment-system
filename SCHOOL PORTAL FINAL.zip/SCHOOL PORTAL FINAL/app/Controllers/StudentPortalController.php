<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class StudentPortalController extends Controller
{
    private function getStudentContext(): array
    {
        Auth::requireLogin();
        $user = Auth::user();
        $userId = (int)Auth::id();
        $schoolId = (int)Auth::schoolId();
        $role = Auth::roleSlug();

        if ($role === 'parent') {
            $parentId = (int) ($user['parent_id'] ?? 0);
            $children = (new \App\Models\ParentModel())->children($parentId);
            if (empty($children)) {
                flash('error', 'No children linked to this parent account.');
                $this->view('errors/403', ['title' => 'Access Denied']);
                exit;
            }
            $studentId = (int) ($_SESSION['selected_student_id'] ?? ($children[0]['id'] ?? 0));
            if (!$studentId || !(new \App\Models\ParentModel())->ownsStudent($parentId, $studentId)) {
                $studentId = (int) $children[0]['id'];
                $_SESSION['selected_student_id'] = $studentId;
            }

            $student = Database::fetch(
                "SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                 FROM students s
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                 WHERE s.id = :student_id AND s.school_id = :school_id LIMIT 1",
                ['student_id' => $studentId, 'school_id' => $schoolId]
            );
        } else {
            $student = Database::fetch(
                "SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                 FROM students s
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                 WHERE s.user_id = :user_id AND s.school_id = :school_id LIMIT 1",
                ['user_id' => $userId, 'school_id' => $schoolId]
            );

            // If administrator/staff is viewing or testing portal, fallback to school student for preview
            if (!$student && in_array($role, ['school_admin', 'admin', 'principal', 'superadmin'], true)) {
                $student = Database::fetch(
                    "SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                     FROM students s
                     LEFT JOIN classes c ON c.id = s.class_id
                     LEFT JOIN sections sec ON sec.id = s.section_id
                     LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                     WHERE s.school_id = :school_id AND s.status = 'active'
                     ORDER BY s.id ASC LIMIT 1",
                    ['school_id' => $schoolId]
                );
            }
        }

        if (!$student) {
            flash('info', 'No student profile is linked to this account.');
            redirect(url('students'));
        }

        // Adjust student context if viewing historical academic session
        $selectedYearId = activeAcademicYearId();
        if ($selectedYearId && (int)($student['academic_year_id'] ?? 0) !== $selectedYearId) {
            $hist = Database::fetch(
                "SELECT h.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                 FROM student_academic_history h
                 LEFT JOIN classes c ON c.id = h.class_id
                 LEFT JOIN sections sec ON sec.id = h.section_id
                 LEFT JOIN academic_years ay ON ay.id = h.academic_year_id
                 WHERE h.student_id = ? AND h.academic_year_id = ? LIMIT 1",
                [(int)$student['id'], $selectedYearId]
            );
            if ($hist) {
                $student['class_id'] = $hist['class_id'];
                $student['section_id'] = $hist['section_id'];
                $student['class_name'] = $hist['class_name'];
                $student['section_name'] = $hist['section_name'];
                $student['year_name'] = $hist['year_name'];
                $student['academic_year_id'] = $hist['academic_year_id'];
            } else {
                $ay = Database::fetch("SELECT name FROM academic_years WHERE id = ? AND school_id = ?", [$selectedYearId, $schoolId]);
                if ($ay) {
                    $student['year_name'] = $ay['name'];
                }
            }
        }

        return ['user' => $user, 'student' => $student];
    }

    public function attendance(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];
        $studentId = (int)$student['id'];

        $selectedYearId = activeAcademicYearId();
        $selectedYear = null;
        if ($selectedYearId) {
            $selectedYear = Database::fetch("SELECT * FROM academic_years WHERE id = ? AND school_id = ?", [$selectedYearId, (int)Auth::schoolId()]);
        }

        // Determine default month for selected academic session
        $nowYm = date('Y-m');
        $defaultMonth = $nowYm;
        if ($selectedYear && !empty($selectedYear['start_date']) && !empty($selectedYear['end_date'])) {
            $startYm = date('Y-m', strtotime($selectedYear['start_date']));
            $endYm = date('Y-m', strtotime($selectedYear['end_date']));
            if ($nowYm < $startYm || $nowYm > $endYm) {
                $latestRecord = Database::fetch(
                    "SELECT attendance_date FROM student_attendance WHERE student_id = ? AND (academic_year_id = ? OR academic_year_id IS NULL) ORDER BY attendance_date DESC LIMIT 1",
                    [$studentId, $selectedYearId]
                );
                if ($latestRecord && !empty($latestRecord['attendance_date'])) {
                    $defaultMonth = date('Y-m', strtotime($latestRecord['attendance_date']));
                } else {
                    $defaultMonth = ($nowYm > $endYm) ? $endYm : $startYm;
                }
            }
        }

        $requestedMonth = trim($_GET['month'] ?? $defaultMonth);
        if (!preg_match('/^\d{4}-\d{2}$/', $requestedMonth)) {
            $requestedMonth = $defaultMonth;
        }

        $monthTime = strtotime($requestedMonth . '-01');
        $monthTitle = date('F Y', $monthTime);
        $prevMonth = date('Y-m', strtotime('-1 month', $monthTime));
        $nextMonth = date('Y-m', strtotime('+1 month', $monthTime));

        $startDate = date('Y-m-01', $monthTime);
        $endDate = date('Y-m-t', $monthTime);

        // Fetch attendance records for requested month and session
        $records = Database::fetchAll(
            "SELECT * FROM student_attendance 
             WHERE student_id = ? AND attendance_date BETWEEN ? AND ?
             ORDER BY attendance_date ASC",
            [$studentId, $startDate, $endDate]
        );

        $attendanceMap = [];
        $presentDays = 0;
        $absentDays = 0;
        $lateArrivals = 0;

        foreach ($records as $r) {
            $d = $r['attendance_date'];
            $st = strtolower($r['status'] ?? 'present');
            $attendanceMap[$d] = [
                'status' => $st,
                'remarks' => $r['remarks'] ?? '—'
            ];
            if ($st === 'present') {
                $presentDays++;
            } elseif ($st === 'absent') {
                $absentDays++;
            } elseif ($st === 'late') {
                $lateArrivals++;
            }
        }

        $totalSchoolDays = $presentDays + $absentDays + $lateArrivals;
        $attendanceRate = $totalSchoolDays > 0 ? round((($presentDays + $lateArrivals) / $totalSchoolDays) * 100, 1) : 0.0;

        $this->view('portal/student_attendance', [
            'title'            => 'Attendance Records',
            'student'          => $student,
            'currentMonth'     => $requestedMonth,
            'monthTitle'       => $monthTitle,
            'prevMonth'        => $prevMonth,
            'nextMonth'        => $nextMonth,
            'attendanceRate'   => $attendanceRate,
            'presentDays'      => $presentDays,
            'absentDays'       => $absentDays,
            'lateArrivals'     => $lateArrivals,
            'totalSchoolDays'  => $totalSchoolDays,
            'records'          => $records,
            'attendanceMap'    => $attendanceMap,
            'monthTime'        => $monthTime
        ]);
    }

    public function finance(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];
        $studentId = (int)$student['id'];

        $selectedYearId = activeAcademicYearId();
        $invParams = [$studentId];
        $invAyFilter = "";
        if ($selectedYearId) {
            $invAyFilter = " AND (academic_year_id = ? OR academic_year_id IS NULL) ";
            $invParams[] = $selectedYearId;
        }

        // Fetch fee invoices
        $invoices = Database::fetchAll(
            "SELECT * FROM student_fee_invoices 
             WHERE student_id = ? {$invAyFilter}
             ORDER BY invoice_date DESC, id DESC",
            $invParams
        );

        $totalInvoiced = 0.0;
        $totalPaid = 0.0;
        $balanceDue = 0.0;
        $overdue = 0.0;
        $today = date('Y-m-d');

        foreach ($invoices as $inv) {
            $tot = (float)$inv['total_amount'];
            $paid = (float)$inv['paid_amount'];
            $bal = max(0, $tot - $paid);

            $totalInvoiced += $tot;
            $totalPaid += $paid;
            $balanceDue += $bal;

            if ($bal > 0 && !empty($inv['due_date']) && $inv['due_date'] < $today) {
                $overdue += $bal;
            }
        }

        $this->view('portal/student_finance', [
            'title'         => 'Fee & Payment Records',
            'student'       => $student,
            'totalInvoiced' => $totalInvoiced,
            'totalPaid'     => $totalPaid,
            'balanceDue'    => $balanceDue,
            'overdue'       => $overdue,
            'invoices'      => $invoices
        ]);
    }

    public function timetable(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];
        $classId = (int)($student['class_id'] ?? 5);
        $sectionId = (int)($student['section_id'] ?? 6);

        $viewMode = $_GET['view'] ?? 'day';
        $activeDay = strtolower(trim($_GET['day'] ?? 'mon'));
        $dayMap = [
            'mon' => 1,
            'tue' => 2,
            'wed' => 3,
            'thu' => 4,
            'fri' => 5,
            'sat' => 6,
        ];
        $dayNumber = $dayMap[$activeDay] ?? 1;

        // Query timetable for this class and section
        $timetables = Database::fetchAll(
            "SELECT t.*, s.name AS subject_name, tp.name AS period_name, tp.period_number, tp.start_time, tp.end_time,
                    CONCAT(COALESCE(emp.first_name, ''), ' ', COALESCE(emp.last_name, '')) AS teacher_name,
                    r.name AS room_number
             FROM timetables t
             LEFT JOIN subjects s ON s.id = t.subject_id
             LEFT JOIN timetable_periods tp ON tp.id = t.period_id
             LEFT JOIN teachers tch ON tch.id = t.teacher_id
             LEFT JOIN employees emp ON emp.id = tch.employee_id
             LEFT JOIN rooms r ON r.id = t.room
             WHERE t.class_id = ? AND t.section_id = ?
             ORDER BY t.day_of_week ASC, tp.start_time ASC, tp.period_number ASC",
            [$classId, $sectionId]
        );

        $this->view('portal/student_timetable', [
            'title'      => 'Weekly Class Timetable',
            'student'    => $student,
            'viewMode'   => $viewMode,
            'activeDay'  => $activeDay,
            'dayNumber'  => $dayNumber,
            'timetables' => $timetables
        ]);
    }

    public function academics(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];
        $classId = (int)($student['class_id'] ?? 0);

        // Fetch genuine subjects for this student's class
        $subjects = [];
        if ($classId > 0) {
            $subjects = Database::fetchAll(
                "SELECT s.* FROM class_subjects cs
                 JOIN subjects s ON s.id = cs.subject_id
                 WHERE cs.class_id = ? AND s.status = 1
                 ORDER BY s.name ASC",
                [$classId]
            );
        }

        $enrolledSubjects = [];
        foreach ($subjects as $s) {
            $enrolledSubjects[] = [
                'name' => $s['name'],
                'code' => $s['code'] ?? strtoupper(substr($s['name'], 0, 4)),
                'type' => ucfirst($s['type'] ?? 'Core')
            ];
        }

        $this->view('portal/student_academics', [
            'title'            => 'Academic Overview',
            'student'          => $student,
            'enrolledSubjects' => $enrolledSubjects
        ]);
    }

    public function notifications(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];
        $user = $ctx['user'];
        $filter = strtolower(trim($_GET['filter'] ?? 'all'));
        $schoolId = (int)($user['school_id'] ?? Auth::schoolId());
        $userId = (int)($user['id'] ?? Auth::id());
        $classId = (int)($student['class_id'] ?? 0);
        $sectionId = (int)($student['section_id'] ?? 0);

        // Query genuine notifications for this user from database
        $dbNotifications = Database::fetchAll(
            "SELECT * FROM notifications 
             WHERE school_id = ? AND user_id = ? 
             ORDER BY created_at DESC LIMIT 50",
            [$schoolId, $userId]
        );

        // Query genuine announcements for student / parent audience or this class
        $announcements = Database::fetchAll(
            "SELECT * FROM announcements 
             WHERE (school_id = ? OR school_id IS NULL) 
               AND status = 'published'
               AND (
                   audience IN ('all', 'students')
                   OR (class_id = ? AND (section_id IS NULL OR section_id = ?))
               )
             ORDER BY created_at DESC LIMIT 20",
            [$schoolId, $classId, $sectionId]
        );

        $notificationsList = [];

        // Add user-specific notifications
        foreach ($dbNotifications as $n) {
            $typeStr = strtolower($n['type'] ?? 'general');
            $cat = 'general';
            $icon = 'bell';
            $iconBg = '#eff6ff';
            $iconCol = '#3b82f6';
            $actionLabel = 'View Details';
            $actionUrl = !empty($n['link']) ? url($n['link']) : url('portal/notifications');

            if (str_contains($typeStr, 'attend')) {
                $cat = 'academic';
                $icon = 'calendar';
                $iconBg = '#eff6ff';
                $iconCol = '#3b82f6';
                $actionLabel = 'View Attendance';
                $actionUrl = url('portal/attendance');
            } elseif (str_contains($typeStr, 'fee') || str_contains($typeStr, 'finance') || str_contains($typeStr, 'invoice') || str_contains($typeStr, 'pay')) {
                $cat = 'finance';
                $icon = 'credit-card';
                $iconBg = '#f0fdf4';
                $iconCol = '#10b981';
                $actionLabel = 'View Finance';
                $actionUrl = url('portal/finance');
            } elseif (str_contains($typeStr, 'assign') || str_contains($typeStr, 'homework') || str_contains($typeStr, 'exam')) {
                $cat = 'academic';
                $icon = 'book-open';
                $iconBg = '#f5f3ff';
                $iconCol = '#8b5cf6';
                $actionLabel = 'View Homework';
                $actionUrl = url('parent/assignments');
            }

            $notificationsList[] = [
                'id'           => 'notif_' . $n['id'],
                'category'     => $cat,
                'type'         => ucfirst(str_replace('_', ' ', $n['type'] ?? 'Notification')),
                'title'        => $n['title'] ?? 'Notification',
                'message'      => $n['message'] ?? '',
                'time'         => !empty($n['created_at']) ? date('M j, Y • h:i A', strtotime($n['created_at'])) : 'Recently',
                'raw_time'     => $n['created_at'] ?? '',
                'icon'         => $icon,
                'icon_bg'      => $iconBg,
                'icon_col'     => $iconCol,
                'action_label' => $actionLabel,
                'action_url'   => $actionUrl,
                'is_read'      => (bool)($n['is_read'] ?? 0)
            ];
        }

        // Add announcements
        foreach ($announcements as $ann) {
            $cat = 'announcements';
            if (str_contains(strtolower($ann['category'] ?? ''), 'academic')) {
                $cat = 'academic';
            } elseif (str_contains(strtolower($ann['category'] ?? ''), 'fee')) {
                $cat = 'finance';
            }

            $notificationsList[] = [
                'id'           => 'ann_' . $ann['id'],
                'category'     => $cat,
                'type'         => 'Announcement',
                'title'        => $ann['title'],
                'message'      => $ann['body'],
                'time'         => !empty($ann['created_at']) ? date('M j, Y • h:i A', strtotime($ann['created_at'])) : 'Recently',
                'raw_time'     => $ann['created_at'] ?? '',
                'icon'         => 'bell',
                'icon_bg'      => '#fef3c7',
                'icon_col'     => '#f59e0b',
                'action_label' => 'View Noticeboard',
                'action_url'   => url('announcements'),
                'is_read'      => !empty($_SESSION['portal_read_notifications_all']) || in_array('ann_' . $ann['id'], $_SESSION['portal_read_notifications'] ?? [])
            ];
        }

        // Sort by date DESC
        usort($notificationsList, function ($a, $b) {
            return strcmp($b['raw_time'], $a['raw_time']);
        });

        // Apply filter
        $filtered = array_filter($notificationsList, function ($item) use ($filter) {
            if ($filter === 'unread') {
                return empty($item['is_read']);
            }
            if ($filter === 'academic') {
                return $item['category'] === 'academic';
            }
            if ($filter === 'finance') {
                return $item['category'] === 'finance';
            }
            if ($filter === 'announcements') {
                return $item['category'] === 'announcements';
            }
            return true;
        });

        $unreadCount = count(array_filter($notificationsList, fn($n) => empty($n['is_read'])));

        $this->view('portal/student_notifications', [
            'title'         => 'Notifications',
            'student'       => $student,
            'filter'        => $filter,
            'notifications' => array_values($filtered),
            'totalCount'    => count($notificationsList),
            'unreadCount'   => $unreadCount
        ]);
    }

    public function markAllNotificationsRead(): void
    {
        Auth::requireLogin();
        $schoolId = (int)Auth::schoolId();
        $userId = (int)Auth::id();

        Database::execute(
            "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND school_id = ?",
            [$userId, $schoolId]
        );
        $_SESSION['portal_read_notifications_all'] = true;

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'success']);
            exit;
        }
        flash('success', 'All notifications marked as read.');
        redirect(url('portal/notifications'));
    }

    public function profile(): void
    {
        $ctx = $this->getStudentContext();
        $student = $ctx['student'];

        $tab = strtolower(trim($_GET['tab'] ?? 'details'));

        $this->view('portal/student_profile', [
            'title'   => 'Student Profile',
            'student' => $student,
            'tab'     => $tab
        ]);
    }
}
