<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\TenantContext;

final class SupportTicketController extends Controller
{
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = TenantContext::currentSchoolId();
        $tickets = Database::fetchAll(
            'SELECT * FROM support_tickets WHERE school_id = ? ORDER BY id DESC LIMIT 100',
            [$schoolId]
        );
        $this->view('support/index', [
            'title' => 'Support Tickets',
            'tickets' => $tickets,
        ]);
    }

    public function store(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'category' => 'required|in:technical,billing,account,feature,other',
            'priority' => 'required|in:low,medium,high,urgent',
            'subject' => 'required|max:255',
            'message' => 'required|min:10',
        ]);

        $schoolId = TenantContext::currentSchoolId();
        $ticketNo = 'TKT-' . strtoupper(bin2hex(random_bytes(4)));

        Database::beginTransaction();
        try {
            $id = Database::insert(
                'INSERT INTO support_tickets
                (ticket_number, school_id, created_by, category, priority, subject, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $ticketNo,
                    $schoolId,
                    currentUserId(),
                    $data['category'],
                    $data['priority'],
                    $data['subject'],
                    'open',
                ]
            );
            Database::insert(
                'INSERT INTO support_ticket_messages (ticket_id, sender_type, sender_id, message, created_at)
                 VALUES (?, ?, ?, ?, NOW())',
                [$id, 'school', currentUserId(), $data['message']]
            );
            Database::insert(
                'INSERT INTO platform_notifications (user_id, school_id, type, title, message, link, is_read, created_at)
                 VALUES (NULL, ?, ?, ?, ?, ?, 0, NOW())',
                [
                    $schoolId,
                    'support.ticket',
                    'New support ticket',
                    $ticketNo . ': ' . $data['subject'],
                    '/superadmin/support/' . $id,
                ]
            );
            Database::commit();
            flash('success', 'Ticket ' . $ticketNo . ' created.');
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', $e->getMessage());
        }
        redirect(url('support'));
    }

    public function show(string $id): void
    {
        requirePermission('settings.manage');
        $schoolId = TenantContext::currentSchoolId();
        $ticket = Database::fetch(
            'SELECT * FROM support_tickets WHERE id = ? AND school_id = ? LIMIT 1',
            [(int) $id, $schoolId]
        );
        if (!$ticket) {
            http_response_code(404);
            view('errors/404', ['title' => 'Not Found']);
            return;
        }
        $messages = Database::fetchAll(
            'SELECT * FROM support_ticket_messages WHERE ticket_id = ? ORDER BY id ASC',
            [(int) $id]
        );
        $this->view('support/show', [
            'title' => 'Ticket ' . $ticket['ticket_number'],
            'ticket' => $ticket,
            'messages' => $messages,
        ]);
    }

    public function reply(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = TenantContext::currentSchoolId();
        $ticket = Database::fetch(
            'SELECT * FROM support_tickets WHERE id = ? AND school_id = ? LIMIT 1',
            [(int) $id, $schoolId]
        );
        if (!$ticket) {
            flash('error', 'Ticket not found.');
            redirect(url('support'));
        }
        $data = $this->validate($_POST, ['message' => 'required|min:2']);
        Database::insert(
            'INSERT INTO support_ticket_messages (ticket_id, sender_type, sender_id, message, created_at)
             VALUES (?, ?, ?, ?, NOW())',
            [(int) $id, 'school', currentUserId(), $data['message']]
        );
        Database::execute(
            'UPDATE support_tickets SET status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?',
            ['open', (int) $id, $schoolId]
        );
        flash('success', 'Reply sent.');
        redirect(url('support/' . $id));
    }
}
