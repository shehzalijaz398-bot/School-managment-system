<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Admission;
use App\Models\Announcement;
use App\Models\AuditLog;
use App\Models\ClassModel;
use App\Models\LeaveRequest;
use App\Models\Notification;
use App\Models\Teacher;
use App\Models\Timetable;
use App\Models\User;
use App\Services\AdmissionService;
use App\Services\LeaveService;
use App\Services\ReportService;
use App\Services\TimetableService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class AdmissionController extends Controller
{
    public function index(): void
    {
        requirePermission('admissions.manage');
        
        $schoolId = Auth::schoolId();
        $status = $_GET['status'] ?? '';
        $search = trim($_GET['search'] ?? ($_GET['q'] ?? ''));
        $classId = (int)($_GET['class_id'] ?? 0);
        $dateFilter = $_GET['date'] ?? 'all';

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = isset($_GET['limit']) && in_array((int)$_GET['limit'], [10, 25, 50, 100], true) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;

        $params = [$schoolId];
        $sql = 'SELECT a.*, c.name AS class_name FROM admissions a
                LEFT JOIN classes c ON c.id = a.class_id
                WHERE a.school_id = ?';
                
        if ($status !== '' && $status !== 'all') {
            if ($status === 'accepted') {
                $sql .= ' AND a.status IN ("accepted", "approved")';
            } elseif ($status === 'admitted') {
                $sql .= ' AND a.status IN ("admitted", "enrolled")';
            } else {
                $sql .= ' AND a.status = ?';
                $params[] = $status;
            }
        }
        if ($classId > 0) {
            $sql .= ' AND a.class_id = ?';
            $params[] = $classId;
        }
        if ($search !== '') {
            $sql .= ' AND (a.student_name LIKE ? OR a.application_no LIKE ? OR a.parent_name LIKE ?)';
            $q = "%{$search}%";
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }
        if ($dateFilter === 'today') {
            $sql .= ' AND DATE(a.created_at) = CURDATE()';
        } elseif ($dateFilter === 'week') {
            $sql .= ' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } elseif ($dateFilter === 'month') {
            $sql .= ' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }
        
        // Count total
        $countSql = str_replace('a.*, c.name AS class_name', 'COUNT(*) AS total', $sql);
        $totalRow = Database::fetch($countSql, $params);
        $total = (int)($totalRow['total'] ?? 0);
        $totalPages = max(1, (int)ceil($total / $limit));
        
        // Sorting
        $sort = $_GET['sort'] ?? 'date';
        $dir = (isset($_GET['dir']) && strtolower($_GET['dir']) === 'asc') ? 'ASC' : 'DESC';
        $orderClause = match ($sort) {
            'reference' => "a.application_no {$dir}",
            'name' => "a.student_name {$dir}",
            'status' => "a.status {$dir}, a.created_at DESC",
            default => "a.created_at {$dir}"
        };

        $sql .= " ORDER BY {$orderClause} LIMIT {$limit} OFFSET {$offset}";
        $admissions = Database::fetchAll($sql, $params);

        $startRecord = $total > 0 ? ($offset + 1) : 0;
        $endRecord = min($offset + $limit, $total);

        $this->view('admissions/index', [
            'title' => 'Admission Applications Dashboard',
            'admissions' => $admissions,
            'classes' => (new ClassModel())->listAll(),
            'filters' => ['status' => $status, 'search' => $search, 'class_id' => $classId, 'date' => $dateFilter],
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => $totalPages,
            'startRecord' => $startRecord,
            'endRecord' => $endRecord,
            'sort' => $sort,
            'dir' => strtolower($dir),
        ]);
    }

    public function create(): void
    {
        requirePermission('admissions.manage');
        $this->view('admissions/create', [
            'title' => 'New Admission',
            'classes' => (new ClassModel())->listAll(),
        ]);
    }

    public function store(): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, ['student_name' => 'required']);
        (new AdmissionService())->create([
            'student_name' => $data['student_name'],
            'gender' => $_POST['gender'] ?? null,
            'date_of_birth' => $_POST['date_of_birth'] ?: null,
            'parent_name' => $_POST['parent_name'] ?? null,
            'parent_phone' => $_POST['parent_phone'] ?? null,
            'parent_email' => $_POST['parent_email'] ?? null,
            'class_id' => $_POST['class_id'] ?: null,
            'section_id' => $_POST['section_id'] ?: null,
            'notes' => $_POST['notes'] ?? null,
            'status' => $_POST['status'] ?? 'application',
        ]);
        flash('success', 'Admission application created.');
        redirect(url('admissions'));
    }

    public function updateStatus(string $id): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();
        try {
            $newStatus = $_POST['status'] ?? 'application';
            (new AdmissionService())->updateStatus((int) $id, $newStatus);
            flash('success', 'Application status updated to ' . ucfirst($newStatus) . '.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('admissions'));
    }

    public function enroll(string $id): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();
        try {
            $studentId = (new AdmissionService())->enroll((int) $id);
            flash('success', 'Applicant successfully enrolled as registered student (ID: ' . $studentId . ').');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('admissions'));
    }

    public function verifyDocs(string $id): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();
        try {
            $verifiedItems = is_array($_POST['documents'] ?? null) ? $_POST['documents'] : [];
            $notes = !empty($_POST['notes']) ? trim((string) $_POST['notes']) : null;
            $res = (new AdmissionService())->verifyDocuments((int) $id, $verifiedItems, $notes);
            if ($res['all_verified']) {
                flash('success', 'All documents verified! Application moved to Review stage.');
            } else {
                flash('warning', 'Document checklist updated. Pending documents remain.');
            }
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('admissions'));
    }

    public function destroy(string $id): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();
        $schoolId = Auth::schoolId();
        $app = Database::fetch('SELECT * FROM admissions WHERE id = ? AND school_id = ?', [(int)$id, $schoolId]);
        if ($app) {
            Database::query('DELETE FROM admissions WHERE id = ? AND school_id = ?', [(int)$id, $schoolId]);
            flash('success', 'Admission application deleted.');
        }
        redirect(url('admissions'));
    }

    public function bulkAction(): void
    {
        requirePermission('admissions.manage');
        $this->requireCsrf();

        $action = $_POST['action'] ?? '';
        $rawIds = $_POST['admission_ids'] ?? [];
        if (!is_array($rawIds) || empty($rawIds)) {
            flash('error', 'No applications selected.');
            redirect(url('admissions'));
            return;
        }

        $ids = array_map('intval', $rawIds);
        $schoolId = Auth::schoolId();

        if ($action === 'status') {
            $newStatus = $_POST['bulk_status'] ?? 'application';
            $count = 0;
            foreach ($ids as $appId) {
                $app = Database::fetch('SELECT id FROM admissions WHERE id = ? AND school_id = ?', [$appId, $schoolId]);
                if ($app) {
                    (new AdmissionService())->updateStatus($appId, $newStatus);
                    $count++;
                }
            }
            flash('success', "Updated {$count} application(s) status to " . ucfirst($newStatus) . ".");
        } elseif ($action === 'delete') {
            $count = 0;
            foreach ($ids as $appId) {
                Database::query('DELETE FROM admissions WHERE id = ? AND school_id = ?', [$appId, $schoolId]);
                $count++;
            }
            flash('success', "Deleted {$count} admission application(s).");
        }

        redirect(url('admissions'));
    }

    public function exportCsv(): void
    {
        requirePermission('admissions.manage');
        $schoolId = Auth::schoolId();

        $sql = 'SELECT a.application_no, a.student_name, a.gender, c.name AS class_name,
                       a.parent_name, a.parent_phone, a.status, a.created_at
                FROM admissions a
                LEFT JOIN classes c ON c.id = a.class_id
                WHERE a.school_id = ? ORDER BY a.created_at DESC';
        $rows = Database::fetchAll($sql, [$schoolId]);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="admission_applications_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Reference', 'Applicant Name', 'Gender', 'Class', 'Primary Parent / Guardian', 'Parent Phone', 'Status', 'Submission Date']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['application_no'],
                $r['student_name'],
                ucfirst($r['gender'] ?? ''),
                $r['class_name'] ?? 'Unassigned',
                $r['parent_name'] ?? 'Not Specified',
                $r['parent_phone'] ?? '',
                ucfirst($r['status']),
                date('d/m/Y', strtotime($r['created_at']))
            ]);
        }
        fclose($out);
        exit;
    }
}
