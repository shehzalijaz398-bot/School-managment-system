<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\Section;
use App\Models\Student;
use Core\Controller;
use Core\Database;

final class StudentController extends Controller
{
    public function index(): void
    {
        requirePermission('students.view');
        
        $search = trim($_GET['q'] ?? '');
        $status = $_GET['status'] ?? null;
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $sectionId = isset($_GET['section_id']) && $_GET['section_id'] !== '' ? (int) $_GET['section_id'] : null;
        
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = isset($_GET['limit']) && in_array((int)$_GET['limit'], [10, 25, 50, 100], true) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;
        
        $sql = 'SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS academic_year,
                       p.first_name AS parent_first_name, p.last_name AS parent_last_name, p.phone AS parent_phone,
                       sp.relationship AS parent_relationship
                FROM students s
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                LEFT JOIN student_parents sp ON sp.student_id = s.id AND sp.is_primary = 1
                LEFT JOIN parents p ON p.id = sp.parent_id
                WHERE s.school_id = ?';
        $params = [$this->schoolId()];

        if ($search !== '') {
            $sql .= ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ? OR p.first_name LIKE ? OR p.last_name LIKE ? OR s.emergency_contact LIKE ?)';
            $q = '%' . $search . '%';
            $params = array_merge($params, [$q, $q, $q, $q, $q, $q, $q]);
        }
        if ($status && $status !== 'all') {
            $sql .= ' AND s.status = ?';
            $params[] = $status;
        }
        if ($classId) {
            $sql .= ' AND s.class_id = ?';
            $params[] = $classId;
        }
        if ($sectionId) {
            $sql .= ' AND s.section_id = ?';
            $params[] = $sectionId;
        }
        
        // Count Total
        $countSql = 'SELECT COUNT(DISTINCT s.id) AS total FROM students s
                     LEFT JOIN classes c ON c.id = s.class_id
                     LEFT JOIN sections sec ON sec.id = s.section_id
                     LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                     LEFT JOIN student_parents sp ON sp.student_id = s.id AND sp.is_primary = 1
                     LEFT JOIN parents p ON p.id = sp.parent_id
                     WHERE s.school_id = ?';
        $countParams = [$this->schoolId()];
        if ($search !== '') {
            $countSql .= ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ? OR p.first_name LIKE ? OR p.last_name LIKE ? OR s.emergency_contact LIKE ?)';
            $countParams = array_merge($countParams, [$q, $q, $q, $q, $q, $q, $q]);
        }
        if ($status && $status !== 'all') {
            $countSql .= ' AND s.status = ?';
            $countParams[] = $status;
        }
        if ($classId) {
            $countSql .= ' AND s.class_id = ?';
            $countParams[] = $classId;
        }
        if ($sectionId) {
            $countSql .= ' AND s.section_id = ?';
            $countParams[] = $sectionId;
        }

        $totalRow = Database::fetch($countSql, $countParams);
        $total = (int)($totalRow['total'] ?? 0);
        $totalPages = max(1, (int)ceil($total / $limit));
        
        $sort = $_GET['sort'] ?? 'name';
        $dir = (isset($_GET['dir']) && strtolower($_GET['dir']) === 'desc') ? 'DESC' : 'ASC';
        $orderClause = match ($sort) {
            'admission_no' => "s.admission_no {$dir}",
            'status' => "s.status {$dir}, s.first_name ASC",
            'class' => "c.name {$dir}, s.first_name ASC",
            'created_at' => "s.created_at {$dir}",
            default => "s.first_name {$dir}, s.last_name {$dir}"
        };

        $sql .= " ORDER BY {$orderClause} LIMIT {$limit} OFFSET {$offset}";
        $students = Database::fetchAll($sql, $params);

        $unpaidInvoices = Database::fetchAll(
            'SELECT student_id, COUNT(id) as count FROM student_fee_invoices WHERE school_id = ? AND status IN ("unpaid", "partial") GROUP BY student_id',
            [$this->schoolId()]
        );
        $unpaidMap = [];
        foreach ($unpaidInvoices as $u) {
            $unpaidMap[(int)$u['student_id']] = (int)$u['count'];
        }

        $feeCategories = Database::fetchAll(
            'SELECT id, name, amount FROM fee_categories WHERE school_id = ? AND status = 1 ORDER BY name ASC',
            [$this->schoolId()]
        );

        $startRecord = $total > 0 ? ($offset + 1) : 0;
        $endRecord = min($offset + $limit, $total);

        $this->view('students/index', [
            'title' => 'Student Directory',
            'students' => $students,
            'classes' => (new ClassModel())->withSections(),
            'filters' => $_GET,
            'unpaidMap' => $unpaidMap,
            'feeCategories' => $feeCategories,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => $totalPages,
            'startRecord' => $startRecord,
            'endRecord' => $endRecord,
            'sort' => $sort,
            'dir' => strtolower($dir),
        ]);
    }

    public function create(): void
    {
        requirePermission('students.create');
        $schoolId = $this->schoolId();
        $classModel = new ClassModel();
        $classes = $classModel->withSections();
        
        // Fetch class subjects
        $classSubjects = Database::fetchAll(
            "SELECT cs.class_id, s.id, s.name, s.code, s.type 
             FROM class_subjects cs 
             INNER JOIN subjects s ON s.id = cs.subject_id 
             WHERE cs.school_id = ? AND s.status = 1 
             ORDER BY s.type ASC, s.name ASC", 
            [$schoolId]
        );
        $classSubjectMap = [];
        foreach ($classSubjects as $cs) {
            $classSubjectMap[$cs['class_id']][] = $cs;
        }

        $allSubjects = Database::fetchAll(
            "SELECT id, name, code, type FROM subjects WHERE school_id = ? AND status = 1 ORDER BY name ASC",
            [$schoolId]
        );

        // Fetch existing parents for linking
        $existingParents = Database::fetchAll(
            "SELECT id, first_name, last_name, email, phone, relation_label 
             FROM parents 
             WHERE school_id = ? AND status = 1 
             ORDER BY first_name ASC, last_name ASC", 
            [$schoolId]
        );

        $nextAdmissionNo = (new Student())->nextAdmissionNo();
        $seq = preg_replace('/[^0-9]/', '', $nextAdmissionNo) ?: '0301';
        $nextStudentId = 'STU' . date('Y') . str_pad($seq, 4, '0', STR_PAD_LEFT);
        $nextAdmissionPreview = 'ADM' . date('Y') . str_pad($seq, 4, '0', STR_PAD_LEFT);

        $this->view('students/form', [
            'title'                => 'Admit New Student',
            'student'              => null,
            'classes'              => $classes,
            'sections'             => [],
            'allSubjects'          => $allSubjects,
            'classSubjectMap'      => $classSubjectMap,
            'existingParents'      => $existingParents,
            'nextAdmissionNo'      => $nextAdmissionNo,
            'nextStudentId'        => $nextStudentId,
            'nextAdmissionPreview' => $nextAdmissionPreview,
            'transport_routes'     => Database::fetchAll('SELECT id, title, fare FROM transport_routes WHERE school_id = ? AND status = "active" ORDER BY title', [$schoolId]),
        ]);
    }

    public function store(): void
    {
        requirePermission('students.create');
        $this->requireCsrf();

        // 1. Validation with flexible CodeClove layout
        $data = $this->validate($_POST, [
            'first_name' => 'required|max:100',
            'last_name' => 'required|max:100',
            'gender' => 'required|in:male,female,other',
            'class_id' => 'required|integer',
        ]);

        try {
            \App\Services\Platform\PlanLimitService::assertCanCreate('students');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('students/create'));
            return;
        }

        // Section handling: if section_id empty, pick first active section of class
        $sectionId = !empty($_POST['section_id']) ? (int) $_POST['section_id'] : null;
        if (!$sectionId) {
            $defaultSec = Database::fetch(
                'SELECT id FROM sections WHERE class_id = ? AND school_id = ? AND status = 1 ORDER BY name ASC LIMIT 1',
                [(int)$data['class_id'], $this->schoolId()]
            );
            $sectionId = (int) ($defaultSec['id'] ?? 0);
        }

        // Address aggregation
        $addressParts = array_filter([
            $_POST['street_address'] ?? '',
            $_POST['city'] ?? '',
            $_POST['state'] ?? '',
            $_POST['zip'] ?? '',
            $_POST['country'] ?? ''
        ]);
        $fullAddress = !empty($addressParts) ? implode(', ', $addressParts) : ($_POST['address'] ?? null);

        // Admission & Student ID
        $model = new Student();
        $autoGenerateId = isset($_POST['auto_generate_id']) ? (bool)$_POST['auto_generate_id'] : true;
        if ($autoGenerateId || empty($_POST['admission_no'])) {
            $admissionNo = $model->nextAdmissionNo();
        } else {
            $admissionNo = trim((string)$_POST['admission_no']);
            $existingStudent = Database::fetch('SELECT id FROM students WHERE school_id = ? AND admission_no = ? LIMIT 1', [$this->schoolId(), $admissionNo]);
            if ($existingStudent) {
                flash('error', "Admission number '{$admissionNo}' is already assigned to an enrolled student in this school.");
                redirect(url('students/admit'));
                return;
            }
        }

        // Full name with middle name
        $middleName = trim((string)($_POST['middle_name'] ?? ''));
        $firstName = $data['first_name'];
        if ($middleName !== '') {
            $firstName .= ' ' . $middleName;
        }

        $userId = null;
        if (!empty($_POST['email'])) {
            $studentRoleId = Database::fetch("SELECT id FROM roles WHERE slug = 'student' AND (school_id = ? OR school_id IS NULL) ORDER BY school_id DESC LIMIT 1", [$this->schoolId()])['id'] ?? null;
            $studentPass = !empty($_POST['student_password']) ? $_POST['student_password'] : 'Password@123';
            if ($studentRoleId) {
                $existingUser = Database::fetch('SELECT id FROM users WHERE email = ? AND school_id = ? LIMIT 1', [$_POST['email'], $this->schoolId()]);
                if (!$existingUser) {
                    $userId = (new \App\Models\User())->create([
                        'school_id' => $this->schoolId(),
                        'name' => $firstName . ' ' . $data['last_name'],
                        'email' => $_POST['email'],
                        'phone' => $_POST['phone'] ?? null,
                        'password' => password_hash($studentPass, PASSWORD_DEFAULT),
                        'role_id' => $studentRoleId,
                        'status' => 1
                    ]);
                } else {
                    $userId = (int) $existingUser['id'];
                }
            }
        }

        // Date of birth & admission date normalization
        $dob = !empty($_POST['date_of_birth']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['date_of_birth']))) : null;
        $admDate = !empty($_POST['admission_date']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['admission_date']))) : date('Y-m-d');

        $payload = [
            'admission_no'       => $admissionNo,
            'roll_no'            => $_POST['roll_no'] ?? null,
            'first_name'         => $firstName,
            'last_name'          => $data['last_name'],
            'gender'             => $data['gender'],
            'date_of_birth'      => $dob,
            'class_id'           => (int) $data['class_id'],
            'section_id'         => $sectionId,
            'academic_year_id'   => activeAcademicYearId(),
            'email'              => $_POST['email'] ?? null,
            'phone'              => $_POST['phone'] ?? null,
            'address'            => $fullAddress,
            'admission_date'     => $admDate,
            'previous_school'    => $_POST['previous_school'] ?? null,
            'medical_note'       => $_POST['medical_note'] ?? null,
            'emergency_contact'  => $_POST['emergency_contact'] ?? ($_POST['parent_first_name'] ?? null),
            'emergency_phone'    => $_POST['emergency_phone'] ?? ($_POST['parent_phone'] ?? null),
            'status'             => !empty($_POST['status']) ? $_POST['status'] : 'active',
            'transport_route_id' => !empty($_POST['transport_route_id']) ? (int)$_POST['transport_route_id'] : null,
            'user_id'            => $userId,
        ];

        if (!empty($_FILES['profile_image']['name'])) {
            $payload['profile_image'] = upload_file($_FILES['profile_image'], 'profiles', app_config('upload.allowed_images'));
        }

        $id = $model->create($payload);

        // Academic history - always record enrollment snapshot
        Database::insert(
            'INSERT INTO student_academic_history (school_id, student_id, academic_year_id, class_id, section_id, roll_no, result_status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
            [$this->schoolId(), $id, activeAcademicYearId(), (int) $data['class_id'], $sectionId ?: null, $payload['roll_no'], 'enrolled']
        );

        // Parent / Guardian linking or creation
        $parentId = null;
        if (!empty($_POST['link_existing_parent']) && !empty($_POST['existing_parent_id'])) {
            $parentId = (int) $_POST['existing_parent_id'];
        } elseif (!empty($_POST['parent_first_name'])) {
            $parentFirst = trim((string)$_POST['parent_first_name']);
            $parentLast = trim((string)($_POST['parent_last_name'] ?? ''));
            $parentEmail = trim((string)($_POST['parent_email'] ?? ''));
            $parentPhone = trim((string)($_POST['parent_phone'] ?? ''));
            $parentRelation = trim((string)($_POST['parent_relation'] ?? 'Legal Parent / Guardian'));

            $existingP = null;
            if ($parentEmail !== '') {
                $existingP = Database::fetch('SELECT id FROM parents WHERE email = ? AND school_id = ? LIMIT 1', [$parentEmail, $this->schoolId()]);
            }
            if ($existingP) {
                $parentId = (int) $existingP['id'];
            } else {
                $parentId = (new \App\Models\ParentModel())->create([
                    'school_id' => $this->schoolId(),
                    'first_name' => $parentFirst,
                    'last_name' => $parentLast,
                    'email' => $parentEmail ?: null,
                    'phone' => $parentPhone ?: null,
                    'relation_label' => $parentRelation,
                    'status' => 1
                ]);

                if ($parentEmail !== '') {
                    $existingUser = Database::fetch('SELECT id FROM users WHERE email = ? AND school_id = ? LIMIT 1', [$parentEmail, $this->schoolId()]);
                    if (!$existingUser) {
                        $roleId = Database::fetch("SELECT id FROM roles WHERE slug = 'parent' AND (school_id = ? OR school_id IS NULL) ORDER BY school_id DESC LIMIT 1", [$this->schoolId()])['id'] ?? null;
                        if ($roleId) {
                            $parentPass = !empty($_POST['parent_password']) ? $_POST['parent_password'] : 'Password@123';
                            (new \App\Models\User())->create([
                                'school_id' => $this->schoolId(),
                                'name' => $parentFirst . ' ' . $parentLast,
                                'email' => $parentEmail,
                                'phone' => $parentPhone,
                                'password' => password_hash($parentPass, PASSWORD_DEFAULT),
                                'role_id' => $roleId,
                                'parent_id' => $parentId,
                                'status' => 1
                            ]);
                        }
                    }
                }
            }
        }

        if ($parentId) {
            $alreadyLinked = Database::fetch(
                'SELECT id FROM student_parents WHERE school_id = ? AND student_id = ? AND parent_id = ? LIMIT 1',
                [$this->schoolId(), $id, $parentId]
            );
            if (!$alreadyLinked) {
                Database::insert(
                    'INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                    [$this->schoolId(), $id, $parentId, $_POST['parent_relation'] ?? 'Legal Parent / Guardian', 1]
                );
            }
        }

        auditLog('student.create', 'students', 'students', $id, null, $payload);

        $flashMsg = 'Student admitted successfully!';
        if (!empty($_POST['email'])) {
            $flashMsg .= ' [Student Portal Login: ' . htmlspecialchars($_POST['email']) . ' | Password: ' . htmlspecialchars(!empty($_POST['student_password']) ? $_POST['student_password'] : 'Password@123') . ']';
        }
        if (!empty($_POST['parent_email'])) {
            $flashMsg .= ' [Parent Portal Login: ' . htmlspecialchars($_POST['parent_email']) . ' | Password: ' . htmlspecialchars(!empty($_POST['parent_password']) ? $_POST['parent_password'] : 'Password@123') . ']';
        }
        flash('success', $flashMsg);
        redirect(url('students/' . $id));
    }

    public function show(string $id): void
    {
        requirePermission('students.view');
        $studentId = (int) $id;
        $schoolId = (int) $this->schoolId();

        $student = (new Student())->findDetailed($studentId);
        if (!$student) {
            flash('error', 'Student not found.');
            redirect(url('students'));
            return;
        }

        $parents = Database::fetchAll(
            'SELECT p.*, sp.relationship, sp.is_primary FROM parents p
             INNER JOIN student_parents sp ON sp.parent_id = p.id
             WHERE sp.school_id = ? AND sp.student_id = ?',
            [$schoolId, $studentId]
        );

        $history = Database::fetchAll(
            'SELECT h.*, c.name AS class_name, sec.name AS section_name, ay.name AS academic_year
             FROM student_academic_history h
             LEFT JOIN classes c ON c.id = h.class_id
             LEFT JOIN sections sec ON sec.id = h.section_id
             LEFT JOIN academic_years ay ON ay.id = h.academic_year_id
             WHERE h.school_id = ? AND h.student_id = ? ORDER BY h.created_at DESC',
            [$schoolId, $studentId]
        );

        // Financial Ledger (Invoices & Balance)
        $invoices = Database::fetchAll(
            'SELECT i.*, COALESCE(SUM(p.amount), 0) AS paid_amount
             FROM student_fee_invoices i
             LEFT JOIN payments p ON p.invoice_id = i.id
             WHERE i.school_id = ? AND i.student_id = ?
             GROUP BY i.id
             ORDER BY i.created_at DESC LIMIT 10',
            [$schoolId, $studentId]
        );

        $totalInvoiced = 0.0;
        $totalOutstanding = 0.0;
        foreach ($invoices as &$inv) {
            $totalInvoiced += (float) ($inv['total_amount'] ?? 0);
            $paid = (float) ($inv['paid_amount'] ?? 0);
            $total = (float) ($inv['total_amount'] ?? 0);
            $inv['due_amount'] = max(0.0, $total - $paid);
            $totalOutstanding += $inv['due_amount'];
        }
        unset($inv);

        // Attendance stats in last 90 days
        $attRows = Database::fetchAll(
            'SELECT status, COUNT(*) AS count FROM student_attendance
             WHERE school_id = ? AND student_id = ? AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
             GROUP BY status',
            [$schoolId, $studentId]
        );
        $attCounts = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];
        $totalDays = 0;
        foreach ($attRows as $ar) {
            $st = $ar['status'];
            $c = (int) $ar['count'];
            $attCounts[$st] = $c;
            $totalDays += $c;
        }
        $presentDays = $attCounts['present'] + $attCounts['late'];
        $attendanceRate = $totalDays > 0 ? round(($presentDays / $totalDays) * 100, 1) : 100.0;

        // Examination Snapshots
        $examResults = Database::fetchAll(
            'SELECT snap.*, ex.name AS exam_name, ex.status AS exam_status
             FROM exam_results_snapshot snap
             JOIN exams ex ON ex.id = snap.exam_id
             WHERE snap.school_id = ? AND snap.student_id = ?
             ORDER BY snap.created_at DESC LIMIT 5',
            [$schoolId, $studentId]
        );

        // Activity & Audit Timeline
        $timelineLogs = Database::fetchAll(
            'SELECT a.*, u.name AS author_name, r.name AS author_role
             FROM audit_logs a
             LEFT JOIN users u ON u.id = a.user_id
             LEFT JOIN roles r ON r.id = u.role_id
             WHERE a.school_id = ? AND (
                 (a.entity_type = "students" AND a.entity_id = ?) OR
                 (a.entity_type = "student_fee_invoices" AND a.entity_id IN (SELECT id FROM student_fee_invoices WHERE student_id = ?))
             )
             ORDER BY a.created_at DESC LIMIT 20',
            [$schoolId, $studentId, $studentId]
        );

        $this->view('students/show', [
            'title' => trim($student['first_name'] . ' ' . $student['last_name']) . ' — Student Dossier',
            'student' => $student,
            'parents' => $parents,
            'history' => $history,
            'invoices' => $invoices,
            'total_invoiced' => $totalInvoiced,
            'total_outstanding' => $totalOutstanding,
            'attendance_rate' => $attendanceRate,
            'attendance_counts' => $attCounts,
            'total_attendance_days' => $totalDays,
            'exam_results' => $examResults,
            'timeline_logs' => $timelineLogs,
        ]);
    }

    public function edit(string $id): void
    {
        requirePermission('students.edit');
        $student = (new Student())->findDetailed((int) $id);
        if (!$student) {
            flash('error', 'Student not found.');
            redirect(url('students'));
        }
        $schoolId = $this->schoolId();
        $sections = (new Section())->byClass((int) $student['class_id']);
        
        $currentParent = \Core\Database::fetch("
            SELECT p.*, sp.relationship 
            FROM parents p 
            INNER JOIN student_parents sp ON sp.parent_id = p.id 
            WHERE sp.student_id = ? AND sp.school_id = ? 
            ORDER BY sp.is_primary DESC 
            LIMIT 1
        ", [(int)$id, $schoolId]);

        $subjectsRaw = Database::fetchAll(
            'SELECT s.id, s.name, s.code, s.class_id, s.type, c.name AS class_name
             FROM subjects s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE s.school_id = ? AND s.status = "active"
             ORDER BY c.numeric_value ASC, s.name ASC',
            [$schoolId]
        );
        $classSubjectMap = [];
        $allSubjects = [];
        foreach ($subjectsRaw as $sub) {
            $cId = (int)$sub['class_id'];
            if (!isset($classSubjectMap[$cId])) {
                $classSubjectMap[$cId] = [];
            }
            $classSubjectMap[$cId][] = $sub;
            $allSubjects[] = $sub;
        }

        $existingParents = Database::fetchAll(
            'SELECT id, first_name, last_name, email, phone FROM parents WHERE school_id = ? ORDER BY first_name ASC',
            [$schoolId]
        );

        $this->view('students/form', [
            'title' => 'Edit Student',
            'student' => $student,
            'classes' => (new ClassModel())->withSections(),
            'sections' => $sections,
            'current_parent' => $currentParent,
            'allSubjects' => $allSubjects,
            'classSubjectMap' => $classSubjectMap,
            'existingParents' => $existingParents,
            'transport_routes' => Database::fetchAll('SELECT id, title, fare FROM transport_routes WHERE school_id = ? AND status = "active" ORDER BY title', [$schoolId]),
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('students.edit');
        $this->requireCsrf();
        $model = new Student();
        $old = $model->find((int) $id);
        if (!$old) {
            flash('error', 'Student not found.');
            redirect(url('students'));
            return;
        }

        $data = $this->validate($_POST, [
            'first_name' => 'required|max:100',
            'last_name' => 'required|max:100',
            'gender' => 'nullable|in:male,female,other',
            'status' => 'nullable|in:active,inactive,graduated,transferred,suspended,withdrawn',
        ]);

        $status = !empty($_POST['status']) ? trim((string)$_POST['status']) : ($old['status'] ?? 'active');
        if (!in_array($status, ['active', 'inactive', 'graduated', 'transferred', 'suspended', 'withdrawn'], true)) {
            $status = $old['status'] ?? 'active';
        }

        // Section handling: if section_id empty, preserve old section
        $sectionId = !empty($_POST['section_id']) ? (int) $_POST['section_id'] : ($old['section_id'] ?? null);

        // Address aggregation
        $addressParts = array_filter([
            $_POST['street_address'] ?? '',
            $_POST['city'] ?? '',
            $_POST['state'] ?? '',
            $_POST['zip'] ?? '',
            $_POST['country'] ?? ''
        ]);
        $fullAddress = !empty($addressParts) ? implode(', ', $addressParts) : (!empty($_POST['address']) ? $_POST['address'] : ($old['address'] ?? null));

        // Date of birth & admission date normalization
        $dob = !empty($_POST['date_of_birth']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['date_of_birth']))) : ($old['date_of_birth'] ?? null);
        $admDate = !empty($_POST['admission_date']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['admission_date']))) : ($old['admission_date'] ?? date('Y-m-d'));

        // Full name with middle name
        $middleName = trim((string)($_POST['middle_name'] ?? ''));
        $firstName = trim($data['first_name']);
        if ($middleName !== '' && !str_contains($firstName, $middleName)) {
            $firstName .= ' ' . $middleName;
        }

        $payload = [
            'roll_no' => !empty($_POST['roll_no']) ? $_POST['roll_no'] : null,
            'first_name' => $firstName,
            'last_name' => $data['last_name'],
            'gender' => $_POST['gender'] ?? $old['gender'],
            'date_of_birth' => $dob,
            'admission_date' => $admDate,
            'class_id' => (int) ($_POST['class_id'] ?? $old['class_id']),
            'section_id' => $sectionId,
            'email' => $_POST['email'] ?? null,
            'phone' => $_POST['phone'] ?? null,
            'address' => $fullAddress,
            'medical_note' => $_POST['medical_note'] ?? null,
            'emergency_contact' => $_POST['emergency_contact'] ?? ($_POST['parent_first_name'] ?? ($old['emergency_contact'] ?? null)),
            'emergency_phone' => $_POST['emergency_phone'] ?? ($_POST['parent_phone'] ?? ($old['emergency_phone'] ?? null)),
            'status' => $status,
            'transport_route_id' => !empty($_POST['transport_route_id']) ? (int)$_POST['transport_route_id'] : null,
        ];

        if (!empty($_FILES['profile_image']['name'])) {
            $payload['profile_image'] = upload_file($_FILES['profile_image'], 'profiles', app_config('upload.allowed_images'));
        }
        $model->update((int) $id, $payload);

        // Update linked user account if exists
        if (!empty($old['user_id'])) {
            $userUpdates = [
                'name' => $firstName . ' ' . $data['last_name'],
            ];
            if (!empty($_POST['email'])) {
                $userUpdates['email'] = $_POST['email'];
            }
            if (!empty($_POST['phone'])) {
                $userUpdates['phone'] = $_POST['phone'];
            }
            if (!empty($_POST['student_password'])) {
                $userUpdates['password'] = password_hash($_POST['student_password'], PASSWORD_DEFAULT);
            }
            (new \App\Models\User())->update((int)$old['user_id'], $userUpdates);
        }

        // Parent / Guardian handling
        $parentId = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
        if (!empty($_POST['link_existing_parent']) && !empty($_POST['existing_parent_id'])) {
            $parentId = (int)$_POST['existing_parent_id'];
            $linked = Database::fetch("SELECT id FROM student_parents WHERE student_id = ? AND parent_id = ?", [(int)$id, $parentId]);
            if (!$linked) {
                Database::insert(
                    'INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                    [$this->schoolId(), (int)$id, $parentId, $_POST['parent_relation'] ?? 'Legal Parent / Guardian', 1]
                );
            }
        } elseif ($parentId) {
            $parentFirst = trim((string)($_POST['parent_first_name'] ?? ''));
            $parentLast = trim((string)($_POST['parent_last_name'] ?? ''));
            $parentEmail = trim((string)($_POST['parent_email'] ?? ''));
            $parentPhone = trim((string)($_POST['parent_phone'] ?? ''));
            $parentRelation = trim((string)($_POST['parent_relation'] ?? 'Legal Parent / Guardian'));

            if ($parentFirst !== '') {
                (new \App\Models\ParentModel())->update($parentId, [
                    'first_name' => $parentFirst,
                    'last_name' => $parentLast,
                    'email' => $parentEmail ?: null,
                    'phone' => $parentPhone ?: null,
                    'relation_label' => $parentRelation,
                ]);

                if ($parentEmail !== '') {
                    $user = Database::fetch("SELECT id FROM users WHERE parent_id = ? AND school_id = ?", [$parentId, $this->schoolId()]);
                    if ($user) {
                        (new \App\Models\User())->update((int)$user['id'], [
                            'name' => $parentFirst . ' ' . $parentLast,
                            'email' => $parentEmail,
                            'phone' => $parentPhone ?: null,
                        ]);
                    }
                }

                Database::execute("UPDATE student_parents SET relationship = ? WHERE student_id = ? AND parent_id = ?", [$parentRelation, (int)$id, $parentId]);
            }
        } elseif (!empty($_POST['parent_first_name'])) {
            $parentFirst = trim((string)$_POST['parent_first_name']);
            $parentLast = trim((string)($_POST['parent_last_name'] ?? ''));
            $parentEmail = trim((string)($_POST['parent_email'] ?? ''));
            $parentPhone = trim((string)($_POST['parent_phone'] ?? ''));
            $parentRelation = trim((string)($_POST['parent_relation'] ?? 'Legal Parent / Guardian'));

            $newParentId = (new \App\Models\ParentModel())->create([
                'school_id' => $this->schoolId(),
                'first_name' => $parentFirst,
                'last_name' => $parentLast,
                'email' => $parentEmail ?: null,
                'phone' => $parentPhone ?: null,
                'relation_label' => $parentRelation,
                'status' => 1,
            ]);

            Database::insert(
                'INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
                [$this->schoolId(), (int)$id, $newParentId, $parentRelation, 1]
            );
        }

        auditLog('student.update', 'students', 'students', (int) $id, $old, $payload);
        flash('success', 'Student updated successfully.');
        redirect(url('students/' . $id));
    }

    public function quickFee(): void
    {
        requirePermission('finance.manage');
        $this->requireCsrf();

        $studentId = (int) ($_POST['student_id'] ?? 0);
        $feeType = trim((string) ($_POST['fee_type'] ?? ''));
        $paymentMethod = trim((string) ($_POST['payment_method'] ?? 'cash'));
        $paymentStatus = trim((string) ($_POST['payment_status'] ?? 'paid'));
        $amount = (float) ($_POST['amount'] ?? 0);

        if ($studentId <= 0 || empty($feeType)) {
            flash('error', 'Student and Fee Type are required.');
            redirect(url('students'));
            return;
        }

        $schoolId = $this->schoolId();
        $student = Database::fetch('SELECT id, first_name, last_name FROM students WHERE id = ? AND school_id = ?', [$studentId, $schoolId]);
        if (!$student) {
            flash('error', 'Student not found.');
            redirect(url('students'));
            return;
        }

        // Find or check fee category for default amount if amount is 0
        $feeCat = Database::fetch('SELECT id, name, amount FROM fee_categories WHERE school_id = ? AND (id = ? OR name = ?)', [$schoolId, $feeType, $feeType]);
        $catId = $feeCat ? (int)$feeCat['id'] : null;
        $titleName = $feeCat ? $feeCat['name'] : $feeType;
        
        if ($amount <= 0) {
            $amount = $feeCat ? (float)$feeCat['amount'] : 0.0;
        }

        $feeService = new \App\Services\FeeService();
        $invoiceTitle = $titleName . ' - ' . $student['first_name'] . ' ' . $student['last_name'];
        $dueDate = date('Y-m-d');
        $invoiceDate = date('Y-m-d');

        try {
            $invoiceId = $feeService->createInvoice([
                'student_id' => $studentId,
                'title' => $invoiceTitle,
                'invoice_date' => $invoiceDate,
                'due_date' => $dueDate,
                'discount' => 0,
                'notes' => 'Quick fee entry from Students directory. Mode: ' . ucfirst($paymentMethod) . ', Status: ' . ucfirst($paymentStatus),
            ], [
                [
                    'description' => $titleName,
                    'amount' => $amount,
                    'fee_category_id' => $catId,
                ]
            ]);

            // If marked as paid, record the payment immediately
            if ($paymentStatus === 'paid' && $amount > 0) {
                $validMethods = ['cash', 'online', 'bank', 'card', 'cheque'];
                $methodToUse = in_array($paymentMethod, $validMethods, true) ? $paymentMethod : 'cash';
                $feeService->recordPayment(
                    $invoiceId,
                    $amount,
                    $methodToUse,
                    $invoiceDate,
                    'QUICK-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6)),
                    'Quick payment registered via student directory.'
                );
            }

            flash('success', "Fee record saved successfully for {$student['first_name']} {$student['last_name']} ({$titleName} - " . strtoupper($paymentStatus) . ").");
        } catch (\Throwable $e) {
            flash('error', 'Failed to save fee: ' . $e->getMessage());
        }

        redirect(url('students'));
    }

    public function destroy(string $id): void
    {
        requirePermission('students.delete');
        $this->requireCsrf();
        $model = new Student();
        $old = $model->find((int) $id);
        if ($old) {
            $model->update((int) $id, ['status' => 'withdrawn']);
            auditLog('student.withdraw', 'students', 'students', (int) $id, $old, ['status' => 'withdrawn']);
            flash('success', 'Student marked as withdrawn.');
        }
        redirect(url('students'));
    }

    public function bulkAction(): void
    {
        requirePermission('students.view');
        $this->requireCsrf();

        $action = $_POST['action'] ?? '';
        $rawIds = $_POST['student_ids'] ?? [];
        if (!is_array($rawIds) || empty($rawIds)) {
            flash('error', 'No students selected for bulk action.');
            redirect(url('students'));
            return;
        }

        $ids = array_map('intval', $rawIds);
        $schoolId = $this->schoolId();
        $model = new Student();

        if ($action === 'status') {
            requirePermission('students.edit');
            $newStatus = $_POST['bulk_status'] ?? 'active';
            $validStatuses = ['active', 'inactive', 'graduated', 'transferred', 'suspended', 'withdrawn'];
            if (!in_array($newStatus, $validStatuses, true)) {
                flash('error', 'Invalid status specified.');
                redirect(url('students'));
                return;
            }

            $count = 0;
            foreach ($ids as $sId) {
                $stu = Database::fetch('SELECT id, status FROM students WHERE id = ? AND school_id = ?', [$sId, $schoolId]);
                if ($stu) {
                    $model->update($sId, ['status' => $newStatus]);
                    $count++;
                }
            }
            flash('success', "Updated status for {$count} student(s) to " . ucfirst($newStatus) . ".");
        } elseif ($action === 'withdraw' || $action === 'delete') {
            requirePermission('students.delete');
            $count = 0;
            foreach ($ids as $sId) {
                $stu = Database::fetch('SELECT id, status FROM students WHERE id = ? AND school_id = ?', [$sId, $schoolId]);
                if ($stu) {
                    $model->update($sId, ['status' => 'withdrawn']);
                    auditLog('student.bulk_withdraw', 'students', 'students', $sId, $stu, ['status' => 'withdrawn']);
                    $count++;
                }
            }
            flash('success', "Marked {$count} student(s) as withdrawn.");
        } else {
            flash('error', 'Unknown bulk action.');
        }

        redirect(url('students'));
    }

    public function bulkImport(): void
    {
        requirePermission('students.create');
        $this->requireCsrf();

        if (empty($_FILES['csv_file']['tmp_name']) || !is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
            flash('error', 'Please upload a valid CSV file.');
            redirect(url('students'));
            return;
        }

        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if (!$handle) {
            flash('error', 'Unable to read the uploaded CSV file.');
            redirect(url('students'));
            return;
        }

        $header = fgetcsv($handle);
        if (!$header) {
            fclose($handle);
            flash('error', 'The CSV file is empty or formatted incorrectly.');
            redirect(url('students'));
            return;
        }

        // Clean headers
        $header = array_map(fn($h) => strtolower(trim($h)), $header);
        $schoolId = $this->schoolId();
        $fallbackClassId = !empty($_POST['class_id']) ? (int)$_POST['class_id'] : null;
        $fallbackSectionId = !empty($_POST['section_id']) ? (int)$_POST['section_id'] : null;
        $activeAyId = activeAcademicYearId();

        $model = new Student();
        $imported = 0;

        while (($row = fgetcsv($handle)) !== false) {
            if (empty(array_filter($row))) {
                continue;
            }
            $record = array_combine($header, array_pad($row, count($header), ''));
            if (!$record) {
                continue;
            }

            $firstName = trim($record['first_name'] ?? $record['name'] ?? '');
            $lastName = trim($record['last_name'] ?? '');
            if ($firstName === '') {
                continue;
            }

            $gender = strtolower(trim($record['gender'] ?? 'other'));
            if (!in_array($gender, ['male', 'female', 'other'], true)) {
                $gender = 'other';
            }

            $admissionNo = trim($record['admission_no'] ?? '');
            if ($admissionNo === '') {
                $admissionNo = $model->nextAdmissionNo();
            }

            // Check duplicate admission no
            $exists = Database::fetch('SELECT id FROM students WHERE admission_no = ? AND school_id = ?', [$admissionNo, $schoolId]);
            if ($exists) {
                $admissionNo = $model->nextAdmissionNo();
            }

            $rollNo = trim($record['roll_no'] ?? '');
            $classId = $fallbackClassId;
            $sectionId = $fallbackSectionId;

            $stuId = $model->create([
                'admission_no' => $admissionNo,
                'roll_no' => $rollNo ?: null,
                'first_name' => $firstName,
                'last_name' => $lastName ?: 'Student',
                'gender' => $gender,
                'class_id' => $classId,
                'section_id' => $sectionId,
                'academic_year_id' => $activeAyId,
                'admission_date' => date('Y-m-d'),
                'status' => 'active',
                'phone' => trim($record['phone'] ?? ''),
                'emergency_contact' => trim($record['emergency_contact'] ?? $record['parent_name'] ?? ''),
                'emergency_phone' => trim($record['emergency_phone'] ?? $record['parent_phone'] ?? ''),
            ]);

            if ($stuId && $classId) {
                Database::insert(
                    'INSERT INTO student_academic_history (school_id, student_id, academic_year_id, class_id, section_id, roll_no, result_status, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
                    [$schoolId, $stuId, $activeAyId, $classId, $sectionId, $rollNo ?: null, 'enrolled']
                );
            }

            // Optional parent entry
            $parentName = trim($record['parent_name'] ?? $record['guardian_name'] ?? '');
            $parentPhone = trim($record['parent_phone'] ?? $record['guardian_phone'] ?? '');
            if ($parentName !== '' && $stuId) {
                $pParts = explode(' ', $parentName, 2);
                $pFirst = $pParts[0];
                $pLast = $pParts[1] ?? 'Parent';
                $pId = (new \App\Models\ParentModel())->create([
                    'school_id' => $schoolId,
                    'first_name' => $pFirst,
                    'last_name' => $pLast,
                    'phone' => $parentPhone,
                    'relation_label' => 'Parent',
                    'status' => 1
                ]);
                Database::insert(
                    'INSERT INTO student_parents (school_id, student_id, parent_id, relationship, is_primary, created_at) VALUES (?, ?, ?, ?, 1, NOW())',
                    [$schoolId, $stuId, $pId, 'Parent']
                );
            }

            $imported++;
        }

        fclose($handle);
        flash('success', "Successfully imported {$imported} student(s) into the directory.");
        redirect(url('students'));
    }

    public function exportCsv(): void
    {
        requirePermission('students.view');
        $schoolId = $this->schoolId();
        
        $sql = 'SELECT s.admission_no, s.roll_no, s.first_name, s.last_name, s.gender,
                       c.name AS class_name, sec.name AS section_name,
                       p.first_name AS parent_first, p.last_name AS parent_last, p.phone AS parent_phone,
                       s.status, s.admission_date
                FROM students s
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN student_parents sp ON sp.student_id = s.id AND sp.is_primary = 1
                LEFT JOIN parents p ON p.id = sp.parent_id
                WHERE s.school_id = ? ORDER BY s.first_name, s.last_name';
        $rows = Database::fetchAll($sql, [$schoolId]);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="students_directory_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Admission No', 'Roll No', 'First Name', 'Last Name', 'Gender', 'Class', 'Section', 'Parent Name', 'Parent Phone', 'Status', 'Admission Date']);
        foreach ($rows as $r) {
            $pName = trim(($r['parent_first'] ?? '') . ' ' . ($r['parent_last'] ?? ''));
            fputcsv($out, [
                $r['admission_no'],
                $r['roll_no'] ?? '',
                $r['first_name'],
                $r['last_name'],
                ucfirst($r['gender'] ?? ''),
                $r['class_name'] ?? 'Unassigned',
                $r['section_name'] ?? 'Unassigned',
                $pName ?: 'Not Assigned',
                $r['parent_phone'] ?? '',
                ucfirst($r['status']),
                $r['admission_date'] ?? ''
            ]);
        }
        fclose($out);
        exit;
    }
}
