<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Assignment;
use App\Models\Exam;
use App\Models\FeeInvoice;
use App\Models\ParentModel;
use App\Models\Student;
use App\Models\Timetable;
use App\Services\AttendanceService;
use App\Services\DashboardService;
use App\Services\ExamService;
use Core\Auth;
use Core\Controller;

final class ParentPortalController extends Controller
{
    private function ensureParentStudent(?int $studentId = null): array
    {
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();
        $schoolId = (int)Auth::schoolId();

        // If school_admin or principal is inspecting/previewing
        if (in_array($role, ['school_admin', 'super_admin', 'admin', 'principal'], true)) {
            $student = \Core\Database::fetch(
                "SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                 FROM students s
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                 WHERE s.school_id = ? ORDER BY s.id ASC LIMIT 1",
                [$schoolId]
            );
            if (!$student) {
                $student = [
                    'id' => 1,
                    'first_name' => 'Sample',
                    'last_name' => 'Student',
                    'admission_no' => 'DEMO-001',
                    'school_id' => $schoolId,
                    'class_id' => 1,
                    'section_id' => 1,
                    'status' => 'active',
                    'admission_date' => date('Y-m-d')
                ];
            }
            return [
                'parent_id' => 0,
                'student_id' => (int)$student['id'],
                'children' => [$student],
                'student' => $student
            ];
        }

        requirePermission('parent.portal');
        $parentId = (int) ($user['parent_id'] ?? 0);
        if (!$parentId) {
            flash('warning', 'Parent profile not linked to this account.');
            $this->redirect('dashboard');
        }
        $children = (new ParentModel())->children($parentId);
        if (empty($children)) {
            flash('warning', 'No children registered under this parent profile.');
            $this->redirect('dashboard');
        }
        $studentId = $studentId ?? (int) ($_SESSION['selected_student_id'] ?? ($children[0]['id'] ?? 0));
        if (!$studentId || !(new ParentModel())->ownsStudent($parentId, $studentId)) {
            $studentId = (int) $children[0]['id'];
        }
        $_SESSION['selected_student_id'] = $studentId;
        return [
            'parent_id' => $parentId,
            'student_id' => $studentId,
            'children' => $children,
            'student' => (new Student())->findDetailed($studentId) ?? $children[0]
        ];
    }

    public function attendance(): void
    {
        $ctx = $this->ensureParentStudent();
        $studentId = $ctx['student_id'];
        
        $student = $ctx['student'];
        $admissionDate = !empty($student['admission_date']) ? $student['admission_date'] : ($student['created_at'] ?? date('Y-m-d'));
        
        $startMonth = new \DateTime(date('Y-m-01', strtotime($admissionDate)));
        $endMonth = new \DateTime(date('Y-m-01'));
        
        $months = [];
        $currentMonth = clone $startMonth;
        while ($currentMonth <= $endMonth) {
            $months[] = $currentMonth->format('Y-m');
            $currentMonth->modify('+1 month');
        }
        $months = array_reverse($months);

        $selectedMonth = $_GET['month'] ?? date('Y-m');
        if (!in_array($selectedMonth, $months)) {
            $selectedMonth = $months[0] ?? date('Y-m');
        }

        $from = $selectedMonth . '-01';
        $to = date('Y-m-t', strtotime($from));

        $attendanceRows = \Core\Database::fetchAll(
            'SELECT attendance_date, status FROM student_attendance WHERE school_id = ? AND student_id = ? AND attendance_date BETWEEN ? AND ? ORDER BY attendance_date ASC',
            [$this->schoolId(), $studentId, $from, $to]
        );

        $pct = (new AttendanceService())->studentPercentage($studentId);
        
        $this->view('parents/attendance', [
            'title' => 'Child Attendance',
            'ctx' => $ctx,
            'percentage' => $pct,
            'months' => $months,
            'selectedMonth' => $selectedMonth,
            'attendanceRows' => $attendanceRows
        ]);
    }

    public function assignments(): void
    {
        $ctx = $this->ensureParentStudent();
        $this->view('parents/assignments', [
            'title' => 'Assignments',
            'ctx' => $ctx,
            'assignments' => (new Assignment())->forStudent($ctx['student_id']),
        ]);
    }

    public function exams(): void
    {
        $ctx = $this->ensureParentStudent();
        $exams = (new Exam())->listAll();
        $this->view('parents/exams', [
            'title' => 'Exam Results',
            'ctx' => $ctx,
            'exams' => $exams,
            'service' => new ExamService(),
        ]);
    }

    public function fees(): void
    {
        $ctx = $this->ensureParentStudent();
        $this->view('parents/fees', [
            'title' => 'Fee Status',
            'ctx' => $ctx,
            'invoices' => (new FeeInvoice())->forStudent($ctx['student_id']),
        ]);
    }

    public function timetable(): void
    {
        $ctx = $this->ensureParentStudent();
        $student = $ctx['student'];
        $rows = [];
        if ($student && $student['class_id'] && $student['section_id']) {
            $rows = (new Timetable())->forClass((int) $student['class_id'], (int) $student['section_id']);
        }
        $this->view('parents/timetable', [
            'title' => 'Timetable',
            'ctx' => $ctx,
            'rows' => $rows,
        ]);
    }
}
