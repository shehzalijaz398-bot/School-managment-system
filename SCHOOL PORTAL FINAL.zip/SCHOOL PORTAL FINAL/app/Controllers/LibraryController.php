<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Book;
use App\Models\BookCategory;
use App\Models\BookIssue;
use App\Models\Student;
use App\Models\Employee;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class LibraryController extends Controller
{
    public function index(): void
    {
        requirePermission('library.view');
        
        $bookModel = new Book();
        $issueModel = new BookIssue();
        
        $stats = [
            'total_books' => Database::fetch("SELECT SUM(quantity) as t FROM books WHERE school_id = ?", [$this->schoolId()])['t'] ?? 0,
            'available_books' => Database::fetch("SELECT SUM(available_quantity) as t FROM books WHERE school_id = ?", [$this->schoolId()])['t'] ?? 0,
            'issued_books' => Database::fetch("SELECT COUNT(*) as t FROM book_issues WHERE status = 'issued' AND school_id = ?", [$this->schoolId()])['t'] ?? 0,
        ];
        
        $this->view('library/index', [
            'title' => 'Library Dashboard',
            'stats' => $stats
        ]);
    }

    // --- BOOKS ---

    public function books(): void
    {
        requirePermission('library.view');
        
        $query = $_GET['q'] ?? '';
        $bookModel = new Book();
        
        if ($query !== '') {
            $books = $bookModel->search($query);
        } else {
            $books = $bookModel->getWithCategory();
        }
        
        $this->view('library/books', [
            'title' => 'Books Catalog',
            'books' => $books,
            'categories' => (new BookCategory())->all('name ASC'),
            'query' => $query
        ]);
    }

    public function storeBook(): void
    {
        requirePermission('library.manage');
        $this->requireCsrf();
        
        $data = [
            'category_id' => (int)$_POST['category_id'],
            'title' => trim($_POST['title']),
            'author' => trim($_POST['author']),
            'isbn' => trim($_POST['isbn'] ?? ''),
            'publisher' => trim($_POST['publisher'] ?? ''),
            'quantity' => (int)$_POST['quantity'],
            'available_quantity' => (int)$_POST['quantity'],
            'status' => $_POST['status'] ?? 'active'
        ];
        
        if (empty($data['title']) || empty($data['author']) || $data['quantity'] < 1) {
            flash('error', 'Please fill all required fields correctly.');
            redirect(url('library/books'));
            return;
        }
        
        (new Book())->create($data);
        flash('success', 'Book added successfully.');
        redirect(url('library/books'));
    }

    public function updateBook(string $id): void
    {
        requirePermission('library.manage');
        $this->requireCsrf();
        
        $bookId = (int)$id;
        $bookModel = new Book();
        $book = $bookModel->find($bookId);
        
        if (!$book) {
            flash('error', 'Book not found.');
            redirect(url('library/books'));
            return;
        }
        
        $newQuantity = (int)$_POST['quantity'];
        $diff = $newQuantity - $book['quantity'];
        
        $data = [
            'category_id' => (int)$_POST['category_id'],
            'title' => trim($_POST['title']),
            'author' => trim($_POST['author']),
            'isbn' => trim($_POST['isbn'] ?? ''),
            'publisher' => trim($_POST['publisher'] ?? ''),
            'quantity' => $newQuantity,
            'available_quantity' => $book['available_quantity'] + $diff,
            'status' => $_POST['status'] ?? 'active'
        ];
        
        if ($data['available_quantity'] < 0) {
            flash('error', 'Cannot reduce quantity below currently issued books.');
            redirect(url('library/books'));
            return;
        }
        
        $bookModel->update($bookId, $data);
        flash('success', 'Book updated successfully.');
        redirect(url('library/books'));
    }

    // --- CATEGORIES ---
    
    public function categories(): void
    {
        requirePermission('library.manage');
        
        $this->view('library/categories', [
            'title' => 'Book Categories',
            'categories' => (new BookCategory())->all('name ASC')
        ]);
    }
    
    public function storeCategory(): void
    {
        requirePermission('library.manage');
        $this->requireCsrf();
        
        $name = trim($_POST['name'] ?? '');
        if (empty($name)) {
            flash('error', 'Category name is required.');
        } else {
            (new BookCategory())->create(['name' => $name]);
            flash('success', 'Category added.');
        }
        redirect(url('library/categories'));
    }

    // --- ISSUES & RETURNS ---

    public function issues(): void
    {
        requirePermission('library.view');
        
        $status = $_GET['status'] ?? null;
        if ($status === 'all') $status = null;
        
        $issues = (new BookIssue())->getWithDetails($status);
        
        $this->view('library/issues', [
            'title' => 'Book Issues',
            'issues' => $issues,
            'books' => (new Book())->getWithCategory(),
            'students' => (new Student())->all('first_name ASC, last_name ASC'),
            'employees' => (new Employee())->all('first_name ASC')
        ]);
    }

    public function issueBook(): void
    {
        requirePermission('library.manage');
        $this->requireCsrf();
        
        $bookId = (int)$_POST['book_id'];
        $memberType = $_POST['member_type'];
        $memberId = (int)$_POST['member_id'];
        $dueDate = $_POST['due_date'];
        
        $bookModel = new Book();
        $book = $bookModel->find($bookId);
        
        if (!$book || $book['available_quantity'] <= 0) {
            flash('error', 'Book is not available for issue.');
            redirect(url('library/issues'));
            return;
        }
        
        Database::beginTransaction();
        
        try {
            // Re-check available quantity with lock in real app, but we rely on atomic update
            $updated = $bookModel->adjustAvailableQuantity($bookId, -1);
            
            if (!$updated) {
                Database::rollBack();
                flash('error', 'Book is not available for issue.');
                redirect(url('library/issues'));
                return;
            }
            
            (new BookIssue())->create([
                'book_id' => $bookId,
                'member_type' => $memberType,
                'member_id' => $memberId,
                'issue_date' => date('Y-m-d'),
                'due_date' => $dueDate,
                'status' => 'issued',
                'issued_by' => Auth::id()
            ]);
            
            Database::commit();
            flash('success', 'Book issued successfully.');
        } catch (\Exception $e) {
            Database::rollBack();
            flash('error', 'Failed to issue book.');
        }
        
        redirect(url('library/issues'));
    }

    public function returnBook(string $id): void
    {
        requirePermission('library.manage');
        $this->requireCsrf();
        
        $issueId = (int)$id;
        $issueModel = new BookIssue();
        $issue = $issueModel->find($issueId);
        
        if (!$issue || $issue['status'] === 'returned') {
            flash('error', 'Invalid issue record or already returned.');
            redirect(url('library/issues'));
            return;
        }
        
        Database::beginTransaction();
        
        try {
            $issueModel->update($issueId, [
                'status' => 'returned',
                'return_date' => date('Y-m-d')
            ]);
            
            (new Book())->adjustAvailableQuantity((int)$issue['book_id'], 1);
            
            Database::commit();
            flash('success', 'Book returned successfully.');
        } catch (\Exception $e) {
            Database::rollBack();
            flash('error', 'Failed to return book.');
        }
        
        redirect(url('library/issues'));
    }
}
