<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\Employee;
use App\Models\Section;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use App\Services\AttendanceService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class TeacherController extends Controller
{
    public function index(): void
    {
        requirePermission('teachers.view');
        
        $search = $_GET['q'] ?? '';
        $status = $_GET['status'] ?? '';
        
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $sql = 'SELECT t.*, e.employee_code, e.first_name, e.last_name, e.email, e.phone, e.status AS emp_status, e.profile_image, e.joining_date
                FROM teachers t
                INNER JOIN employees e ON e.id = t.employee_id
                WHERE t.school_id = ?';
        $params = [$this->schoolId()];
        
        if ($search !== '') {
            $sql .= ' AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ? OR e.email LIKE ? OR t.specialization LIKE ?)';
            $q = "%$search%";
            $params = array_merge($params, [$q, $q, $q, $q, $q]);
        }
        
        if ($status !== '') {
            if ($status === 'active' || $status === 'inactive') {
                $sql .= ' AND e.status = ?';
                $params[] = $status;
            } else {
                $sql .= ' AND t.status = ?';
                $params[] = (int)$status;
            }
        }
        
        // Count total
        $countSql = str_replace('t.*, e.employee_code, e.first_name, e.last_name, e.email, e.phone, e.status AS emp_status, e.profile_image, e.joining_date', 'COUNT(*) AS total', $sql);
        $totalRow = Database::fetch($countSql, $params);
        $total = (int)($totalRow['total'] ?? 0);
        $totalPages = ceil($total / $limit);
        
        $sql .= ' ORDER BY e.first_name ASC LIMIT ' . $limit . ' OFFSET ' . $offset;
        $teachers = Database::fetchAll($sql, $params);
        
        // Fetch classes/subjects for each teacher
        foreach ($teachers as &$teacher) {
            $teacher['assignments'] = Database::fetchAll(
                'SELECT ta.id, c.name AS class_name, s.name AS subject_name 
                 FROM teacher_assignments ta
                 INNER JOIN classes c ON c.id = ta.class_id
                 INNER JOIN subjects s ON s.id = ta.subject_id
                 WHERE ta.teacher_id = ? AND ta.school_id = ? AND ta.status = 1',
                [(int)$teacher['id'], $this->schoolId()]
            );
        }

        $this->view('teachers/index', [
            'title' => 'Teachers',
            'teachers' => $teachers,
            'filters' => ['q' => $search, 'status' => $status],
            'page' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function show(string $id): void
    {
        requirePermission('teachers.view');
        $teacher = (new Teacher())->findDetailed((int) $id);
        if (!$teacher) {
            flash('error', 'Teacher not found.');
            redirect(url('teachers'));
        }

        $specs = array_filter(array_map('trim', explode(',', (string) ($teacher['specialization'] ?? ''))));
        $specializationSubjects = [];
        if (!empty($specs)) {
            $inClause = implode(',', array_fill(0, count($specs), '?'));
            $params = array_merge([$this->schoolId()], $specs);
            $specializationSubjects = Database::fetchAll(
                "SELECT * FROM subjects WHERE school_id = ? AND name IN ($inClause) ORDER BY name ASC",
                $params
            );
        }

        $this->view('teachers/show', [
            'title' => $teacher['first_name'] . ' ' . $teacher['last_name'],
            'teacher' => $teacher,
            'assignments' => (new Teacher())->assignments((int) $id),
            'classes' => (new ClassModel())->withSections(),
            'specializationSubjects' => $specializationSubjects,
        ]);
    }

    public function create(): void
    {
        requirePermission('teachers.create');
        $this->view('teachers/form', [
            'title' => 'Add Teacher',
            'subjects' => (new Subject())->all('name ASC'),
        ]);
    }

    public function store(): void
    {
        requirePermission('teachers.create');
        $this->requireCsrf();
        try {
            \App\Services\Platform\PlanLimitService::assertCanCreate('teachers');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('teachers/create'));
        }

        $data = $this->validate($_POST, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email',
            'login_password' => 'required|min:8',
            'login_password_confirm' => 'required',
        ]);

        if ($data['login_password'] !== $data['login_password_confirm']) {
            flash('error', 'Passwords do not match.');
            redirect(url('teachers/create'));
        }

        $email = strtolower(trim($data['email']));
        $firstName = trim($data['first_name']);
        $lastName = trim($data['last_name']);

        $existingUser = Database::fetch('SELECT id FROM users WHERE email = ? AND school_id = ? LIMIT 1', [
            $email,
            $this->schoolId()
        ]);
        
        if ($existingUser) {
            flash('error', 'Login email already exists in this school.');
            redirect(url('teachers/create'));
        }

        $role = Database::fetch("SELECT id FROM roles WHERE slug = 'teacher' AND school_id = ? LIMIT 1", [$this->schoolId()]);
        if (!$role) {
            flash('error', 'Teacher role not found. Please contact administrator.');
            redirect(url('teachers/create'));
        }

        $specialization = null;
        if (!empty($_POST['specialization']) && is_array($_POST['specialization'])) {
            $specialization = implode(', ', array_map('trim', $_POST['specialization']));
        }

        $profileImage = null;
        if (!empty($_FILES['profile_image']['name'])) {
            try {
                $profileImage = upload_file($_FILES['profile_image'], 'profiles', app_config('upload.allowed_images', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']));
            } catch (\Throwable $e) {
                flash('error', 'Profile image upload failed: ' . $e->getMessage());
                redirect(url('teachers/create'));
                return;
            }
        }

        $resumePath = null;
        if (!empty($_FILES['resume_path']['name'])) {
            try {
                $docTypes = [
                    'application/pdf',
                    'application/msword',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                ];
                $resumePath = upload_file($_FILES['resume_path'], 'resumes', $docTypes);
            } catch (\Throwable $e) {
                flash('error', 'Resume upload failed: ' . $e->getMessage());
                redirect(url('teachers/create'));
                return;
            }
        }

        Database::beginTransaction();
        try {
            $empModel = new Employee();
            $employeeId = $empModel->create([
                'employee_code' => $empModel->nextCode(),
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $email,
                'phone' => $_POST['phone'] ?? null,
                'gender' => $_POST['gender'] ?? null,
                'date_of_birth' => !empty($_POST['date_of_birth']) ? $_POST['date_of_birth'] : null,
                'joining_date' => !empty($_POST['joining_date']) ? $_POST['joining_date'] : date('Y-m-d'),
                'status' => 'active',
                'profile_image' => $profileImage,
            ]);

            $id = (new Teacher())->create([
                'employee_id' => $employeeId,
                'qualification' => $_POST['qualification'] ?? null,
                'specialization' => $specialization,
                'experience_years' => (int) ($_POST['experience_years'] ?? 0),
                'resume_path' => $resumePath,
                'status' => 1,
            ]);

            Database::insert(
                'INSERT INTO users (school_id, employee_id, role_id, name, email, password, status, created_at, updated_at) 
                 VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
                [
                    $this->schoolId(),
                    $employeeId,
                    (int) $role['id'],
                    $firstName . ' ' . $lastName,
                    $email,
                    password_hash($data['login_password'], PASSWORD_DEFAULT)
                ]
            );

            Database::commit();
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', 'Failed to create teacher profile: ' . $e->getMessage());
            redirect(url('teachers/create'));
        }

        auditLog('employee.create', 'hr', 'employees', $employeeId);
        auditLog('teacher.create', 'teachers', 'teachers', $id);
        
        flash('success', 'Teacher profile created.');
        redirect(url('teachers/' . $id));
    }

    public function edit(string $id): void
    {
        requirePermission('teachers.edit');
        $teacher = (new Teacher())->findDetailed((int) $id);
        if (!$teacher || $teacher['school_id'] !== $this->schoolId()) {
            flash('error', 'Teacher not found.');
            redirect(url('teachers'));
        }
        $this->view('teachers/form', [
            'title' => 'Edit Teacher',
            'teacher' => $teacher,
            'subjects' => (new Subject())->all('name ASC'),
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('teachers.edit');
        $this->requireCsrf();
        $teacher = (new Teacher())->find((int) $id);
        if (!$teacher || $teacher['school_id'] !== $this->schoolId()) {
            flash('error', 'Teacher not found.');
            redirect(url('teachers'));
        }

        $specialization = null;
        if (!empty($_POST['specialization']) && is_array($_POST['specialization'])) {
            $specialization = implode(', ', array_map('trim', $_POST['specialization']));
        }

        $empUpdate = [
            'first_name' => trim($_POST['first_name'] ?? ''),
            'last_name' => trim($_POST['last_name'] ?? ''),
            'phone' => $_POST['phone'] ?? null,
            'gender' => $_POST['gender'] ?? null,
            'date_of_birth' => !empty($_POST['date_of_birth']) ? $_POST['date_of_birth'] : null,
            'joining_date' => !empty($_POST['joining_date']) ? $_POST['joining_date'] : null,
        ];

        if (!empty($_FILES['profile_image']['name'])) {
            try {
                $empUpdate['profile_image'] = upload_file($_FILES['profile_image'], 'profiles', app_config('upload.allowed_images', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']));
            } catch (\Throwable $e) {
                flash('error', 'Profile image upload failed: ' . $e->getMessage());
                redirect(url('teachers/' . $id . '/edit'));
                return;
            }
        }
        (new Employee())->update((int) $teacher['employee_id'], $empUpdate);

        $teachUpdate = [
            'qualification' => $_POST['qualification'] ?? null,
            'specialization' => $specialization,
            'experience_years' => (int) ($_POST['experience_years'] ?? 0),
            'status' => $_POST['status'] ?? 1,
        ];

        if (!empty($_FILES['resume_path']['name'])) {
            try {
                $docTypes = [
                    'application/pdf',
                    'application/msword',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                ];
                $teachUpdate['resume_path'] = upload_file($_FILES['resume_path'], 'resumes', $docTypes);
            } catch (\Throwable $e) {
                flash('error', 'Resume upload failed: ' . $e->getMessage());
                redirect(url('teachers/' . $id . '/edit'));
                return;
            }
        }
        (new Teacher())->update((int) $id, $teachUpdate);

        auditLog('teacher.update', 'teachers', 'teachers', (int) $id);
        flash('success', 'Teacher updated.');
        redirect(url('teachers/' . $id));
    }

    public function destroy(string $id): void
    {
        requirePermission('teachers.delete');
        $this->requireCsrf();
        $teacher = (new Teacher())->find((int) $id);
        if (!$teacher || $teacher['school_id'] !== $this->schoolId()) {
            flash('error', 'Teacher not found.');
            redirect(url('teachers'));
        }
        (new Teacher())->update((int) $id, [
            'status' => 0, // deactivate
        ]);
        auditLog('teacher.deactivate', 'teachers', 'teachers', (int) $id);
        flash('success', 'Teacher deactivated.');
        redirect(url('teachers'));
    }

    public function storeAssignment(string $id): void
    {
        requirePermission('teachers.edit');
        $this->requireCsrf();
        $teacher = (new Teacher())->find((int) $id);
        if (!$teacher) {
            flash('error', 'Teacher not found.');
            redirect(url('teachers'));
        }
        $assignId = Database::insert(
            'INSERT INTO teacher_assignments
            (school_id, teacher_id, class_id, section_id, subject_id, academic_year_id, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
            [
                $this->schoolId(),
                (int) $id,
                (int) $_POST['class_id'],
                (int) $_POST['section_id'],
                (int) $_POST['subject_id'],
                activeAcademicYearId(),
            ]
        );
        auditLog('teacher.assign', 'academic', 'teacher_assignments', $assignId);
        flash('success', 'Assignment added.');
        redirect(url('teachers/' . $id));
    }

    public function destroyAssignment(string $id): void
    {
        requirePermission('teachers.edit');
        $this->requireCsrf();
        $assignment = Database::fetch('SELECT * FROM teacher_assignments WHERE id = ? AND school_id = ?', [(int) $id, $this->schoolId()]);
        if (!$assignment) {
            flash('error', 'Assignment not found.');
            redirect(url('teachers'));
        }
        Database::execute('DELETE FROM teacher_assignments WHERE id = ?', [(int) $id]);
        auditLog('teacher.unassign', 'academic', 'teacher_assignments', (int) $id);
        flash('success', 'Assignment removed.');
        redirect(url('teachers/' . $assignment['teacher_id']));
    }
}
