<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ParentModel;
use App\Models\Teacher;
use App\Services\DashboardService;
use Core\Auth;
use Core\Controller;

final class DashboardController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $service = new DashboardService();
        $role = Auth::roleSlug();

        switch ($role) {
            case 'principal':
            case 'academic_manager':
                $this->view('dashboard/principal', [
                    'title' => 'Principal Executive Cockpit',
                    'stats' => $service->principal(),
                ]);
                break;

            case 'accountant':
            case 'finance':
                $this->view('dashboard/accountant', [
                    'title' => 'Finance & Accounting Cockpit',
                    'stats' => $service->accountant(),
                ]);
                break;

            case 'school_admin':
            case 'owner':
            case 'administrator':
            case 'admin':
                $period = $_GET['period'] ?? 'this_term';
                $productivityService = new \App\Services\UserProductivityService();
                $widgetPrefs = $productivityService->getDashboardWidgets((int)Auth::id(), (int)Auth::schoolId());
                $this->view('dashboard/owner', [
                    'title' => 'Dashboard',
                    'stats' => $service->owner($period),
                    'widget_prefs' => $widgetPrefs,
                ]);
                break;

            case 'teacher':
                $teacher = (new Teacher())->findByUserId((int) Auth::id());
                if (!$teacher) {
                    flash('error', 'Teacher profile not linked to this account.');
                    $this->view('dashboard/teacher', ['title' => 'Teacher Dashboard', 'stats' => []]);
                    return;
                }
                $this->view('dashboard/teacher', [
                    'title' => 'Teacher Dashboard',
                    'stats' => $service->teacher((int) $teacher['id']),
                    'teacher' => $teacher,
                ]);
                break;

            case 'hr':
            case 'hr_manager':
                $this->view('dashboard/hr', ['title' => 'HR Dashboard', 'stats' => $service->hr()]);
                break;

            case 'receptionist':
                $this->view('dashboard/reception', [
                    'title' => 'Front Desk & Reception Cockpit',
                    'stats' => $service->reception(),
                ]);
                break;

            case 'admissions_officer':
            case 'admissions':
                (new AdmissionController())->index();
                break;

            case 'parent':
                $user = Auth::user();
                $schoolId = (int) Auth::schoolId();
                $parentId = (int) ($user['parent_id'] ?? 0);
                $children = $parentId ? (new ParentModel())->children($parentId) : [];
                
                $selectedId = 0;
                $student = null;
                $presentCount = 0;
                $totalAttendanceDays = 0;
                $attendanceRate = 0.0;
                $subjectsCount = 0;
                $totalDue = 0.0;
                $totalPaid = 0.0;
                $todayTimetable = [];
                $warnings = [];
                $announcements = [];
                $unreadMessages = 0;
                $upcomingHomework = [];

                if (!empty($children)) {
                    $reqStudentId = (int) ($_GET['student_id'] ?? ($_SESSION['selected_student_id'] ?? $children[0]['id']));
                    if ((new ParentModel())->ownsStudent($parentId, $reqStudentId)) {
                        $selectedId = $reqStudentId;
                    } else {
                        $selectedId = (int) $children[0]['id'];
                    }
                    $_SESSION['selected_student_id'] = $selectedId;

                    $student = (new \App\Models\Student())->findDetailed($selectedId);
                    $classId = (int) ($student['class_id'] ?? 0);
                    $sectionId = (int) ($student['section_id'] ?? 0);

                    // Real Attendance stats
                    $attCounts = \Core\Database::fetchAll(
                        "SELECT status, count(*) as cnt FROM student_attendance WHERE student_id = ? AND school_id = ? GROUP BY status",
                        [$selectedId, $schoolId]
                    );
                    foreach ($attCounts as $ac) {
                        $totalAttendanceDays += (int) $ac['cnt'];
                        if (in_array(strtolower($ac['status']), ['present', 'late', 'half_day'], true)) {
                            $presentCount += (int) $ac['cnt'];
                        }
                    }
                    if ($totalAttendanceDays > 0) {
                        $attendanceRate = round(($presentCount / $totalAttendanceDays) * 100, 1);
                    }

                    // Real Curriculum / Subjects count
                    if ($classId > 0) {
                        $subjects = \Core\Database::fetchAll(
                            "SELECT s.id FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.class_id = ? AND s.status = 1",
                            [$classId]
                        );
                        $subjectsCount = count($subjects);
                    }

                    // Real Fee Standing
                    $feeInvoices = \Core\Database::fetchAll(
                        "SELECT total_amount, paid_amount, status FROM student_fee_invoices WHERE student_id = ? AND school_id = ?",
                        [$selectedId, $schoolId]
                    );
                    foreach ($feeInvoices as $inv) {
                        $totalPaid += (float) $inv['paid_amount'];
                        if ($inv['status'] !== 'paid') {
                            $totalDue += max(0, (float) $inv['total_amount'] - (float) $inv['paid_amount']);
                        }
                    }

                    // Real Today's timetable
                    $dayOfWeek = (int) date('N');
                    if ($dayOfWeek <= 6 && $classId > 0) {
                        $todayTimetable = \Core\Database::fetchAll(
                            "SELECT t.*, s.name AS subject_name, tp.name AS period_name, tp.period_number, tp.start_time, tp.end_time,
                                    CONCAT(COALESCE(emp.first_name, ''), ' ', COALESCE(emp.last_name, '')) AS teacher_name,
                                    r.name AS room_name
                             FROM timetables t
                             LEFT JOIN subjects s ON s.id = t.subject_id
                             LEFT JOIN timetable_periods tp ON tp.id = t.period_id
                             LEFT JOIN teachers tch ON tch.id = t.teacher_id
                             LEFT JOIN employees emp ON emp.id = tch.employee_id
                             LEFT JOIN rooms r ON r.id = t.room
                             WHERE t.class_id = ? AND t.day_of_week = ?
                               AND (t.section_id = ? OR t.section_id IS NULL)
                             ORDER BY tp.start_time ASC, tp.period_number ASC",
                            [$classId, $dayOfWeek, $sectionId]
                        );
                    }

                    $warnings = \Core\Database::fetchAll(
                        "SELECT message FROM student_warnings WHERE school_id = ? AND student_id = ? AND is_read = 0 ORDER BY created_at DESC",
                        [$schoolId, $selectedId]
                    );

                    // Upcoming homework due
                    $upcomingHomework = \Core\Database::fetchAll(
                        "SELECT a.*, s.name AS subject_name 
                         FROM assignments a
                         LEFT JOIN subjects s ON s.id = a.subject_id
                         WHERE a.school_id = ? AND a.class_id = ? AND a.status = 'published'
                           AND a.due_date >= CURDATE()
                         ORDER BY a.due_date ASC LIMIT 5",
                        [$schoolId, $classId]
                    );
                }

                // Real school announcements
                $announcements = \Core\Database::fetchAll(
                    "SELECT id, title, body, created_at, audience 
                     FROM announcements 
                     WHERE school_id = ? AND status = 'published' AND audience IN ('all', 'parents')
                     ORDER BY created_at DESC LIMIT 5",
                    [$schoolId]
                );

                // Real unread parent-teacher messages
                try {
                    $unreadRow = \Core\Database::fetch(
                        "SELECT COUNT(m.id) AS cnt 
                         FROM parent_teacher_messages m
                         JOIN parent_teacher_conversations c ON c.id = m.conversation_id
                         WHERE c.school_id = ? AND c.parent_id = ? AND m.is_read = 0 AND m.sender_role != 'parent'",
                        [$schoolId, $parentId]
                    );
                    $unreadMessages = (int) ($unreadRow['cnt'] ?? 0);
                } catch (\Throwable $e) {
                    $unreadMessages = 0;
                }

                $this->view('dashboard/parent', [
                    'title'               => 'Parent Portal',
                    'student'             => $student,
                    'children'            => $children,
                    'studentId'           => $selectedId,
                    'presentCount'        => $presentCount,
                    'totalAttendanceDays' => $totalAttendanceDays,
                    'attendanceRate'      => $attendanceRate,
                    'subjectsCount'       => $subjectsCount,
                    'totalDue'            => $totalDue,
                    'totalPaid'           => $totalPaid,
                    'todayTimetable'      => $todayTimetable,
                    'warnings'            => $warnings,
                    'announcements'       => $announcements,
                    'upcomingHomework'    => $upcomingHomework,
                    'unreadMessages'      => $unreadMessages,
                ]);
                break;

            case 'student':
                $userId = (int) Auth::id();
                $schoolId = (int) Auth::schoolId();
                
                $student = \Core\Database::fetch(
                    "SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS year_name
                     FROM students s
                     LEFT JOIN classes c ON c.id = s.class_id
                     LEFT JOIN sections sec ON sec.id = s.section_id
                     LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                     WHERE s.user_id = :user_id AND s.school_id = :school_id LIMIT 1",
                    ['user_id' => $userId, 'school_id' => $schoolId]
                );

                if (!$student) {
                    flash('error', 'Student profile not linked to this account.');
                    $this->view('errors/403', ['title' => 'Profile Error']);
                    exit;
                }

                $studentId = (int) $student['id'];
                $classId = (int) ($student['class_id'] ?? 0);
                $sectionId = (int) ($student['section_id'] ?? 0);

                // Real Attendance stats
                $attCounts = \Core\Database::fetchAll(
                    "SELECT status, count(*) as cnt FROM student_attendance WHERE student_id = ? AND school_id = ? GROUP BY status",
                    [$studentId, $schoolId]
                );
                $presentCount = 0;
                $totalAttendanceDays = 0;
                $attendanceRate = 0.0;
                foreach ($attCounts as $ac) {
                    $totalAttendanceDays += (int) $ac['cnt'];
                    if (in_array(strtolower($ac['status']), ['present', 'late', 'half_day'], true)) {
                        $presentCount += (int) $ac['cnt'];
                    }
                }
                if ($totalAttendanceDays > 0) {
                    $attendanceRate = round(($presentCount / $totalAttendanceDays) * 100, 1);
                }

                // Real Curriculum / Subjects count
                $subjectsCount = 0;
                if ($classId > 0) {
                    $subjects = \Core\Database::fetchAll(
                        "SELECT s.id FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.class_id = ? AND s.status = 1",
                        [$classId]
                    );
                    $subjectsCount = count($subjects);
                }

                // Real Fee Standing
                $feeInvoices = \Core\Database::fetchAll(
                    "SELECT total_amount, paid_amount, status FROM student_fee_invoices WHERE student_id = ? AND school_id = ?",
                    [$studentId, $schoolId]
                );
                $totalDue = 0.0;
                $totalPaid = 0.0;
                foreach ($feeInvoices as $inv) {
                    $totalPaid += (float) $inv['paid_amount'];
                    if ($inv['status'] !== 'paid') {
                        $totalDue += max(0, (float) $inv['total_amount'] - (float) $inv['paid_amount']);
                    }
                }

                // Real Today's schedule / timetable
                $dayOfWeek = (int) date('N');
                $todayTimetable = [];
                if ($dayOfWeek <= 6 && $classId > 0) {
                    $todayTimetable = \Core\Database::fetchAll(
                        "SELECT t.*, s.name AS subject_name, tp.name AS period_name, tp.period_number, tp.start_time, tp.end_time,
                                CONCAT(COALESCE(emp.first_name, ''), ' ', COALESCE(emp.last_name, '')) AS teacher_name,
                                r.name AS room_name
                         FROM timetables t
                         LEFT JOIN subjects s ON s.id = t.subject_id
                         LEFT JOIN timetable_periods tp ON tp.id = t.period_id
                         LEFT JOIN teachers tch ON tch.id = t.teacher_id
                         LEFT JOIN employees emp ON emp.id = tch.employee_id
                         LEFT JOIN rooms r ON r.id = t.room
                         WHERE t.class_id = ? AND t.day_of_week = ?
                           AND (t.section_id = ? OR t.section_id IS NULL)
                         ORDER BY tp.start_time ASC, tp.period_number ASC",
                        [$classId, $dayOfWeek, $sectionId]
                    );
                }

                $warnings = \Core\Database::fetchAll(
                    "SELECT message FROM student_warnings WHERE school_id = ? AND student_id = ? AND is_read = 0 ORDER BY created_at DESC",
                    [$schoolId, $studentId]
                );

                // Upcoming homework due
                $upcomingHomework = \Core\Database::fetchAll(
                    "SELECT a.*, s.name AS subject_name 
                     FROM assignments a
                     LEFT JOIN subjects s ON s.id = a.subject_id
                     WHERE a.school_id = ? AND a.class_id = ? AND a.status = 'published'
                       AND a.due_date >= CURDATE()
                     ORDER BY a.due_date ASC LIMIT 5",
                    [$schoolId, $classId]
                );

                // Announcements targeting students
                $announcements = \Core\Database::fetchAll(
                    "SELECT id, title, body, created_at, audience 
                     FROM announcements 
                     WHERE school_id = ? AND status = 'published' AND (audience IN ('all', 'students') OR class_id = ?)
                     ORDER BY created_at DESC LIMIT 5",
                    [$schoolId, $classId]
                );

                $this->view('dashboard/student', [
                    'title'               => 'Student Portal',
                    'student'             => $student,
                    'presentCount'        => $presentCount,
                    'totalAttendanceDays' => $totalAttendanceDays,
                    'attendanceRate'      => $attendanceRate,
                    'subjectsCount'       => $subjectsCount,
                    'totalDue'            => $totalDue,
                    'totalPaid'           => $totalPaid,
                    'todayTimetable'      => $todayTimetable,
                    'warnings'            => $warnings,
                    'upcomingHomework'    => $upcomingHomework,
                    'announcements'       => $announcements,
                ]);
                break;

            default:
                http_response_code(403);
                view('errors/403', ['title' => 'Forbidden']);
                exit;
        }
    }

    public function switchChild(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        if (!isRole('parent')) {
            http_response_code(403);
            exit;
        }
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $parentId = (int) (Auth::user()['parent_id'] ?? 0);
        if (!(new ParentModel())->ownsStudent($parentId, $studentId)) {
            flash('error', 'Invalid student selection.');
            redirect(url('dashboard'));
        }
        $_SESSION['selected_student_id'] = $studentId;
        unset($_SESSION['selected_academic_year_id']);
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if ($referer && !str_contains($referer, 'switch-child')) {
            redirect($referer);
        } else {
            redirect(url('dashboard'));
        }
    }
}
