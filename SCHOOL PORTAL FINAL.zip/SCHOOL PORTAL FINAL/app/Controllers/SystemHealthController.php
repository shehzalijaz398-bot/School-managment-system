<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\BackupRecoveryService;
use App\Services\SystemHealthService;
use Core\Controller;

final class SystemHealthController extends Controller
{
    /**
     * System Monitoring & Operational Health Dashboard
     */
    public function health(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int) $this->schoolId();
        $healthService = new SystemHealthService();

        $overview = $healthService->getSystemHealthOverview($schoolId);

        $this->view('admin/system/health', [
            'title' => 'System Health & Operational Monitoring',
            'overview' => $overview
        ]);
    }

    /**
     * Backup & Disaster Recovery Console
     */
    public function backups(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int) $this->schoolId();
        $backupService = new BackupRecoveryService();

        $backups = $backupService->getBackups($schoolId);
        $totalSize = array_sum(array_column($backups, 'file_size'));

        $this->view('admin/system/backups', [
            'title' => 'Database Backup & Disaster Recovery Vault',
            'backups' => $backups,
            'total_size_bytes' => $totalSize
        ]);
    }

    /**
     * Trigger Instant Encrypted Backup Snapshot
     */
    public function triggerBackup(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $userId = (int) $this->userId();
        $type = in_array($_POST['backup_type'] ?? '', ['tenant_data', 'full_database'], true) ? $_POST['backup_type'] : 'tenant_data';

        try {
            $result = (new BackupRecoveryService())->createBackup($schoolId, $userId, $type);
            flash('success', "Encrypted backup snapshot ({$result['name']}) created successfully. Checksum SHA-256: " . substr($result['checksum'], 0, 16) . '...');
        } catch (\Throwable $e) {
            flash('error', 'Backup failed: ' . $e->getMessage());
        }

        redirect(url('admin/system/backups'));
    }

    /**
     * Non-destructive verification of backup integrity
     */
    public function verifyBackup(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            $result = (new BackupRecoveryService())->verifyBackupIntegrity($schoolId, (int) $id);
            if ($result['valid']) {
                flash('success', $result['message']);
            } else {
                flash('error', $result['message']);
            }
        } catch (\Throwable $e) {
            flash('error', 'Integrity check error: ' . $e->getMessage());
        }

        redirect(url('admin/system/backups'));
    }

    /**
     * Isolated Dry-Run Restoration Sandbox
     */
    public function testRestoreSandbox(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            $result = (new BackupRecoveryService())->dryRunRestorationSandbox($schoolId, (int) $id);
            if ($result['simulation_passed']) {
                flash('success', $result['message'] . " Verified {$result['insert_statements']} data statements without modifying production tables.");
            } else {
                flash('error', 'Restoration simulation failed: ' . ($result['error'] ?? 'Unknown error'));
            }
        } catch (\Throwable $e) {
            flash('error', 'Sandbox simulation error: ' . $e->getMessage());
        }

        redirect(url('admin/system/backups'));
    }

    /**
     * Authorized streaming download of encrypted backup archive
     */
    public function downloadBackup(string $id): void
    {
        requirePermission('settings.manage');
        $schoolId = (int) $this->schoolId();

        $path = (new BackupRecoveryService())->getBackupFilePath($schoolId, (int) $id);
        if (!$path || !file_exists($path)) {
            flash('error', 'Backup file not found or unauthorized.');
            redirect(url('admin/system/backups'));
            return;
        }

        $filename = basename($path);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($path);
        exit;
    }

    /**
     * Machine-readable Health Check API Endpoint
     */
    public function apiHealth(): void
    {
        $schoolId = (int) (currentSchoolId() ?: 0);
        $overview = (new SystemHealthService())->getSystemHealthOverview($schoolId);

        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code($overview['overall_status'] === 'critical' ? 503 : 200);
        }

        echo json_encode([
            'status' => $overview['overall_status'],
            'health_score' => $overview['health_score'],
            'timestamp' => $overview['checked_at'],
            'services' => [
                'database' => [
                    'status' => $overview['database']['status'] ?? 'unknown',
                    'latency_ms' => $overview['database']['latency_ms'] ?? 0,
                    'version' => $overview['database']['version'] ?? 'unknown',
                ],
                'cache' => [
                    'status' => $overview['cache']['status'] ?? 'operational',
                    'entries' => $overview['cache']['active_entries'] ?? 0,
                    'storage_kb' => $overview['cache']['storage_size_kb'] ?? 0,
                ],
                'queue' => [
                    'status' => $overview['queue_worker']['status'] ?? 'operational',
                    'pending_jobs' => $overview['queue_worker']['pending_jobs'] ?? 0,
                    'failed_jobs' => $overview['queue_worker']['failed_jobs'] ?? 0,
                ],
                'storage' => [
                    'status' => ($overview['storage']['writable_failures'] ?? 0) === 0 ? 'healthy' : 'degraded',
                    'disk_free_gb' => $overview['storage']['disk_free_gb'] ?? 0,
                ],
                'integrations' => [
                    'mail' => $overview['integrations']['mail']['status'] ?? 'not_configured',
                    'ai' => $overview['integrations']['ai_gemini']['status'] ?? 'not_configured',
                    'sms' => $overview['integrations']['sms']['status'] ?? 'not_configured',
                ],
                'alerts' => [
                    'open_incidents' => $overview['alerts']['open_count'] ?? 0,
                    'critical_incidents' => $overview['alerts']['critical_count'] ?? 0,
                ]
            ]
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        if (php_sapi_name() !== 'cli') {
            exit;
        }
    }
}
