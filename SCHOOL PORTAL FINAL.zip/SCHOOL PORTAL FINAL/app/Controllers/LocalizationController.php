<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;

final class LocalizationController extends Controller
{
    public function switchLanguage(): void
    {
        $this->requireCsrf();
        $locale = $_POST['locale'] ?? 'en';
        
        $locale = preg_replace('/[^a-zA-Z0-9_-]/', '', $locale);
        
        $_SESSION['app_locale'] = $locale;
        setcookie('app_locale', $locale, time() + (86400 * 365), "/");
        
        $referer = $_SERVER['HTTP_REFERER'] ?? url('/');
        redirect($referer);
    }
}
