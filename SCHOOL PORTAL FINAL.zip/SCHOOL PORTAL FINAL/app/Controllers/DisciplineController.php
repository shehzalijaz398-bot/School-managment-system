<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class DisciplineController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS student_behaviour_logs (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                student_id INT NOT NULL,
                reporter_user_id INT NOT NULL,
                incident_title VARCHAR(255) NOT NULL,
                points_impact INT NOT NULL DEFAULT 0,
                action_type VARCHAR(50) NOT NULL,
                status VARCHAR(50) NOT NULL DEFAULT 'active',
                fine_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function index(): void
    {
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        $role = $user['role_slug'] ?? '';
        
        $logs = [];
        $students = [];
        $leaderboard = [];
        
        if (in_array($role, ['student', 'parent'])) {
            // Student/Parent Scope
            $studentId = $role === 'student' ? ($user['student_id'] ?? 0) : ($user['parent_id'] ?? 0); 
            // Mocking the parent to student link for simplicity, assuming they view via linked session
            
            // Just load logs where student_id is tied to user context
            $logs = Database::fetchAll("
                SELECT l.*, 
                       CONCAT(s.first_name, ' ', s.last_name) as student_name,
                       u.name as reporter_name
                FROM student_behaviour_logs l
                JOIN students s ON l.student_id = s.id
                JOIN users u ON l.reporter_user_id = u.id
                WHERE l.school_id = ? AND (s.user_id = ? OR s.parent_id = ?)
                ORDER BY l.created_at DESC
            ", [$schoolId, $user['id'], $user['id']]);
        } else {
            // Admin/Teacher Scope
            $students = Database::fetchAll("SELECT id, CONCAT(first_name, ' ', last_name) as name, class_id FROM students WHERE school_id = ? AND status = 'active' ORDER BY first_name ASC", [$schoolId]);
            $logs = Database::fetchAll("
                SELECT l.*, 
                       CONCAT(s.first_name, ' ', s.last_name) as student_name,
                       u.name as reporter_name
                FROM student_behaviour_logs l
                JOIN students s ON l.student_id = s.id
                JOIN users u ON l.reporter_user_id = u.id
                WHERE l.school_id = ?
                ORDER BY l.created_at DESC
            ", [$schoolId]);
            
            // Leaderboard (Defaulters)
            $leaderboard = Database::fetchAll("
                SELECT s.id, CONCAT(s.first_name, ' ', s.last_name) as name,
                       COALESCE(SUM(l.points_impact), 0) as total_points
                FROM students s
                LEFT JOIN student_behaviour_logs l ON s.id = l.student_id AND l.status != 'appealed'
                WHERE s.school_id = ? AND s.status = 'active'
                GROUP BY s.id
                HAVING total_points < 0
                ORDER BY total_points ASC
                LIMIT 10
            ", [$schoolId]);
        }

        $this->view('discipline/index', [
            'title' => 'Student Behaviour & Discipline Hub',
            'logs' => $logs,
            'students' => $students,
            'leaderboard' => $leaderboard,
            'role' => $role,
            'userId' => $user['id']
        ]);
    }

    public function report(): void
    {
        $this->requireCsrf();
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        
        if (!in_array($user['role_slug'], ['teacher', 'admin', 'superadmin', 'principal'])) {
            abort(403);
        }
        
        $studentId = (int)($_POST['student_id'] ?? 0);
        $incidentTitle = $_POST['incident_title'] ?? '';
        $pointsImpact = (int)($_POST['points_impact'] ?? 0);
        $actionType = $_POST['action_type'] ?? 'warning';
        $fineAmount = (float)($_POST['fine_amount'] ?? 0.0);

        if (!$studentId || !$incidentTitle) {
            flash('error', 'Student and Incident Title are required.');
            redirect(url('discipline/logs'));
            return;
        }

        Database::beginTransaction();
        try {
            Database::insert("
                INSERT INTO student_behaviour_logs (school_id, student_id, reporter_user_id, incident_title, points_impact, action_type, fine_amount, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
            ", [$schoolId, $studentId, $user['id'], $incidentTitle, $pointsImpact, $actionType, $fineAmount]);
            
            // Finance Portal Integration
            if ($fineAmount > 0) {
                // Attempt to inject into active invoice if exists, else log in a pending fee ledger
                try {
                    $invoice = Database::fetch("SELECT id FROM student_fee_invoices WHERE student_id = ? AND school_id = ? AND status = 'unpaid' ORDER BY id DESC LIMIT 1", [$studentId, $schoolId]);
                    if ($invoice) {
                        Database::insert("
                            INSERT INTO student_fee_invoice_items (invoice_id, fee_head_id, amount, created_at)
                            VALUES (?, (SELECT id FROM fee_heads WHERE school_id = ? AND name LIKE '%Fine%' LIMIT 1), ?, NOW())
                        ", [$invoice['id'], $schoolId, $fineAmount]);
                    }
                } catch (\Throwable $e) {}
            }
            
            // Check threshold for Suspension
            $totalPoints = Database::fetch("
                SELECT COALESCE(SUM(points_impact), 0) as pt 
                FROM student_behaviour_logs 
                WHERE student_id = ? AND school_id = ? AND status = 'active'
            ", [$studentId, $schoolId]);
            
            if ($totalPoints && (int)$totalPoints['pt'] <= -30) {
                // Threshold Crossed
                Database::execute("UPDATE users SET status = 'suspended' WHERE id = (SELECT user_id FROM students WHERE id = ?)", [$studentId]);
                // Flag attendance (mock structural call)
                Database::execute("UPDATE students SET status = 'suspended' WHERE id = ? AND school_id = ?", [$studentId, $schoolId]);
                
                // Inject HR alert
                Database::insert("
                    INSERT INTO notifications (school_id, user_id, title, message, type, is_read, created_at)
                    SELECT ?, id, 'Suspension Triggered', 'Student crossed -30 behavioural points threshold.', 'discipline', 0, NOW()
                    FROM users WHERE school_id = ? AND role_slug IN ('admin', 'principal')
                ", [$schoolId, $schoolId]);
            }
            
            Database::commit();
            flash('success', 'Incident officially registered. Behavioral metrics updated.');
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', 'Critical failure reporting incident.');
        }

        redirect(url('discipline/logs'));
    }

    public function appeal(): void
    {
        $this->requireCsrf();
        $schoolId = Auth::schoolId();
        $incidentId = (int)($_POST['incident_id'] ?? 0);
        
        Database::execute("UPDATE student_behaviour_logs SET status = 'appealed' WHERE id = ? AND school_id = ?", [$incidentId, $schoolId]);
        
        flash('success', 'Official appeal submitted to Principal/HR for review.');
        redirect(url('discipline/logs'));
    }

    public function processAction(): void
    {
        $this->requireCsrf();
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        
        if (!in_array($user['role_slug'], ['admin', 'superadmin', 'principal'])) {
            abort(403);
        }
        
        $incidentId = (int)($_POST['incident_id'] ?? 0);
        $action = $_POST['action'] ?? ''; // 'approve_appeal' or 'reject_appeal' or 'clear_suspension'
        
        if ($action === 'approve_appeal') {
            Database::execute("UPDATE student_behaviour_logs SET status = 'voided', points_impact = 0 WHERE id = ? AND school_id = ?", [$incidentId, $schoolId]);
            flash('success', 'Appeal approved. Disciplinary points voided.');
        } elseif ($action === 'reject_appeal') {
            Database::execute("UPDATE student_behaviour_logs SET status = 'active' WHERE id = ? AND school_id = ?", [$incidentId, $schoolId]);
            flash('error', 'Appeal rejected. Incident remains active.');
        } elseif ($action === 'clear_suspension') {
            $studentId = (int)($_POST['student_id'] ?? 0);
            Database::execute("UPDATE users SET status = 'active' WHERE id = (SELECT user_id FROM students WHERE id = ?)", [$studentId]);
            Database::execute("UPDATE students SET status = 'active' WHERE id = ? AND school_id = ?", [$studentId, $schoolId]);
            // Void all negative points to reset
            Database::execute("UPDATE student_behaviour_logs SET status = 'cleared' WHERE student_id = ? AND school_id = ?", [$studentId, $schoolId]);
            flash('success', 'Suspension cleared securely. Active token restored.');
        }
        
        redirect(url('discipline/logs'));
    }
}
