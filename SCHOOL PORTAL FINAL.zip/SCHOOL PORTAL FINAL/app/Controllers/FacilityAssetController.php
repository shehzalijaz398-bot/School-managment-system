<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\FacilityAssetService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class FacilityAssetController extends Controller
{
    private FacilityAssetService $service;

    public function __construct()
    {
        $this->service = new FacilityAssetService();
    }

    /**
     * Centralized Facilities, Reservations, Fixed Assets & Maintenance Hub
     */
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $tab = trim((string)($_GET['tab'] ?? 'facilities'));
        $search = trim((string)($_GET['search'] ?? ''));

        $metrics = $this->service->getMetrics($schoolId);
        $facilities = $this->service->listFacilities(
            $schoolId,
            $_GET['type'] ?? null,
            $_GET['status'] ?? null,
            $search
        );

        $bookings = $this->service->listBookings(
            $schoolId,
            !empty($_GET['facility_id']) ? (int)$_GET['facility_id'] : null,
            $_GET['booking_status'] ?? null,
            $_GET['booking_date'] ?? null
        );

        $assets = $this->service->listAssets(
            $schoolId,
            $_GET['asset_category'] ?? null,
            $_GET['asset_status'] ?? null,
            $search
        );

        $workOrders = $this->service->listWorkOrders(
            $schoolId,
            $_GET['wo_status'] ?? null,
            $_GET['wo_priority'] ?? null,
            $_GET['wo_category'] ?? null
        );

        // Fetch staff members for asset assignment dropdown
        $staffMembers = Database::fetchAll(
            "SELECT u.id, u.name, r.name AS role_name
             FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.school_id = ? AND u.status = 'active'
             ORDER BY u.name ASC",
            [$schoolId]
        );

        $this->view('facilities/index', [
            'title' => 'Campus Facilities, Asset Lifecycle & Maintenance',
            'tab' => $tab,
            'metrics' => $metrics,
            'facilities' => $facilities,
            'bookings' => $bookings,
            'assets' => $assets,
            'workOrders' => $workOrders,
            'staffMembers' => $staffMembers,
            'search' => $search,
        ]);
    }

    // -------------------------------------------------------------------------
    // Facility CRUD
    // -------------------------------------------------------------------------

    public function storeFacility(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') {
            flash('error', 'Facility name is required.');
            redirect(url('facilities?tab=facilities'));
        }

        $amenities = $_POST['amenities'] ?? [];
        if (is_string($amenities)) {
            $amenities = array_filter(array_map('trim', explode(',', $amenities)));
        }

        $this->service->createFacility($schoolId, [
            'facility_code' => $_POST['facility_code'] ?? '',
            'name' => $name,
            'facility_type' => $_POST['facility_type'] ?? 'smart_classroom',
            'building_block' => $_POST['building_block'] ?? '',
            'floor' => $_POST['floor'] ?? '',
            'capacity' => (int)($_POST['capacity'] ?? 30),
            'hourly_rate' => (float)($_POST['hourly_rate'] ?? 0.0),
            'amenities' => $amenities,
            'status' => $_POST['status'] ?? 'available',
            'rules_notes' => $_POST['rules_notes'] ?? '',
        ]);

        flash('success', "Campus facility '{$name}' registered successfully.");
        redirect(url('facilities?tab=facilities'));
    }

    public function updateFacility(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $facId = (int)$id;

        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') {
            flash('error', 'Facility name is required.');
            redirect(url('facilities?tab=facilities'));
        }

        $amenities = $_POST['amenities'] ?? [];
        if (is_string($amenities)) {
            $amenities = array_filter(array_map('trim', explode(',', $amenities)));
        }

        $this->service->updateFacility($schoolId, $facId, [
            'facility_code' => $_POST['facility_code'] ?? '',
            'name' => $name,
            'facility_type' => $_POST['facility_type'] ?? 'smart_classroom',
            'building_block' => $_POST['building_block'] ?? '',
            'floor' => $_POST['floor'] ?? '',
            'capacity' => (int)($_POST['capacity'] ?? 30),
            'hourly_rate' => (float)($_POST['hourly_rate'] ?? 0.0),
            'amenities' => $amenities,
            'status' => $_POST['status'] ?? 'available',
            'rules_notes' => $_POST['rules_notes'] ?? '',
        ]);

        flash('success', "Facility details updated.");
        redirect(url('facilities?tab=facilities'));
    }

    public function destroyFacility(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $this->service->deleteFacility($schoolId, (int)$id);
        flash('success', 'Facility removed from registry.');
        redirect(url('facilities?tab=facilities'));
    }

    // -------------------------------------------------------------------------
    // Bookings & Conflict Checking
    // -------------------------------------------------------------------------

    public function checkConflict(): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $facId = (int)($_GET['facility_id'] ?? 0);
        $start = trim((string)($_GET['start_time'] ?? ''));
        $end = trim((string)($_GET['end_time'] ?? ''));
        $excludeId = !empty($_GET['exclude_id']) ? (int)$_GET['exclude_id'] : null;

        if ($facId <= 0 || $start === '' || $end === '') {
            $this->json(['conflict' => false, 'message' => 'Incomplete parameters']);
            return;
        }

        $conflict = $this->service->checkBookingConflict($schoolId, $facId, $start, $end, $excludeId);
        if ($conflict) {
            $this->json([
                'conflict' => true,
                'message' => "Collision with existing booking: '{$conflict['title']}' ({$conflict['start_time']} to {$conflict['end_time']})",
                'details' => $conflict,
            ]);
        } else {
            $this->json(['conflict' => false, 'message' => 'Time slot is available without conflicts.']);
        }
    }

    public function storeBooking(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $result = $this->service->createBooking($schoolId, [
            'facility_id' => (int)($_POST['facility_id'] ?? 0),
            'title' => trim((string)($_POST['title'] ?? '')),
            'purpose' => trim((string)($_POST['purpose'] ?? '')),
            'start_time' => trim((string)($_POST['start_time'] ?? '')),
            'end_time' => trim((string)($_POST['end_time'] ?? '')),
            'expected_attendees' => (int)($_POST['expected_attendees'] ?? 0),
            'conflict_override' => !empty($_POST['conflict_override']),
        ], $userId);

        if (!$result['success']) {
            flash('error', $result['error']);
        } else {
            flash('success', "Facility reservation confirmed. Reference: {$result['booking_ref']}");
        }

        redirect(url('facilities?tab=bookings'));
    }

    public function updateBookingStatus(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $status = trim((string)($_POST['status'] ?? 'confirmed'));
        $remarks = trim((string)($_POST['remarks'] ?? ''));

        $this->service->updateBookingStatus($schoolId, (int)$id, $status, $remarks, $userId);
        flash('success', 'Booking status updated to ' . ucfirst($status) . '.');
        redirect(url('facilities?tab=bookings'));
    }

    // -------------------------------------------------------------------------
    // Fixed Asset Lifecycle & Custody
    // -------------------------------------------------------------------------

    public function storeAsset(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') {
            flash('error', 'Asset item name is required.');
            redirect(url('facilities?tab=assets'));
        }

        $this->service->createAsset($schoolId, [
            'asset_tag' => $_POST['asset_tag'] ?? '',
            'name' => $name,
            'category' => $_POST['category'] ?? 'general',
            'serial_number' => $_POST['serial_number'] ?? '',
            'barcode' => $_POST['barcode'] ?? '',
            'facility_id' => $_POST['facility_id'] ?? null,
            'purchase_date' => $_POST['purchase_date'] ?? date('Y-m-d'),
            'purchase_cost' => (float)($_POST['purchase_cost'] ?? 0.0),
            'salvage_value' => (float)($_POST['salvage_value'] ?? 0.0),
            'useful_life_years' => (int)($_POST['useful_life_years'] ?? 5),
            'depreciation_method' => $_POST['depreciation_method'] ?? 'straight_line',
            'status' => $_POST['status'] ?? 'in_service',
            'notes' => $_POST['notes'] ?? '',
        ]);

        flash('success', "Fixed asset '{$name}' registered.");
        redirect(url('facilities?tab=assets'));
    }

    public function updateAsset(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $assetId = (int)$id;

        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') {
            flash('error', 'Asset item name is required.');
            redirect(url('facilities?tab=assets'));
        }

        $this->service->updateAsset($schoolId, $assetId, [
            'asset_tag' => $_POST['asset_tag'] ?? '',
            'name' => $name,
            'category' => $_POST['category'] ?? 'general',
            'serial_number' => $_POST['serial_number'] ?? '',
            'barcode' => $_POST['barcode'] ?? '',
            'facility_id' => $_POST['facility_id'] ?? null,
            'purchase_date' => $_POST['purchase_date'] ?? date('Y-m-d'),
            'purchase_cost' => (float)($_POST['purchase_cost'] ?? 0.0),
            'salvage_value' => (float)($_POST['salvage_value'] ?? 0.0),
            'useful_life_years' => (int)($_POST['useful_life_years'] ?? 5),
            'depreciation_method' => $_POST['depreciation_method'] ?? 'straight_line',
            'status' => $_POST['status'] ?? 'in_service',
            'notes' => $_POST['notes'] ?? '',
        ]);

        flash('success', 'Asset details updated.');
        redirect(url('facilities?tab=assets'));
    }

    public function destroyAsset(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $this->service->deleteAsset($schoolId, (int)$id);
        flash('success', 'Asset removed from register.');
        redirect(url('facilities?tab=assets'));
    }

    public function checkoutAsset(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();
        $assetId = (int)$id;

        $assignedType = $_POST['assigned_to_type'] ?? 'staff';
        $assignedId = !empty($_POST['assigned_to_id']) ? (int)$_POST['assigned_to_id'] : null;
        $assignedName = trim((string)($_POST['assigned_to_name'] ?? ''));

        if ($assignedType === 'staff' && $assignedId) {
            $staff = Database::fetch("SELECT name FROM users WHERE id = ? AND school_id = ? LIMIT 1", [$assignedId, $schoolId]);
            if ($staff) {
                $assignedName = $staff['name'];
            }
        }

        if ($assignedName === '') {
            $assignedName = 'Assigned Custodian';
        }

        $res = $this->service->checkoutAsset(
            $schoolId,
            $assetId,
            $assignedType,
            $assignedId,
            $assignedName,
            $_POST['condition_state'] ?? 'good',
            !empty($_POST['expected_return_date']) ? $_POST['expected_return_date'] : null,
            $userId,
            $_POST['remarks'] ?? null
        );

        if ($res['success']) {
            flash('success', "Asset checked out successfully to {$assignedName}.");
        } else {
            flash('error', $res['error']);
        }

        redirect(url('facilities?tab=assets'));
    }

    public function checkinAsset(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();
        $assetId = (int)$id;

        $res = $this->service->checkinAsset(
            $schoolId,
            $assetId,
            $_POST['condition_state'] ?? 'good',
            $userId,
            $_POST['remarks'] ?? null
        );

        if ($res['success']) {
            flash('success', 'Asset returned to campus inventory pool.');
        } else {
            flash('error', $res['error']);
        }

        redirect(url('facilities?tab=assets'));
    }

    // -------------------------------------------------------------------------
    // Work Orders & Maintenance
    // -------------------------------------------------------------------------

    public function storeWorkOrder(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $title = trim((string)($_POST['title'] ?? ''));
        if ($title === '') {
            flash('error', 'Work order title is required.');
            redirect(url('facilities?tab=work_orders'));
        }

        $woId = $this->service->createWorkOrder($schoolId, [
            'title' => $title,
            'description' => $_POST['description'] ?? '',
            'facility_id' => $_POST['facility_id'] ?? null,
            'asset_id' => $_POST['asset_id'] ?? null,
            'category' => $_POST['category'] ?? 'general',
            'priority' => $_POST['priority'] ?? 'medium',
            'assigned_technician' => $_POST['assigned_technician'] ?? '',
            'technician_phone' => $_POST['technician_phone'] ?? '',
            'estimated_cost' => (float)($_POST['estimated_cost'] ?? 0.0),
            'scheduled_date' => !empty($_POST['scheduled_date']) ? $_POST['scheduled_date'] : null,
        ], $userId);

        flash('success', "Maintenance work order #{$woId} dispatched.");
        redirect(url('facilities?tab=work_orders'));
    }

    public function updateWorkOrder(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $woId = (int)$id;

        $status = $_POST['status'] ?? 'in_progress';
        $actualCost = (float)($_POST['actual_cost'] ?? 0.0);
        $notes = trim((string)($_POST['resolution_notes'] ?? ''));

        $this->service->updateWorkOrderStatus($schoolId, $woId, $status, $actualCost, $notes);
        flash('success', 'Work order updated.');
        redirect(url('facilities?tab=work_orders'));
    }

    // -------------------------------------------------------------------------
    // Export Fixed Assets CSV
    // -------------------------------------------------------------------------

    public function exportAssetsCsv(): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $assets = $this->service->listAssets($schoolId);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=fixed_assets_report_' . date('Ymd_His') . '.csv');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Asset Tag', 'Asset Name', 'Category', 'Serial Number', 'Location / Facility', 'Purchase Date', 'Purchase Cost', 'Salvage Value', 'Useful Life (Yrs)', 'Method', 'Net Book Value', 'Status']);

        foreach ($assets as $a) {
            fputcsv($out, [
                $a['asset_tag'],
                $a['name'],
                ucwords(str_replace('_', ' ', (string)$a['category'])),
                $a['serial_number'] ?? '',
                $a['facility_name'] ?? 'General Campus',
                $a['purchase_date'],
                number_format((float)$a['purchase_cost'], 2),
                number_format((float)$a['salvage_value'], 2),
                $a['useful_life_years'],
                ucwords(str_replace('_', ' ', (string)$a['depreciation_method'])),
                number_format((float)$a['calculated_net_book_value'], 2),
                ucwords(str_replace('_', ' ', (string)$a['status'])),
            ]);
        }

        fclose($out);
        exit;
    }
}
