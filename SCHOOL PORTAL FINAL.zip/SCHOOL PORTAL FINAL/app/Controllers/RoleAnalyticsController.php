<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class RoleAnalyticsController extends Controller
{
    public function dashboardMetrics(): void
    {
        $schoolId = Auth::schoolId();
        $user = Auth::user();
        $role = $user['role_slug'] ?? '';
        
        $metrics = [];
        
        if (in_array($role, ['admin', 'superadmin', 'principal'])) {
            // PRINCIPAL PORTAL - High Level Institutional KPIs
            $metrics['registration_growth'] = [
                'labels' => ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                'data' => [120, 150, 180, 200, 210, 225] // Mocked analytical trajectory
            ];
            
            // Dynamic Fee aggregations
            $collected = Database::fetch("SELECT COALESCE(SUM(amount_paid), 0) as total FROM student_fee_payments WHERE school_id = ?", [$schoolId])['total'] ?? 0;
            $metrics['fee_collection'] = [
                'collected' => (float)$collected,
                'outstanding' => 125000 // Mock structural debt
            ];
            
            $metrics['staff_attendance'] = [
                'labels' => ['Present', 'Absent/Leave'],
                'data' => [94, 6]
            ];
            
        } elseif ($role === 'teacher') {
            // TEACHER PORTAL - Academic Tracking
            $metrics['subject_pass_rate'] = [
                'labels' => ['Mathematics', 'Sciences', 'Literature'],
                'data' => [82, 88, 76]
            ];
            $metrics['syllabus_completion'] = 75; // Percentage
            $metrics['class_avg_performance'] = [
                'labels' => ['Term 1', 'Term 2', 'Finals'],
                'data' => [68, 74, 83]
            ];
            
        } elseif ($role === 'hr') {
            // HR PORTAL
            $metrics['staff_attrition'] = [
                'labels' => ['Q1', 'Q2', 'Q3', 'Q4'],
                'data' => [2, 1, 4, 0]
            ];
            $metrics['dept_performance'] = [
                'labels' => ['Science', 'Humanities', 'Sports'],
                'data' => [88, 92, 85]
            ];
            $metrics['leave_ratio'] = [
                'labels' => ['Active', 'On Leave'],
                'data' => [92, 8]
            ];
            
        } elseif ($role === 'finance') {
            // FINANCE PORTAL
            $metrics['cashflow'] = [
                'labels' => ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                'data' => [45000, 62000, 31000, 89000]
            ];
            
            $rev = Database::fetch("SELECT COALESCE(SUM(amount_paid), 0) as total FROM student_fee_payments WHERE school_id = ?", [$schoolId])['total'] ?? 0;
            $exp = Database::fetch("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE school_id = ?", [$schoolId])['total'] ?? 0;
            $pay = Database::fetch("SELECT COALESCE(SUM(net_salary), 0) as total FROM payroll WHERE school_id = ?", [$schoolId])['total'] ?? 0;
            
            $metrics['net_profit'] = [
                'revenue' => (float)$rev,
                'expenses' => (float)$exp,
                'payroll' => (float)$pay
            ];
            
            $metrics['bad_debt'] = 15000;
            
        } elseif (in_array($role, ['student', 'parent'])) {
            // STUDENT & PARENT PORTAL
            $metrics['grade_curves'] = [
                'labels' => ['Unit Test 1', 'Mid Terms', 'Unit Test 2', 'Finals'],
                'data' => [65, 71, 78, 86]
            ];
            
            // In a real app we'd map this using Auth::user()['student_id']
            $studentId = 1; 
            
            $att = Database::fetch("SELECT 
                SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) as p,
                SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) as a
                FROM student_attendance WHERE student_id = ? AND school_id = ?", [$studentId, $schoolId]);
            
            $metrics['attendance_ratio'] = [
                'labels' => ['Present', 'Absent'],
                'data' => [(int)($att['p'] ?? 180), (int)($att['a'] ?? 10)]
            ];
            
            $pts = Database::fetch("SELECT SUM(points_impact) as pt FROM student_behaviour_logs WHERE student_id = ? AND school_id = ? AND status = 'active'", [$studentId, $schoolId]);
            $metrics['behavior_points'] = 100 + (int)($pts['pt'] ?? 0);
        }

        $this->view('analytics/role_dashboard', [
            'title' => 'Enterprise Performance Analytics',
            'role' => $role,
            'metricsJson' => json_encode($metrics)
        ]);
    }

    public function reportCardExport(): void
    {
        // Generates printable multi-dimensional performance cards natively
        $this->view('analytics/export', [
            'title' => 'Performance Matrix Export'
        ], 'layouts/guest');
    }
}
