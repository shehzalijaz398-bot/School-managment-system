<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Controller;
use Core\Database;
use Core\Auth;

final class NotificationMatrixController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS system_live_notifications (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                school_id INT NOT NULL,
                receiver_user_id INT NOT NULL,
                sender_user_id INT NULL,
                title VARCHAR(255) NOT NULL,
                context_message TEXT NOT NULL,
                action_url VARCHAR(500) NULL,
                priority VARCHAR(20) NOT NULL DEFAULT 'low',
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function stream(): void
    {
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $userId = Auth::user()['id'];
        
        $unread = Database::fetchAll("
            SELECT * FROM system_live_notifications 
            WHERE school_id = ? AND receiver_user_id = ? AND is_read = 0 
            ORDER BY created_at DESC
        ", [$schoolId, $userId]);
        
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'data' => $unread]);
        exit;
    }

    public function markRead(): void
    {
        // Simple token verification for AJAX
        $token = $_POST['csrf_token'] ?? '';
        if (!\Core\CSRF::verify($token)) {
            http_response_code(403);
            exit(json_encode(['error' => 'Invalid Token']));
        }
        
        $schoolId = Auth::schoolId();
        $userId = Auth::user()['id'];
        
        $id = $_POST['id'] ?? 'all';
        
        if ($id === 'all') {
            Database::execute("UPDATE system_live_notifications SET is_read = 1 WHERE school_id = ? AND receiver_user_id = ?", [$schoolId, $userId]);
        } else {
            Database::execute("UPDATE system_live_notifications SET is_read = 1 WHERE id = ? AND school_id = ? AND receiver_user_id = ?", [(int)$id, $schoolId, $userId]);
        }
        
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success']);
        exit;
    }

    public function center(): void
    {
        $this->initSchema();
        $schoolId = Auth::schoolId();
        $userId = Auth::user()['id'];
        
        $notifications = Database::fetchAll("
            SELECT * FROM system_live_notifications 
            WHERE school_id = ? AND receiver_user_id = ?
            ORDER BY is_read ASC, created_at DESC LIMIT 200
        ", [$schoolId, $userId]);
        
        $this->view('notifications/center', [
            'title' => 'Live Unified Notification Center',
            'notifications' => $notifications
        ]);
    }

    /**
     * Cross-Role Interceptor & Dispatch Mechanism
     */
    public static function dispatch(int $schoolId, int $receiverId, string $title, string $message, string $priority = 'low', ?string $url = null, ?int $senderId = null): void
    {
        try {
            Database::insert("
                INSERT INTO system_live_notifications (school_id, receiver_user_id, sender_user_id, title, context_message, action_url, priority, is_read, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
            ", [$schoolId, $receiverId, $senderId, $title, $message, $url, $priority]);
        } catch (\Throwable $e) {}
    }
}
