<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class SettingController extends Controller
{
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = $this->schoolId();
        $activeTab = trim((string)($_GET['tab'] ?? 'school-profile'));

        $school = Database::fetch('SELECT * FROM schools WHERE id = ?', [$schoolId]);
        if ($school) {
            if (empty($school['address'])) {
                $addressParts = array_filter([
                    $school['house_number'] ?? '',
                    $school['street'] ?? '',
                    $school['area'] ?? '',
                    $school['city'] ?? '',
                    $school['province'] ?? '',
                    $school['country'] ?? ''
                ]);
                if (!empty($addressParts)) {
                    $school['address'] = implode(', ', $addressParts);
                    Database::execute('UPDATE schools SET address = ? WHERE id = ?', [$school['address'], $schoolId]);
                }
            }
        } else {
            $school = [
                'id' => $schoolId,
                'name' => 'School Portal Institution',
                'code' => 'SCH-001',
                'email' => '',
                'phone' => '',
                'website' => '',
                'address' => '',
                'logo' => '',
                'signature_image' => ''
            ];
        }

        $settings = school_settings($schoolId);

        // Fetch recent audit logs for Activity Log tab
        $auditLogs = Database::fetchAll(
            'SELECT a.*, COALESCE(u.name, "Administrator") as user_name, u.email as user_email 
             FROM audit_logs a 
             LEFT JOIN users u ON a.user_id = u.id 
             WHERE a.school_id = ? 
             ORDER BY a.id DESC 
             LIMIT 150',
            [$schoolId]
        );

        $this->view('settings/index', [
            'title' => 'Settings',
            'school' => $school,
            'settings' => $settings,
            'auditLogs' => $auditLogs,
            'activeTab' => $activeTab
        ]);
    }

    public function save(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = $this->schoolId();
        $activeTab = trim((string)($_POST['active_tab'] ?? 'school-profile'));

        $schoolName = trim($_POST['school_name'] ?? '');
        $schoolCode = trim($_POST['school_code'] ?? '');
        $primaryEmail = trim($_POST['primary_email'] ?? '');
        $primaryPhone = trim($_POST['primary_phone'] ?? '');
        $website = trim($_POST['institution_website'] ?? '');
        $postalAddress = trim($_POST['postal_address'] ?? '');

        // Handle logo upload
        $logoPath = null;
        if (!empty($_FILES['logo']['name']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            try {
                $logoPath = uploadFile($_FILES['logo'], 'logos');
            } catch (\Throwable $e) {
                flash('error', 'Logo upload error: ' . $e->getMessage());
                back();
            }
        }

        // Handle signature upload
        $signaturePath = null;
        if (!empty($_FILES['signature']['name']) && $_FILES['signature']['error'] === UPLOAD_ERR_OK) {
            try {
                $signaturePath = uploadFile($_FILES['signature'], 'logos');
            } catch (\Throwable $e) {
                flash('error', 'Signature upload error: ' . $e->getMessage());
                back();
            }
        }

        // Update schools table
        if ($schoolName !== '' || $schoolCode !== '') {
            $currentSchool = Database::fetch('SELECT name, code FROM schools WHERE id = ?', [$schoolId]);
            $sql = 'UPDATE schools SET name = ?, code = ?, email = ?, phone = ?, website = ?, address = ?, updated_at = NOW()';
            $params = [
                $schoolName !== '' ? $schoolName : ($currentSchool['name'] ?? 'School Portal'),
                $schoolCode !== '' ? $schoolCode : ($currentSchool['code'] ?? 'SCH-001'),
                $primaryEmail,
                $primaryPhone,
                $website,
                $postalAddress
            ];

            if ($logoPath) {
                $sql .= ', logo = ?';
                $params[] = $logoPath;
            }
            if ($signaturePath) {
                $sql .= ', signature_image = ?';
                $params[] = $signaturePath;
            }

            $sql .= ' WHERE id = ?';
            $params[] = $schoolId;

            Database::execute($sql, $params);
        }

        // Update settings table
        $settingKeys = [
            'school_name', 'school_code', 'primary_email', 'primary_phone', 'institution_website',
            'postal_address', 'academic_session', 'session_start_month', 'session_end_month', 'passing_percentage',
            'grading_system', 'admission_status', 'registration_fee', 'auto_roll_number',
            'employee_id_prefix', 'probation_period', 'student_id_format', 'staff_id_format',
            'barcode_type', 'timezone', 'default_language', 'date_format', 'currency',
            'week_start_day', 'rtl_layout', 'time_format', 'currency_symbol_position', 'decimal_precision', 'number_format',
            'theme_color', 'dark_mode', 'theme_mode', 'accent_color', 'layout_density', 'sidebar_density', 'table_density', 'display_scale',
            'mail_driver', 'mail_from_name', 'mail_from_address',
            'smtp_host', 'smtp_port', 'smtp_encryption',
            'enable_sms_notifications', 'sms_provider', 'sms_sender_id', 'sms_account_sid', 'sms_auth_token',
            'in_app_sound', 'inapp_admission_submitted', 'inapp_admission_status_updated', 'inapp_invoice_issued', 'inapp_payment_received', 'inapp_invoice_overdue', 'inapp_attendance_taken',
            'maintenance_mode', 'system_version', 'database_version', 'plugin_version', 'debug_logging', 'audit_log_retention',
            // Academic Setup & Dynamic Terminology
            'curriculum_preset', 'default_grading_scheme', 'class_seeding_strategy',
            'default_academic_units', 'default_groups_per_unit',
            'term_academic_session_singular', 'term_academic_session_plural',
            'term_academic_term_singular', 'term_academic_term_plural',
            'term_academic_unit_singular', 'term_academic_unit_plural',
            'term_academic_group_singular', 'term_academic_group_plural',
            'term_subject_singular', 'term_subject_plural',
            'term_assessment_singular', 'term_assessment_plural',
            'term_student_singular', 'term_student_plural',
            'term_staff_singular', 'term_staff_plural',
            'term_guardian_singular', 'term_guardian_plural',
            'term_invoice_singular', 'term_invoice_plural',
            'term_payment_singular', 'term_payment_plural',
            'term_attendance_record_singular', 'term_attendance_record_plural',
            // Staff Onboarding
            'staff_public_applications', 'staff_application_tracker', 'staff_login_creation_flow',
            'staff_default_role', 'staff_default_status', 'staff_alert_recipients',
            'staff_allowed_statuses', 'staff_lookup_verification_fields', 'staff_mandatory_hiring_documents',
            // Admissions
            'admission_public_form', 'admission_status_lookup', 'admission_auto_convert',
            'admission_alert_recipients', 'admission_default_status',
            'admission_allowed_statuses', 'admission_verification_fields', 'admission_required_documents'
        ];

        if ($activeTab === 'in-app-alerts') {
            $inappKeys = [
                'inapp_admission_submitted', 'inapp_admission_status_updated',
                'inapp_invoice_issued', 'inapp_payment_received',
                'inapp_invoice_overdue', 'inapp_attendance_taken'
            ];
            foreach ($inappKeys as $ik) {
                $_POST[$ik] = (isset($_POST[$ik]) && (string)$_POST[$ik] === '1') ? '1' : '0';
            }
        }
        if ($activeTab === 'sms-alerts') {
            $_POST['enable_sms_notifications'] = (isset($_POST['enable_sms_notifications']) && (string)$_POST['enable_sms_notifications'] === '1') ? '1' : '0';
        }
        if ($activeTab === 'system') {
            $_POST['debug_logging'] = (isset($_POST['debug_logging']) && (string)$_POST['debug_logging'] === '1') ? '1' : '0';
        }
        if ($activeTab === 'appearance') {
            $mode = trim((string)($_POST['theme_mode'] ?? 'system'));
            if ($mode === 'dark') {
                $_POST['dark_mode'] = '1';
            } elseif ($mode === 'light') {
                $_POST['dark_mode'] = '0';
            }
            $accent = trim((string)($_POST['accent_color'] ?? 'Classic'));
            $colorMap = [
                'Classic' => '#4f46e5',
                'Sky Blue' => '#0284c7',
                'Sunset' => '#ea580c',
                'Gold' => '#d97706',
                'Mint' => '#059669',
                'Violet' => '#7c3aed',
                'Pink' => '#db2777',
            ];
            if ($accent !== 'Custom' && isset($colorMap[$accent])) {
                $_POST['theme_color'] = $colorMap[$accent];
            } elseif (!empty($_POST['theme_color'])) {
                $_POST['theme_color'] = trim((string)$_POST['theme_color']);
            }
        }
        if ($activeTab === 'region-language') {
            $_POST['rtl_layout'] = (isset($_POST['rtl_layout']) && (string)$_POST['rtl_layout'] === '1') ? '1' : '0';
        }
        if ($activeTab === 'staff-onboarding') {
            $_POST['staff_public_applications'] = isset($_POST['staff_public_applications']) ? '1' : '0';
            $_POST['staff_application_tracker'] = isset($_POST['staff_application_tracker']) ? '1' : '0';
        }
        if ($activeTab === 'admissions') {
            $_POST['admission_public_form'] = isset($_POST['admission_public_form']) ? '1' : '0';
            $_POST['admission_status_lookup'] = isset($_POST['admission_status_lookup']) ? '1' : '0';
            $_POST['admission_auto_convert'] = isset($_POST['admission_auto_convert']) ? '1' : '0';
        }

        foreach ($settingKeys as $key) {
            if (isset($_POST[$key])) {
                $val = trim((string)$_POST[$key]);
                $exists = Database::fetch('SELECT id FROM settings WHERE school_id = ? AND setting_key = ?', [$schoolId, $key]);
                if ($exists) {
                    Database::execute('UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$val, (int)$exists['id']]);
                } else {
                    Database::insert('INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())', [$schoolId, $key, $val]);
                }
            }
        }

        // Update ID formats & Notification template custom fields
        foreach ($_POST as $postKey => $postVal) {
            if (str_starts_with($postKey, 'id_fmt_') || str_starts_with($postKey, 'email_tpl_')) {
                $val = trim((string)$postVal);
                $exists = Database::fetch('SELECT id FROM settings WHERE school_id = ? AND setting_key = ?', [$schoolId, $postKey]);
                if ($exists) {
                    Database::execute('UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$val, (int)$exists['id']]);
                } else {
                    Database::insert('INSERT INTO settings (school_id, setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())', [$schoolId, $postKey, $val]);
                }
            }
        }

        // Invalidate cached tenant settings
        \Core\Cache\CacheManager::flushTenant($schoolId);

        auditLog('settings.update', 'settings', 'Settings updated');
        flash('success', 'Settings saved successfully.');
        redirect(url('settings' . ($activeTab !== '' ? '?tab=' . urlencode($activeTab) : '')));
    }
}
