<?php

declare(strict_types=1);

namespace App\Controllers\PublicSite;

use App\Services\MailService;
use App\Services\Platform\SchoolOnboardingService;
use Core\Controller;
use Core\Database;

final class MarketingController extends Controller
{
    private const SUCCESS_SESSION_KEY = 'registration_success';

    public function home(): void
    {
        $this->view('public/home', [
            'title' => platform_setting('platform_name', 'School Portal SaaS'),
            'plans' => Database::fetchAll('SELECT * FROM plans WHERE status = 1 ORDER BY sort_order'),
        ], 'layouts/guest');
    }


    public function pricing(): void
    {
        $this->view('public/pricing', [
            'title' => 'Pricing',
            'plans' => Database::fetchAll('SELECT * FROM plans WHERE status = 1 ORDER BY sort_order'),
        ], 'layouts/guest');
    }

    public function registerForm(): void
    {
        if (platform_setting('registration_enabled', '1') !== '1') {
            flash('error', 'Public registration is currently disabled.');
            redirect(url('pricing'));
        }

        $draft = $_SESSION['school_registration_draft'] ?? [];

        $this->view('public/register', [
            'title' => 'Register Your School · School Portal SaaS',
            'plans' => Database::fetchAll('SELECT * FROM plans WHERE status = 1 ORDER BY sort_order'),
            'draft' => $draft,
            'trialDays' => 30,
            'trialStartDate' => date('M d, Y'),
            'trialEndDate' => date('M d, Y', strtotime('+30 days')),
        ], 'layouts/guest');
    }

    public function saveDraft(): void
    {
        $input = $_POST;
        unset($input['password'], $input['password_confirmation'], $input['_csrf']);
        $_SESSION['school_registration_draft'] = $input;

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Registration draft saved successfully.']);
            exit;
        }

        flash('success', 'Your registration draft has been saved.');
        redirect(url('register'));
    }

    public function clearDraft(): void
    {
        unset($_SESSION['school_registration_draft']);
        flash('info', 'Registration draft has been cleared.');
        redirect(url('register'));
    }

    public function registrationSuccess(): void
    {
        $reference = $_SESSION[self::SUCCESS_SESSION_KEY] ?? null;
        if (!is_array($reference) || !isset($reference['id'], $reference['signature'])) {
            flash('error', 'Registration details are no longer available.');
            redirect(url('register'));
        }

        $registrationId = (int) $reference['id'];
        $expectedSignature = $this->registrationSignature($registrationId);
        if (!hash_equals($expectedSignature, (string) $reference['signature'])) {
            unset($_SESSION[self::SUCCESS_SESSION_KEY]);
            flash('error', 'Registration details are no longer available.');
            redirect(url('register'));
        }

        $registration = Database::fetch(
            'SELECT r.id, r.school_name, r.school_type, r.website, r.contact_person, r.email, r.phone, r.city, r.province, r.area, r.street, r.house_number, 
                    r.estimated_students, r.estimated_staff, r.education_levels, r.curriculum, r.academic_year_start, r.academic_year_end, r.country,
                    r.status AS registration_status, r.school_id, r.created_at, r.logo,
                    p.name AS plan_name, p.monthly_price,
                    s.code AS school_code, s.subscription_status, s.status AS school_status, s.trial_ends_at
             FROM school_registrations r
             LEFT JOIN plans p ON p.id = r.plan_id
             LEFT JOIN schools s ON s.id = r.school_id
             WHERE r.id = ? LIMIT 1',
            [$registrationId]
        );

        if (!$registration) {
            unset($_SESSION[self::SUCCESS_SESSION_KEY]);
            flash('error', 'Registration details are no longer available.');
            redirect(url('register'));
        }

        $isProvisioned = $registration['registration_status'] === 'provisioned' && !empty($registration['school_id']);
        $status = $isProvisioned
            ? ucfirst(str_replace('_', ' ', (string) ($registration['subscription_status'] ?: 'trial')))
            : 'Pending Email Verification';

        $this->view('public/register_success', [
            'title' => 'School Registration Successful · Welcome to School Portal',
            'registration' => $registration,
            'isProvisioned' => $isProvisioned,
            'statusLabel' => $status,
            'loginUrl' => $isProvisioned && !empty($registration['school_code'])
                ? url('login?school=' . urlencode($registration['school_code']))
                : url('login'),
        ], 'layouts/guest');
    }

    public function register(): void
    {
        if (platform_setting('registration_enabled', '1') !== '1') {
            flash('error', 'Registration is currently disabled.');
            redirect(url('/'));
        }
        $this->requireCsrf();

        // -----------------------------------------------------------------------
        // 1. Password confirmation check
        // -----------------------------------------------------------------------
        $password        = $_POST['password']              ?? '';
        $passwordConfirm = $_POST['password_confirmation'] ?? '';

        if ($password !== $passwordConfirm) {
            flash('error', 'Password and Confirm Password do not match.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }

        // -----------------------------------------------------------------------
        // 2. Password strength requirement (Min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 symbol)
        // -----------------------------------------------------------------------
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
            flash('error', 'Password must be at least 8 characters long and include an uppercase letter, lowercase letter, number, and special character.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }

        // -----------------------------------------------------------------------
        // 3. Terms of Service acceptance
        // -----------------------------------------------------------------------
        if (empty($_POST['terms_accepted'])) {
            flash('error', 'You must agree to the Terms of Service and Privacy Policy to register.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }

        // -----------------------------------------------------------------------
        // 4. Server-side validation of required fields
        // -----------------------------------------------------------------------
        $data = $this->validate($_POST, [
            'school_name'    => 'required',
            'contact_person' => 'required',
            'email'          => 'required|email',
            'plan_id'        => 'required|integer',
            'password'       => 'required|min:8',
        ]);

        $cleanEmail = strtolower(trim($data['email']));

        // -----------------------------------------------------------------------
        // 5. Prevent duplicate registrations and account collision in users table
        // -----------------------------------------------------------------------
        $existingReg = Database::fetch(
            'SELECT id FROM school_registrations WHERE email = ? AND status IN ("provisioned", "pending") LIMIT 1',
            [$cleanEmail]
        );
        $existingUser = Database::fetch(
            'SELECT id FROM users WHERE email = ? LIMIT 1',
            [$cleanEmail]
        );

        if ($existingReg || $existingUser) {
            flash('error', 'An account with this email address already exists. Please sign in or use a different email.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }

        // -----------------------------------------------------------------------
        // 6. Validate the selected plan exists and is active
        // -----------------------------------------------------------------------
        $plan = Database::fetch(
            'SELECT * FROM plans WHERE id = ? AND status = 1 LIMIT 1',
            [(int) $data['plan_id']]
        );
        if (!$plan) {
            flash('error', 'The selected subscription plan is not available.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }

        // -----------------------------------------------------------------------
        // 7. Handle File Upload (Logo) with Strict MIME & Extension Validation
        // -----------------------------------------------------------------------
        $logoPath = null;
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['logo']['tmp_name'];
            $name    = basename($_FILES['logo']['name']);
            $ext     = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $size    = (int) ($_FILES['logo']['size'] ?? 0);

            if ($size > 2 * 1024 * 1024) {
                flash('error', 'Logo file size exceeds the 2MB limit.');
                flash('old', $this->sanitizeOldInput($_POST));
                redirect(url('register'));
            }

            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $tmpName);
            finfo_close($finfo);

            $allowedMimes = ['image/jpeg', 'image/png'];
            if (in_array($ext, ['png', 'jpg', 'jpeg'], true) && in_array($mime, $allowedMimes, true)) {
                $uploadDir = base_path('public/uploads/logos/');
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                $newName = uniqid('logo_', true) . '.' . $ext;
                if (move_uploaded_file($tmpName, $uploadDir . $newName)) {
                    $logoPath = 'uploads/logos/' . $newName;
                }
            } else {
                flash('error', 'Invalid logo image format. Only official PNG and JPG files are permitted.');
                flash('old', $this->sanitizeOldInput($_POST));
                redirect(url('register'));
            }
        }

        // -----------------------------------------------------------------------
        // 8. Prepare Academic Structure & Extended Metadata
        // -----------------------------------------------------------------------
        $educationLevels = $_POST['education_levels'] ?? ['Montessori', 'Primary', 'Middle', 'Matric'];
        $educationLevelsStr = is_array($educationLevels) ? implode(',', array_map('trim', $educationLevels)) : trim((string) $educationLevels);

        $schoolType      = trim((string) ($_POST['school_type'] ?? 'Private School'));
        $website         = trim((string) ($_POST['website'] ?? ''));
        $curriculum      = trim((string) ($_POST['curriculum'] ?? 'Federal Board'));
        $academicStart   = trim((string) ($_POST['academic_year_start'] ?? 'April'));
        $academicEnd     = trim((string) ($_POST['academic_year_end'] ?? 'March'));
        $estimatedStaff  = !empty($_POST['estimated_staff']) ? (int) $_POST['estimated_staff'] : 25;
        $estStudents     = !empty($_POST['estimated_students']) ? (int) $_POST['estimated_students'] : 300;

        $token           = bin2hex(random_bytes(32));
        $passwordHash    = password_hash($data['password'], PASSWORD_DEFAULT);

        // -----------------------------------------------------------------------
        // 9. Atomic Insertion into school_registrations
        // -----------------------------------------------------------------------
        $id = Database::insert(
            'INSERT INTO school_registrations
            (school_name, school_type, website, contact_person, email, phone, country, province, city, area, street, house_number, 
             estimated_students, education_levels, curriculum, academic_year_start, academic_year_end, estimated_staff,
             plan_id, logo, password_hash, verification_token, status, terms_accepted, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())',
            [
                $data['school_name'],
                $schoolType,
                $website ?: null,
                $data['contact_person'],
                $cleanEmail,
                $_POST['phone'] ?? null,
                $_POST['country'] ?? 'Pakistan',
                $_POST['province'] ?? null,
                $_POST['city'] ?? null,
                $_POST['area'] ?? null,
                $_POST['street'] ?? null,
                $_POST['house_number'] ?? null,
                $estStudents,
                $educationLevelsStr,
                $curriculum,
                $academicStart,
                $academicEnd,
                $estimatedStaff,
                (int) $data['plan_id'],
                $logoPath,
                $passwordHash,
                hash('sha256', $token),
                'pending',
            ]
        );

        // -----------------------------------------------------------------------
        // 10. Atomic Provisioning of Tenant School, Admin User, and 30-Day Trial
        // -----------------------------------------------------------------------
        try {
            $schoolId = SchoolOnboardingService::provision([
                'name'                => $data['school_name'],
                'school_type'         => $schoolType,
                'website'             => $website ?: null,
                'email'               => $cleanEmail,
                'phone'               => $_POST['phone'] ?? null,
                'country'             => $_POST['country'] ?? 'Pakistan',
                'province'            => $_POST['province'] ?? null,
                'city'                => $_POST['city'] ?? null,
                'area'                => $_POST['area'] ?? null,
                'street'              => $_POST['street'] ?? null,
                'house_number'        => $_POST['house_number'] ?? null,
                'logo'                => $logoPath,
                'education_levels'    => $educationLevelsStr,
                'curriculum'          => $curriculum,
                'academic_year_start' => $academicStart,
                'academic_year_end'   => $academicEnd,
                'estimated_staff'     => $estimatedStaff,
            ], [
                'name'          => $data['contact_person'],
                'email'         => $cleanEmail,
                'password_hash' => $passwordHash,
                'phone'         => $_POST['phone'] ?? null,
            ], (int) $data['plan_id'], true);

            $school = Database::fetch('SELECT code, name FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
            if (!$school || empty($school['code'])) {
                throw new \RuntimeException('School provisioning did not return a valid School Code.');
            }

            Database::execute(
                'UPDATE school_registrations
                 SET status = ?, email_verified_at = NOW(), school_id = ?, updated_at = NOW()
                 WHERE id = ?',
                ['provisioned', $schoolId, $id]
            );

            // Clear draft session after successful creation
            unset($_SESSION['school_registration_draft']);

            try {
                MailService::sendWelcome(
                    $cleanEmail,
                    $data['contact_person'],
                    $school['name'],
                    $school['code'],
                    url('login')
                );
            } catch (\Throwable $e) {
                error_log('[MarketingController] Welcome email notification skipped: ' . $e->getMessage());
            }

            $this->rememberRegistrationSuccess($id);
            redirect(url('register/success'));
        } catch (\Throwable $e) {
            if ($e instanceof \App\Exceptions\RedirectException) {
                throw $e;
            }
            error_log('[MarketingController] Immediate registration provisioning failed: ' . $e->getMessage());
            flash('error', 'Registration could not be completed at this moment. Please try again.');
            flash('old', $this->sanitizeOldInput($_POST));
            redirect(url('register'));
        }
    }

    private function sanitizeOldInput(array $post): array
    {
        unset($post['password'], $post['password_confirmation'], $post['_csrf']);
        return $post;
    }

    public function verify(): void
    {
        $id    = (int) ($_GET['id']    ?? 0);
        $token = $_GET['token'] ?? '';
        $row   = Database::fetch('SELECT * FROM school_registrations WHERE id = ? LIMIT 1', [$id]);

        if (!$row || !hash_equals($row['verification_token'] ?? '', hash('sha256', $token))) {
            flash('error', 'Invalid verification link.');
            redirect(url('register'));
        }
        if ($row['status'] === 'provisioned') {
            $this->rememberRegistrationSuccess((int) $row['id']);
            redirect(url('register/success'));
        }

        try {
            // ------------------------------------------------------------------
            // Provision the school. This generates the school code inside
            // TenantService::createSchool(). The code is then read back from
            // the database — it is NEVER regenerated or provided by the client.
            // ------------------------------------------------------------------
            $schoolId = SchoolOnboardingService::provision([
                'name'                => $row['school_name'],
                'school_type'         => $row['school_type'] ?? 'Private School',
                'website'             => $row['website'] ?? null,
                'email'               => $row['email'],
                'phone'               => $row['phone'],
                'country'             => $row['country'],
                'province'            => $row['province'] ?? null,
                'city'                => $row['city'],
                'area'                => $row['area'] ?? null,
                'street'              => $row['street'] ?? null,
                'house_number'        => $row['house_number'] ?? null,
                'logo'                => $row['logo'] ?? null,
                'education_levels'    => $row['education_levels'] ?? null,
                'curriculum'          => $row['curriculum'] ?? null,
                'academic_year_start' => $row['academic_year_start'] ?? null,
                'academic_year_end'   => $row['academic_year_end'] ?? null,
                'estimated_staff'     => $row['estimated_staff'] ?? null,
            ], [
                'name'          => $row['contact_person'],
                'email'         => $row['email'],
                'password_hash' => $row['password_hash'],
                'phone'         => $row['phone'],
            ], (int) $row['plan_id'], true);

            // ------------------------------------------------------------------
            // Read the actual school code assigned by the system.
            // SECURITY: This code comes from the database. It was generated
            // server-side by TenantService::generateSchoolCode(). The client
            // cannot supply or override it.
            // ------------------------------------------------------------------
            $school = Database::fetch('SELECT code, name FROM schools WHERE id = ?', [$schoolId]);

            Database::execute(
                'UPDATE school_registrations SET status = ?, email_verified_at = NOW(), school_id = ?, updated_at = NOW() WHERE id = ?',
                ['provisioned', $schoolId, $id]
            );

            // ------------------------------------------------------------------
            // Send the welcome/login email. Contains school name, school code,
            // login email, and login URL. NEVER contains the plain-text password.
            // ------------------------------------------------------------------
            $schoolCode = $school['code'] ?? '';
            $loginUrl   = url('login');

            try {
                MailService::sendWelcome(
                    strtolower($row['email']),
                    $row['contact_person'],
                    $school['name'] ?? $row['school_name'],
                    $schoolCode,
                    $loginUrl
                );
            } catch (\Throwable $e) {
                // Mail failure must not block activation. Log and continue.
                error_log('[MarketingController] Welcome email failed: ' . $e->getMessage());
            }

            $this->rememberRegistrationSuccess((int) $row['id']);
            redirect(url('register/success'));

        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('register'));
        }
    }

    private function rememberRegistrationSuccess(int $registrationId): void
    {
        $_SESSION[self::SUCCESS_SESSION_KEY] = [
            'id' => $registrationId,
            'signature' => $this->registrationSignature($registrationId),
        ];
    }

    private function registrationSignature(int $registrationId): string
    {
        return hash_hmac('sha256', (string) $registrationId, session_id());
    }
}
