<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ParentModel;
use App\Models\User;
use Core\Controller;
use Core\Database;

final class ParentController extends Controller
{
    public function index(): void
    {
        requirePermission('parents.view');
        
        $search = $_GET['q'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $sql = 'SELECT p.* FROM parents p WHERE p.school_id = ?';
        $params = [$this->schoolId()];
        
        if ($search !== '') {
            $sql .= ' AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.email LIKE ? OR p.phone LIKE ?)';
            $q = "%$search%";
            $params = array_merge($params, [$q, $q, $q, $q]);
        }
        
        // Count total
        $countSql = str_replace('p.*', 'COUNT(*) AS total', $sql);
        $totalRow = Database::fetch($countSql, $params);
        $total = (int)($totalRow['total'] ?? 0);
        $totalPages = ceil($total / $limit);
        
        $sql .= ' ORDER BY p.first_name ASC LIMIT ' . $limit . ' OFFSET ' . $offset;
        $parents = Database::fetchAll($sql, $params);
        
        foreach ($parents as &$parent) {
            $parent['children'] = Database::fetchAll(
                'SELECT s.*, c.name AS class_name, sec.name AS section_name 
                 FROM students s 
                 INNER JOIN student_parents sp ON sp.student_id = s.id 
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 WHERE sp.parent_id = ? AND sp.school_id = ?',
                [(int)$parent['id'], $this->schoolId()]
            );
        }

        $this->view('parents/admin_index', [
            'title' => 'Parents & Guardians',
            'parents' => $parents,
            'filters' => ['q' => $search],
            'page' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function create(): void
    {
        requirePermission('parents.create');
        $this->view('parents/admin_form', [
            'title' => 'Add Parent',
            'parent' => null,
        ]);
    }

    public function store(): void
    {
        requirePermission('parents.create');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'first_name' => 'required|max:100',
            'last_name' => 'required|max:100',
            'email' => 'required|email|max:191',
            'phone' => 'required|max:50',
        ]);

        $model = new ParentModel();
        
        $parentId = $model->create([
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'occupation' => $_POST['occupation'] ?? null,
            'address' => $_POST['address'] ?? null,
            'relation_label' => $_POST['relation_label'] ?? 'Guardian',
            'status' => 1,
        ]);

        // Automatically create a user for the parent
        $roleId = Database::fetch("SELECT id FROM roles WHERE slug = 'parent' AND (school_id = ? OR school_id IS NULL) ORDER BY school_id DESC LIMIT 1", [$this->schoolId()])['id'] ?? null;
        $parentPass = !empty($_POST['password']) ? $_POST['password'] : 'Password@123';
        if ($roleId) {
            (new User())->create([
                'school_id' => $this->schoolId(),
                'name' => $data['first_name'] . ' ' . $data['last_name'],
                'email' => $data['email'],
                'phone' => $data['phone'],
                'password' => password_hash($parentPass, PASSWORD_DEFAULT),
                'role_id' => $roleId,
                'parent_id' => $parentId,
                'status' => 1
            ]);
        }

        flash('success', 'Parent created successfully! Login Email: ' . htmlspecialchars($data['email']) . ' | Password: ' . htmlspecialchars($parentPass));
        redirect(url('parents'));
    }

    public function edit(string $id): void
    {
        requirePermission('parents.edit');
        $parent = (new ParentModel())->find((int) $id);
        if (!$parent) {
            flash('error', 'Parent not found.');
            redirect(url('parents'));
        }
        $this->view('parents/admin_form', [
            'title' => 'Edit Parent',
            'parent' => $parent,
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('parents.edit');
        $this->requireCsrf();
        
        $model = new ParentModel();
        $old = $model->find((int) $id);
        if (!$old) {
            flash('error', 'Parent not found.');
            redirect(url('parents'));
        }

        $data = $this->validate($_POST, [
            'first_name' => 'required|max:100',
            'last_name' => 'required|max:100',
            'email' => 'required|email|max:191',
            'phone' => 'required|max:50',
        ]);

        $model->update((int) $id, [
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'occupation' => $_POST['occupation'] ?? null,
            'address' => $_POST['address'] ?? null,
            'relation_label' => $_POST['relation_label'] ?? 'Guardian',
        ]);

        // Sync with User table if it exists
        $user = Database::fetch("SELECT id FROM users WHERE parent_id = ? AND school_id = ?", [(int)$id, $this->schoolId()]);
        if ($user) {
            (new User())->update((int)$user['id'], [
                'name' => $data['first_name'] . ' ' . $data['last_name'],
                'email' => $data['email'],
                'phone' => $data['phone']
            ]);
        }

        flash('success', 'Parent updated.');
        redirect(url('parents'));
    }
}
