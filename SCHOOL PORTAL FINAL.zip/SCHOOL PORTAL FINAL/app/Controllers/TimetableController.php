<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Admission;
use App\Models\Announcement;
use App\Models\AuditLog;
use App\Models\ClassModel;
use App\Models\LeaveRequest;
use App\Models\Notification;
use App\Models\Teacher;
use App\Models\Timetable;
use App\Models\User;
use App\Services\AdmissionService;
use App\Services\LeaveService;
use App\Services\ReportService;
use App\Services\TimetableService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class TimetableController extends Controller
{
    public function index(): void
    {
        if (\Core\Auth::roleSlug() === 'student') {
            (new StudentPortalController())->timetable();
            return;
        }
        requirePermission('timetable.view');
        
        $classes = (new ClassModel())->withSections();
        $teachers = (new Teacher())->listAll();
        $subjects = Database::fetchAll('SELECT * FROM subjects WHERE school_id = ? AND status = 1 ORDER BY name ASC', [$this->schoolId()]);
        
        $activeYearId = activeAcademicYearId();
        $terms = $activeYearId ? Database::fetchAll('SELECT * FROM academic_terms WHERE academic_year_id = ? AND school_id = ? ORDER BY start_date ASC', [$activeYearId, $this->schoolId()]) : [];
        $selectedTermId = (int) ($_GET['term_id'] ?? ($terms[0]['id'] ?? 0));

        $periods = Database::fetchAll('SELECT * FROM timetable_periods WHERE school_id = ? ORDER BY period_number ASC', [$this->schoolId()]);
        $rooms = Database::fetchAll('SELECT * FROM rooms WHERE school_id = ? AND status = 1', [$this->schoolId()]);

        $viewMode = $_GET['view'] ?? 'class';
        $teacherId = (int) ($_GET['teacher_id'] ?? 0);
        $classId = (int) ($_GET['class_id'] ?? 0);
        $sectionId = (int) ($_GET['section_id'] ?? 0);

        if (!$classId && isRole('parent')) {
            $studentId = (int) ($_SESSION['selected_student_id'] ?? 0);
            if ($studentId) {
                $student = (new \App\Models\Student())->find($studentId);
                if ($student) {
                    $classId = (int) $student['class_id'];
                    $sectionId = (int) $student['section_id'];
                }
            }
        }

        // Default selection for seamless display
        if ($viewMode === 'class') {
            if (!$classId && !empty($classes)) {
                $classId = (int) $classes[0]['id'];
                if (!empty($classes[0]['sections'])) {
                    $sectionId = (int) $classes[0]['sections'][0]['id'];
                }
            } elseif ($classId && !$sectionId) {
                foreach ($classes as $c) {
                    if ((int)$c['id'] === $classId && !empty($c['sections'])) {
                        $sectionId = (int)$c['sections'][0]['id'];
                        break;
                    }
                }
            }
        } elseif ($viewMode === 'teacher') {
            if (!$teacherId && !empty($teachers)) {
                $teacherId = (int) $teachers[0]['id'];
            }
        }

        $rows = [];
        if ($viewMode === 'teacher' && $teacherId) {
            $rows = (new Timetable())->forTeacher($teacherId);
        } elseif ($classId && $sectionId) {
            $rows = (new Timetable())->forClass($classId, $sectionId);
        } elseif (isRole('teacher')) {
            $t = (new Teacher())->findByUserId((int) Auth::id());
            if ($t) {
                $rows = (new Timetable())->forTeacher((int) $t['id']);
                $viewMode = 'teacher';
                $teacherId = (int) $t['id'];
            }
        }

        // Find selected class name and section name
        $selectedClassName = '';
        $selectedSectionName = '';
        foreach ($classes as $c) {
            if ((int)$c['id'] === $classId) {
                $selectedClassName = $c['name'];
                foreach ($c['sections'] as $sec) {
                    if ((int)$sec['id'] === $sectionId) {
                        $selectedSectionName = $sec['name'];
                        break;
                    }
                }
                break;
            }
        }

        // Find selected teacher name
        $selectedTeacherName = '';
        foreach ($teachers as $t) {
            if ((int)$t['id'] === $teacherId) {
                $selectedTeacherName = trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''));
                break;
            }
        }

        $this->view('timetable/index', [
            'title' => 'Timetable & Schedules',
            'rows' => $rows,
            'classes' => $classes,
            'teachers' => $teachers,
            'subjects' => $subjects,
            'terms' => $terms,
            'selectedTermId' => $selectedTermId,
            'periods' => $periods,
            'rooms' => $rooms,
            'viewMode' => $viewMode,
            'classId' => $classId,
            'sectionId' => $sectionId,
            'teacherId' => $teacherId,
            'selectedClassName' => $selectedClassName,
            'selectedSectionName' => $selectedSectionName,
            'selectedTeacherName' => $selectedTeacherName,
        ]);
    }

    public function store(): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();
        try {
            (new TimetableService())->create($_POST);
            flash('success', 'Timetable slot added successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        $classId = (int)($_POST['class_id'] ?? 0);
        $sectionId = (int)($_POST['section_id'] ?? 0);
        redirect(url("timetable?class_id={$classId}&section_id={$sectionId}"));
    }

    public function edit(string $id): void
    {
        requirePermission('timetable.manage');
        $timetable = (new Timetable())->find((int) $id);
        if (!$timetable || (int)$timetable['school_id'] !== (int)$this->schoolId()) {
            flash('error', 'Timetable entry not found.');
            redirect(url('timetable'));
        }
        $this->view('timetable/form_edit', [
            'title' => 'Edit Timetable Entry',
            'timetable' => $timetable,
            'classes' => (new ClassModel())->withSections(),
            'teachers' => (new Teacher())->listAll(),
            'subjects' => Database::fetchAll('SELECT * FROM subjects WHERE school_id = ? AND status = 1', [$this->schoolId()]),
        ]);
    }

    public function update(string $id): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();
        try {
            (new TimetableService())->update((int) $id, $_POST);
            flash('success', 'Timetable slot updated successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        $classId = (int)($_POST['class_id'] ?? 0);
        $sectionId = (int)($_POST['section_id'] ?? 0);
        redirect(url("timetable?class_id={$classId}&section_id={$sectionId}"));
    }

    public function destroy(string $id): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();
        $timetable = (new Timetable())->find((int) $id);
        if ($timetable && (int)$timetable['school_id'] === (int)$this->schoolId()) {
            $classId = (int)$timetable['class_id'];
            $sectionId = (int)$timetable['section_id'];
            (new Timetable())->delete((int) $id);
            auditLog('timetable.delete', 'timetable', 'timetables', (int) $id);
            flash('success', 'Timetable entry deleted successfully.');
            redirect(url("timetable?class_id={$classId}&section_id={$sectionId}"));
            return;
        }
        redirect(url('timetable'));
    }

    public function bulkEdit(): void
    {
        requirePermission('timetable.manage');
        $classId = (int) ($_GET['class_id'] ?? 0);
        $sectionId = (int) ($_GET['section_id'] ?? 0);

        if (!$classId || !$sectionId) {
            flash('error', 'Select class and section first.');
            redirect(url('timetable'));
        }

        // Fetch or create default periods (e.g. 1 to 7)
        $periods = Database::fetchAll('SELECT * FROM timetable_periods WHERE school_id = ? ORDER BY period_number', [$this->schoolId()]);
        if (empty($periods)) {
            for ($i = 1; $i <= 7; $i++) {
                $start = sprintf('%02d:00:00', 7 + $i);
                $end = sprintf('%02d:45:00', 7 + $i);
                Database::insert('INSERT INTO timetable_periods (school_id, period_number, start_time, end_time, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())', [$this->schoolId(), $i, $start, $end]);
            }
            $periods = Database::fetchAll('SELECT * FROM timetable_periods WHERE school_id = ? ORDER BY period_number', [$this->schoolId()]);
        }

        // Current timetable for this class
        $current = (new Timetable())->forClass($classId, $sectionId);
        $timetableMap = [];
        foreach ($current as $tt) {
            $timetableMap[$tt['day_of_week']][$tt['period_id']] = $tt;
        }

        $classSubjects = Database::fetchAll(
            'SELECT s.* FROM subjects s INNER JOIN class_subjects cs ON cs.subject_id = s.id WHERE cs.class_id = ? AND s.school_id = ? AND s.status = 1',
            [$classId, $this->schoolId()]
        );

        $this->view('timetable/bulk_edit', [
            'title' => 'Bulk Edit Timetable',
            'periods' => $periods,
            'timetableMap' => $timetableMap,
            'classId' => $classId,
            'sectionId' => $sectionId,
            'classes' => (new ClassModel())->withSections(),
            'teachers' => (new Teacher())->listAll(),
            'subjects' => $classSubjects,
        ]);
    }

    public function bulkStore(): void
    {
        requirePermission('timetable.manage');
        $this->requireCsrf();
        $classId = (int) ($_POST['class_id'] ?? 0);
        $sectionId = (int) ($_POST['section_id'] ?? 0);
        $slots = $_POST['timetable'] ?? [];
        $academicYearId = activeAcademicYearId();

        if ($classId && $sectionId) {
            Database::beginTransaction();
            try {
                // Delete existing timetable for this class and section
                Database::execute('DELETE FROM timetables WHERE school_id = ? AND class_id = ? AND section_id = ? AND academic_year_id = ?', [
                    $this->schoolId(), $classId, $sectionId, $academicYearId
                ]);

                foreach ($slots as $day => $periods) {
                    foreach ($periods as $periodId => $data) {
                        if (!empty($data['subject_id']) && !empty($data['teacher_id'])) {
                            Database::insert('INSERT INTO timetables (school_id, academic_year_id, class_id, section_id, period_id, subject_id, teacher_id, day_of_week, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())', [
                                $this->schoolId(), $academicYearId, $classId, $sectionId, (int)$periodId, (int)$data['subject_id'], (int)$data['teacher_id'], (int)$day
                            ]);
                        }
                    }
                }
                Database::commit();
                flash('success', 'Timetable saved successfully.');
            } catch (\Throwable $e) {
                Database::rollBack();
                flash('error', $e->getMessage());
            }
        }
        redirect(url("timetable?class_id={$classId}&section_id={$sectionId}"));
    }

    public function conflicts(): void
    {
        requirePermission('timetable.view');
        $schoolId = (int) $this->schoolId();
        $yearId = (int) activeAcademicYearId();
        $report = (new TimetableService())->scanAllConflicts($schoolId, $yearId);

        if ($this->isAjax()) {
            $this->json($report);
            return;
        }

        $this->view('timetable/conflicts', [
            'title' => 'Timetable Conflict Scanner',
            'report' => $report,
        ]);
    }
}
