<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\WorkflowEngineService;
use Core\Auth;
use Core\Controller;

final class WorkflowController extends Controller
{
    private WorkflowEngineService $workflowService;

    public function __construct()
    {
        $this->workflowService = new WorkflowEngineService();
    }

    /**
     * Approvals Console & Workflow Dashboard.
     */
    public function index(): void
    {
        Auth::requireLogin();
        if (!hasPermission('settings.manage') && !isRole('admin') && !isRole('principal')) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }

        $schoolId = (int) Auth::schoolId();
        $status = $_GET['status'] ?? 'pending';
        $type = $_GET['type'] ?? 'all';
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $limit = 15;
        $offset = ($page - 1) * $limit;

        $data = $this->workflowService->listAll($schoolId, $status, $type, $limit, $offset);
        $metrics = $this->workflowService->metrics($schoolId);

        $totalPages = max(1, (int) ceil($data['total'] / $limit));

        $this->view('workflows/index', [
            'title' => 'Unified Approvals & Workflow Hub',
            'workflows' => $data['rows'],
            'total' => $data['total'],
            'metrics' => $metrics,
            'status' => $status,
            'type' => $type,
            'page' => $page,
            'totalPages' => $totalPages,
        ]);
    }

    /**
     * Process workflow transition action (Approve / Reject / Cancel).
     */
    public function action(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();

        if (!hasPermission('settings.manage') && !isRole('admin') && !isRole('principal')) {
            flash('error', 'Unauthorized to action approval workflows.');
            redirect(url('workflows'));
            return;
        }

        $action = trim((string) ($_POST['action'] ?? ''));
        $remarks = trim((string) ($_POST['remarks'] ?? ''));
        $workflowId = (int) $id;

        if (!in_array($action, ['approve', 'reject', 'cancel'], true)) {
            flash('error', 'Invalid workflow action specified.');
            redirect(url('workflows'));
            return;
        }

        try {
            $this->workflowService->transition($workflowId, $action, (int) Auth::id(), $remarks ?: null);
            flash('success', "Workflow item #{$workflowId} successfully " . ucfirst($action) . "d.");
        } catch (\Throwable $e) {
            flash('error', 'Workflow transition error: ' . $e->getMessage());
        }

        redirect(url('workflows'));
    }

    /**
     * API: Get pending workflows count and recent items.
     */
    public function apiPending(): void
    {
        Auth::requireLogin();
        $schoolId = (int) Auth::schoolId();
        if ($schoolId <= 0) {
            $this->json(['error' => 'Unauthorized'], 403);
            return;
        }

        $pending = $this->workflowService->listPending($schoolId, null, 5);
        $metrics = $this->workflowService->metrics($schoolId);

        $this->json([
            'pending_count' => $metrics['pending'],
            'items' => $pending,
        ]);
    }
}
