<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Services\ReportService;
use Core\Controller;

final class ReportController extends Controller
{
    public function index(): void
    {
        requirePermission('reports.view');
        $this->view('reports/index', ['title' => 'Reports']);
    }

    public function fees(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $this->view('reports/fees', [
            'title' => 'Fee Collection Report',
            'rows' => (new ReportService())->feeCollection($from, $to),
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function attendance(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $this->view('reports/attendance', [
            'title' => 'Attendance Report',
            'rows' => (new ReportService())->studentAttendance($from, $to, $classId),
            'classes' => (new ClassModel())->all('numeric_name ASC'),
            'from' => $from,
            'to' => $to,
            'classId' => $classId,
        ]);
    }

    public function payroll(): void
    {
        requirePermission('reports.view');
        $month = $_GET['month'] ?? date('Y-m');
        $this->view('reports/payroll', [
            'title' => 'Payroll Report',
            'rows' => (new ReportService())->payroll($month),
            'month' => $month,
        ]);
    }

    public function expenses(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $this->view('reports/expenses', [
            'title' => 'Expense Report',
            'rows' => (new ReportService())->expenses($from, $to),
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function staffAttendance(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $this->view('reports/staff_attendance', [
            'title' => 'Staff Attendance Report',
            'rows' => (new ReportService())->staffAttendance($from, $to),
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function leaves(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $this->view('reports/leaves', [
            'title' => 'Leave Report',
            'rows' => (new ReportService())->leaves($from, $to),
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function students(): void
    {
        requirePermission('reports.view');
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $this->view('reports/students', [
            'title' => 'Student Demographics Report',
            'rows' => (new ReportService())->students($classId),
            'classes' => (new ClassModel())->all('numeric_name ASC'),
            'classId' => $classId,
        ]);
    }

    public function executiveSummary(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $summary = (new ReportService())->executiveSummary($from, $to);

        $this->view('reports/executive', [
            'title' => 'Executive Analytics & Cross-Module Summary',
            'summary' => $summary,
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function trends(): void
    {
        requirePermission('reports.view');
        $months = isset($_GET['months']) ? max(3, min(12, (int) $_GET['months'])) : 6;
        $trends = (new ReportService())->analyticsTrends($this->schoolId(), $months);

        $this->view('reports/trends', [
            'title' => 'Historical Trends & MoM Analytics',
            'trends' => $trends,
            'months' => $months,
        ]);
    }

    public function exportFees(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $rows = (new ReportService())->feeCollection($from, $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="fee_collection_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Payment Date', 'Receipt No', 'Admission No', 'Student Name', 'Amount', 'Payment Method']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['payment_date'],
                $r['receipt_no'],
                $r['admission_no'],
                $r['student_name'],
                $r['amount'],
                strtoupper($r['payment_method'] ?? 'CASH'),
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportAttendance(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $rows = (new ReportService())->studentAttendance($from, $to, $classId);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="student_attendance_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Date', 'Student Name', 'Class', 'Section', 'Status']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['attendance_date'],
                $r['student_name'],
                $r['class_name'],
                $r['section_name'] ?? 'N/A',
                strtoupper($r['status']),
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportPayroll(): void
    {
        requirePermission('reports.view');
        $month = $_GET['month'] ?? date('Y-m');
        $rows = (new ReportService())->payroll($month);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="payroll_' . date('Ym') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Staff Name', 'Employee Code', 'Month', 'Basic Salary', 'Allowances', 'Deductions', 'Net Salary', 'Status']);
        foreach ($rows as $r) {
            fputcsv($out, [
                ($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''),
                $r['employee_code'] ?? '',
                $r['month'] ?? $month,
                $r['basic_salary'] ?? 0,
                $r['allowances'] ?? 0,
                $r['deductions'] ?? 0,
                $r['net_salary'] ?? 0,
                strtoupper($r['status'] ?? 'PENDING'),
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportExpenses(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $rows = (new ReportService())->expenses($from, $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="expenses_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Expense Date', 'Title', 'Category', 'Amount', 'Payment Method', 'Notes']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['expense_date'],
                $r['title'] ?? '',
                $r['category'] ?? 'General',
                $r['amount'],
                strtoupper($r['payment_method'] ?? 'CASH'),
                $r['notes'] ?? '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportStudents(): void
    {
        requirePermission('reports.view');
        $classId = isset($_GET['class_id']) && $_GET['class_id'] !== '' ? (int) $_GET['class_id'] : null;
        $rows = (new ReportService())->students($classId);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="students_demographics_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Admission No', 'Student Name', 'Gender', 'Date of Birth', 'Class', 'Section']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['admission_no'],
                $r['student_name'],
                ucfirst($r['gender'] ?? ''),
                $r['date_of_birth'] ?? '',
                $r['class_name'] ?? 'Unassigned',
                $r['section_name'] ?? '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportStaffAttendance(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $rows = (new ReportService())->staffAttendance($from, $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="staff_attendance_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Date', 'Employee Name', 'Status', 'Remarks']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['attendance_date'],
                $r['employee_name'],
                strtoupper($r['status']),
                $r['remarks'] ?? '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function exportLeaves(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $rows = (new ReportService())->leaves($from, $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="leave_report_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Employee Name', 'Leave Type', 'Start Date', 'End Date', 'Days', 'Status', 'Reason']);
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['employee_name'],
                $r['leave_type'],
                $r['start_date'],
                $r['end_date'],
                $r['days'],
                strtoupper($r['status']),
                $r['reason'] ?? '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function incomeStatement(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $data = (new ReportService())->incomeVsExpense($from, $to);
        $this->view('reports/income_statement', [
            'title' => 'Income vs. Expense Statement',
            'data' => $data,
            'from' => $from,
            'to' => $to,
        ]);
    }

    public function exportIncomeStatement(): void
    {
        requirePermission('reports.view');
        $from = $_GET['from'] ?? date('Y-m-01');
        $to = $_GET['to'] ?? date('Y-m-d');
        $data = (new ReportService())->incomeVsExpense($from, $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="income_statement_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');

        fputcsv($out, ['INCOME VS EXPENSE STATEMENT']);
        fputcsv($out, ['Period:', $from . ' to ' . $to]);
        fputcsv($out, []);

        fputcsv($out, ['FINANCIAL PERFORMANCE SUMMARY']);
        fputcsv($out, ['Metric', 'Amount (USD)']);
        fputcsv($out, ['Total Fee Collections', number_format($data['summary']['total_fees'], 2)]);
        fputcsv($out, ['Total Other Incomes', number_format($data['summary']['total_other_income'], 2)]);
        fputcsv($out, ['Gross Operating Revenue', number_format($data['summary']['gross_revenue'], 2)]);
        fputcsv($out, ['Less: Refunds Issued', number_format($data['summary']['total_refunds'], 2)]);
        fputcsv($out, ['Net Operating Revenue', number_format($data['summary']['net_revenue'], 2)]);
        fputcsv($out, ['Total Operating Expenses', number_format($data['summary']['total_expenses'], 2)]);
        fputcsv($out, ['Net Operating Surplus / (Deficit)', number_format($data['summary']['net_operating_surplus'], 2)]);
        fputcsv($out, ['Net Profit Margin %', $data['summary']['profit_margin_pct'] . '%']);
        fputcsv($out, ['Operating Expense Ratio %', $data['summary']['expense_ratio_pct'] . '%']);
        fputcsv($out, []);

        fputcsv($out, ['REVENUE BREAKDOWN BY CATEGORY']);
        fputcsv($out, ['Category', 'Amount (USD)']);
        foreach ($data['incomes_by_category'] as $cat => $amt) {
            fputcsv($out, [$cat, number_format((float) $amt, 2)]);
        }
        fputcsv($out, []);

        fputcsv($out, ['EXPENSE BREAKDOWN BY CATEGORY']);
        fputcsv($out, ['Category', 'Amount (USD)']);
        foreach ($data['expenses_by_category'] as $cat => $amt) {
            fputcsv($out, [$cat, number_format((float) $amt, 2)]);
        }
        fputcsv($out, []);

        fputcsv($out, ['DETAILED EXPENSE TRANSACTIONS']);
        fputcsv($out, ['Date', 'Title', 'Category', 'Payment Method', 'Reference No', 'Amount']);
        foreach ($data['expenses'] as $exp) {
            fputcsv($out, [
                $exp['expense_date'],
                $exp['title'],
                $exp['category'],
                strtoupper((string) ($exp['payment_method'] ?? 'N/A')),
                $exp['reference_no'] ?? '',
                number_format((float) $exp['amount'], 2),
            ]);
        }

        fclose($out);
        exit;
    }
}

