<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\ParentModel;
use App\Models\Subject;
use App\Services\ClassResourceService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class ClassResourceController extends Controller
{
    private ClassResourceService $resourceService;

    public function __construct()
    {
        $this->resourceService = new ClassResourceService();
    }

    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) Auth::schoolId();
        $role = Auth::roleSlug();

        if ($role === 'student' || $role === 'parent') {
            redirect(url('portal/resources'));
            return;
        }

        requirePermission('assignments.view'); // Teachers & Admins

        $classes = (new ClassModel())->withSections();
        $subjects = (new Subject())->all('name ASC');

        $classId = (int) ($_GET['class_id'] ?? ($classes[0]['id'] ?? 0));
        $sectionId = !empty($_GET['section_id']) ? (int) $_GET['section_id'] : null;
        $subjectId = !empty($_GET['subject_id']) ? (int) $_GET['subject_id'] : null;

        $resources = [];
        if ($classId) {
            $resources = $this->resourceService->getResourcesForClass($classId, $sectionId, $subjectId, $schoolId);
        }

        $this->view('resources/index', [
            'title' => 'Class Learning Resources & Study Materials',
            'classes' => $classes,
            'subjects' => $subjects,
            'classId' => $classId,
            'sectionId' => $sectionId,
            'subjectId' => $subjectId,
            'resources' => $resources,
        ]);
    }

    public function portalIndex(): void
    {
        Auth::requireLogin();
        $schoolId = (int) Auth::schoolId();
        $role = Auth::roleSlug();
        $user = Auth::user();

        $student = null;
        $children = [];

        if ($role === 'parent') {
            $parentId = (int) ($user['parent_id'] ?? 0);
            if ($parentId) {
                $children = (new ParentModel())->children($parentId);
            }
            $studentId = (int) ($_GET['student_id'] ?? ($_SESSION['selected_student_id'] ?? ($children[0]['id'] ?? 0)));
            if ($studentId && (new ParentModel())->ownsStudent($parentId, $studentId)) {
                $_SESSION['selected_student_id'] = $studentId;
                $student = Database::fetch("SELECT * FROM students WHERE id = ? AND school_id = ? LIMIT 1", [$studentId, $schoolId]);
            }
        } else {
            // Student
            $student = Database::fetch("SELECT * FROM students WHERE user_id = ? AND school_id = ? LIMIT 1", [Auth::id(), $schoolId]);
        }

        if (!$student) {
            flash('error', 'Student profile could not be verified.');
            redirect(url('dashboard'));
            return;
        }

        $classId = (int) ($student['class_id'] ?? 0);
        $sectionId = (int) ($student['section_id'] ?? 0);
        $subjectId = !empty($_GET['subject_id']) ? (int) $_GET['subject_id'] : null;

        $resources = $this->resourceService->getResourcesForClass($classId, $sectionId, $subjectId, $schoolId);
        $subjects = Database::fetchAll("
            SELECT s.* FROM class_subjects cs
            JOIN subjects s ON s.id = cs.subject_id
            WHERE cs.class_id = ? AND s.status = 1
            ORDER BY s.name ASC
        ", [$classId]);

        $this->view('portal/student_resources', [
            'title' => 'Learning Resources & Documents',
            'student' => $student,
            'children' => $children,
            'role' => $role,
            'resources' => $resources,
            'subjects' => $subjects,
            'selectedSubjectId' => $subjectId,
        ]);
    }

    public function store(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        requirePermission('assignments.manage');

        $schoolId = (int) Auth::schoolId();
        $userId = (int) Auth::id();

        if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            flash('error', 'Please attach a valid resource file to upload.');
            back();
            return;
        }

        try {
            $id = $this->resourceService->createResource($schoolId, $_POST, $_FILES['file'], $userId);
            flash('success', 'Class resource uploaded and shared successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        back();
    }

    public function download(string $id): void
    {
        Auth::requireLogin();
        $schoolId = (int) Auth::schoolId();
        $resId = (int) $id;

        $res = $this->resourceService->downloadResource($resId, $schoolId);
        if (!$res) {
            flash('error', 'Resource file not found.');
            back();
            return;
        }

        $basePublic = realpath(public_path());
        $cleanRel = ltrim(str_replace(['../', '..\\'], '', (string)$res['file_path']), '/\\');
        $realPath = realpath(public_path($cleanRel));
        if (!$realPath || !str_starts_with($realPath, $basePublic) || !file_exists($realPath)) {
            flash('error', 'The requested file is no longer available on disk.');
            back();
            return;
        }

        header('Content-Description: File Transfer');
        header('Content-Type: ' . ($res['file_type'] ?: 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . addslashes(basename($res['file_name'])) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($realPath));
        readfile($realPath);
        exit;
    }

    public function destroy(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        requirePermission('assignments.manage');

        $schoolId = (int) Auth::schoolId();
        $userId = (int) Auth::id();
        $isAdmin = in_array(Auth::roleSlug(), ['admin', 'super_admin', 'owner', 'principal'], true);

        try {
            $this->resourceService->deleteResource((int) $id, $schoolId, $userId, $isAdmin);
            flash('success', 'Resource deleted successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        back();
    }
}
