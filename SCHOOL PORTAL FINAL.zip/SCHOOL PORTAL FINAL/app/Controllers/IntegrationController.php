<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\IntegrationService;
use Core\Controller;

final class IntegrationController extends Controller
{
    /**
     * School Tenant Integration & API Center
     */
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int)$this->schoolId();

        $service = new IntegrationService();
        $apiKeys = $service->getApiKeys($schoolId);
        $webhooks = $service->getWebhooks($schoolId);
        $deliveries = $service->getDeliveries($schoolId, null, 25);

        $this->view('admin/integrations/index', [
            'title' => 'API & Integration Center',
            'api_keys' => $apiKeys,
            'webhooks' => $webhooks,
            'deliveries' => $deliveries
        ]);
    }

    /**
     * Issue a new API Key for the school tenant
     */
    public function storeApiKey(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)$this->userId();

        $name = trim($_POST['name'] ?? 'Mobile App Key');
        $scopes = !empty($_POST['scopes']) && is_array($_POST['scopes']) ? $_POST['scopes'] : ['students.read', 'attendance.read'];
        $rateLimit = max(10, min(1000, (int)($_POST['rate_limit_per_minute'] ?? 60)));

        try {
            $result = (new IntegrationService())->generateApiKey($schoolId, $name, $scopes, $rateLimit, $userId);
            flash('success', "API Key created successfully! Copy this key immediately: <strong>{$result['api_key']}</strong> (It will not be displayed again).");
        } catch (\Throwable $e) {
            flash('error', 'Failed to generate API Key: ' . $e->getMessage());
        }

        redirect(url('admin/integrations'));
    }

    /**
     * Revoke an API Key
     */
    public function revokeApiKey(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();

        $revoked = (new IntegrationService())->revokeApiKey($schoolId, (int)$id);
        if ($revoked) {
            flash('success', 'API Key revoked successfully.');
        } else {
            flash('error', 'API Key not found or unauthorized.');
        }

        redirect(url('admin/integrations'));
    }

    /**
     * Register a new Webhook endpoint
     */
    public function storeWebhook(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();

        $name = trim($_POST['name'] ?? 'Event Webhook');
        $url = trim($_POST['target_url'] ?? '');
        $events = !empty($_POST['events']) && is_array($_POST['events']) ? $_POST['events'] : ['student.admitted', 'fee.paid'];

        try {
            $wh = (new IntegrationService())->registerWebhook($schoolId, $name, $url, $events);
            flash('success', "Webhook endpoint '{$wh['name']}' registered successfully. Secret: <code>{$wh['secret']}</code>");
        } catch (\Throwable $e) {
            flash('error', 'Failed to register webhook: ' . $e->getMessage());
        }

        redirect(url('admin/integrations'));
    }

    /**
     * Test a Webhook endpoint with a simulated test ping
     */
    public function testWebhook(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();

        try {
            $result = (new IntegrationService())->dispatchWebhookEvent($schoolId, 'student.admitted', [
                'test_event' => true,
                'admission_no' => 'TEST-001',
                'student_name' => 'Test Student',
                'message' => 'Simulated test ping payload from School Integration Center'
            ]);

            if ($result['dispatched']) {
                flash('success', "Test webhook event dispatched! Delivery ID: " . ($result['deliveries'][0]['delivery_id'] ?? 'N/A') . ".");
            } else {
                flash('warning', "Dispatch blocked: " . ($result['reason'] ?? 'Unknown reason'));
            }
        } catch (\Throwable $e) {
            flash('error', 'Webhook test failed: ' . $e->getMessage());
        }

        redirect(url('admin/integrations'));
    }

    /**
     * Re-try a failed webhook delivery
     */
    public function retryWebhook(string $deliveryId): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();

        $res = (new IntegrationService())->retryDelivery($schoolId, (int)$deliveryId);
        if ($res['success']) {
            flash('success', $res['message']);
        } else {
            flash('error', $res['message']);
        }

        redirect(url('admin/integrations'));
    }

    /**
     * Delete a webhook endpoint
     */
    public function deleteWebhook(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();

        (new IntegrationService())->deleteWebhook($schoolId, (int)$id);
        flash('success', 'Webhook endpoint deleted successfully.');
        redirect(url('admin/integrations'));
    }
}
