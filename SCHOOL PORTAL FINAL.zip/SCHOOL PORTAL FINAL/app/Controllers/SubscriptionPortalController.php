<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\Platform\BillingService;
use Core\Auth;
use Core\Database;
use Core\TenantContext;

final class SubscriptionPortalController
{
    public function index(): void
    {
        $school = TenantContext::currentSchool();
        if (!$school) {
            flash('error', 'School context not found.');
            redirect(url('login'));
        }

        $planId = $school['plan_id'] ?? null;
        $currentPlan = null;
        if ($planId) {
            $currentPlan = Database::fetch('SELECT * FROM plans WHERE id = ?', [(int) $planId]);
        }

        // Calculate remaining trial or subscription days
        $status = $school['subscription_status'] ?? 'trial';
        $remainingDays = 0;
        $isExpired = false;

        if ($status === 'trial' && !empty($school['trial_ends_at'])) {
            $seconds = strtotime($school['trial_ends_at']) - time();
            $remainingDays = max(0, (int) ceil($seconds / 86400));
            $isExpired = $seconds <= 0 || $status === 'expired';
        } elseif ($status === 'active' && !empty($school['subscription_ends_at'])) {
            $seconds = strtotime($school['subscription_ends_at']) - time();
            $remainingDays = max(0, (int) ceil($seconds / 86400));
            $isExpired = $seconds <= 0;
        } elseif ($status === 'expired') {
            $isExpired = true;
            $remainingDays = 0;
        }

        // Fetch recent subscription invoices for this school
        $invoices = Database::fetchAll(
            'SELECT * FROM subscription_invoices WHERE school_id = ? ORDER BY id DESC LIMIT 10',
            [(int) $school['id']]
        );

        // Fetch student & teacher counts for quota visibility
        $studentCount = (int) (Database::fetch("SELECT COUNT(*) as cnt FROM students WHERE school_id = ? AND (status != 'inactive' OR status IS NULL)", [(int) $school['id']])['cnt'] ?? 0);
        $teacherCount = (int) (Database::fetch("SELECT COUNT(*) as cnt FROM teachers WHERE school_id = ? AND (status != 'inactive' OR status IS NULL)", [(int) $school['id']])['cnt'] ?? 0);

        view('subscription/index', [
            'title' => 'School Subscription & Billing',
            'school' => $school,
            'currentPlan' => $currentPlan,
            'status' => $status,
            'remainingDays' => $remainingDays,
            'isExpired' => $isExpired,
            'invoices' => $invoices,
            'studentCount' => $studentCount,
            'teacherCount' => $teacherCount,
        ]);
    }

    public function plans(): void
    {
        $school = TenantContext::currentSchool();
        $plans = Database::fetchAll('SELECT * FROM plans WHERE status = 1 ORDER BY sort_order ASC, monthly_price ASC');

        // Fetch features mapped to each plan
        foreach ($plans as &$plan) {
            $planFeatures = Database::fetchAll(
                'SELECT f.name, f.slug FROM plan_features pf 
                 JOIN features f ON pf.feature_id = f.id 
                 WHERE pf.plan_id = ? ORDER BY f.id ASC',
                [(int) $plan['id']]
            );
            $plan['features'] = $planFeatures;
        }
        unset($plan);

        view('subscription/plans', [
            'title' => 'Select Subscription Plan',
            'school' => $school,
            'plans' => $plans,
            'currentPlanId' => $school['plan_id'] ?? null,
        ]);
    }

    public function checkout(string $planId): void
    {
        $school = TenantContext::currentSchool();
        $plan = Database::fetch('SELECT * FROM plans WHERE id = ? AND status = 1 LIMIT 1', [(int) $planId]);
        if (!$plan) {
            flash('error', 'Selected subscription plan not found or inactive.');
            redirect(url('subscription/plans'));
        }

        $planFeatures = Database::fetchAll(
            'SELECT f.name, f.slug FROM plan_features pf 
             JOIN features f ON pf.feature_id = f.id 
             WHERE pf.plan_id = ? ORDER BY f.id ASC',
            [(int) $plan['id']]
        );
        $plan['features'] = $planFeatures;

        view('subscription/checkout', [
            'title' => 'Subscription Checkout — ' . $plan['name'],
            'school' => $school,
            'plan' => $plan,
        ]);
    }

    public function processCheckout(): void
    {
        $school = TenantContext::currentSchool();
        if (!$school) {
            flash('error', 'School context not found.');
            redirect(url('login'));
        }

        $planId = (int) ($_POST['plan_id'] ?? 0);
        $billingCycle = ($_POST['billing_cycle'] ?? 'monthly') === 'annual' ? 'annual' : 'monthly';
        $paymentMethod = trim($_POST['payment_method'] ?? 'bank_transfer');
        $transactionRef = trim($_POST['transaction_reference'] ?? '');

        $plan = Database::fetch('SELECT * FROM plans WHERE id = ? AND status = 1 LIMIT 1', [$planId]);
        if (!$plan) {
            flash('error', 'Invalid subscription plan selected.');
            redirect(url('subscription/plans'));
        }

        $price = $billingCycle === 'annual' ? (float) $plan['annual_price'] : (float) $plan['monthly_price'];
        $months = $billingCycle === 'annual' ? 12 : 1;
        $startDate = date('Y-m-d');
        $endDate = date('Y-m-d', strtotime("+{$months} months"));
        $dueDate = date('Y-m-d', strtotime('+3 days'));

        $notes = sprintf(
            'Payment via %s%s',
            strtoupper(str_replace('_', ' ', $paymentMethod)),
            !empty($transactionRef) ? " (Ref: {$transactionRef})" : ''
        );

        $invoiceId = BillingService::createInvoice(
            (int) $school['id'],
            [
                'billing_period_start' => $startDate,
                'billing_period_end' => $endDate,
                'due_date' => $dueDate,
                'discount' => 0.0,
                'tax' => 0.0,
                'notes' => $notes,
            ],
            [
                [
                    'description' => sprintf('%s Plan (%s Subscription - %d Month%s)', $plan['name'], ucfirst($billingCycle), $months, $months > 1 ? 's' : ''),
                    'amount' => $price,
                ],
            ]
        );

        // Update school's target plan if not already set
        Database::execute('UPDATE schools SET plan_id = ?, updated_at = NOW() WHERE id = ?', [$planId, (int) $school['id']]);

        flash('success', "Invoice #{$invoiceId} created successfully. Please follow the payment instructions below to activate or renew your subscription.");
        redirect(url("subscription/invoice/{$invoiceId}"));
    }

    public function invoice(string $id): void
    {
        $schoolId = TenantContext::currentSchoolId();
        $invoice = Database::fetch(
            'SELECT si.*, s.name as school_name, s.code as school_code, s.email as school_email, s.phone as school_phone, s.address as school_address 
             FROM subscription_invoices si 
             JOIN schools s ON si.school_id = s.id 
             WHERE si.id = ? AND si.school_id = ? LIMIT 1',
            [(int) $id, $schoolId]
        );

        if (!$invoice) {
            flash('error', 'Invoice not found or access denied.');
            redirect(url('subscription'));
        }

        $items = Database::fetchAll(
            'SELECT * FROM subscription_invoice_items WHERE invoice_id = ? ORDER BY id ASC',
            [(int) $id]
        );

        $payments = Database::fetchAll(
            'SELECT * FROM subscription_payments WHERE invoice_id = ? ORDER BY id DESC',
            [(int) $id]
        );

        view('subscription/invoice', [
            'title' => 'Invoice ' . $invoice['invoice_no'],
            'invoice' => $invoice,
            'items' => $items,
            'payments' => $payments,
        ]);
    }
}
