<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\CSRF;
use Core\Database;
use Core\Validator;

final class AuthController extends Controller
{
    public function showLogin(): void
    {
        $this->view('auth/login', [
            'title' => 'Sign In',
            'blocked' => $_SESSION['blocked_school'] ?? null,
        ], 'layouts/guest');
        unset($_SESSION['blocked_school']);
    }

    public function showTenantLogin(string $schoolCode): void
    {
        $_SESSION['login_school_code'] = strtoupper($schoolCode);
        redirect(url('login?school=' . urlencode(strtoupper($schoolCode))));
    }

    public function login(): void
    {
        $this->requireCsrf();

        $email = trim((string)($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $errors = [];

        if ($email === '') {
            $errors['email'] = 'Email is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email address.';
        }

        if ($password === '') {
            $errors['password'] = 'Password is required.';
        }

        if (!empty($errors)) {
            flash('errors', $errors);
            flash('error', reset($errors));
            flash('old', ['email' => $email]);
            redirect(url('login'));
            return;
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

        // Whitelist loopback and private development IPs from being blocked
        $isLoopback = in_array($ip, ['127.0.0.1', '::1', 'localhost', '0.0.0.0'], true)
            || str_starts_with($ip, '192.168.')
            || str_starts_with($ip, '10.')
            || str_starts_with($ip, '172.16.');

        // FIREWALL INTERCEPTOR: Check block state (only for non-loopback IPs)
        if (!$isLoopback) {
            \Core\Database::execute("
                CREATE TABLE IF NOT EXISTS platform_blocked_ips (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ip_address VARCHAR(45) NOT NULL,
                    is_blacklisted TINYINT(1) NOT NULL DEFAULT 1,
                    reason VARCHAR(255) NULL,
                    created_at DATETIME NOT NULL,
                    UNIQUE KEY uk_ip (ip_address)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            \Core\Database::execute("
                CREATE TABLE IF NOT EXISTS platform_firewall_logs (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    school_id INT NULL,
                    user_id INT NULL,
                    ip_address VARCHAR(45) NOT NULL,
                    attempted_email VARCHAR(150) NULL,
                    event_type VARCHAR(50) NOT NULL,
                    severity VARCHAR(20) NOT NULL DEFAULT 'Low',
                    user_agent VARCHAR(255) NULL,
                    created_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            $blocked = \Core\Database::fetch('SELECT id, is_blacklisted FROM platform_blocked_ips WHERE ip_address = ? AND is_blacklisted = 1 LIMIT 1', [$ip]);
            if ($blocked) {
                http_response_code(403);
                die('403 Forbidden - Your IP address has been permanently blocked by the system firewall.');
            }
        }

        if (\Core\PlatformAuth::attempt($email, $password)) {
            flash('success', 'Welcome to the platform console.');
            redirect(url('superadmin/dashboard'));
            return;
        }

        $schoolCode = !empty($_POST['school_code']) ? (string)$_POST['school_code'] : null;
        $ok = Auth::attempt($email, $password, !empty($_POST['remember']), $schoolCode);
        if (!$ok) {
            // FIREWALL: Log failed attempt & trigger brute force detector for non-loopback
            if (!$isLoopback) {
                \Core\Database::insert(
                    "INSERT INTO platform_firewall_logs (ip_address, attempted_email, event_type, severity, user_agent, created_at)
                     VALUES (?, ?, 'failed_login', 'Warning', ?, NOW())",
                    [$ip, $email, $ua]
                );

                $recentFails = \Core\Database::fetch(
                    "SELECT COUNT(*) AS c FROM platform_firewall_logs 
                     WHERE ip_address = ? AND event_type = 'failed_login' 
                     AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
                    [$ip]
                );

                if (($recentFails['c'] ?? 0) >= 5) {
                    \Core\Database::insert(
                        "INSERT IGNORE INTO platform_blocked_ips (ip_address, is_blacklisted, reason, created_at)
                         VALUES (?, 1, 'Auto-blocked: Brute-force detection', NOW())",
                        [$ip]
                    );
                }
            }

            $err = 'Invalid credentials.';
            $field = null;
            if (!empty($_SESSION['login_error'])) {
                $err = $_SESSION['login_error'];
                $field = $_SESSION['login_error_field'] ?? null;
                unset($_SESSION['login_error'], $_SESSION['login_error_field']);
            } elseif (!empty($_SESSION['blocked_school'])) {
                $err = 'Your school\'s subscription is currently inactive. Please renew or contact support.';
            }

            flash('error', $err);
            if ($field) {
                flash('errors', [$field => $err]);
            }
            flash('old', ['email' => $email]);
            redirect(url('login'));
            return;
        }

        flash('success', 'Welcome back, ' . (Auth::user()['name'] ?? '') . '!');
        $role = Auth::roleSlug();
        $targetPortal = match ($role) {
            'super_admin' => 'superadmin/dashboard',
            'principal', 'academic_manager' => 'principal/dashboard',
            'teacher' => 'teacher/dashboard',
            'accountant', 'finance' => 'accountant/dashboard',
            'hr', 'hr_manager' => 'hr/dashboard',
            'parent' => 'parent/dashboard',
            'student' => 'student/dashboard',
            default => 'dashboard',
        };
        redirect(url($targetPortal));
    }

    public function logout(): void
    {
        Auth::logout();
        flash('success', 'You have been logged out.');
        redirect(url('login'));
    }

    public function showForgot(): void
    {
        $this->view('auth/forgot', ['title' => 'Forgot Password'], 'layouts/guest');
    }

    public function sendReset(): void
    {
        $this->requireCsrf();
        $data = $this->validate($_POST, ['email' => 'required|email']);
        $email = strtolower(trim($data['email']));
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        // Rate limit: max 5 requests per 15 minutes per IP or email
        $recentResets = Database::fetch(
            'SELECT COUNT(*) AS c FROM password_resets WHERE (email = ? OR ip_address = ?) AND created_at > (NOW() - INTERVAL 15 MINUTE)',
            [$email, $ip]
        );
        if (((int)($recentResets['c'] ?? 0)) >= 5) {
            flash('error', 'Too many password reset requests. Please wait 15 minutes before trying again.');
            redirect(url('forgot-password'));
            return;
        }

        $user = Database::fetch(
            'SELECT id, school_id, email FROM users WHERE email = ? AND status = 1 LIMIT 1',
            [$email]
        );

        // Always show success to avoid account enumeration
        if ($user) {
            $token = bin2hex(random_bytes(32));
            Database::insert(
                'INSERT INTO password_resets (school_id, email, ip_address, token_hash, expires_at, created_at)
                 VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR), NOW())',
                [(int) $user['school_id'], $email, $ip, hash('sha256', $token)]
            );
            // In production, email the link. For local/dev we surface it once via flash.
            if (app_config('debug')) {
                flash('success', 'Password reset link (dev): ' . url('reset-password?token=' . $token . '&email=' . urlencode($email)));
            } else {
                flash('success', 'If the account exists, a reset link has been sent.');
            }
        } else {
            flash('success', 'If the account exists, a reset link has been sent.');
        }

        redirect(url('forgot-password'));
    }

    public function showReset(): void
    {
        $this->view('auth/reset', [
            'title' => 'Reset Password',
            'token' => $_GET['token'] ?? '',
            'email' => $_GET['email'] ?? '',
        ], 'layouts/guest');
    }

    public function resetPassword(): void
    {
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'email' => 'required|email',
            'token' => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        $email = strtolower(trim($data['email']));

        $row = Database::fetch(
            'SELECT * FROM password_resets
             WHERE email = ? AND used_at IS NULL AND expires_at > NOW()
             ORDER BY id DESC LIMIT 1',
            [$email]
        );

        if (!$row || !hash_equals($row['token_hash'], hash('sha256', $data['token']))) {
            flash('error', 'Invalid or expired reset token.');
            redirect(url('forgot-password'));
            return;
        }

        // Validate password against tenant security policy
        $policy = (new \App\Services\SecurityService())->validatePasswordPolicy((int)$row['school_id'], $data['password']);
        if (!($policy['valid'] ?? false)) {
            flash('error', $policy['errors'][0] ?? 'Password does not satisfy complexity requirements.');
            flash('old', ['email' => $data['email']]);
            redirect(url('reset-password?token=' . urlencode($data['token']) . '&email=' . urlencode($data['email'])));
            return;
        }

        $user = Database::fetch(
            'SELECT id, school_id FROM users WHERE email = ? AND school_id = ? LIMIT 1',
            [$email, (int)$row['school_id']]
        );

        Database::beginTransaction();
        try {
            Database::execute(
                'UPDATE users SET password = ?, updated_at = NOW() WHERE email = ? AND school_id = ?',
                [password_hash($data['password'], PASSWORD_DEFAULT), $email, (int) $row['school_id']]
            );

            // Invalidate all pending reset tokens for this email
            Database::execute(
                'UPDATE password_resets SET used_at = NOW() WHERE email = ? AND school_id = ? AND used_at IS NULL',
                [$email, (int) $row['school_id']]
            );

            // Invalidate all existing remember tokens across any device/session
            if ($user) {
                Database::execute(
                    'DELETE FROM remember_tokens WHERE user_id = ? AND school_id = ?',
                    [(int)$user['id'], (int)$row['school_id']]
                );
            }

            Database::commit();

            \App\Helpers\Audit::log(
                'password.reset',
                'auth',
                'user',
                $user ? (int)$user['id'] : null,
                null,
                ['email' => $email],
                (int) $row['school_id']
            );
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }

        flash('success', 'Password updated successfully. Please log in with your new password.');
        redirect(url('login'));
    }
}
