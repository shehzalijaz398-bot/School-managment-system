<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\BillingService;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformReportController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('reports.view');
        
        $this->view('platform/reports/index', [
            'title' => 'SaaS Reports & Analytics',
        ], 'platform/layouts/app');
    }
    
    private function parseDateRange(): array
    {
        $range = $_GET['range'] ?? '30d';
        $end = date('Y-m-d 23:59:59');
        
        switch ($range) {
            case 'today': $start = date('Y-m-d 00:00:00'); break;
            case '7d': $start = date('Y-m-d 00:00:00', strtotime('-7 days')); break;
            case '30d': $start = date('Y-m-d 00:00:00', strtotime('-30 days')); break;
            case '3m': $start = date('Y-m-d 00:00:00', strtotime('-3 months')); break;
            case '6m': $start = date('Y-m-d 00:00:00', strtotime('-6 months')); break;
            case '12m': $start = date('Y-m-d 00:00:00', strtotime('-12 months')); break;
            case 'custom':
                $start = ($_GET['start'] ?? date('Y-m-d')) . ' 00:00:00';
                $end = ($_GET['end'] ?? date('Y-m-d')) . ' 23:59:59';
                break;
            default: $start = date('Y-m-d 00:00:00', strtotime('-30 days')); break;
        }
        
        // Previous period for comparison
        $diff = strtotime($end) - strtotime($start);
        $prevEnd = date('Y-m-d H:i:s', strtotime($start) - 1);
        $prevStart = date('Y-m-d H:i:s', strtotime($prevEnd) - $diff);
        
        return [$start, $end, $prevStart, $prevEnd];
    }

    public function data(): void
    {
        PlatformAuth::requirePermission('reports.view');
        header('Content-Type: application/json');
        
        [$start, $end, $prevStart, $prevEnd] = $this->parseDateRange();

        // 1. Schools Overview
        $totalSchools = (int) (Database::fetch('SELECT COUNT(id) AS c FROM schools WHERE deleted_at IS NULL')['c'] ?? 0);
        $activeSchools = (int) (Database::fetch('SELECT COUNT(id) AS c FROM schools WHERE status = 1 AND deleted_at IS NULL')['c'] ?? 0);
        
        $newSchools = (int) (Database::fetch('SELECT COUNT(id) AS c FROM schools WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL', [$start, $end])['c'] ?? 0);
        $newSchoolsPrev = (int) (Database::fetch('SELECT COUNT(id) AS c FROM schools WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL', [$prevStart, $prevEnd])['c'] ?? 0);
        
        // 2. Financials
        $revenue = (float) (Database::fetch('SELECT SUM(amount) AS c FROM subscription_payments WHERE payment_status="paid" AND paid_at BETWEEN ? AND ?', [$start, $end])['c'] ?? 0);
        $revenuePrev = (float) (Database::fetch('SELECT SUM(amount) AS c FROM subscription_payments WHERE payment_status="paid" AND paid_at BETWEEN ? AND ?', [$prevStart, $prevEnd])['c'] ?? 0);
        
        $mrr = (float) (Database::fetch('SELECT SUM(amount) AS c FROM subscription_payments WHERE payment_status="paid" AND MONTH(paid_at) = MONTH(CURRENT_DATE()) AND YEAR(paid_at) = YEAR(CURRENT_DATE())')['c'] ?? 0);
        $arr = $mrr * 12;

        // Revenue by Plan
        $revByPlan = Database::fetchAll(
            'SELECT p.name, SUM(sp.amount) AS total 
             FROM subscription_payments sp
             INNER JOIN subscription_invoices si ON si.id = sp.invoice_id
             INNER JOIN schools s ON s.id = sp.school_id
             LEFT JOIN plans p ON p.id = s.plan_id
             WHERE sp.payment_status="paid" AND sp.paid_at BETWEEN ? AND ?
             GROUP BY p.name ORDER BY total DESC',
            [$start, $end]
        );

        // Revenue Trend (Daily or Monthly depending on range)
        $trendFormat = (strtotime($end) - strtotime($start) > 60*24*3600) ? '%Y-%m' : '%Y-%m-%d';
        $revTrend = Database::fetchAll(
            'SELECT DATE_FORMAT(paid_at, ?) AS label, SUM(amount) AS total 
             FROM subscription_payments WHERE payment_status="paid" AND paid_at BETWEEN ? AND ?
             GROUP BY label ORDER BY label',
            [$trendFormat, $start, $end]
        );

        // School Growth
        $schoolTrend = Database::fetchAll(
            'SELECT DATE_FORMAT(created_at, ?) AS label, COUNT(id) AS total 
             FROM schools WHERE deleted_at IS NULL AND created_at BETWEEN ? AND ?
             GROUP BY label ORDER BY label',
            [$trendFormat, $start, $end]
        );

        // Subscriptions
        $planDist = Database::fetchAll(
            'SELECT p.name, COUNT(s.id) AS total FROM plans p
             LEFT JOIN schools s ON s.plan_id = p.id AND s.status=1 AND s.deleted_at IS NULL
             GROUP BY p.id, p.name ORDER BY total DESC'
        );
        
        echo json_encode([
            'overview' => [
                'total_schools' => $totalSchools,
                'active_schools' => $activeSchools,
                'new_schools' => $newSchools,
                'new_schools_growth' => $this->calcGrowth($newSchools, $newSchoolsPrev),
                'revenue' => $revenue,
                'revenue_growth' => $this->calcGrowth($revenue, $revenuePrev),
                'mrr' => $mrr,
                'arr' => $arr,
            ],
            'charts' => [
                'revenue_trend' => $this->formatChartData($revTrend),
                'school_growth' => $this->formatChartData($schoolTrend),
                'plan_distribution' => $this->formatChartData($planDist, true),
                'revenue_by_plan' => $this->formatChartData($revByPlan, true),
            ]
        ]);
    }
    
    public function export(): void
    {
        PlatformAuth::requirePermission('reports.view');
        [$start, $end] = $this->parseDateRange();
        $type = $_GET['type'] ?? 'revenue';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="export_'.$type.'_'.date('Ymd').'.csv"');
        $out = fopen('php://output', 'w');
        
        if ($type === 'revenue') {
            fputcsv($out, ['Payment ID', 'School', 'Invoice No', 'Amount', 'Method', 'Status', 'Paid At']);
            $data = Database::fetchAll(
                'SELECT p.id, s.name as school, i.invoice_no, p.amount, p.payment_method, p.payment_status, p.paid_at 
                 FROM subscription_payments p
                 INNER JOIN schools s ON s.id = p.school_id
                 INNER JOIN subscription_invoices i ON i.id = p.invoice_id
                 WHERE p.paid_at BETWEEN ? AND ? ORDER BY p.paid_at DESC',
                [$start, $end]
            );
            foreach($data as $row) fputcsv($out, $row);
        } elseif ($type === 'schools') {
            fputcsv($out, ['School ID', 'Name', 'Status', 'Plan', 'Created At']);
            $data = Database::fetchAll(
                'SELECT s.id, s.name, s.status, p.name as plan, s.created_at 
                 FROM schools s
                 LEFT JOIN plans p ON p.id = s.plan_id
                 WHERE s.created_at BETWEEN ? AND ? ORDER BY s.created_at DESC',
                [$start, $end]
            );
            foreach($data as $row) fputcsv($out, $row);
        }
        
        fclose($out);
        exit;
    }
    
    private function calcGrowth(float|int $current, float|int $prev): float
    {
        if ($prev == 0) return $current > 0 ? 100.0 : 0.0;
        return round((($current - $prev) / $prev) * 100, 1);
    }
    
    private function formatChartData(array $data, bool $isPie = false): array
    {
        $labels = [];
        $values = [];
        foreach($data as $d) {
            $keys = array_keys($d);
            $labels[] = $d[$keys[0]] ?? 'Unknown';
            $values[] = (float)($d[$keys[1]] ?? 0);
        }
        return ['labels' => $labels, 'values' => $values];
    }
}
