<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformSettingController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        
        $rows = Database::fetchAll('SELECT * FROM platform_settings');
        $settings = [];
        foreach ($rows as $r) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }
        
        $this->view('platform/settings/index', [
            'title' => 'Platform Settings',
            'settings' => $settings,
        ], 'platform/layouts/app');
    }

    public function save(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $before = [];
        $after = [];
        
        $existingRows = Database::fetchAll('SELECT * FROM platform_settings');
        $existingMap = [];
        foreach ($existingRows as $r) {
            $existingMap[$r['setting_key']] = $r;
        }

        foreach ($_POST as $key => $value) {
            if ($key === 'csrf_token' || $key === '_method') {
                continue;
            }
            
            // Handle boolean toggles appropriately
            if (is_array($value)) {
                $value = json_encode($value);
            } else {
                $value = (string) $value;
            }

            if (isset($existingMap[$key])) {
                if ($existingMap[$key]['setting_value'] !== $value) {
                    $before[$key] = $existingMap[$key]['setting_value'];
                    $after[$key] = $value;
                    Database::execute('UPDATE platform_settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$value, (int) $existingMap[$key]['id']]);
                }
            } else {
                $before[$key] = null;
                $after[$key] = $value;
                Database::insert(
                    'INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())',
                    [$key, $value]
                );
            }
        }
        
        // Handle un-checked checkboxes which don't send POST data
        $checkboxKeys = [
            'reg_enabled', 'reg_approval_req', 'reg_email_verif_req', 'reg_doc_verif_req',
            'tax_enabled', 'notif_inapp', 'notif_email', 'notif_sms', 'notif_whatsapp',
            'sec_force_2fa', 'maint_mode', 'maint_allow_admin'
        ];
        
        foreach ($checkboxKeys as $chk) {
            if (!isset($_POST[$chk])) {
                $value = '0';
                if (isset($existingMap[$chk]) && $existingMap[$chk]['setting_value'] !== $value) {
                    $before[$chk] = $existingMap[$chk]['setting_value'];
                    $after[$chk] = $value;
                    Database::execute('UPDATE platform_settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$value, (int) $existingMap[$chk]['id']]);
                } elseif (!isset($existingMap[$chk])) {
                    $before[$chk] = null;
                    $after[$chk] = $value;
                    Database::insert('INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())', [$chk, $value]);
                }
            }
        }

        if (!empty($after)) {
            // Mask sensitive data in audit logs
            $auditBefore = $before;
            $auditAfter = $after;
            $sensitiveKeys = ['smtp_password', 'stripe_secret', 'aws_secret_access_key'];
            foreach ($sensitiveKeys as $sk) {
                if (isset($auditBefore[$sk]) && !empty($auditBefore[$sk])) $auditBefore[$sk] = '********';
                if (isset($auditAfter[$sk]) && !empty($auditAfter[$sk])) $auditAfter[$sk] = '********';
            }
            
            PlatformAudit::log('settings.update', 'platform_settings', null, 'settings', 0, $auditBefore, $auditAfter);
        }
        
        flash('success', 'Platform settings successfully saved.');
        redirect(url('superadmin/settings'));
    }

    public function manageLanguages(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        
        \Core\Language::init();
        $languages = Database::fetchAll("SELECT * FROM system_languages ORDER BY id ASC");
        $translations = Database::fetchAll("SELECT * FROM system_translations ORDER BY locale_code ASC, translation_key ASC");
        
        $this->view('platform/settings/localization', [
            'title' => 'Global Localization & Language Matrix',
            'languages' => $languages,
            'translations' => $translations
        ], 'platform/layouts/app');
    }

    public function saveTranslations(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $locale = $_POST['locale_code'] ?? '';
        $key = $_POST['translation_key'] ?? '';
        $value = $_POST['translated_value'] ?? '';
        
        if (!$locale || !$key || !$value) {
            flash('error', 'Locale, Key, and Value are strictly required.');
            redirect(url('superadmin/settings/languages'));
            return;
        }

        $check = Database::fetch("SELECT id FROM system_translations WHERE locale_code = ? AND translation_key = ?", [$locale, $key]);
        if ($check) {
            Database::execute("UPDATE system_translations SET translated_value = ?, updated_at = NOW() WHERE id = ?", [$value, $check['id']]);
            flash('success', 'Translation securely updated.');
        } else {
            Database::insert("INSERT INTO system_translations (locale_code, translation_key, translated_value, updated_at) VALUES (?, ?, ?, NOW())", [$locale, $key, $value]);
            flash('success', 'Translation securely bound.');
        }

        redirect(url('superadmin/settings/languages'));
    }
}
