<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformDeveloperController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_api_keys (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NULL,
                name VARCHAR(100) NOT NULL,
                token_hash VARCHAR(128) NOT NULL,
                token_prefix VARCHAR(10) NOT NULL,
                scopes JSON NULL,
                status TINYINT(1) DEFAULT 1,
                expires_at DATETIME NULL,
                last_used_at DATETIME NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_webhooks (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NULL,
                url VARCHAR(500) NOT NULL,
                secret VARCHAR(128) NOT NULL,
                events JSON NULL,
                status TINYINT(1) DEFAULT 1,
                last_delivery_at DATETIME NULL,
                last_response_code INT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_oauth_clients (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NULL,
                name VARCHAR(100) NOT NULL,
                client_id VARCHAR(64) NOT NULL UNIQUE,
                client_secret_hash VARCHAR(128) NOT NULL,
                redirect_uris JSON NULL,
                status TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $apiKeys = Database::fetchAll("
            SELECT k.*, s.name as school_name 
            FROM platform_api_keys k 
            LEFT JOIN schools s ON s.id = k.school_id 
            ORDER BY k.created_at DESC
        ");

        $webhooks = Database::fetchAll("
            SELECT w.*, s.name as school_name 
            FROM platform_webhooks w 
            LEFT JOIN schools s ON s.id = w.school_id 
            ORDER BY w.created_at DESC
        ");

        $oauthClients = Database::fetchAll("
            SELECT c.*, s.name as school_name 
            FROM platform_oauth_clients c 
            LEFT JOIN schools s ON s.id = c.school_id 
            ORDER BY c.created_at DESC
        ");

        $schools = Database::fetchAll("SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name ASC");

        $this->view('platform/developer/index', [
            'title' => 'API & Developer Center',
            'apiKeys' => $apiKeys,
            'webhooks' => $webhooks,
            'oauthClients' => $oauthClients,
            'schools' => $schools
        ], 'platform/layouts/app');
    }

    public function createApiKey(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $name = trim($_POST['name'] ?? '');
        $schoolId = !empty($_POST['school_id']) ? (int) $_POST['school_id'] : null;
        $scopes = !empty($_POST['scopes']) ? json_encode(array_values((array) $_POST['scopes'])) : json_encode(['*']);
        $expiresAt = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;

        if (empty($name)) {
            flash('error', 'API Key name is required.');
            redirect(url('superadmin/developer'));
        }

        // Generate raw token
        $rawToken = bin2hex(random_bytes(32));
        $prefix = substr($rawToken, 0, 8);
        $tokenHash = hash('sha256', $rawToken);

        Database::insert("
            INSERT INTO platform_api_keys (school_id, name, token_hash, token_prefix, scopes, status, expires_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?, NOW(), NOW())
        ", [$schoolId, $name, $tokenHash, $prefix, $scopes, $expiresAt]);

        $id = Database::lastInsertId();

        PlatformAudit::log('api_key.created', 'platform_api_keys', $schoolId, 'api_key', $id, null, ['name' => $name, 'scopes' => $scopes]);

        // Flash raw token ONLY ONCE.
        $_SESSION['flash_api_key'] = $rawToken;
        
        flash('success', 'API Key created successfully.');
        redirect(url('superadmin/developer'));
    }

    public function revokeApiKey(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $key = Database::fetch('SELECT school_id FROM platform_api_keys WHERE id = ?', [(int)$id]);
        if ($key) {
            Database::execute("UPDATE platform_api_keys SET status = 0, updated_at = NOW() WHERE id = ?", [(int)$id]);
            PlatformAudit::log('api_key.revoked', 'platform_api_keys', (int)$key['school_id'], 'api_key', (int)$id);
            flash('success', 'API Key revoked.');
        }
        redirect(url('superadmin/developer'));
    }

    public function createWebhook(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $url = trim($_POST['url'] ?? '');
        $schoolId = !empty($_POST['school_id']) ? (int) $_POST['school_id'] : null;
        $events = !empty($_POST['events']) ? json_encode(array_values((array) $_POST['events'])) : json_encode(['*']);

        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            flash('error', 'Valid Webhook URL is required.');
            redirect(url('superadmin/developer'));
        }

        $secret = 'whsec_' . bin2hex(random_bytes(24));

        Database::insert("
            INSERT INTO platform_webhooks (school_id, url, secret, events, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, NOW(), NOW())
        ", [$schoolId, $url, $secret, $events]);

        $id = Database::lastInsertId();

        PlatformAudit::log('webhook.created', 'platform_webhooks', $schoolId, 'webhook', $id, null, ['url' => $url]);
        
        $_SESSION['flash_webhook_secret'] = $secret;
        
        flash('success', 'Webhook endpoint registered successfully.');
        redirect(url('superadmin/developer'));
    }

    public function toggleWebhook(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $webhook = Database::fetch('SELECT status, school_id FROM platform_webhooks WHERE id = ?', [(int)$id]);
        if ($webhook) {
            $newStatus = $webhook['status'] == 1 ? 0 : 1;
            Database::execute("UPDATE platform_webhooks SET status = ?, updated_at = NOW() WHERE id = ?", [$newStatus, (int)$id]);
            PlatformAudit::log('webhook.toggled', 'platform_webhooks', (int)$webhook['school_id'], 'webhook', (int)$id, null, ['new_status' => $newStatus]);
            flash('success', 'Webhook status updated.');
        }
        redirect(url('superadmin/developer'));
    }
    
    public function pingWebhook(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $webhook = Database::fetch('SELECT id, school_id FROM platform_webhooks WHERE id = ?', [(int)$id]);
        if ($webhook) {
            // Mock delivery
            $code = 200;
            Database::execute("UPDATE platform_webhooks SET last_delivery_at = NOW(), last_response_code = ? WHERE id = ?", [$code, (int)$id]);
            PlatformAudit::log('webhook.ping', 'platform_webhooks', (int)$webhook['school_id'], 'webhook', (int)$id, null, ['code' => $code]);
            flash('success', 'Webhook ping simulated. Status: 200 OK');
        }
        redirect(url('superadmin/developer'));
    }

    public function createOauthClient(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $name = trim($_POST['name'] ?? '');
        $schoolId = !empty($_POST['school_id']) ? (int) $_POST['school_id'] : null;
        $uris = trim($_POST['redirect_uris'] ?? '');
        
        if (empty($name)) {
            flash('error', 'OAuth Client name is required.');
            redirect(url('superadmin/developer'));
        }

        $redirectUris = array_filter(array_map('trim', explode(',', $uris)));
        
        $clientId = bin2hex(random_bytes(16));
        $clientSecret = bin2hex(random_bytes(32));
        $secretHash = password_hash($clientSecret, PASSWORD_DEFAULT);

        Database::insert("
            INSERT INTO platform_oauth_clients (school_id, name, client_id, client_secret_hash, redirect_uris, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())
        ", [$schoolId, $name, $clientId, $secretHash, json_encode(array_values($redirectUris))]);

        $id = Database::lastInsertId();
        PlatformAudit::log('oauth_client.created', 'platform_oauth_clients', $schoolId, 'oauth_client', $id, null, ['name' => $name]);

        $_SESSION['flash_oauth'] = [
            'client_id' => $clientId,
            'client_secret' => $clientSecret
        ];
        
        flash('success', 'OAuth Client registered.');
        redirect(url('superadmin/developer'));
    }

    public function toggleOauthClient(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $client = Database::fetch('SELECT status, school_id FROM platform_oauth_clients WHERE id = ?', [(int)$id]);
        if ($client) {
            $newStatus = $client['status'] == 1 ? 0 : 1;
            Database::execute("UPDATE platform_oauth_clients SET status = ?, updated_at = NOW() WHERE id = ?", [$newStatus, (int)$id]);
            PlatformAudit::log('oauth_client.toggled', 'platform_oauth_clients', (int)$client['school_id'], 'oauth_client', (int)$id, null, ['new_status' => $newStatus]);
            flash('success', 'OAuth Client status updated.');
        }
        redirect(url('superadmin/developer'));
    }
}
