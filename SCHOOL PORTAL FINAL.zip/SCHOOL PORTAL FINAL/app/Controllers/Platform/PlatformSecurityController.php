<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformSecurityController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_security_ips (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                ip_address VARCHAR(45) NOT NULL,
                type VARCHAR(20) NOT NULL DEFAULT 'blocked', -- 'blocked' or 'whitelist'
                reason TEXT NULL,
                created_by BIGINT UNSIGNED NULL,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        try { Database::execute("ALTER TABLE platform_audit_logs ADD COLUMN severity VARCHAR(30) DEFAULT 'info'"); } catch (\Throwable $e) {}
        
        // Add 2FA support if missing
        try { Database::execute("ALTER TABLE platform_users ADD COLUMN two_factor_secret VARCHAR(255) NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE platform_users ADD COLUMN two_factor_enabled TINYINT(1) DEFAULT 0"); } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage'); // Or a specific security perm
        $this->checkSchema();

        $analytics = [
            'failed_logins' => (int) (Database::fetch("SELECT COUNT(id) as c FROM platform_audit_logs WHERE action = 'auth.login_failed' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")['c'] ?? 0),
            'critical_alerts' => (int) (Database::fetch("SELECT COUNT(id) as c FROM platform_audit_logs WHERE severity = 'critical' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")['c'] ?? 0),
            'blocked_ips' => (int) (Database::fetch("SELECT COUNT(id) as c FROM platform_security_ips WHERE type = 'blocked'")['c'] ?? 0),
            '2fa_enabled' => (int) (Database::fetch("SELECT COUNT(id) as c FROM platform_users WHERE two_factor_enabled = 1")['c'] ?? 0)
        ];

        // Fetch recent active sessions (simulated via recent login audit logs)
        $activeSessions = Database::fetchAll("
            SELECT a.actor_id, a.ip_address, a.user_agent, a.created_at, u.name, COALESCE(r.name, 'Admin') AS role
            FROM platform_audit_logs a
            JOIN platform_users u ON u.id = a.actor_id
            LEFT JOIN platform_roles r ON r.id = u.role_id
            WHERE a.action = 'auth.login' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 12 HOUR)
            ORDER BY a.created_at DESC LIMIT 20
        ");

        // Fetch Alerts
        $alerts = Database::fetchAll("
            SELECT * FROM platform_audit_logs 
            WHERE severity IN ('critical', 'high') 
            ORDER BY created_at DESC LIMIT 50
        ");

        // Fetch IPs
        $ips = Database::fetchAll("SELECT * FROM platform_security_ips ORDER BY created_at DESC");

        // System Health (Static checks simulation)
        $health = [
            'https' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
            'php_version' => PHP_VERSION,
            'db_connection' => 'Secure',
            'debug_mode' => getenv('APP_DEBUG') === 'true'
        ];

        $this->view('platform/security/index', [
            'title' => 'Security Center',
            'analytics' => $analytics,
            'activeSessions' => $activeSessions,
            'alerts' => $alerts,
            'ips' => $ips,
            'health' => $health
        ], 'platform/layouts/app');
    }

    public function addIp(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $ip = trim($_POST['ip_address'] ?? '');
        $type = $_POST['type'] ?? 'blocked';
        $reason = trim($_POST['reason'] ?? '');

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            flash('error', 'Invalid IP Address format.');
            redirect(url('superadmin/security'));
        }

        Database::insert(
            "INSERT INTO platform_security_ips (ip_address, type, reason, created_by, created_at) VALUES (?, ?, ?, ?, NOW())",
            [$ip, $type, $reason, PlatformAuth::id()]
        );

        PlatformAudit::log('security.ip_added', 'platform_security_ips', null, 'ip', 0, null, ['ip' => $ip, 'type' => $type]);
        
        flash('success', 'IP address has been ' . ($type === 'blocked' ? 'blocked' : 'whitelisted') . '.');
        redirect(url('superadmin/security'));
    }

    public function removeIp(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $ip = Database::fetch("SELECT * FROM platform_security_ips WHERE id = ?", [(int) $id]);
        if ($ip) {
            Database::execute("DELETE FROM platform_security_ips WHERE id = ?", [(int) $id]);
            PlatformAudit::log('security.ip_removed', 'platform_security_ips', null, 'ip', (int) $id, null, ['ip' => $ip['ip_address']]);
        }
        
        flash('success', 'IP address removed from lists.');
        redirect(url('superadmin/security'));
    }

    public function emergency(string $action): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        if ($action === 'lock_all') {
            Database::execute("UPDATE platform_users SET status = 0 WHERE id != ?", [PlatformAuth::id()]);
            PlatformAudit::log('security.emergency_lock', 'platform_users', null, 'system', 0, null, ['action' => 'Locked all platform users except current.']);
            flash('success', 'EMERGENCY: All other platform accounts have been locked.');
        } elseif ($action === 'maintenance') {
            $exists = Database::fetch('SELECT id FROM platform_settings WHERE setting_key = "maint_mode"');
            if ($exists) {
                Database::execute('UPDATE platform_settings SET setting_value = "1", updated_at = NOW() WHERE id = ?', [(int) $exists['id']]);
            } else {
                Database::insert('INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES ("maint_mode", "1", NOW(), NOW())');
            }
            PlatformAudit::log('security.emergency_maintenance', 'platform_settings');
            flash('success', 'EMERGENCY: Platform is now in Maintenance Mode.');
        }
        
        redirect(url('superadmin/security'));
    }

    public function firewallIndex(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        
        $failedLogins = Database::fetch("SELECT COUNT(*) as c FROM platform_firewall_logs WHERE event_type = 'failed_login' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")['c'] ?? 0;
        $blockedIps = Database::fetch("SELECT COUNT(*) as c FROM platform_blocked_ips WHERE is_blacklisted = 1")['c'] ?? 0;
        $warnings = Database::fetch("SELECT COUNT(*) as c FROM platform_firewall_logs WHERE severity IN ('Warning', 'Critical')")['c'] ?? 0;
        
        $logs = Database::fetchAll("SELECT * FROM platform_firewall_logs ORDER BY created_at DESC LIMIT 50");
        $blocked = Database::fetchAll("SELECT * FROM platform_blocked_ips ORDER BY created_at DESC");

        $this->view('platform/security_center', [
            'title' => 'Automated Security Center',
            'failedLogins' => $failedLogins,
            'blockedIps' => $blockedIps,
            'warnings' => $warnings,
            'logs' => $logs,
            'blocked' => $blocked,
        ], 'layouts/platform');
    }

    public function toggleIpStatus(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $ip = trim($_POST['ip_address'] ?? '');
        $action = $_POST['action'] ?? 'block';
        
        if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
            flash('error', 'Invalid IP address format.');
            redirect(url('superadmin/security/firewall'));
            return;
        }

        if ($action === 'block') {
            Database::execute("
                INSERT INTO platform_blocked_ips (ip_address, is_blacklisted, reason, created_at)
                VALUES (?, 1, 'Manual admin block via Security Center', NOW())
                ON DUPLICATE KEY UPDATE is_blacklisted = 1, reason = 'Manual admin block via Security Center', created_at = NOW()
            ", [$ip]);
            
            Database::insert(
                "INSERT INTO platform_firewall_logs (ip_address, event_type, severity, user_agent, created_at)
                 VALUES (?, 'manual_blacklist', 'Critical', 'System Admin', NOW())",
                [$ip]
            );
            
            flash('success', "IP {$ip} has been instantly blacklisted.");
        } else {
            Database::execute("UPDATE platform_blocked_ips SET is_blacklisted = 0 WHERE ip_address = ?", [$ip]);
            
            Database::insert(
                "INSERT INTO platform_firewall_logs (ip_address, event_type, severity, user_agent, created_at)
                 VALUES (?, 'manual_whitelist', 'Info', 'System Admin', NOW())",
                [$ip]
            );
            
            flash('success', "IP {$ip} has been whitelisted.");
        }

        redirect(url('superadmin/security/firewall'));
    }

    public function triggerEmergencyLockdown(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $sessionDir = session_save_path();
        if (empty($sessionDir)) {
            $sessionDir = sys_get_temp_dir();
        }

        $currentSessionId = session_id();
        
        $files = glob($sessionDir . '/sess_*');
        $dropped = 0;
        if ($files) {
            foreach ($files as $file) {
                if (basename($file) !== 'sess_' . $currentSessionId) {
                    @unlink($file);
                    $dropped++;
                }
            }
        }
        
        Database::insert(
            "INSERT INTO platform_firewall_logs (ip_address, event_type, severity, user_agent, created_at)
             VALUES (?, 'emergency_lockdown', 'Critical', 'System Admin', NOW())",
            [$_SERVER['REMOTE_ADDR'] ?? '127.0.0.1']
        );

        flash('success', "EMERGENCY LOCKDOWN INITIATED. {$dropped} active global session tokens dropped instantly across all tenant bounds.");
        redirect(url('superadmin/security/firewall'));
    }
}
