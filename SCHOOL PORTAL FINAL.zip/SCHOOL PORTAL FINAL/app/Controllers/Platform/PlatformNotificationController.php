<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformNotificationController extends Controller
{
    private function checkSchema(): void
    {
        try { Database::execute("ALTER TABLE platform_notifications ADD COLUMN status VARCHAR(30) DEFAULT 'delivered'"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE platform_notifications ADD COLUMN channel VARCHAR(30) DEFAULT 'in_app'"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE platform_notifications ADD COLUMN priority VARCHAR(30) DEFAULT 'normal'"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE platform_notifications ADD COLUMN scheduled_at DATETIME NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE platform_notifications ADD COLUMN failed_reason TEXT NULL"); } catch (\Throwable $e) {}

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_notification_templates (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                subject VARCHAR(255) NOT NULL,
                body TEXT NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('notifications.manage');
        $this->checkSchema();

        $query = 'SELECT n.*, s.name as school_name, u.name as user_name 
                  FROM platform_notifications n
                  LEFT JOIN schools s ON s.id = n.school_id
                  LEFT JOIN users u ON u.id = n.user_id
                  WHERE 1=1';
        
        $params = [];

        if (!empty($_GET['status'])) {
            $query .= ' AND n.status = ?';
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['type'])) {
            $query .= ' AND n.type = ?';
            $params[] = $_GET['type'];
        }
        if (!empty($_GET['q'])) {
            $query .= ' AND (n.title LIKE ? OR n.message LIKE ?)';
            $params[] = '%' . $_GET['q'] . '%';
            $params[] = '%' . $_GET['q'] . '%';
        }

        $query .= ' ORDER BY n.created_at DESC LIMIT 200';
        $notifications = Database::fetchAll($query, $params);

        $analytics = [
            'total' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_notifications')['c'] ?? 0),
            'delivered' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_notifications WHERE status="delivered"')['c'] ?? 0),
            'read' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_notifications WHERE is_read=1')['c'] ?? 0),
            'failed' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_notifications WHERE status="failed"')['c'] ?? 0),
            'scheduled' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_notifications WHERE status="scheduled"')['c'] ?? 0),
        ];

        $this->view('platform/notifications/index', [
            'title' => 'Notifications',
            'notifications' => $notifications,
            'analytics' => $analytics,
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function create(): void
    {
        PlatformAuth::requirePermission('notifications.manage');
        $this->checkSchema();

        $schools = Database::fetchAll('SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name');
        $templates = Database::fetchAll('SELECT * FROM platform_notification_templates ORDER BY name');

        $this->view('platform/notifications/create', [
            'title' => 'Compose Notification',
            'schools' => $schools,
            'templates' => $templates
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('notifications.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $title = trim($_POST['title'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'system';
        $priority = $_POST['priority'] ?? 'normal';
        $channel = $_POST['channel'] ?? 'in_app';
        $status = empty($_POST['scheduled_at']) ? 'delivered' : 'scheduled';
        $scheduledAt = empty($_POST['scheduled_at']) ? null : $_POST['scheduled_at'];

        $target = $_POST['target'] ?? 'all';
        $schoolIds = [];

        if ($target === 'all') {
            $schools = Database::fetchAll('SELECT id FROM schools WHERE deleted_at IS NULL');
            $schoolIds = array_column($schools, 'id');
        } elseif ($target === 'selected' && !empty($_POST['school_ids'])) {
            $schoolIds = array_map('intval', $_POST['school_ids']);
        } elseif ($target === 'active') {
            $schools = Database::fetchAll('SELECT id FROM schools WHERE status = 1 AND deleted_at IS NULL');
            $schoolIds = array_column($schools, 'id');
        }

        if (empty($schoolIds)) {
            flash('error', 'No target schools selected.');
            redirect(url('superadmin/notifications/create'));
        }

        foreach ($schoolIds as $sid) {
            // In a real app, this might send an email or push if $channel != in_app
            // We just store it in DB for the in-app notification center.
            Database::insert(
                'INSERT INTO platform_notifications (school_id, type, title, message, status, channel, priority, scheduled_at, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())',
                [$sid, $type, $title, $message, $status, $channel, $priority, $scheduledAt]
            );
        }

        PlatformAudit::log('notification.sent', 'platform_notifications', null, 'notification', 0, null, ['count' => count($schoolIds)]);
        
        flash('success', 'Notification dispatched to ' . count($schoolIds) . ' schools.');
        redirect(url('superadmin/notifications'));
    }

    public function retry(string $id): void
    {
        PlatformAuth::requirePermission('notifications.manage');
        $this->requireCsrf();

        Database::execute('UPDATE platform_notifications SET status = "delivered", failed_reason = NULL WHERE id = ?', [(int) $id]);
        
        PlatformAudit::log('notification.retry', 'platform_notifications', null, 'notification', (int) $id);
        
        flash('success', 'Notification retried and marked as delivered.');
        redirect(url('superadmin/notifications'));
    }
}
