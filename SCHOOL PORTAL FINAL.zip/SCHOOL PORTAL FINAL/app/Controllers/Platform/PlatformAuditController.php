<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformAuditController extends Controller
{
    private function checkSchema(): void
    {
        try {
            Database::execute('ALTER TABLE platform_audit_logs ADD COLUMN severity VARCHAR(20) DEFAULT "info"');
        } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('audit.view');
        $this->checkSchema();

        $query = 'SELECT a.*, pu.name as actor_name, pu.email as actor_email, s.name as school_name 
                  FROM platform_audit_logs a
                  LEFT JOIN platform_users pu ON pu.id = a.actor_id AND a.actor_type = "platform"
                  LEFT JOIN schools s ON s.id = a.school_id
                  WHERE 1=1';
        $params = [];

        // Filters
        if (!empty($_GET['module'])) {
            $query .= ' AND a.module = ?';
            $params[] = $_GET['module'];
        }
        if (!empty($_GET['action'])) {
            $query .= ' AND a.action = ?';
            $params[] = $_GET['action'];
        }
        if (!empty($_GET['severity'])) {
            $query .= ' AND a.severity = ?';
            $params[] = $_GET['severity'];
        }
        if (!empty($_GET['school_id'])) {
            $query .= ' AND a.school_id = ?';
            $params[] = (int)$_GET['school_id'];
        }
        if (!empty($_GET['user_id'])) {
            $query .= ' AND a.actor_id = ? AND a.actor_type = "platform"';
            $params[] = (int)$_GET['user_id'];
        }
        if (!empty($_GET['date_from'])) {
            $query .= ' AND DATE(a.created_at) >= ?';
            $params[] = $_GET['date_from'];
        }
        if (!empty($_GET['date_to'])) {
            $query .= ' AND DATE(a.created_at) <= ?';
            $params[] = $_GET['date_to'];
        }
        
        $query .= ' ORDER BY a.id DESC LIMIT 300';
        $logs = Database::fetchAll($query, $params);

        // Analytics
        $todayStart = date('Y-m-d 00:00:00');
        $analytics = [
            'total' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_audit_logs')['c'] ?? 0),
            'today' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_audit_logs WHERE created_at >= ?', [$todayStart])['c'] ?? 0),
            'security' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_audit_logs WHERE module IN ("security", "auth", "impersonation")')['c'] ?? 0),
            'critical' => (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_audit_logs WHERE severity IN ("high", "critical")')['c'] ?? 0),
        ];

        $this->view('platform/audit/index', [
            'title' => 'Activity & Audit Logs',
            'logs' => $logs,
            'analytics' => $analytics,
            'users' => Database::fetchAll('SELECT id, name FROM platform_users ORDER BY name'),
            'schools' => Database::fetchAll('SELECT id, name, code FROM schools ORDER BY name'),
            'filters' => $_GET
        ], 'platform/layouts/app');
    }
    
    public function export(): void
    {
        PlatformAuth::requirePermission('audit.view');
        $this->checkSchema();
        
        PlatformAudit::log('audit.export', 'platform_audit_logs', null, 'export', 0);
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="audit_logs_'.date('Ymd_His').'.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID', 'Date', 'Actor', 'Actor Type', 'Action', 'Module', 'Target ID', 'Target Type', 'Severity', 'IP Address']);
        
        $logs = Database::fetchAll(
            'SELECT a.id, a.created_at, COALESCE(pu.name, a.actor_id) as actor, a.actor_type, a.action, a.module, a.entity_id, a.entity_type, a.severity, a.ip_address 
             FROM platform_audit_logs a
             LEFT JOIN platform_users pu ON pu.id = a.actor_id AND a.actor_type = "platform"
             ORDER BY a.id DESC LIMIT 5000'
        );
        
        foreach($logs as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    }
}
