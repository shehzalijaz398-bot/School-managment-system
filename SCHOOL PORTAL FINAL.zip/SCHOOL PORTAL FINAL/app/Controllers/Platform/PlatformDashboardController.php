<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\SubscriptionService;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformDashboardController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('platform.dashboard');
        
        $counts = [
            'total' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL')['c'] ?? 0),
            'active' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "active" AND deleted_at IS NULL')['c'] ?? 0),
            'trial' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "trial" AND deleted_at IS NULL')['c'] ?? 0),
            'suspended' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "suspended" AND deleted_at IS NULL')['c'] ?? 0),
            'expired' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "expired" AND deleted_at IS NULL')['c'] ?? 0),
        ];

        $aggregate = [
            'total_students' => (int) (Database::fetch('SELECT COUNT(*) c FROM students')['c'] ?? 0),
            'total_staff' => (int) (Database::fetch('SELECT COUNT(*) c FROM employees')['c'] ?? 0),
            'total_invoices_volume' => (float) (Database::fetch('SELECT COALESCE(SUM(total_amount), 0) s FROM student_fee_invoices')['s'] ?? 0),
            'completed_onboardings' => (int) (Database::fetch('SELECT COUNT(*) c FROM school_onboarding_wizard WHERE is_completed = 1')['c'] ?? 0),
            'in_progress_onboardings' => (int) (Database::fetch('SELECT COUNT(*) c FROM school_onboarding_wizard WHERE is_completed = 0')['c'] ?? 0),
            'timezones' => Database::fetchAll('SELECT COALESCE(timezone, "UTC") as tz, COUNT(*) c FROM schools WHERE deleted_at IS NULL GROUP BY tz ORDER BY c DESC LIMIT 5'),
            'currencies' => Database::fetchAll('SELECT COALESCE(currency, "USD") as cur, COUNT(*) c FROM schools WHERE deleted_at IS NULL GROUP BY cur ORDER BY c DESC LIMIT 5'),
        ];

        $this->view('platform/dashboard/index', [
            'title' => 'Platform Dashboard',
            'health' => $this->getSystemHealth(),
            'counts' => $counts,
            'aggregate' => $aggregate,
        ], 'platform/layouts/app');
    }

    public function data(): void
    {
        PlatformAuth::requirePermission('platform.dashboard');
        header('Content-Type: application/json');
        
        $period = $_GET['period'] ?? '30d';
        
        $dateFilter = match ($period) {
            'today' => 'DATE(created_at) = CURRENT_DATE()',
            '7d' => 'created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)',
            '30d' => 'created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)',
            '3m' => 'created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 MONTH)',
            '6m' => 'created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)',
            '12m' => 'created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)',
            default => '1=1',
        };

        $paymentDateFilter = str_replace('created_at', 'paid_at', $dateFilter);
        $invoiceDateFilter = str_replace('created_at', 'due_date', $dateFilter);

        // 1. KPI Cards
        $totalSchools = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL')['c'] ?? 0);
        $activeSchools = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "active" AND deleted_at IS NULL')['c'] ?? 0);
        $trialSchools = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "trial" AND deleted_at IS NULL')['c'] ?? 0);
        $suspendedSchools = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "suspended" AND deleted_at IS NULL')['c'] ?? 0);
        $expiredSchools = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE subscription_status = "expired" AND deleted_at IS NULL')['c'] ?? 0);
        
        // Accurate MRR: Sum of monthly plan prices for all active schools
        $activeMrr = (float) (Database::fetch(
            'SELECT COALESCE(SUM(p.monthly_price), 0) AS mrr 
             FROM schools s 
             INNER JOIN plans p ON p.id = s.plan_id 
             WHERE s.deleted_at IS NULL AND s.subscription_status = "active"'
        )['mrr'] ?? 0);

        if ($activeMrr <= 0) {
            $activeMrr = (float) (Database::fetch(
                'SELECT COALESCE(SUM(amount), 0) AS mrr 
                 FROM subscription_payments 
                 WHERE payment_status = "paid" AND paid_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)'
            )['mrr'] ?? 0);
        }

        $allTimeRevenue = (float) (Database::fetch(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM subscription_payments WHERE payment_status = 'paid'"
        )['total'] ?? 0);

        $periodRevenue = (float) (Database::fetch(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM subscription_payments WHERE payment_status = 'paid' AND $paymentDateFilter"
        )['total'] ?? 0);

        $totalRevenue = ($periodRevenue > 0) ? $periodRevenue : $allTimeRevenue;

        $pendingPayments = (float) (Database::fetch(
            "SELECT COALESCE(SUM(total_amount - paid_amount), 0) AS pending FROM subscription_invoices WHERE status IN ('pending', 'partial', 'overdue')"
        )['pending'] ?? 0);

        // 2. Analytics: Dynamic Plan distribution
        $planRows = Database::fetchAll(
            'SELECT p.id, p.name, COUNT(s.id) as count 
             FROM plans p 
             LEFT JOIN schools s ON s.plan_id = p.id AND s.deleted_at IS NULL AND s.subscription_status IN ("active", "trial")
             GROUP BY p.id, p.name ORDER BY p.id ASC'
        );
        $planLabels = [];
        $planData = [];
        $planCounts = [];
        foreach ($planRows as $row) {
            $planLabels[] = $row['name'];
            $planData[] = (int) $row['count'];
            $planCounts[$row['name']] = (int) $row['count'];
        }

        $newSchools = (int) (Database::fetch("SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND $dateFilter")['c'] ?? 0);
        $churnedSchools = (int) (Database::fetch("SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND subscription_status IN ('cancelled', 'expired') AND $dateFilter")['c'] ?? 0);

        // Build continuous last 6 months trend
        $chartLabels = [];
        $chartValues = [];
        $revMap = [];

        $revenueRows = Database::fetchAll(
            'SELECT DATE_FORMAT(paid_at, "%Y-%m") AS ym, SUM(amount) AS total
             FROM subscription_payments WHERE payment_status = "paid" AND paid_at IS NOT NULL
             GROUP BY ym'
        );
        foreach ($revenueRows as $row) {
            $revMap[$row['ym']] = (float) $row['total'];
        }

        for ($i = 5; $i >= 0; $i--) {
            $time = strtotime("-$i months");
            $ym = date('Y-m', $time);
            $chartLabels[] = date('M Y', $time);
            $chartValues[] = $revMap[$ym] ?? 0.0;
        }

        // 4. School Activity
        $recentSchools = Database::fetchAll('SELECT s.*, p.name AS plan_name FROM schools s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.deleted_at IS NULL ORDER BY s.created_at DESC LIMIT 5');
        $recentlyActivated = Database::fetchAll('SELECT s.*, p.name AS plan_name FROM schools s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.deleted_at IS NULL AND s.subscription_status = "active" ORDER BY s.updated_at DESC LIMIT 5');
        $pendingApprovals = Database::fetchAll('SELECT s.*, p.name AS plan_name FROM schools s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.deleted_at IS NULL AND s.subscription_status = "pending" ORDER BY s.created_at DESC LIMIT 5');
        $expiringSoon = SubscriptionService::expiringWithin(15);
        $recentlySuspended = Database::fetchAll('SELECT s.*, p.name AS plan_name FROM schools s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.deleted_at IS NULL AND s.subscription_status = "suspended" ORDER BY s.updated_at DESC LIMIT 5');

        // 5. Financial Snapshot
        $recentPaymentsList = Database::fetchAll('SELECT sp.*, s.name AS school_name FROM subscription_payments sp INNER JOIN schools s ON s.id = sp.school_id WHERE s.deleted_at IS NULL ORDER BY sp.paid_at DESC LIMIT 5');
        $outstandingInvoices = Database::fetchAll('SELECT si.*, s.name AS school_name FROM subscription_invoices si INNER JOIN schools s ON s.id = si.school_id WHERE si.status IN ("pending", "partial") ORDER BY si.created_at DESC LIMIT 5');
        $overduePayments = Database::fetchAll('SELECT si.*, s.name AS school_name FROM subscription_invoices si INNER JOIN schools s ON s.id = si.school_id WHERE si.status = "overdue" ORDER BY si.due_date ASC LIMIT 5');
        
        echo json_encode([
            'kpi' => [
                'total' => $totalSchools,
                'active' => $activeSchools,
                'trial' => $trialSchools,
                'suspended' => $suspendedSchools,
                'expired' => $expiredSchools,
                'mrr' => $activeMrr,
                'total_revenue' => $totalRevenue,
                'pending_payments' => $pendingPayments,
            ],
            'analytics' => [
                'new_schools' => $newSchools,
                'churned_schools' => $churnedSchools,
                'chart_labels' => $chartLabels,
                'chart_values' => $chartValues,
                'plan_counts' => $planCounts,
                'plan_labels' => $planLabels,
                'plan_values' => $planData,
            ],
            'activity' => [
                'recent' => $recentSchools,
                'activated' => $recentlyActivated,
                'pending' => $pendingApprovals,
                'expiring' => $expiringSoon,
                'suspended' => $recentlySuspended,
            ],
            'financial' => [
                'recent_payments' => $recentPaymentsList,
                'outstanding' => $outstandingInvoices,
                'overdue' => $overduePayments,
            ],
            'aggregate' => [
                'total_students' => (int) (Database::fetch('SELECT COUNT(*) c FROM students')['c'] ?? 0),
                'total_staff' => (int) (Database::fetch('SELECT COUNT(*) c FROM employees')['c'] ?? 0),
                'total_invoices_volume' => (float) (Database::fetch('SELECT COALESCE(SUM(total_amount), 0) s FROM student_fee_invoices')['s'] ?? 0),
                'completed_onboardings' => (int) (Database::fetch('SELECT COUNT(*) c FROM school_onboarding_wizard WHERE is_completed = 1')['c'] ?? 0),
                'in_progress_onboardings' => (int) (Database::fetch('SELECT COUNT(*) c FROM school_onboarding_wizard WHERE is_completed = 0')['c'] ?? 0),
            ]
        ]);
        exit;
    }

    private function getSystemHealth(): array
    {
        $dbOk = true;
        try { Database::fetch('SELECT 1'); } catch (\Throwable) { $dbOk = false; }
        
        return [
            'status' => $dbOk ? 'Online' : 'Database Error',
            'db_status' => $dbOk ? 'Connected' : 'Disconnected',
            'php_version' => PHP_VERSION,
            'storage' => '25% Used', // Placeholder for quick view, real data in System page
            'active_users' => (int) (Database::fetch('SELECT COUNT(*) c FROM users WHERE last_login_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)')['c'] ?? 0),
            'cron_status' => 'Running',
            'errors' => 0
        ];
    }
}
