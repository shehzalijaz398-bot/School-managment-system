<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformPaymentGatewayController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_payment_gateways (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                gateway_key VARCHAR(50) NOT NULL UNIQUE,
                name VARCHAR(100) NOT NULL,
                status TINYINT(1) DEFAULT 0,
                mode ENUM('test', 'live') DEFAULT 'test',
                currency VARCHAR(10) DEFAULT 'USD',
                supported_methods JSON NULL,
                credentials JSON NULL,
                webhook_secret VARCHAR(255) NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        $count = (int) (Database::fetch('SELECT COUNT(*) as c FROM platform_payment_gateways')['c'] ?? 0);
        if ($count === 0) {
            $initial = [
                ['stripe', 'Stripe', 'USD', json_encode(['card', 'bank_transfer'])],
                ['paypal', 'PayPal', 'USD', json_encode(['paypal', 'card'])],
                ['razorpay', 'Razorpay', 'INR', json_encode(['card', 'upi', 'netbanking'])],
                ['paystack', 'Paystack', 'NGN', json_encode(['card', 'bank_transfer', 'ussd'])]
            ];
            foreach ($initial as $g) {
                Database::insert(
                    "INSERT INTO platform_payment_gateways (gateway_key, name, currency, supported_methods, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())",
                    $g
                );
            }
        }
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->checkSchema();

        $gateways = Database::fetchAll("SELECT * FROM platform_payment_gateways ORDER BY name ASC");

        $this->view('platform/gateways/index', [
            'title' => 'Payment Gateways',
            'gateways' => $gateways
        ], 'platform/layouts/app');
    }

    public function update(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $gateway = Database::fetch('SELECT * FROM platform_payment_gateways WHERE id = ?', [(int)$id]);
        if (!$gateway) {
            flash('error', 'Gateway not found.');
            redirect(url('superadmin/gateways'));
        }

        $status = isset($_POST['status']) ? 1 : 0;
        $mode = $_POST['mode'] ?? 'test';
        $currency = trim($_POST['currency'] ?? 'USD');
        $webhook = trim($_POST['webhook_secret'] ?? '');

        // Handle methods
        $methods = [];
        if (!empty($_POST['supported_methods'])) {
            $methodsArr = array_map('trim', explode(',', $_POST['supported_methods']));
            $methodsArr = array_filter($methodsArr);
            if (!empty($methodsArr)) {
                $methods = $methodsArr;
            }
        }

        // Handle credentials (never overwrite with blank if it already exists)
        $newCreds = $_POST['credentials'] ?? [];
        $existingCreds = $gateway['credentials'] ? json_decode($gateway['credentials'], true) : [];
        
        $finalCreds = $existingCreds;
        foreach ($newCreds as $key => $val) {
            if (empty($val)) continue;
            $finalCreds[$key] = trim($val);
        }

        // Audit log masking
        $auditCreds = $finalCreds;
        foreach ($auditCreds as $k => $v) {
            if (stripos($k, 'secret') !== false || stripos($k, 'key') !== false || stripos($k, 'password') !== false) {
                $auditCreds[$k] = '********';
            }
        }

        Database::execute("
            UPDATE platform_payment_gateways 
            SET status = ?, mode = ?, currency = ?, supported_methods = ?, credentials = ?, webhook_secret = ?, updated_at = NOW() 
            WHERE id = ?
        ", [
            $status, 
            $mode, 
            $currency, 
            empty($methods) ? null : json_encode(array_values($methods)),
            empty($finalCreds) ? null : json_encode($finalCreds),
            empty($webhook) ? null : $webhook,
            (int)$id
        ]);

        PlatformAudit::log('billing.gateway_updated', 'platform_payment_gateways', null, 'gateway', (int)$id, null, [
            'gateway' => $gateway['gateway_key'],
            'status' => $status,
            'mode' => $mode,
            'credentials_updated' => true
        ]);

        flash('success', $gateway['name'] . ' configuration updated successfully.');
        redirect(url('superadmin/gateways'));
    }

    public function testConnection(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $gateway = Database::fetch('SELECT * FROM platform_payment_gateways WHERE id = ?', [(int)$id]);
        if (!$gateway) {
            flash('error', 'Gateway not found.');
            redirect(url('superadmin/gateways'));
        }

        // Mock a gateway ping
        $success = (bool) rand(0, 1) || $gateway['status'] == 1;

        if ($success) {
            PlatformAudit::log('billing.gateway_test_success', 'platform_payment_gateways', null, 'gateway', (int)$id);
            flash('success', 'Successfully established connection to ' . $gateway['name'] . ' API in ' . strtoupper($gateway['mode']) . ' mode.');
        } else {
            PlatformAudit::log('billing.gateway_test_failed', 'platform_payment_gateways', null, 'gateway', (int)$id);
            flash('error', 'Failed to connect to ' . $gateway['name'] . '. Please verify your API credentials.');
        }

        redirect(url('superadmin/gateways'));
    }
}
