<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformBackupController extends Controller
{
    private function initSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_backups (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                file_name VARCHAR(255) NOT NULL,
                file_size BIGINT NOT NULL DEFAULT 0,
                status VARCHAR(50) NOT NULL DEFAULT 'completed',
                storage_location VARCHAR(50) NOT NULL DEFAULT 'local',
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->initSchema();

        $backups = Database::fetchAll("SELECT * FROM platform_backups ORDER BY created_at DESC");
        
        $totalSize = 0;
        foreach($backups as $b) {
            $totalSize += (int)$b['file_size'];
        }
        
        $lastBackup = Database::fetch("SELECT created_at FROM platform_backups WHERE status = 'completed' ORDER BY created_at DESC LIMIT 1");
        
        // Calculate diff manually to avoid Carbon dependency issues if missing
        $timeElapsed = 'Never';
        if ($lastBackup) {
            $diff = time() - strtotime($lastBackup['created_at']);
            if ($diff < 60) $timeElapsed = 'Just now';
            elseif ($diff < 3600) $timeElapsed = floor($diff/60) . ' mins ago';
            elseif ($diff < 86400) $timeElapsed = floor($diff/3600) . ' hours ago';
            else $timeElapsed = floor($diff/86400) . ' days ago';
        }

        $this->view('platform/backups', [
            'title' => 'Disaster Recovery & Vault',
            'backups' => $backups,
            'totalSize' => $totalSize,
            'timeElapsed' => $timeElapsed,
            'cloudStatus' => 'Synchronized'
        ], 'platform/layouts/app');
    }

    public function createBackup(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $cronPath = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'cron' . DIRECTORY_SEPARATOR . 'system_backup_runner.php';
        if (file_exists($cronPath)) {
            shell_exec("php " . escapeshellarg($cronPath));
            flash('success', 'Instant snapshot triggered and encrypted vault payload generated successfully.');
        } else {
            flash('error', 'Backup runner script not found at path: ' . $cronPath);
        }

        redirect(url('superadmin/system/backups'));
    }

    public function restoreCheckpoint(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        $backup = Database::fetch("SELECT * FROM platform_backups WHERE id = ?", [(int)$id]);
        if (!$backup) {
            flash('error', 'Backup checkpoint not found in registry.');
            redirect(url('superadmin/system/backups'));
            return;
        }

        $backupDir = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'backups';
        $encFile = $backupDir . DIRECTORY_SEPARATOR . $backup['file_name'];
        if (!file_exists($encFile)) {
            flash('error', 'Backup archive file is missing from disk.');
            redirect(url('superadmin/system/backups'));
            return;
        }

        try {
            // Decrypt AES-256-CBC
            $encryptionKey = backup_encryption_key();
            $data = file_get_contents($encFile);
            $ivLength = openssl_cipher_iv_length('aes-256-cbc');
            $iv = substr($data, 0, $ivLength);
            $cipherText = substr($data, $ivLength);
            $decryptedGz = openssl_decrypt($cipherText, 'aes-256-cbc', $encryptionKey, 0, $iv);

            if ($decryptedGz === false) {
                throw new \RuntimeException('Decryption failed: cryptographic key mismatch or corrupted payload.');
            }

            // Decompress GZIP
            $sql = gzdecode($decryptedGz);
            if ($sql === false) {
                throw new \RuntimeException('Decompression failed: corrupted gzip payload.');
            }

            // Execute SQL restoration statements safely
            $pdo = Database::connection();
            $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, 1);
            $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");
            $pdo->exec($sql);
            $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");
            $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, 0);

            \App\Services\Platform\PlatformAudit::log('system.rollback', 'platform_backups', null, 'system', (int)$id, null, ['file' => $backup['file_name']]);
            flash('success', "Database snapshot restored successfully from encrypted checkpoint: " . $backup['file_name']);
        } catch (\Throwable $e) {
            error_log("Database Restore Error: " . $e->getMessage());
            flash('error', "Database restoration failed: " . $e->getMessage());
        }

        redirect(url('superadmin/system/backups'));
    }
}
