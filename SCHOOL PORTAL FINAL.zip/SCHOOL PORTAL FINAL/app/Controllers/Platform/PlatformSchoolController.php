<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\BillingService;
use App\Services\Platform\PlanLimitService;
use App\Services\Platform\PlatformAudit;
use App\Services\Platform\SchoolOnboardingService;
use App\Services\Platform\SubscriptionService;
use App\Services\Platform\TenantService;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformSchoolController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('schools.view');
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $result = TenantService::list([
            'q' => $_GET['q'] ?? null,
            'status' => $_GET['status'] ?? null,
            'plan_id' => $_GET['plan_id'] ?? null,
        ], $page, 20);

        $countsRaw = Database::fetchAll('SELECT subscription_status, COUNT(*) as c FROM schools WHERE deleted_at IS NULL GROUP BY subscription_status');
        $counts = ['total' => 0, 'active' => 0, 'trial' => 0, 'pending' => 0, 'past_due' => 0, 'suspended' => 0, 'expired' => 0, 'cancelled' => 0, 'archived' => 0];
        foreach($countsRaw as $r) {
            $status = $r['subscription_status'] ?: 'pending';
            $counts[$status] = (int) $r['c'];
            $counts['total'] += (int) $r['c'];
        }

        $this->view('platform/schools/index', [
            'title' => 'Schools Management',
            'result' => $result,
            'counts' => $counts,
            'plans' => Database::fetchAll('SELECT id, name FROM plans WHERE status = 1 ORDER BY sort_order'),
            'filters' => $_GET,
        ], 'platform/layouts/app');
    }

    public function create(): void
    {
        PlatformAuth::requirePermission('schools.create');
        $this->view('platform/schools/form', [
            'title' => 'Create School',
            'school' => null,
            'plans' => Database::fetchAll('SELECT * FROM plans WHERE status = 1 ORDER BY sort_order'),
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('schools.create');
        $this->requireCsrf();
        $data = $this->validate($_POST, [
            'name' => 'required|max:191',
            'email' => 'required|email',
            'plan_id' => 'required|integer',
            'admin_name' => 'required',
            'admin_email' => 'required|email',
            'admin_password' => 'required|min:8',
        ]);

        try {
            $schoolId = SchoolOnboardingService::provision([
                'name' => $data['name'],
                'email' => $data['email'],
                'phone' => $_POST['phone'] ?? null,
                'city' => $_POST['city'] ?? null,
                'country' => $_POST['country'] ?? null,
                'address' => $_POST['address'] ?? null,
                'notes' => $_POST['notes'] ?? null,
            ], [
                'name' => $data['admin_name'],
                'email' => $data['admin_email'],
                'password' => $data['admin_password'],
                'phone' => $_POST['admin_phone'] ?? null,
            ], (int) $data['plan_id'], !empty($_POST['start_trial']));

            flash('success', 'School provisioned successfully.');
            redirect(url('superadmin/schools/' . $schoolId));
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect(url('superadmin/schools/create'));
        }
    }

    public function show(string $id): void
    {
        PlatformAuth::requirePermission('schools.view');
        $school = Database::fetch(
            'SELECT s.*, p.name AS plan_name FROM schools s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.id = ? LIMIT 1',
            [(int) $id]
        );
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/schools'));
        }
        $usage = PlanLimitService::usage((int) $id);
        $this->view('platform/schools/show', [
            'title' => $school['name'],
            'school' => $school,
            'usage' => $usage,
            'plan' => $school['plan_id'] ? Database::fetch('SELECT * FROM plans WHERE id = ?', [(int) $school['plan_id']]) : null,
            'subscriptions' => Database::fetchAll('SELECT sub.*, p.name AS plan_name FROM subscriptions sub LEFT JOIN plans p ON p.id = sub.plan_id WHERE sub.school_id = ? ORDER BY sub.id DESC', [(int) $id]),
            'invoices' => Database::fetchAll('SELECT * FROM subscription_invoices WHERE school_id = ? ORDER BY id DESC LIMIT 20', [(int) $id]),
            'payments' => Database::fetchAll('SELECT * FROM subscription_payments WHERE school_id = ? ORDER BY id DESC LIMIT 20', [(int) $id]),
            'users' => Database::fetchAll(
                'SELECT u.id, u.name, u.email, u.status, u.last_login_at, r.name AS role_name FROM users u
                 INNER JOIN roles r ON r.id = u.role_id WHERE u.school_id = ? ORDER BY u.name LIMIT 50',
                [(int) $id]
            ),
            'activity' => Database::fetchAll('SELECT * FROM platform_audit_logs WHERE school_id = ? ORDER BY created_at DESC LIMIT 30', [(int) $id]),
            'plans' => Database::fetchAll('SELECT * FROM plans WHERE status = 1'),
        ], 'platform/layouts/app');
    }

    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();
        $status = $_POST['subscription_status'] ?? '';
        $allowed = ['pending','trial','active','past_due','suspended','expired','cancelled','archived'];
        if (!in_array($status, $allowed, true)) {
            flash('error', 'Invalid status.');
            redirect(url('superadmin/schools/' . $id));
        }
        TenantService::setStatus((int) $id, $status);
        flash('success', 'School status updated.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function changePlan(string $id): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        $this->requireCsrf();
        SubscriptionService::changePlan((int) $id, (int) $_POST['plan_id']);
        flash('success', 'Plan updated.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function extend(string $id): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        $this->requireCsrf();
        SubscriptionService::extend((int) $id, max(1, (int) ($_POST['days'] ?? 30)));
        flash('success', 'Subscription extended.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function activate(string $id): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        $this->requireCsrf();
        $school = Database::fetch('SELECT plan_id FROM schools WHERE id = ?', [(int) $id]);
        if (!$school || !$school['plan_id']) {
            flash('error', 'School has no plan.');
            redirect(url('superadmin/schools/' . $id));
        }
        SubscriptionService::activate((int) $id, (int) $school['plan_id'], $_POST['billing_cycle'] ?? 'monthly');
        flash('success', 'Subscription activated.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function saveNotes(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();
        $old = Database::fetch('SELECT notes FROM schools WHERE id = ?', [(int) $id]);
        Database::execute('UPDATE schools SET notes = ?, updated_at = NOW() WHERE id = ?', [$_POST['notes'] ?? '', (int) $id]);
        PlatformAudit::log('school.notes', 'schools', (int) $id, 'school', (int) $id, $old, ['notes' => $_POST['notes'] ?? '']);
        flash('success', 'Notes saved.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function destroy(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();
        
        $schoolId = (int) $id;
        $school = Database::fetch('SELECT id, name FROM schools WHERE id = ?', [$schoolId]);
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/schools'));
        }

        Database::beginTransaction();
        try {
            Database::execute('SET FOREIGN_KEY_CHECKS = 0');

            $tables = [
                'remember_tokens', 'login_attempts', 'support_ticket_messages', 'support_tickets',
                'subscription_payments', 'subscription_invoice_items', 'subscription_invoices', 'subscriptions',
                'school_usage', 'student_fee_payments', 'student_fee_invoice_items', 'student_fee_invoices',
                'expenses', 'incomes', 'payroll_items', 'payroll', 'salary_structures',
                'student_attendance', 'staff_attendance', 'student_parents', 'teacher_assignments',
                'parents', 'students', 'student_academic_history', 'teachers', 'employees', 'employee_documents',
                'leave_requests', 'leave_types', 'timetables',
                'exam_marks', 'exam_subjects', 'exams', 'exam_types',
                'assignment_submissions', 'assignments',
                'book_issues', 'books', 'book_categories',
                'visitors', 'admissions', 'admission_inquiries',
                'users', 'role_permissions', 'roles',
                'announcements', 'notifications',
                'academic_years', 'departments', 'grade_scales', 'settings',
                'sections', 'classes', 'subjects', 'fee_categories',
                'platform_notifications', 'school_registrations', 'school_branding',
                'school_domains', 'platform_audit_logs', 'support_impersonations'
            ];

            foreach ($tables as $table) {
                // Delete rows from each tenant-scoped table if it has school_id
                // Some tables (like support_ticket_messages, subscription_invoice_items, student_fee_payments, payroll_items) might not have school_id directly in all versions, so we use a safe query
                try {
                    Database::execute("DELETE FROM `$table` WHERE school_id = ?", [$schoolId]);
                } catch (\Throwable $e) {
                    // Ignore missing column errors if the table doesn't have school_id
                }
            }

            // Finally delete the school record itself
            Database::execute('DELETE FROM schools WHERE id = ?', [$schoolId]);
            
            // Log as platform action (school_id = null since it no longer exists)
            PlatformAudit::log('school.delete', 'schools', $schoolId, 'school', $schoolId, $school, ['deleted' => true, 'type' => 'hard_delete'], null);
            
            Database::execute('SET FOREIGN_KEY_CHECKS = 1');
            Database::commit();
            flash('success', 'School permanently deleted.');
        } catch (\Throwable $e) {
            Database::execute('SET FOREIGN_KEY_CHECKS = 1');
            Database::rollBack();
            error_log('[PlatformSchoolController] Hard Delete Error: ' . $e->getMessage());
            flash('error', 'Error deleting school. Some data could not be removed.');
        }
        
        redirect(url('superadmin/schools'));
    }

    public function saveLimits(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();
        $limits = json_encode([
            'max_students' => (int) ($_POST['max_students'] ?? 0),
            'max_teachers' => (int) ($_POST['max_teachers'] ?? 0),
            'storage_mb' => (int) ($_POST['storage_mb'] ?? 0),
        ]);
        Database::execute('UPDATE schools SET custom_limits = ? WHERE id = ?', [$limits, (int) $id]);
        flash('success', 'Custom limits applied successfully.');
        redirect(url('superadmin/schools/' . $id));
    }

    public function bulkAction(): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();
        $action = $_POST['action'] ?? '';
        $ids = $_POST['ids'] ?? [];
        if (empty($ids) || !is_array($ids)) {
            flash('error', 'No schools selected.');
            redirect(url('superadmin/schools'));
        }
        
        $count = 0;
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($action === 'suspend') {
                TenantService::setStatus($id, 'suspended');
                $count++;
            } elseif ($action === 'activate') {
                TenantService::setStatus($id, 'active');
                $count++;
            }
        }
        
        flash('success', "Bulk action '{$action}' applied to {$count} schools.");
        redirect(url('superadmin/schools'));
    }

    public function trials(): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        
        $filter = $_GET['filter'] ?? 'all';
        $q = trim((string) ($_GET['q'] ?? ''));
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = 25;

        $now = date('Y-m-d H:i:s');
        $in7Days = date('Y-m-d H:i:s', strtotime('+7 days'));

        $counts = [
            'total' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND (subscription_status = "trial" OR trial_ends_at IS NOT NULL)')['c'] ?? 0),
            'active' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND subscription_status = "trial" AND trial_ends_at >= ?', [$now])['c'] ?? 0),
            'expiring_soon' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND subscription_status = "trial" AND trial_ends_at BETWEEN ? AND ?', [$now, $in7Days])['c'] ?? 0),
            'expired' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND (subscription_status = "expired" OR (subscription_status = "trial" AND trial_ends_at < ?))', [$now])['c'] ?? 0),
            'converted' => (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE deleted_at IS NULL AND subscription_status = "active" AND trial_ends_at IS NOT NULL')['c'] ?? 0),
        ];

        $sql = 'SELECT s.id, s.name, s.code, s.email, s.subscription_status, s.trial_ends_at, s.subscription_ends_at, s.created_at, s.status,
                       p.name AS plan_name, p.monthly_price,
                       (SELECT u.email FROM users u WHERE u.school_id = s.id ORDER BY u.id ASC LIMIT 1) AS owner_email,
                       (SELECT u.name FROM users u WHERE u.school_id = s.id ORDER BY u.id ASC LIMIT 1) AS owner_name
                FROM schools s
                LEFT JOIN plans p ON p.id = s.plan_id
                WHERE s.deleted_at IS NULL';
        $params = [];

        if ($filter === 'active') {
            $sql .= ' AND s.subscription_status = "trial" AND s.trial_ends_at >= ?';
            $params[] = $now;
        } elseif ($filter === 'expiring_soon') {
            $sql .= ' AND s.subscription_status = "trial" AND s.trial_ends_at BETWEEN ? AND ?';
            $params[] = $now;
            $params[] = $in7Days;
        } elseif ($filter === 'expired') {
            $sql .= ' AND (s.subscription_status = "expired" OR (s.subscription_status = "trial" AND s.trial_ends_at < ?))';
            $params[] = $now;
        } elseif ($filter === 'converted') {
            $sql .= ' AND s.subscription_status = "active"';
        } else {
            $sql .= ' AND (s.subscription_status IN ("trial", "expired") OR s.trial_ends_at IS NOT NULL)';
        }

        if (!empty($q)) {
            $sql .= ' AND (s.name LIKE ? OR s.code LIKE ? OR s.email LIKE ? OR EXISTS (SELECT 1 FROM users u WHERE u.school_id = s.id AND (u.email LIKE ? OR u.name LIKE ?)))';
            $kw = '%' . $q . '%';
            $params = array_merge($params, [$kw, $kw, $kw, $kw, $kw]);
        }

        $sql .= ' ORDER BY s.trial_ends_at ASC, s.id DESC';

        $total = (int) (Database::fetch('SELECT COUNT(*) AS c FROM (' . $sql . ') t', $params)['c'] ?? 0);
        $offset = ($page - 1) * $perPage;
        $items = Database::fetchAll($sql . " LIMIT {$perPage} OFFSET {$offset}", $params);

        foreach ($items as &$item) {
            $expiry = $item['trial_ends_at'];
            if (!empty($expiry)) {
                $rem = (int) ceil((strtotime($expiry) - time()) / 86400);
                $item['remaining_days'] = $rem;
                if ($item['subscription_status'] === 'active') {
                    $item['badge_label'] = 'Converted to Paid';
                    $item['badge_class'] = 'success';
                } elseif ($rem > 7) {
                    $item['badge_label'] = "{$rem} days left";
                    $item['badge_class'] = 'info';
                } elseif ($rem > 0) {
                    $item['badge_label'] = "{$rem} days left (Expiring Soon)";
                    $item['badge_class'] = 'warning';
                } elseif ($rem === 0) {
                    $item['badge_label'] = 'Expires today';
                    $item['badge_class'] = 'danger';
                } else {
                    $item['badge_label'] = 'Expired ' . abs($rem) . ' days ago';
                    $item['badge_class'] = 'danger';
                }
            } else {
                $item['remaining_days'] = 0;
                $item['badge_label'] = 'No trial set';
                $item['badge_class'] = 'secondary';
            }
        }

        $this->view('platform/trials/index', [
            'title' => 'Trial Management & Controlled Extensions',
            'items' => $items,
            'counts' => $counts,
            'filter' => $filter,
            'q' => $q,
            'page' => $page,
            'pages' => (int) ceil(max(1, $total) / $perPage),
            'total' => $total,
        ], 'platform/layouts/app');
    }

    public function extendTrial(string $id): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        $this->requireCsrf();

        $schoolId = (int) $id;
        $school = Database::fetch('SELECT * FROM schools WHERE id = ? LIMIT 1', [$schoolId]);
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/trials'));
            return;
        }

        $days = max(1, (int) ($_POST['days'] ?? 14));
        $reason = trim((string) ($_POST['reason'] ?? ''));

        if (empty($reason)) {
            flash('error', 'A specific business reason for the manual trial extension is mandatory for audit records.');
            redirect(url('superadmin/trials'));
            return;
        }

        $oldExpiry = $school['trial_ends_at'];
        $base = $oldExpiry && strtotime($oldExpiry) > time()
            ? strtotime($oldExpiry)
            : time();

        $newExpiry = date('Y-m-d 23:59:59', strtotime(date('Y-m-d H:i:s', $base) . " +{$days} days"));

        Database::beginTransaction();
        try {
            Database::execute(
                'UPDATE schools 
                 SET trial_ends_at = ?, subscription_ends_at = ?, subscription_status = "trial", status = 1, updated_at = NOW() 
                 WHERE id = ?',
                [$newExpiry, $newExpiry, $schoolId]
            );

            Database::execute(
                'UPDATE subscriptions 
                 SET trial_end_date = ?, end_date = ?, status = "trial", updated_at = NOW() 
                 WHERE school_id = ? AND (status = "trial" OR status = "expired")
                 ORDER BY id DESC LIMIT 1',
                [date('Y-m-d', strtotime($newExpiry)), date('Y-m-d', strtotime($newExpiry)), $schoolId]
            );

            PlatformAudit::log(
                'trial.extended',
                'subscriptions',
                $schoolId,
                'school',
                $schoolId,
                ['trial_ends_at' => $oldExpiry, 'status' => $school['subscription_status']],
                [
                    'trial_ends_at' => $newExpiry,
                    'extended_days' => $days,
                    'reason' => $reason,
                    'administrator' => PlatformAuth::user()['name'] ?? 'Super Admin',
                    'administrator_email' => PlatformAuth::user()['email'] ?? '',
                ]
            );

            Database::commit();
            flash('success', "Trial for '{$school['name']}' extended by {$days} days until " . date('M d, Y', strtotime($newExpiry)) . ". Reason logged: {$reason}");
        } catch (\Throwable $e) {
            Database::rollBack();
            flash('error', 'Failed to extend trial: ' . $e->getMessage());
        }

        redirect(url('superadmin/trials'));
    }
}
