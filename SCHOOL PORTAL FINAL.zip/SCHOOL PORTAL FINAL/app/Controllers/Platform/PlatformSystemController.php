<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;
use PDO;

final class PlatformSystemController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_jobs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                queue VARCHAR(50) NOT NULL,
                payload LONGTEXT NOT NULL,
                attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
                reserved_at DATETIME NULL,
                available_at DATETIME NOT NULL,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_failed_jobs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                queue VARCHAR(50) NOT NULL,
                payload LONGTEXT NOT NULL,
                exception LONGTEXT NOT NULL,
                failed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_cron_tasks (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                frequency VARCHAR(50) NOT NULL,
                last_run_at DATETIME NULL,
                next_run_at DATETIME NULL,
                status VARCHAR(20) DEFAULT 'idle',
                last_output TEXT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_system_errors (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                level VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                file VARCHAR(255) NULL,
                line INT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('system.view');
        $this->checkSchema();
        
        $dbOk = false;
        $dbPingMs = 0;
        $dbSizeMB = '0.00';
        $dbTables = 0;
        $dbVersion = 'Unknown';

        try {
            $start = microtime(true);
            Database::fetch('SELECT 1 AS ok');
            $dbPingMs = round((microtime(true) - $start) * 1000, 2);
            $dbOk = true;

            $dbName = Database::fetch('SELECT DATABASE() as db')['db'] ?? '';
            if ($dbName) {
                $dbSize = Database::fetch('SELECT SUM(data_length + index_length) / 1048576 as size FROM information_schema.tables WHERE table_schema = ?', [$dbName]);
                $dbSizeMB = number_format((float) ($dbSize['size'] ?? 0), 2);
                
                $dbTableInfo = Database::fetch('SELECT COUNT(*) as c FROM information_schema.tables WHERE table_schema = ?', [$dbName]);
                $dbTables = (int) ($dbTableInfo['c'] ?? 0);
            }
            
            $dbVersionInfo = Database::fetch('SELECT VERSION() as v');
            $dbVersion = $dbVersionInfo['v'] ?? 'Unknown';

        } catch (\Throwable) {
            $dbOk = false;
        }

        $freeDiskSpace = @disk_free_space(base_path('')) ?: 0;
        $totalDiskSpace = @disk_total_space(base_path('')) ?: 0;
        $usedDiskSpace = $totalDiskSpace - $freeDiskSpace;
        $diskUsagePercent = $totalDiskSpace > 0 ? round(($usedDiskSpace / $totalDiskSpace) * 100, 2) : 0;

        $memoryUsage = round(memory_get_usage(true) / 1048576, 2);

        $maintMode = Database::fetch('SELECT setting_value FROM platform_settings WHERE setting_key = "maint_mode"');
        $isMaintenance = $maintMode && $maintMode['setting_value'] === '1';

        // Queue Stats
        $pendingJobs = (int) (Database::fetch('SELECT COUNT(*) as c FROM platform_jobs')['c'] ?? 0);
        $failedJobs = (int) (Database::fetch('SELECT COUNT(*) as c FROM platform_failed_jobs')['c'] ?? 0);
        
        // Cron Stats
        $cronTasks = Database::fetchAll('SELECT * FROM platform_cron_tasks ORDER BY next_run_at ASC');
        $failedTasks = count(array_filter($cronTasks, fn($c) => $c['status'] === 'error'));
        
        // Recent Errors
        $recentErrors = Database::fetchAll('SELECT * FROM platform_system_errors ORDER BY created_at DESC LIMIT 5');

        $overallStatus = 'Healthy';
        if (!$dbOk || $diskUsagePercent > 95 || $failedJobs > 100 || $failedTasks > 0) {
            $overallStatus = 'Critical';
        } elseif ($diskUsagePercent > 80 || $failedJobs > 10) {
            $overallStatus = 'Warning';
        }

        $this->view('platform/system/index', [
            'title' => 'System Health & Monitoring',
            'health' => [
                'status' => $overallStatus,
                'db_ok' => $dbOk,
                'db_ping' => $dbPingMs,
                'db_size' => $dbSizeMB,
                'db_tables' => $dbTables,
                'db_version' => $dbVersion,
                'is_maintenance' => $isMaintenance
            ],
            'queue' => [
                'pending' => $pendingJobs,
                'failed' => $failedJobs,
                'status' => $failedJobs > 50 ? 'Critical' : ($failedJobs > 0 ? 'Warning' : 'Healthy')
            ],
            'cron' => [
                'tasks' => $cronTasks,
                'failed' => $failedTasks,
                'status' => $failedTasks > 0 ? 'Warning' : 'Healthy'
            ],
            'errors' => $recentErrors,
            'server' => [
                'php_version' => PHP_VERSION,
                'app_version' => '2.0.1',
                'os' => php_uname('s') . ' ' . php_uname('r'),
                'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'server_time' => date('Y-m-d H:i:s T'),
                'timezone' => date_default_timezone_get(),
                'memory_limit' => ini_get('memory_limit'),
                'upload_max' => ini_get('upload_max_filesize'),
                'max_execution_time' => ini_get('max_execution_time') . 's',
                'memory_usage' => $memoryUsage,
                'disk_usage_percent' => $diskUsagePercent,
                'disk_free_gb' => round($freeDiskSpace / 1073741824, 2),
                'disk_total_gb' => round($totalDiskSpace / 1073741824, 2)
            ],
            'storage' => [
                'uploads' => $this->dirSize(public_path('uploads')),
                'logs' => $this->dirSize(base_path('storage/logs')),
                'cache' => $this->dirSize(base_path('storage/cache')),
                'views' => $this->dirSize(base_path('storage/views')),
            ],
        ], 'platform/layouts/app');
    }

    public function clearCache(string $type = 'all'): void
    {
        PlatformAuth::requirePermission('system.view');
        $this->requireCsrf();

        if ($type === 'app' || $type === 'all') {
            $this->emptyDir(base_path('storage/cache'));
        }
        if ($type === 'views' || $type === 'all') {
            $this->emptyDir(base_path('storage/views'));
        }

        PlatformAudit::log('system.cache_cleared', 'system', null, 'cache', 0, null, ['type' => $type]);
        
        flash('success', ucfirst($type) . ' cache cleared successfully.');
        redirect(url('superadmin/system'));
    }

    public function toggleMaintenance(): void
    {
        PlatformAuth::requirePermission('system.view');
        $this->requireCsrf();

        $exists = Database::fetch('SELECT id, setting_value FROM platform_settings WHERE setting_key = "maint_mode"');
        if ($exists) {
            $newValue = $exists['setting_value'] === '1' ? '0' : '1';
            Database::execute('UPDATE platform_settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$newValue, (int) $exists['id']]);
        } else {
            $newValue = '1';
            Database::insert('INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES ("maint_mode", "1", NOW(), NOW())');
        }

        PlatformAudit::log('system.maintenance_toggled', 'platform_settings', null, 'system', 0, null, ['status' => $newValue]);

        if ($newValue === '1') {
            flash('warning', 'Platform is now in MAINTENANCE MODE. Tenant traffic is blocked.');
        } else {
            flash('success', 'Maintenance mode disabled. Platform is LIVE.');
        }
        redirect(url('superadmin/system'));
    }

    private function emptyDir(string $dir): void
    {
        if (!is_dir($dir)) return;
        foreach (new \DirectoryIterator($dir) as $f) {
            if ($f->isFile() && $f->getFilename() !== '.gitignore') {
                @unlink($f->getPathname());
            }
        }
    }

    private function dirSize(string $dir): string
    {
        if (!is_dir($dir)) return '0.00 MB';
        $size = 0;
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $f) {
            $size += $f->getSize();
        }
        return number_format($size / 1048576, 2) . ' MB';
    }
}
