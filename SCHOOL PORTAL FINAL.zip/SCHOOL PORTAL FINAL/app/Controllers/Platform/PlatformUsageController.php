<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use App\Services\Platform\PlanLimitService;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformUsageController extends Controller
{
    private function checkSchema(): void
    {
        try { Database::execute("ALTER TABLE schools ADD COLUMN override_student_limit INT NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE schools ADD COLUMN override_teacher_limit INT NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE schools ADD COLUMN override_employee_limit INT NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE schools ADD COLUMN override_storage_limit_mb INT NULL"); } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $schools = Database::fetchAll("
            SELECT s.id, s.name, s.subscription_status, p.name as plan_name,
                   p.student_limit, p.teacher_limit, p.employee_limit, p.storage_limit_mb,
                   s.override_student_limit, s.override_teacher_limit, s.override_employee_limit, s.override_storage_limit_mb
            FROM schools s
            LEFT JOIN plans p ON s.plan_id = p.id
            ORDER BY s.name ASC
        ");

        // Collect usage for all schools
        $usageData = [];
        $totalStudents = 0;
        $totalTeachers = 0;
        
        foreach ($schools as $k => $s) {
            $usage = PlanLimitService::usage((int)$s['id']);
            $schools[$k]['usage'] = $usage;
            
            $totalStudents += $usage['students'];
            $totalTeachers += $usage['teachers'];
            
            // Resolve limits
            $schools[$k]['active_student_limit'] = $s['override_student_limit'] ?? $s['student_limit'] ?? null;
            $schools[$k]['active_teacher_limit'] = $s['override_teacher_limit'] ?? $s['teacher_limit'] ?? null;
            $schools[$k]['active_employee_limit'] = $s['override_employee_limit'] ?? $s['employee_limit'] ?? null;
            $schools[$k]['active_storage_limit_mb'] = $s['override_storage_limit_mb'] ?? $s['storage_limit_mb'] ?? null;
            
            // Check if overridden
            $schools[$k]['is_student_overridden'] = $s['override_student_limit'] !== null;
            $schools[$k]['is_teacher_overridden'] = $s['override_teacher_limit'] !== null;
        }

        $analytics = [
            'total_schools' => count($schools),
            'total_students' => $totalStudents,
            'total_teachers' => $totalTeachers,
            'overridden_schools' => count(array_filter($schools, fn($s) => $s['override_student_limit'] !== null || $s['override_teacher_limit'] !== null || $s['override_employee_limit'] !== null || $s['override_storage_limit_mb'] !== null))
        ];

        $this->view('platform/usage/index', [
            'title' => 'Usage & Limits',
            'schools' => $schools,
            'analytics' => $analytics
        ], 'platform/layouts/app');
    }

    public function show(string $schoolId): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $school = Database::fetch("
            SELECT s.*, p.name as plan_name,
                   p.student_limit, p.teacher_limit, p.employee_limit, p.storage_limit_mb
            FROM schools s
            LEFT JOIN plans p ON s.plan_id = p.id
            WHERE s.id = ?
        ", [(int) $schoolId]);
        
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/usage'));
        }

        $school['usage'] = PlanLimitService::usage((int) $school['id']);

        $this->view('platform/usage/show', [
            'title' => 'Usage: ' . $school['name'],
            'school' => $school
        ], 'platform/layouts/app');
    }

    public function update(string $schoolId): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $school = Database::fetch('SELECT id, name FROM schools WHERE id = ?', [(int) $schoolId]);
        if (!$school) redirect(url('superadmin/usage'));

        $overrideStudents = $_POST['override_student_limit'] !== '' ? (int)$_POST['override_student_limit'] : null;
        $overrideTeachers = $_POST['override_teacher_limit'] !== '' ? (int)$_POST['override_teacher_limit'] : null;
        $overrideEmployees = $_POST['override_employee_limit'] !== '' ? (int)$_POST['override_employee_limit'] : null;
        $overrideStorage = $_POST['override_storage_limit_mb'] !== '' ? (int)$_POST['override_storage_limit_mb'] : null;

        Database::execute(
            'UPDATE schools SET override_student_limit = ?, override_teacher_limit = ?, override_employee_limit = ?, override_storage_limit_mb = ?, updated_at = NOW() WHERE id = ?',
            [$overrideStudents, $overrideTeachers, $overrideEmployees, $overrideStorage, (int) $school['id']]
        );

        PlatformAudit::log('usage.limits_overridden', 'schools', (int)$school['id'], 'school', (int)$school['id'], null, [
            'override_students' => $overrideStudents,
            'override_teachers' => $overrideTeachers,
            'override_employees' => $overrideEmployees,
            'override_storage' => $overrideStorage
        ]);

        flash('success', 'Custom limit overrides updated for ' . $school['name'] . '.');
        redirect(url('superadmin/usage/' . $schoolId));
    }
}
