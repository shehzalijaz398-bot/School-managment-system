<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\BillingService;
use App\Services\Platform\PlatformAudit;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;
use Core\TenantContext;

final class PlatformImpersonationController extends Controller
{
    public function start(string $schoolId): void
    {
        PlatformAuth::requirePermission('support.impersonate');
        $this->requireCsrf();

        $school = Database::fetch('SELECT * FROM schools WHERE id = ? LIMIT 1', [(int) $schoolId]);
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/schools'));
        }

        $admin = Database::fetch(
            'SELECT u.* FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.school_id = ? AND r.slug IN ("school_admin","principal") AND u.status = 1
             ORDER BY FIELD(r.slug, "school_admin", "principal") LIMIT 1',
            [(int) $schoolId]
        );
        if (!$admin) {
            flash('error', 'No school administrator account found to impersonate.');
            redirect(url('superadmin/schools/' . $schoolId));
        }

        $impId = Database::insert(
            'INSERT INTO support_impersonations (platform_user_id, school_id, school_user_id, mode, started_at, ip_address)
             VALUES (?, ?, ?, ?, NOW(), ?)',
            [PlatformAuth::id(), (int) $schoolId, (int) $admin['id'], $_POST['mode'] ?? 'read_only', $_SERVER['REMOTE_ADDR'] ?? null]
        );

        $_SESSION['impersonation'] = [
            'id' => $impId,
            'platform_user_id' => PlatformAuth::id(),
            'school_id' => (int) $schoolId,
            'school_user_id' => (int) $admin['id'],
            'mode' => $_POST['mode'] ?? 'read_only',
            'started_at' => date('c'),
        ];

        // Load school user into school session while keeping platform identity
        $admin['role_slug'] = Database::fetch('SELECT slug FROM roles WHERE id = ?', [(int) $admin['role_id']])['slug'] ?? 'school_admin';
        $admin['role_name'] = 'Support Impersonation';
        $admin['school_name'] = $school['name'];
        unset($admin['password']);
        $_SESSION['user_id'] = (int) $admin['id'];
        $_SESSION['school_id'] = (int) $schoolId;
        $_SESSION['role_id'] = (int) $admin['role_id'];
        $_SESSION['role_slug'] = $admin['role_slug'];
        $_SESSION['auth_context'] = 'school';
        Auth::clearCache();
        TenantContext::clear();

        PlatformAudit::log('impersonation.start', 'support', (int) $schoolId, 'support_impersonation', $impId);
        flash('success', 'Support mode started (read-only preferred).');
        redirect(url('dashboard'));
    }

    public function stop(): void
    {
        PlatformAuth::requireLogin();
        $this->requireCsrf();
        if (!empty($_SESSION['impersonation']['id'])) {
            Database::execute(
                'UPDATE support_impersonations SET ended_at = NOW() WHERE id = ?',
                [(int) $_SESSION['impersonation']['id']]
            );
            PlatformAudit::log('impersonation.end', 'support', (int) ($_SESSION['impersonation']['school_id'] ?? 0), 'support_impersonation', (int) $_SESSION['impersonation']['id']);
        }
        unset($_SESSION['impersonation'], $_SESSION['user_id'], $_SESSION['school_id'], $_SESSION['role_id'], $_SESSION['role_slug']);
        $_SESSION['auth_context'] = 'platform';
        Auth::clearCache();
        TenantContext::clear();
        flash('success', 'Returned to platform console.');
        redirect(url('superadmin/dashboard'));
    }
}
