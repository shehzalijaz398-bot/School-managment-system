<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use Core\Controller;
use Core\PlatformAuth;

final class PlatformAuthController extends Controller
{
    public function showLogin(): void
    {
        if (PlatformAuth::check()) {
            redirect(url('superadmin/dashboard'));
            return;
        }

        $this->view('platform/auth/login', [
            'title' => 'Super Admin Console Login',
        ], 'layouts/guest');
    }

    public function login(): void
    {
        $this->requireCsrf();

        $data = $this->validate($_POST, [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (PlatformAuth::attempt($data['email'], $data['password'])) {
            flash('success', 'Welcome to the SaaS Super Admin Control Panel.');
            redirect(url('superadmin/dashboard'));
            return;
        }

        flash('error', 'Invalid platform administrator credentials or account locked.');
        flash('old', ['email' => $data['email']]);
        redirect(url('superadmin/login'));
    }

    public function logout(): void
    {
        PlatformAuth::logout();
        flash('success', 'Logged out of platform console.');
        redirect(url('superadmin/login'));
    }
}
