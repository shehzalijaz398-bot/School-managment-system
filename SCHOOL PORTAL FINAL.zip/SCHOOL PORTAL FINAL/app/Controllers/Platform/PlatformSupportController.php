<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformSupportController extends Controller
{
    private function checkSchema(): void
    {
        try { Database::execute("ALTER TABLE support_ticket_messages ADD COLUMN is_internal TINYINT(1) DEFAULT 0"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE support_ticket_messages ADD COLUMN attachments TEXT NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE support_tickets ADD COLUMN last_reply_at DATETIME NULL"); } catch (\Throwable $e) {}
        try { Database::execute("ALTER TABLE support_tickets ADD COLUMN resolved_at DATETIME NULL"); } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('support.manage');
        $this->checkSchema();

        $query = 'SELECT t.*, s.name AS school_name, pu.name as assigned_name
                  FROM support_tickets t
                  INNER JOIN schools s ON s.id = t.school_id
                  LEFT JOIN platform_users pu ON pu.id = t.assigned_to
                  WHERE s.deleted_at IS NULL';
        
        $params = [];

        if (!empty($_GET['status'])) {
            $query .= ' AND t.status = ?';
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['priority'])) {
            $query .= ' AND t.priority = ?';
            $params[] = $_GET['priority'];
        }
        if (!empty($_GET['school_id'])) {
            $query .= ' AND t.school_id = ?';
            $params[] = (int) $_GET['school_id'];
        }
        if (!empty($_GET['q'])) {
            $query .= ' AND (t.ticket_number LIKE ? OR t.subject LIKE ?)';
            $params[] = '%' . $_GET['q'] . '%';
            $params[] = '%' . $_GET['q'] . '%';
        }

        $query .= ' ORDER BY t.updated_at DESC LIMIT 200';
        $tickets = Database::fetchAll($query, $params);

        $analytics = [
            'total' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets')['c'] ?? 0),
            'open' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets WHERE status="open"')['c'] ?? 0),
            'pending' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets WHERE status="waiting"')['c'] ?? 0),
            'in_progress' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets WHERE status="in_progress"')['c'] ?? 0),
            'resolved' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets WHERE status IN ("resolved", "closed")')['c'] ?? 0),
            'urgent' => (int) (Database::fetch('SELECT COUNT(id) as c FROM support_tickets WHERE priority="urgent" AND status NOT IN ("resolved", "closed")')['c'] ?? 0),
        ];

        $schools = Database::fetchAll('SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name');
        
        $this->view('platform/support/index', [
            'title' => 'Support / Helpdesk',
            'tickets' => $tickets,
            'analytics' => $analytics,
            'schools' => $schools,
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function show(string $id): void
    {
        PlatformAuth::requirePermission('support.manage');
        $this->checkSchema();
        
        $ticket = Database::fetch(
            'SELECT t.*, s.name AS school_name, pu.name as assigned_name 
             FROM support_tickets t 
             INNER JOIN schools s ON s.id = t.school_id 
             LEFT JOIN platform_users pu ON pu.id = t.assigned_to 
             WHERE t.id = ?',
            [(int) $id]
        );
        
        if (!$ticket) {
            flash('error', 'Ticket not found.');
            redirect(url('superadmin/support'));
        }

        $messages = Database::fetchAll(
            'SELECT m.*, 
                CASE 
                    WHEN m.sender_type = "platform" THEN (SELECT name FROM platform_users WHERE id = m.sender_id)
                    ELSE (SELECT name FROM users WHERE id = m.sender_id) 
                END as sender_name
             FROM support_ticket_messages m 
             WHERE m.ticket_id = ? 
             ORDER BY m.id ASC', 
            [(int) $id]
        );

        $agents = Database::fetchAll('SELECT id, name FROM platform_users WHERE status = 1');

        $this->view('platform/support/show', [
            'title' => 'Ticket: ' . $ticket['ticket_number'],
            'ticket' => $ticket,
            'messages' => $messages,
            'agents' => $agents
        ], 'platform/layouts/app');
    }

    public function reply(string $id): void
    {
        PlatformAuth::requirePermission('support.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $isInternal = isset($_POST['is_internal']) && $_POST['is_internal'] == '1' ? 1 : 0;
        $status = $_POST['status'] ?? 'in_progress';
        
        Database::insert(
            'INSERT INTO support_ticket_messages (ticket_id, sender_type, sender_id, message, is_internal, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
            [(int) $id, 'platform', PlatformAuth::id(), $_POST['message'], $isInternal]
        );
        
        $updateSql = 'UPDATE support_tickets SET status = ?, last_reply_at = NOW(), updated_at = NOW()';
        $params = [$status];

        if (!empty($_POST['assign_to'])) {
            $updateSql .= ', assigned_to = ?';
            $params[] = (int) $_POST['assign_to'];
        }

        if ($status === 'resolved' || $status === 'closed') {
            $updateSql .= ', resolved_at = NOW()';
        }

        $updateSql .= ' WHERE id = ?';
        $params[] = (int) $id;
        
        Database::execute($updateSql, $params);
        
        PlatformAudit::log('ticket.reply', 'support_tickets', null, 'ticket', (int) $id, null, ['is_internal' => $isInternal, 'status' => $status]);

        flash('success', $isInternal ? 'Internal note added.' : 'Reply sent to school.');
        redirect(url('superadmin/support/' . $id));
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('support.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $schoolId = (int) $_POST['school_id'];
        $subject = trim($_POST['subject']);
        
        // Find primary owner
        $owner = Database::fetch('SELECT id FROM users WHERE school_id = ? AND role = "school_owner" ORDER BY id LIMIT 1', [$schoolId]);
        if (!$owner) {
            flash('error', 'School has no owner to create ticket for.');
            redirect(url('superadmin/support'));
        }

        $ticketNumber = 'TK-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid()), 0, 6));

        $ticketId = Database::insert(
            'INSERT INTO support_tickets (ticket_number, school_id, created_by, category, priority, subject, status, assigned_to, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, "open", ?, NOW(), NOW())',
            [
                $ticketNumber,
                $schoolId,
                $owner['id'],
                $_POST['category'] ?? 'other',
                $_POST['priority'] ?? 'medium',
                $subject,
                PlatformAuth::id()
            ]
        );

        Database::insert(
            'INSERT INTO support_ticket_messages (ticket_id, sender_type, sender_id, message, created_at) VALUES (?, ?, ?, ?, NOW())',
            [$ticketId, 'platform', PlatformAuth::id(), $_POST['message']]
        );

        PlatformAudit::log('ticket.create', 'support_tickets', null, 'ticket', (int) $ticketId);
        flash('success', 'Ticket created successfully.');
        redirect(url('superadmin/support/' . $ticketId));
    }
}
