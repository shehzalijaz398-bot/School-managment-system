<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformAnnouncementController extends Controller
{
    private function checkSchema(): void
    {
        // Ensure new columns exist for advanced announcements
        try {
            Database::execute('ALTER TABLE announcements ADD COLUMN is_platform TINYINT(1) NOT NULL DEFAULT 0');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements ADD COLUMN type VARCHAR(50) DEFAULT "general"');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements ADD COLUMN priority VARCHAR(50) DEFAULT "normal"');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements ADD COLUMN expiry_date DATETIME NULL');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements ADD COLUMN target_data TEXT NULL');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements MODIFY COLUMN audience VARCHAR(50) NOT NULL DEFAULT "all"');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements MODIFY COLUMN status VARCHAR(30) NOT NULL DEFAULT "draft"');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements DROP FOREIGN KEY fk_ann_user');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements MODIFY COLUMN created_by BIGINT UNSIGNED NULL');
        } catch (\Throwable $e) {}
        try {
            Database::execute('ALTER TABLE announcements MODIFY COLUMN school_id BIGINT UNSIGNED NULL');
        } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $this->checkSchema();
        
        $query = 'SELECT a.*, pu.name AS author, s.name AS target_school_name 
                  FROM announcements a 
                  LEFT JOIN platform_users pu ON pu.id = a.created_by AND a.is_platform = 1
                  LEFT JOIN schools s ON s.id = a.school_id
                  WHERE a.is_platform = 1';
                  
        $params = [];
        if (!empty($_GET['status'])) {
            $query .= ' AND a.status = ?';
            $params[] = $_GET['status'];
        }
        $query .= ' ORDER BY a.id DESC LIMIT 200';
        
        $items = Database::fetchAll($query, $params);
        
        // Analytics
        $total = count($items);
        $published = count(array_filter($items, fn($i) => $i['status'] === 'published'));
        $draft = count(array_filter($items, fn($i) => $i['status'] === 'draft'));
        $scheduled = count(array_filter($items, fn($i) => $i['status'] === 'scheduled'));

        $this->view('platform/announcements/index', [
            'title' => 'Platform Announcements',
            'items' => $items,
            'analytics' => ['total' => $total, 'published' => $published, 'draft' => $draft, 'scheduled' => $scheduled],
            'schools' => Database::fetchAll('SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name ASC'),
            'plans' => Database::fetchAll('SELECT id, name FROM plans WHERE status = 1'),
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $this->requireCsrf();
        $this->checkSchema();
        
        $audience = $_POST['audience'] ?? 'all';
        $schoolId = null;
        $targetData = null;
        
        if ($audience === 'specific_school' && !empty($_POST['school_id'])) {
            $schoolId = (int) $_POST['school_id'];
        } elseif (in_array($audience, ['by_status', 'by_plan', 'by_country'])) {
            $targetData = json_encode([
                'status' => $_POST['target_status'] ?? null,
                'plan_id' => $_POST['target_plan_id'] ?? null,
                'country' => $_POST['target_country'] ?? null,
            ]);
        }
        
        $status = $_POST['status'] ?? 'draft';
        $publishedAt = ($status === 'published') ? date('Y-m-d H:i:s') : (empty($_POST['published_at']) ? null : $_POST['published_at']);

        $id = Database::insert(
            'INSERT INTO announcements (title, body, type, priority, audience, school_id, target_data, is_platform, status, published_at, expiry_date, created_by, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, NOW(), NOW())',
            [
                $_POST['title'],
                $_POST['body'],
                $_POST['type'] ?? 'general',
                $_POST['priority'] ?? 'normal',
                $audience,
                $schoolId,
                $targetData,
                $status,
                $publishedAt,
                empty($_POST['expiry_date']) ? null : $_POST['expiry_date'],
                PlatformAuth::id(),
            ]
        );
        PlatformAudit::log('announcement.create', 'announcements', null, 'announcement', $id);
        flash('success', 'Announcement ' . $status . ' successfully.');
        redirect(url('superadmin/announcements'));
    }

    public function edit(string $id): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $announcement = Database::fetch('SELECT * FROM announcements WHERE id = ?', [(int) $id]);
        if (!$announcement) {
            flash('error', 'Announcement not found.');
            redirect(url('superadmin/announcements'));
        }

        $this->view('platform/announcements/edit', [
            'title' => 'Edit Announcement',
            'announcement' => $announcement,
            'schools' => Database::fetchAll('SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name ASC'),
            'plans' => Database::fetchAll('SELECT id, name FROM plans WHERE status = 1'),
        ], 'platform/layouts/app');
    }

    public function update(string $id): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $this->requireCsrf();

        $announcement = Database::fetch('SELECT id FROM announcements WHERE id = ?', [(int) $id]);
        if (!$announcement) {
            flash('error', 'Announcement not found.');
            redirect(url('superadmin/announcements'));
        }

        $audience = $_POST['audience'] ?? 'all';
        $schoolId = null;
        $targetData = null;
        
        if ($audience === 'specific_school' && !empty($_POST['school_id'])) {
            $schoolId = (int) $_POST['school_id'];
        } elseif (in_array($audience, ['by_status', 'by_plan', 'by_country'])) {
            $targetData = json_encode([
                'status' => $_POST['target_status'] ?? null,
                'plan_id' => $_POST['target_plan_id'] ?? null,
                'country' => $_POST['target_country'] ?? null,
            ]);
        }
        
        $status = $_POST['status'] ?? 'draft';
        $publishedAt = ($status === 'published' && $announcement['published_at'] === null) ? date('Y-m-d H:i:s') : ($_POST['published_at'] ?? $announcement['published_at']);

        Database::execute(
            'UPDATE announcements SET title=?, body=?, type=?, priority=?, audience=?, school_id=?, target_data=?, status=?, published_at=?, expiry_date=?, updated_at=NOW() WHERE id=?',
            [
                $_POST['title'],
                $_POST['body'],
                $_POST['type'] ?? 'general',
                $_POST['priority'] ?? 'normal',
                $audience,
                $schoolId,
                $targetData,
                $status,
                $publishedAt,
                empty($_POST['expiry_date']) ? null : $_POST['expiry_date'],
                (int) $id,
            ]
        );

        PlatformAudit::log('announcement.update', 'announcements', null, 'announcement', (int) $id);
        flash('success', 'Announcement updated.');
        redirect(url('superadmin/announcements'));
    }
    
    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $this->requireCsrf();
        $status = $_POST['status'] ?? '';
        $publishedAt = null;
        if ($status === 'published') $publishedAt = date('Y-m-d H:i:s');
        
        if ($publishedAt) {
            Database::execute('UPDATE announcements SET status=?, published_at=? WHERE id=?', [$status, $publishedAt, (int)$id]);
        } else {
            Database::execute('UPDATE announcements SET status=? WHERE id=?', [$status, (int)$id]);
        }
        
        PlatformAudit::log('announcement.status', 'announcements', null, 'announcement', (int) $id);
        flash('success', 'Announcement status updated.');
        redirect(url('superadmin/announcements'));
    }

    public function destroy(string $id): void
    {
        PlatformAuth::requirePermission('announcements.manage');
        $this->requireCsrf();
        Database::execute('DELETE FROM announcements WHERE id = ?', [(int) $id]);
        PlatformAudit::log('announcement.delete', 'announcements', null, 'announcement', (int) $id);
        flash('success', 'Announcement deleted permanently.');
        redirect(url('superadmin/announcements'));
    }
}
