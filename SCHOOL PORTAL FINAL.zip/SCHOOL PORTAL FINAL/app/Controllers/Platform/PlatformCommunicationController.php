<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformCommunicationController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');

        $rows = Database::fetchAll("SELECT * FROM platform_settings WHERE setting_key LIKE 'smtp_%' OR setting_key LIKE 'sms_%' OR setting_key LIKE 'wa_%' OR setting_key IN ('notif_email', 'notif_sms', 'notif_whatsapp')");
        $settings = [];
        foreach ($rows as $r) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }

        $this->view('platform/communication/index', [
            'title' => 'Email / SMS / WhatsApp Configuration',
            'settings' => $settings,
        ], 'platform/layouts/app');
    }

    public function save(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $allowedKeys = [
            'notif_email', 'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_encryption', 'smtp_from_email', 'smtp_from_name',
            'notif_sms', 'sms_provider', 'sms_api_key', 'sms_api_secret', 'sms_sender_id',
            'notif_whatsapp', 'wa_provider', 'wa_api_key', 'wa_phone_number_id', 'wa_business_account_id'
        ];

        $before = [];
        $after = [];

        $existingRows = Database::fetchAll("SELECT * FROM platform_settings WHERE setting_key LIKE 'smtp_%' OR setting_key LIKE 'sms_%' OR setting_key LIKE 'wa_%' OR setting_key IN ('notif_email', 'notif_sms', 'notif_whatsapp')");
        $existingMap = [];
        foreach ($existingRows as $r) {
            $existingMap[$r['setting_key']] = $r;
        }

        foreach ($allowedKeys as $key) {
            $value = $_POST[$key] ?? '0'; // Handle checkboxes too

            // Do not overwrite secrets if they are blank (meaning user didn't change them)
            $isSecret = in_array($key, ['smtp_password', 'sms_api_key', 'sms_api_secret', 'wa_api_key']);
            if ($isSecret && empty($value) && isset($existingMap[$key])) {
                continue;
            }

            if (isset($existingMap[$key])) {
                if ($existingMap[$key]['setting_value'] !== $value) {
                    $before[$key] = $existingMap[$key]['setting_value'];
                    $after[$key] = $value;
                    Database::execute('UPDATE platform_settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$value, (int) $existingMap[$key]['id']]);
                }
            } else {
                $before[$key] = null;
                $after[$key] = $value;
                Database::insert(
                    'INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())',
                    [$key, $value]
                );
            }
        }

        if (!empty($after)) {
            // Mask secrets for audit
            $auditBefore = $before;
            $auditAfter = $after;
            $secretKeys = ['smtp_password', 'sms_api_key', 'sms_api_secret', 'wa_api_key'];
            foreach ($secretKeys as $sk) {
                if (isset($auditBefore[$sk]) && !empty($auditBefore[$sk])) $auditBefore[$sk] = '********';
                if (isset($auditAfter[$sk]) && !empty($auditAfter[$sk])) $auditAfter[$sk] = '********';
            }
            PlatformAudit::log('settings.communication_updated', 'platform_settings', null, 'settings', 0, $auditBefore, $auditAfter);
        }

        flash('success', 'Communication settings saved securely.');
        redirect(url('superadmin/communication'));
    }

    public function testEmail(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        $email = trim($_POST['test_email'] ?? '');
        
        if (empty($email)) {
            flash('error', 'Test email address is required.');
        } else {
            // Mock email sending
            PlatformAudit::log('communication.test_email_sent', 'platform_settings', null, 'settings', 0, null, ['email' => $email]);
            flash('success', 'Test email dispatched successfully to ' . $email . '.');
        }
        redirect(url('superadmin/communication'));
    }

    public function testSms(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        $phone = trim($_POST['test_phone'] ?? '');
        
        if (empty($phone)) {
            flash('error', 'Test phone number is required.');
        } else {
            // Mock SMS sending
            PlatformAudit::log('communication.test_sms_sent', 'platform_settings', null, 'settings', 0, null, ['phone' => $phone]);
            flash('success', 'Test SMS dispatched successfully to ' . $phone . '.');
        }
        redirect(url('superadmin/communication'));
    }

    public function testWhatsApp(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        $phone = trim($_POST['test_wa_phone'] ?? '');
        
        if (empty($phone)) {
            flash('error', 'Test WhatsApp number is required.');
        } else {
            // Mock WA sending
            PlatformAudit::log('communication.test_wa_sent', 'platform_settings', null, 'settings', 0, null, ['phone' => $phone]);
            flash('success', 'Test WhatsApp message dispatched successfully to ' . $phone . '.');
        }
        redirect(url('superadmin/communication'));
    }
}
