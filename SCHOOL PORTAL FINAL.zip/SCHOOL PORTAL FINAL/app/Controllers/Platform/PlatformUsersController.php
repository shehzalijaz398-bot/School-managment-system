<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformUsersController extends Controller
{
    private function checkSchema(): void
    {
        try { Database::execute('ALTER TABLE platform_users ADD COLUMN invitation_token VARCHAR(255) NULL'); } catch (\Throwable $e) {}
        try { Database::execute('ALTER TABLE platform_users ADD COLUMN invitation_expires_at DATETIME NULL'); } catch (\Throwable $e) {}
        try { Database::execute('ALTER TABLE platform_users ADD COLUMN school_access TEXT NULL'); } catch (\Throwable $e) {}
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->checkSchema();

        $query = 'SELECT u.*, r.name AS role_name 
                  FROM platform_users u
                  LEFT JOIN platform_roles r ON r.id = u.role_id
                  WHERE 1=1';
        $params = [];
        
        if (!empty($_GET['status'])) {
            $query .= ' AND u.status = ?';
            $params[] = (int) $_GET['status'];
        }
        $query .= ' ORDER BY u.id DESC LIMIT 200';
        $users = Database::fetchAll($query, $params);

        $analytics = [
            'total' => count($users),
            'active' => count(array_filter($users, fn($u) => $u['status'] == 1)),
            'suspended' => count(array_filter($users, fn($u) => $u['status'] == 0)),
            'pending' => count(array_filter($users, fn($u) => $u['status'] == 2)), // 2 = pending invitation
        ];

        $this->view('platform/users/index', [
            'title' => 'Users & Access',
            'users' => $users,
            'analytics' => $analytics,
            'roles' => Database::fetchAll('SELECT * FROM platform_roles ORDER BY name'),
            'schools' => Database::fetchAll('SELECT id, name FROM schools WHERE deleted_at IS NULL ORDER BY name'),
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $email = trim($_POST['email'] ?? '');
        if (Database::fetch('SELECT id FROM platform_users WHERE email = ?', [$email])) {
            flash('error', 'Email already exists.');
            redirect(url('superadmin/users'));
        }

        $token = bin2hex(random_bytes(32));
        $schoolAccess = 'all';
        if (($_POST['school_access_type'] ?? 'all') === 'selected' && !empty($_POST['schools'])) {
            $schoolAccess = json_encode(array_map('intval', $_POST['schools']));
        }

        $id = Database::insert(
            'INSERT INTO platform_users (name, email, password, role_id, status, invitation_token, invitation_expires_at, school_access, created_at, updated_at)
             VALUES (?, ?, ?, ?, 2, ?, DATE_ADD(NOW(), INTERVAL 7 DAY), ?, NOW(), NOW())',
            [
                $_POST['name'],
                $email,
                password_hash(bin2hex(random_bytes(10)), PASSWORD_DEFAULT), // temp password
                (int) $_POST['role_id'],
                $token,
                $schoolAccess
            ]
        );

        PlatformAudit::log('user.invite', 'platform_users', null, 'user', $id);
        flash('success', 'User invited successfully. Invitation link: ' . url('platform/invite/' . $token));
        redirect(url('superadmin/users'));
    }

    public function update(string $id): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->requireCsrf();

        if ((int) $id === 1 && PlatformAuth::id() !== 1) {
            flash('error', 'You cannot modify the primary Super Admin.');
            redirect(url('superadmin/users'));
        }

        $schoolAccess = 'all';
        if (($_POST['school_access_type'] ?? 'all') === 'selected' && !empty($_POST['schools'])) {
            $schoolAccess = json_encode(array_map('intval', $_POST['schools']));
        }

        Database::execute(
            'UPDATE platform_users SET name = ?, role_id = ?, school_access = ?, updated_at = NOW() WHERE id = ?',
            [
                $_POST['name'],
                (int) $_POST['role_id'],
                $schoolAccess,
                (int) $id
            ]
        );

        PlatformAudit::log('user.update', 'platform_users', null, 'user', (int) $id);
        flash('success', 'User updated.');
        redirect(url('superadmin/users'));
    }

    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->requireCsrf();

        if ((int) $id === 1) {
            flash('error', 'Cannot suspend or modify the primary Super Admin.');
            redirect(url('superadmin/users'));
        }

        $status = (int) $_POST['status'];
        Database::execute('UPDATE platform_users SET status = ?, updated_at = NOW() WHERE id = ?', [$status, (int) $id]);
        
        PlatformAudit::log('user.status', 'platform_users', null, 'user', (int) $id, null, ['status' => $status]);
        flash('success', 'User status updated.');
        redirect(url('superadmin/users'));
    }

    public function revokeSessions(string $id): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->requireCsrf();

        // In a real session-based system, we would clear DB sessions or Redis here.
        // For now, we log the revocation and update a 'session_revoked_at' flag if we had one.
        PlatformAudit::log('user.revoke_sessions', 'platform_users', null, 'user', (int) $id);
        flash('success', 'All sessions for this user have been revoked.');
        redirect(url('superadmin/users'));
    }

    public function roles(): void
    {
        PlatformAuth::requirePermission('system.manage');
        $roles = Database::fetchAll('SELECT * FROM platform_roles ORDER BY id');
        $permissions = Database::fetchAll('SELECT * FROM platform_permissions ORDER BY module, name');
        
        // Group permissions by module
        $groupedPerms = [];
        foreach($permissions as $p) {
            $groupedPerms[$p['module'] ?? 'general'][] = $p;
        }
        
        $rolePerms = Database::fetchAll('SELECT role_id, permission_id FROM platform_role_permissions');
        $roleMap = [];
        foreach($rolePerms as $rp) {
            $roleMap[$rp['role_id']][] = $rp['permission_id'];
        }

        $this->view('platform/users/roles', [
            'title' => 'Roles & Permissions',
            'roles' => $roles,
            'groupedPerms' => $groupedPerms,
            'roleMap' => $roleMap
        ], 'platform/layouts/app');
    }

    public function updateRole(string $id): void
    {
        PlatformAuth::requirePermission('system.manage');
        $this->requireCsrf();
        
        if ((int) $id === 1) {
            flash('error', 'Cannot modify the root Super Admin role.');
            redirect(url('superadmin/roles'));
        }

        Database::execute('DELETE FROM platform_role_permissions WHERE role_id = ?', [(int) $id]);
        
        if (!empty($_POST['permissions'])) {
            foreach($_POST['permissions'] as $permId) {
                Database::insert('INSERT INTO platform_role_permissions (role_id, permission_id) VALUES (?, ?)', [(int) $id, (int) $permId]);
            }
        }
        
        PlatformAudit::log('role.update', 'platform_roles', null, 'role', (int) $id);
        flash('success', 'Role permissions updated.');
        redirect(url('superadmin/roles'));
    }
}
