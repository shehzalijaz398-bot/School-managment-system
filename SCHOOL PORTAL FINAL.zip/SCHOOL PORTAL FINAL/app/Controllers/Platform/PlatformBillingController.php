<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\BillingService;
use App\Services\Platform\PlatformAudit;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformBillingController extends Controller
{
    public function invoices(): void
    {
        PlatformAuth::requirePermission('billing.view');
        
        $query = 'SELECT i.*, s.name AS school_name, s.code AS school_code, p.name AS plan_name 
                  FROM subscription_invoices i
                  INNER JOIN schools s ON s.id = i.school_id
                  LEFT JOIN plans p ON p.id = s.plan_id 
                  WHERE s.deleted_at IS NULL';
        
        $params = [];
        if (!empty($_GET['status'])) {
            $query .= ' AND i.status = ?';
            $params[] = $_GET['status'];
        }
        
        $query .= ' ORDER BY i.id DESC LIMIT 200';
        $invoices = Database::fetchAll($query, $params);

        // Billing Analytics
        $totalInvoiced = (float) (Database::fetch('SELECT SUM(total_amount) as t FROM subscription_invoices WHERE status != "cancelled"')['t'] ?? 0);
        $totalPaid = (float) (Database::fetch('SELECT SUM(paid_amount) as t FROM subscription_invoices WHERE status != "cancelled"')['t'] ?? 0);
        $outstanding = $totalInvoiced - $totalPaid;
        
        $overdueAmount = (float) (Database::fetch('SELECT SUM(total_amount - paid_amount) as t FROM subscription_invoices WHERE status IN ("pending", "issued", "overdue", "partially_paid") AND due_date < CURRENT_DATE()')['t'] ?? 0);
        $thisMonthRev = (float) (Database::fetch('SELECT SUM(amount) as t FROM subscription_payments WHERE payment_status = "paid" AND MONTH(paid_at) = MONTH(CURRENT_DATE()) AND YEAR(paid_at) = YEAR(CURRENT_DATE())')['t'] ?? 0);

        $this->view('platform/invoices/index', [
            'title' => 'SaaS Invoices & Billing',
            'invoices' => $invoices,
            'schools' => Database::fetchAll('SELECT id, name, code FROM schools WHERE deleted_at IS NULL ORDER BY name'),
            'analytics' => [
                'total_invoiced' => $totalInvoiced,
                'total_paid' => $totalPaid,
                'outstanding' => $outstanding,
                'overdue' => $overdueAmount,
                'this_month' => $thisMonthRev
            ],
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function storeInvoice(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();
        $schoolId = (int) $_POST['school_id'];
        $amount = (float) $_POST['amount'];
        $id = BillingService::createInvoice($schoolId, [
            'billing_period_start' => $_POST['billing_period_start'] ?? date('Y-m-01'),
            'billing_period_end' => $_POST['billing_period_end'] ?? date('Y-m-t'),
            'due_date' => $_POST['due_date'] ?? date('Y-m-d', strtotime('+7 days')),
            'notes' => $_POST['notes'] ?? null,
        ], [['description' => $_POST['description'] ?? 'Subscription fee', 'amount' => $amount]]);
        PlatformAudit::log('billing.invoice_created', 'subscription_invoices', $schoolId, 'invoice', $id);
        flash('success', 'Invoice created.');
        redirect(url('superadmin/invoices/' . $id));
    }

    public function showInvoice(string $id): void
    {
        PlatformAuth::requirePermission('billing.view');
        $invoice = Database::fetch(
            'SELECT i.*, s.name AS school_name, s.code AS school_code, s.address, s.email, s.phone, p.name AS plan_name 
             FROM subscription_invoices i
             INNER JOIN schools s ON s.id = i.school_id 
             LEFT JOIN plans p ON p.id = s.plan_id
             WHERE i.id = ?',
            [(int) $id]
        );
        if (!$invoice) {
            flash('error', 'Invoice not found.');
            redirect(url('superadmin/invoices'));
        }
        $this->view('platform/invoices/show', [
            'title' => 'Invoice ' . $invoice['invoice_no'],
            'invoice' => $invoice,
            'items' => Database::fetchAll('SELECT * FROM subscription_invoice_items WHERE invoice_id = ?', [(int) $id]),
            'payments' => Database::fetchAll('SELECT * FROM subscription_payments WHERE invoice_id = ? ORDER BY id DESC', [(int) $id]),
        ], 'platform/layouts/app');
    }
    
    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();
        $status = $_POST['status'] ?? '';
        $allowed = ['draft', 'issued', 'pending', 'cancelled'];
        
        if (in_array($status, $allowed)) {
            Database::execute('UPDATE subscription_invoices SET status = ? WHERE id = ?', [$status, (int)$id]);
            $inv = Database::fetch('SELECT school_id FROM subscription_invoices WHERE id = ?', [(int)$id]);
            PlatformAudit::log('billing.invoice_status', 'subscription_invoices', (int)($inv['school_id']??0), 'invoice', (int)$id, null, ['status' => $status]);
            flash('success', 'Invoice status updated to ' . ucfirst($status));
        } else {
            flash('error', 'Invalid status transition.');
        }
        redirect(url('superadmin/invoices/' . $id));
    }

    public function printInvoice(string $id): void
    {
        PlatformAuth::requirePermission('billing.view');
        $invoice = Database::fetch(
            'SELECT i.*, s.name AS school_name, s.code AS school_code, s.address, s.email AS school_email
             FROM subscription_invoices i INNER JOIN schools s ON s.id = i.school_id WHERE i.id = ?',
            [(int) $id]
        );
        $this->view('platform/invoices/print', [
            'title' => 'Invoice ' . $invoice['invoice_no'],
            'invoice' => $invoice,
            'items' => Database::fetchAll('SELECT * FROM subscription_invoice_items WHERE invoice_id = ?', [(int) $id]),
            'platform' => platform_setting('platform_name', 'School Portal SaaS'),
        ], 'layouts/print');
    }

    public function payments(): void
    {
        PlatformAuth::requirePermission('billing.view');
        $this->view('platform/payments/index', [
            'title' => 'Payments',
            'payments' => Database::fetchAll(
                'SELECT sp.*, s.name AS school_name, i.invoice_no FROM subscription_payments sp
                 INNER JOIN schools s ON s.id = sp.school_id
                 INNER JOIN subscription_invoices i ON i.id = sp.invoice_id
                 WHERE s.deleted_at IS NULL
                 ORDER BY sp.id DESC LIMIT 200'
            ),
        ], 'platform/layouts/app');
    }

    public function storePayment(string $invoiceId): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();
        try {
            $inv = Database::fetch('SELECT school_id FROM subscription_invoices WHERE id = ?', [(int)$invoiceId]);
            BillingService::recordManualPayment(
                (int) $invoiceId,
                (float) $_POST['amount'],
                $_POST['payment_method'] ?? 'bank_transfer',
                $_POST['transaction_reference'] ?? null,
                $_POST['notes'] ?? null
            );
            PlatformAudit::log('billing.payment_recorded', 'subscription_payments', (int)($inv['school_id']??0), 'invoice', (int)$invoiceId, null, ['amount' => (float)$_POST['amount']]);
            flash('success', 'Payment recorded and verified.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }
        redirect(url('superadmin/invoices/' . $invoiceId));
    }
}
