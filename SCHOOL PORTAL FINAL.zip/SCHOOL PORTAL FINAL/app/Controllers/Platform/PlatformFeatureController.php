<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformFeatureController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_modules (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                module_key VARCHAR(100) NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                description TEXT NULL,
                category VARCHAR(100) DEFAULT 'General',
                is_core TINYINT(1) DEFAULT 0,
                is_enabled TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        $count = (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_modules')['c'] ?? 0);
        if ($count === 0) {
            $defaultModules = [
                ['core.dashboard', 'Dashboard', 'Central analytics and overview.', 'Core', 1, 1],
                ['core.settings', 'School Settings', 'School-level configuration and preferences.', 'Core', 1, 1],
                ['core.users', 'User Management', 'Manage school staff, teachers, and admins.', 'Core', 1, 1],
                
                ['academic.students', 'Student Management', 'Enrollment, student profiles, and history.', 'Academic', 0, 1],
                ['academic.attendance', 'Attendance Tracking', 'Daily attendance for students and staff.', 'Academic', 0, 1],
                ['academic.exams', 'Examinations', 'Exam scheduling, grading, and report cards.', 'Academic', 0, 1],
                ['academic.timetable', 'Timetable Management', 'Class scheduling and teacher assignments.', 'Academic', 0, 1],
                
                ['finance.fees', 'Fee Collection', 'Student billing, invoices, and payments.', 'Finance', 0, 1],
                ['finance.expenses', 'Expense Tracking', 'School expense management.', 'Finance', 0, 1],
                ['finance.payroll', 'Payroll', 'Staff salaries and payslips.', 'Finance', 0, 1],
                
                ['facility.library', 'Library Management', 'Books, issues, and returns.', 'Facilities', 0, 1],
                ['facility.transport', 'Transport Management', 'Vehicles, routes, and assignments.', 'Facilities', 0, 1],
                ['facility.hostel', 'Hostel Management', 'Dorms, rooms, and boarders.', 'Facilities', 0, 1],
                
                ['comms.messages', 'Messaging', 'Internal messaging between users.', 'Communication', 0, 1],
                ['comms.sms', 'SMS Integration', 'Send SMS alerts to parents/staff.', 'Communication', 0, 1]
            ];
            
            foreach ($defaultModules as $m) {
                Database::insert(
                    'INSERT INTO platform_modules (module_key, name, description, category, is_core, is_enabled, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
                    $m
                );
            }
        }
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $modules = Database::fetchAll('SELECT * FROM platform_modules ORDER BY category, name');
        
        // Group by category
        $grouped = [];
        foreach ($modules as $m) {
            $grouped[$m['category']][] = $m;
        }
        
        // Fetch plans to show plan availability
        $plans = Database::fetchAll('SELECT * FROM platform_plans WHERE status = "active"');
        
        $analytics = [
            'total' => count($modules),
            'enabled' => count(array_filter($modules, fn($m) => $m['is_enabled'] == 1)),
            'disabled' => count(array_filter($modules, fn($m) => $m['is_enabled'] == 0)),
            'core' => count(array_filter($modules, fn($m) => $m['is_core'] == 1)),
        ];

        $this->view('platform/features/index', [
            'title' => 'Features & Modules',
            'grouped' => $grouped,
            'plans' => $plans,
            'analytics' => $analytics
        ], 'platform/layouts/app');
    }

    public function toggle(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $module = Database::fetch('SELECT * FROM platform_modules WHERE id = ?', [(int) $id]);
        if (!$module) {
            flash('error', 'Module not found.');
            redirect(url('superadmin/features'));
        }

        if ($module['is_core'] == 1) {
            flash('error', 'Core modules cannot be disabled. They are required for the platform to function.');
            redirect(url('superadmin/features'));
        }

        $newState = $module['is_enabled'] == 1 ? 0 : 1;
        Database::execute('UPDATE platform_modules SET is_enabled = ?, updated_at = NOW() WHERE id = ?', [$newState, (int) $id]);

        PlatformAudit::log(
            'module.toggled',
            'platform_modules',
            null,
            'module',
            (int) $id,
            ['is_enabled' => $module['is_enabled']],
            ['is_enabled' => $newState]
        );

        $action = $newState === 1 ? 'enabled' : 'disabled';
        flash('success', "Module '{$module['name']}' has been {$action} globally.");
        redirect(url('superadmin/features'));
    }
}
