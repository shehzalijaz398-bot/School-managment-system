<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformTaxController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_taxes (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                type ENUM('inclusive', 'exclusive') NOT NULL DEFAULT 'exclusive',
                regions JSON NULL,
                status TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $rows = Database::fetchAll('SELECT * FROM platform_settings WHERE setting_key IN ("default_country", "default_currency", "default_timezone", "date_format", "number_format")');
        $settings = [];
        foreach ($rows as $r) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }

        $taxes = Database::fetchAll("SELECT * FROM platform_taxes ORDER BY created_at DESC");

        $this->view('platform/taxes/index', [
            'title' => 'Tax & Regional Settings',
            'settings' => $settings,
            'taxes' => $taxes
        ], 'platform/layouts/app');
    }

    public function saveSettings(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $keys = ['default_country', 'default_currency', 'default_timezone', 'date_format', 'number_format'];
        $before = [];
        $after = [];

        foreach ($keys as $key) {
            $value = (string) ($_POST[$key] ?? '');
            $existing = Database::fetch('SELECT id, setting_value FROM platform_settings WHERE setting_key = ?', [$key]);
            
            if ($existing) {
                if ($existing['setting_value'] !== $value) {
                    $before[$key] = $existing['setting_value'];
                    $after[$key] = $value;
                    Database::execute('UPDATE platform_settings SET setting_value = ?, updated_at = NOW() WHERE id = ?', [$value, (int)$existing['id']]);
                }
            } else {
                $before[$key] = null;
                $after[$key] = $value;
                Database::insert('INSERT INTO platform_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())', [$key, $value]);
            }
        }

        if (!empty($after)) {
            PlatformAudit::log('settings.regional_updated', 'platform_settings', null, 'settings', 0, $before, $after);
        }

        flash('success', 'Regional settings updated successfully.');
        redirect(url('superadmin/taxes'));
    }

    public function storeTax(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        $this->checkSchema();

        $name = trim($_POST['name'] ?? '');
        $rate = (float) ($_POST['rate'] ?? 0);
        $type = $_POST['type'] ?? 'exclusive';
        $status = isset($_POST['status']) ? 1 : 0;
        
        $regions = null;
        if (!empty($_POST['regions']) && is_string($_POST['regions'])) {
            $regionsArr = array_map('trim', explode(',', $_POST['regions']));
            $regionsArr = array_filter($regionsArr);
            if (!empty($regionsArr)) {
                $regions = json_encode(array_values($regionsArr));
            }
        }

        if (empty($name) || $rate <= 0) {
            flash('error', 'Tax name and a valid rate are required.');
            redirect(url('superadmin/taxes'));
        }

        Database::insert("
            INSERT INTO platform_taxes (name, rate, type, regions, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ", [$name, $rate, $type, $regions, $status]);

        PlatformAudit::log('taxes.created', 'platform_taxes', Database::lastInsertId(), 'tax', Database::lastInsertId(), null, ['name' => $name, 'rate' => $rate]);

        flash('success', 'Tax rule created.');
        redirect(url('superadmin/taxes'));
    }

    public function updateTax(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $name = trim($_POST['name'] ?? '');
        $rate = (float) ($_POST['rate'] ?? 0);
        $type = $_POST['type'] ?? 'exclusive';
        $status = isset($_POST['status']) ? 1 : 0;
        
        $regions = null;
        if (!empty($_POST['regions']) && is_string($_POST['regions'])) {
            $regionsArr = array_map('trim', explode(',', $_POST['regions']));
            $regionsArr = array_filter($regionsArr);
            if (!empty($regionsArr)) {
                $regions = json_encode(array_values($regionsArr));
            }
        }

        if (empty($name) || $rate <= 0) {
            flash('error', 'Tax name and a valid rate are required.');
            redirect(url('superadmin/taxes'));
        }

        Database::execute("
            UPDATE platform_taxes SET name = ?, rate = ?, type = ?, regions = ?, status = ?, updated_at = NOW()
            WHERE id = ?
        ", [$name, $rate, $type, $regions, $status, (int)$id]);

        PlatformAudit::log('taxes.updated', 'platform_taxes', (int)$id, 'tax', (int)$id, null, ['name' => $name, 'rate' => $rate]);

        flash('success', 'Tax rule updated.');
        redirect(url('superadmin/taxes'));
    }

    public function deleteTax(string $id): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();
        
        Database::execute("DELETE FROM platform_taxes WHERE id = ?", [(int)$id]);
        PlatformAudit::log('taxes.deleted', 'platform_taxes', (int)$id, 'tax', (int)$id);
        
        flash('success', 'Tax rule deleted.');
        redirect(url('superadmin/taxes'));
    }
}
