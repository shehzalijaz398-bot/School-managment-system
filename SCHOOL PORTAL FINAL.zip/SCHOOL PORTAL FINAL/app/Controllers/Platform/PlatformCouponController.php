<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformCouponController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_coupons (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(50) NOT NULL UNIQUE,
                description TEXT NULL,
                type ENUM('percentage', 'fixed') NOT NULL DEFAULT 'percentage',
                amount DECIMAL(12,2) NOT NULL,
                min_subscription_amount DECIMAL(12,2) DEFAULT 0.00,
                applicable_plans JSON NULL,
                valid_from DATETIME NULL,
                valid_until DATETIME NULL,
                usage_limit INT NULL,
                per_school_limit INT DEFAULT 1,
                used_count INT DEFAULT 0,
                status TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_coupon_usage (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                coupon_id BIGINT UNSIGNED NOT NULL,
                school_id BIGINT UNSIGNED NOT NULL,
                invoice_id BIGINT UNSIGNED NULL,
                discount_amount DECIMAL(12,2) NOT NULL,
                created_at DATETIME NOT NULL,
                FOREIGN KEY (coupon_id) REFERENCES platform_coupons(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->checkSchema();

        $coupons = Database::fetchAll("SELECT * FROM platform_coupons ORDER BY created_at DESC");

        $now = time();
        foreach ($coupons as $k => $c) {
            $statusStr = 'active';
            if ($c['status'] == 0) {
                $statusStr = 'disabled';
            } elseif ($c['valid_from'] && strtotime($c['valid_from']) > $now) {
                $statusStr = 'scheduled';
            } elseif ($c['valid_until'] && strtotime($c['valid_until']) < $now) {
                $statusStr = 'expired';
            } elseif ($c['usage_limit'] && $c['used_count'] >= $c['usage_limit']) {
                $statusStr = 'exhausted';
            }
            $coupons[$k]['computed_status'] = $statusStr;
        }

        $analytics = [
            'total' => count($coupons),
            'active' => count(array_filter($coupons, fn($c) => $c['computed_status'] === 'active')),
            'exhausted' => count(array_filter($coupons, fn($c) => $c['computed_status'] === 'exhausted')),
            'total_used' => array_sum(array_column($coupons, 'used_count'))
        ];

        $this->view('platform/coupons/index', [
            'title' => 'Coupons & Discounts',
            'coupons' => $coupons,
            'analytics' => $analytics
        ], 'platform/layouts/app');
    }

    public function create(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->checkSchema();
        $plans = Database::fetchAll("SELECT id, name FROM plans WHERE status = 1");

        $this->view('platform/coupons/create', [
            'title' => 'Create Coupon',
            'plans' => $plans
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();
        
        $code = strtoupper(trim($_POST['code'] ?? ''));
        if (empty($code)) {
            flash('error', 'Coupon code is required.');
            redirect(url('superadmin/coupons/create'));
        }

        $exists = Database::fetch('SELECT id FROM platform_coupons WHERE code = ?', [$code]);
        if ($exists) {
            flash('error', 'Coupon code already exists.');
            redirect(url('superadmin/coupons/create'));
        }

        $applicable = isset($_POST['plans']) && is_array($_POST['plans']) ? json_encode($_POST['plans']) : null;
        
        $params = [
            $code,
            $_POST['description'] ?? '',
            $_POST['type'] ?? 'percentage',
            (float)($_POST['amount'] ?? 0),
            (float)($_POST['min_subscription_amount'] ?? 0),
            $applicable,
            empty($_POST['valid_from']) ? null : $_POST['valid_from'],
            empty($_POST['valid_until']) ? null : $_POST['valid_until'],
            empty($_POST['usage_limit']) ? null : (int)$_POST['usage_limit'],
            (int)($_POST['per_school_limit'] ?? 1),
            isset($_POST['status']) ? 1 : 0
        ];

        Database::insert("
            INSERT INTO platform_coupons 
            (code, description, type, amount, min_subscription_amount, applicable_plans, valid_from, valid_until, usage_limit, per_school_limit, status, created_at, updated_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ", $params);

        $id = Database::lastInsertId();
        PlatformAudit::log('coupon.created', 'platform_coupons', $id, 'coupon', $id, null, ['code' => $code]);

        flash('success', 'Coupon created successfully.');
        redirect(url('superadmin/coupons'));
    }

    public function edit(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->checkSchema();
        
        $coupon = Database::fetch("SELECT * FROM platform_coupons WHERE id = ?", [(int) $id]);
        if (!$coupon) {
            flash('error', 'Coupon not found.');
            redirect(url('superadmin/coupons'));
        }
        
        $coupon['plans'] = $coupon['applicable_plans'] ? json_decode($coupon['applicable_plans'], true) : [];
        $plans = Database::fetchAll("SELECT id, name FROM plans");

        $this->view('platform/coupons/edit', [
            'title' => 'Edit Coupon: ' . $coupon['code'],
            'coupon' => $coupon,
            'plans' => $plans
        ], 'platform/layouts/app');
    }

    public function update(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $coupon = Database::fetch("SELECT * FROM platform_coupons WHERE id = ?", [(int) $id]);
        if (!$coupon) redirect(url('superadmin/coupons'));

        $code = strtoupper(trim($_POST['code'] ?? ''));
        $exists = Database::fetch('SELECT id FROM platform_coupons WHERE code = ? AND id != ?', [$code, (int) $id]);
        if ($exists) {
            flash('error', 'Coupon code already exists.');
            redirect(url('superadmin/coupons/' . $id . '/edit'));
        }

        $applicable = isset($_POST['plans']) && is_array($_POST['plans']) ? json_encode($_POST['plans']) : null;
        
        $params = [
            $code,
            $_POST['description'] ?? '',
            $_POST['type'] ?? 'percentage',
            (float)($_POST['amount'] ?? 0),
            (float)($_POST['min_subscription_amount'] ?? 0),
            $applicable,
            empty($_POST['valid_from']) ? null : $_POST['valid_from'],
            empty($_POST['valid_until']) ? null : $_POST['valid_until'],
            empty($_POST['usage_limit']) ? null : (int)$_POST['usage_limit'],
            (int)($_POST['per_school_limit'] ?? 1),
            isset($_POST['status']) ? 1 : 0,
            (int) $id
        ];

        Database::execute("
            UPDATE platform_coupons SET 
            code = ?, description = ?, type = ?, amount = ?, min_subscription_amount = ?, applicable_plans = ?, 
            valid_from = ?, valid_until = ?, usage_limit = ?, per_school_limit = ?, status = ?, updated_at = NOW()
            WHERE id = ?
        ", $params);

        PlatformAudit::log('coupon.updated', 'platform_coupons', (int)$id, 'coupon', (int)$id, null, ['code' => $code]);

        flash('success', 'Coupon updated successfully.');
        redirect(url('superadmin/coupons'));
    }

    public function show(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        
        $coupon = Database::fetch("SELECT * FROM platform_coupons WHERE id = ?", [(int) $id]);
        if (!$coupon) redirect(url('superadmin/coupons'));

        $usages = Database::fetchAll("
            SELECT u.*, s.name as school_name 
            FROM platform_coupon_usage u
            JOIN schools s ON s.id = u.school_id
            WHERE u.coupon_id = ?
            ORDER BY u.created_at DESC LIMIT 50
        ", [(int) $id]);

        $this->view('platform/coupons/show', [
            'title' => 'Coupon Usage: ' . $coupon['code'],
            'coupon' => $coupon,
            'usages' => $usages
        ], 'platform/layouts/app');
    }

    public function delete(string $id): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $coupon = Database::fetch("SELECT * FROM platform_coupons WHERE id = ?", [(int) $id]);
        if ($coupon) {
            Database::execute("DELETE FROM platform_coupons WHERE id = ?", [(int) $id]);
            PlatformAudit::log('coupon.deleted', 'platform_coupons', (int)$id, 'coupon', (int)$id, null, ['code' => $coupon['code']]);
        }
        
        flash('success', 'Coupon deleted successfully.');
        redirect(url('superadmin/coupons'));
    }
}
