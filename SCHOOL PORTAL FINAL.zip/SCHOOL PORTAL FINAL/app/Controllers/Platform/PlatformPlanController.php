<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\BillingService;
use App\Services\Platform\PlatformAudit;
use App\Services\Platform\SubscriptionService;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;
use Core\TenantContext;

final class PlatformPlanController extends Controller
{
    public function index(): void
    {
        PlatformAuth::requirePermission('plans.manage');
        
        $plans = Database::fetchAll('SELECT * FROM plans WHERE status != 2 ORDER BY sort_order, id');
        foreach ($plans as &$p) {
            $p['features'] = Database::fetchAll(
                'SELECT f.* FROM features f INNER JOIN plan_features pf ON pf.feature_id = f.id WHERE pf.plan_id = ?',
                [(int) $p['id']]
            );
            $p['school_count'] = (int) (Database::fetch('SELECT COUNT(*) c FROM schools WHERE plan_id = ? AND deleted_at IS NULL', [(int) $p['id']])['c'] ?? 0);
        }
        
        $subscriptions = Database::fetchAll('
            SELECT s.*, p.name as plan_name, sch.name as school_name, sch.subscription_status
            FROM subscriptions s 
            INNER JOIN plans p ON p.id = s.plan_id 
            INNER JOIN schools sch ON sch.id = s.school_id 
            WHERE sch.deleted_at IS NULL
            ORDER BY s.id DESC LIMIT 100
        ');

        // Analytics
        $activePlans = count(array_filter($plans, fn($p) => (int)$p['status'] === 1));
        
        $mrr = (float) (Database::fetch(
            'SELECT COALESCE(SUM(amount), 0) AS mrr 
             FROM subscription_payments 
             WHERE payment_status = "paid" AND MONTH(paid_at) = MONTH(CURRENT_DATE()) AND YEAR(paid_at) = YEAR(CURRENT_DATE())'
        )['mrr'] ?? 0);
        
        $arr = $mrr * 12;

        $this->view('platform/plans/index', [
            'title' => 'Subscriptions & Plans',
            'plans' => $plans,
            'features' => Database::fetchAll('SELECT * FROM features ORDER BY module, name'),
            'subscriptions' => $subscriptions,
            'analytics' => [
                'total_plans' => count($plans),
                'active_plans' => $activePlans,
                'mrr' => $mrr,
                'arr' => $arr
            ]
        ], 'platform/layouts/app');
    }

    public function store(): void
    {
        PlatformAuth::requirePermission('plans.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, ['name' => 'required', 'slug' => 'required']);
        $id = Database::insert(
            'INSERT INTO plans (name, slug, description, monthly_price, annual_price, trial_days, student_limit, teacher_limit, employee_limit, storage_limit_mb, status, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, NOW(), NOW())',
            [
                $data['name'],
                $data['slug'],
                $_POST['description'] ?? null,
                (float) ($_POST['monthly_price'] ?? 0),
                (float) ($_POST['annual_price'] ?? 0),
                (int) ($_POST['trial_days'] ?? 14),
                $_POST['student_limit'] !== '' ? (int) $_POST['student_limit'] : null,
                $_POST['teacher_limit'] !== '' ? (int) $_POST['teacher_limit'] : null,
                $_POST['employee_limit'] !== '' ? (int) $_POST['employee_limit'] : null,
                $_POST['storage_limit_mb'] !== '' ? (int) $_POST['storage_limit_mb'] : null,
                (int) ($_POST['sort_order'] ?? 0),
            ]
        );
        foreach ($_POST['features'] ?? [] as $fid) {
            Database::insert('INSERT INTO plan_features (plan_id, feature_id) VALUES (?, ?)', [$id, (int) $fid]);
        }
        PlatformAudit::log('plan.create', 'plans', null, 'plan', $id);
        flash('success', 'Plan created.');
        redirect(url('superadmin/plans'));
    }

    public function update(string $id): void
    {
        PlatformAuth::requirePermission('plans.manage');
        $this->requireCsrf();
        $data = $this->validate($_POST, ['name' => 'required', 'slug' => 'required']);
        
        Database::execute(
            'UPDATE plans SET name=?, slug=?, description=?, monthly_price=?, annual_price=?, trial_days=?, student_limit=?, teacher_limit=?, employee_limit=?, storage_limit_mb=?, sort_order=?, updated_at=NOW() WHERE id=?',
            [
                $data['name'],
                $data['slug'],
                $_POST['description'] ?? null,
                (float) ($_POST['monthly_price'] ?? 0),
                (float) ($_POST['annual_price'] ?? 0),
                (int) ($_POST['trial_days'] ?? 14),
                $_POST['student_limit'] !== '' ? (int) $_POST['student_limit'] : null,
                $_POST['teacher_limit'] !== '' ? (int) $_POST['teacher_limit'] : null,
                $_POST['employee_limit'] !== '' ? (int) $_POST['employee_limit'] : null,
                $_POST['storage_limit_mb'] !== '' ? (int) $_POST['storage_limit_mb'] : null,
                (int) ($_POST['sort_order'] ?? 0),
                (int) $id
            ]
        );
        
        Database::execute('DELETE FROM plan_features WHERE plan_id = ?', [(int) $id]);
        foreach ($_POST['features'] ?? [] as $fid) {
            Database::insert('INSERT INTO plan_features (plan_id, feature_id) VALUES (?, ?)', [(int) $id, (int) $fid]);
        }
        
        PlatformAudit::log('plan.update', 'plans', null, 'plan', (int)$id);
        flash('success', 'Plan updated successfully.');
        redirect(url('superadmin/plans'));
    }

    public function duplicate(string $id): void
    {
        PlatformAuth::requirePermission('plans.manage');
        $this->requireCsrf();
        $plan = Database::fetch('SELECT * FROM plans WHERE id = ?', [(int) $id]);
        if (!$plan) {
            flash('error', 'Plan not found.');
            redirect(url('superadmin/plans'));
        }
        
        $newId = Database::insert(
            'INSERT INTO plans (name, slug, description, monthly_price, annual_price, trial_days, student_limit, teacher_limit, employee_limit, storage_limit_mb, status, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NOW(), NOW())',
            [
                $plan['name'] . ' (Copy)',
                $plan['slug'] . '-copy-' . time(),
                $plan['description'],
                $plan['monthly_price'],
                $plan['annual_price'],
                $plan['trial_days'],
                $plan['student_limit'],
                $plan['teacher_limit'],
                $plan['employee_limit'],
                $plan['storage_limit_mb'],
                $plan['sort_order'] + 1,
            ]
        );
        
        $features = Database::fetchAll('SELECT feature_id FROM plan_features WHERE plan_id = ?', [(int) $id]);
        foreach ($features as $f) {
            Database::insert('INSERT INTO plan_features (plan_id, feature_id) VALUES (?, ?)', [$newId, (int) $f['feature_id']]);
        }
        
        PlatformAudit::log('plan.duplicate', 'plans', null, 'plan', $newId);
        flash('success', 'Plan duplicated. The new plan is currently drafted (inactive).');
        redirect(url('superadmin/plans'));
    }

    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('plans.manage');
        $this->requireCsrf();
        $status = (int) ($_POST['status'] ?? 1); // 0=inactive, 1=active, 2=archived
        
        if ($status === 2) {
            $activeSubs = Database::fetch('SELECT COUNT(*) c FROM schools WHERE plan_id = ? AND subscription_status IN ("active", "trial") AND deleted_at IS NULL', [(int)$id])['c'] ?? 0;
            if ($activeSubs > 0) {
                flash('error', 'Cannot archive plan with active subscriptions. Migrate schools to another plan first.');
                redirect(url('superadmin/plans'));
            }
        }
        
        Database::execute('UPDATE plans SET status = ? WHERE id = ?', [$status, (int) $id]);
        PlatformAudit::log('plan.status', 'plans', null, 'plan', (int)$id, null, ['new_status' => $status]);
        flash('success', 'Plan status updated.');
        redirect(url('superadmin/plans'));
    }

    public function subscriptionAction(string $id): void
    {
        PlatformAuth::requirePermission('subscriptions.manage');
        $this->requireCsrf();
        $action = $_POST['action'] ?? '';
        
        $sub = Database::fetch('SELECT * FROM subscriptions WHERE id = ?', [(int) $id]);
        if (!$sub) {
            flash('error', 'Subscription not found.');
            redirect(url('superadmin/plans'));
        }
        
        $schoolId = (int) $sub['school_id'];
        
        if ($action === 'pause') {
            Database::execute('UPDATE subscriptions SET status = "paused" WHERE id = ?', [(int) $id]);
            Database::execute('UPDATE schools SET subscription_status = "paused" WHERE id = ?', [$schoolId]);
        } elseif ($action === 'resume') {
            Database::execute('UPDATE subscriptions SET status = "active" WHERE id = ?', [(int) $id]);
            Database::execute('UPDATE schools SET subscription_status = "active" WHERE id = ?', [$schoolId]);
        } elseif ($action === 'cancel') {
            Database::execute('UPDATE subscriptions SET status = "cancelled" WHERE id = ?', [(int) $id]);
            Database::execute('UPDATE schools SET subscription_status = "cancelled" WHERE id = ?', [$schoolId]);
        }
        
        PlatformAudit::log('subscription.action', 'subscriptions', $schoolId, 'subscription', (int)$id, null, ['action' => $action]);
        flash('success', 'Subscription action applied successfully.');
        redirect(url('superadmin/plans'));
    }

    public function updateFeatures(string $id): void
    {
        PlatformAuth::requirePermission('plans.manage');
        $this->requireCsrf();
        Database::execute('DELETE FROM plan_features WHERE plan_id = ?', [(int) $id]);
        foreach ($_POST['features'] ?? [] as $fid) {
            Database::insert('INSERT INTO plan_features (plan_id, feature_id) VALUES (?, ?)', [(int) $id, (int) $fid]);
        }
        PlatformAudit::log('plan.features', 'plans', null, 'plan', (int) $id);
        flash('success', 'Plan features updated.');
        redirect(url('superadmin/plans'));
    }
}
