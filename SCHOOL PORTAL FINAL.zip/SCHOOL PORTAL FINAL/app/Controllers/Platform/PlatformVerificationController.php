<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformVerificationController extends Controller
{
    private function checkSchema(): void
    {
        try { Database::execute("ALTER TABLE schools ADD COLUMN verification_status VARCHAR(30) DEFAULT 'not_submitted'"); } catch (\Throwable $e) {}

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_document_types (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                is_required TINYINT(1) DEFAULT 0,
                requires_expiry TINYINT(1) DEFAULT 0,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS school_documents (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                type_id BIGINT UNSIGNED NOT NULL,
                file_path VARCHAR(255) NOT NULL,
                document_number VARCHAR(100) NULL,
                issue_date DATE NULL,
                expiry_date DATE NULL,
                status VARCHAR(30) DEFAULT 'pending',
                review_notes TEXT NULL,
                reviewed_by BIGINT UNSIGNED NULL,
                reviewed_at DATETIME NULL,
                submitted_by BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
                FOREIGN KEY (type_id) REFERENCES platform_document_types(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        // Seed default document types if empty
        $count = (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_document_types')['c'] ?? 0);
        if ($count === 0) {
            $types = [
                ['School Registration/License', 1, 1],
                ['Legal Entity Document', 1, 0],
                ['Tax Document', 0, 0],
                ['Owner Identity', 1, 1],
                ['Address/Proof of Location', 1, 0]
            ];
            foreach($types as $t) {
                Database::insert('INSERT INTO platform_document_types (name, is_required, requires_expiry, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())', $t);
            }
        }
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->checkSchema();

        $query = 'SELECT s.id, s.name, s.code, s.country, s.verification_status, s.created_at, u.name as owner_name 
                  FROM schools s
                  LEFT JOIN users u ON u.school_id = s.id AND u.role = "school_owner"
                  WHERE s.deleted_at IS NULL';
        
        $params = [];

        if (!empty($_GET['status'])) {
            $query .= ' AND s.verification_status = ?';
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['q'])) {
            $query .= ' AND (s.name LIKE ? OR s.code LIKE ?)';
            $params[] = '%' . $_GET['q'] . '%';
            $params[] = '%' . $_GET['q'] . '%';
        }

        $query .= ' ORDER BY s.created_at DESC LIMIT 200';
        $schools = Database::fetchAll($query, $params);

        $analytics = [
            'total' => (int) (Database::fetch('SELECT COUNT(id) as c FROM schools WHERE deleted_at IS NULL')['c'] ?? 0),
            'verified' => (int) (Database::fetch('SELECT COUNT(id) as c FROM schools WHERE verification_status = "verified" AND deleted_at IS NULL')['c'] ?? 0),
            'pending' => (int) (Database::fetch('SELECT COUNT(id) as c FROM schools WHERE verification_status IN ("pending_review", "under_review") AND deleted_at IS NULL')['c'] ?? 0),
            'rejected' => (int) (Database::fetch('SELECT COUNT(id) as c FROM schools WHERE verification_status = "rejected" AND deleted_at IS NULL')['c'] ?? 0),
            'expiring' => (int) (Database::fetch('SELECT COUNT(DISTINCT d.school_id) as c FROM school_documents d WHERE d.status="approved" AND d.expiry_date IS NOT NULL AND d.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)')['c'] ?? 0)
        ];

        $this->view('platform/verification/index', [
            'title' => 'Documents & Verification',
            'schools' => $schools,
            'analytics' => $analytics,
            'filters' => $_GET
        ], 'platform/layouts/app');
    }

    public function show(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->checkSchema();

        $school = Database::fetch(
            'SELECT s.*, u.name as owner_name, u.email as owner_email 
             FROM schools s 
             LEFT JOIN users u ON u.school_id = s.id AND u.role="school_owner" 
             WHERE s.id = ?',
            [(int) $id]
        );
        
        if (!$school) {
            flash('error', 'School not found.');
            redirect(url('superadmin/verification'));
        }

        $documents = Database::fetchAll(
            'SELECT d.*, t.name as type_name, t.is_required, t.requires_expiry, pu.name as reviewer_name
             FROM school_documents d
             INNER JOIN platform_document_types t ON t.id = d.type_id
             LEFT JOIN platform_users pu ON pu.id = d.reviewed_by
             WHERE d.school_id = ?
             ORDER BY d.created_at DESC',
            [(int) $id]
        );

        $this->view('platform/verification/show', [
            'title' => 'Verification Profile: ' . $school['name'],
            'school' => $school,
            'documents' => $documents,
            'docTypes' => Database::fetchAll('SELECT * FROM platform_document_types ORDER BY name')
        ], 'platform/layouts/app');
    }

    public function updateStatus(string $id): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();

        $status = $_POST['status'];
        Database::execute('UPDATE schools SET verification_status = ?, updated_at = NOW() WHERE id = ?', [$status, (int) $id]);
        
        PlatformAudit::log('verification.school_status', 'schools', null, 'school', (int) $id, null, ['status' => $status]);
        
        flash('success', 'School verification status updated to ' . strtoupper($status));
        redirect(url('superadmin/verification/' . $id));
    }

    public function reviewDocument(string $schoolId, string $docId): void
    {
        PlatformAuth::requirePermission('schools.manage');
        $this->requireCsrf();

        $status = $_POST['status'];
        $notes = trim($_POST['review_notes'] ?? '');

        Database::execute(
            'UPDATE school_documents SET status = ?, review_notes = ?, reviewed_by = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ? AND school_id = ?',
            [$status, $notes, PlatformAuth::id(), (int) $docId, (int) $schoolId]
        );

        PlatformAudit::log('verification.document_reviewed', 'school_documents', null, 'document', (int) $docId, null, ['status' => $status]);
        
        flash('success', 'Document reviewed successfully.');
        redirect(url('superadmin/verification/' . $schoolId));
    }
}
