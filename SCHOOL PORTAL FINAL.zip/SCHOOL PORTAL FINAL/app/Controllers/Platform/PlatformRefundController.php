<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Auth;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformRefundController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_refunds (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                invoice_id BIGINT UNSIGNED NOT NULL,
                payment_id BIGINT UNSIGNED NULL,
                amount DECIMAL(12,2) NOT NULL,
                reason TEXT NOT NULL,
                status VARCHAR(30) DEFAULT 'completed',
                admin_id BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_credits (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                school_id BIGINT UNSIGNED NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                type ENUM('granted', 'redeemed') NOT NULL DEFAULT 'granted',
                reason TEXT NOT NULL,
                reference_id BIGINT UNSIGNED NULL,
                admin_id BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->checkSchema();

        $refunds = Database::fetchAll("
            SELECT r.*, s.name as school_name, i.invoice_no, u.name as admin_name
            FROM platform_refunds r
            JOIN schools s ON s.id = r.school_id
            JOIN subscription_invoices i ON i.id = r.invoice_id
            LEFT JOIN users u ON u.id = r.admin_id
            ORDER BY r.created_at DESC
            LIMIT 100
        ");

        $credits = Database::fetchAll("
            SELECT c.*, s.name as school_name, u.name as admin_name, i.invoice_no
            FROM platform_credits c
            JOIN schools s ON s.id = c.school_id
            LEFT JOIN users u ON u.id = c.admin_id
            LEFT JOIN subscription_invoices i ON i.id = c.reference_id AND c.type = 'redeemed'
            ORDER BY c.created_at DESC
            LIMIT 100
        ");

        $analytics = [
            'total_refunded' => (float) (Database::fetch('SELECT SUM(amount) as t FROM platform_refunds WHERE status = "completed"')['t'] ?? 0),
            'total_credits_granted' => (float) (Database::fetch('SELECT SUM(amount) as t FROM platform_credits WHERE type = "granted"')['t'] ?? 0),
            'total_credits_redeemed' => (float) (Database::fetch('SELECT SUM(amount) as t FROM platform_credits WHERE type = "redeemed"')['t'] ?? 0),
        ];
        $analytics['outstanding_credit'] = $analytics['total_credits_granted'] - $analytics['total_credits_redeemed'];

        $schools = Database::fetchAll("
            SELECT s.id, s.name,
                   COALESCE((SELECT SUM(amount) FROM platform_credits WHERE school_id = s.id AND type = 'granted'), 0) -
                   COALESCE((SELECT SUM(amount) FROM platform_credits WHERE school_id = s.id AND type = 'redeemed'), 0) as credit_balance
            FROM schools s
            WHERE s.deleted_at IS NULL
            ORDER BY s.name ASC
        ");

        $this->view('platform/refunds/index', [
            'title' => 'Refunds & Credits',
            'refunds' => $refunds,
            'credits' => $credits,
            'analytics' => $analytics,
            'schools' => $schools
        ], 'platform/layouts/app');
    }

    public function issueRefund(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $invoiceId = (int) $_POST['invoice_id'];
        $amount = (float) $_POST['amount'];
        $reason = trim($_POST['reason'] ?? '');

        if ($amount <= 0 || empty($reason)) {
            flash('error', 'Valid amount and reason are required.');
            redirect(url('superadmin/refunds'));
        }

        $invoice = Database::fetch('SELECT * FROM subscription_invoices WHERE id = ?', [$invoiceId]);
        if (!$invoice) {
            flash('error', 'Invoice not found.');
            redirect(url('superadmin/refunds'));
        }

        // Calculate already refunded
        $alreadyRefunded = (float) (Database::fetch('SELECT SUM(amount) as t FROM platform_refunds WHERE invoice_id = ? AND status = "completed"', [$invoiceId])['t'] ?? 0);
        $maxRefundable = (float) $invoice['paid_amount'] - $alreadyRefunded;

        if ($amount > $maxRefundable) {
            flash('error', 'Refund amount cannot exceed the valid refundable balance ($' . number_format($maxRefundable, 2) . ').');
            redirect(url('superadmin/refunds'));
        }

        Database::insert("
            INSERT INTO platform_refunds (school_id, invoice_id, amount, reason, status, admin_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'completed', ?, NOW(), NOW())
        ", [(int) $invoice['school_id'], $invoiceId, $amount, $reason, Auth::id()]);

        PlatformAudit::log('billing.refund_issued', 'subscription_invoices', (int) $invoice['school_id'], 'invoice', $invoiceId, null, [
            'amount' => $amount,
            'reason' => $reason
        ]);

        flash('success', 'Refund of $' . number_format($amount, 2) . ' issued successfully.');
        redirect(url('superadmin/refunds'));
    }

    public function grantCredit(): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $this->requireCsrf();

        $schoolId = (int) $_POST['school_id'];
        $amount = (float) $_POST['amount'];
        $reason = trim($_POST['reason'] ?? '');

        if ($amount <= 0 || empty($reason)) {
            flash('error', 'Valid amount and reason are required.');
            redirect(url('superadmin/refunds'));
        }

        Database::insert("
            INSERT INTO platform_credits (school_id, amount, type, reason, admin_id, created_at)
            VALUES (?, ?, 'granted', ?, ?, NOW())
        ", [$schoolId, $amount, $reason, Auth::id()]);

        PlatformAudit::log('billing.credit_granted', 'platform_credits', $schoolId, 'school', $schoolId, null, [
            'amount' => $amount,
            'reason' => $reason
        ]);

        flash('success', 'Account credit of $' . number_format($amount, 2) . ' granted successfully.');
        redirect(url('superadmin/refunds'));
    }

    public function schoolInvoices(string $schoolId): void
    {
        PlatformAuth::requirePermission('billing.manage');
        $invoices = Database::fetchAll("
            SELECT id, invoice_no, total_amount, paid_amount 
            FROM subscription_invoices 
            WHERE school_id = ? AND paid_amount > 0
            ORDER BY created_at DESC
        ", [(int) $schoolId]);

        foreach ($invoices as $k => $inv) {
            $refunded = (float) (Database::fetch('SELECT SUM(amount) as t FROM platform_refunds WHERE invoice_id = ? AND status="completed"', [$inv['id']])['t'] ?? 0);
            $invoices[$k]['refundable'] = $inv['paid_amount'] - $refunded;
        }

        header('Content-Type: application/json');
        echo json_encode($invoices);
        exit;
    }
}
