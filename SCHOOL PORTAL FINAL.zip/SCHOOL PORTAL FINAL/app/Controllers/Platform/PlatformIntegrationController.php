<?php

declare(strict_types=1);

namespace App\Controllers\Platform;

use App\Services\Platform\PlatformAudit;
use Core\Controller;
use Core\Database;
use Core\PlatformAuth;

final class PlatformIntegrationController extends Controller
{
    private function checkSchema(): void
    {
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_integrations (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                provider_id VARCHAR(50) NOT NULL UNIQUE,
                name VARCHAR(100) NOT NULL,
                category VARCHAR(50) NOT NULL,
                status VARCHAR(30) DEFAULT 'disconnected',
                environment VARCHAR(20) DEFAULT 'test',
                credentials TEXT NULL,
                webhook_url VARCHAR(255) NULL,
                webhook_secret VARCHAR(255) NULL,
                last_checked_at DATETIME NULL,
                last_synced_at DATETIME NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        Database::execute("
            CREATE TABLE IF NOT EXISTS platform_integration_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                integration_id BIGINT UNSIGNED NOT NULL,
                event VARCHAR(100) NOT NULL,
                status VARCHAR(20) NOT NULL,
                message TEXT NULL,
                created_at DATETIME NOT NULL,
                FOREIGN KEY (integration_id) REFERENCES platform_integrations(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");
        
        $count = (int) (Database::fetch('SELECT COUNT(id) as c FROM platform_integrations')['c'] ?? 0);
        if ($count === 0) {
            $providers = [
                ['stripe', 'Stripe', 'Payment Gateways'],
                ['paypal', 'PayPal', 'Payment Gateways'],
                ['sendgrid', 'SendGrid', 'Email Providers'],
                ['twilio', 'Twilio', 'SMS Providers'],
                ['aws_s3', 'AWS S3', 'Cloud Storage'],
                ['google_auth', 'Google Workspace', 'Google Services']
            ];
            foreach($providers as $p) {
                Database::insert('INSERT INTO platform_integrations (provider_id, name, category, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())', $p);
            }
        }
    }

    public function index(): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $query = 'SELECT * FROM platform_integrations ORDER BY category, name';
        $integrations = Database::fetchAll($query);

        $analytics = [
            'total' => count($integrations),
            'connected' => count(array_filter($integrations, fn($i) => $i['status'] === 'connected')),
            'disconnected' => count(array_filter($integrations, fn($i) => $i['status'] === 'disconnected')),
            'error' => count(array_filter($integrations, fn($i) => $i['status'] === 'error')),
        ];

        // Group by category
        $grouped = [];
        foreach ($integrations as $i) {
            $grouped[$i['category']][] = $i;
        }

        $this->view('platform/integrations/index', [
            'title' => 'Integrations Center',
            'analytics' => $analytics,
            'grouped' => $grouped
        ], 'platform/layouts/app');
    }

    public function show(string $providerId): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->checkSchema();

        $integration = Database::fetch('SELECT * FROM platform_integrations WHERE provider_id = ?', [$providerId]);
        if (!$integration) {
            flash('error', 'Integration not found.');
            redirect(url('superadmin/integrations'));
        }
        
        $integration['credentials_decoded'] = $integration['credentials'] ? json_decode($integration['credentials'], true) : [];

        $logs = Database::fetchAll('SELECT * FROM platform_integration_logs WHERE integration_id = ? ORDER BY created_at DESC LIMIT 50', [(int) $integration['id']]);

        $this->view('platform/integrations/show', [
            'title' => 'Configure: ' . $integration['name'],
            'integration' => $integration,
            'logs' => $logs
        ], 'platform/layouts/app');
    }

    public function update(string $providerId): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $integration = Database::fetch('SELECT * FROM platform_integrations WHERE provider_id = ?', [$providerId]);
        if (!$integration) {
            redirect(url('superadmin/integrations'));
        }

        $status = $_POST['status'] ?? 'disconnected';
        $environment = $_POST['environment'] ?? 'test';
        $webhookUrl = $_POST['webhook_url'] ?? null;
        
        $creds = $_POST['credentials'] ?? [];
        // Mask passwords in audit log but save real in DB
        $auditCreds = $creds;
        foreach($auditCreds as $k => $v) {
            if (!empty($v)) $auditCreds[$k] = '********';
        }

        Database::execute(
            'UPDATE platform_integrations SET status = ?, environment = ?, webhook_url = ?, credentials = ?, updated_at = NOW() WHERE id = ?',
            [$status, $environment, $webhookUrl, json_encode($creds), (int) $integration['id']]
        );

        PlatformAudit::log('integration.updated', 'platform_integrations', null, 'integration', (int) $integration['id'], null, ['status' => $status, 'env' => $environment, 'creds' => $auditCreds]);

        flash('success', $integration['name'] . ' configuration updated.');
        redirect(url('superadmin/integrations/' . $providerId));
    }

    public function test(string $providerId): void
    {
        PlatformAuth::requirePermission('settings.manage');
        $this->requireCsrf();

        $integration = Database::fetch('SELECT * FROM platform_integrations WHERE provider_id = ?', [$providerId]);
        
        // Mock connection testing
        $success = (bool)rand(0, 1) || $integration['status'] === 'connected';
        $status = $success ? 'connected' : 'error';
        $logStatus = $success ? 'success' : 'failed';
        $logMessage = $success ? 'Connection tested successfully via API ping.' : 'Connection timeout or invalid credentials.';

        Database::execute('UPDATE platform_integrations SET status = ?, last_checked_at = NOW() WHERE id = ?', [$status, (int) $integration['id']]);
        
        Database::insert('INSERT INTO platform_integration_logs (integration_id, event, status, message, created_at) VALUES (?, ?, ?, ?, NOW())', 
            [(int) $integration['id'], 'test_connection', $logStatus, $logMessage]
        );

        if ($success) {
            flash('success', 'Connection to ' . $integration['name'] . ' was successful.');
        } else {
            flash('error', 'Connection to ' . $integration['name'] . ' failed. Check integration logs.');
        }

        redirect(url('superadmin/integrations/' . $providerId));
    }
}
