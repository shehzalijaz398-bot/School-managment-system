<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\DocumentService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class DocumentController extends Controller
{
    private DocumentService $service;

    public function __construct()
    {
        $this->service = new DocumentService();
    }

    /**
     * Document Center UI.
     * GET /documents
     */
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $category = trim((string)($_GET['category'] ?? 'all'));
        $status = trim((string)($_GET['status'] ?? 'all'));
        $search = trim((string)($_GET['q'] ?? ''));
        $expiringSoon = !empty($_GET['expiring']) ? 30 : null;

        $filters = [
            'category' => $category,
            'review_status' => $status,
            'search' => $search,
            'expiring_soon' => $expiringSoon,
            'limit' => 100
        ];

        // If user is not admin/principal, filter out confidential documents
        $role = Auth::roleSlug();
        $isPrivileged = in_array($role, ['school_admin', 'principal', 'owner', 'superadmin'], true) || hasPermission('documents.manage');
        if (!$isPrivileged) {
            $filters['is_confidential'] = 0;
        }

        $documents = $this->service->queryDocuments($schoolId, $filters);

        // Compute metrics
        $allDocs = Database::fetchAll("SELECT category, review_status, expiry_date, is_confidential FROM school_documents WHERE school_id = ?", [$schoolId]);
        $totalDocs = count($allDocs);
        $totalApproved = count(array_filter($allDocs, fn($d) => $d['review_status'] === 'approved'));
        $totalPending = count(array_filter($allDocs, fn($d) => in_array($d['review_status'], ['pending', 'under_review'], true)));
        
        $today = date('Y-m-d');
        $in30Days = date('Y-m-d', strtotime('+30 days'));
        $totalExpiring = count(array_filter($allDocs, fn($d) => !empty($d['expiry_date']) && $d['expiry_date'] <= $in30Days));

        // Fetch students for record generation modal
        $students = Database::fetchAll("
            SELECT s.id, s.admission_no, s.first_name, s.last_name, c.name as class_name, sec.name as section_name
            FROM students s
            LEFT JOIN classes c ON c.id = s.class_id
            LEFT JOIN sections sec ON sec.id = s.section_id
            WHERE s.school_id = ?
            ORDER BY s.first_name ASC
            LIMIT 200
        ", [$schoolId]);

        $this->view('documents/index', [
            'title' => 'Digital Document Center',
            'documents' => $documents,
            'students' => $students,
            'stats' => [
                'total' => $totalDocs,
                'approved' => $totalApproved,
                'pending' => $totalPending,
                'expiring' => $totalExpiring,
            ],
            'filters' => [
                'category' => $category,
                'status' => $status,
                'q' => $search,
                'expiring' => $expiringSoon ? '1' : '',
            ],
            'isPrivileged' => $isPrivileged
        ]);
    }

    /**
     * Upload document.
     * POST /documents
     */
    public function store(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        if (empty($_FILES['document_file'])) {
            flash('error', 'Please select a document file to upload.');
            back();
        }

        try {
            $meta = [
                'category' => $_POST['category'] ?? 'general',
                'title' => trim((string)($_POST['title'] ?? '')),
                'description' => trim((string)($_POST['description'] ?? '')),
                'entity_type' => trim((string)($_POST['entity_type'] ?? 'general')),
                'entity_id' => !empty($_POST['entity_id']) ? (int)$_POST['entity_id'] : null,
                'is_confidential' => !empty($_POST['is_confidential']) ? 1 : 0,
                'expiry_date' => !empty($_POST['expiry_date']) ? trim((string)$_POST['expiry_date']) : null,
                'review_status' => !empty($_POST['review_status']) ? trim((string)$_POST['review_status']) : 'approved',
            ];

            $res = $this->service->uploadDocument($schoolId, $userId, $_FILES['document_file'], $meta);
            flash('success', "Document uploaded successfully. Reference Code: {$res['document_ref']}");
        } catch (\Throwable $e) {
            flash('error', 'Document upload failed: ' . $e->getMessage());
        }

        redirect(url('documents'));
    }

    /**
     * Upload a new version of an existing document.
     * POST /documents/{id}/version
     */
    public function uploadVersion(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        if (empty($_FILES['version_file'])) {
            flash('error', 'Please select a file to upload as new version.');
            back();
        }

        try {
            $changelog = trim((string)($_POST['changelog'] ?? ''));
            $res = $this->service->uploadNewVersion($schoolId, $userId, (int)$id, $_FILES['version_file'], $changelog);
            flash('success', "New version (v{$res['version']}) uploaded successfully.");
        } catch (\Throwable $e) {
            flash('error', 'Version upload failed: ' . $e->getMessage());
        }

        redirect(url('documents'));
    }

    /**
     * Update document review status.
     * POST /documents/{id}/status
     */
    public function updateStatus(string $id): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $status = trim((string)($_POST['status'] ?? 'approved'));
        $notes = trim((string)($_POST['reviewer_notes'] ?? ''));

        $updated = $this->service->updateReviewStatus($schoolId, $userId, (int)$id, $status, $notes);
        if ($updated) {
            flash('success', "Document status updated to '{$status}'.");
        } else {
            flash('error', 'Document not found or status update failed.');
        }

        back();
    }

    /**
     * Stream document inline for modal preview.
     * GET /documents/{ref}/preview
     */
    public function preview(string $ref): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();

        $doc = $this->service->getDocumentByRef($schoolId, $ref);
        if (!$doc) {
            http_response_code(404);
            die('Document not found or unauthorized.');
        }

        // Check confidentiality access
        if (!empty($doc['is_confidential'])) {
            $role = Auth::roleSlug();
            $isPrivileged = in_array($role, ['school_admin', 'principal', 'owner', 'superadmin'], true) || hasPermission('documents.manage');
            if (!$isPrivileged) {
                http_response_code(403);
                die('Access Denied: You do not have permission to view confidential documents.');
            }
        }

        $baseDir = realpath(dirname(__DIR__, 2));
        $absPath = dirname(__DIR__, 2) . '/' . ltrim(str_replace(['../', '..\\'], '', (string)$doc['file_path']), '/\\');
        $realPath = realpath($absPath);
        if (!$realPath || !str_starts_with($realPath, $baseDir) || !file_exists($realPath)) {
            http_response_code(404);
            die('File content missing or unauthorized storage path.');
        }

        $mime = $doc['mime_type'] ?: 'application/octet-stream';
        $fileName = basename($doc['file_name']);

        header('Content-Type: ' . $mime);
        header('Content-Disposition: inline; filename="' . addslashes($fileName) . '"');
        header('Content-Length: ' . filesize($realPath));
        header('Cache-Control: private, max-age=3600');

        readfile($realPath);
        exit;
    }

    /**
     * Stream document attachment for download.
     * GET /documents/{ref}/download
     */
    public function download(string $ref): void
    {
        Auth::requireLogin();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $doc = $this->service->getDocumentByRef($schoolId, $ref);
        if (!$doc) {
            http_response_code(404);
            die('Document not found or unauthorized.');
        }

        // Check confidentiality access
        if (!empty($doc['is_confidential'])) {
            $role = Auth::roleSlug();
            $isPrivileged = in_array($role, ['school_admin', 'principal', 'owner', 'superadmin'], true) || hasPermission('documents.manage');
            if (!$isPrivileged) {
                http_response_code(403);
                die('Access Denied: You do not have permission to download confidential documents.');
            }
        }

        $baseDir = realpath(dirname(__DIR__, 2));
        $absPath = dirname(__DIR__, 2) . '/' . ltrim(str_replace(['../', '..\\'], '', (string)$doc['file_path']), '/\\');
        $realPath = realpath($absPath);
        if (!$realPath || !str_starts_with($realPath, $baseDir) || !file_exists($realPath)) {
            http_response_code(404);
            die('File missing or unauthorized storage path.');
        }

        // Log download audit event
        Database::insert("
            INSERT INTO document_reviews (
                document_id, school_id, action, old_status, new_status,
                notes, actor_id, actor_name, created_at
            ) VALUES (?, ?, 'downloaded', ?, ?, 'Document downloaded by authorized user.', ?, ?, NOW())
        ", [$doc['id'], $schoolId, $doc['review_status'], $doc['review_status'], $userId, Auth::user()['name'] ?? 'Authorized User']);

        $mime = $doc['mime_type'] ?: 'application/octet-stream';
        $fileName = $doc['file_name'];

        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename="' . addslashes($fileName) . '"');
        header('Content-Length: ' . filesize($absPath));
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($absPath);
        exit;
    }

    /**
     * Generate an official digital record.
     * POST /documents/generate-record
     */
    public function generateRecord(): void
    {
        Auth::requireLogin();
        $this->requireCsrf();
        $schoolId = (int)$this->schoolId();
        $userId = (int)Auth::id();

        $type = trim((string)($_POST['record_type'] ?? 'enrollment_confirmation'));
        $studentId = (int)($_POST['student_id'] ?? 0);

        if ($studentId <= 0) {
            flash('error', 'Please select a student.');
            back();
        }

        try {
            $record = $this->service->generateDigitalRecord($schoolId, $userId, $type, $studentId);
            flash('success', "Digital Record generated successfully. Reference: {$record['document_ref']} | Verification: {$record['verification_code']}");
        } catch (\Throwable $e) {
            flash('error', 'Failed to generate record: ' . $e->getMessage());
        }

        redirect(url('documents'));
    }

    /**
     * Public document verification endpoint.
     * GET /verify-document/{code}
     */
    public function verify(string $code): void
    {
        $doc = $this->service->verifyDocument($code);

        $this->view('documents/verify', [
            'title' => 'Official Document Verification',
            'document' => $doc,
            'code' => $code
        ]);
    }
}
