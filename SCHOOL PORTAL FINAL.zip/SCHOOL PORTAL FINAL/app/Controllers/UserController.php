<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Admission;
use App\Models\Announcement;
use App\Models\AuditLog;
use App\Models\ClassModel;
use App\Models\LeaveRequest;
use App\Models\Notification;
use App\Models\Teacher;
use App\Models\Timetable;
use App\Models\User;
use App\Services\AdmissionService;
use App\Services\LeaveService;
use App\Services\ReportService;
use App\Services\TimetableService;
use Core\Auth;
use Core\Controller;
use Core\Database;
final class UserController extends Controller
{
    public function index(): void
    {
        if (!isRole(['principal', 'school_admin'])) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }
        $this->view('settings/users', [
            'title' => 'Users / Staff Management',
            'users' => (new User())->listWithRoles(),
        ]);
    }

    public function create(): void
    {
        if (!isRole(['school_admin', 'principal'])) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }
        
        $roles = Database::fetchAll(
            "SELECT * FROM roles WHERE school_id IS NULL OR school_id = ? ORDER BY name",
            [Auth::schoolId()]
        );
        
        // Filter out roles that are automatically managed like Parent, Student, Teacher
        $allowedRoles = array_filter($roles, function($r) {
            return in_array($r['slug'], ['hr', 'finance', 'accountant', 'receptionist', 'school_admin']);
        });

        $this->view('settings/user_form', [
            'title' => 'Add User',
            'user' => null,
            'roles' => $allowedRoles,
            'employees' => (new \App\Models\Employee())->listAll(),
        ]);
    }

    public function store(): void
    {
        if (!isRole(['school_admin', 'principal'])) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }

        $this->requireCsrf();

        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $roleId = (int)($_POST['role_id'] ?? 0);
        $password = $_POST['password'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';
        $status = (int)($_POST['status'] ?? 1);
        $employeeId = !empty($_POST['employee_id']) ? (int)$_POST['employee_id'] : null;

        if (!$name || !$email || !$roleId || !$password) {
            flash('error', 'All fields are required.');
            redirect(url('users/create'));
            return;
        }

        if ($password !== $passwordConfirm) {
            flash('error', 'Passwords do not match.');
            redirect(url('users/create'));
            return;
        }

        // Verify role belongs to this school or is a system role
        $role = Database::fetch(
            "SELECT * FROM roles WHERE id = ? AND (school_id IS NULL OR school_id = ?)",
            [$roleId, Auth::schoolId()]
        );

        if (!$role || !in_array($role['slug'], ['hr', 'finance', 'accountant', 'receptionist', 'school_admin'])) {
            flash('error', 'Invalid role selected.');
            redirect(url('users/create'));
            return;
        }

        // Check email uniqueness
        $existing = Database::fetch("SELECT id FROM users WHERE email = ?", [$email]);
        if ($existing) {
            flash('error', 'Email is already taken.');
            redirect(url('users/create'));
            return;
        }

        if ($employeeId) {
            $empCheck = Database::fetch("SELECT id FROM employees WHERE id = ? AND school_id = ?", [$employeeId, Auth::schoolId()]);
            if (!$empCheck) {
                flash('error', 'Invalid employee selected.');
                redirect(url('users/create'));
                return;
            }
        }

        $userId = Database::insert(
            "INSERT INTO users (school_id, role_id, employee_id, name, email, password, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
            [Auth::schoolId(), $roleId, $employeeId, $name, $email, password_hash($password, PASSWORD_DEFAULT), $status]
        );

        auditLog('user.create', 'users', 'users', $userId, null, [
            'name' => $name,
            'email' => $email,
            'role_id' => $roleId,
            'employee_id' => $employeeId,
        ]);

        $school = currentSchool();
        $_SESSION['new_staff_credentials'] = [
            'user_id'       => $userId,
            'staff_id'      => $employeeId,
            'name'          => $name,
            'employee_code' => $employeeId ? (Database::fetch('SELECT employee_code FROM employees WHERE id = ?', [$employeeId])['employee_code'] ?? '') : '',
            'email'         => $email,
            'password'      => $password,
            'role_name'     => $role['name'] ?? 'User',
            'role_slug'     => $role['slug'] ?? 'user',
            'school_name'   => $school['name'] ?? 'School Portal',
            'school_code'   => $school['code'] ?? '',
            'login_url'     => url('login'),
            'is_accountant' => in_array($role['slug'] ?? '', ['accountant', 'finance'], true),
            'timestamp'     => date('d M Y, h:i A'),
        ];

        flash('success', "User created successfully! Login credentials generated for {$name} ({$role['name']}).");
        redirect(url('staff'));
    }

    public function edit(int $id): void
    {
        if (!isRole(['school_admin', 'principal'])) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }

        $user = Database::fetch("SELECT * FROM users WHERE id = ? AND school_id = ?", [$id, Auth::schoolId()]);
        if (!$user) {
            flash('error', 'User not found.');
            redirect('/users');
            return;
        }

        $roles = Database::fetchAll(
            "SELECT * FROM roles WHERE school_id IS NULL OR school_id = ? ORDER BY name",
            [Auth::schoolId()]
        );
        
        $allowedRoles = array_filter($roles, function($r) {
            return in_array($r['slug'], ['hr', 'finance', 'accountant', 'receptionist', 'school_admin']);
        });

        // Ensure the user's current role is included even if it's not one of the allowed ones to create, just so the select box doesn't break
        $currentRoleIncluded = false;
        foreach($allowedRoles as $ar) {
            if ($ar['id'] == $user['role_id']) {
                $currentRoleIncluded = true;
                break;
            }
        }
        if (!$currentRoleIncluded) {
            $currentRole = Database::fetch("SELECT * FROM roles WHERE id = ?", [$user['role_id']]);
            if ($currentRole) {
                $allowedRoles[] = $currentRole;
            }
        }

        $this->view('settings/user_form', [
            'title' => 'Edit User',
            'user' => $user,
            'roles' => $allowedRoles,
            'employees' => (new \App\Models\Employee())->listAll(),
        ]);
    }

    public function update(int $id): void
    {
        if (!isRole(['school_admin', 'principal'])) {
            http_response_code(403);
            view('errors/403', ['title' => 'Forbidden']);
            return;
        }

        $this->requireCsrf();

        $user = Database::fetch("SELECT * FROM users WHERE id = ? AND school_id = ?", [$id, Auth::schoolId()]);
        if (!$user) {
            flash('error', 'User not found.');
            redirect(url('users'));
            return;
        }

        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $roleId = (int)($_POST['role_id'] ?? 0);
        $status = (int)($_POST['status'] ?? 0);
        $password = $_POST['password'] ?? '';
        $employeeId = !empty($_POST['employee_id']) ? (int)$_POST['employee_id'] : null;

        if (!$name || !$email || !$roleId) {
            flash('error', 'Name, email, and role are required.');
            redirect(url("users/{$id}/edit"));
            return;
        }

        // Verify role
        $role = Database::fetch(
            "SELECT * FROM roles WHERE id = ? AND (school_id IS NULL OR school_id = ?)",
            [$roleId, Auth::schoolId()]
        );
        if (!$role) {
            flash('error', 'Invalid role selected.');
            redirect(url("users/{$id}/edit"));
            return;
        }

        // Check email uniqueness
        $existing = Database::fetch("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $id]);
        if ($existing) {
            flash('error', 'Email is already taken by another user.');
            redirect(url("users/{$id}/edit"));
            return;
        }

        if ($employeeId) {
            $empCheck = Database::fetch("SELECT id FROM employees WHERE id = ? AND school_id = ?", [$employeeId, Auth::schoolId()]);
            if (!$empCheck) {
                flash('error', 'Invalid employee selected.');
                redirect(url("users/{$id}/edit"));
                return;
            }
        }

        if ($password !== '') {
            $passwordConfirm = $_POST['password_confirm'] ?? '';
            if ($password !== $passwordConfirm) {
                flash('error', 'Passwords do not match.');
                redirect(url("users/{$id}/edit"));
                return;
            }
            Database::execute(
                "UPDATE users SET name = ?, email = ?, role_id = ?, employee_id = ?, status = ?, password = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
                [$name, $email, $roleId, $employeeId, $status, password_hash($password, PASSWORD_DEFAULT), $id, Auth::schoolId()]
            );
        } else {
            Database::execute(
                "UPDATE users SET name = ?, email = ?, role_id = ?, employee_id = ?, status = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
                [$name, $email, $roleId, $employeeId, $status, $id, Auth::schoolId()]
            );
        }

        auditLog('user.update', 'users', 'users', $id, $user, [
            'name' => $name,
            'email' => $email,
            'role_id' => $roleId,
            'employee_id' => $employeeId,
            'status' => $status,
        ]);

        flash('success', 'User updated successfully.');
        redirect(url('users'));
    }
}
