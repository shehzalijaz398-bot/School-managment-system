<?php

declare(strict_types=1);

namespace App\Controllers;

use Core\Auth;
use Core\Controller;
use Core\Database;

final class HostelController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $tab = trim((string)($_GET['tab'] ?? 'hostels'));
        $hostelId = (int)($_GET['hostel_id'] ?? 0);

        // Fetch Hostels with room count & resident counts
        $hostels = Database::fetchAll(
            'SELECT h.*, 
                    (SELECT COUNT(*) FROM hostel_rooms r WHERE r.hostel_id = h.id AND r.school_id = ?) AS room_count,
                    (SELECT COUNT(*) FROM hostel_allocations a WHERE a.hostel_id = h.id AND a.school_id = ? AND a.status = "active") AS resident_count,
                    (SELECT COALESCE(SUM(r.capacity), 0) FROM hostel_rooms r WHERE r.hostel_id = h.id AND r.school_id = ?) AS total_beds
             FROM hostels h 
             WHERE h.school_id = ? 
             ORDER BY h.id ASC',
            [$schoolId, $schoolId, $schoolId, $schoolId]
        );

        // Fetch Rooms
        $roomsQuery = 'SELECT r.*, h.name AS hostel_name, h.type AS hostel_type,
                              (SELECT COUNT(*) FROM hostel_allocations a WHERE a.room_id = r.id AND a.school_id = ? AND a.status = "active") AS occupied_beds
                       FROM hostel_rooms r
                       INNER JOIN hostels h ON h.id = r.hostel_id
                       WHERE r.school_id = ?';
        $roomParams = [$schoolId, $schoolId];
        if ($hostelId > 0) {
            $roomsQuery .= ' AND r.hostel_id = ?';
            $roomParams[] = $hostelId;
        }
        $roomsQuery .= ' ORDER BY h.name ASC, r.room_number ASC';
        $rooms = Database::fetchAll($roomsQuery, $roomParams);

        // Fetch Allocations (Residents)
        $allocQuery = 'SELECT a.*, h.name AS hostel_name, r.room_number, r.cost_per_bed,
                              s.first_name, s.last_name, s.admission_no, s.roll_no, c.name AS class_name, sec.name AS section_name
                       FROM hostel_allocations a
                       INNER JOIN hostels h ON h.id = a.hostel_id
                       INNER JOIN hostel_rooms r ON r.id = a.room_id
                       INNER JOIN students s ON s.id = a.student_id
                       LEFT JOIN classes c ON c.id = s.class_id
                       LEFT JOIN sections sec ON sec.id = s.section_id
                       WHERE a.school_id = ?';
        $allocParams = [$schoolId];
        if ($hostelId > 0) {
            $allocQuery .= ' AND a.hostel_id = ?';
            $allocParams[] = $hostelId;
        }
        $allocQuery .= ' ORDER BY a.status ASC, a.allocated_date DESC';
        $allocations = Database::fetchAll($allocQuery, $allocParams);

        // Students available for allocation (active students)
        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.first_name, s.last_name, c.name AS class_name, sec.name AS section_name 
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             WHERE s.school_id = ? AND s.status = "active" 
             ORDER BY s.first_name ASC',
            [$schoolId]
        );

        // KPI calculations
        $totalHostels = count($hostels);
        $totalRooms = count($rooms);
        $totalBeds = array_sum(array_column($rooms, 'capacity'));
        $occupiedBeds = (int)(Database::fetch('SELECT COUNT(*) AS c FROM hostel_allocations WHERE school_id = ? AND status = "active"', [$schoolId])['c'] ?? 0);
        $availableBeds = max(0, $totalBeds - $occupiedBeds);

        $this->view('hostels/index', [
            'title' => 'Hostel & Dormitory Management',
            'tab' => $tab,
            'hostels' => $hostels,
            'rooms' => $rooms,
            'allocations' => $allocations,
            'students' => $students,
            'selectedHostelId' => $hostelId,
            'stats' => [
                'total_hostels' => $totalHostels,
                'total_rooms' => $totalRooms,
                'total_beds' => $totalBeds,
                'occupied_beds' => $occupiedBeds,
                'available_beds' => $availableBeds,
            ],
        ]);
    }

    public function storeHostel(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $name = trim((string)($_POST['name'] ?? ''));
        $type = in_array($_POST['type'] ?? '', ['boys', 'girls', 'mixed'], true) ? $_POST['type'] : 'boys';
        $wardenName = trim((string)($_POST['warden_name'] ?? ''));
        $wardenPhone = trim((string)($_POST['warden_phone'] ?? ''));
        $address = trim((string)($_POST['address'] ?? ''));
        $capacity = (int)($_POST['capacity'] ?? 0);

        if ($name === '') {
            flash('error', 'Hostel name is required.');
            redirect(url('hostels?tab=hostels'));
        }

        Database::insert(
            'INSERT INTO hostels (school_id, name, type, warden_name, warden_phone, address, capacity, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, "active", NOW(), NOW())',
            [$schoolId, $name, $type, $wardenName, $wardenPhone, $address, $capacity]
        );

        flash('success', 'Hostel building added.');
        redirect(url('hostels?tab=hostels'));
    }

    public function storeRoom(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $hostelId = (int)($_POST['hostel_id'] ?? 0);
        $roomNumber = trim((string)($_POST['room_number'] ?? ''));
        $floor = trim((string)($_POST['floor'] ?? ''));
        $capacity = (int)($_POST['capacity'] ?? 4);
        $roomType = in_array($_POST['room_type'] ?? '', ['standard', 'ac', 'deluxe'], true) ? $_POST['room_type'] : 'standard';
        $costPerBed = (float)($_POST['cost_per_bed'] ?? 0.0);

        if (!$hostelId || $roomNumber === '') {
            flash('error', 'Hostel and room number required.');
            redirect(url('hostels?tab=rooms'));
        }

        Database::insert(
            'INSERT INTO hostel_rooms (school_id, hostel_id, room_number, floor, capacity, room_type, cost_per_bed, status, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, "available", NOW(), NOW())',
            [$schoolId, $hostelId, $roomNumber, $floor, $capacity, $roomType, $costPerBed]
        );

        flash('success', 'Hostel room created.');
        redirect(url('hostels?tab=rooms'));
    }

    public function storeAllocation(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        $studentId = (int)($_POST['student_id'] ?? 0);
        $roomId = (int)($_POST['room_id'] ?? 0);
        $bedNumber = trim((string)($_POST['bed_number'] ?? ''));
        $date = trim((string)($_POST['allocated_date'] ?? date('Y-m-d')));
        $notes = trim((string)($_POST['notes'] ?? ''));

        if (!$studentId || !$roomId) {
            flash('error', 'Student and room are required.');
            redirect(url('hostels?tab=allocations'));
        }

        // Verify room capacity
        $room = Database::fetch('SELECT r.*, (SELECT COUNT(*) FROM hostel_allocations a WHERE a.room_id = r.id AND a.school_id = ? AND a.status = "active") as occ 
                                 FROM hostel_rooms r WHERE r.id = ? AND r.school_id = ? LIMIT 1', [$schoolId, $roomId, $schoolId]);
        if (!$room) {
            flash('error', 'Room not found.');
            redirect(url('hostels?tab=allocations'));
        }

        if ((int)$room['occ'] >= (int)$room['capacity']) {
            flash('error', 'Room ' . $room['room_number'] . ' is already at full capacity (' . $room['capacity'] . ' beds).');
            redirect(url('hostels?tab=allocations'));
        }

        // Check if student already has active allocation
        $existing = Database::fetch('SELECT id FROM hostel_allocations WHERE student_id = ? AND school_id = ? AND status = "active" LIMIT 1', [$studentId, $schoolId]);
        if ($existing) {
            flash('error', 'This student is already allocated to a hostel room. Please vacate first.');
            redirect(url('hostels?tab=allocations'));
        }

        Database::insert(
            'INSERT INTO hostel_allocations (school_id, hostel_id, room_id, student_id, bed_number, allocated_date, status, notes, created_at, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, "active", ?, NOW(), NOW())',
            [$schoolId, (int)$room['hostel_id'], $roomId, $studentId, $bedNumber, $date, $notes]
        );

        flash('success', 'Student allocated to hostel room successfully.');
        redirect(url('hostels?tab=allocations'));
    }

    public function vacateAllocation(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $schoolId = (int) $this->schoolId();

        Database::execute(
            'UPDATE hostel_allocations SET status = "vacated", vacated_date = NOW(), updated_at = NOW() 
             WHERE id = ? AND school_id = ?',
            [(int)$id, $schoolId]
        );

        flash('success', 'Hostel bed marked as vacated.');
        redirect(url('hostels?tab=allocations'));
    }
}
