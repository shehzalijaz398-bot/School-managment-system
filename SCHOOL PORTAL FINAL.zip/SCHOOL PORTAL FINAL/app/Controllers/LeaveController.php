<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\LeaveRequest;
use App\Models\ParentModel;
use App\Models\Teacher;
use App\Services\LeaveService;
use Core\Auth;
use Core\Controller;
use Core\Database;

final class LeaveController extends Controller
{
    public function index(): void
    {
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();
        $schoolId = (int) $this->schoolId();

        // If Student or Parent, forward to Portal Leave interface
        if ($role === 'student' || $role === 'parent') {
            redirect(url('portal/leaves'));
        }

        $leaveModel = new LeaveRequest();
        $isSchoolAdmin = in_array($role, ['school_admin', 'admin', 'principal', 'super_admin', 'hr'], true) 
                         || hasPermission('leave.approve') 
                         || hasPermission('leave.manage');

        $isTeacher = ($role === 'teacher');
        $teacher = $isTeacher ? (new Teacher())->findByUserId((int) Auth::id()) : null;

        $tab = $_GET['tab'] ?? '';
        $q = trim((string)($_GET['q'] ?? ''));
        $status = trim((string)($_GET['status'] ?? ''));
        $classId = (int)($_GET['class_id'] ?? 0);
        $sectionId = (int)($_GET['section_id'] ?? 0);
        $deptId = (int)($_GET['department_id'] ?? 0);

        $filters = [
            'q' => $q,
            'status' => $status,
            'class_id' => $classId,
            'section_id' => $sectionId,
            'department_id' => $deptId,
        ];

        // Determine employee ID for "My Leaves"
        $employeeId = (int) ($user['employee_id'] ?? ($teacher['employee_id'] ?? 0));
        if (!$employeeId && !empty($user['email'])) {
            $empRow = Database::fetch('SELECT id FROM employees WHERE email = ? AND school_id = ? LIMIT 1', [$user['email'], $schoolId]);
            $employeeId = (int) ($empRow['id'] ?? 0);
        }

        // Classes & Sections for filters
        $classes = Database::fetchAll('SELECT id, name FROM classes WHERE school_id = ? ORDER BY numeric_name ASC, name ASC', [$schoolId]);
        $sections = $classId > 0 
            ? Database::fetchAll('SELECT id, name FROM sections WHERE school_id = ? AND class_id = ? ORDER BY name ASC', [$schoolId, $classId])
            : [];
        $departments = Database::fetchAll('SELECT id, name FROM departments WHERE school_id = ? ORDER BY name ASC', [$schoolId]);

        // Leave types
        $staffTypes = $leaveModel->types('staff');
        $studentTypes = $leaveModel->types('student');

        if ($isTeacher) {
            if ($tab === '') {
                $tab = 'students';
            }
            $stats = $teacher ? $leaveModel->getStats((int)$teacher['id']) : [
                'pending_total' => 0,
                'approved_month' => 0,
                'rejected_month' => 0,
                'on_leave_today' => 0,
            ];
            $studentLeaves = $teacher ? $leaveModel->forTeacherReview((int)$teacher['id'], $filters) : [];
            $myLeaves = $employeeId ? $leaveModel->forEmployee($employeeId, $status ?: null) : [];

            $this->view('leave/index', [
                'title' => 'Leave Management',
                'viewMode' => 'teacher',
                'isSchoolAdmin' => false,
                'isTeacher' => true,
                'tab' => $tab,
                'stats' => $stats,
                'studentLeaves' => $studentLeaves,
                'myLeaves' => $myLeaves,
                'staffLeaves' => [],
                'classes' => $classes,
                'sections' => $sections,
                'departments' => $departments,
                'staffTypes' => $staffTypes,
                'studentTypes' => $studentTypes,
                'employeeId' => $employeeId,
                'filters' => $filters,
            ]);
            return;
        }

        if ($isSchoolAdmin) {
            if ($tab === '') {
                $tab = 'students';
            }
            $stats = $leaveModel->getStats();
            $studentLeaves = $leaveModel->listStudents($filters);
            $staffLeaves = $leaveModel->listStaff($filters);
            $myLeaves = $employeeId ? $leaveModel->forEmployee($employeeId, $status ?: null) : [];

            $this->view('leave/index', [
                'title' => 'Leave Management & Approvals',
                'viewMode' => 'admin',
                'isSchoolAdmin' => true,
                'isTeacher' => false,
                'tab' => $tab,
                'stats' => $stats,
                'studentLeaves' => $studentLeaves,
                'staffLeaves' => $staffLeaves,
                'myLeaves' => $myLeaves,
                'classes' => $classes,
                'sections' => $sections,
                'departments' => $departments,
                'staffTypes' => $staffTypes,
                'studentTypes' => $studentTypes,
                'employeeId' => $employeeId,
                'filters' => $filters,
            ]);
            return;
        }

        // Staff self-service (Accountant, Finance, Receptionist, etc.)
        $tab = 'my';
        $myLeaves = $employeeId ? $leaveModel->forEmployee($employeeId, $status ?: null) : [];
        $stats = [
            'pending_total' => count(array_filter($myLeaves, fn($l) => $l['status'] === 'pending')),
            'approved_month' => count(array_filter($myLeaves, fn($l) => $l['status'] === 'approved')),
            'rejected_month' => count(array_filter($myLeaves, fn($l) => $l['status'] === 'rejected')),
            'on_leave_today' => 0,
        ];

        $this->view('leave/index', [
            'title' => 'My Leaves',
            'viewMode' => 'staff',
            'isSchoolAdmin' => false,
            'isTeacher' => false,
            'tab' => $tab,
            'stats' => $stats,
            'studentLeaves' => [],
            'staffLeaves' => [],
            'myLeaves' => $myLeaves,
            'classes' => [],
            'sections' => [],
            'departments' => [],
            'staffTypes' => $staffTypes,
            'studentTypes' => [],
            'employeeId' => $employeeId,
            'filters' => $filters,
        ]);
    }

    public function portalLeaves(): void
    {
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();
        $schoolId = (int) $this->schoolId();
        $leaveModel = new LeaveRequest();

        $student = null;
        $children = [];
        $selectedStudentId = 0;

        if ($role === 'parent') {
            $parentId = (int) ($user['parent_id'] ?? 0);
            if (!$parentId && !empty($user['email'])) {
                $pRow = Database::fetch('SELECT id FROM parents WHERE email = ? AND school_id = ? LIMIT 1', [$user['email'], $schoolId]);
                $parentId = (int) ($pRow['id'] ?? 0);
            }
            $children = (new ParentModel())->children($parentId);
            $selectedStudentId = (int) ($_GET['student_id'] ?? ($_SESSION['selected_student_id'] ?? ($children[0]['id'] ?? 0)));

            if ($selectedStudentId) {
                $_SESSION['selected_student_id'] = $selectedStudentId;
                $student = Database::fetch(
                    'SELECT s.*, c.name AS class_name, sec.name AS section_name 
                     FROM students s
                     LEFT JOIN classes c ON c.id = s.class_id
                     LEFT JOIN sections sec ON sec.id = s.section_id
                     WHERE s.id = ? AND s.school_id = ? LIMIT 1',
                    [$selectedStudentId, $schoolId]
                );
            }
        } else {
            // Student
            $student = Database::fetch(
                'SELECT s.*, c.name AS class_name, sec.name AS section_name 
                 FROM students s
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 WHERE s.user_id = ? AND s.school_id = ? LIMIT 1',
                [Auth::id(), $schoolId]
            );
            $selectedStudentId = (int) ($student['id'] ?? 0);
        }

        if (!$student) {
            flash('error', 'Student profile not linked to this account.');
            redirect(url('dashboard'));
        }

        $leaves = $leaveModel->forStudent($selectedStudentId);
        $types = $leaveModel->types('student');

        $stats = [
            'total' => count($leaves),
            'pending' => count(array_filter($leaves, fn($l) => $l['status'] === 'pending')),
            'approved' => count(array_filter($leaves, fn($l) => $l['status'] === 'approved')),
            'rejected' => count(array_filter($leaves, fn($l) => $l['status'] === 'rejected')),
        ];

        $this->view('leave/portal', [
            'title' => 'Leave Applications',
            'isParent' => ($role === 'parent'),
            'student' => $student,
            'children' => $children,
            'selectedStudentId' => $selectedStudentId,
            'leaves' => $leaves,
            'types' => $types,
            'stats' => $stats,
        ]);
    }

    public function store(): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();
        $schoolId = (int) $this->schoolId();

        $attachmentPath = null;
        if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            try {
                $attachmentPath = upload_file($_FILES['attachment'], 'leaves', [
                    'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
                ]);
            } catch (\Throwable $e) {
                flash('error', 'Attachment upload failed: ' . $e->getMessage());
                redirect($_SERVER['HTTP_REFERER'] ?? url('leave'));
            }
        }

        $leaveTypeId = (int) ($_POST['leave_type_id'] ?? 0);
        $startDate = trim((string) ($_POST['start_date'] ?? ''));
        $endDate = trim((string) ($_POST['end_date'] ?? ''));
        $reason = trim((string) ($_POST['reason'] ?? ''));

        if (!$leaveTypeId || !$startDate || !$endDate) {
            flash('error', 'Please fill in all required fields (Leave Type, Start Date, End Date).');
            redirect($_SERVER['HTTP_REFERER'] ?? url('leave'));
        }

        $service = new LeaveService();

        // 1. Student / Parent application
        if ($role === 'student' || $role === 'parent' || !empty($_POST['student_id'])) {
            $studentId = (int) ($_POST['student_id'] ?? 0);
            if (!$studentId && $role === 'student') {
                $st = Database::fetch('SELECT id FROM students WHERE user_id = ? AND school_id = ? LIMIT 1', [Auth::id(), $schoolId]);
                $studentId = (int) ($st['id'] ?? 0);
            }

            if (!$studentId) {
                flash('error', 'Student profile could not be identified.');
                redirect(url('portal/leaves'));
            }

            try {
                $service->submitStudent(
                    $studentId,
                    (int) Auth::id(),
                    $leaveTypeId,
                    $startDate,
                    $endDate,
                    $reason,
                    $attachmentPath
                );
                flash('success', 'Leave application submitted successfully! Your teacher or admin will review it.');
            } catch (\Throwable $e) {
                flash('error', $e->getMessage());
            }

            redirect(url('portal/leaves'));
        }

        // 2. Staff application (Teacher, HR, Accountant, Admin, etc.)
        $employeeId = (int) ($_POST['employee_id'] ?? ($user['employee_id'] ?? 0));
        if (!$employeeId && !empty($user['email'])) {
            $empRow = Database::fetch('SELECT id FROM employees WHERE email = ? AND school_id = ? LIMIT 1', [$user['email'], $schoolId]);
            $employeeId = (int) ($empRow['id'] ?? 0);
        }

        if (!$employeeId) {
            flash('error', 'No employee profile linked to your user account.');
            redirect(url('leave'));
        }

        try {
            $service->submitStaff(
                $employeeId,
                (int) Auth::id(),
                $leaveTypeId,
                $startDate,
                $endDate,
                $reason,
                $attachmentPath
            );
            flash('success', 'Leave request submitted successfully for approval.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        $tab = ($role === 'teacher') ? 'my' : 'my';
        redirect(url('leave?tab=' . $tab));
    }

    public function review(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();
        $user = Auth::user();
        $role = Auth::roleSlug();

        $canReview = in_array($role, ['school_admin', 'admin', 'principal', 'super_admin', 'hr', 'teacher'], true)
                     || hasPermission('leave.approve')
                     || hasPermission('leave.manage');

        if (!$canReview) {
            flash('error', 'You do not have permission to review leave requests.');
            redirect(url('leave'));
        }

        $status = $_POST['status'] ?? '';
        $notes = trim((string) ($_POST['review_notes'] ?? ''));
        $tab = $_POST['redirect_tab'] ?? 'students';

        try {
            (new LeaveService())->review((int) $id, $status, $notes ?: null, (int) Auth::id());
            flash('success', 'Leave request has been ' . htmlspecialchars($status) . ' successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('leave?tab=' . urlencode($tab)));
    }

    public function cancel(string $id): void
    {
        $this->requireCsrf();
        Auth::requireLogin();

        try {
            (new LeaveService())->cancel((int) $id, (int) Auth::id());
            flash('success', 'Leave request cancelled.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        $ref = $_SERVER['HTTP_REFERER'] ?? url('leave');
        redirect($ref);
    }

    public function exportCsv(): void
    {
        Auth::requireLogin();
        $role = Auth::roleSlug();
        if (!in_array($role, ['school_admin', 'admin', 'principal', 'super_admin', 'hr', 'teacher'], true)) {
            flash('error', 'Access denied.');
            redirect(url('leave'));
        }

        $leaveModel = new LeaveRequest();
        $type = $_GET['type'] ?? 'student';

        $leaves = ($type === 'staff')
            ? $leaveModel->listStaff($_GET)
            : $leaveModel->listStudents($_GET);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=leave_report_' . $type . '_' . date('Ymd_His') . '.csv');

        $output = fopen('php://output', 'w');
        if ($type === 'staff') {
            fputcsv($output, ['ID', 'Employee Code', 'Employee Name', 'Department', 'Designation', 'Leave Type', 'Start Date', 'End Date', 'Days', 'Reason', 'Status', 'Reviewer', 'Review Notes', 'Submitted At']);
            foreach ($leaves as $l) {
                fputcsv($output, [
                    $l['id'],
                    $l['employee_code'] ?? '',
                    $l['employee_name'] ?? '',
                    $l['department_name'] ?? '',
                    $l['designation_name'] ?? '',
                    $l['leave_type'] ?? '',
                    $l['start_date'],
                    $l['end_date'],
                    $l['days'],
                    $l['reason'] ?? '',
                    ucfirst($l['status']),
                    $l['reviewer_name'] ?? '',
                    $l['review_notes'] ?? '',
                    $l['created_at'],
                ]);
            }
        } else {
            fputcsv($output, ['ID', 'Admission No', 'Student Name', 'Class', 'Section', 'Leave Type', 'Start Date', 'End Date', 'Days', 'Reason', 'Status', 'Reviewer', 'Review Notes', 'Submitted At']);
            foreach ($leaves as $l) {
                fputcsv($output, [
                    $l['id'],
                    $l['admission_no'] ?? '',
                    $l['student_name'] ?? '',
                    $l['class_name'] ?? '',
                    $l['section_name'] ?? '',
                    $l['leave_type'] ?? '',
                    $l['start_date'],
                    $l['end_date'],
                    $l['days'],
                    $l['reason'] ?? '',
                    ucfirst($l['status']),
                    $l['reviewer_name'] ?? '',
                    $l['review_notes'] ?? '',
                    $l['created_at'],
                ]);
            }
        }
        fclose($output);
        exit;
    }
}
