<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\SecurityService;
use Core\Controller;

final class SecurityController extends Controller
{
    /**
     * Security Center Dashboard
     */
    public function index(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int) $this->schoolId();
        $secService = new SecurityService();

        $metrics = $secService->getSecurityDashboardMetrics($schoolId);
        $settings = $secService->getSecuritySettings($schoolId);
        $history = $secService->getLoginHistory($schoolId, $_GET);
        $incidents = $secService->getSecurityIncidents($schoolId, $_GET);
        $audit = $secService->runTenantIsolationAudit($schoolId);

        $this->view('admin/security/index', [
            'title' => 'Security Center & Access Control',
            'metrics' => $metrics,
            'settings' => $settings,
            'history' => $history,
            'incidents' => $incidents,
            'audit' => $audit,
            'filters' => [
                'status' => $_GET['status'] ?? 'all',
                'q' => $_GET['q'] ?? '',
            ]
        ]);
    }

    /**
     * Update Password Policy & Lockout Controls
     */
    public function updatePolicy(): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();

        try {
            (new SecurityService())->updateSecuritySettings($schoolId, $_POST);
            flash('success', 'Security policies and lockout controls updated successfully.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('admin/security'));
    }

    /**
     * Resolve Security Incident Alert
     */
    public function resolveIncident(string $id): void
    {
        requirePermission('settings.manage');
        $this->requireCsrf();
        $schoolId = (int) $this->schoolId();
        $userId = (int) $this->userId();
        $notes = trim((string)($_POST['resolution_notes'] ?? 'Investigated and confirmed benign or resolved.'));

        try {
            (new SecurityService())->resolveSecurityIncident($schoolId, (int) $id, $notes, $userId);
            flash('success', 'Security incident resolved and audit status updated.');
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
        }

        redirect(url('admin/security#incidents'));
    }

    /**
     * Trigger Multi-Tenant Isolation Security Audit
     */
    public function runIsolationAudit(): void
    {
        requirePermission('settings.manage');
        $schoolId = (int) $this->schoolId();

        $audit = (new SecurityService())->runTenantIsolationAudit($schoolId);

        if (function_exists('is_json_request') && is_json_request()) {
            $this->json(['success' => true, 'audit' => $audit]);
            return;
        }

        flash('success', "Tenant Isolation Audit completed with Security Score: {$audit['score']}% ({$audit['secure_tables_count']}/{$audit['total_tables_checked']} tables verified).");
        redirect(url('admin/security'));
    }
}
