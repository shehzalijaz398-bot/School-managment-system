<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\AcademicYear;
use Core\Controller;
use Core\Database;

final class AcademicSessionController extends Controller
{
    public function index(): void
    {
        requirePermission('academic_sessions.view');
        
        $sessions = Database::fetchAll("SELECT * FROM academic_years WHERE school_id = ? ORDER BY start_date DESC", [$this->schoolId()]);
        
        foreach ($sessions as &$session) {
            $session['terms'] = Database::fetchAll("SELECT * FROM academic_terms WHERE academic_year_id = ? AND school_id = ? ORDER BY start_date ASC", [(int)$session['id'], $this->schoolId()]);
            $session['term_count'] = count($session['terms']);
            
            $dep = Database::fetch("
                SELECT (
                    (SELECT COUNT(*) FROM students WHERE academic_year_id = :id1 AND school_id = :sch1) +
                    (SELECT COUNT(*) FROM student_fee_invoices WHERE academic_year_id = :id2 AND school_id = :sch2) +
                    (SELECT COUNT(*) FROM exams WHERE academic_year_id = :id3 AND school_id = :sch3) +
                    (SELECT COUNT(*) FROM student_attendance WHERE academic_year_id = :id4 AND school_id = :sch4) +
                    (SELECT COUNT(*) FROM assignments WHERE academic_year_id = :id5 AND school_id = :sch5) +
                    (SELECT COUNT(*) FROM timetables WHERE academic_year_id = :id6 AND school_id = :sch6) +
                    (SELECT COUNT(*) FROM sections WHERE academic_year_id = :id7 AND school_id = :sch7)
                ) as total
            ", [
                'id1' => (int)$session['id'], 'sch1' => $this->schoolId(),
                'id2' => (int)$session['id'], 'sch2' => $this->schoolId(),
                'id3' => (int)$session['id'], 'sch3' => $this->schoolId(),
                'id4' => (int)$session['id'], 'sch4' => $this->schoolId(),
                'id5' => (int)$session['id'], 'sch5' => $this->schoolId(),
                'id6' => (int)$session['id'], 'sch6' => $this->schoolId(),
                'id7' => (int)$session['id'], 'sch7' => $this->schoolId(),
            ]);
            $session['linked_count'] = (int)($dep['total'] ?? 0);

            $st = $session['status'] ?? '';
            if ((int)$session['is_active'] === 1 || $st === 'active') {
                $session['status'] = 'active';
                $session['status_label'] = 'Active';
                $session['is_current'] = true;
            } elseif ($st === 'draft') {
                $session['status'] = 'draft';
                $session['status_label'] = 'Draft';
                $session['is_current'] = false;
            } elseif ($st === 'archived') {
                $session['status'] = 'archived';
                $session['status_label'] = 'Archived';
                $session['is_current'] = false;
            } elseif (strtotime($session['start_date']) > time()) {
                $session['status'] = 'draft';
                $session['status_label'] = 'Draft';
                $session['is_current'] = false;
            } else {
                $session['status'] = 'archived';
                $session['status_label'] = 'Archived';
                $session['is_current'] = false;
            }
        }
        unset($session);
        
        $this->view('academic_sessions/index', [
            'title' => 'Academic Years',
            'sessions' => $sessions
        ]);
    }

    private function normalizeDateInput(string $val): string
    {
        $val = trim($val);
        if ($val === '') {
            return '';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
            return $val;
        }
        if (preg_match('/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/', $val, $m)) {
            $p1 = (int)$m[1];
            $p2 = (int)$m[2];
            $year = (int)$m[3];
            if ($p1 > 12 && $p2 <= 12) {
                return sprintf('%04d-%02d-%02d', $year, $p2, $p1);
            }
            if ($p2 > 12 && $p1 <= 12) {
                return sprintf('%04d-%02d-%02d', $year, $p1, $p2);
            }
            $ts = strtotime($val);
            if ($ts !== false) {
                return date('Y-m-d', $ts);
            }
            return sprintf('%04d-%02d-%02d', $year, $p1, $p2);
        }
        $ts = strtotime($val);
        if ($ts !== false) {
            return date('Y-m-d', $ts);
        }
        return $val;
    }

    public function store(): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();

        $startDate = $this->normalizeDateInput((string)($_POST['start_date'] ?? ''));
        $endDate = $this->normalizeDateInput((string)($_POST['end_date'] ?? ''));
        $_POST['start_date'] = $startDate;
        $_POST['end_date'] = $endDate;

        $data = $this->validate($_POST, [
            'name' => 'required|max:100',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);

        $status = trim((string)($_POST['status'] ?? 'draft'));
        if (!in_array($status, ['active', 'draft', 'archived'], true)) {
            $status = 'draft';
        }
        $isActive = ($status === 'active' || !empty($_POST['is_active'])) ? 1 : 0;
        if ($isActive === 1) {
            Database::execute("UPDATE academic_years SET is_active = 0, status = 'archived' WHERE school_id = ?", [$this->schoolId()]);
            $status = 'active';
        }

        (new AcademicYear())->create([
            'name' => trim($data['name']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'status' => $status,
            'is_active' => $isActive
        ]);

        flash('success', 'Academic Year created successfully.');
        redirect(url('academic-sessions'));
    }

    public function update(string $id): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $session = (new AcademicYear())->find((int) $id);
        if (!$session || (int)$session['school_id'] !== (int)$this->schoolId()) {
            abort(404);
        }

        $startDate = $this->normalizeDateInput((string)($_POST['start_date'] ?? ''));
        $endDate = $this->normalizeDateInput((string)($_POST['end_date'] ?? ''));
        $_POST['start_date'] = $startDate;
        $_POST['end_date'] = $endDate;

        $data = $this->validate($_POST, [
            'name' => 'required|max:100',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);

        $status = trim((string)($_POST['status'] ?? ''));
        if (!in_array($status, ['active', 'draft', 'archived'], true)) {
            $status = (int)$session['is_active'] === 1 ? 'active' : 'draft';
        }
        $isActive = ($status === 'active' || !empty($_POST['is_active'])) ? 1 : 0;
        if ($isActive === 1) {
            Database::execute("UPDATE academic_years SET is_active = 0, status = 'archived' WHERE school_id = ?", [$this->schoolId()]);
            $status = 'active';
        }

        (new AcademicYear())->update((int) $id, [
            'name' => trim($data['name']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'status' => $status,
            'is_active' => $isActive
        ]);

        flash('success', 'Academic Year updated successfully.');
        redirect(url('academic-sessions'));
    }

    public function destroy(string $id): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $session = (new AcademicYear())->find((int) $id);
        if (!$session || (int)$session['school_id'] !== (int)$this->schoolId()) {
            abort(404);
        }

        if ((int)$session['is_active'] === 1) {
            flash('error', 'Cannot delete the currently active academic year. Please activate another session first.');
            redirect(url('academic-sessions'));
            return;
        }

        // Check all linked records across modules
        $invoicesCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM student_fee_invoices WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $studentsCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM students WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $examsCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM exams WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $attendanceCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM student_attendance WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $assignmentsCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM assignments WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $timetablesCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM timetables WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $sectionsCount = (int) (Database::fetch(
            "SELECT COUNT(*) as cnt FROM sections WHERE academic_year_id = ? AND school_id = ?",
            [(int) $id, $this->schoolId()]
        )['cnt'] ?? 0);

        $issues = [];
        if ($invoicesCount > 0) {
            $issues[] = "{$invoicesCount} fee invoice(s)";
        }
        if ($studentsCount > 0) {
            $issues[] = "{$studentsCount} student(s)";
        }
        if ($examsCount > 0) {
            $issues[] = "{$examsCount} exam(s)";
        }
        if ($attendanceCount > 0) {
            $issues[] = "{$attendanceCount} attendance record(s)";
        }
        if ($assignmentsCount > 0) {
            $issues[] = "{$assignmentsCount} assignment(s)";
        }
        if ($timetablesCount > 0) {
            $issues[] = "{$timetablesCount} timetable(s)";
        }
        if ($sectionsCount > 0) {
            $issues[] = "{$sectionsCount} class section(s)";
        }

        if (!empty($issues)) {
            $issueList = implode(', ', $issues);
            flash('error', "Cannot delete this academic year because it has linked records ({$issueList}). Please archive this academic year instead.");
            redirect(url('academic-sessions'));
            return;
        }

        try {
            Database::execute("DELETE FROM academic_terms WHERE academic_year_id = ? AND school_id = ?", [(int) $id, $this->schoolId()]);
            (new AcademicYear())->delete((int) $id);
            flash('success', 'Academic Year deleted successfully.');
        } catch (\PDOException $e) {
            flash('error', 'Cannot delete this academic year due to existing database dependencies. Please archive it instead.');
        } catch (\Throwable $e) {
            flash('error', 'An unexpected error occurred while deleting the academic year.');
        }

        redirect(url('academic-sessions'));
    }

    public function activate(string $id): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $session = (new AcademicYear())->find((int) $id);
        if (!$session || (int)$session['school_id'] !== (int)$this->schoolId()) {
            abort(404);
        }

        Database::execute("UPDATE academic_years SET is_active = 0, status = 'archived' WHERE school_id = ?", [$this->schoolId()]);
        (new AcademicYear())->update((int) $id, ['is_active' => 1, 'status' => 'active']);

        flash('success', 'Academic Year activated.');
        redirect(url('academic-sessions'));
    }

    public function storeTerm(string $yearId): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $session = (new AcademicYear())->find((int) $yearId);
        if (!$session || $session['school_id'] !== $this->schoolId()) {
            abort(404);
        }

        $data = $this->validate($_POST, [
            'name' => 'required|max:50',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);

        (new \App\Models\AcademicTerm())->create([
            'academic_year_id' => (int) $yearId,
            'name' => $data['name'],
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'is_active' => 0
        ]);

        flash('success', 'Academic term added.');
        redirect(url('academic-sessions'));
    }

    public function activateTerm(string $id): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $term = (new \App\Models\AcademicTerm())->find((int) $id);
        if (!$term || $term['school_id'] !== $this->schoolId()) {
            abort(404);
        }

        Database::execute("UPDATE academic_terms SET is_active = 0 WHERE academic_year_id = ? AND school_id = ?", [(int)$term['academic_year_id'], $this->schoolId()]);
        
        (new \App\Models\AcademicTerm())->update((int) $id, ['is_active' => 1]);

        flash('success', 'Academic term activated.');
        redirect(url('academic-sessions'));
    }

    public function destroyTerm(string $id): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $term = (new \App\Models\AcademicTerm())->find((int) $id);
        if (!$term || $term['school_id'] !== $this->schoolId()) {
            abort(404);
        }

        (new \App\Models\AcademicTerm())->delete((int) $id);

        flash('success', 'Academic term deleted.');
        redirect(url('academic-sessions'));
    }

    public function promotionForm(): void
    {
        requirePermission('academic_sessions.manage');
        
        $schoolId = \Core\Auth::schoolId();
        
        $classes = (new \App\Models\ClassModel())->withSections();
        $years = Database::fetchAll("SELECT id, name, is_active, start_date, end_date FROM academic_years WHERE school_id = ? ORDER BY start_date DESC", [$schoolId]);
        
        $currentYear = null;
        $nextYear = null;
        foreach ($years as $yr) {
            if ($yr['is_active']) {
                $currentYear = $yr;
            }
        }
        // If currentYear found, look for next year
        if ($currentYear) {
            foreach ($years as $yr) {
                if (!$yr['is_active'] && strtotime($yr['start_date']) >= strtotime($currentYear['end_date'])) {
                    $nextYear = $yr;
                    break;
                }
            }
        }
        if (!$nextYear && !empty($years)) {
            foreach ($years as $yr) {
                if (!$yr['is_active']) {
                    $nextYear = $yr;
                    break;
                }
            }
        }

        $sourceYearId = (int)($_GET['source_year_id'] ?? ($currentYear['id'] ?? 0));
        $targetYearId = (int)($_GET['target_year_id'] ?? ($nextYear['id'] ?? 0));

        $this->view('academic_sessions/promotion', [
            'title' => 'Student Promotion & Session Rollover',
            'classes' => $classes,
            'years' => $years,
            'currentYear' => $currentYear,
            'nextYear' => $nextYear,
            'sourceYearId' => $sourceYearId,
            'targetYearId' => $targetYearId,
        ]);
    }

    public function processMassPromotion(): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $schoolId = \Core\Auth::schoolId();
        
        $sourceClassId = (int)($_POST['source_class_id'] ?? 0);
        $sourceSectionId = (int)($_POST['source_section_id'] ?? 0);
        $targetClassId = (int)($_POST['target_class_id'] ?? 0);
        $targetSectionId = (int)($_POST['target_section_id'] ?? 0);
        $targetYearId = (int)($_POST['target_year_id'] ?? 0);
        $passPercentage = (float)($_POST['pass_percentage'] ?? 40.0);
        
        if ($sourceClassId === 0 || $targetClassId === 0 || $targetYearId === 0) {
            flash('error', 'Please define Source Class, Target Class, and Target Academic Year correctly.');
            redirect(url('academic/promotion'));
            return;
        }

        $sourceClass = Database::fetch("SELECT id FROM classes WHERE id = ? AND school_id = ?", [$sourceClassId, $schoolId]);
        $targetClass = Database::fetch("SELECT id FROM classes WHERE id = ? AND school_id = ?", [$targetClassId, $schoolId]);
        $targetYear = Database::fetch("SELECT id, is_active FROM academic_years WHERE id = ? AND school_id = ?", [$targetYearId, $schoolId]);

        if (!$sourceClass || !$targetClass || !$targetYear) {
            flash('error', 'Invalid source class, target class, or target academic year.');
            redirect(url('academic/promotion'));
            return;
        }

        if ($sourceClassId === $targetClassId && (int)$targetYear['id'] === (int)activeAcademicYearId()) {
            flash('error', 'Cannot promote students to the same class within the same active academic year.');
            redirect(url('academic/promotion'));
            return;
        }

        $sql = "SELECT id, class_id, section_id, first_name, last_name, roll_no FROM students WHERE school_id = ? AND class_id = ? AND status = 'active'";
        $params = [$schoolId, $sourceClassId];
        if ($sourceSectionId > 0) {
            $sql .= " AND section_id = ?";
            $params[] = $sourceSectionId;
        }

        $students = Database::fetchAll($sql, $params);

        if (empty($students)) {
            flash('warning', 'No active students found in the selected source class.');
            redirect(url('academic/promotion'));
            return;
        }

        $promotedCount = 0;
        $retainedCount = 0;

        Database::beginTransaction();
        try {
            foreach ($students as $student) {
                // Check latest exam snapshot for performance criteria
                $snapshot = Database::fetch(
                    "SELECT final_percentage FROM exam_results_snapshot WHERE student_id = ? AND school_id = ? ORDER BY id DESC LIMIT 1",
                    [$student['id'], $schoolId]
                );
                
                $finalPerc = $snapshot ? (float)$snapshot['final_percentage'] : 50.0; // Default to passing if no exam record yet
                
                if ($finalPerc >= $passPercentage) {
                    Database::execute(
                        "UPDATE students SET class_id = ?, section_id = ?, academic_year_id = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
                        [$targetClassId, $targetSectionId ?: null, $targetYearId, $student['id'], $schoolId]
                    );
                    
                    Database::insert(
                        "INSERT INTO student_academic_history (school_id, student_id, academic_year_id, class_id, section_id, roll_no, result_status, remarks, created_at)
                         VALUES (?, ?, ?, ?, ?, ?, 'promoted', ?, NOW())",
                        [$schoolId, $student['id'], $targetYearId, $targetClassId, $targetSectionId ?: null, $student['roll_no'], "Promoted from Class ID {$sourceClassId} ({$finalPerc}%)"]
                    );
                    
                    $promotedCount++;
                } else {
                    Database::execute(
                        "UPDATE students SET academic_year_id = ?, updated_at = NOW() WHERE id = ? AND school_id = ?",
                        [$targetYearId, $student['id'], $schoolId]
                    );
                    
                    Database::insert(
                        "INSERT INTO student_academic_history (school_id, student_id, academic_year_id, class_id, section_id, roll_no, result_status, remarks, created_at)
                         VALUES (?, ?, ?, ?, ?, ?, 'retained', ?, NOW())",
                        [$schoolId, $student['id'], $targetYearId, $sourceClassId, $student['section_id'] ?: null, $student['roll_no'], "Retained in Class ID {$sourceClassId} ({$finalPerc}%)"]
                    );
                    
                    $retainedCount++;
                }
            }
            Database::commit();
            flash('success', "🚀 Promotion execution complete. {$promotedCount} Promoted to next class, {$retainedCount} Retained.");
        } catch (\Throwable $e) {
            Database::rollBack();
            \Core\Logger\StructuredLogger::error("Mass promotion failure: " . $e->getMessage(), [
                'exception' => $e,
                'source_class_id' => $sourceClassId,
                'target_class_id' => $targetClassId,
                'target_year_id' => $targetYearId,
            ]);
            flash('error', 'Critical failure during promotion execution. Database changes rolled back safely.');
        }

        redirect(url('academic/promotion'));
    }

    public function executeSessionRollover(): void
    {
        requirePermission('academic_sessions.manage');
        $this->requireCsrf();
        
        $schoolId = \Core\Auth::schoolId();
        $targetYearId = (int)($_POST['rollover_year_id'] ?? 0);
        
        if ($targetYearId === 0) {
            flash('error', 'Select a valid target academic year for the rollover operation.');
            redirect(url('academic/promotion'));
            return;
        }

        $validYear = Database::fetch("SELECT id FROM academic_years WHERE id = ? AND school_id = ?", [$targetYearId, $schoolId]);
        if (!$validYear) {
            flash('error', 'Target academic year not found or unauthorized.');
            redirect(url('academic/promotion'));
            return;
        }

        Database::beginTransaction();
        try {
            Database::execute("UPDATE academic_years SET is_active = 0 WHERE school_id = ?", [$schoolId]);
            Database::execute("UPDATE academic_years SET is_active = 1 WHERE id = ? AND school_id = ?", [$targetYearId, $schoolId]);
            Database::commit();
            flash('success', "System Rollover Successful! New active academic year globally deployed.");
        } catch (\Throwable $e) {
            Database::rollBack();
            \Core\Logger\StructuredLogger::error("Session rollover failure: " . $e->getMessage(), ['exception' => $e, 'target_year_id' => $targetYearId]);
            flash('error', 'Rollover aborted due to internal database failure.');
        }

        redirect(url('academic/promotion'));
    }

    public function switchViewSession(): void
    {
        \Core\Auth::requireLogin();
        $schoolId = $this->schoolId();
        $yearId = (int)($_GET['year_id'] ?? 0);

        if ($yearId > 0) {
            $year = Database::fetch(
                'SELECT * FROM academic_years WHERE id = ? AND school_id = ? LIMIT 1',
                [$yearId, $schoolId]
            );
            if ($year) {
                $_SESSION['selected_academic_year_id'] = $yearId;
            }
        } else {
            unset($_SESSION['selected_academic_year_id']);
        }

        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if ($referer && !str_contains($referer, 'academic-sessions/switch-view') && !str_contains($referer, 'settings?tab=academic-setup')) {
            redirect($referer);
        } else {
            redirect(url('dashboard'));
        }
    }
}
