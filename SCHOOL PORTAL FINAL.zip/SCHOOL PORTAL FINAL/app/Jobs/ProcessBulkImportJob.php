<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\DataImportExportService;
use Core\Database;
use Core\Queue\JobInterface;
use Throwable;

/**
 * ProcessBulkImportJob
 * Asynchronously processes bulk data imports in transactional batches,
 * eliminating web request timeouts and tracking progress in bulk_import_jobs table.
 */
final class ProcessBulkImportJob implements JobInterface
{
    public function __construct(
        public readonly int $jobRecordId,
        public readonly int $schoolId,
        public readonly string $entity,
        public readonly array $validRows,
        public readonly ?int $userId = null
    ) {}

    public function handle(): void
    {
        // 1. Mark job as processing
        Database::execute(
            'UPDATE bulk_import_jobs 
             SET status = "processing", total_rows = ?, processed_rows = 0, success_count = 0, error_count = 0 
             WHERE id = ? AND school_id = ?',
            [count($this->validRows), $this->jobRecordId, $this->schoolId]
        );

        $importService = new DataImportExportService();
        $chunkSize = 50;
        $chunks = array_chunk($this->validRows, $chunkSize);

        $totalSuccess = 0;
        $totalErrors = 0;
        $errorSummaries = [];
        $processedSoFar = 0;

        foreach ($chunks as $chunkIndex => $chunk) {
            try {
                $chunkResult = $importService->commitImport($this->schoolId, $this->entity, $chunk, $this->userId ?? 0, true);
                $totalSuccess += (int) ($chunkResult['imported_count'] ?? count($chunk));
            } catch (Throwable $e) {
                $totalErrors += count($chunk);
                $errorSummaries[] = sprintf("Chunk %d failed: %s", $chunkIndex + 1, $e->getMessage());
                error_log(sprintf("[ProcessBulkImportJob] Chunk %d error: %s", $chunkIndex + 1, $e->getMessage()));
            }

            $processedSoFar += count($chunk);

            // Update progress incrementally in database for real-time UI polling
            Database::execute(
                'UPDATE bulk_import_jobs 
                 SET processed_rows = ?, success_count = ?, error_count = ? 
                 WHERE id = ? AND school_id = ?',
                [$processedSoFar, $totalSuccess, $totalErrors, $this->jobRecordId, $this->schoolId]
            );
        }

        // 2. Mark job as completed or failed
        $finalStatus = ($totalErrors === 0 || $totalSuccess > 0) ? 'completed' : 'failed';
        $summaryText = !empty($errorSummaries) ? implode('; ', array_slice($errorSummaries, 0, 5)) : null;

        Database::execute(
            'UPDATE bulk_import_jobs 
             SET status = ?, error_summary = ?, completed_at = NOW() 
             WHERE id = ? AND school_id = ?',
            [$finalStatus, $summaryText, $this->jobRecordId, $this->schoolId]
        );

        // 3. Notify user if userId provided
        if ($this->userId !== null && $this->userId > 0) {
            notify_user(
                $this->schoolId,
                $this->userId,
                'import_completed',
                'Bulk Import Finished',
                sprintf(
                    "Import of %s finished: %d records imported successfully, %d failed.",
                    ucfirst($this->entity),
                    $totalSuccess,
                    $totalErrors
                ),
                'bulk_import_jobs',
                $this->jobRecordId,
                'import-export'
            );
        }
    }
}
