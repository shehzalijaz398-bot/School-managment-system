<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Queue\JobInterface;
use Throwable;

/**
 * GenerateReportJob
 * Asynchronously generates large-scale tabular and analytical CSV/Excel reports,
 * preventing browser HTTP request timeouts on large school datasets.
 */
final class GenerateReportJob implements JobInterface
{
    public function __construct(
        public readonly int $jobRecordId,
        public readonly int $schoolId,
        public readonly string $reportType,
        public readonly array $parameters = [],
        public readonly ?int $userId = null
    ) {}

    public function handle(): void
    {
        // 1. Mark job as processing
        Database::execute(
            'UPDATE report_export_jobs SET status = "processing" WHERE id = ? AND school_id = ?',
            [$this->jobRecordId, $this->schoolId]
        );

        $reportsDir = (defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2)) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'reports';
        if (!is_dir($reportsDir)) {
            @mkdir($reportsDir, 0755, true);
        }

        $filename = sprintf(
            'report_%s_tenant_%d_%s_%s.csv',
            preg_replace('/[^a-zA-Z0-9_]/', '', $this->reportType),
            $this->schoolId,
            date('Ymd_His'),
            bin2hex(random_bytes(4))
        );
        $fullPath = $reportsDir . DIRECTORY_SEPARATOR . $filename;
        $relativeUrl = 'storage/reports/' . $filename;

        $fp = fopen($fullPath, 'w');
        if (!$fp) {
            throw new \RuntimeException("Unable to open report export target: {$fullPath}");
        }

        try {
            // Write UTF-8 BOM for Excel compatibility
            fprintf($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));

            switch ($this->reportType) {
                case 'student_roster':
                    fputcsv($fp, ['Admission No', 'Student Name', 'Gender', 'Class', 'Section', 'Phone', 'Enrollment Status']);
                    $students = Database::fetchAll(
                        'SELECT s.admission_no, CONCAT(s.first_name, " ", COALESCE(s.last_name, "")) as name, s.gender,
                                c.name as class_name, sec.name as section_name, s.phone, s.status
                         FROM students s
                         LEFT JOIN classes c ON c.id = s.class_id
                         LEFT JOIN sections sec ON sec.id = s.section_id
                         WHERE s.school_id = ? ORDER BY c.id, sec.id, s.admission_no',
                        [$this->schoolId]
                    );
                    foreach ($students as $row) {
                        fputcsv($fp, [
                            $row['admission_no'],
                            trim($row['name']),
                            ucfirst($row['gender'] ?? ''),
                            $row['class_name'] ?? 'Unassigned',
                            $row['section_name'] ?? '—',
                            $row['phone'] ?? '—',
                            ucfirst($row['status'] ?? 'active')
                        ]);
                    }
                    break;

                case 'financial_ledger':
                    fputcsv($fp, ['Invoice #', 'Student Name', 'Admission No', 'Fee Title', 'Total Due', 'Paid Amount', 'Balance', 'Status', 'Due Date']);
                    $invoices = Database::fetchAll(
                        'SELECT i.invoice_no, CONCAT(s.first_name, " ", COALESCE(s.last_name, "")) as student_name, s.admission_no,
                                i.title, i.total_amount, i.paid_amount, (i.total_amount - i.paid_amount) as balance, i.status, i.due_date
                         FROM student_fee_invoices i
                         INNER JOIN students s ON s.id = i.student_id
                         WHERE i.school_id = ? ORDER BY i.id DESC',
                        [$this->schoolId]
                    );
                    foreach ($invoices as $inv) {
                        fputcsv($fp, [
                            $inv['invoice_no'],
                            trim($inv['student_name']),
                            $inv['admission_no'],
                            $inv['title'] ?? 'Fee Invoice',
                            number_format((float)$inv['total_amount'], 2),
                            number_format((float)$inv['paid_amount'], 2),
                            number_format(max(0.0, (float)$inv['balance']), 2),
                            ucfirst($inv['status']),
                            $inv['due_date']
                        ]);
                    }
                    break;

                case 'attendance_summary':
                default:
                    fputcsv($fp, ['Student Name', 'Admission No', 'Class', 'Date', 'Status', 'Remarks']);
                    $attRows = Database::fetchAll(
                        'SELECT CONCAT(s.first_name, " ", COALESCE(s.last_name, "")) as student_name, s.admission_no,
                                c.name as class_name, a.attendance_date, a.status, a.remarks
                         FROM student_attendance a
                         INNER JOIN students s ON s.id = a.student_id
                         LEFT JOIN classes c ON c.id = a.class_id
                         WHERE a.school_id = ? ORDER BY a.attendance_date DESC LIMIT 5000',
                        [$this->schoolId]
                    );
                    foreach ($attRows as $att) {
                        fputcsv($fp, [
                            trim($att['student_name']),
                            $att['admission_no'],
                            $att['class_name'] ?? '—',
                            $att['attendance_date'],
                            ucfirst($att['status']),
                            $att['remarks'] ?? ''
                        ]);
                    }
                    break;
            }

            fclose($fp);

            // 2. Mark report job as completed
            Database::execute(
                'UPDATE report_export_jobs 
                 SET status = "completed", file_path = ?, completed_at = NOW() 
                 WHERE id = ? AND school_id = ?',
                [$relativeUrl, $this->jobRecordId, $this->schoolId]
            );

            // 3. Notify requesting user
            if ($this->userId !== null && $this->userId > 0) {
                notify_user(
                    $this->schoolId,
                    $this->userId,
                    'report_ready',
                    'Report Ready for Download',
                    sprintf("Your %s export is ready.", ucwords(str_replace('_', ' ', $this->reportType))),
                    'report_export_jobs',
                    $this->jobRecordId,
                    $relativeUrl
                );
            }

        } catch (Throwable $e) {
            fclose($fp);
            @unlink($fullPath);

            Database::execute(
                'UPDATE report_export_jobs SET status = "failed", completed_at = NOW() WHERE id = ? AND school_id = ?',
                [$this->jobRecordId, $this->schoolId]
            );

            throw $e;
        }
    }
}
