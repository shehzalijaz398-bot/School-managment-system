<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Queue\JobInterface;

/**
 * SendDailyDiaryBroadcastJob
 * Asynchronously notifies all students and parents of a class about new daily diary tasks.
 */
final class SendDailyDiaryBroadcastJob implements JobInterface
{
    public function __construct(
        public readonly int $schoolId,
        public readonly int $classId,
        public readonly int $sectionId,
        public readonly string $diaryDate,
        public readonly int $tasksCount
    ) {}

    public function handle(): void
    {
        // 1. Fetch all student user IDs in this class & section
        $students = Database::fetchAll(
            'SELECT s.id, s.user_id 
             FROM students s 
             WHERE s.school_id = ? AND s.class_id = ? AND s.section_id = ? AND s.status = "active"',
            [$this->schoolId, $this->classId, $this->sectionId]
        );

        if (empty($students)) {
            return;
        }

        $studentIds = array_column($students, 'id');
        $studentUserIds = array_filter(array_column($students, 'user_id'));

        // 2. Fetch all parent user IDs linked to these students
        $parentUserIds = [];
        if (!empty($studentIds)) {
            $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
            $params = array_merge([$this->schoolId], $studentIds);
            
            $parentRows = Database::fetchAll(
                "SELECT DISTINCT u.id 
                 FROM users u
                 INNER JOIN student_parents sp ON sp.parent_id = u.parent_id
                 WHERE u.school_id = ? AND sp.student_id IN ({$placeholders}) AND u.status = 1",
                $params
            );
            $parentUserIds = array_column($parentRows, 'id');
        }

        $allRecipientUserIds = array_unique(array_merge($studentUserIds, $parentUserIds));
        if (empty($allRecipientUserIds)) {
            return;
        }

        $title = "Daily School Diary Updated ({$this->diaryDate})";
        $message = "{$this->tasksCount} subject homework tasks have been posted for today.";

        (new SendBroadcastNotificationJob(
            schoolId: $this->schoolId,
            recipientUserIds: array_values($allRecipientUserIds),
            type: 'diary',
            title: $title,
            message: $message,
            entityType: 'assignments',
            entityId: null,
            actionUrl: 'portal/assignments'
        ))->handle();
    }
}
