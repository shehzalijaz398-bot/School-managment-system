<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Queue\JobInterface;

/**
 * SendBroadcastNotificationJob
 * Asynchronously delivers bulk notifications across thousands of users without HTTP latency.
 */
final class SendBroadcastNotificationJob implements JobInterface
{
    /**
     * @param int $schoolId
     * @param array<int> $recipientUserIds
     * @param string $type
     * @param string $title
     * @param string $message
     * @param string $entityType
     * @param int|null $entityId
     * @param string|null $actionUrl
     */
    public function __construct(
        public readonly int $schoolId,
        public readonly array $recipientUserIds,
        public readonly string $type,
        public readonly string $title,
        public readonly string $message,
        public readonly string $entityType = 'announcement',
        public readonly ?int $entityId = null,
        public readonly ?string $actionUrl = null
    ) {}

    public function handle(): void
    {
        if (empty($this->recipientUserIds)) {
            return;
        }

        $now = date('Y-m-d H:i:s');

        // Chunk inserts to optimize MySQL statement size
        $chunks = array_chunk($this->recipientUserIds, 250);

        foreach ($chunks as $chunk) {
            $values = [];
            $params = [];

            foreach ($chunk as $userId) {
                $values[] = '(?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())';
                $params[] = $this->schoolId;
                $params[] = (int) $userId;
                $params[] = $this->type;
                $params[] = $this->title;
                $params[] = $this->message;
                $params[] = $this->entityType;
                $params[] = $this->entityId;
                $params[] = $this->actionUrl;
            }

            $sql = 'INSERT INTO notifications 
                    (school_id, user_id, type, title, message, entity_type, entity_id, link, is_read, created_at) 
                    VALUES ' . implode(', ', $values);

            Database::execute($sql, $params);
        }
    }
}
