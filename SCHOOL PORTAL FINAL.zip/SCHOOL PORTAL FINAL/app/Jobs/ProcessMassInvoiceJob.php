<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Queue\JobInterface;

/**
 * ProcessMassInvoiceJob
 * Asynchronously generates bulk fee invoices across students/classes without stalling the web request.
 */
final class ProcessMassInvoiceJob implements JobInterface
{
    public function __construct(
        public readonly int $schoolId,
        public readonly int $academicYearId,
        public readonly int $classId,
        public readonly int $feeCategoryId,
        public readonly float $amount,
        public readonly string $dueDate,
        public readonly string $month,
        public readonly int $createdBy
    ) {}

    public function handle(): void
    {
        // Fetch active students in target class (or all classes if classId is 0)
        $sql = 'SELECT id, user_id, admission_no, first_name, last_name 
                FROM students 
                WHERE school_id = ? AND status = "active"';
        $params = [$this->schoolId];

        if ($this->classId > 0) {
            $sql .= ' AND class_id = ?';
            $params[] = $this->classId;
        }

        $students = Database::fetchAll($sql, $params);
        if (empty($students)) {
            return;
        }

        // Fetch category details
        $category = Database::fetch(
            'SELECT name FROM fee_categories WHERE id = ? AND school_id = ? LIMIT 1',
            [$this->feeCategoryId, $this->schoolId]
        );
        $categoryName = $category['name'] ?? 'Tuition Fee';

        $generatedCount = 0;

        foreach ($students as $student) {
            $studentId = (int) $student['id'];

            // Prevent duplicate invoice for the same month and fee category
            $existing = Database::fetch(
                'SELECT i.id FROM student_fee_invoices i
                 INNER JOIN student_fee_invoice_items it ON it.invoice_id = i.id
                 WHERE i.school_id = ? AND i.student_id = ? AND it.fee_category_id = ? AND i.month = ?
                 LIMIT 1',
                [$this->schoolId, $studentId, $this->feeCategoryId, $this->month]
            );

            if ($existing) {
                continue;
            }

            // Generate invoice number
            $invoiceNo = sprintf('INV-%d-%s-%04d', $this->schoolId, date('Ym'), rand(1000, 9999));

            Database::transaction(function () use ($studentId, $invoiceNo, $categoryName, &$generatedCount) {
                $invoiceId = Database::insert(
                    'INSERT INTO student_fee_invoices 
                    (school_id, academic_year_id, student_id, invoice_no, title, total_amount, paid_amount, due_date, status, month, created_by, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, 0.00, ?, "unpaid", ?, ?, NOW(), NOW())',
                    [
                        $this->schoolId,
                        $this->academicYearId,
                        $studentId,
                        $invoiceNo,
                        "{$categoryName} - {$this->month}",
                        $this->amount,
                        $this->dueDate,
                        $this->month,
                        $this->createdBy,
                    ]
                );

                // Insert fee line item
                Database::insert(
                    'INSERT INTO student_fee_invoice_items (invoice_id, fee_category_id, description, amount, created_at, updated_at)
                     VALUES (?, ?, ?, ?, NOW(), NOW())',
                    [$invoiceId, $this->feeCategoryId, $categoryName, $this->amount]
                );

                $generatedCount++;
            });
        }

        if (function_exists('auditLog')) {
            auditLog(
                'finance.mass_invoice_async',
                'student_fee_invoices',
                'finance',
                null,
                null,
                [
                    'school_id' => $this->schoolId,
                    'class_id' => $this->classId,
                    'generated' => $generatedCount,
                    'month' => $this->month,
                ]
            );
        }
    }
}
