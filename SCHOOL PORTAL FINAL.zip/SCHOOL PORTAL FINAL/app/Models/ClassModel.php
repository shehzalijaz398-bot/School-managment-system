<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class ClassModel extends Model
{
    protected string $table = 'classes';

    public function withSections(): array
    {
        $classes = $this->all('numeric_name ASC, name ASC');
        foreach ($classes as &$class) {
            $class['sections'] = Database::fetchAll(
                'SELECT s.*, 
                        e.first_name AS teacher_first, e.last_name AS teacher_last,
                        (SELECT COUNT(*) FROM students st WHERE st.section_id = s.id AND st.school_id = s.school_id AND st.status IN ("active", "enrolled")) AS student_count
                 FROM sections s
                 LEFT JOIN teachers t ON t.id = s.class_teacher_id
                 LEFT JOIN employees e ON e.id = t.employee_id
                 WHERE s.school_id = ? AND s.class_id = ? AND s.status = 1 
                 ORDER BY s.name',
                [$this->schoolId(), (int) $class['id']]
            );

            $stuRow = Database::fetch(
                'SELECT COUNT(*) as cnt FROM students WHERE class_id = ? AND school_id = ? AND status IN ("active", "enrolled")',
                [(int) $class['id'], $this->schoolId()]
            );
            $class['active_students'] = (int) ($stuRow['cnt'] ?? 0);
        }
        unset($class);
        return $classes;
    }

    public function listAll(): array
    {
        return $this->all('numeric_name ASC, name ASC');
    }
}
