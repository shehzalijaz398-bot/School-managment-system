<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class AuditLog extends Model
{
    protected string $table = 'audit_logs';

    public function recent(int $limit = 50, ?string $module = null): array
    {
        $sql = 'SELECT a.*, u.name AS user_name
                FROM audit_logs a
                LEFT JOIN users u ON u.id = a.user_id
                WHERE a.school_id = ?';
        $params = [$this->schoolId()];
        if ($module) {
            $sql .= ' AND a.module = ?';
            $params[] = $module;
        }
        $sql .= ' ORDER BY a.created_at DESC LIMIT ' . (int) $limit;
        return Database::fetchAll($sql, $params);
    }
}
