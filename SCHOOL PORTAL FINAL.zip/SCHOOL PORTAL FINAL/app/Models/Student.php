<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Student extends Model
{
    protected string $table = 'students';

    public function list(?string $search = null, ?string $status = null, ?int $classId = null): array
    {
        $sql = 'SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS academic_year
                FROM students s
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
                WHERE s.school_id = ?';
        $params = [$this->schoolId()];

        if ($search) {
            $sql .= ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ?)';
            $q = '%' . $search . '%';
            $params = array_merge($params, [$q, $q, $q, $q]);
        }
        if ($status) {
            $sql .= ' AND s.status = ?';
            $params[] = $status;
        }
        if ($classId) {
            $sql .= ' AND s.class_id = ?';
            $params[] = $classId;
        }
        $sql .= ' ORDER BY s.first_name, s.last_name';
        return Database::fetchAll($sql, $params);
    }

    public function findDetailed(int $id): ?array
    {
        return Database::fetch(
            'SELECT s.*, c.name AS class_name, sec.name AS section_name, ay.name AS academic_year
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             LEFT JOIN academic_years ay ON ay.id = s.academic_year_id
             WHERE s.id = ? AND s.school_id = ? LIMIT 1',
            [$id, $this->schoolId()]
        );
    }

    public function byClassSection(int $classId, int $sectionId = 0): array
    {
        if ($sectionId > 0) {
            return Database::fetchAll(
                'SELECT s.*, sec.name AS section_name 
                 FROM students s 
                 LEFT JOIN sections sec ON sec.id = s.section_id 
                 WHERE s.school_id = ? AND s.class_id = ? AND s.section_id = ? AND s.status = ? 
                 ORDER BY CAST(s.roll_no AS UNSIGNED) ASC, s.roll_no ASC, s.first_name ASC',
                [$this->schoolId(), $classId, $sectionId, 'active']
            );
        }
        return Database::fetchAll(
            'SELECT s.*, sec.name AS section_name 
             FROM students s 
             LEFT JOIN sections sec ON sec.id = s.section_id 
             WHERE s.school_id = ? AND s.class_id = ? AND s.status = ? 
             ORDER BY CAST(s.roll_no AS UNSIGNED) ASC, s.roll_no ASC, s.first_name ASC',
            [$this->schoolId(), $classId, 'active']
        );
    }

    public function forParent(int $parentId): array
    {
        return Database::fetchAll(
            'SELECT s.*, c.name AS class_name, sec.name AS section_name
             FROM students s
             INNER JOIN student_parents sp ON sp.student_id = s.id AND sp.school_id = s.school_id
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             WHERE s.school_id = ? AND sp.parent_id = ?
             ORDER BY s.first_name',
            [$this->schoolId(), $parentId]
        );
    }

    public function nextAdmissionNo(): string
    {
        $year = date('Y');
        $row = Database::fetch(
            "SELECT admission_no FROM students WHERE school_id = ? AND admission_no LIKE ? ORDER BY id DESC LIMIT 1",
            [$this->schoolId(), "ADM-{$year}-%"]
        );
        $seq = 1;
        if ($row && preg_match('/(\d+)$/', $row['admission_no'], $m)) {
            $seq = (int) $m[1] + 1;
        }
        return sprintf('ADM-%s-%04d', $year, $seq);
    }

    public function countByStatus(string $status = 'active'): int
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM students WHERE school_id = ? AND status = ?',
            [$this->schoolId(), $status]
        );
        return (int) ($row['c'] ?? 0);
    }
}
