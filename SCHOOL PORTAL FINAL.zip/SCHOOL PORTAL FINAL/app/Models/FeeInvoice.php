<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class FeeInvoice extends Model
{
    protected string $table = 'student_fee_invoices';

    /**
     * Retrieve invoice by ID with strict tenant boundary check.
     */
    public function findWithStudent(int $id): ?array
    {
        $sql = 'SELECT i.*, 
                       s.first_name, 
                       s.last_name, 
                       s.admission_no, 
                       s.email,
                       s.phone,
                       c.name AS class_name,
                       sec.name AS section_name
                FROM student_fee_invoices i
                INNER JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = i.school_id
                LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = i.school_id
                WHERE i.id = ? AND i.school_id = ?
                LIMIT 1';

        $result = Database::fetch($sql, [$id, $this->schoolId()]);
        return $result ?: null;
    }

    /**
     * Fetch line items belonging to an invoice under tenant isolation.
     *
     * @return array<int, array<string, mixed>>
     */
    public function items(int $invoiceId): array
    {
        return Database::fetchAll(
            'SELECT it.*, fc.name AS category_name
             FROM student_fee_invoice_items it
             LEFT JOIN fee_categories fc ON fc.id = it.fee_category_id AND fc.school_id = it.school_id
             WHERE it.invoice_id = ? AND it.school_id = ?
             ORDER BY it.id ASC',
            [$invoiceId, $this->schoolId()]
        );
    }

    /**
     * Fetch all payments recorded against an invoice under tenant isolation.
     *
     * @return array<int, array<string, mixed>>
     */
    public function payments(int $invoiceId): array
    {
        return Database::fetchAll(
            'SELECT p.*, u.name AS received_by_name
             FROM payments p
             LEFT JOIN users u ON u.id = p.received_by AND u.school_id = p.school_id
             WHERE p.invoice_id = ? AND p.school_id = ?
             ORDER BY p.payment_date DESC, p.id DESC',
            [$invoiceId, $this->schoolId()]
        );
    }

    /**
     * Check if invoice has any recorded payments.
     */
    public function hasPayments(int $invoiceId): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS cnt FROM payments WHERE invoice_id = ? AND school_id = ?',
            [$invoiceId, $this->schoolId()]
        );

        return ((int) ($row['cnt'] ?? 0)) > 0;
    }

    /**
     * Filtered search for invoices with tenant isolation and prepared statements.
     *
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    public function listFiltered(array $filters = []): array
    {
        $schoolId = $this->schoolId();
        $sql = 'SELECT i.*, 
                       s.first_name, 
                       s.last_name, 
                       s.admission_no, 
                       c.name AS class_name
                FROM student_fee_invoices i
                INNER JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = i.school_id
                WHERE i.school_id = ?';
        
        $params = [$schoolId];

        if (!empty($filters['status'])) {
            $sql .= ' AND i.status = ?';
            $params[] = (string) $filters['status'];
        }

        if (!empty($filters['student_id'])) {
            $sql .= ' AND i.student_id = ?';
            $params[] = (int) $filters['student_id'];
        }

        if (!empty($filters['class_id'])) {
            $sql .= ' AND s.class_id = ?';
            $params[] = (int) $filters['class_id'];
        }

        if (!empty($filters['search'])) {
            $sql .= ' AND (i.invoice_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ?)';
            $like = '%' . trim((string) $filters['search']) . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $sql .= " ORDER BY i.id DESC";

        if (!empty($filters['limit'])) {
            $limit = (int) $filters['limit'];
            $offset = (int) ($filters['offset'] ?? 0);
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }

        return Database::fetchAll($sql, $params);
    }

    /**
     * Get aggregate statistics for fee invoices.
     *
     * @return array{invoiced: float, collected: float, overdue: float, count_unpaid: int}
     */
    public function getSummaryMetrics(): array
    {
        $schoolId = $this->schoolId();

        $row = Database::fetch(
            'SELECT 
                COALESCE(SUM(total_amount), 0) AS total_invoiced,
                COALESCE(SUM(paid_amount), 0) AS total_collected,
                COALESCE(SUM(CASE WHEN status IN ("unpaid", "partial") AND due_date < CURDATE() THEN (total_amount - paid_amount) ELSE 0 END), 0) AS total_overdue,
                COUNT(CASE WHEN status IN ("unpaid", "partial") THEN 1 END) AS count_unpaid
             FROM student_fee_invoices
             WHERE school_id = ? AND status != "cancelled"',
            [$schoolId]
        );

        return [
            'invoiced' => (float) ($row['total_invoiced'] ?? 0),
            'collected' => (float) ($row['total_collected'] ?? 0),
            'overdue' => (float) ($row['total_overdue'] ?? 0),
            'count_unpaid' => (int) ($row['count_unpaid'] ?? 0),
        ];
    }

    /**
     * Fetch complete student financial ledger (invoices + payments).
     *
     * @return array<int, array<string, mixed>>
     */
    public function getStudentLedger(int $studentId): array
    {
        $schoolId = $this->schoolId();

        $sql = "SELECT 
                    'INVOICE' AS entry_type,
                    i.id AS reference_id,
                    i.invoice_no AS document_number,
                    i.invoice_date AS transaction_date,
                    i.title AS description,
                    i.total_amount AS debit,
                    0.00 AS credit,
                    i.status
                FROM student_fee_invoices i
                WHERE i.school_id = ? AND i.student_id = ? AND i.status != 'cancelled'
                
                UNION ALL
                
                SELECT 
                    'PAYMENT' AS entry_type,
                    p.id AS reference_id,
                    p.receipt_no AS document_number,
                    p.payment_date AS transaction_date,
                    CONCAT('Payment via ', UPPER(p.payment_method), COALESCE(CONCAT(' (Ref: ', p.reference_no, ')'), '')) AS description,
                    0.00 AS debit,
                    p.amount AS credit,
                    'paid' AS status
                FROM payments p
                WHERE p.school_id = ? AND p.student_id = ?
                
                ORDER BY transaction_date ASC, entry_type DESC";

        return Database::fetchAll($sql, [$schoolId, $studentId, $schoolId, $studentId]);
    }

    /**
     * Get list of defaulter students with outstanding balance.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getDefaulters(?int $classId = null, float $minDue = 0.0): array
    {
        $schoolId = $this->schoolId();
        $sql = 'SELECT s.id AS student_id,
                       s.admission_no,
                       s.first_name,
                       s.last_name,
                       s.phone,
                       c.name AS class_name,
                       sec.name AS section_name,
                       COUNT(i.id) AS overdue_invoices_count,
                       SUM(i.total_amount - i.paid_amount) AS total_due,
                       MIN(i.due_date) AS oldest_due_date
                FROM student_fee_invoices i
                INNER JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
                LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = i.school_id
                LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = i.school_id
                WHERE i.school_id = ? 
                  AND i.status IN ("unpaid", "partial") 
                  AND i.due_date < CURDATE()';

        $params = [$schoolId];

        if ($classId !== null && $classId > 0) {
            $sql .= ' AND s.class_id = ?';
            $params[] = $classId;
        }

        $sql .= ' GROUP BY s.id, s.admission_no, s.first_name, s.last_name, s.phone, c.name, sec.name';

        if ($minDue > 0) {
            $sql .= ' HAVING total_due >= ?';
            $params[] = $minDue;
        }

        $sql .= ' ORDER BY total_due DESC';

        return Database::fetchAll($sql, $params);
    }

    /**
     * Retrieve all fee invoices for a specific student under tenant isolation.
     *
     * @return array<int, array<string, mixed>>
     */
    public function forStudent(int $studentId): array
    {
        return Database::fetchAll(
            'SELECT i.*, 
                    s.first_name, 
                    s.last_name, 
                    s.admission_no, 
                    c.name AS class_name, 
                    sec.name AS section_name,
                    ay.name AS academic_year_name
             FROM student_fee_invoices i
             INNER JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
             LEFT JOIN classes c ON c.id = s.class_id AND c.school_id = i.school_id
             LEFT JOIN sections sec ON sec.id = s.section_id AND sec.school_id = i.school_id
             LEFT JOIN academic_years ay ON ay.id = i.academic_year_id AND ay.school_id = i.school_id
             WHERE i.student_id = ? AND i.school_id = ?
             ORDER BY i.due_date DESC, i.id DESC',
            [$studentId, $this->schoolId()]
        );
    }
}
