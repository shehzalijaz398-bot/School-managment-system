<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class LeaveRequest extends Model
{
    protected string $table = 'leave_requests';

    public function listAll(?string $status = null, ?int $employeeId = null): array
    {
        $sql = 'SELECT lr.*, 
                       CASE 
                           WHEN lr.applicant_type = "student" THEN CONCAT(s.first_name, " ", s.last_name)
                           ELSE CONCAT(e.first_name, " ", e.last_name)
                       END AS applicant_name,
                       CONCAT(e.first_name, " ", e.last_name) AS employee_name,
                       lt.name AS leave_type,
                       c.name AS class_name,
                       sec.name AS section_name,
                       u_rev.name AS reviewer_name
                FROM leave_requests lr
                LEFT JOIN employees e ON e.id = lr.employee_id
                LEFT JOIN students s ON s.id = lr.student_id
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                WHERE lr.school_id = ?';
        $params = [$this->schoolId()];

        if ($status) {
            $sql .= ' AND lr.status = ?';
            $params[] = $status;
        }
        if ($employeeId) {
            $sql .= ' AND lr.employee_id = ?';
            $params[] = $employeeId;
        }
        $sql .= ' ORDER BY lr.created_at DESC';
        return Database::fetchAll($sql, $params);
    }

    public function forStudent(int $studentId, ?string $status = null): array
    {
        $sql = 'SELECT lr.*, 
                       lt.name AS leave_type,
                       CONCAT(s.first_name, " ", s.last_name) AS student_name,
                       s.admission_no,
                       c.name AS class_name,
                       sec.name AS section_name,
                       u_rev.name AS reviewer_name,
                       u_app.email AS applied_by_email
                FROM leave_requests lr
                INNER JOIN students s ON s.id = lr.student_id
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                LEFT JOIN users u_app ON u_app.id = lr.applied_by
                WHERE lr.school_id = ? AND lr.student_id = ?';
        $params = [$this->schoolId(), $studentId];

        if ($status) {
            $sql .= ' AND lr.status = ?';
            $params[] = $status;
        }

        $sql .= ' ORDER BY lr.created_at DESC';
        return Database::fetchAll($sql, $params);
    }

    public function forEmployee(int $employeeId, ?string $status = null): array
    {
        $sql = 'SELECT lr.*, 
                       lt.name AS leave_type,
                       lt.is_paid,
                       CONCAT(e.first_name, " ", e.last_name) AS employee_name,
                       e.employee_code,
                       d.name AS department_name,
                       des.name AS designation_name,
                       u_rev.name AS reviewer_name
                FROM leave_requests lr
                INNER JOIN employees e ON e.id = lr.employee_id
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                WHERE lr.school_id = ? AND lr.employee_id = ?';
        $params = [$this->schoolId(), $employeeId];

        if ($status) {
            $sql .= ' AND lr.status = ?';
            $params[] = $status;
        }

        $sql .= ' ORDER BY lr.created_at DESC';
        return Database::fetchAll($sql, $params);
    }

    public function forTeacherReview(int $teacherId, array $filters = []): array
    {
        // Find classes and sections assigned to this teacher
        $assignments = Database::fetchAll(
            'SELECT DISTINCT class_id, section_id FROM teacher_assignments WHERE teacher_id = ? AND school_id = ? AND status = 1',
            [$teacherId, $this->schoolId()]
        );

        if (empty($assignments)) {
            // If teacher has no specific assignments, check if they are designated as a class teacher or return empty
            return [];
        }

        $conditions = [];
        $params = [$this->schoolId()];

        $assignClauses = [];
        foreach ($assignments as $a) {
            $assignClauses[] = '(s.class_id = ? AND s.section_id = ?)';
            $params[] = (int)$a['class_id'];
            $params[] = (int)$a['section_id'];
        }
        $conditions[] = '(' . implode(' OR ', $assignClauses) . ')';

        if (!empty($filters['status'])) {
            $conditions[] = 'lr.status = ?';
            $params[] = $filters['status'];
        }

        if (!empty($filters['class_id'])) {
            $conditions[] = 's.class_id = ?';
            $params[] = (int)$filters['class_id'];
        }

        if (!empty($filters['section_id'])) {
            $conditions[] = 's.section_id = ?';
            $params[] = (int)$filters['section_id'];
        }

        if (!empty($filters['q'])) {
            $q = '%' . trim($filters['q']) . '%';
            $conditions[] = '(s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ?)';
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $where = implode(' AND ', $conditions);

        $sql = "SELECT lr.*, 
                       lt.name AS leave_type,
                       CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                       s.admission_no,
                       s.roll_no,
                       s.profile_image,
                       c.name AS class_name,
                       sec.name AS section_name,
                       u_rev.name AS reviewer_name,
                       u_app.name AS applied_by_name
                FROM leave_requests lr
                INNER JOIN students s ON s.id = lr.student_id
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                LEFT JOIN users u_app ON u_app.id = lr.applied_by
                WHERE lr.school_id = ? AND lr.applicant_type = 'student' AND {$where}
                ORDER BY CASE WHEN lr.status = 'pending' THEN 0 ELSE 1 END, lr.created_at DESC";

        return Database::fetchAll($sql, $params);
    }

    public function listStudents(array $filters = []): array
    {
        $conditions = ['lr.school_id = ?', 'lr.applicant_type = "student"'];
        $params = [$this->schoolId()];

        if (!empty($filters['status'])) {
            $conditions[] = 'lr.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['class_id'])) {
            $conditions[] = 's.class_id = ?';
            $params[] = (int)$filters['class_id'];
        }
        if (!empty($filters['section_id'])) {
            $conditions[] = 's.section_id = ?';
            $params[] = (int)$filters['section_id'];
        }
        if (!empty($filters['q'])) {
            $q = '%' . trim($filters['q']) . '%';
            $conditions[] = '(s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.roll_no LIKE ?)';
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $where = implode(' AND ', $conditions);

        $sql = "SELECT lr.*, 
                       lt.name AS leave_type,
                       CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                       s.admission_no,
                       s.roll_no,
                       s.profile_image,
                       c.name AS class_name,
                       sec.name AS section_name,
                       u_rev.name AS reviewer_name,
                       u_app.name AS applied_by_name
                FROM leave_requests lr
                INNER JOIN students s ON s.id = lr.student_id
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                LEFT JOIN users u_app ON u_app.id = lr.applied_by
                WHERE {$where}
                ORDER BY CASE WHEN lr.status = 'pending' THEN 0 ELSE 1 END, lr.created_at DESC";

        return Database::fetchAll($sql, $params);
    }

    public function listStaff(array $filters = []): array
    {
        $conditions = ['lr.school_id = ?', 'lr.applicant_type = "staff"'];
        $params = [$this->schoolId()];

        if (!empty($filters['status'])) {
            $conditions[] = 'lr.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['department_id'])) {
            $conditions[] = 'e.department_id = ?';
            $params[] = (int)$filters['department_id'];
        }
        if (!empty($filters['q'])) {
            $q = '%' . trim($filters['q']) . '%';
            $conditions[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ? OR e.email LIKE ?)';
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $where = implode(' AND ', $conditions);

        $sql = "SELECT lr.*, 
                       lt.name AS leave_type,
                       lt.is_paid,
                       CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                       e.employee_code,
                       e.email AS employee_email,
                       e.profile_image,
                       d.name AS department_name,
                       des.name AS designation_name,
                       u_rev.name AS reviewer_name,
                       u_app.name AS applied_by_name
                FROM leave_requests lr
                INNER JOIN employees e ON e.id = lr.employee_id
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                LEFT JOIN users u_app ON u_app.id = lr.applied_by
                WHERE {$where}
                ORDER BY CASE WHEN lr.status = 'pending' THEN 0 ELSE 1 END, lr.created_at DESC";

        return Database::fetchAll($sql, $params);
    }

    public function findDetailed(int $id): ?array
    {
        $sql = 'SELECT lr.*, 
                       lt.name AS leave_type,
                       lt.is_paid,
                       CASE 
                           WHEN lr.applicant_type = "student" THEN CONCAT(s.first_name, " ", s.last_name)
                           ELSE CONCAT(e.first_name, " ", e.last_name)
                       END AS applicant_name,
                       s.admission_no,
                       s.roll_no,
                       c.name AS class_name,
                       sec.name AS section_name,
                       e.employee_code,
                       d.name AS department_name,
                       des.name AS designation_name,
                       u_rev.name AS reviewer_name,
                       u_app.name AS applied_by_name,
                       u_app.email AS applied_by_email
                FROM leave_requests lr
                LEFT JOIN students s ON s.id = lr.student_id
                LEFT JOIN classes c ON c.id = s.class_id
                LEFT JOIN sections sec ON sec.id = s.section_id
                LEFT JOIN employees e ON e.id = lr.employee_id
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                LEFT JOIN leave_types lt ON lt.id = lr.leave_type_id
                LEFT JOIN users u_rev ON u_rev.id = lr.reviewed_by
                LEFT JOIN users u_app ON u_app.id = lr.applied_by
                WHERE lr.id = ? AND lr.school_id = ? LIMIT 1';

        return Database::fetch($sql, [$id, $this->schoolId()]);
    }

    public function getStats(?int $teacherId = null): array
    {
        $schoolId = $this->schoolId();
        $today = date('Y-m-d');
        $startOfMonth = date('Y-m-01');

        if ($teacherId !== null) {
            // Teacher specific stats
            $assignments = Database::fetchAll(
                'SELECT DISTINCT class_id, section_id FROM teacher_assignments WHERE teacher_id = ? AND school_id = ? AND status = 1',
                [$teacherId, $schoolId]
            );

            if (empty($assignments)) {
                return [
                    'pending_total' => 0,
                    'approved_month' => 0,
                    'rejected_month' => 0,
                    'on_leave_today' => 0,
                ];
            }

            $clauses = [];
            $params = [$schoolId];
            foreach ($assignments as $a) {
                $clauses[] = '(s.class_id = ? AND s.section_id = ?)';
                $params[] = (int)$a['class_id'];
                $params[] = (int)$a['section_id'];
            }
            $scope = '(' . implode(' OR ', $clauses) . ')';

            $pending = Database::fetch(
                "SELECT COUNT(*) AS c FROM leave_requests lr INNER JOIN students s ON s.id = lr.student_id WHERE lr.school_id = ? AND lr.applicant_type = 'student' AND lr.status = 'pending' AND {$scope}",
                $params
            )['c'] ?? 0;

            $approved = Database::fetch(
                "SELECT COUNT(*) AS c FROM leave_requests lr INNER JOIN students s ON s.id = lr.student_id WHERE lr.school_id = ? AND lr.applicant_type = 'student' AND lr.status = 'approved' AND lr.created_at >= '{$startOfMonth}' AND {$scope}",
                $params
            )['c'] ?? 0;

            $rejected = Database::fetch(
                "SELECT COUNT(*) AS c FROM leave_requests lr INNER JOIN students s ON s.id = lr.student_id WHERE lr.school_id = ? AND lr.applicant_type = 'student' AND lr.status = 'rejected' AND lr.created_at >= '{$startOfMonth}' AND {$scope}",
                $params
            )['c'] ?? 0;

            $todayCount = Database::fetch(
                "SELECT COUNT(*) AS c FROM leave_requests lr INNER JOIN students s ON s.id = lr.student_id WHERE lr.school_id = ? AND lr.applicant_type = 'student' AND lr.status = 'approved' AND ? BETWEEN lr.start_date AND lr.end_date AND {$scope}",
                array_merge([$schoolId, $today], array_slice($params, 1))
            )['c'] ?? 0;

            return [
                'pending_total' => (int)$pending,
                'approved_month' => (int)$approved,
                'rejected_month' => (int)$rejected,
                'on_leave_today' => (int)$todayCount,
            ];
        }

        // Admin stats
        $pendingTotal = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND status = 'pending'",
            [$schoolId]
        )['c'] ?? 0;

        $pendingStudents = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND applicant_type = 'student' AND status = 'pending'",
            [$schoolId]
        )['c'] ?? 0;

        $pendingStaff = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND applicant_type = 'staff' AND status = 'pending'",
            [$schoolId]
        )['c'] ?? 0;

        $approvedMonth = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND status = 'approved' AND created_at >= ?",
            [$schoolId, $startOfMonth]
        )['c'] ?? 0;

        $rejectedMonth = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND status = 'rejected' AND created_at >= ?",
            [$schoolId, $startOfMonth]
        )['c'] ?? 0;

        $onLeaveToday = Database::fetch(
            "SELECT COUNT(*) AS c FROM leave_requests WHERE school_id = ? AND status = 'approved' AND ? BETWEEN start_date AND end_date",
            [$schoolId, $today]
        )['c'] ?? 0;

        return [
            'pending_total' => (int)$pendingTotal,
            'pending_students' => (int)$pendingStudents,
            'pending_staff' => (int)$pendingStaff,
            'approved_month' => (int)$approvedMonth,
            'rejected_month' => (int)$rejectedMonth,
            'on_leave_today' => (int)$onLeaveToday,
        ];
    }

    public function types(string $category = 'all'): array
    {
        $schoolId = $this->schoolId();
        if ($category === 'all') {
            return Database::fetchAll(
                'SELECT * FROM leave_types WHERE school_id = ? ORDER BY name ASC',
                [$schoolId]
            );
        }

        return Database::fetchAll(
            'SELECT * FROM leave_types WHERE school_id = ? AND (category = ? OR category = "all") ORDER BY name ASC',
            [$schoolId, $category]
        );
    }
}
