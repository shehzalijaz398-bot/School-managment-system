<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Announcement extends Model
{
    protected string $table = 'announcements';

    public function published(string $audience = 'all', int $limit = 20, bool $isManagement = false): array
    {
        $sql = 'SELECT a.*, 
                 CASE WHEN a.is_platform = 1 THEN pu.name ELSE u.name END AS author
             FROM announcements a
             LEFT JOIN users u ON u.id = a.created_by AND a.is_platform = 0
             LEFT JOIN platform_users pu ON pu.id = a.created_by AND a.is_platform = 1
             WHERE (a.school_id = ? OR a.school_id IS NULL) AND a.status = ? ';

        if (!$isManagement) {
            $sql .= ' AND a.is_platform = 0 ';
        }

        $sql .= ' AND (a.audience = ? OR a.audience = ?)
             ORDER BY a.published_at DESC LIMIT ' . (int) $limit;

        return Database::fetchAll($sql, [$this->schoolId(), 'published', $audience, 'all']);
    }
}
