<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Timetable extends Model
{
    protected string $table = 'timetables';

    public function forClass(int $classId, int $sectionId): array
    {
        return Database::fetchAll(
            'SELECT tt.*, s.name AS subject_name, CONCAT(e.first_name, " ", e.last_name) AS teacher_name, tp.start_time, tp.end_time, tp.period_number
             FROM timetables tt
             INNER JOIN timetable_periods tp ON tp.id = tt.period_id
             INNER JOIN subjects s ON s.id = tt.subject_id
             INNER JOIN teachers t ON t.id = tt.teacher_id
             INNER JOIN employees e ON e.id = t.employee_id
             WHERE tt.school_id = ? AND tt.class_id = ? AND tt.section_id = ? AND tt.academic_year_id = ?
             ORDER BY tt.day_of_week, tp.start_time',
            [$this->schoolId(), $classId, $sectionId, activeAcademicYearId()]
        );
    }

    public function forTeacher(int $teacherId): array
    {
        return Database::fetchAll(
            'SELECT tt.*, s.name AS subject_name, c.name AS class_name, sec.name AS section_name, tp.start_time, tp.end_time, tp.period_number
             FROM timetables tt
             INNER JOIN timetable_periods tp ON tp.id = tt.period_id
             INNER JOIN subjects s ON s.id = tt.subject_id
             INNER JOIN classes c ON c.id = tt.class_id
             INNER JOIN sections sec ON sec.id = tt.section_id
             WHERE tt.school_id = ? AND tt.teacher_id = ? AND tt.academic_year_id = ?
             ORDER BY tt.day_of_week, tp.start_time',
            [$this->schoolId(), $teacherId, activeAcademicYearId()]
        );
    }
}
