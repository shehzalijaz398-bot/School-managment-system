<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Admission extends Model
{
    protected string $table = 'admissions';

    public function listAll(?string $status = null): array
    {
        $sql = 'SELECT a.*, c.name AS class_name FROM admissions a
                LEFT JOIN classes c ON c.id = a.class_id
                WHERE a.school_id = ?';
        $params = [$this->schoolId()];
        if ($status) {
            $sql .= ' AND a.status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY a.created_at DESC';
        return Database::fetchAll($sql, $params);
    }

    public function nextApplicationNo(): string
    {
        $year = date('Y');
        $row = Database::fetch(
            'SELECT application_no FROM admissions WHERE school_id = ? AND application_no LIKE ? ORDER BY id DESC LIMIT 1',
            [$this->schoolId(), "APP-{$year}-%"]
        );
        $seq = 1;
        if ($row && preg_match('/(\d+)$/', $row['application_no'], $m)) {
            $seq = (int) $m[1] + 1;
        }
        return sprintf('APP-%s-%04d', $year, $seq);
    }
}
