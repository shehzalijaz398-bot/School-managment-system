<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Employee extends Model
{
    protected string $table = 'employees';

    public function listAll(?string $status = null): array
    {
        $sql = 'SELECT e.*, d.name AS department, des.name AS designation
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations des ON des.id = e.designation_id
                WHERE e.school_id = ?';
        $params = [$this->schoolId()];
        if ($status) {
            $sql .= ' AND e.status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY e.first_name';
        return Database::fetchAll($sql, $params);
    }

    public function findDetailed(int $id): ?array
    {
        return Database::fetch(
            'SELECT e.*, d.name AS department, des.name AS designation
             FROM employees e
             LEFT JOIN departments d ON d.id = e.department_id
             LEFT JOIN designations des ON des.id = e.designation_id
             WHERE e.id = ? AND e.school_id = ? LIMIT 1',
            [$id, $this->schoolId()]
        );
    }

    public function nextCode(): string
    {
        $row = Database::fetch(
            'SELECT employee_code FROM employees WHERE school_id = ? ORDER BY id DESC LIMIT 1',
            [$this->schoolId()]
        );
        
        // Ensure we don't return a duplicate if EMPXXX is already taken by some other ID
        $maxRow = Database::fetch(
            'SELECT MAX(CAST(SUBSTRING(employee_code, 4) AS UNSIGNED)) as max_seq FROM employees WHERE school_id = ? AND employee_code LIKE "EMP%"',
            [$this->schoolId()]
        );
        $seq = 1;
        if ($maxRow && $maxRow['max_seq']) {
            $seq = (int) $maxRow['max_seq'] + 1;
        }
        return sprintf('EMP%03d', $seq);
    }

    public function countActive(): int
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM employees WHERE school_id = ? AND status = ?',
            [$this->schoolId(), 'active']
        );
        return (int) ($row['c'] ?? 0);
    }
}
