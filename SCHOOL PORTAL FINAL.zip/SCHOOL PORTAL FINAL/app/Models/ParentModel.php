<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class ParentModel extends Model
{
    protected string $table = 'parents';

    public function children(int $parentId): array
    {
        return (new Student())->forParent($parentId);
    }

    public function ownsStudent(int $parentId, int $studentId): bool
    {
        $row = Database::fetch(
            'SELECT id FROM student_parents WHERE school_id = ? AND parent_id = ? AND student_id = ? LIMIT 1',
            [$this->schoolId(), $parentId, $studentId]
        );
        return $row !== null;
    }
}
