<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

final class Subject extends Model
{
    protected string $table = 'subjects';
}
