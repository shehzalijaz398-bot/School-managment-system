<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Notification extends Model
{
    protected string $table = 'notifications';

    public function forUser(int $userId, int $limit = 50): array
    {
        return Database::fetchAll(
            'SELECT * FROM notifications WHERE school_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ' . (int) $limit,
            [$this->schoolId(), $userId]
        );
    }

    public function unreadCount(int $userId): int
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM notifications WHERE school_id = ? AND user_id = ? AND is_read = 0',
            [$this->schoolId(), $userId]
        );
        return (int) ($row['c'] ?? 0);
    }

    public function markRead(int $id, int $userId): void
    {
        Database::execute(
            'UPDATE notifications SET is_read = 1 WHERE id = ? AND school_id = ? AND user_id = ?',
            [$id, $this->schoolId(), $userId]
        );
    }

    public function markAllRead(int $userId): void
    {
        Database::execute(
            'UPDATE notifications SET is_read = 1 WHERE school_id = ? AND user_id = ? AND is_read = 0',
            [$this->schoolId(), $userId]
        );
    }

    public function recentUnread(int $userId, int $limit = 5): array
    {
        return Database::fetchAll(
            'SELECT * FROM notifications WHERE school_id = ? AND user_id = ? ORDER BY is_read ASC, created_at DESC LIMIT ' . (int) $limit,
            [$this->schoolId(), $userId]
        );
    }

    public function ensurePreferencesTable(): void
    {
        Database::execute('CREATE TABLE IF NOT EXISTS notification_preferences (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            school_id BIGINT UNSIGNED NOT NULL,
            notify_attendance TINYINT(1) NOT NULL DEFAULT 1,
            notify_finance TINYINT(1) NOT NULL DEFAULT 1,
            notify_academics TINYINT(1) NOT NULL DEFAULT 1,
            notify_workflows TINYINT(1) NOT NULL DEFAULT 1,
            notify_announcements TINYINT(1) NOT NULL DEFAULT 1,
            channel_inapp TINYINT(1) NOT NULL DEFAULT 1,
            channel_email TINYINT(1) NOT NULL DEFAULT 1,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_user_school (user_id, school_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    public function getPreferences(int $userId, int $schoolId): array
    {
        $this->ensurePreferencesTable();
        $row = Database::fetch(
            'SELECT * FROM notification_preferences WHERE user_id = ? AND school_id = ?',
            [$userId, $schoolId]
        );

        if (!$row) {
            return [
                'notify_attendance' => 1,
                'notify_finance' => 1,
                'notify_academics' => 1,
                'notify_workflows' => 1,
                'notify_announcements' => 1,
                'channel_inapp' => 1,
                'channel_email' => 1,
            ];
        }

        return $row;
    }

    public function savePreferences(int $userId, int $schoolId, array $prefs): bool
    {
        $this->ensurePreferencesTable();
        return Database::execute(
            'INSERT INTO notification_preferences (user_id, school_id, notify_attendance, notify_finance, notify_academics, notify_workflows, notify_announcements, channel_inapp, channel_email, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
                notify_attendance = VALUES(notify_attendance),
                notify_finance = VALUES(notify_finance),
                notify_academics = VALUES(notify_academics),
                notify_workflows = VALUES(notify_workflows),
                notify_announcements = VALUES(notify_announcements),
                channel_inapp = VALUES(channel_inapp),
                channel_email = VALUES(channel_email),
                updated_at = NOW()',
            [
                $userId,
                $schoolId,
                !empty($prefs['notify_attendance']) ? 1 : 0,
                !empty($prefs['notify_finance']) ? 1 : 0,
                !empty($prefs['notify_academics']) ? 1 : 0,
                !empty($prefs['notify_workflows']) ? 1 : 0,
                !empty($prefs['notify_announcements']) ? 1 : 0,
                !empty($prefs['channel_inapp']) ? 1 : 0,
                !empty($prefs['channel_email']) ? 1 : 0,
            ]
        ) >= 0;
    }

    public static function createNotification(
        int $schoolId,
        int $userId,
        string $type,
        string $title,
        string $message,
        ?string $entityType = null,
        ?int $entityId = null,
        ?string $link = null
    ): int {
        // Honor user preferences if configured
        $instance = new self();
        $prefs = $instance->getPreferences($userId, $schoolId);
        
        // Check category suppression
        if (str_starts_with($type, 'attendance') && empty($prefs['notify_attendance'])) {
            return 0; // Muted by user preference
        }
        if (str_starts_with($type, 'finance') && empty($prefs['notify_finance'])) {
            return 0;
        }
        if ((str_starts_with($type, 'academic') || str_starts_with($type, 'exam')) && empty($prefs['notify_academics'])) {
            return 0;
        }
        if (str_starts_with($type, 'workflow') && empty($prefs['notify_workflows'])) {
            return 0;
        }

        return (int) Database::insert(
            'INSERT INTO notifications (school_id, user_id, type, title, message, entity_type, entity_id, link, is_read, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())',
            [$schoolId, $userId, $type, $title, $message, $entityType, $entityId, $link]
        );
    }
}
