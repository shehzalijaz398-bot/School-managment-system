<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Assignment extends Model
{
    protected string $table = 'assignments';

    public function listForSchool(?int $teacherId = null, array $filters = []): array
    {
        $schoolId = $this->schoolId();
        $conditions = ['a.school_id = ?'];
        $params = [$schoolId];

        if ($teacherId) {
            $conditions[] = 'a.teacher_id = ?';
            $params[] = $teacherId;
        }

        if (!empty($filters['class_id'])) {
            $conditions[] = 'a.class_id = ?';
            $params[] = (int) $filters['class_id'];
        }

        if (!empty($filters['section_id'])) {
            $conditions[] = 'a.section_id = ?';
            $params[] = (int) $filters['section_id'];
        }

        if (!empty($filters['subject_id'])) {
            $conditions[] = 'a.subject_id = ?';
            $params[] = (int) $filters['subject_id'];
        }

        if (!empty($filters['status'])) {
            $conditions[] = 'a.status = ?';
            $params[] = $filters['status'];
        }

        if (!empty($filters['date'])) {
            $conditions[] = 'a.assigned_date = ?';
            $params[] = $filters['date'];
        }

        if (!empty($filters['q'])) {
            $q = '%' . trim($filters['q']) . '%';
            $conditions[] = '(a.title LIKE ? OR a.description LIKE ? OR s.name LIKE ?)';
            $params[] = $q;
            $params[] = $q;
            $params[] = $q;
        }

        $where = implode(' AND ', $conditions);

        $sql = "SELECT a.*, 
                       c.name AS class_name, 
                       sec.name AS section_name, 
                       s.name AS subject_name,
                       CONCAT(e.first_name, ' ', e.last_name) AS teacher_name,
                       (SELECT COUNT(*) FROM students st WHERE st.class_id = a.class_id AND st.section_id = a.section_id AND st.status = 'active') AS total_students,
                       (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.status IN ('submitted', 'graded', 'late')) AS submitted_count,
                       (SELECT COUNT(*) FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.status = 'graded') AS graded_count
                FROM assignments a
                INNER JOIN classes c ON c.id = a.class_id
                INNER JOIN sections sec ON sec.id = a.section_id
                INNER JOIN subjects s ON s.id = a.subject_id
                LEFT JOIN teachers t ON t.id = a.teacher_id
                LEFT JOIN employees e ON e.id = t.employee_id
                WHERE {$where}
                ORDER BY a.assigned_date DESC, a.created_at DESC";

        return Database::fetchAll($sql, $params);
    }

    public function submissions(int $assignmentId): array
    {
        $schoolId = $this->schoolId();
        // Fetch assignment
        $assign = Database::fetch('SELECT class_id, section_id FROM assignments WHERE id = ? AND school_id = ? LIMIT 1', [$assignmentId, $schoolId]);
        if (!$assign) {
            return [];
        }

        // Return all students in class/section, with submission data if exists
        $sql = "SELECT st.id AS student_id, st.admission_no, st.roll_no, st.first_name, st.last_name, st.profile_image,
                       sub.id AS submission_id, sub.status AS submission_status, sub.submitted_at,
                       sub.attachment AS student_attachment, sub.content AS student_content,
                       sub.marks, sub.teacher_comment, sub.is_late
                FROM students st
                LEFT JOIN assignment_submissions sub ON sub.assignment_id = ? AND sub.student_id = st.id
                WHERE st.school_id = ? AND st.class_id = ? AND st.section_id = ? AND st.status = 'active'
                ORDER BY CAST(st.roll_no AS UNSIGNED) ASC, st.first_name ASC";

        return Database::fetchAll($sql, [$assignmentId, $schoolId, (int) $assign['class_id'], (int) $assign['section_id']]);
    }

    public function forStudent(int $studentId, ?string $filterStatus = null, ?string $date = null): array
    {
        $schoolId = $this->schoolId();

        $conditions = [
            'a.school_id = ?',
            'st.id = ?',
            'a.status = "published"'
        ];
        $params = [$schoolId, $studentId];

        if ($date) {
            $conditions[] = 'a.assigned_date = ?';
            $params[] = $date;
        }

        $where = implode(' AND ', $conditions);

        $sql = "SELECT a.*, 
                       s.name AS subject_name,
                       c.name AS class_name,
                       sec.name AS section_name,
                       CONCAT(e.first_name, ' ', e.last_name) AS teacher_name,
                       sub.id AS submission_id,
                       COALESCE(sub.status, 'pending') AS submission_status,
                       sub.submitted_at,
                       sub.attachment AS student_attachment,
                       sub.content AS student_content,
                       sub.marks,
                       sub.teacher_comment,
                       sub.is_late
                FROM assignments a
                INNER JOIN subjects s ON s.id = a.subject_id
                INNER JOIN classes c ON c.id = a.class_id
                INNER JOIN sections sec ON sec.id = a.section_id
                INNER JOIN students st ON st.class_id = a.class_id AND st.section_id = a.section_id
                LEFT JOIN teachers t ON t.id = a.teacher_id
                LEFT JOIN employees e ON e.id = t.employee_id
                LEFT JOIN assignment_submissions sub ON sub.assignment_id = a.id AND sub.student_id = st.id
                WHERE {$where}
                ORDER BY a.assigned_date DESC, a.due_date ASC";

        $rows = Database::fetchAll($sql, $params);

        if ($filterStatus) {
            $rows = array_filter($rows, function ($r) use ($filterStatus) {
                if ($filterStatus === 'pending') {
                    return in_array($r['submission_status'], ['pending', null], true);
                }
                if ($filterStatus === 'submitted') {
                    return in_array($r['submission_status'], ['submitted', 'late'], true);
                }
                if ($filterStatus === 'graded') {
                    return $r['submission_status'] === 'graded';
                }
                return true;
            });
        }

        return array_values($rows);
    }

    public function getStats(?int $teacherId = null): array
    {
        $schoolId = $this->schoolId();
        $today = date('Y-m-d');

        $tFilter = $teacherId ? " AND teacher_id = {$teacherId}" : "";

        $total = Database::fetch("SELECT COUNT(*) AS c FROM assignments WHERE school_id = ?{$tFilter}", [$schoolId])['c'] ?? 0;
        $active = Database::fetch("SELECT COUNT(*) AS c FROM assignments WHERE school_id = ? AND status = 'published'{$tFilter}", [$schoolId])['c'] ?? 0;
        $dueToday = Database::fetch("SELECT COUNT(*) AS c FROM assignments WHERE school_id = ? AND due_date = ? AND status = 'published'{$tFilter}", [$schoolId, $today])['c'] ?? 0;
        
        $submissionsCount = Database::fetch(
            "SELECT COUNT(*) AS c FROM assignment_submissions sub 
             INNER JOIN assignments a ON a.id = sub.assignment_id 
             WHERE a.school_id = ? AND sub.status IN ('submitted', 'graded', 'late'){$tFilter}",
            [$schoolId]
        )['c'] ?? 0;

        return [
            'total' => (int) $total,
            'active' => (int) $active,
            'due_today' => (int) $dueToday,
            'submissions' => (int) $submissionsCount,
        ];
    }
}
