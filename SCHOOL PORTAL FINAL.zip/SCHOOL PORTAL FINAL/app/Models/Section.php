<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Section extends Model
{
    protected string $table = 'sections';

    public function byClass(int $classId): array
    {
        return Database::fetchAll(
            'SELECT * FROM sections WHERE school_id = ? AND class_id = ? ORDER BY name',
            [$this->schoolId(), $classId]
        );
    }
}
