<?php
declare(strict_types=1);

namespace App\Models;

use Core\Model;
use Core\Database;

final class BookIssue extends Model
{
    protected string $table = 'book_issues';

    public function getWithDetails(string $status = null): array
    {
        $sql = "SELECT bi.*, b.title as book_title, b.isbn, 
                       CASE 
                           WHEN bi.member_type = 'student' THEN TRIM(CONCAT(COALESCE(s.first_name, ''), ' ', COALESCE(s.last_name, '')))
                           WHEN bi.member_type = 'employee' THEN TRIM(CONCAT(COALESCE(e.first_name, ''), ' ', COALESCE(e.last_name, '')))
                       END as member_name
                FROM book_issues bi
                JOIN books b ON bi.book_id = b.id
                LEFT JOIN students s ON bi.member_type = 'student' AND bi.member_id = s.id
                LEFT JOIN employees e ON bi.member_type = 'employee' AND bi.member_id = e.id
                WHERE bi.school_id = ?";
        
        $params = [$this->schoolId()];
        
        if ($status) {
            $sql .= " AND bi.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY bi.issue_date DESC";
        
        return Database::fetchAll($sql, $params);
    }
}
