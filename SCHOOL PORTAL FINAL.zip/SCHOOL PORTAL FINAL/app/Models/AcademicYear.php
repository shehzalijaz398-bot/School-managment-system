<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class AcademicYear extends Model
{
    protected string $table = 'academic_years';

    public function active(): ?array
    {
        return Database::fetch(
            'SELECT * FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1',
            [$this->schoolId()]
        );
    }
}
