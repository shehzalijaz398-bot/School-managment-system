<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class User extends Model
{
    protected string $table = 'users';

    public function listWithRoles(): array
    {
        return Database::fetchAll(
            'SELECT u.id, u.name, u.email, u.phone, u.status, u.last_login_at, 
                    r.name AS role_name, r.slug AS role_slug,
                    e.first_name AS emp_first_name, e.last_name AS emp_last_name, e.employee_code AS emp_code
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             LEFT JOIN employees e ON e.id = u.employee_id
             WHERE u.school_id = ?
             ORDER BY u.name',
            [$this->schoolId()]
        );
    }

    public function byRoleSlug(string $slug): array
    {
        return Database::fetchAll(
            'SELECT u.* FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.school_id = ? AND r.slug = ? AND u.status = 1',
            [$this->schoolId(), $slug]
        );
    }
}
