<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class PayrollModel extends Model
{
    protected string $table = 'payroll';

    /**
     * Retrieve a payroll record with employee details and tenant boundary enforcement.
     *
     * @param int $id
     * @return array<string, mixed>|null
     */
    public function findByIdWithDetails(int $id): ?array
    {
        $sql = 'SELECT p.*, 
                       e.first_name, 
                       e.last_name, 
                       e.employee_code, 
                       e.email,
                       e.phone,
                       e.joining_date,
                       d.name AS department_name, 
                       ds.name AS designation_name,
                       u.name AS approved_by_name
                FROM payroll p
                INNER JOIN employees e ON e.id = p.employee_id AND e.school_id = p.school_id
                LEFT JOIN departments d ON d.id = e.department_id AND d.school_id = p.school_id
                LEFT JOIN designations ds ON ds.id = e.designation_id AND ds.school_id = p.school_id
                LEFT JOIN users u ON u.id = p.approved_by AND u.school_id = p.school_id
                WHERE p.id = ? AND p.school_id = ?
                LIMIT 1';

        $row = Database::fetch($sql, [$id, $this->schoolId()]);
        return $row ?: null;
    }

    /**
     * Retrieve breakdown line items for a payroll slip under tenant isolation.
     *
     * @param int $payrollId
     * @return array<int, array<string, mixed>>
     */
    public function items(int $payrollId): array
    {
        return Database::fetchAll(
            'SELECT * FROM payroll_items 
             WHERE payroll_id = ? AND school_id = ? 
             ORDER BY type ASC, id ASC',
            [$payrollId, $this->schoolId()]
        );
    }

    /**
     * List all payroll records filtered by month and/or status under tenant isolation.
     *
     * @param string|null $month
     * @param string|null $status
     * @return array<int, array<string, mixed>>
     */
    public function listAll(?string $month = null, ?string $status = null): array
    {
        $sql = 'SELECT p.*, 
                       CONCAT(e.first_name, " ", e.last_name) AS employee_name, 
                       e.employee_code,
                       des.name AS designation_name
                FROM payroll p
                INNER JOIN employees e ON e.id = p.employee_id AND e.school_id = p.school_id
                LEFT JOIN designations des ON des.id = e.designation_id AND des.school_id = p.school_id
                WHERE p.school_id = ?';

        $params = [$this->schoolId()];

        if ($month !== null && $month !== '') {
            $sql .= ' AND p.payroll_month = ?';
            $params[] = $month;
        }

        if ($status !== null && $status !== '') {
            $sql .= ' AND p.status = ?';
            $params[] = $status;
        }

        $sql .= ' ORDER BY p.payroll_month DESC, e.first_name ASC';
        return Database::fetchAll($sql, $params);
    }

    /**
     * List payroll records for a single employee under tenant isolation.
     *
     * @param int $employeeId
     * @return array<int, array<string, mixed>>
     */
    public function forEmployee(int $employeeId): array
    {
        return Database::fetchAll(
            'SELECT * FROM payroll 
             WHERE employee_id = ? AND school_id = ? 
             ORDER BY payroll_month DESC',
            [$employeeId, $this->schoolId()]
        );
    }

    /**
     * Aggregate statistics for a specific payroll month.
     *
     * @param string $month
     * @return array{total_net: float, paid_net: float, pending_count: int, paid_count: int}
     */
    public function summaryForMonth(string $month): array
    {
        $schoolId = $this->schoolId();
        $row = Database::fetch(
            'SELECT 
                COALESCE(SUM(net_salary), 0) AS total_net,
                COALESCE(SUM(CASE WHEN status = "paid" THEN net_salary ELSE 0 END), 0) AS paid_net,
                COUNT(CASE WHEN status IN ("draft", "pending") THEN 1 END) AS pending_count,
                COUNT(CASE WHEN status = "paid" THEN 1 END) AS paid_count
             FROM payroll 
             WHERE school_id = ? AND payroll_month = ? AND status != "cancelled"',
            [$schoolId, $month]
        );

        return [
            'total_net' => (float) ($row['total_net'] ?? 0),
            'paid_net' => (float) ($row['paid_net'] ?? 0),
            'pending_count' => (int) ($row['pending_count'] ?? 0),
            'paid_count' => (int) ($row['paid_count'] ?? 0),
        ];
    }
}
