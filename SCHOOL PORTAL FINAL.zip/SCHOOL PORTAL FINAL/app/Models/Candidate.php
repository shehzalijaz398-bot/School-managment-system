<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Candidate extends Model
{
    protected string $table = 'candidates';

    public function listAll(?string $status = null): array
    {
        $sql = 'SELECT c.*, d.name AS department FROM candidates c
                LEFT JOIN departments d ON d.id = c.department_id
                WHERE c.school_id = ?';
        $params = [$this->schoolId()];
        if ($status) {
            $sql .= ' AND c.status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY c.created_at DESC';
        return Database::fetchAll($sql, $params);
    }
}
