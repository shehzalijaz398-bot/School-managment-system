<?php
declare(strict_types=1);

namespace App\Models;

use Core\Model;
use Core\Database;

final class Book extends Model
{
    protected string $table = 'books';

    public function getWithCategory(): array
    {
        return Database::fetchAll(
            'SELECT b.*, c.name as category_name 
             FROM books b
             LEFT JOIN book_categories c ON b.category_id = c.id
             WHERE b.school_id = ?
             ORDER BY b.id DESC',
            [$this->schoolId()]
        );
    }

    public function search(string $query): array
    {
        return Database::fetchAll(
            'SELECT b.*, c.name as category_name 
             FROM books b
             LEFT JOIN book_categories c ON b.category_id = c.id
             WHERE b.school_id = ? 
             AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)
             ORDER BY b.title ASC',
            [$this->schoolId(), "%$query%", "%$query%", "%$query%"]
        );
    }

    public function adjustAvailableQuantity(int $bookId, int $amount): bool
    {
        $sql = "UPDATE books 
                SET available_quantity = available_quantity + ? 
                WHERE id = ? AND school_id = ? AND (available_quantity + ?) >= 0 AND (available_quantity + ?) <= quantity";
        
        $stmt = Database::execute($sql, [$amount, $bookId, $this->schoolId(), $amount, $amount]);
        return $stmt > 0;
    }
}
