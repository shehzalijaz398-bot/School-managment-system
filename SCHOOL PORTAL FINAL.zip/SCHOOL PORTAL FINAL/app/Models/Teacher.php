<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Teacher extends Model
{
    protected string $table = 'teachers';

    public function listAll(): array
    {
        return Database::fetchAll(
            'SELECT t.*, e.employee_code, e.first_name, e.last_name, e.email, e.phone, e.status AS emp_status,
                    d.name AS department, des.name AS designation
             FROM teachers t
             INNER JOIN employees e ON e.id = t.employee_id
             LEFT JOIN departments d ON d.id = e.department_id
             LEFT JOIN designations des ON des.id = e.designation_id
             WHERE t.school_id = ?
             ORDER BY e.first_name',
            [$this->schoolId()]
        );
    }

    public function countAll(): int
    {
        return (int) (Database::fetch(
            'SELECT COUNT(*) AS c FROM teachers WHERE school_id = ?',
            [$this->schoolId()]
        )['c'] ?? 0);
    }

    public function countActive(): int
    {
        return (int) (Database::fetch(
            'SELECT COUNT(*) AS c 
             FROM teachers t 
             INNER JOIN employees e ON e.id = t.employee_id 
             WHERE t.school_id = ? AND e.status = "active"',
            [$this->schoolId()]
        )['c'] ?? 0);
    }

    public function findDetailed(int $id): ?array
    {
        return Database::fetch(
            'SELECT t.*, e.employee_code, e.first_name, e.last_name, e.email, e.phone, e.gender,
                    e.joining_date, e.status AS emp_status, e.address, e.profile_image,
                    u.email AS login_email, u.status AS login_status
             FROM teachers t
             INNER JOIN employees e ON e.id = t.employee_id
             LEFT JOIN users u ON u.employee_id = t.employee_id AND u.school_id = t.school_id
             WHERE t.id = ? AND t.school_id = ? LIMIT 1',
            [$id, $this->schoolId()]
        );
    }

    public function findByEmployeeId(int $employeeId): ?array
    {
        return Database::fetch(
            'SELECT * FROM teachers WHERE school_id = ? AND employee_id = ? LIMIT 1',
            [$this->schoolId(), $employeeId]
        );
    }

    public function findByUserId(int $userId): ?array
    {
        return Database::fetch(
            'SELECT t.*, e.first_name, e.last_name, e.employee_code, e.email, e.phone, e.profile_image
             FROM teachers t
             INNER JOIN users u ON u.employee_id = t.employee_id AND u.school_id = t.school_id
             INNER JOIN employees e ON e.id = t.employee_id
             WHERE t.school_id = ? AND u.id = ? LIMIT 1',
            [$this->schoolId(), $userId]
        );
    }


    public function assignments(int $teacherId, ?int $yearId = null): array
    {
        $yearId = $yearId ?? activeAcademicYearId();
        return Database::fetchAll(
            'SELECT ta.*, c.name AS class_name, sec.name AS section_name, s.name AS subject_name
             FROM teacher_assignments ta
             INNER JOIN classes c ON c.id = ta.class_id
             INNER JOIN sections sec ON sec.id = ta.section_id
             INNER JOIN subjects s ON s.id = ta.subject_id
             WHERE ta.school_id = ? AND ta.teacher_id = ? AND ta.academic_year_id = ? AND ta.status = 1
             ORDER BY c.numeric_name, sec.name, s.name',
            [$this->schoolId(), $teacherId, $yearId]
        );
    }

    public function hasAssignment(int $teacherId, int $classId, int $sectionId, int $subjectId): bool
    {
        $row = Database::fetch(
            'SELECT id FROM teacher_assignments
             WHERE school_id = ? AND teacher_id = ? AND class_id = ? AND section_id = ? AND subject_id = ?
               AND academic_year_id = ? AND status = 1 LIMIT 1',
            [$this->schoolId(), $teacherId, $classId, $sectionId, $subjectId, activeAcademicYearId()]
        );
        return $row !== null;
    }
}
