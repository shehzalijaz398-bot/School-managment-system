<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

final class Exam extends Model
{
    protected string $table = 'exams';

    /**
     * Retrieve exam by ID with associated exam type, class, and academic year under tenant isolation.
     *
     * @param int $id
     * @return array<string, mixed>|null
     */
    public function findByIdWithDetails(int $id): ?array
    {
        $sql = 'SELECT e.*, 
                       et.name AS exam_type_name, 
                       c.name AS class_name, 
                       ay.name AS academic_year_name
                FROM exams e
                LEFT JOIN exam_types et ON et.id = e.exam_type_id AND et.school_id = e.school_id
                LEFT JOIN classes c ON c.id = e.class_id AND c.school_id = e.school_id
                LEFT JOIN academic_years ay ON ay.id = e.academic_year_id AND ay.school_id = e.school_id
                WHERE e.id = ? AND e.school_id = ?
                LIMIT 1';

        $row = Database::fetch($sql, [$id, $this->schoolId()]);
        return $row ?: null;
    }

    /**
     * List all exams in the tenant's current school.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listAll(): array
    {
        return Database::fetchAll(
            'SELECT e.*, 
                    COALESCE(et.name, "General") AS exam_type, 
                    c.name AS class_name, 
                    COALESCE(ay.name, "Current Session") AS academic_year
             FROM exams e
             LEFT JOIN exam_types et ON et.id = e.exam_type_id AND et.school_id = e.school_id
             LEFT JOIN classes c ON c.id = e.class_id AND c.school_id = e.school_id
             LEFT JOIN academic_years ay ON ay.id = e.academic_year_id AND ay.school_id = e.school_id
             WHERE e.school_id = ?
             ORDER BY e.start_date DESC, e.id DESC',
            [$this->schoolId()]
        );
    }

    /**
     * List timetable/subjects for an exam under tenant isolation.
     *
     * @param int $examId
     * @return array<int, array<string, mixed>>
     */
    public function subjects(int $examId): array
    {
        return Database::fetchAll(
            'SELECT es.*, s.name AS subject_name, s.code AS subject_code
             FROM exam_subjects es
             INNER JOIN subjects s ON s.id = es.subject_id AND s.school_id = es.school_id
             WHERE es.school_id = ? AND es.exam_id = ?
             ORDER BY es.exam_date ASC, s.name ASC',
            [$this->schoolId(), $examId]
        );
    }

    /**
     * Retrieve upcoming scheduled/ongoing exams.
     *
     * @param int $limit
     * @return array<int, array<string, mixed>>
     */
    public function upcoming(int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT e.*, c.name AS class_name 
             FROM exams e
             INNER JOIN classes c ON c.id = e.class_id AND c.school_id = e.school_id
             WHERE e.school_id = ? AND e.start_date >= CURDATE() AND e.status IN ("scheduled", "ongoing")
             ORDER BY e.start_date ASC 
             LIMIT ' . max(1, (int) $limit),
            [$this->schoolId()]
        );
    }

    /**
     * Check if exam has recorded student marks.
     */
    public function hasRecordedMarks(int $examId): bool
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS cnt FROM exam_marks WHERE exam_id = ? AND school_id = ?',
            [$examId, $this->schoolId()]
        );

        return ((int) ($row['cnt'] ?? 0)) > 0;
    }

    /**
     * Get published snapshot ranks for an exam and class.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getClassSnapshotResults(int $examId, int $classId): array
    {
        return Database::fetchAll(
            'SELECT snap.*, 
                    s.admission_no, 
                    s.first_name, 
                    s.last_name, 
                    sec.name AS section_name
             FROM exam_results_snapshot snap
             INNER JOIN students s ON s.id = snap.student_id AND s.school_id = snap.school_id
             LEFT JOIN sections sec ON sec.id = snap.section_id AND sec.school_id = snap.school_id
             WHERE snap.school_id = ? AND snap.exam_id = ? AND snap.class_id = ?
             ORDER BY snap.class_position ASC, snap.final_percentage DESC',
            [$this->schoolId(), $examId, $classId]
        );
    }

    /**
     * Get published snapshot rank for a specific student.
     *
     * @return array<string, mixed>|null
     */
    public function getStudentSnapshot(int $examId, int $studentId): ?array
    {
        $row = Database::fetch(
            'SELECT snap.*, c.name AS class_name, sec.name AS section_name
             FROM exam_results_snapshot snap
             LEFT JOIN classes c ON c.id = snap.class_id AND c.school_id = snap.school_id
             LEFT JOIN sections sec ON sec.id = snap.section_id AND sec.school_id = snap.school_id
             WHERE snap.school_id = ? AND snap.exam_id = ? AND snap.student_id = ?
             LIMIT 1',
            [$this->schoolId(), $examId, $studentId]
        );

        return $row ?: null;
    }
}
