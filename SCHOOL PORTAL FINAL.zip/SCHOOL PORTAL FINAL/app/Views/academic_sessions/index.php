<!-- Academics Breadcrumb & Title Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Academics</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Academic Years</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Academic Years</h1>
      <p class="text-muted small mb-0">Manage academic years and their terms. Each academic year scopes classes, attendance, and finance records.</p>
    </div>
    <?php if (hasPermission('academic_sessions.manage')): ?>
      <div>
        <button type="button" class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#newAcademicYearModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
          <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
          <span>New Academic Year</span>
        </button>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Academics Subnav Pill Switcher -->
<div class="mb-4">
  <div class="d-inline-flex align-items-center bg-white border rounded-pill p-1 shadow-xs" style="border-color: #e2e8f0 !important;">
    <a href="<?= e(url('academic-sessions')) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2" style="background-color: #ede9fe; color: #4f46e5; border: 1px solid #c7d2fe;">
      <i data-lucide="calendar" style="width: 14px; height: 14px;"></i>
      <span>Academic Years</span>
    </a>
    <a href="<?= e(url('classes')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="graduation-cap" style="width: 14px; height: 14px;"></i>
      <span>Classes</span>
    </a>
    <a href="<?= e(url('sections')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="layout-grid" style="width: 14px; height: 14px;"></i>
      <span>Sections</span>
    </a>
    <a href="<?= e(url('subjects')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="book-open" style="width: 14px; height: 14px;"></i>
      <span>Subjects</span>
    </a>
  </div>
</div>

<!-- Search & Status Filter Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <div class="row g-3 align-items-end">
      <div class="col-md-8 col-lg-9">
        <label for="academicYearSearch" class="form-label small fw-semibold text-secondary mb-1">Search Academic Years</label>
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 14px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; pointer-events: none;"></i>
          <input type="text" id="academicYearSearch" class="form-control" placeholder="Search by name, code..." style="padding-left: 40px; height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
        </div>
      </div>
      <div class="col-md-4 col-lg-3">
        <label for="statusFilter" class="form-label small fw-semibold text-secondary mb-1">Status</label>
        <select id="statusFilter" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="draft">Draft</option>
          <option value="archived">Archived</option>
        </select>
      </div>
    </div>
  </div>
</div>

<!-- Academic Years Table Card -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; overflow: hidden; background: #ffffff;">
  <div class="table-responsive">
    <table class="table align-middle mb-0" id="academicYearsTable">
      <thead style="background-color: #ffffff; border-bottom: 1px solid #e2e8f0;">
        <tr>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em;">NAME</th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase text-center" style="font-size: 11px; letter-spacing: 0.05em;">TERMS</th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em;">STATUS</th>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase text-end" style="font-size: 11px; letter-spacing: 0.05em;">ACTIONS</th>
        </tr>
      </thead>
      <tbody id="sessionTableBody">
        <?php if (empty($sessions)): ?>
          <tr id="emptyRow">
            <td colspan="4" class="text-center py-5 text-muted">
              <i data-lucide="calendar-x" class="d-block mx-auto mb-2 opacity-50" style="width: 36px; height: 36px;"></i>
              No academic years found.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($sessions as $session): ?>
            <tr class="session-row" 
                data-name="<?= e(strtolower($session['name'])) ?>" 
                data-status="<?= e($session['status']) ?>"
                style="border-bottom: 1px solid #f8fafc; transition: background-color 0.15s ease;">
              <!-- Name -->
              <td class="py-3 px-4">
                <span class="fw-semibold text-dark session-name-text" style="font-size: 13.5px;"><?= e($session['name']) ?></span>
              </td>

              <!-- Terms Count -->
              <td class="py-3 px-3 text-center text-dark fw-semibold" style="font-size: 13px;">
                <?= (int)($session['term_count'] ?? 0) ?>
              </td>

              <!-- Status Badge -->
              <td class="py-3 px-3">
                <?php if ($session['status'] === 'active'): ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px;">●</span> Active
                  </span>
                <?php elseif ($session['status'] === 'draft'): ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f8fafc; color: #64748b; border: 1px solid #e2e8f0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px; color: #94a3b8;">●</span> Draft
                  </span>
                <?php else: ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px; color: #64748b;">●</span> Archived
                  </span>
                <?php endif; ?>
              </td>

              <!-- Actions (Calendar, Edit, Trash) -->
              <td class="py-3 px-4 text-end">
                <div class="d-inline-flex align-items-center gap-2">
                  <!-- Terms Management Modal Trigger -->
                  <button type="button" class="btn btn-sm btn-icon-action" title="Manage Terms" data-bs-toggle="modal" data-bs-target="#termsModal-<?= $session['id'] ?>">
                    <i data-lucide="calendar" style="width: 16px; height: 16px;"></i>
                  </button>

                  <?php if (hasPermission('academic_sessions.manage')): ?>
                    <!-- Edit Academic Year Modal Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action" title="Edit Academic Year" data-bs-toggle="modal" data-bs-target="#editModal-<?= $session['id'] ?>">
                      <i data-lucide="edit-3" style="width: 16px; height: 16px;"></i>
                    </button>

                    <!-- Delete Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action text-danger" title="Delete Academic Year" onclick="confirmDeleteSession(<?= $session['id'] ?>, '<?= e(addslashes($session['name'])) ?>', <?= (int)$session['is_active'] ?>, <?= (int)($session['linked_count'] ?? 0) ?>)">
                      <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                    </button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        <tr id="noResultsRow" style="display: none;">
          <td colspan="6" class="text-center py-5 text-muted">
            <i data-lucide="search-x" class="d-block mx-auto mb-2 opacity-50" style="width: 32px; height: 32px;"></i>
            No academic years matching your search filters.
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Table Pagination / Footer -->
  <div class="card-footer bg-white py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2" style="border-top: 1px solid #f1f5f9;">
    <span class="text-muted small" id="recordCounter">Showing 1 to <?= count($sessions) ?> of <?= count($sessions) ?> records</span>
    <div class="d-flex align-items-center gap-2">
      <span class="text-muted small">Rows:</span>
      <select class="form-select form-select-sm" id="rowsPerPageSelect" style="width: 70px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 13px;">
        <option value="10" selected>10</option>
        <option value="25">25</option>
        <option value="50">50</option>
      </select>
    </div>
  </div>
</div>

<!-- ========================================== -->
<!-- MODALS -->
<!-- ========================================== -->

<!-- 1. Modal: + New Academic Year -->
<?php if (hasPermission('academic_sessions.manage')): ?>
<div class="modal fade" id="newAcademicYearModal" tabindex="-1" aria-labelledby="newAcademicYearModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 540px;">
    <div class="modal-content border-0 shadow" style="border-radius: 16px; overflow: hidden; background: #ffffff;">
      <div class="modal-header border-0 pb-0 px-4 pt-4 d-flex justify-content-between align-items-start">
        <div>
          <h5 class="modal-title fw-bold text-dark mb-1" id="newAcademicYearModalLabel" style="font-size: 1.15rem; letter-spacing: -0.01em;">New Academic Year</h5>
          <p class="text-muted small mb-0" style="font-size: 13px;">Create a new academic year. You can add terms after creation.</p>
        </div>
        <button type="button" class="btn btn-sm btn-outline-light text-muted border d-flex align-items-center justify-content-center p-0" data-bs-dismiss="modal" aria-label="Close" style="width: 32px; height: 32px; border-radius: 8px; border-color: #e2e8f0 !important;">
          <i data-lucide="x" style="width: 16px; height: 16px;"></i>
        </button>
      </div>
      <form method="post" action="<?= e(url('academic-sessions')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body px-4 py-3">
          <!-- Banner Card -->
          <div class="d-flex align-items-center gap-3 p-3 mb-4 rounded-3 border" style="border-color: #f1f5f9 !important; background-color: #ffffff;">
            <div class="d-flex align-items-center justify-content-center flex-shrink-0" style="width: 40px; height: 40px; border-radius: 10px; background-color: #f5f3ff; color: #6366f1;">
              <i data-lucide="calendar" style="width: 20px; height: 20px;"></i>
            </div>
            <div>
              <h6 class="fw-bold mb-0 text-dark" style="font-size: 14.5px;">Academic Year Details</h6>
              <p class="text-muted mb-0" style="font-size: 12.5px;">Define the name, date range, and status for this academic year.</p>
            </div>
          </div>

          <!-- Academic Year Name -->
          <div class="mb-3">
            <label class="form-label small fw-semibold text-secondary mb-1">Academic Year Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="e.g. 2026–2027" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
          </div>

          <!-- Dates Row -->
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary mb-1">Start Date <span class="text-danger">*</span></label>
              <div class="position-relative">
                <input type="text" name="start_date" class="form-control" placeholder="DD/MM/YYYY" onfocus="(this.type='date')" onblur="if(!this.value)this.type='text'" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px; padding-right: 36px;">
                <i data-lucide="calendar" class="position-absolute text-muted" style="right: 12px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; pointer-events: none;"></i>
              </div>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary mb-1">End Date <span class="text-danger">*</span></label>
              <div class="position-relative">
                <input type="text" name="end_date" class="form-control" placeholder="DD/MM/YYYY" onfocus="(this.type='date')" onblur="if(!this.value)this.type='text'" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px; padding-right: 36px;">
                <i data-lucide="calendar" class="position-absolute text-muted" style="right: 12px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; pointer-events: none;"></i>
              </div>
            </div>
          </div>

          <!-- Status Dropdown -->
          <div class="mb-2">
            <label class="form-label small fw-semibold text-secondary mb-1">Status <span class="text-danger">*</span></label>
            <select name="status" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
              <option value="draft" selected>Draft</option>
              <option value="active">Active</option>
              <option value="archived">Archived</option>
            </select>
          </div>
        </div>
        <div class="modal-footer border-0 px-4 pb-4 pt-2 d-flex justify-content-end align-items-center gap-2">
          <button type="button" class="btn btn-link text-secondary text-decoration-none fw-medium px-3 py-2" data-bs-dismiss="modal" style="font-size: 14px;">Cancel</button>
          <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; font-size: 14px;">Create Academic Year</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 2. Modals: Edit Academic Year & Terms Management for each Session -->
<?php foreach ($sessions as $session): ?>
  <!-- Edit Academic Year Modal -->
  <?php if (hasPermission('academic_sessions.manage')): ?>
  <div class="modal fade" id="editModal-<?= $session['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 540px;">
      <div class="modal-content border-0 shadow" style="border-radius: 16px; overflow: hidden; background: #ffffff;">
        <div class="modal-header border-0 pb-0 px-4 pt-4 d-flex justify-content-between align-items-start">
          <div>
            <h5 class="modal-title fw-bold text-dark mb-1" style="font-size: 1.15rem; letter-spacing: -0.01em;">Edit Academic Year</h5>
            <p class="text-muted small mb-0" style="font-size: 13px;">Update academic year details and dates.</p>
          </div>
          <button type="button" class="btn btn-sm btn-outline-light text-muted border d-flex align-items-center justify-content-center p-0" data-bs-dismiss="modal" aria-label="Close" style="width: 32px; height: 32px; border-radius: 8px; border-color: #e2e8f0 !important;">
            <i data-lucide="x" style="width: 16px; height: 16px;"></i>
          </button>
        </div>
        <form method="post" action="<?= e(url("academic-sessions/{$session['id']}/update")) ?>">
          <?= csrf_field() ?>
          <div class="modal-body px-4 py-3">
            <!-- Banner Card -->
            <div class="d-flex align-items-center gap-3 p-3 mb-4 rounded-3 border" style="border-color: #f1f5f9 !important; background-color: #ffffff;">
              <div class="d-flex align-items-center justify-content-center flex-shrink-0" style="width: 40px; height: 40px; border-radius: 10px; background-color: #f5f3ff; color: #6366f1;">
                <i data-lucide="calendar" style="width: 20px; height: 20px;"></i>
              </div>
              <div>
                <h6 class="fw-bold mb-0 text-dark" style="font-size: 14.5px;">Academic Year Details</h6>
                <p class="text-muted mb-0" style="font-size: 12.5px;">Define the name, date range, and status for this academic year.</p>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary mb-1">Academic Year Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" value="<?= e($session['name']) ?>" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
            </div>

            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label small fw-semibold text-secondary mb-1">Start Date <span class="text-danger">*</span></label>
                <div class="position-relative">
                  <input type="date" name="start_date" class="form-control" value="<?= e($session['start_date']) ?>" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold text-secondary mb-1">End Date <span class="text-danger">*</span></label>
                <div class="position-relative">
                  <input type="date" name="end_date" class="form-control" value="<?= e($session['end_date']) ?>" required style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
                </div>
              </div>
            </div>

            <div class="mb-2">
              <label class="form-label small fw-semibold text-secondary mb-1">Status <span class="text-danger">*</span></label>
              <select name="status" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 14px;">
                <option value="draft" <?= $session['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
                <option value="active" <?= $session['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                <option value="archived" <?= $session['status'] === 'archived' ? 'selected' : '' ?>>Archived</option>
              </select>
            </div>
          </div>
          <div class="modal-footer border-0 px-4 pb-4 pt-2 d-flex justify-content-end align-items-center gap-2">
            <button type="button" class="btn btn-link text-secondary text-decoration-none fw-medium px-3 py-2" data-bs-dismiss="modal" style="font-size: 14px;">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; font-size: 14px;">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Manage Terms Modal (Calendar Icon) -->
  <div class="modal fade" id="termsModal-<?= $session['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
        <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
          <div>
            <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
              <i data-lucide="layers" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
              Manage Terms — <?= e($session['name']) ?>
            </h5>
            <div class="text-muted small mt-1">Configure terms / semesters for this academic year.</div>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <!-- Existing Terms List -->
          <div class="mb-4">
            <h6 class="fw-bold text-dark small text-uppercase mb-3" style="letter-spacing: 0.05em;">Current Terms (<?= count($session['terms']) ?>)</h6>
            <?php if (empty($session['terms'])): ?>
              <div class="p-3 text-center text-muted bg-light rounded-3 small">
                No terms configured for this academic year yet.
              </div>
            <?php else: ?>
              <div class="table-responsive border rounded-3 overflow-hidden">
                <table class="table align-middle mb-0 table-sm" style="font-size: 13px;">
                  <thead class="bg-light text-muted fw-bold">
                    <tr>
                      <th class="py-2 px-3">TERM NAME</th>
                      <th class="py-2 px-3">START DATE</th>
                      <th class="py-2 px-3">END DATE</th>
                      <th class="py-2 px-3">STATUS</th>
                      <?php if (hasPermission('academic_sessions.manage')): ?>
                        <th class="py-2 px-3 text-end">ACTIONS</th>
                      <?php endif; ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($session['terms'] as $term): ?>
                      <tr>
                        <td class="py-2 px-3 fw-semibold text-dark"><?= e($term['name']) ?></td>
                        <td class="py-2 px-3 text-muted"><?= date('d/m/Y', strtotime($term['start_date'])) ?></td>
                        <td class="py-2 px-3 text-muted"><?= date('d/m/Y', strtotime($term['end_date'])) ?></td>
                        <td class="py-2 px-3">
                          <?php if (!empty($term['is_active'])): ?>
                            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1">Active</span>
                          <?php else: ?>
                            <span class="badge bg-light text-secondary border px-2 py-1">Inactive</span>
                          <?php endif; ?>
                        </td>
                        <?php if (hasPermission('academic_sessions.manage')): ?>
                          <td class="py-2 px-3 text-end">
                            <div class="d-inline-flex gap-1 align-items-center">
                              <?php if (empty($term['is_active'])): ?>
                                <form method="post" action="<?= e(url("academic-sessions/terms/{$term['id']}/activate")) ?>" class="m-0" title="Set as Active Term">
                                  <?= csrf_field() ?>
                                  <button type="submit" class="btn btn-xs btn-outline-success p-1 px-2 rounded" style="font-size: 11px;">
                                    Activate
                                  </button>
                                </form>
                              <?php endif; ?>
                              <form method="post" action="<?= e(url("academic-sessions/terms/{$term['id']}/delete")) ?>" class="m-0" onsubmit="return confirm('Delete this term?');" title="Delete Term">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-xs btn-outline-danger p-1 px-2 rounded" style="font-size: 11px;">
                                  Delete
                                </button>
                              </form>
                            </div>
                          </td>
                        <?php endif; ?>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Add Term Form Section -->
          <?php if (hasPermission('academic_sessions.manage')): ?>
            <div class="card border rounded-3 bg-light p-3">
              <h6 class="fw-bold text-dark small mb-3">
                <i data-lucide="plus-circle" class="text-primary me-1" style="width: 15px; height: 15px; vertical-align: middle;"></i>
                Add New Term
              </h6>
              <form method="post" action="<?= e(url("academic-sessions/{$session['id']}/terms")) ?>">
                <?= csrf_field() ?>
                <div class="row g-2 align-items-end">
                  <div class="col-md-5">
                    <label class="form-label small text-secondary mb-1">Term Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control form-control-sm" placeholder="e.g. Term 1 or Fall Semester" required style="border-radius: 6px;">
                  </div>
                  <div class="col-md-3">
                    <label class="form-label small text-secondary mb-1">Start Date <span class="text-danger">*</span></label>
                    <input type="date" name="start_date" class="form-control form-control-sm" required style="border-radius: 6px;">
                  </div>
                  <div class="col-md-3">
                    <label class="form-label small text-secondary mb-1">End Date <span class="text-danger">*</span></label>
                    <input type="date" name="end_date" class="form-control form-control-sm" required style="border-radius: 6px;">
                  </div>
                  <div class="col-md-1">
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Add</button>
                  </div>
                </div>
              </form>
            </div>
          <?php endif; ?>
        </div>
        <div class="modal-footer bg-light px-4 py-2 border-top">
          <button type="button" class="btn btn-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Close</button>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<!-- Hidden form for deleting an academic year -->
<form id="deleteSessionForm" method="post" action="" style="display: none;">
  <?= csrf_field() ?>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('academicYearSearch');
  const statusFilter = document.getElementById('statusFilter');
  const rows = document.querySelectorAll('.session-row');
  const recordCounter = document.getElementById('recordCounter');
  const noResultsRow = document.getElementById('noResultsRow');
  const totalCount = rows.length;

  function filterSessions() {
    const query = searchInput.value.trim().toLowerCase();
    const status = statusFilter.value.toLowerCase();
    let visibleCount = 0;

    rows.forEach(row => {
      const name = row.getAttribute('data-name') || '';
      const rowStatus = row.getAttribute('data-status') || '';

      const matchesQuery = query === '' || name.includes(query);
      const matchesStatus = status === 'all' || rowStatus === status;

      if (matchesQuery && matchesStatus) {
        row.style.display = '';
        visibleCount++;
      } else {
        row.style.display = 'none';
      }
    });

    if (recordCounter) {
      recordCounter.textContent = `Showing 1 to ${visibleCount} of ${totalCount} records`;
    }

    if (noResultsRow) {
      noResultsRow.style.display = visibleCount === 0 ? '' : 'none';
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterSessions);
  }
  if (statusFilter) {
    statusFilter.addEventListener('change', filterSessions);
  }

  // Row highlight style
  rows.forEach(row => {
    row.addEventListener('mouseenter', () => {
      row.style.backgroundColor = '#f8fafc';
    });
    row.addEventListener('mouseleave', () => {
      row.style.backgroundColor = '';
    });
  });

  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
});

function confirmDeleteSession(id, name, isActive, linkedCount) {
  if (isActive === 1) {
    if (typeof showDeleteConfirm === 'function') {
      showDeleteConfirm({
        title: 'Cannot Delete Active Year',
        message: `"${name}" is currently the active academic year.`,
        subtext: 'You cannot delete the active session. Please activate another academic year first.',
        confirmText: 'Understood',
        onConfirm: function() {
          if (typeof closeDeleteConfirm === 'function') closeDeleteConfirm();
        }
      });
    } else {
      alert(`"${name}" is currently active and cannot be deleted.`);
    }
    return;
  }

  if (linkedCount > 0) {
    if (typeof showDeleteConfirm === 'function') {
      showDeleteConfirm({
        title: 'Cannot Delete Academic Year',
        message: `"${name}" has ${linkedCount} linked record(s) (such as fee invoices, students, or exams).`,
        subtext: 'Deleting this session would violate data integrity. Please set its status to Archived instead.',
        confirmText: 'Understood',
        onConfirm: function() {
          if (typeof closeDeleteConfirm === 'function') closeDeleteConfirm();
        }
      });
    } else {
      alert(`"${name}" has ${linkedCount} linked record(s) and cannot be deleted. Please archive it instead.`);
    }
    return;
  }

  showDeleteConfirm({
    title: 'Delete Academic Session',
    message: `Are you sure you want to delete ${name}?`,
    subtext: 'This action cannot be undone and will permanently remove this academic year and its terms.',
    confirmText: 'Delete',
    onConfirm: function() {
      const form = document.getElementById('deleteSessionForm');
      form.action = `<?= e(url('academic-sessions')) ?>/${id}/delete`;
      form.submit();
    }
  });
}
</script>

<style>
.btn-icon-action {
  color: #64748b;
  background: transparent;
  border: 1px solid transparent;
  padding: 4px 6px;
  border-radius: 6px;
  transition: all 0.15s ease;
}
.btn-icon-action:hover {
  color: #4f46e5;
  background-color: #f1f5f9;
}
.btn-icon-action.text-danger:hover {
  color: #ef4444 !important;
  background-color: #fef2f2;
}
.hover-bg-light:hover {
  background-color: #f8fafc;
  color: #1e293b !important;
}
</style>
