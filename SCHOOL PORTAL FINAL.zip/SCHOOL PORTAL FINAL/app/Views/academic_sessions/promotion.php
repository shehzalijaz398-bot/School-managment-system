<?php
/**
 * Student Promotion & Session Rollover View - CodeClove School Management Pro UI Match
 */
?>

<!-- Breadcrumbs & Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Students</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Promotion &amp; Rollover</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Student Promotion &amp; Session Rollover</h1>
      <p class="text-muted small mb-0">Advance active student profiles into the new academic year. Set up class mappings, preview capacity issues, and execute rollover in a single transaction.</p>
    </div>
  </div>
</div>

<!-- STEP 01: Select Academic Sessions (Matches CodeClove Screenshot) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <!-- Step Header -->
    <div class="d-flex align-items-start gap-3 mb-4">
      <div class="rounded-circle border d-flex align-items-center justify-content-center text-muted fw-bold flex-shrink-0" 
           style="width: 32px; height: 32px; font-size: 13px; background: #f8fafc; border-color: #cbd5e1 !important;">
        01
      </div>
      <div>
        <h5 class="fw-bold text-dark mb-0 fs-6">Select Academic Sessions</h5>
        <p class="text-muted small mb-0">Define the source session to promote from and target session to enroll into.</p>
      </div>
    </div>

    <!-- Sessions Selectors Form -->
    <form method="get" action="<?= e(url('students/promotion')) ?>" id="sessionSelectForm" class="row g-4">
      <!-- Source Academic Year -->
      <div class="col-12 col-md-6">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 12px; letter-spacing: 0.02em;">
          Source Academic Year (Promote From)
        </label>
        <select name="source_year_id" class="form-select" style="height: 42px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <?php foreach ($years as $yr): ?>
            <option value="<?= (int)$yr['id'] ?>" <?= ((int)$yr['id'] === (int)$sourceYearId) ? 'selected' : '' ?>>
              <?= e($yr['name']) ?> <?= $yr['is_active'] ? '(Current)' : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Target Academic Year -->
      <div class="col-12 col-md-6">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 12px; letter-spacing: 0.02em;">
          Target Academic Year (Promote Into)
        </label>
        <select name="target_year_id" id="targetYearSelect" class="form-select" style="height: 42px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="0" disabled <?= empty($targetYearId) ? 'selected' : '' ?>>Select target session</option>
          <?php foreach ($years as $yr): ?>
            <?php if ((int)$yr['id'] !== (int)$sourceYearId): ?>
              <option value="<?= (int)$yr['id'] ?>" <?= ((int)$yr['id'] === (int)$targetYearId) ? 'selected' : '' ?>>
                <?= e($yr['name']) ?> <?= $yr['is_active'] ? '(Active)' : '[Draft / Upcoming]' ?>
              </option>
            <?php endif; ?>
          <?php endforeach; ?>
        </select>
      </div>
    </form>
  </div>
</div>

<!-- STEP 02: Class & Section Promotion Mapping -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <!-- Step Header -->
    <div class="d-flex align-items-start gap-3 mb-4">
      <div class="rounded-circle border d-flex align-items-center justify-content-center text-muted fw-bold flex-shrink-0" 
           style="width: 32px; height: 32px; font-size: 13px; background: #f8fafc; border-color: #cbd5e1 !important;">
        02
      </div>
      <div>
        <h5 class="fw-bold text-dark mb-0 fs-6">Class &amp; Section Promotion Mapping</h5>
        <p class="text-muted small mb-0">Set up source class to target class progressions, configure minimum passing percentage, and review student lists.</p>
      </div>
    </div>

    <!-- Targeted Class-to-Class Promotion Engine -->
    <form method="post" action="<?= e(url('academic/promotion/process-mass')) ?>" id="massPromotionForm" onsubmit="return confirmMassPromotion(this)">
      <?= csrf_field() ?>
      <input type="hidden" name="target_year_id" value="<?= (int)$targetYearId ?>">

      <div class="p-3 mb-4 rounded-3 border" style="background: #f8fafc; border-color: #e2e8f0 !important;">
        <div class="row g-3 align-items-center">
          
          <!-- Source Class & Section -->
          <div class="col-12 col-md-4">
            <label class="form-label small fw-semibold text-secondary mb-1">Source Class &amp; Section</label>
            <div class="d-flex gap-2">
              <select name="source_class_id" id="sourceClassSelect" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;" onchange="onSourceClassChange(this)">
                <option value="" disabled selected>Select Class...</option>
                <?php foreach ($classes as $c): ?>
                  <option value="<?= (int)$c['id'] ?>" data-active="<?= (int)($c['active_students'] ?? 0) ?>">
                    <?= e($c['name']) ?> (<?= (int)($c['active_students'] ?? 0) ?> Students)
                  </option>
                <?php endforeach; ?>
              </select>
              <select name="source_section_id" id="sourceSectionSelect" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                <option value="0">All Sections</option>
              </select>
            </div>
          </div>

          <!-- Direction Arrow -->
          <div class="col-12 col-md-1 text-center d-none d-md-block">
            <i data-lucide="arrow-right" class="text-muted" style="width: 22px; height: 22px;"></i>
          </div>

          <!-- Target Class & Section -->
          <div class="col-12 col-md-4">
            <label class="form-label small fw-semibold text-secondary mb-1">Target Class &amp; Section</label>
            <div class="d-flex gap-2">
              <select name="target_class_id" id="targetClassSelect" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;" onchange="onTargetClassChange(this)">
                <option value="" disabled selected>Target Next Class...</option>
                <?php foreach ($classes as $c): ?>
                  <option value="<?= (int)$c['id'] ?>">
                    <?= e($c['name']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <select name="target_section_id" id="targetSectionSelect" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                <option value="0">Auto / First Section</option>
              </select>
            </div>
          </div>

          <!-- Min Passing Percentage -->
          <div class="col-12 col-md-3">
            <label class="form-label small fw-semibold text-secondary mb-1">Min Passing Threshold</label>
            <div class="input-group input-group-sm">
              <input type="number" step="0.5" name="pass_percentage" class="form-control" value="40.0" min="0" max="100" required style="height: 38px; border-radius: 8px 0 0 8px;">
              <span class="input-group-text bg-light text-muted" style="border-radius: 0 8px 8px 0;">%</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Rule Evaluation Note -->
      <div class="alert alert-light border-0 d-flex align-items-center gap-3 p-3 mb-4 rounded-3" style="background-color: #f1f5f9; border-left: 4px solid #4f46e5 !important;">
        <i data-lucide="info" style="width: 20px; height: 20px; color: #4f46e5;" class="flex-shrink-0"></i>
        <div class="small text-secondary mb-0">
          <strong>Promotion Rule:</strong> Students who achieved &ge; <span id="thresholdDisplay">40%</span> in their terminal examinations will be promoted to the Target Class. Students below the threshold will remain in their current grade for the target academic year.
        </div>
      </div>

      <!-- Execution Button -->
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span class="text-muted small">
          Target Session: <strong><?= e($nextYear['name'] ?? 'Upcoming Session') ?></strong>
        </span>
        <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-4 py-2" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; height: 40px;">
          <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
          <span>Execute Class Promotion</span>
        </button>
      </div>
    </form>

    <hr class="my-4 text-muted opacity-25">

    <!-- Automated School Progression Overview Table -->
    <h6 class="fw-bold text-dark mb-3 fs-6">School Grade Progression Hierarchy</h6>
    <div class="table-responsive">
      <table class="table align-middle table-sm mb-0">
        <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; color: #64748b;">
          <tr>
            <th class="ps-3 py-2">Current Class</th>
            <th class="py-2">Active Students</th>
            <th class="py-2">Auto Next Progression</th>
            <th class="py-2">Sections Mapped</th>
            <th class="pe-3 py-2 text-end">Quick Action</th>
          </tr>
        </thead>
        <tbody style="font-size: 13px;">
          <?php 
            $classesCount = count($classes);
            for ($i = 0; $i < $classesCount; $i++):
              $curr = $classes[$i];
              $next = $classes[$i + 1] ?? null;
          ?>
            <tr style="border-bottom: 1px solid #f1f5f9;">
              <td class="ps-3 py-2 fw-semibold text-dark">
                <?= e($curr['name']) ?>
              </td>
              <td class="py-2">
                <span class="badge bg-light text-secondary border fw-medium px-2 py-1">
                  <?= (int)($curr['active_students'] ?? 0) ?> Students
                </span>
              </td>
              <td class="py-2">
                <?php if ($next): ?>
                  <span class="d-inline-flex align-items-center gap-1 text-primary fw-medium">
                    <i data-lucide="arrow-right" style="width: 14px; height: 14px;"></i>
                    <?= e($next['name']) ?>
                  </span>
                <?php else: ?>
                  <span class="badge bg-success-subtle text-success fw-medium">Graduation / Alumni</span>
                <?php endif; ?>
              </td>
              <td class="py-2 text-muted small">
                <?= count($curr['sections'] ?? []) ?> section(s)
              </td>
              <td class="pe-3 py-2 text-end">
                <button type="button" class="btn btn-xs btn-outline-secondary px-2 py-1" style="border-radius: 6px; font-size: 11px;" 
                        onclick="autoFillProgression(<?= (int)$curr['id'] ?>, <?= $next ? (int)$next['id'] : 0 ?>)">
                  Select in Form
                </button>
              </td>
            </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- STEP 03: Global Academic Session Rollover -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <!-- Step Header -->
    <div class="d-flex align-items-start gap-3 mb-4">
      <div class="rounded-circle border d-flex align-items-center justify-content-center text-muted fw-bold flex-shrink-0" 
           style="width: 32px; height: 32px; font-size: 13px; background: #f8fafc; border-color: #cbd5e1 !important;">
        03
      </div>
      <div>
        <h5 class="fw-bold text-dark mb-0 fs-6">Execute Global Session Rollover</h5>
        <p class="text-muted small mb-0">Universally activate the new academic session as the global current year across the ERP.</p>
      </div>
    </div>

    <div class="p-4 rounded-3 border" style="background: #fffbeb; border-color: #fde68a !important;">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
          <h6 class="fw-bold text-dark mb-1">Deploy Next Session Globally</h6>
          <p class="text-muted small mb-0">Once students are promoted, switch the school instance so all modules (attendance, fee vouchers, daily timetables) open in the new session timeline.</p>
        </div>
        <form method="post" action="<?= e(url('academic/promotion/rollover-session')) ?>" onsubmit="return confirmGlobalRollover(this)">
          <?= csrf_field() ?>
          <input type="hidden" name="rollover_year_id" value="<?= (int)$targetYearId ?>">
          <button type="submit" class="btn btn-sm btn-outline-danger d-inline-flex align-items-center gap-2 fw-semibold px-3 py-2 shadow-sm" style="border-radius: 8px; height: 40px;" <?= empty($targetYearId) ? 'disabled' : '' ?>>
            <i data-lucide="refresh-cw" style="width: 15px; height: 15px;"></i>
            <span>Set Target Session as Active</span>
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Dynamic JavaScript -->
<script>
const classesData = <?= json_encode($classes) ?>;

function onSourceClassChange(classSelect) {
  const classId = parseInt(classSelect.value);
  const secSelect = document.getElementById('sourceSectionSelect');
  secSelect.innerHTML = '<option value="0">All Sections</option>';

  const cls = classesData.find(c => parseInt(c.id) === classId);
  if (cls && cls.sections) {
    cls.sections.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = s.name;
      secSelect.appendChild(opt);
    });
  }

  // Auto pick next class in target
  const idx = classesData.findIndex(c => parseInt(c.id) === classId);
  if (idx !== -1 && idx < classesData.length - 1) {
    const nextCls = classesData[idx + 1];
    const targetSelect = document.getElementById('targetClassSelect');
    targetSelect.value = nextCls.id;
    onTargetClassChange(targetSelect);
  }
}

function onTargetClassChange(classSelect) {
  const classId = parseInt(classSelect.value);
  const secSelect = document.getElementById('targetSectionSelect');
  secSelect.innerHTML = '<option value="0">Auto / First Section</option>';

  const cls = classesData.find(c => parseInt(c.id) === classId);
  if (cls && cls.sections) {
    cls.sections.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = s.name;
      secSelect.appendChild(opt);
    });
  }
}

function autoFillProgression(sourceId, targetId) {
  const sourceSelect = document.getElementById('sourceClassSelect');
  sourceSelect.value = sourceId;
  onSourceClassChange(sourceSelect);

  if (targetId > 0) {
    const targetSelect = document.getElementById('targetClassSelect');
    targetSelect.value = targetId;
    onTargetClassChange(targetSelect);
  }

  window.scrollTo({
    top: document.getElementById('massPromotionForm').offsetTop - 80,
    behavior: 'smooth'
  });
}

function confirmMassPromotion(form) {
  const srcClass = form.querySelector('#sourceClassSelect');
  const tgtClass = form.querySelector('#targetClassSelect');
  const srcText = srcClass.options[srcClass.selectedIndex]?.text || '';
  const tgtText = tgtClass.options[tgtClass.selectedIndex]?.text || '';

  return confirm(`Confirm Promotion:\n\nAre you sure you want to promote students from "${srcText}" to "${tgtText}"?\n\nEligible students will advance into the target academic cycle.`);
}

function confirmGlobalRollover(form) {
  const confirmed = prompt("CRITICAL OPERATION:\nYou are about to switch the entire school portal active session.\n\nType 'ROLLOVER' to proceed:");
  return confirmed === 'ROLLOVER';
}

document.addEventListener('DOMContentLoaded', function() {
  if (window.lucide) {
    lucide.createIcons();
  }
});
</script>
