<?php
$layout = 'layouts/app';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Certificates & Documents') ?>
        </h1>
        <p class="text-muted small mb-0">
            Generate, manage, and print official Transfer Certificates (TC), Bonafide, Character, and Staff Experience certificates
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                data-bs-toggle="modal" data-bs-target="#newCertModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="file-badge" style="width: 16px; height: 16px;"></i>
            <span>Generate Certificate</span>
        </button>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="award" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Total Issued</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Official Documents</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 34px; height: 34px;">
                        <i data-lucide="file-output" style="width: 16px; height: 16px; stroke: #dc2626;"></i>
                    </div>
                    <span class="badge rounded-pill bg-danger-subtle text-danger px-2 py-1" style="font-size: 10px;">TC Issued</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['tc'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Transfer Certificates</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="check-circle" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 10px;">Bonafide</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['bonafide'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Bonafide Letters</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="user-check" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <span class="badge rounded-pill bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">Conduct</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['character'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Character Certificates</div>
            </div>
        </div>
    </div>
</div>

<!-- Certificate Ledger Table -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <!-- Filter bar -->
        <form method="GET" action="<?= e(url('certificates')) ?>" class="row g-2 align-items-center mb-3">
            <div class="col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
                    <input type="text" name="q" class="form-control border-start-0" placeholder="Search by certificate # or recipient..." value="<?= e($filters['q'] ?? '') ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="type" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Certificate Types</option>
                    <option value="transfer" <?= ($filters['type'] ?? '') === 'transfer' ? 'selected' : '' ?>>Transfer Certificate (TC)</option>
                    <option value="bonafide" <?= ($filters['type'] ?? '') === 'bonafide' ? 'selected' : '' ?>>Bonafide Student Certificate</option>
                    <option value="character" <?= ($filters['type'] ?? '') === 'character' ? 'selected' : '' ?>>Character &amp; Conduct</option>
                    <option value="experience" <?= ($filters['type'] ?? '') === 'experience' ? 'selected' : '' ?>>Staff Experience</option>
                    <option value="merit" <?= ($filters['type'] ?? '') === 'merit' ? 'selected' : '' ?>>Merit &amp; Achievement</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary w-100">Filter</button>
                <?php if (!empty($filters['q']) || !empty($filters['type'])): ?>
                    <a href="<?= e(url('certificates')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Cert # / Title</th>
                        <th>Type</th>
                        <th>Recipient</th>
                        <th>Class / Role</th>
                        <th>Issue Date</th>
                        <th>Verification Code</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($certificates)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No certificates found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($certificates as $c): ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark font-monospace"><?= e($c['certificate_no']) ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><?= e($c['title']) ?></div>
                                </td>
                                <td>
                                    <span class="badge rounded-pill bg-light text-dark border text-uppercase" style="font-size: 10px;">
                                        <?= e($c['type']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?= e($c['recipient_name']) ?></div>
                                    <div class="text-muted small" style="font-size: 11px;"><?= e($c['admission_no'] ?? '') ?></div>
                                </td>
                                <td><?= e($c['class_name'] ? ($c['class_name'] . ' ' . ($c['section_name'] ?? '')) : 'Staff') ?></td>
                                <td><?= date('M d, Y', strtotime($c['issue_date'])) ?></td>
                                <td>
                                    <code class="text-primary fw-bold" style="font-size: 11px;"><?= e($c['verification_code']) ?></code>
                                </td>
                                <td>
                                    <?php if ($c['status'] === 'issued'): ?>
                                        <span class="badge bg-success-subtle text-success">Valid</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">Revoked</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-3">
                                    <a href="<?= e(url('certificates/print/' . $c['id'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary py-1 px-3 rounded-pill" style="font-size: 12px;">
                                        <i data-lucide="printer" style="width: 13px; height: 13px; margin-right: 4px;"></i> Print / View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal: Generate Certificate -->
<div class="modal fade" id="newCertModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('certificates/generate')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Generate Official School Certificate</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Certificate Type *</label>
                            <select name="type" class="form-select" id="certTypeSelect" required>
                                <option value="transfer">Transfer Certificate (School Leaving / TC)</option>
                                <option value="bonafide">Bonafide Student Certificate</option>
                                <option value="character">Character &amp; Conduct Certificate</option>
                                <option value="experience">Staff Experience Certificate</option>
                                <option value="merit">Merit &amp; Achievement Award</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Recipient Type *</label>
                            <select name="recipient_type" class="form-select" id="recipientTypeSelect" required onchange="toggleRecipientType(this.value)">
                                <option value="student">Student</option>
                                <option value="staff">Staff / Employee</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3" id="studentSelectWrapper">
                        <label class="form-label small fw-bold">Select Student *</label>
                        <select name="student_id" class="form-select">
                            <option value="">-- Choose Student --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?> - <?= e($st['class_name'] ?? '') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3 d-none" id="staffSelectWrapper">
                        <label class="form-label small fw-bold">Select Staff Member *</label>
                        <select name="employee_id" class="form-select">
                            <option value="">-- Choose Employee --</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= (int)$emp['id'] ?>">
                                    <?= e($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= e($emp['employee_code']) ?> - <?= e($emp['designation'] ?? '') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">Certificate Header / Title (Optional)</label>
                            <input type="text" name="title" class="form-control" placeholder="Leave empty for default title">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Date of Issuance</label>
                            <input type="date" name="issue_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Custom Statement / Body (Optional)</label>
                        <textarea name="content" class="form-control" rows="4" placeholder="Leave empty to automatically generate official institutional text format with cleared fee dues and character record."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Generate &amp; Print</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleRecipientType(type) {
    if (type === 'staff') {
        document.getElementById('studentSelectWrapper').classList.add('d-none');
        document.getElementById('staffSelectWrapper').classList.remove('d-none');
    } else {
        document.getElementById('studentSelectWrapper').classList.remove('d-none');
        document.getElementById('staffSelectWrapper').classList.add('d-none');
    }
}
</script>
