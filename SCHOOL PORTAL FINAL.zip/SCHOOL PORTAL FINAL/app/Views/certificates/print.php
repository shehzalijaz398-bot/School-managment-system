<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($certificate['title']) ?> - <?= e($certificate['certificate_no']) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,400&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: #f1f5f9;
            font-family: 'Inter', sans-serif;
            color: #1e293b;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 30px 15px;
        }
        .action-bar {
            width: 900px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn {
            background: #4f46e5;
            color: #ffffff;
            border: none;
            padding: 10px 22px;
            border-radius: 9999px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);
        }
        .btn:hover { background: #4338ca; }
        .btn-outline {
            background: #ffffff;
            color: #475569;
            border: 1px solid #cbd5e1;
            box-shadow: 0 1px 2px 0 rgba(0,0,0,0.05);
        }
        .btn-outline:hover { background: #f8fafc; }

        /* The Certificate Paper (A4 Landscape / Formal Box) */
        .cert-paper {
            width: 900px;
            min-height: 620px;
            background: #ffffff;
            position: relative;
            padding: 30px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .cert-inner-border {
            border: 4px double #0f172a;
            height: 100%;
            min-height: 560px;
            padding: 36px 44px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .corner-ornament {
            position: absolute;
            width: 28px;
            height: 28px;
            border: 3px solid #b45309;
        }
        .corner-tl { top: 6px; left: 6px; border-right: none; border-bottom: none; }
        .corner-tr { top: 6px; right: 6px; border-left: none; border-bottom: none; }
        .corner-bl { bottom: 6px; left: 6px; border-right: none; border-top: none; }
        .corner-br { bottom: 6px; right: 6px; border-left: none; border-top: none; }

        /* Header */
        .cert-header {
            text-align: center;
        }
        .school-name {
            font-family: 'Cinzel', serif;
            font-size: 26px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .school-sub {
            font-size: 13px;
            color: #64748b;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .cert-meta-row {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #475569;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 8px;
            margin-top: 14px;
            margin-bottom: 24px;
        }
        .cert-title-badge {
            font-family: 'Cinzel', serif;
            font-size: 22px;
            font-weight: 700;
            color: #b45309;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            margin-bottom: 18px;
            display: inline-block;
            border-bottom: 2px solid #fde68a;
            padding-bottom: 4px;
        }

        /* Body */
        .cert-body {
            text-align: center;
            font-family: 'Playfair Display', serif;
            font-size: 17px;
            line-height: 1.8;
            color: #1e293b;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        .recipient-name {
            font-family: 'Playfair Display', serif;
            font-size: 26px;
            font-weight: 700;
            color: #0f172a;
            border-bottom: 1px dashed #94a3b8;
            display: inline-block;
            padding: 0 16px;
            margin: 4px 0;
        }

        /* Signatures & Footer */
        .cert-footer {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 20px;
        }
        .sig-block {
            text-align: center;
            width: 180px;
        }
        .sig-line {
            border-top: 1px solid #334155;
            margin-top: 40px;
            padding-top: 6px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: #334155;
            letter-spacing: 0.04em;
        }
        .seal-circle {
            width: 80px;
            height: 80px;
            border: 2px dashed #b45309;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
            color: #b45309;
            text-transform: uppercase;
            text-align: center;
            margin: 0 auto;
            letter-spacing: 0.05em;
        }

        @media print {
            body { background: transparent; padding: 0; }
            .action-bar { display: none; }
            .cert-paper { box-shadow: none; border-radius: 0; width: 100%; }
        }
    </style>
</head>
<body>

    <div class="action-bar">
        <a href="<?= e(url('certificates')) ?>" class="btn btn-outline">&larr; Back to Certificates</a>
        <button onclick="window.print()" class="btn">
            Print Certificate
        </button>
    </div>

    <div class="cert-paper">
        <div class="cert-inner-border">
            <div class="corner-ornament corner-tl"></div>
            <div class="corner-ornament corner-tr"></div>
            <div class="corner-ornament corner-bl"></div>
            <div class="corner-ornament corner-br"></div>

            <div class="cert-header">
                <div class="school-name"><?= e($school['name'] ?? 'School Educational System') ?></div>
                <div class="school-sub"><?= e($school['address'] ?? 'Official Academic Campus &amp; Directorate of Examinations') ?></div>

                <div class="cert-meta-row">
                    <div><strong>Certificate No:</strong> <?= e($certificate['certificate_no']) ?></div>
                    <div><strong>Date of Issue:</strong> <?= date('F d, Y', strtotime($certificate['issue_date'])) ?></div>
                    <div><strong>Verification Code:</strong> <?= e($certificate['verification_code']) ?></div>
                </div>

                <div class="cert-title-badge">
                    <?= e($certificate['title']) ?>
                </div>
            </div>

            <div class="cert-body">
                This is to officially certify that
                <br>
                <span class="recipient-name"><?= e($certificate['recipient_name']) ?></span>
                <br>
                <span style="font-size: 15px; font-family: 'Inter', sans-serif; color: #475569;">
                    <?php if ($certificate['recipient_type'] === 'student'): ?>
                        Admission No: <strong><?= e($certificate['admission_no'] ?? 'N/A') ?></strong> &bull; Class: <strong><?= e($certificate['class_name'] ?? 'General') ?> <?= e($certificate['section_name'] ?? '') ?></strong>
                    <?php else: ?>
                        Employee Code: <strong><?= e($certificate['employee_code'] ?? 'N/A') ?></strong> &bull; Designation: <strong><?= e($certificate['designation'] ?? 'Staff') ?></strong>
                    <?php endif; ?>
                </span>
                <br><br>
                <?= nl2br(e($certificate['content'])) ?>
            </div>

            <div class="cert-footer">
                <div class="sig-block">
                    <div class="sig-line">Prepared By</div>
                </div>
                <div>
                    <div class="seal-circle">
                        Institutional<br>Seal
                    </div>
                </div>
                <div class="sig-block">
                    <div class="sig-line">Principal / Registrar</div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
