<?php
$school = currentSchool() ?? [];
$schoolName = $school['name'] ?? 'Apex International Academy';
$schoolAddress = $school['address'] ?? 'Institutional Campus · Education Boulevard';
$schoolContact = ($school['email'] ?? 'admin@school.edu') . ' · ' . ($school['phone'] ?? '+1 (555) 019-2834');

$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$admNo = $student['admission_no'] ?? 'N/A';
$rollNo = $student['roll_no'] ?? 'N/A';
$className = $student['class_name'] ?? 'Grade';
$sectionName = $student['section_name'] ?? '';
$gender = ucfirst((string) ($student['gender'] ?? 'Not Specified'));
$dob = !empty($student['date_of_birth']) ? date('M d, Y', strtotime((string)$student['date_of_birth'])) : 'N/A';
$guardianName = $student['guardian_name'] ?? ($student['parent_name'] ?? 'Guardian / Parent');

$examName = $exam['name'] ?? 'Term Assessment';
$examStatus = strtoupper((string) ($exam['status'] ?? 'PUBLISHED'));
$issueDate = date('F d, Y');
$reportUid = 'TRN-' . strtoupper(substr(md5(($exam['id'] ?? 0) . '-' . ($student['id'] ?? 0) . '-salt'), 0, 8));

$totalMax = (float) ($result['total_max'] ?? 0);
$totalObtained = (float) ($result['total_obtained'] ?? 0);
$percentage = (float) ($result['percentage'] ?? 0);
$overallGrade = $result['grade'] ?? 'N/A';
$isPassed = !empty($result['passed']);
$position = $result['position'] ?? null;

$insightsData = $insights ?? [];
$gpa = $insightsData['gpa_4'] ?? 0.0;
$percentile = $insightsData['percentile'] ?? null;
$attendanceRate = $insightsData['attendance_rate'] ?? null;
$strengths = $insightsData['strengths'] ?? [];
$focusAreas = $insightsData['focus_areas'] ?? [];
$synthesisText = $insightsData['academic_synthesis'] ?? 'Comprehensive evaluation based on verified examination records.';
?>

<style>
  @media print {
    .no-print { display: none !important; }
    body { padding: 0 !important; background: #fff !important; color: #0f172a !important; }
    .report-card-container { box-shadow: none !important; border: 1px solid #cbd5e1 !important; margin: 0 !important; width: 100% !important; max-width: 100% !important; }
    .page-break-inside-avoid { break-inside: avoid; }
    @page { margin: 12mm 15mm; size: A4 portrait; }
  }
  .report-card-container {
    max-width: 960px;
    margin: 0 auto;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.06);
    padding: 32px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #1e293b;
  }
  .header-band {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 2px solid #0f172a;
    padding-bottom: 20px;
    margin-bottom: 24px;
  }
  .school-crest-badge {
    width: 64px;
    height: 64px;
    background: #0f172a;
    color: #ffffff;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 26px;
    letter-spacing: -0.5px;
  }
  .metric-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 14px 16px;
    text-align: center;
  }
  .metric-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 700;
    color: #64748b;
    margin-bottom: 4px;
  }
  .metric-value {
    font-size: 22px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.2;
  }
  .dossier-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 24px;
  }
  .dossier-item .d-label {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    color: #64748b;
  }
  .dossier-item .d-val {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
  }
  .table-transcript th {
    background: #f1f5f9;
    color: #334155;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    padding: 10px 12px;
    border-bottom: 2px solid #cbd5e1;
  }
  .table-transcript td {
    padding: 10px 12px;
    font-size: 13.5px;
    vertical-align: middle;
    border-bottom: 1px solid #e2e8f0;
  }
  .pill-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 9999px;
    font-size: 11px;
    font-weight: 700;
  }
  .pill-success { background: #dcfce7; color: #15803d; }
  .pill-warning { background: #fef3c7; color: #b45309; }
  .pill-danger { background: #fee2e2; color: #b91c1c; }
  .pill-primary { background: #e0f2fe; color: #0369a1; }
  .insight-panel {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 8px;
    padding: 18px 20px;
    margin-top: 24px;
  }
  .signature-line {
    border-top: 1px dashed #94a3b8;
    margin-top: 50px;
    padding-top: 8px;
    text-align: center;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
  }
</style>

<div class="no-print d-flex justify-content-between align-items-center mb-4 max-w-4xl mx-auto" style="max-width: 960px;">
  <div class="d-flex align-items-center gap-2">
    <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m15 18-6-6 6-6"/></svg>
      Return
    </a>
    <span class="text-muted small">Official Institutional Record · <?= e($reportUid) ?></span>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
      Print Official Transcript
    </button>
  </div>
</div>

<div class="report-card-container">
  <!-- Institutional Header -->
  <div class="header-band">
    <div class="d-flex align-items-center gap-3">
      <div class="school-crest-badge">
        <?= strtoupper(substr($schoolName, 0, 1)) ?>
      </div>
      <div>
        <h2 class="mb-0 fw-bold text-dark" style="font-size: 22px; letter-spacing: -0.3px;"><?= e($schoolName) ?></h2>
        <div class="text-muted small"><?= e($schoolAddress) ?></div>
        <div class="text-muted small" style="font-size: 11px;"><?= e($schoolContact) ?></div>
      </div>
    </div>
    <div class="text-end">
      <span class="badge bg-dark px-3 py-2 text-uppercase mb-1" style="font-size: 11px; letter-spacing: 0.05em;">Official Academic Transcript</span>
      <div class="fw-bold text-primary small"><?= e($examName) ?></div>
      <div class="text-muted" style="font-size: 11px;">Issue Date: <?= e($issueDate) ?></div>
    </div>
  </div>

  <!-- Student Dossier Grid -->
  <div class="dossier-grid">
    <div class="dossier-item">
      <div class="d-label">Student Name</div>
      <div class="d-val"><?= e($studentName) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Admission Number</div>
      <div class="d-val"><?= e($admNo) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Class & Section</div>
      <div class="d-val"><?= e($className) ?> <?= e($sectionName ? '— Sec ' . $sectionName : '') ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Roll Number</div>
      <div class="d-val"><?= e((string)$rollNo) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Date of Birth</div>
      <div class="d-val"><?= e($dob) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Gender</div>
      <div class="d-val"><?= e($gender) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Guardian / Parent</div>
      <div class="d-val"><?= e($guardianName) ?></div>
    </div>
    <div class="dossier-item">
      <div class="d-label">Academic Status</div>
      <div class="d-val">
        <?php if ($isPassed): ?>
          <span class="pill-badge pill-success">PASSED</span>
        <?php else: ?>
          <span class="pill-badge pill-danger">NEEDS IMPROVEMENT</span>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Executive Performance Matrix -->
  <div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
      <div class="metric-card">
        <div class="metric-label">Cumulative GPA</div>
        <div class="metric-value"><?= number_format((float)$gpa, 2) ?> <span class="fs-6 fw-normal text-muted">/ 4.0</span></div>
        <div class="small text-muted mt-1">Grade Point Index</div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="metric-card">
        <div class="metric-label">Aggregate Marks</div>
        <div class="metric-value"><?= e((string)$totalObtained) ?> <span class="fs-6 fw-normal text-muted">/ <?= e((string)$totalMax) ?></span></div>
        <div class="small text-muted mt-1"><?= number_format($percentage, 1) ?>% Overall</div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="metric-card">
        <div class="metric-label">Letter Grade</div>
        <div class="metric-value text-primary"><?= e($overallGrade) ?></div>
        <div class="small text-muted mt-1"><?= $isPassed ? 'Satisfactory Standing' : 'Remediation Required' ?></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="metric-card">
        <div class="metric-label">Class Standing</div>
        <div class="metric-value">
          <?= $position ? '#' . e((string)$position) : 'N/A' ?>
          <?php if (!empty($percentile)): ?>
            <span class="fs-6 fw-bold text-success">(Top <?= 100 - (float)$percentile < 1 ? 1 : round(100 - (float)$percentile) ?>%)</span>
          <?php endif; ?>
        </div>
        <div class="small text-muted mt-1">
          <?= !empty($insightsData['total_students_ranked']) ? 'Out of ' . $insightsData['total_students_ranked'] . ' Students' : 'Class Rank' ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Detailed Subject Examination Breakdown Table -->
  <div class="table-responsive mb-4">
    <table class="table table-transcript align-middle">
      <thead>
        <tr>
          <th style="width: 12%;">Code</th>
          <th style="width: 32%;">Subject Title</th>
          <th class="text-center" style="width: 12%;">Max</th>
          <th class="text-center" style="width: 12%;">Pass</th>
          <th class="text-center" style="width: 12%;">Obtained</th>
          <th class="text-center" style="width: 10%;">Grade</th>
          <th class="text-center" style="width: 10%;">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach (($result['subjects'] ?? []) as $row): 
          $sMax = (float) ($row['max_marks'] ?? 100);
          $sPass = (float) ($row['pass_marks'] ?? 40);
          $sObtained = (float) ($row['marks_obtained'] ?? 0);
          $sPassed = $sObtained >= $sPass;
          $sPct = $sMax > 0 ? round(($sObtained / $sMax) * 100, 1) : 0;
        ?>
          <tr>
            <td class="fw-semibold text-muted font-monospace small"><?= e($row['subject_code'] ?? 'SUB') ?></td>
            <td class="fw-bold text-dark"><?= e($row['subject_name'] ?? 'Subject') ?></td>
            <td class="text-center text-muted"><?= e((string)$sMax) ?></td>
            <td class="text-center text-muted"><?= e((string)$sPass) ?></td>
            <td class="text-center fw-bold fs-6 <?= $sPassed ? 'text-dark' : 'text-danger' ?>">
              <?= e((string)$sObtained) ?>
              <span class="text-muted fw-normal" style="font-size: 11px;">(<?= $sPct ?>%)</span>
            </td>
            <td class="text-center fw-bold">
              <span class="badge bg-light text-dark border"><?= e($row['grade'] ?? 'N/A') ?></span>
            </td>
            <td class="text-center">
              <?php if ($sPassed): ?>
                <span class="pill-badge pill-success">PASS</span>
              <?php else: ?>
                <span class="pill-badge pill-danger">FAIL</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot class="table-group-divider">
        <tr class="fw-bold bg-light">
          <td colspan="2" class="text-uppercase small">Grand Aggregate</td>
          <td class="text-center"><?= e((string)$totalMax) ?></td>
          <td class="text-center">-</td>
          <td class="text-center fs-6 text-primary"><?= e((string)$totalObtained) ?></td>
          <td class="text-center"><?= e($overallGrade) ?></td>
          <td class="text-center">
            <?= $isPassed ? '<span class="pill-badge pill-success">PASSED</span>' : '<span class="pill-badge pill-danger">FAIL</span>' ?>
          </td>
        </tr>
      </tfoot>
    </table>
  </div>

  <!-- Factual Academic Insights & Diagnostic Synthesis -->
  <div class="insight-panel page-break-inside-avoid">
    <div class="d-flex align-items-center justify-content-between mb-2">
      <div class="d-flex align-items-center gap-2">
        <span class="fw-bold text-success text-uppercase small" style="letter-spacing: 0.05em;">
          Academic Performance Synthesis & Insights
        </span>
      </div>
      <?php if ($attendanceRate !== null): ?>
        <span class="small fw-semibold text-muted">
          Institutional Attendance Rate: <strong class="text-dark"><?= $attendanceRate ?>%</strong>
        </span>
      <?php endif; ?>
    </div>
    <p class="mb-3 text-secondary small" style="line-height: 1.6;">
      <?= e($synthesisText) ?>
    </p>

    <div class="row g-2">
      <div class="col-md-6">
        <div class="bg-white border rounded p-2">
          <div class="fw-bold text-success small mb-1">Key Subject Strengths (≥ 80%)</div>
          <?php if (!empty($strengths)): ?>
            <div class="d-flex flex-wrap gap-1">
              <?php foreach ($strengths as $st): ?>
                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1">
                  <?= e($st['subject']) ?>: <?= $st['percentage'] ?>% (Grade <?= e($st['grade']) ?>)
                </span>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <span class="text-muted small">Marks distributed evenly across moderate grade bands.</span>
          <?php endif; ?>
        </div>
      </div>
      <div class="col-md-6">
        <div class="bg-white border rounded p-2">
          <div class="fw-bold text-warning-emphasis small mb-1">Targeted Academic Focus Areas (&lt; 60%)</div>
          <?php if (!empty($focusAreas)): ?>
            <div class="d-flex flex-wrap gap-1">
              <?php foreach ($focusAreas as $fa): ?>
                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-2 py-1">
                  <?= e($fa['subject']) ?>: <?= $fa['percentage'] ?>% (Grade <?= e($fa['grade']) ?>)
                </span>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <span class="text-success small fw-semibold">No subjects below threshold; student maintained solid foundational marks.</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Institutional Grading Scale Standard Reference -->
  <div class="mt-4 p-3 bg-light rounded border page-break-inside-avoid">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <span class="fw-bold small text-muted text-uppercase" style="font-size: 11px;">Institutional Evaluation Scale Reference</span>
      <span class="text-muted font-monospace" style="font-size: 10px;">REF: <?= e($reportUid) ?></span>
    </div>
    <div class="row text-center text-muted" style="font-size: 11px;">
      <div class="col"><strong>A+</strong>: 90–100% (4.0)</div>
      <div class="col"><strong>A</strong>: 80–89% (3.5)</div>
      <div class="col"><strong>B</strong>: 70–79% (3.0)</div>
      <div class="col"><strong>C</strong>: 60–69% (2.5)</div>
      <div class="col"><strong>D</strong>: 40–59% (1.5)</div>
      <div class="col"><strong>F</strong>: &lt;40% (0.0)</div>
    </div>
  </div>

  <!-- Official Signatures Block -->
  <div class="row mt-5 pt-3 page-break-inside-avoid">
    <div class="col-4">
      <div class="signature-line">
        Class Teacher Signature
      </div>
    </div>
    <div class="col-4">
      <div class="signature-line">
        Examination Controller
      </div>
    </div>
    <div class="col-4">
      <div class="signature-line">
        Principal / Official Stamp
      </div>
    </div>
  </div>
</div>