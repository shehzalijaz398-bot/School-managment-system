<style>
@media print {
    @page { size: A4; margin: 15mm; }
    body { font-family: 'Arial', sans-serif; color: #000; background: #fff; }
    .print-btn-container { display: none !important; }
    .border, .table-bordered td, .table-bordered th { border-color: #000 !important; }
}
body { font-family: 'Arial', sans-serif; background: #f8fafc; padding: 20px; }
.print-container {
    max-width: 210mm;
    margin: 0 auto;
    background: #fff;
    padding: 20px 40px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    min-height: 297mm;
}
.school-header {
    text-align: center;
    border-bottom: 2px solid #000;
    padding-bottom: 15px;
    margin-bottom: 30px;
}
.school-name {
    font-size: 28px;
    font-weight: bold;
    text-transform: uppercase;
    margin-bottom: 5px;
}
.exam-title {
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    text-decoration: underline;
    margin-bottom: 25px;
}
.meta-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    font-size: 16px;
    font-weight: bold;
}
.table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 30px;
}
.table th, .table td {
    border: 1px solid #000;
    padding: 10px;
    text-align: left;
}
.table th {
    background-color: #f0f0f0 !important;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}
</style>

<div class="print-btn-container text-center mb-4">
    <button onclick="window.print()" class="btn btn-primary btn-lg rounded-pill shadow px-5">
        <i data-lucide="download" style="width:20px;height:20px;vertical-align:middle;margin-right:8px;"></i> Download (Save as PDF)
    </button>
    <p class="text-muted small mt-2">Hint: In the print dialog, select "Save as PDF" as your destination.</p>
</div>

<div class="print-container">
    <div class="school-header">
        <?php if (!empty($school['logo'])): ?>
            <img src="<?= e(url($school['logo'])) ?>" alt="Logo" style="max-height:80px; margin-bottom:10px;">
        <?php endif; ?>
        <div class="school-name"><?= e($school['name'] ?? 'School Name') ?></div>
        <div style="font-size:14px;"><?= e($school['address'] ?? '') ?></div>
    </div>

    <div class="exam-title">
        DATE SHEET / TIMETABLE
    </div>

    <div class="meta-info">
        <div>Exam: <?= e($exam['name']) ?></div>
        <?php
            // Find class name from database
            $class = \Core\Database::fetch('SELECT name FROM classes WHERE id = ?', [(int)$exam['class_id']]);
        ?>
        <div>Class: <?= e($class['name'] ?? 'N/A') ?> &nbsp;|&nbsp; Section: All Sections</div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th style="width: 25%;">Date</th>
                <th style="width: 25%;">Day</th>
                <th style="width: 50%;">Subject</th>
            </tr>
        </thead>
        <tbody>
            <?php if(empty($timetable)): ?>
                <tr>
                    <td colspan="5" style="text-align:center; padding: 20px;">No timetable has been built for this exam yet.</td>
                </tr>
            <?php else: ?>
                <?php foreach($timetable as $row): 
                    $timestamp = strtotime($row['exam_date']);
                ?>
                <tr>
                    <td><?= date('d-m-Y', $timestamp) ?></td>
                    <td><?= date('l', $timestamp) ?></td>
                    <td style="font-weight:bold;"><?= e($row['subject_name']) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top: 50px; display: flex; justify-content: space-between;">
        <div style="text-align: center; width: 200px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            Controller of Examinations
        </div>
        <div style="text-align: center; width: 200px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            Principal
        </div>
    </div>
</div>

<script>
    // Include lucide icons for the print button
    if(window.lucide) window.lucide.createIcons();
    
    // Auto-trigger print dialog when page loads
    window.addEventListener('load', function() {
        // setTimeout(() => window.print(), 500);
    });
</script>
