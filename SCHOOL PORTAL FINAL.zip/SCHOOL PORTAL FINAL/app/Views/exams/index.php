<style>
.exam-card {
    background: #fff;
    border-radius: 1rem;
    box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    transition: all 0.3s ease;
    border: 1px solid #f1f5f9;
}
.exam-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    border-color: var(--sp-accent);
}
.exam-header {
    background: #f8fafc;
    border-radius: 1rem 1rem 0 0;
    border-bottom: 2px dashed #e2e8f0;
}
.icon-box {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: var(--sp-light);
    color: var(--sp-accent);
    display: flex;
    align-items: center;
    justify-content: center;
}
.table-hover tbody tr:hover {
    background-color: #f8fafc;
    box-shadow: inset 0 0 0 9999px rgba(0,0,0,0.02);
}
.datalist-input {
    border-radius: 0.75rem;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    transition: all 0.2s;
}
.datalist-input:focus {
    background: #fff;
    border-color: var(--sp-accent);
    box-shadow: 0 0 0 0.25rem rgba(2, 169, 216, 0.15);
}
</style>

<div class="row g-4">
    <!-- Exam List Column -->
    <div class="col-lg-7">
        <div class="card exam-card h-100">
            <div class="card-header exam-header pt-4 pb-3 px-4 d-flex justify-content-between align-items-center">
                <h4 class="mb-0 d-flex align-items-center gap-2 fw-bold" style="color:var(--sp-primary-dark);">
                    <i data-lucide="calendar-days" style="color:var(--sp-accent);"></i> Manage Exams
                </h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light text-muted small text-uppercase" style="letter-spacing:0.5px;">
                            <tr>
                                <th class="py-3 ps-4 fw-medium">Exam Name</th>
                                <th class="py-3 fw-medium">Class</th>
                                <th class="py-3 fw-medium">Status</th>
                                <th class="py-3 pe-4 text-end fw-medium">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($exams)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    <i data-lucide="file-x" style="width:48px;height:48px;opacity:0.3;margin-bottom:1rem;"></i>
                                    <h5>No Exams Found</h5>
                                    <p class="mb-0">Create a new exam to get started.</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($exams as $ex): ?>
                            <tr>
                                <td class="py-3 ps-4">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="icon-box shadow-sm">
                                            <i data-lucide="award" style="width:20px;height:20px;"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark fs-6"><?= e($ex['name']) ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3 fw-bold text-muted">
                                    <?= e($ex['class_name']) ?>
                                </td>
                                <td class="py-3">
                                    <?= statusBadge($ex['status']) ?>
                                </td>
                                <td class="py-3 pe-4 text-end">
                                    <div class="d-flex justify-content-end gap-2">
                                        <!-- Build Timetable Button -->
                                        <a href="<?= e(url('exams/'.$ex['id'].'/timetable')) ?>" class="btn btn-sm btn-primary d-flex align-items-center gap-1 shadow-sm" style="border-radius:0.5rem;" title="Build Timetable">
                                            <i data-lucide="table" style="width:14px;height:14px;"></i> Timetable
                                        </a>
                                        
                                        <!-- Download Button -->
                                        <a href="<?= e(url('exams/'.$ex['id'].'/print-timetable')) ?>" target="_blank" class="btn btn-sm btn-success d-flex align-items-center gap-1 shadow-sm" style="border-radius:0.5rem;" title="Download Timetable">
                                            <i data-lucide="download" style="width:14px;height:14px;"></i> Download
                                        </a>
                                        <?php if (hasPermission('grades.manage')): ?>
                                            <a href="<?= e(url('exams/'.$ex['id'].'/marks')) ?>" class="btn btn-sm btn-info text-white shadow-sm" style="border-radius:0.5rem;" title="Manage Marks">
                                                <i data-lucide="check-square" style="width:14px;height:14px;"></i> Marks
                                            </a>
                                            <a href="<?= e(url('exams/'.$ex['id'].'/subject-analysis')) ?>" class="btn btn-sm btn-outline-primary shadow-sm d-flex align-items-center gap-1" style="border-radius:0.5rem;" title="Subject Performance Analysis">
                                                <i data-lucide="bar-chart-2" style="width:14px;height:14px;"></i> Analysis
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if (hasPermission('exams.manage')): ?>
                                            <form method="post" action="<?= e(url('exams/'.$ex['id'].'/delete')) ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this exam? This will fail if marks have been entered.');">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-sm btn-light text-danger shadow-sm border" style="border-radius:0.5rem;" title="Delete Exam">
                                                    <i data-lucide="trash-2" style="width:14px;height:14px;"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Create Exam Column -->
    <?php if (hasPermission('exams.manage')): ?>
    <div class="col-lg-5">
        <div class="card exam-card h-100">
            <div class="card-header exam-header pt-4 pb-3 px-4 d-flex justify-content-between align-items-center">
                <h4 class="mb-0 d-flex align-items-center gap-2 fw-bold" style="color:var(--sp-primary-dark);">
                    <i data-lucide="plus-circle" style="color:var(--sp-success);"></i> Create Exam
                </h4>
            </div>
            <div class="card-body p-4">
                <form method="post" action="<?= e(url('exams')) ?>">
                    <?= csrf_field() ?>
                    
                    <!-- Exam Name with Datalist -->
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1"><i data-lucide="pen-tool" style="width:14px;height:14px;color:var(--sp-accent);"></i> Exam Name</label>
                        <input list="examNameOptions" name="name" class="form-control form-control-lg fs-6 datalist-input" placeholder="Select or type exam name..." required>
                        <datalist id="examNameOptions">
                            <option value="Grand Test">
                            <option value="Mid Term">
                            <option value="Final Term">
                            <option value="Monthly Test">
                            <option value="Weekly Test">
                            <option value="Mock Exam">
                        </datalist>
                        <small class="text-muted mt-1 d-block"><i data-lucide="info" style="width:12px;height:12px;"></i> You can select from the dropdown or type a custom name.</small>
                    </div>



                    <div class="mb-4">
                        <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1"><i data-lucide="layers" style="width:14px;height:14px;color:var(--sp-primary);"></i> Target Class</label>
                        <select name="class_id" class="form-select form-select-lg fs-6 datalist-input" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="p-3 bg-light rounded-3 mb-4 border d-flex gap-3 align-items-start">
                        <i data-lucide="info" style="color:var(--sp-accent); width:20px; height:20px; margin-top: 2px;"></i>
                        <div>
                            <h6 class="fw-bold mb-1" style="color:var(--sp-primary-dark);">Next Step: Build Timetable</h6>
                            <p class="text-muted small mb-0">After creating this exam, you will be taken to the Timetable Builder to schedule the subjects and dates.</p>
                        </div>
                    </div>

                    <button class="btn btn-primary btn-lg w-100 fw-medium shadow-sm d-flex align-items-center justify-content-center gap-2" style="border-radius:2rem;">
                        <i data-lucide="arrow-right-circle" style="width:20px;height:20px;"></i> Continue to Timetable
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if(window.lucide) window.lucide.createIcons();
});
</script>