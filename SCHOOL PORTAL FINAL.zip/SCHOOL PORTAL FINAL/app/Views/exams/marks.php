<div class="panel">
  <h2>Marks — <?= e($exam['name']) ?></h2>
  <form method="get" class="mb-3">
    <select name="exam_subject_id" class="form-select" onchange="this.form.submit()">
      <?php foreach ($subjects as $s): ?>
        <option value="<?= (int)$s['id'] ?>" <?= $examSubjectId==$s['id']?'selected':'' ?>><?= e($s['subject_name']) ?> (Max <?= e((string)$s['max_marks']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </form>
  <form method="post" action="<?= e(url('exams/'.$exam['id'].'/marks')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="exam_subject_id" value="<?= (int)$examSubjectId ?>">
    <table class="table"><thead><tr><th>Student</th><th>Marks</th><th>Grade</th><th>Report</th></tr></thead><tbody>
    <?php foreach ($students as $st): $sid=(int)$st['id']; $m=$marks[$sid]??null; ?>
      <tr>
        <td><?= e($st['first_name'].' '.$st['last_name']) ?></td>
        <td><input name="marks[<?= $sid ?>]" class="form-control form-control-sm" value="<?= e((string)($m['marks_obtained'] ?? '')) ?>"></td>
        <td><?= e($m['grade'] ?? '—') ?></td>
        <td><a href="<?= e(url('exams/'.$exam['id'].'/report-card/'.$sid)) ?>">Card</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table>
    <button class="btn btn-primary">Save Marks</button>
  </form>
</div>