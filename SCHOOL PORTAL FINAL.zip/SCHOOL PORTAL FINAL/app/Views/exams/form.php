<div class="row g-3">
  <div class="col-lg-6 mx-auto">
    <div class="panel">
      <h2>Edit Exam</h2>
      <form method="post" action="<?= e(url('exams/' . $exam['id'])) ?>">
        <?= csrf_field() ?>
        
        <div class="mb-3">
          <label class="form-label">Exam Name</label>
          <input name="name" class="form-control" value="<?= e($exam['name']) ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Exam Type</label>
          <select name="exam_type_id" class="form-select" required>
            <?php foreach ($types as $t): ?>
              <option value="<?= (int)$t['id'] ?>" <?= $t['id'] == $exam['exam_type_id'] ? 'selected' : '' ?>>
                <?= e($t['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Class</label>
          <select name="class_id" class="form-select" required>
            <?php foreach ($classes as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $exam['class_id'] ? 'selected' : '' ?>>
                <?= e($c['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="row g-2 mb-3">
          <div class="col">
            <label class="form-label">Start Date</label>
            <input type="date" name="start_date" class="form-control" value="<?= e($exam['start_date'] ?? '') ?>">
          </div>
          <div class="col">
            <label class="form-label">End Date</label>
            <input type="date" name="end_date" class="form-control" value="<?= e($exam['end_date'] ?? '') ?>">
          </div>
        </div>

        <div class="mb-4">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="scheduled" <?= $exam['status'] === 'scheduled' ? 'selected' : '' ?>>Scheduled</option>
            <option value="ongoing" <?= $exam['status'] === 'ongoing' ? 'selected' : '' ?>>Ongoing</option>
            <option value="completed" <?= $exam['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
            <option value="published" <?= $exam['status'] === 'published' ? 'selected' : '' ?>>Published</option>
          </select>
        </div>

        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary">Save Changes</button>
          <a href="<?= e(url('exams')) ?>" class="btn btn-secondary">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</div>
