<?php
$title = 'Subject-Wise Performance Analysis';
$exam = $analysis['exam'] ?? [];
$subjects = $analysis['subjects'] ?? [];
$strongest = $analysis['strongest_subject'] ?? null;
$weakest = $analysis['weakest_subject'] ?? null;
$overallPassRate = $analysis['overall_pass_rate'] ?? 0;
$classId = $classId ?? null;
$classes = $classes ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="bar-chart-2" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Academic Intelligence
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Comparative discipline diagnostics, pass rate distribution, and targeted academic intervention tracking for <strong><?= e($exam['name'] ?? 'Exam') ?></strong>.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('exams/' . (int)$exam['id'])) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Back to Exam
    </a>
    <button onclick="window.print()" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Analysis
    </button>
  </div>
</div>

<!-- Class Filter Card -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('exams/' . (int)$exam['id'] . '/subject-analysis')) ?>" class="row g-2 align-items-center">
      <div class="col-md-4">
        <label class="form-label small text-muted mb-0 me-2 fw-semibold">Class Filter:</label>
        <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="">All Assigned Classes</option>
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int) $c['id'] ?>" <?= $classId === (int)$c['id'] ? 'selected' : '' ?>>
              <?= e($c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-8 text-md-end text-muted small">
        Evaluation Standard: Minimum Pass Marks threshold defined per subject curriculum.
      </div>
    </form>
  </div>
</div>

<!-- Overview Metric Tiles -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Overall Pass Rate</div>
          <div class="fs-4 fw-bold <?= $overallPassRate >= 75 ? 'text-success' : 'text-warning' ?>">
            <?= $overallPassRate ?>%
          </div>
          <div class="text-muted" style="font-size: 11px;">Across All Disciplines</div>
        </div>
        <div class="rounded-3 p-2 <?= $overallPassRate >= 75 ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning' ?>">
          <i data-lucide="check-circle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Subjects Evaluated</div>
          <div class="fs-4 fw-bold text-dark"><?= count($subjects) ?></div>
          <div class="text-muted" style="font-size: 11px;">Examination Papers</div>
        </div>
        <div class="rounded-3 p-2 bg-light text-dark border">
          <i data-lucide="book-open" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Highest Performing</div>
          <div class="fs-5 fw-bold text-primary text-truncate" style="max-width: 140px;" title="<?= e($strongest['subject_name'] ?? 'N/A') ?>">
            <?= e($strongest['subject_name'] ?? 'N/A') ?>
          </div>
          <div class="text-muted" style="font-size: 11px;">Avg: <?= $strongest['avg_percentage'] ?? 0 ?>%</div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="award" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Needs Remediation</div>
          <div class="fs-5 fw-bold <?= ($weakest['pass_rate'] ?? 100) < 60 ? 'text-danger' : 'text-dark' ?> text-truncate" style="max-width: 140px;" title="<?= e($weakest['subject_name'] ?? 'N/A') ?>">
            <?= e($weakest['subject_name'] ?? 'N/A') ?>
          </div>
          <div class="text-muted" style="font-size: 11px;">Pass Rate: <?= $weakest['pass_rate'] ?? 0 ?>%</div>
        </div>
        <div class="rounded-3 p-2 <?= ($weakest['pass_rate'] ?? 100) < 60 ? 'bg-danger-subtle text-danger' : 'bg-light text-muted border' ?>">
          <i data-lucide="alert-triangle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Subject Comparative Performance Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
    <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
      <i data-lucide="layers" class="text-primary" style="width: 18px; height: 18px;"></i>
      Subject-Wise Comparative Evaluation &amp; Grade Distributions
    </h5>
    <span class="text-muted small">Sorted by Curriculum Name</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr class="text-muted small text-uppercase" style="font-size: 11px;">
            <th class="ps-3">Discipline / Subject</th>
            <th class="text-center">Evaluated</th>
            <th class="text-center">Class Average</th>
            <th class="text-center">Highest / Lowest</th>
            <th class="text-center">Pass Rate</th>
            <th>Grade Distribution</th>
            <th class="text-end pe-3">Action Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($subjects)): ?>
            <tr>
              <td colspan="7" class="text-center py-5 text-muted small">No subject marks recorded for this examination yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($subjects as $s): ?>
              <tr>
                <td class="ps-3 py-3">
                  <div class="fw-bold text-dark"><?= e($s['subject_name']) ?></div>
                  <div class="text-muted" style="font-size: 11px;">
                    <code><?= e($s['subject_code']) ?></code> &middot; Pass: <?= (float) $s['pass_marks'] ?> / <?= (float) $s['max_marks'] ?>
                  </div>
                </td>
                <td class="text-center">
                  <span class="badge bg-light text-dark border"><?= (int) $s['evaluated_count'] ?></span>
                </td>
                <td class="text-center">
                  <div class="fw-bold text-dark font-monospace"><?= $s['avg_marks'] ?></div>
                  <div class="text-muted" style="font-size: 11px;"><?= $s['avg_percentage'] ?>%</div>
                </td>
                <td class="text-center small">
                  <div><strong class="text-success"><?= $s['highest_marks'] ?></strong> <span class="text-muted" style="font-size: 10px;">(<?= e($s['highest_student']) ?>)</span></div>
                  <div><strong class="text-danger"><?= $s['lowest_marks'] ?></strong> min</div>
                </td>
                <td class="text-center">
                  <div class="fw-bold <?= $s['pass_rate'] >= 75 ? 'text-success' : ($s['pass_rate'] >= 60 ? 'text-warning' : 'text-danger') ?> font-monospace">
                    <?= $s['pass_rate'] ?>%
                  </div>
                  <div class="text-muted" style="font-size: 10px;"><?= (int) $s['pass_count'] ?> / <?= (int) $s['evaluated_count'] ?> Passed</div>
                </td>
                <td>
                  <div class="d-flex gap-1">
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-1.5 py-0.5" style="font-size: 10px;" title="A+ (90%+)"><?= $s['grades']['A+'] ?> A+</span>
                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-1.5 py-0.5" style="font-size: 10px;" title="A (80-89%)"><?= $s['grades']['A'] ?> A</span>
                    <span class="badge bg-info-subtle text-info border border-info-subtle px-1.5 py-0.5" style="font-size: 10px;" title="B (70-79%)"><?= $s['grades']['B'] ?> B</span>
                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-1.5 py-0.5" style="font-size: 10px;" title="C (60-69%)"><?= $s['grades']['C'] ?> C</span>
                    <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-1.5 py-0.5" style="font-size: 10px;" title="D (50-59%)"><?= $s['grades']['D'] ?> D</span>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-1.5 py-0.5" style="font-size: 10px;" title="F (<50%)"><?= $s['grades']['F'] ?> F</span>
                  </div>
                </td>
                <td class="text-end pe-3">
                  <?php
                    $badgeClass = match($s['health_status']) {
                      'Mastery' => 'bg-success-subtle text-success border border-success-subtle',
                      'Needs Intervention' => 'bg-danger-subtle text-danger border border-danger-subtle',
                      default => 'bg-secondary-subtle text-secondary border border-secondary-subtle'
                    };
                  ?>
                  <span class="badge <?= $badgeClass ?> px-2 py-1 rounded-pill small">
                    <?= e($s['health_status']) ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
