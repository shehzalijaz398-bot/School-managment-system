<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= htmlspecialchars($title) ?></h1>
    </div>

    <!-- Filter Form -->
    <div class="card shadow mb-4 border-left-primary">
        <div class="card-body">
            <form method="GET" action="<?= url('exams/analytics') ?>" class="row gx-3 gy-2 align-items-center">
                <div class="col-sm-4">
                    <label class="form-label" for="exam_id">Select Exam</label>
                    <select class="form-select" id="exam_id" name="exam_id" required>
                        <option value="">Choose Exam...</option>
                        <?php foreach($exams as $e): ?>
                            <option value="<?= $e['id'] ?>" <?= $examId == $e['id'] ? 'selected' : '' ?>><?= htmlspecialchars($e['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-sm-4">
                    <label class="form-label" for="class_id">Select Class</label>
                    <select class="form-select" id="class_id" name="class_id" required>
                        <option value="">Choose Class...</option>
                        <?php foreach($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $classId == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-auto align-self-end">
                    <button type="submit" class="btn btn-primary px-4"><i class="bi bi-funnel me-1"></i> Filter Analytics</button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($examId > 0 && $classId > 0): ?>
    
    <!-- Top Level Dashboard Charts -->
    <div class="row">
        <!-- Top Performing Students Chart Area -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Top Performing Students Overview</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                        <canvas id="topStudentsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Subject Pass/Fail Matrix Ratios -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Pass/Fail Matrix Ratios</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="position: relative; height: 280px; width: 100%;">
                        <canvas id="passFailChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center bg-light">
            <h6 class="m-0 font-weight-bold text-primary fs-5">Class Standings & Merit Ledger</h6>
            <form method="POST" action="<?= url('exams/generate-positions') ?>" id="generatePositionsForm">
                <?= csrf_field() ?>
                <input type="hidden" name="exam_id" value="<?= $examId ?>">
                <input type="hidden" name="class_id" value="<?= $classId ?>">
                <button type="button" class="btn btn-success fw-bold px-4" id="generateBtn" onclick="confirmCompute(this)">
                    📊 Compute Class Standings & Merit
                </button>
            </form>
        </div>
        <div class="card-body">
            <?php if (empty($snapshots)): ?>
                <div class="alert alert-info text-center py-4">
                    <i class="bi bi-info-circle-fill fs-3 d-block mb-2"></i>
                    No positions computed yet for this exam and class. Click the "Compute Class Standings & Merit" button to generate the ledger.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="text-center" style="width: 80px;">Rank</th>
                                <th>Admission No</th>
                                <th>Student Name</th>
                                <th>Section</th>
                                <th class="text-end">Total Marks</th>
                                <th class="text-end">Percentage</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $topNames = [];
                            $topScores = [];
                            $passCount = 0;
                            $failCount = 0;
                            
                            foreach ($snapshots as $index => $snap): 
                                // Collect data for charts
                                if ($index < 10) {
                                    $topNames[] = $snap['first_name'];
                                    $topScores[] = (float)$snap['final_percentage'];
                                }
                                if ((float)$snap['final_percentage'] >= 40.0) {
                                    $passCount++;
                                } else {
                                    $failCount++;
                                }
                            ?>
                            <tr>
                                <td class="fw-bold fs-5 text-center text-primary"><?= $snap['class_position'] ?></td>
                                <td><?= htmlspecialchars($snap['admission_no']) ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($snap['first_name'] . ' ' . $snap['last_name']) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($snap['section_name'] ?? 'N/A') ?></span></td>
                                <td class="text-end"><?= $snap['total_obtained_marks'] ?> / <?= $snap['total_max_marks'] ?></td>
                                <td class="text-end">
                                    <div class="d-flex align-items-center justify-content-end">
                                        <span class="me-2"><?= $snap['final_percentage'] ?>%</span>
                                        <div class="progress" style="width: 60px; height: 6px;">
                                            <div class="progress-bar <?= (float)$snap['final_percentage'] >= 40 ? 'bg-success' : 'bg-danger' ?>" role="progressbar" style="width: <?= $snap['final_percentage'] ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <a href="<?= url("exams/report-card/{$snap['student_id']}?exam_id={$examId}") ?>" class="btn btn-sm btn-outline-primary shadow-sm" target="_blank">
                                        <i class="bi bi-file-earmark-pdf"></i> Report Card
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (!empty($snapshots)): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Top 10 Students Chart
        const topNames = <?= json_encode($topNames) ?>;
        const topScores = <?= json_encode($topScores) ?>;

        new Chart(document.getElementById('topStudentsChart'), {
            type: 'bar',
            data: {
                labels: topNames,
                datasets: [{
                    label: 'Final Percentage %',
                    data: topScores,
                    backgroundColor: 'rgba(78, 115, 223, 0.8)',
                    borderColor: 'rgba(78, 115, 223, 1)',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        // Pass Fail Matrix Chart
        const passCount = <?= json_encode($passCount) ?>;
        const failCount = <?= json_encode($failCount) ?>;

        new Chart(document.getElementById('passFailChart'), {
            type: 'doughnut',
            data: {
                labels: ['Passed', 'Failed'],
                datasets: [{
                    data: [passCount, failCount],
                    backgroundColor: ['#1cc88a', '#e74a3b'],
                    hoverBackgroundColor: ['#17a673', '#e02d1b'],
                    hoverBorderColor: "rgba(234, 236, 244, 1)",
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                cutout: '70%',
            }
        });
    });
    </script>
    <?php endif; ?>

    <?php endif; ?>
</div>

<script>
function confirmCompute(btn) {
    if (confirm("Are you sure you want to dynamically re-compute all standings for this class? This operation mathematical loop may take a few moments depending on the array sizes.")) {
        const ogText = btn.innerHTML;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Processing Array...';
        btn.classList.add('disabled');
        btn.setAttribute('disabled', 'disabled');
        
        // Execute the form submission asynchronously through the DOM
        setTimeout(() => {
            document.getElementById('generatePositionsForm').submit();
        }, 100);
    }
}
</script>
