<style>
.builder-card {
    background: #fff;
    border-radius: 1rem;
    box-shadow: 0 4px 15px rgba(0,0,0,0.03);
}
.timetable-row {
    background: #f8fafc;
    border-radius: 0.5rem;
    padding: 1.25rem 1rem;
    margin-bottom: 0.75rem;
    border: 1px solid #e2e8f0;
    transition: all 0.2s ease;
}
.timetable-row:hover {
    border-color: var(--sp-accent);
    box-shadow: 0 4px 10px rgba(0,0,0,0.02);
}
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <div>
        <h2 class="mb-0 d-flex align-items-center gap-2 fw-bold" style="color:var(--sp-primary-dark);">
            <i data-lucide="table" style="color:var(--sp-accent); width:28px; height:28px;"></i> Timetable Builder
        </h2>
        <p class="text-muted small mt-1 mb-0">Exam: <strong class="text-dark"><?= e($exam['name']) ?></strong></p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('exams')) ?>" class="btn btn-light shadow-sm d-flex align-items-center gap-2" style="border-radius:2rem;">
            <i data-lucide="arrow-left" style="width:18px;height:18px;"></i> Back to Exams
        </a>
        <a href="<?= e(url('exams/'.$exam['id'].'/print-timetable')) ?>" target="_blank" class="btn btn-info text-white shadow-sm d-flex align-items-center gap-2" style="border-radius:2rem;">
            <i data-lucide="download" style="width:18px;height:18px;"></i> Download Timetable (PDF)
        </a>
    </div>
</div>

<div class="builder-card p-4">
    <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
        <h5 class="fw-bold mb-0 d-flex align-items-center gap-2">
            <i data-lucide="list-checks" style="width:20px;height:20px;color:var(--sp-primary);"></i> Schedule Subjects
        </h5>
        <span class="badge bg-light text-muted border px-3 py-2">
            <i data-lucide="info" style="width:14px;height:14px;"></i> Leave date blank to skip a subject
        </span>
    </div>

    <form method="post" action="<?= e(url('exams/'.$exam['id'].'/timetable')) ?>">
        <?= csrf_field() ?>
        
        <div id="timetableContainer">
            <?php 
            // Map existing entries by subject_id for easy lookup
            $existingMap = [];
            foreach ($existing as $exm) {
                $existingMap[$exm['subject_id']] = $exm;
            }
            ?>

            <?php if(empty($subjects)): ?>
                <div class="text-center py-5 text-muted">
                    <i data-lucide="folder-minus" style="width:48px;height:48px;opacity:0.3;margin-bottom:1rem;"></i>
                    <h5>No Subjects Assigned</h5>
                    <p>This class does not have any subjects assigned yet. Please assign subjects in the Class settings first.</p>
                </div>
            <?php else: ?>
                <!-- Render a row for every subject assigned to this class -->
                <?php foreach($subjects as $sub): 
                    $isScheduled = isset($existingMap[$sub['id']]);
                    $examDate = $isScheduled ? $existingMap[$sub['id']]['exam_date'] : '';
                    $maxMarks = $isScheduled ? $existingMap[$sub['id']]['max_marks'] : '100';
                    $passMarks = $isScheduled ? $existingMap[$sub['id']]['pass_marks'] : '40';
                ?>
                    <div class="row g-3 timetable-row align-items-center">
                        <div class="col-md-4">
                            <input type="hidden" name="subject_ids[]" value="<?= $sub['id'] ?>">
                            <div class="d-flex align-items-center gap-3">
                                <div class="bg-white border rounded shadow-sm d-flex align-items-center justify-content-center" style="width:40px;height:40px;color:var(--sp-primary);">
                                    <i data-lucide="book" style="width:20px;height:20px;"></i>
                                </div>
                                <h6 class="fw-bold mb-0" style="color:var(--sp-primary-dark);"><?= e($sub['name']) ?></h6>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small text-muted mb-1">Exam Date</label>
                            <input type="date" name="dates[]" class="form-control date-input" value="<?= e($examDate) ?>" min="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php if(!empty($subjects)): ?>
        <div class="mt-4 pt-3 border-top d-flex justify-content-end">
            <button type="submit" class="btn btn-primary btn-lg fw-medium shadow-sm d-flex align-items-center gap-2" style="border-radius:2rem;">
                <i data-lucide="save" style="width:20px;height:20px;"></i> Save Timetable
            </button>
        </div>
        <?php endif; ?>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if(window.lucide) window.lucide.createIcons();
    
    // Prevent selecting duplicate dates
    const dateInputs = document.querySelectorAll('.date-input');
    
    dateInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (!this.value) return; // Allow empty
            
            let isDuplicate = false;
            dateInputs.forEach(otherInput => {
                if (otherInput !== this && otherInput.value === this.value) {
                    isDuplicate = true;
                }
            });
            
            if (isDuplicate) {
                alert('This date has already been assigned to another subject in this exam. Please select a different date.');
                this.value = ''; // Reset the input
            }
        });
    });
});
</script>
