<div class="container-fluid px-3 px-md-4 py-4">
  <!-- Page Header -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
      <div class="d-flex align-items-center gap-2">
        <h1 class="h3 fw-bold text-dark mb-0">Notification Center</h1>
        <?php
          $unreadTotal = 0;
          foreach ($notifications as $notif) {
            if (!$notif['is_read']) $unreadTotal++;
          }
        ?>
        <?php if ($unreadTotal > 0): ?>
          <span class="badge bg-danger rounded-pill px-2 py-1 fs-xs"><?= $unreadTotal ?> Unread</span>
        <?php endif; ?>
      </div>
      <p class="text-muted small mb-0 mt-1">Real-time alerts, attendance notifications, fee updates, and operational announcements.</p>
    </div>

    <div class="d-flex align-items-center gap-2">
      <a href="<?= e(url('notifications/preferences')) ?>" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-1 px-3 py-2 shadow-sm rounded-3">
        <i data-lucide="sliders" style="width: 15px; height: 15px;"></i>
        <span>Preferences</span>
      </a>
      <?php if ($unreadTotal > 0): ?>
        <form method="post" action="<?= e(url('notifications/read-all')) ?>" class="m-0">
          <?= csrf_field() ?>
          <button type="submit" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-2 px-3 py-2 shadow-sm rounded-3">
            <i data-lucide="check-check" style="width: 15px; height: 15px;"></i>
            <span>Mark All as Read</span>
          </button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <!-- Notification Filters & List -->
  <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <!-- Filter Tabs Header -->
    <div class="card-header bg-white border-bottom border-light px-4 py-3 d-flex flex-wrap gap-2 align-items-center justify-content-between">
      <div class="d-flex flex-wrap gap-2" id="notifFilterTabs">
        <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1 notif-filter-btn active" data-filter="all">All (<?= count($notifications) ?>)</button>
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 py-1 notif-filter-btn" data-filter="unread">Unread (<?= $unreadTotal ?>)</button>
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 py-1 notif-filter-btn" data-filter="attendance">Attendance</button>
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 py-1 notif-filter-btn" data-filter="fee">Finance & Fees</button>
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 py-1 notif-filter-btn" data-filter="academic">Academics</button>
      </div>
    </div>

    <!-- Notifications Body -->
    <div class="card-body p-0">
      <?php if (empty($notifications)): ?>
        <div class="text-center py-5 px-3">
          <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-light mb-3" style="width: 64px; height: 64px;">
            <i data-lucide="bell-off" class="text-muted" style="width: 32px; height: 32px;"></i>
          </div>
          <h5 class="fw-bold text-dark mb-1">No notifications yet</h5>
          <p class="text-muted small mb-0">You're completely caught up. When important activities occur, they will appear here.</p>
        </div>
      <?php else: ?>
        <div class="list-group list-group-flush" id="notificationListGroup">
          <?php foreach ($notifications as $n): ?>
            <?php
              $isRead = (bool)$n['is_read'];
              $type = strtolower((string)($n['type'] ?? 'general'));
              $category = 'general';
              $iconName = 'bell';
              $iconColor = '#4f46e5';
              $iconBg = '#eef2ff';

              if (str_contains($type, 'attendance')) {
                $category = 'attendance';
                $iconName = 'calendar-check';
                $iconColor = '#e11d48';
                $iconBg = '#ffe4e6';
              } elseif (str_contains($type, 'fee') || str_contains($type, 'invoice') || str_contains($type, 'payment')) {
                $category = 'fee';
                $iconName = 'credit-card';
                $iconColor = '#059669';
                $iconBg = '#d1fae5';
              } elseif (str_contains($type, 'exam') || str_contains($type, 'grade') || str_contains($type, 'academic')) {
                $category = 'academic';
                $iconName = 'award';
                $iconColor = '#d97706';
                $iconBg = '#fef3c7';
              } elseif (str_contains($type, 'admission')) {
                $category = 'admission';
                $iconName = 'user-plus';
                $iconColor = '#2563eb';
                $iconBg = '#dbeafe';
              }
            ?>
            <div class="list-group-item p-3 p-md-4 notif-item <?= $isRead ? 'opacity-75' : 'bg-light bg-opacity-50' ?>" 
                 data-category="<?= e($category) ?>" 
                 data-read="<?= $isRead ? '1' : '0' ?>"
                 id="notif-row-<?= (int)$n['id'] ?>">
              <div class="d-flex align-items-start gap-3">
                <!-- Category Icon -->
                <div class="flex-shrink-0 rounded-circle d-flex align-items-center justify-content-center shadow-xs" 
                     style="width: 44px; height: 44px; background: <?= $iconBg ?>; color: <?= $iconColor ?>;">
                  <i data-lucide="<?= e($iconName) ?>" style="width: 20px; height: 20px;"></i>
                </div>

                <!-- Text Content -->
                <div class="flex-grow-1 min-w-0">
                  <div class="d-flex flex-wrap justify-content-between align-items-baseline gap-2 mb-1">
                    <h6 class="mb-0 fw-bold <?= $isRead ? 'text-dark' : 'text-primary' ?> fs-sm d-flex align-items-center gap-2">
                      <?= e($n['title']) ?>
                      <?php if (!$isRead): ?>
                        <span class="badge bg-primary rounded-pill px-2 py-0" style="font-size: 10px;">New</span>
                      <?php endif; ?>
                    </h6>
                    <span class="text-muted fs-xs text-nowrap"><?= e(date('M d, Y · h:i A', strtotime($n['created_at']))) ?></span>
                  </div>

                  <p class="text-secondary small mb-2 text-break" style="line-height: 1.5;"><?= e($n['message']) ?></p>

                  <!-- Action Links -->
                  <div class="d-flex flex-wrap align-items-center gap-3 mt-1">
                    <?php if (!empty($n['link'])): ?>
                      <a href="<?= e(url($n['link'])) ?>" class="btn btn-sm btn-link p-0 text-decoration-none fw-semibold fs-xs d-inline-flex align-items-center gap-1">
                        <span>View Details</span>
                        <i data-lucide="arrow-right" style="width: 13px; height: 13px;"></i>
                      </a>
                    <?php endif; ?>

                    <?php if (!$isRead): ?>
                      <form method="post" action="<?= e(url('notifications/' . $n['id'] . '/read')) ?>" class="d-inline m-0">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-link text-muted p-0 text-decoration-none fs-xs d-inline-flex align-items-center gap-1">
                          <i data-lucide="check" style="width: 13px; height: 13px;"></i>
                          <span>Mark as read</span>
                        </button>
                      </form>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const filterBtns = document.querySelectorAll('.notif-filter-btn');
  const items = document.querySelectorAll('.notif-item');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', function () {
      filterBtns.forEach(b => {
        b.classList.remove('btn-primary', 'active');
        b.classList.add('btn-light');
      });
      this.classList.add('btn-primary', 'active');
      this.classList.remove('btn-light');

      const filter = this.getAttribute('data-filter');
      items.forEach(item => {
        if (filter === 'all') {
          item.style.display = '';
        } else if (filter === 'unread') {
          item.style.display = item.getAttribute('data-read') === '0' ? '' : 'none';
        } else {
          item.style.display = item.getAttribute('data-category') === filter ? '' : 'none';
        }
      });
    });
  });
});
</script>
