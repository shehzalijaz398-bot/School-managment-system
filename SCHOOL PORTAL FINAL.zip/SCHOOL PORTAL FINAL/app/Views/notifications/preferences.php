<?php
$title = 'Notification Preferences';
$prefs = $preferences ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="bell-ring" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        User Control
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Configure which institutional updates, reminders, and escalation notices you receive.
    </p>
  </div>
  <div>
    <a href="<?= e(url('notifications')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="inbox" style="width: 14px; height: 14px;"></i> Back to Notifications
    </a>
  </div>
</div>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <form method="POST" action="<?= e(url('notifications/preferences')) ?>">
      <?= csrf_field() ?>

      <!-- Category Preferences Card -->
      <div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
        <div class="card-header bg-white border-bottom py-3">
          <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2 text-dark">
            <i data-lucide="layers" class="text-primary" style="width: 18px; height: 18px;"></i>
            Notification Topics & Triggers
          </h5>
          <div class="text-muted small">Choose the specific events you want to be alerted on</div>
        </div>
        <div class="card-body p-4">
          <div class="d-flex flex-column gap-3">

            <!-- Attendance -->
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark d-flex align-items-center gap-2">
                  <i data-lucide="user-x" class="text-warning" style="width: 18px; height: 18px;"></i>
                  Attendance & Absence Alerts
                </div>
                <div class="text-muted small">
                  Immediate alerts when student absences, late arrivals, or consecutive absence milestones occur.
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="notify_attendance" value="1" id="notifyAttendance" <?= !empty($prefs['notify_attendance']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

            <!-- Finance -->
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark d-flex align-items-center gap-2">
                  <i data-lucide="credit-card" class="text-success" style="width: 18px; height: 18px;"></i>
                  Fee Invoices & Billing Reminders
                </div>
                <div class="text-muted small">
                  New fee generation notices, overdue balance reminders, and payment confirmation receipts.
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="notify_finance" value="1" id="notifyFinance" <?= !empty($prefs['notify_finance']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

            <!-- Academics -->
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark d-flex align-items-center gap-2">
                  <i data-lucide="graduation-cap" class="text-primary" style="width: 18px; height: 18px;"></i>
                  Academic Performance & Exam Reports
                </div>
                <div class="text-muted small">
                  Exam schedule announcements, grade publishing alerts, and downloadable report card ready notices.
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="notify_academics" value="1" id="notifyAcademics" <?= !empty($prefs['notify_academics']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

            <!-- Workflows -->
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark d-flex align-items-center gap-2">
                  <i data-lucide="git-pull-request" class="text-info" style="width: 18px; height: 18px;"></i>
                  Approval Workflows & Leave Reviews
                </div>
                <div class="text-muted small">
                  Decisions on submitted leave applications, document verifications, and institutional task reviews.
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="notify_workflows" value="1" id="notifyWorkflows" <?= !empty($prefs['notify_workflows']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

            <!-- Announcements -->
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark d-flex align-items-center gap-2">
                  <i data-lucide="megaphone" class="text-secondary" style="width: 18px; height: 18px;"></i>
                  General School Broadcasts
                </div>
                <div class="text-muted small">
                  Institutional circulars, calendar holiday events, emergency notices, and townhall invites.
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="notify_announcements" value="1" id="notifyAnnouncements" <?= !empty($prefs['notify_announcements']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- Delivery Channels Card -->
      <div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
        <div class="card-header bg-white border-bottom py-3">
          <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2 text-dark">
            <i data-lucide="send" class="text-primary" style="width: 18px; height: 18px;"></i>
            Delivery Channels
          </h5>
          <div class="text-muted small">Select your preferred transmission mediums</div>
        </div>
        <div class="card-body p-4">
          <div class="d-flex flex-column gap-3">
            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark">In-App Notification Center</div>
                <div class="text-muted small">Live bell icon badges, audio-visual toast pings, and notification inbox center.</div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="channel_inapp" value="1" id="channelInapp" <?= !empty($prefs['channel_inapp']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>

            <div class="d-flex align-items-center justify-content-between p-3 rounded-3 border bg-light-subtle">
              <div class="me-3">
                <div class="fw-bold text-dark">Email Dispatch</div>
                <div class="text-muted small">Instant transactional email digests sent directly to your registered user address.</div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="channel_email" value="1" id="channelEmail" <?= !empty($prefs['channel_email']) ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer bg-white border-top p-3 d-flex justify-content-end">
          <button type="submit" class="btn btn-primary d-flex align-items-center gap-2 px-4 py-2 fw-semibold">
            <i data-lucide="save" style="width: 16px; height: 16px;"></i> Save Preferences
          </button>
        </div>
      </div>
    </form>
  </div>
</div>
