<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-bell-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
        <button class="btn btn-sm btn-outline-secondary shadow-sm fw-bold" onclick="markAllNotificationsRead()">
            <i class="bi bi-check2-all me-1"></i> Mark All as Read
        </button>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card shadow border-0">
                <div class="card-header py-3 bg-white border-bottom border-secondary border-opacity-25 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-dark"><i class="bi bi-collection-fill me-2"></i> Unified Operations Inbox</h6>
                </div>
                <div class="card-body bg-light p-0">
                    <div class="list-group list-group-flush" id="notificationCenterList">
                        <?php foreach($notifications as $notif): ?>
                            <?php 
                                $borderClass = '';
                                $iconClass = 'bi-info-circle text-primary';
                                $bgClass = $notif['is_read'] ? 'bg-white' : 'bg-primary bg-opacity-10';
                                
                                switch($notif['priority']) {
                                    case 'critical':
                                        $borderClass = 'border-start border-danger border-4';
                                        $iconClass = 'bi-exclamation-triangle-fill text-danger pulse-danger';
                                        break;
                                    case 'high':
                                        $borderClass = 'border-start border-warning border-4';
                                        $iconClass = 'bi-exclamation-circle-fill text-warning';
                                        break;
                                    case 'medium':
                                        $borderClass = 'border-start border-info border-4';
                                        $iconClass = 'bi-bell-fill text-info';
                                        break;
                                    default:
                                        $borderClass = 'border-start border-secondary border-4';
                                        $iconClass = 'bi-bell text-secondary';
                                }
                            ?>
                            <div class="list-group-item list-group-item-action <?= $bgClass ?> <?= $borderClass ?> p-3" id="notifRow_<?= $notif['id'] ?>">
                                <div class="d-flex w-100 justify-content-between align-items-center">
                                    <div class="d-flex align-items-center">
                                        <i class="bi fs-4 me-3 <?= $iconClass ?>"></i>
                                        <div>
                                            <h6 class="mb-1 fw-bold text-dark"><?= htmlspecialchars($notif['title']) ?></h6>
                                            <p class="mb-1 small text-muted"><?= htmlspecialchars($notif['context_message']) ?></p>
                                        </div>
                                    </div>
                                    <div class="text-end">
                                        <small class="text-muted fw-bold d-block mb-2"><?= date('M d, H:i', strtotime($notif['created_at'])) ?></small>
                                        <?php if(!$notif['is_read']): ?>
                                            <button class="btn btn-xs btn-outline-success border-0 px-2 fw-bold" onclick="markNotificationRead(<?= $notif['id'] ?>)">
                                                <i class="bi bi-check-lg"></i> Clear
                                            </button>
                                        <?php endif; ?>
                                        <?php if($notif['action_url']): ?>
                                            <a href="<?= htmlspecialchars($notif['action_url']) ?>" class="btn btn-xs btn-primary fw-bold px-2 ms-1">View Details</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if(empty($notifications)): ?>
                            <div class="text-center py-5">
                                <i class="bi bi-envelope-check text-success fs-1 d-block mb-3"></i>
                                <span class="text-muted fw-bold">Inbox is completely clear.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .pulse-danger {
        animation: pulse-danger-anim 1.5s infinite;
    }
    @keyframes pulse-danger-anim {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }
</style>

<script>
    function markNotificationRead(id) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('csrf_token', '<?= csrf_token() ?>');
        
        fetch('<?= url("notifications/mark-read") ?>', {
            method: 'POST',
            body: formData
        }).then(res => res.json()).then(data => {
            if(data.status === 'success') {
                const row = document.getElementById('notifRow_' + id);
                if (row) {
                    row.classList.remove('bg-primary', 'bg-opacity-10');
                    row.classList.add('bg-white');
                    row.querySelector('.btn-outline-success')?.remove();
                }
            }
        });
    }

    function markAllNotificationsRead() {
        const formData = new FormData();
        formData.append('id', 'all');
        formData.append('csrf_token', '<?= csrf_token() ?>');
        
        fetch('<?= url("notifications/mark-read") ?>', {
            method: 'POST',
            body: formData
        }).then(res => res.json()).then(data => {
            if(data.status === 'success') {
                window.location.reload();
            }
        });
    }
</script>
