<?php
/**
 * CodeClove School Management Pro — Admit New Student Form
 * Pixel-perfect match to official CodeClove Admit Student workflow
 */
$s = $student ?? null;
$p = $current_parent ?? [];
$isEdit = !empty($s);
?>

<style>
.cc-admit-container {
  max-width: 980px;
  margin: 0 auto;
}
.cc-admit-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem 1.75rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
  margin-bottom: 1.5rem;
  transition: border-color 0.15s ease;
}
.cc-admit-card:hover {
  border-color: #cbd5e1;
}
.cc-form-section-title {
  font-size: 0.76rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 1.25rem;
  display: flex;
  align-items: center;
  gap: 0.4rem;
}
.cc-form-label {
  font-size: 0.82rem;
  font-weight: 600;
  color: #334155;
  margin-bottom: 0.35rem;
  display: block;
}
.cc-form-label .req {
  color: #dc2626;
  font-weight: 700;
}
.cc-input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.5rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
}
.cc-input:focus {
  border-color: #4f46e5;
  outline: none;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.cc-input::placeholder {
  color: #94a3b8;
  font-size: 0.84rem;
}
.country-picker-wrap {
  position: relative;
}
.country-picker-btn {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.5rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: space-between;
  text-align: left;
}
.country-picker-btn:hover {
  border-color: #cbd5e1;
}
.country-picker-btn:focus, .country-picker-wrap.open .country-picker-btn {
  border-color: #4f46e5;
  outline: none;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.country-dropdown-panel {
  display: none;
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.15), 0 8px 10px -6px rgba(15, 23, 42, 0.1);
  z-index: 1060;
  overflow: hidden;
  min-width: 250px;
}
.country-picker-wrap.open .country-dropdown-panel {
  display: block;
}
.country-search-box {
  height: 34px;
  border-radius: 6px;
  border: 1px solid #cbd5e1;
  font-size: 13px;
  padding-left: 32px;
}
.country-search-box:focus {
  border-color: #4f46e5;
  box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.12);
  outline: none;
}
.country-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  font-size: 13.5px;
  color: #1e293b;
  cursor: pointer;
  transition: background-color 0.1s ease;
  user-select: none;
}
.country-item:hover, .country-item.highlighted {
  background-color: #f8fafc;
}
.country-item.selected {
  background-color: #eef2ff;
  color: #4f46e5;
  font-weight: 600;
}
.country-flag-img {
  width: 20px;
  height: 14px;
  object-fit: cover;
  border-radius: 2px;
  box-shadow: 0 0 1px rgba(0,0,0,0.3);
  flex-shrink: 0;
  margin-right: 8px;
}
.cc-input-group {
  position: relative;
}
.cc-input-icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #94a3b8;
  pointer-events: none;
}
.cc-photo-upload-box {
  width: 96px;
  height: 96px;
  border-radius: 12px;
  border: 1px dashed #cbd5e1;
  background-color: #f8fafc;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  overflow: hidden;
  position: relative;
}
.cc-photo-upload-box:hover {
  border-color: #4f46e5;
  background-color: #f5f3ff;
}
.cc-photo-upload-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.cc-id-preview-box {
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 0.75rem 1rem;
}
.cc-id-pill {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 0.25rem 0.65rem;
  font-size: 0.82rem;
  font-weight: 700;
  font-family: monospace;
  color: #0f172a;
}
.cc-subject-empty {
  background-color: #f8fafc;
  border: 1px dashed #e2e8f0;
  border-radius: 10px;
  padding: 1.5rem;
  text-align: center;
  color: #64748b;
  font-size: 0.86rem;
}
.cc-subheading {
  font-size: 0.88rem;
  font-weight: 700;
  color: #1e293b;
  margin-top: 1rem;
  margin-bottom: 0.85rem;
  padding-bottom: 0.4rem;
  border-bottom: 1px solid #f1f5f9;
}
.cc-btn-cancel {
  border: 1px solid #e2e8f0;
  background: #ffffff;
  color: #475569;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.25rem;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.cc-btn-cancel:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-btn-submit {
  background: #4f46e5;
  border: 1px solid #4f46e5;
  color: #ffffff;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.5rem;
  border-radius: 8px;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(79, 70, 229, 0.2);
}
.cc-btn-submit:hover {
  background: #4338ca;
  border-color: #4338ca;
}
</style>

<div class="cc-admit-container mb-5">

  <!-- 1. Breadcrumbs -->
  <nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item"><a href="<?= e(url('students')) ?>" class="text-muted text-decoration-none">Students</a></li>
      <li class="breadcrumb-item"><a href="<?= e(url('students')) ?>" class="text-muted text-decoration-none">Directory</a></li>
      <li class="breadcrumb-item active text-dark fw-medium" aria-current="page"><?= $isEdit ? 'Edit Student' : 'Admit Student' ?></li>
    </ol>
  </nav>

  <!-- 2. Page Header -->
  <div class="mb-4">
    <h1 class="h3 fw-bold text-dark mb-1 d-flex align-items-center gap-2" style="letter-spacing: -0.02em;">
      <span class="d-inline-flex align-items-center justify-content-center text-white" style="width: 24px; height: 24px; border-radius: 6px; background-color: #4f46e5; font-size: 14px;">+</span>
      <span><?= e($title ?? ($isEdit ? 'Edit Student' : 'Admit New Student')) ?></span>
    </h1>
    <p class="text-muted small mb-0"><?= $isEdit ? 'Update student information and record details.' : 'Manually register and place a new student record.' ?></p>
  </div>

  <form method="post" enctype="multipart/form-data" action="<?= e($isEdit ? url('students/' . $s['id']) : url('students')) ?>" id="admitStudentForm">
    <?= csrf_field() ?>

    <!-- ==========================================
         CARD 1: 1. STUDENT & ACADEMIC DETAILS
         ========================================== -->
    <div class="cc-admit-card">
      <div class="cc-form-section-title"><i data-lucide="user" style="width: 15px; height: 15px; color: #4f46e5;"></i> 1. STUDENT & ACADEMIC DETAILS</div>

      <!-- Student Photo Upload Block -->
      <div class="d-flex align-items-center gap-3 mb-4">
        <div class="cc-photo-upload-box" onclick="document.getElementById('profileImageInput').click();" title="Click to upload student photo">
          <div id="photoPlaceholder" class="text-center">
            <i data-lucide="user" style="width: 28px; height: 28px; color: #94a3b8;"></i>
          </div>
          <img id="photoPreview" src="<?= !empty($s['profile_image']) ? e(asset('uploads/profiles/' . $s['profile_image'])) : '' ?>" style="<?= empty($s['profile_image']) ? 'display:none;' : '' ?>">
        </div>
        <div>
          <div class="cc-form-label mb-1">Student Photo</div>
          <button type="button" class="btn btn-sm btn-link text-decoration-none p-0 text-brand fw-semibold" style="color: #4f46e5; font-size: 13px;" onclick="document.getElementById('profileImageInput').click();">
            Upload Photo
          </button>
          <input type="file" name="profile_image" id="profileImageInput" accept="image/*" style="display:none;" onchange="previewStudentPhoto(this)">
          <div class="text-muted" style="font-size: 11px;">PNG or JPG up to 2MB recommended</div>
        </div>
      </div>

      <!-- Names Row (3 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-4">
          <label class="cc-form-label">First Name <span class="req">*</span></label>
          <input type="text" name="first_name" id="firstNameInput" class="cc-input" required value="<?= e($s['first_name'] ?? old('first_name')) ?>" placeholder="e.g. Alice">
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Middle Name</label>
          <input type="text" name="middle_name" class="cc-input" value="<?= e($s['middle_name'] ?? old('middle_name')) ?>" placeholder="e.g. Marie">
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Last Name <span class="req">*</span></label>
          <input type="text" name="last_name" class="cc-input" required value="<?= e($s['last_name'] ?? old('last_name')) ?>" placeholder="e.g. Smith">
        </div>
      </div>

      <!-- DOB, Gender & Admission Date Row (3 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Date of Birth <span class="req">*</span></label>
          <div class="cc-input-group">
            <input type="date" name="date_of_birth" class="cc-input" required value="<?= e($s['date_of_birth'] ?? old('date_of_birth')) ?>" placeholder="DD/MM/YYYY">
            <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Gender <span class="req">*</span></label>
          <select name="gender" class="cc-input form-select" required>
            <option value="">Select Gender</option>
            <option value="male" <?= (($s['gender'] ?? old('gender')) === 'male') ? 'selected' : '' ?>>Male</option>
            <option value="female" <?= (($s['gender'] ?? old('gender')) === 'female') ? 'selected' : '' ?>>Female</option>
            <option value="other" <?= (($s['gender'] ?? old('gender')) === 'other') ? 'selected' : '' ?>>Other</option>
          </select>
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Admission Date <span class="req">*</span></label>
          <div class="cc-input-group">
            <input type="date" name="admission_date" class="cc-input" required value="<?= e($s['admission_date'] ?? date('Y-m-d')) ?>">
            <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
      </div>

      <!-- Class, Section, Graduation Year & Status Row (4 cols) -->
      <div class="row g-3 mb-4">
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Class <span class="req">*</span></label>
          <select name="class_id" id="classSelect" class="cc-input form-select" required onchange="handleClassChange(this)">
            <option value="">Select class...</option>
            <?php foreach (($classes ?? []) as $c): ?>
              <option value="<?= (int)$c['id'] ?>" data-sections='<?= e(json_encode($c['sections'] ?? [])) ?>' <?= ((int)($s['class_id'] ?? old('class_id')) === (int)$c['id']) ? 'selected' : '' ?>>
                <?= e($c['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Section</label>
          <select name="section_id" id="sectionSelect" class="cc-input form-select">
            <option value="">Select section...</option>
            <?php if (!empty($sections)): ?>
              <?php foreach ($sections as $sec): ?>
                <option value="<?= (int)$sec['id'] ?>" <?= ((int)($s['section_id'] ?? old('section_id')) === (int)$sec['id']) ? 'selected' : '' ?>><?= e($sec['name']) ?></option>
              <?php endforeach; ?>
            <?php endif; ?>
          </select>
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Graduation Year</label>
          <div class="cc-input-group">
            <input type="number" name="graduation_year" class="cc-input" value="<?= e($s['graduation_year'] ?? (date('Y') + 4)) ?>" placeholder="e.g. 2030">
            <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Status <span class="req">*</span></label>
          <select name="status" class="cc-input form-select" required>
            <option value="active" <?= (($s['status'] ?? old('status', 'active')) === 'active') ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= (($s['status'] ?? old('status')) === 'inactive') ? 'selected' : '' ?>>Inactive</option>
            <option value="graduated" <?= (($s['status'] ?? old('status')) === 'graduated') ? 'selected' : '' ?>>Graduated</option>
            <option value="transferred" <?= (($s['status'] ?? old('status')) === 'transferred') ? 'selected' : '' ?>>Transferred</option>
            <option value="suspended" <?= (($s['status'] ?? old('status')) === 'suspended') ? 'selected' : '' ?>>Suspended</option>
            <option value="withdrawn" <?= (($s['status'] ?? old('status')) === 'withdrawn') ? 'selected' : '' ?>>Withdrawn</option>
          </select>
        </div>
      </div>

      <!-- Student Portal Login Account Sub-Card -->
      <div class="cc-inner-card mb-4" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 1.15rem 1.25rem;">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="key-round" style="width: 17px; height: 17px; color: #4f46e5;"></i>
            <span class="fw-bold text-dark" style="font-size: 13.5px;">Student Portal Login Access</span>
          </div>
          <div class="form-check form-switch mb-0">
            <input class="form-check-input" type="checkbox" name="create_student_portal_account" id="createStudentPortalAccount" value="1" checked onchange="toggleStudentPortalFields(this)">
            <label class="form-check-label small fw-semibold text-secondary" for="createStudentPortalAccount">Enable Portal</label>
          </div>
        </div>
        <div class="text-muted small mb-3" style="font-size: 11.5px;">
          Enable this to auto-generate a Student Portal account so the student can access their timetable, attendance, finances, and exams.
        </div>
        <div id="studentPortalFieldsWrap" class="row g-3">
          <div class="col-12 col-md-6">
            <label class="cc-form-label">Student Portal Email <span class="req">*</span></label>
            <div class="input-group">
              <span class="input-group-text bg-white border-end-0" style="border-color: #e2e8f0;"><i data-lucide="mail" style="width: 15px; height: 15px; color: #94a3b8;"></i></span>
              <input type="email" name="email" id="studentEmailInput" class="cc-input border-start-0" value="<?= e($s['email'] ?? old('email')) ?>" placeholder="e.g. student@school.edu">
            </div>
          </div>
          <div class="col-12 col-md-6">
            <label class="cc-form-label">Student Portal Password</label>
            <div class="input-group">
              <span class="input-group-text bg-white border-end-0" style="border-color: #e2e8f0;"><i data-lucide="lock" style="width: 15px; height: 15px; color: #94a3b8;"></i></span>
              <input type="text" name="student_password" id="studentPasswordInput" class="cc-input border-start-0" value="Password@123" placeholder="Password@123">
              <button type="button" class="btn btn-outline-primary px-3 fw-medium" onclick="generateStudentPassword()" style="border-color: #cbd5e1; font-size: 12px;">
                <i data-lucide="refresh-cw" style="width: 13px; height: 13px;"></i> Generate
              </button>
            </div>
            <div class="text-muted mt-1" style="font-size: 10.5px;">Default: <code>Password@123</code>. You can change or generate a random one.</div>
          </div>
        </div>
      </div>

      <!-- Auto-generate Admission ID & Identifiers Preview -->
      <div class="row g-3 align-items-center pt-2 border-top">
        <div class="col-12 col-md-6">
          <div class="form-check mb-1">
            <input class="form-check-input" type="checkbox" name="auto_generate_id" id="autoGenerateId" value="1" checked onchange="toggleAutoGenerateId(this)">
            <label class="form-check-label fw-semibold text-dark" for="autoGenerateId" style="font-size: 13px;">
              Auto-generate Admission ID
            </label>
          </div>
          <div class="text-muted" style="font-size: 12px; margin-left: 1.5rem;">
            Sequential ID based on preset templates
          </div>
          <div id="manualAdmissionWrap" style="display:none;" class="mt-2">
            <input type="text" name="admission_no" id="manualAdmissionInput" class="cc-input" placeholder="e.g. ADM20260301" value="<?= e($nextAdmissionNo ?? '') ?>">
          </div>
        </div>
        <div class="col-12 col-md-6">
          <div class="cc-id-preview-box">
            <div class="d-flex align-items-center justify-content-between mb-1">
              <span style="font-size: 10px; font-weight: 700; color: #64748b; letter-spacing: 0.05em; text-transform: uppercase;">IDENTIFIERS PREVIEW</span>
            </div>
            <div class="d-flex align-items-center gap-3">
              <div>
                <span class="text-muted d-block" style="font-size: 10px;">Auto Student ID</span>
                <span class="cc-id-pill" id="previewStudentId"><?= e($nextStudentId ?? 'STU20260301') ?></span>
              </div>
              <div>
                <span class="text-muted d-block" style="font-size: 10px;">Admission ID</span>
                <span class="cc-id-pill" id="previewAdmissionId"><?= e($nextAdmissionPreview ?? 'ADM20260301') ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- ==========================================
         CARD 2: 2. ADDRESS DETAILS
         ========================================== -->
    <div class="cc-admit-card">
      <div class="cc-form-section-title"><i data-lucide="map-pin" style="width: 15px; height: 15px; color: #4f46e5;"></i> 2. ADDRESS DETAILS</div>

      <div class="mb-3">
        <label class="cc-form-label">Street Address</label>
        <input type="text" name="street_address" class="cc-input" value="<?= e($s['street_address'] ?? ($s['address'] ?? old('street_address'))) ?>" placeholder="e.g. 123 Main St, Apt 4B">
      </div>

      <div class="row g-3">
        <div class="col-12 col-md-3">
          <label class="cc-form-label">City</label>
          <input type="text" name="city" class="cc-input" value="<?= e($s['city'] ?? old('city')) ?>" placeholder="e.g. Springfield">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">State / Province</label>
          <input type="text" name="state" class="cc-input" value="<?= e($s['state'] ?? old('state')) ?>" placeholder="e.g. Illinois">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">ZIP / Postal Code</label>
          <input type="text" name="zip" class="cc-input" value="<?= e($s['zip'] ?? old('zip')) ?>" placeholder="e.g. 62701">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Country</label>
          <div class="country-picker-wrap" id="countryPickerWrap">
            <input type="hidden" name="country" id="countryInputHidden" value="<?= e($s['country'] ?? old('country', 'United States')) ?>">
            
            <button type="button" class="country-picker-btn" id="countryPickerBtn" aria-haspopup="listbox" aria-expanded="false">
              <span class="d-flex align-items-center gap-2 text-truncate" id="countrySelectedDisplay">
                <span class="text-muted">Select country...</span>
              </span>
              <i data-lucide="chevron-down" id="countryChevron" class="text-muted flex-shrink-0 ms-1" style="width: 15px; height: 15px; transition: transform 0.2s;"></i>
            </button>

            <div class="country-dropdown-panel" id="countryDropdownPanel">
              <div class="p-2 border-bottom bg-light">
                <div class="position-relative">
                  <input type="text" id="countrySearchBox" class="form-control form-control-sm country-search-box" placeholder="Search country..." autocomplete="off">
                  <i data-lucide="search" class="position-absolute text-muted" style="left: 10px; top: 50%; transform: translateY(-50%); width: 14px; height: 14px; pointer-events: none;"></i>
                </div>
              </div>
              <div class="country-items-container" id="countryItemsContainer" style="max-height: 220px; overflow-y: auto;">
                <!-- Dynamically populated -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 3: 3. COURSE ELECTIVES & SUBJECTS
         ========================================== -->
    <div class="cc-admit-card">
      <div class="cc-form-section-title"><i data-lucide="book-open" style="width: 15px; height: 15px; color: #4f46e5;"></i> 3. COURSE ELECTIVES & SUBJECTS</div>
      <div id="subjectsContainer">
        <div class="cc-subject-empty" id="subjectsEmptyNotice">
          Please select a class to load available subjects
        </div>
        <div id="subjectsListWrap" style="display:none;" class="row g-2"></div>
      </div>
    </div>

    <!-- ==========================================
         CARD 4: 4. FAMILY & GUARDIANS
         ========================================== -->
    <div class="cc-admit-card">
      <div class="cc-form-section-title"><i data-lucide="users" style="width: 15px; height: 15px; color: #4f46e5;"></i> 4. FAMILY & GUARDIANS</div>

      <!-- Subsection: Father's Details -->
      <div class="cc-subheading">Father's Details (Optional)</div>
      <div class="row g-3 mb-2">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">First Name</label>
          <input type="text" name="father_first_name" class="cc-input" placeholder="e.g. John">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Last Name</label>
          <input type="text" name="father_last_name" class="cc-input" placeholder="e.g. Smith">
        </div>
      </div>
      <div class="row g-3 mb-2">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Phone Number</label>
          <input type="text" name="father_phone" class="cc-input" placeholder="e.g. +1 (555) 019-8765">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Email Address</label>
          <input type="email" name="father_email" class="cc-input" placeholder="e.g. johnsmith@gmail.com">
        </div>
      </div>
      <div class="mb-4">
        <label class="cc-form-label">Occupation</label>
        <input type="text" name="father_occupation" class="cc-input" placeholder="e.g. Software Engineer">
      </div>

      <!-- Subsection: Mother's Details -->
      <div class="cc-subheading">Mother's Details (Optional)</div>
      <div class="row g-3 mb-2">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">First Name</label>
          <input type="text" name="mother_first_name" class="cc-input" placeholder="e.g. Jane">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Last Name</label>
          <input type="text" name="mother_last_name" class="cc-input" placeholder="e.g. Smith">
        </div>
      </div>
      <div class="row g-3 mb-2">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Phone Number</label>
          <input type="text" name="mother_phone" class="cc-input" placeholder="e.g. +1 (555) 019-8766">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Email Address</label>
          <input type="email" name="mother_email" class="cc-input" placeholder="e.g. janesmith@gmail.com">
        </div>
      </div>
      <div class="mb-4">
        <label class="cc-form-label">Occupation</label>
        <input type="text" name="mother_occupation" class="cc-input" placeholder="e.g. Pediatrician">
      </div>

      <!-- Subsection: Legal Parent / Guardian / Secondary Contact -->
      <div class="cc-subheading">Legal Parent / Guardian / Secondary Contact</div>

      <input type="hidden" name="parent_id" value="<?= e($p['id'] ?? '') ?>">

      <div class="mb-3">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" name="link_existing_parent" id="linkExistingParent" value="1" onchange="toggleLinkExistingParent(this)">
          <label class="form-check-label fw-semibold text-dark" for="linkExistingParent" style="font-size: 13px;">
            Link to Existing Registered Parent / Guardian
          </label>
        </div>
        <div class="text-muted" style="font-size: 12px; margin-left: 1.5rem;">
          Link siblings or existing registered accounts from database
        </div>
      </div>

      <div id="existingParentWrap" style="display:none;" class="mb-3">
        <label class="cc-form-label">Select Registered Parent Account</label>
        <select name="existing_parent_id" id="existingParentSelect" class="cc-input form-select" onchange="handleExistingParentChange(this)">
          <option value="">Choose an existing parent from database...</option>
          <?php foreach (($existingParents ?? []) as $ep): ?>
            <option value="<?= (int)$ep['id'] ?>" data-first="<?= e($ep['first_name']) ?>" data-last="<?= e($ep['last_name']) ?>" data-email="<?= e($ep['email'] ?? '') ?>" data-phone="<?= e($ep['phone'] ?? '') ?>">
              <?= e($ep['first_name'] . ' ' . $ep['last_name']) ?> (<?= e($ep['phone'] ?: ($ep['email'] ?: 'No Contact')) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="row g-3 mb-2">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Parent / Guardian First Name</label>
          <input type="text" name="parent_first_name" id="parentFirstName" class="cc-input" value="<?= e($p['first_name'] ?? old('parent_first_name')) ?>" placeholder="e.g. Robert">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Parent / Guardian Last Name</label>
          <input type="text" name="parent_last_name" id="parentLastName" class="cc-input" value="<?= e($p['last_name'] ?? old('parent_last_name')) ?>" placeholder="e.g. Miller">
        </div>
      </div>

      <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Parent / Guardian Phone</label>
          <input type="text" name="parent_phone" id="parentPhone" class="cc-input" value="<?= e($p['phone'] ?? old('parent_phone')) ?>" placeholder="e.g. +1 (555) 017-3456">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Parent / Guardian Email</label>
          <input type="email" name="parent_email" id="parentEmail" class="cc-input" value="<?= e($p['email'] ?? old('parent_email')) ?>" placeholder="e.g. robertmiller@gmail.com">
        </div>
      </div>

      <!-- Parent Portal Login Access Sub-Card -->
      <div class="cc-inner-card mb-3" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 1.15rem 1.25rem;">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="user-check" style="width: 17px; height: 17px; color: #4f46e5;"></i>
            <span class="fw-bold text-dark" style="font-size: 13.5px;">Parent Portal Login Access</span>
          </div>
          <div class="form-check form-switch mb-0">
            <input class="form-check-input" type="checkbox" name="create_parent_portal_account" id="createParentPortalAccount" value="1" checked onchange="toggleParentPortalFields(this)">
            <label class="form-check-label small fw-semibold text-secondary" for="createParentPortalAccount">Enable Portal</label>
          </div>
        </div>
        <div class="text-muted small mb-3" style="font-size: 11.5px;">
          Enable this to auto-generate a Parent / Guardian Portal account so the parent can log in to view their child's attendance, fees, timetable, and report cards.
        </div>
        <div id="parentPortalFieldsWrap" class="row g-3">
          <div class="col-12 col-md-6">
            <label class="cc-form-label">Parent Portal Password</label>
            <div class="input-group">
              <span class="input-group-text bg-white border-end-0" style="border-color: #e2e8f0;"><i data-lucide="lock" style="width: 15px; height: 15px; color: #94a3b8;"></i></span>
              <input type="text" name="parent_password" id="parentPasswordInput" class="cc-input border-start-0" value="Parent@123" placeholder="Parent@123">
              <button type="button" class="btn btn-outline-primary px-3 fw-medium" onclick="generateParentPassword()" style="border-color: #cbd5e1; font-size: 12px;">
                <i data-lucide="refresh-cw" style="width: 13px; height: 13px;"></i> Generate
              </button>
            </div>
            <div class="text-muted mt-1" style="font-size: 10.5px;">Default: <code>Parent@123</code>. Login ID will be the Parent Email above.</div>
          </div>
        </div>
      </div>

      <div class="mb-2">
        <label class="cc-form-label">Relationship to Student</label>
        <select name="parent_relation" class="cc-input form-select">
          <option value="Legal Parent / Guardian" <?= (($p['relationship'] ?? '') === 'Legal Parent / Guardian') ? 'selected' : '' ?>>Legal Parent / Guardian</option>
          <option value="Father" <?= (($p['relationship'] ?? '') === 'Father') ? 'selected' : '' ?>>Father</option>
          <option value="Mother" <?= (($p['relationship'] ?? '') === 'Mother') ? 'selected' : '' ?>>Mother</option>
          <option value="Brother" <?= (($p['relationship'] ?? '') === 'Brother') ? 'selected' : '' ?>>Brother</option>
          <option value="Sister" <?= (($p['relationship'] ?? '') === 'Sister') ? 'selected' : '' ?>>Sister</option>
          <option value="Uncle" <?= (($p['relationship'] ?? '') === 'Uncle') ? 'selected' : '' ?>>Uncle</option>
          <option value="Aunt" <?= (($p['relationship'] ?? '') === 'Aunt') ? 'selected' : '' ?>>Aunt</option>
          <option value="Grandparent" <?= (($p['relationship'] ?? '') === 'Grandparent') ? 'selected' : '' ?>>Grandparent</option>
          <option value="Other" <?= (($p['relationship'] ?? '') === 'Other') ? 'selected' : '' ?>>Other</option>
        </select>
      </div>
    </div>

    <!-- ==========================================
         FORM FOOTER (CANCEL & CONFIRM ADMISSION)
         ========================================== -->
    <div class="d-flex align-items-center justify-content-end gap-2 pt-2">
      <a href="<?= e(url('students')) ?>" class="btn cc-btn-cancel text-decoration-none d-inline-flex align-items-center gap-2"><i data-lucide="x" style="width: 15px; height: 15px;"></i> Cancel</a>
      <button type="submit" class="btn cc-btn-submit d-inline-flex align-items-center gap-2" id="submitAdmissionBtn"><i data-lucide="check" style="width: 16px; height: 16px;"></i> <?= $isEdit ? 'Save Changes' : 'Confirm Admission' ?></button>
    </div>

  </form>
</div>

<script>
function toggleStudentPortalFields(chk) {
  const wrap = document.getElementById('studentPortalFieldsWrap');
  if (wrap) wrap.style.display = chk.checked ? 'flex' : 'none';
}
function toggleParentPortalFields(chk) {
  const wrap = document.getElementById('parentPortalFieldsWrap');
  if (wrap) wrap.style.display = chk.checked ? 'flex' : 'none';
}
function generateStudentPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
  let pass = 'Std!';
  for (let i = 0; i < 6; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
  document.getElementById('studentPasswordInput').value = pass;
}
function generateParentPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
  let pass = 'Par!';
  for (let i = 0; i < 6; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
  document.getElementById('parentPasswordInput').value = pass;
}
</script>

<script>
const classSubjectMap = <?= json_encode($classSubjectMap ?? []) ?>;

function previewStudentPhoto(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('photoPreview');
            const placeholder = document.getElementById('photoPlaceholder');
            preview.src = e.target.result;
            preview.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function handleClassChange(select) {
    const classId = select.value;
    const selectedOption = select.options[select.selectedIndex];
    const sectionSelect = document.getElementById('sectionSelect');
    
    // 1. Update Sections Dropdown
    sectionSelect.innerHTML = '<option value="">Select section...</option>';
    if (selectedOption && selectedOption.dataset.sections) {
        try {
            const sections = JSON.parse(selectedOption.dataset.sections);
            sections.forEach(function(sec) {
                const opt = document.createElement('option');
                opt.value = sec.id;
                opt.textContent = sec.name;
                sectionSelect.appendChild(opt);
            });
        } catch (e) {}
    }

    // 2. Update Course Electives & Subjects Section
    const emptyNotice = document.getElementById('subjectsEmptyNotice');
    const listWrap = document.getElementById('subjectsListWrap');
    listWrap.innerHTML = '';

    if (!classId) {
        emptyNotice.style.display = 'block';
        listWrap.style.display = 'none';
        return;
    }

    const subjects = classSubjectMap[classId] || [];
    if (subjects.length > 0) {
        emptyNotice.style.display = 'none';
        listWrap.style.display = 'flex';
        subjects.forEach(function(sub) {
            const col = document.createElement('div');
            col.className = 'col-12 col-md-6 col-lg-4';
            col.innerHTML = `
                <div class="d-flex align-items-center gap-2 p-2.5 rounded-3 border bg-white shadow-2xs">
                    <input type="checkbox" name="subject_ids[]" value="${sub.id}" class="form-check-input mt-0" checked>
                    <div class="flex-grow-1 min-w-0">
                        <div class="fw-semibold text-dark text-truncate" style="font-size: 13px;">${sub.name}</div>
                        <div class="text-muted text-uppercase" style="font-size: 10px;">${sub.code ? sub.code + ' &bull; ' : ''}${sub.type || 'core'}</div>
                    </div>
                </div>
            `;
            listWrap.appendChild(col);
        });
    } else {
        emptyNotice.textContent = 'No subjects mapped to this class yet.';
        emptyNotice.style.display = 'block';
        listWrap.style.display = 'none';
    }
}

function toggleAutoGenerateId(checkbox) {
    const wrap = document.getElementById('manualAdmissionWrap');
    if (wrap) {
        wrap.style.display = checkbox.checked ? 'none' : 'block';
    }
}

function toggleLinkExistingParent(checkbox) {
    const wrap = document.getElementById('existingParentWrap');
    if (wrap) {
        wrap.style.display = checkbox.checked ? 'block' : 'none';
    }
}

function handleExistingParentChange(select) {
    const opt = select.options[select.selectedIndex];
    if (opt && opt.value) {
        if (opt.dataset.first) document.getElementById('parentFirstName').value = opt.dataset.first;
        if (opt.dataset.last) document.getElementById('parentLastName').value = opt.dataset.last;
        if (opt.dataset.phone) document.getElementById('parentPhone').value = opt.dataset.phone;
        if (opt.dataset.email) document.getElementById('parentEmail').value = opt.dataset.email;
    }
}

const countriesList = [
  { code: 'AF', name: 'Afghanistan' },
  { code: 'AL', name: 'Albania' },
  { code: 'DZ', name: 'Algeria' },
  { code: 'AD', name: 'Andorra' },
  { code: 'AO', name: 'Angola' },
  { code: 'AR', name: 'Argentina' },
  { code: 'AM', name: 'Armenia' },
  { code: 'AU', name: 'Australia' },
  { code: 'AT', name: 'Austria' },
  { code: 'AZ', name: 'Azerbaijan' },
  { code: 'BS', name: 'Bahamas' },
  { code: 'BH', name: 'Bahrain' },
  { code: 'BD', name: 'Bangladesh' },
  { code: 'BB', name: 'Barbados' },
  { code: 'BY', name: 'Belarus' },
  { code: 'BE', name: 'Belgium' },
  { code: 'BZ', name: 'Belize' },
  { code: 'BJ', name: 'Benin' },
  { code: 'BT', name: 'Bhutan' },
  { code: 'BO', name: 'Bolivia' },
  { code: 'BA', name: 'Bosnia and Herzegovina' },
  { code: 'BW', name: 'Botswana' },
  { code: 'BR', name: 'Brazil' },
  { code: 'BN', name: 'Brunei' },
  { code: 'BG', name: 'Bulgaria' },
  { code: 'BF', name: 'Burkina Faso' },
  { code: 'BI', name: 'Burundi' },
  { code: 'KH', name: 'Cambodia' },
  { code: 'CM', name: 'Cameroon' },
  { code: 'CA', name: 'Canada' },
  { code: 'CL', name: 'Chile' },
  { code: 'CN', name: 'China' },
  { code: 'CO', name: 'Colombia' },
  { code: 'CR', name: 'Costa Rica' },
  { code: 'HR', name: 'Croatia' },
  { code: 'CU', name: 'Cuba' },
  { code: 'CY', name: 'Cyprus' },
  { code: 'CZ', name: 'Czech Republic' },
  { code: 'DK', name: 'Denmark' },
  { code: 'DJ', name: 'Djibouti' },
  { code: 'DO', name: 'Dominican Republic' },
  { code: 'EC', name: 'Ecuador' },
  { code: 'EG', name: 'Egypt' },
  { code: 'SV', name: 'El Salvador' },
  { code: 'EE', name: 'Estonia' },
  { code: 'ET', name: 'Ethiopia' },
  { code: 'FI', name: 'Finland' },
  { code: 'FR', name: 'France' },
  { code: 'GE', name: 'Georgia' },
  { code: 'DE', name: 'Germany' },
  { code: 'GH', name: 'Ghana' },
  { code: 'GR', name: 'Greece' },
  { code: 'GT', name: 'Guatemala' },
  { code: 'HT', name: 'Haiti' },
  { code: 'HN', name: 'Honduras' },
  { code: 'HK', name: 'Hong Kong' },
  { code: 'HU', name: 'Hungary' },
  { code: 'IS', name: 'Iceland' },
  { code: 'IN', name: 'India' },
  { code: 'ID', name: 'Indonesia' },
  { code: 'IR', name: 'Iran' },
  { code: 'IQ', name: 'Iraq' },
  { code: 'IE', name: 'Ireland' },
  { code: 'IL', name: 'Israel' },
  { code: 'IT', name: 'Italy' },
  { code: 'JM', name: 'Jamaica' },
  { code: 'JP', name: 'Japan' },
  { code: 'JO', name: 'Jordan' },
  { code: 'KZ', name: 'Kazakhstan' },
  { code: 'KE', name: 'Kenya' },
  { code: 'KW', name: 'Kuwait' },
  { code: 'KG', name: 'Kyrgyzstan' },
  { code: 'LB', name: 'Lebanon' },
  { code: 'LY', name: 'Libya' },
  { code: 'MY', name: 'Malaysia' },
  { code: 'MV', name: 'Maldives' },
  { code: 'MX', name: 'Mexico' },
  { code: 'MA', name: 'Morocco' },
  { code: 'NP', name: 'Nepal' },
  { code: 'NL', name: 'Netherlands' },
  { code: 'NZ', name: 'New Zealand' },
  { code: 'NG', name: 'Nigeria' },
  { code: 'NO', name: 'Norway' },
  { code: 'OM', name: 'Oman' },
  { code: 'PK', name: 'Pakistan' },
  { code: 'PS', name: 'Palestine' },
  { code: 'PA', name: 'Panama' },
  { code: 'PE', name: 'Peru' },
  { code: 'PH', name: 'Philippines' },
  { code: 'PL', name: 'Poland' },
  { code: 'PT', name: 'Portugal' },
  { code: 'QA', name: 'Qatar' },
  { code: 'RO', name: 'Romania' },
  { code: 'RU', name: 'Russia' },
  { code: 'SA', name: 'Saudi Arabia' },
  { code: 'SG', name: 'Singapore' },
  { code: 'ZA', name: 'South Africa' },
  { code: 'KR', name: 'South Korea' },
  { code: 'ES', name: 'Spain' },
  { code: 'LK', name: 'Sri Lanka' },
  { code: 'SD', name: 'Sudan' },
  { code: 'SE', name: 'Sweden' },
  { code: 'CH', name: 'Switzerland' },
  { code: 'SY', name: 'Syria' },
  { code: 'TW', name: 'Taiwan' },
  { code: 'TJ', name: 'Tajikistan' },
  { code: 'TZ', name: 'Tanzania' },
  { code: 'TH', name: 'Thailand' },
  { code: 'TN', name: 'Tunisia' },
  { code: 'TR', name: 'Turkey' },
  { code: 'UA', name: 'Ukraine' },
  { code: 'AE', name: 'United Arab Emirates' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'US', name: 'United States' },
  { code: 'UY', name: 'Uruguay' },
  { code: 'UZ', name: 'Uzbekistan' },
  { code: 'VE', name: 'Venezuela' },
  { code: 'VN', name: 'Vietnam' },
  { code: 'YE', name: 'Yemen' },
  { code: 'ZW', name: 'Zimbabwe' }
];

function initCountryPicker() {
  const wrap = document.getElementById('countryPickerWrap');
  const btn = document.getElementById('countryPickerBtn');
  const hiddenInput = document.getElementById('countryInputHidden');
  const display = document.getElementById('countrySelectedDisplay');
  const searchBox = document.getElementById('countrySearchBox');
  const container = document.getElementById('countryItemsContainer');
  const chevron = document.getElementById('countryChevron');

  if (!wrap || !btn || !hiddenInput || !display || !searchBox || !container) return;

  function escapeHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderList(query = '') {
    const q = query.trim().toLowerCase();
    const filtered = countriesList.filter(c => c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q));
    
    if (filtered.length === 0) {
      container.innerHTML = '<div class="p-3 text-center text-muted small">No country matching "' + escapeHtml(query) + '"</div>';
      return;
    }

    const currentVal = (hiddenInput.value || '').trim().toLowerCase();
    container.innerHTML = filtered.map(c => {
      const isSelected = c.name.toLowerCase() === currentVal;
      const flagUrl = `https://flagcdn.com/w20/${c.code.toLowerCase()}.png`;
      const flagUrl2x = `https://flagcdn.com/w40/${c.code.toLowerCase()}.png`;
      return `
        <div class="country-item ${isSelected ? 'selected' : ''}" data-name="${escapeHtml(c.name)}" data-code="${c.code}">
          <img src="${flagUrl}" srcset="${flagUrl2x} 2x" width="20" height="14" alt="${c.code}" class="country-flag-img">
          <span>${escapeHtml(c.name)}</span>
        </div>
      `;
    }).join('');

    container.querySelectorAll('.country-item').forEach(item => {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        selectCountry(this.dataset.name, this.dataset.code);
        closeDropdown();
      });
    });
  }

  function selectCountry(name, code) {
    if (!name) return;
    hiddenInput.value = name;
    if (!code) {
      const found = countriesList.find(c => c.name.toLowerCase() === name.toLowerCase());
      if (found) code = found.code;
    }
    const flagHtml = code 
      ? `<img src="https://flagcdn.com/w20/${code.toLowerCase()}.png" srcset="https://flagcdn.com/w40/${code.toLowerCase()}.png 2x" width="20" height="14" alt="${code}" class="country-flag-img">`
      : '';
    display.innerHTML = `${flagHtml}<span class="fw-medium">${escapeHtml(name)}</span>`;
  }

  function openDropdown() {
    wrap.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
    if (chevron) chevron.style.transform = 'rotate(180deg)';
    searchBox.value = '';
    renderList('');
    setTimeout(() => searchBox.focus(), 60);
  }

  function closeDropdown() {
    wrap.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    if (chevron) chevron.style.transform = '';
  }

  btn.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    if (wrap.classList.contains('open')) {
      closeDropdown();
    } else {
      openDropdown();
    }
  });

  searchBox.addEventListener('click', function(e) {
    e.stopPropagation();
  });

  searchBox.addEventListener('input', function() {
    renderList(this.value);
  });

  searchBox.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeDropdown();
      btn.focus();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const firstItem = container.querySelector('.country-item');
      if (firstItem) {
        selectCountry(firstItem.dataset.name, firstItem.dataset.code);
        closeDropdown();
        btn.focus();
      }
    }
  });

  document.addEventListener('click', function(e) {
    if (!wrap.contains(e.target)) {
      closeDropdown();
    }
  });

  // Initial selection
  const initial = hiddenInput.value || 'United States';
  selectCountry(initial);
}

document.addEventListener('DOMContentLoaded', function() {
    initCountryPicker();
    
    // In edit mode or after validation redirect, show subjects for the selected class
    const classSelect = document.getElementById('classSelect');
    if (classSelect && classSelect.value) {
        const classId = classSelect.value;
        const emptyNotice = document.getElementById('subjectsEmptyNotice');
        const listWrap = document.getElementById('subjectsListWrap');
        if (typeof classSubjectMap !== 'undefined' && classSubjectMap[classId] && classSubjectMap[classId].length > 0) {
            emptyNotice.style.display = 'none';
            listWrap.style.display = 'flex';
            listWrap.innerHTML = '';
            classSubjectMap[classId].forEach(function(sub) {
                const col = document.createElement('div');
                col.className = 'col-12 col-md-6 col-lg-4';
                col.innerHTML = `
                    <div class="d-flex align-items-center gap-2 p-2.5 rounded-3 border bg-white shadow-2xs">
                        <input type="checkbox" name="subject_ids[]" value="${sub.id}" class="form-check-input mt-0" checked>
                        <div class="flex-grow-1 min-w-0">
                            <div class="fw-semibold text-dark text-truncate" style="font-size: 13px;">${sub.name}</div>
                            <div class="text-muted text-uppercase" style="font-size: 10px;">${sub.code ? sub.code + ' &bull; ' : ''}${sub.type || 'core'}</div>
                        </div>
                    </div>
                `;
                listWrap.appendChild(col);
            });
        }
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
</script>