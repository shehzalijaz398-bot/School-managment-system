<?php
/**
 * Student Directory View - CodeClove School Management Pro UI Match
 */
?>

<!-- Breadcrumbs & Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Students</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Student Directory</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Student Directory</h1>
      <p class="text-muted small mb-0">View registered student directories, class details, primary emergency contacts, and enroll manual student records.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
      <!-- Export CSV Button -->
      <a href="<?= e(url('students/export-csv')) ?>" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;" title="Export full student roster to CSV">
        <i data-lucide="download" style="width: 15px; height: 15px;"></i>
        <span>Export CSV</span>
      </a>

      <!-- Bulk Import Trigger -->
      <?php if (hasPermission('students.create')): ?>
        <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" data-bs-toggle="modal" data-bs-target="#bulkImportModal" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;">
          <i data-lucide="file-up" style="width: 15px; height: 15px;"></i>
          <span>Bulk Import</span>
        </button>
      <?php endif; ?>

      <!-- Admit Student Button -->
      <?php if (hasPermission('students.create')): ?>
        <a href="<?= e(url('students/create')) ?>" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold shadow-sm" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; height: 38px;">
          <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
          <span>Admit Student</span>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- 4-Filter Card (CodeClove Exact Layout) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3">
    <form method="get" action="<?= e(url('students')) ?>" id="studentsFilterForm" class="row g-2 align-items-center m-0">
      <input type="hidden" name="limit" value="<?= (int)($limit ?? 10) ?>">
      <input type="hidden" name="sort" value="<?= e($sort ?? 'name') ?>">
      <input type="hidden" name="dir" value="<?= e($dir ?? 'asc') ?>">

      <!-- Filter 1: Search Students -->
      <div class="col-12 col-md-4">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Search Students</label>
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 10px; width: 15px; height: 15px;"></i>
          <input type="text" name="q" id="searchStudentsInput" value="<?= e($filters['q'] ?? '') ?>" class="form-control form-control-sm ps-5" placeholder="Search by name, ID number.." style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;">
          <?php if (!empty($filters['q'])): ?>
            <a href="<?= e(url('students')) ?>" class="position-absolute text-muted" style="right: 10px; top: 10px;" title="Clear search">
              <i data-lucide="x" style="width: 14px; height: 14px;"></i>
            </a>
          <?php endif; ?>
        </div>
      </div>

      <!-- Filter 2: Class -->
      <div class="col-12 col-sm-6 col-md-3">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Class</label>
        <select name="class_id" id="classFilterSelect" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="onClassFilterChange(this)">
          <option value="">All classes</option>
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((string)($filters['class_id'] ?? '') === (string)$c['id']) ? 'selected' : '' ?>>
              <?= e($c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Filter 3: Section -->
      <div class="col-12 col-sm-6 col-md-3">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Section</label>
        <select name="section_id" id="sectionFilterSelect" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="">All sections</option>
          <?php 
            $selectedClassId = (int)($filters['class_id'] ?? 0);
            foreach ($classes as $c): 
              if ($selectedClassId > 0 && (int)$c['id'] !== $selectedClassId) {
                  continue;
              }
              if (!empty($c['sections'])):
                foreach ($c['sections'] as $sec):
          ?>
                <option value="<?= (int)$sec['id'] ?>" <?= ((string)($filters['section_id'] ?? '') === (string)$sec['id']) ? 'selected' : '' ?> data-class-id="<?= (int)$c['id'] ?>">
                  <?= $selectedClassId === 0 ? e($c['name'] . ' - ' . $sec['name']) : e($sec['name']) ?>
                </option>
          <?php 
                endforeach;
              endif;
            endforeach; 
          ?>
        </select>
      </div>

      <!-- Filter 4: Status -->
      <div class="col-12 col-md-2">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Status</label>
        <select name="status" id="statusFilterSelect" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="">All statuses</option>
          <option value="active" <?= (($filters['status'] ?? '') === 'active') ? 'selected' : '' ?>>Active</option>
          <option value="inactive" <?= (($filters['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
          <option value="withdrawn" <?= (($filters['status'] ?? '') === 'withdrawn') ? 'selected' : '' ?>>Withdrawn</option>
          <option value="suspended" <?= (($filters['status'] ?? '') === 'suspended') ? 'selected' : '' ?>>Suspended</option>
          <option value="graduated" <?= (($filters['status'] ?? '') === 'graduated') ? 'selected' : '' ?>>Graduated</option>
          <option value="transferred" <?= (($filters['status'] ?? '') === 'transferred') ? 'selected' : '' ?>>Transferred</option>
        </select>
      </div>
    </form>
  </div>
</div>

<!-- Bulk Action Floating Bar (Revealed on row selection) -->
<form method="post" action="<?= e(url('students/bulk-action')) ?>" id="bulkActionForm">
  <?= csrf_field() ?>
  <div id="bulkActionBar" class="card border-0 shadow-sm mb-3 d-none" style="border-radius: 10px; background: #f8fafc; border: 1px solid #cbd5e1 !important;">
    <div class="card-body p-2 px-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary rounded-pill px-2 py-1" id="selectedCountBadge" style="background-color: #4f46e5 !important;">0</span>
        <span class="small fw-semibold text-dark">student(s) selected</span>
      </div>
      <div class="d-flex align-items-center gap-2">
        <select name="bulk_status" class="form-select form-select-sm" style="width: 140px; height: 32px; border-radius: 6px; font-size: 12px;">
          <option value="active">Set Active</option>
          <option value="inactive">Set Inactive</option>
          <option value="suspended">Set Suspended</option>
          <option value="graduated">Set Graduated</option>
          <option value="withdrawn">Set Withdrawn</option>
        </select>
        <button type="submit" name="action" value="status" class="btn btn-sm btn-outline-secondary fw-medium" style="height: 32px; border-radius: 6px; font-size: 12px;">
          Apply Status
        </button>
        <button type="submit" name="action" value="withdraw" class="btn btn-sm btn-outline-danger fw-medium d-inline-flex align-items-center gap-1" style="height: 32px; border-radius: 6px; font-size: 12px;" onclick="return confirm('Are you sure you want to withdraw selected students?')">
          <i data-lucide="trash-2" style="width: 13px; height: 13px;"></i>
          <span>Withdraw</span>
        </button>
        <button type="button" class="btn btn-sm btn-link text-muted p-0 ms-2" onclick="clearSelectedRows()" title="Cancel Selection">
          <i data-lucide="x" style="width: 16px; height: 16px;"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- Students Table Card -->
  <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; overflow: hidden;">
    <?php if (empty($students)): ?>
      <!-- Empty State (Matches CodeClove Screenshot) -->
      <div class="text-center py-5 my-3">
        <div class="d-inline-flex align-items-center justify-content-center rounded-circle mb-3" style="width: 56px; height: 56px; background: #f8fafc; border: 1px solid #e2e8f0;">
          <i data-lucide="users" style="width: 26px; height: 26px; color: #94a3b8;"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1" style="font-size: 16px;">No Students Found</h5>
        <p class="text-muted small mb-3">Admit your first student to configure their academic record.</p>
        <?php if (hasPermission('students.create')): ?>
          <a href="<?= e(url('students/create')) ?>" class="btn btn-sm btn-primary px-3 py-2 fw-semibold" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
            <span>Admit Student</span>
          </a>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle mb-0" id="studentsDirectoryTable">
          <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
            <tr style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
              <!-- Select All Checkbox -->
              <th class="ps-3 py-3" style="width: 40px;">
                <div class="form-check m-0">
                  <input class="form-check-input" type="checkbox" id="selectAllCheckbox" style="border-color: #cbd5e1; cursor: pointer;" onchange="toggleSelectAll(this)">
                </div>
              </th>
              
              <!-- Column: STUDENT -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('name')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>STUDENT</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: ADMISSION NO. -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('admission_no')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>ADMISSION NO.</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: CLASS -->
              <th class="py-3 fw-bold">CLASS</th>

              <!-- Column: SECTION -->
              <th class="py-3 fw-bold">SECTION</th>

              <!-- Column: PRIMARY PARENT / GUARDIAN -->
              <th class="py-3 fw-bold">PRIMARY PARENT / GUARDIAN</th>

              <!-- Column: STATUS -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('status')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>STATUS</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: ACTIONS -->
              <th class="pe-3 py-3 fw-bold text-end" style="width: 140px;">ACTIONS</th>
            </tr>
          </thead>
          <tbody style="font-size: 13px;">
            <?php foreach ($students as $s): ?>
              <?php
                $fullName = trim($s['first_name'] . ' ' . $s['last_name']);
                $initial = strtoupper(substr($s['first_name'] ?: 'S', 0, 1));
                
                // Parent / Guardian Display
                $parentName = trim(($s['parent_first_name'] ?? '') . ' ' . ($s['parent_last_name'] ?? ''));
                if (!$parentName && !empty($s['emergency_contact'])) {
                    $parentName = $s['emergency_contact'];
                }
                $parentPhone = $s['parent_phone'] ?: ($s['emergency_phone'] ?: '');
                $parentRel = $s['parent_relationship'] ?: 'Guardian';

                // Status configuration
                $statusColors = [
                    'active' => ['bg' => '#f0fdf4', 'text' => '#16a34a', 'dot' => '#22c55e', 'label' => 'Active'],
                    'inactive' => ['bg' => '#f1f5f9', 'text' => '#475569', 'dot' => '#94a3b8', 'label' => 'Inactive'],
                    'withdrawn' => ['bg' => '#fffbeb', 'text' => '#b45309', 'dot' => '#f59e0b', 'label' => 'Withdrawn'],
                    'suspended' => ['bg' => '#fef2f2', 'text' => '#dc2626', 'dot' => '#ef4444', 'label' => 'Suspended'],
                    'graduated' => ['bg' => '#eff6ff', 'text' => '#2563eb', 'dot' => '#3b82f6', 'label' => 'Graduated'],
                    'transferred' => ['bg' => '#f5f3ff', 'text' => '#7c3aed', 'dot' => '#8b5cf6', 'label' => 'Transferred'],
                ];
                $stInfo = $statusColors[$s['status']] ?? $statusColors['active'];
              ?>
              <tr class="student-row" style="border-bottom: 1px solid #f1f5f9;">
                <!-- Row Checkbox -->
                <td class="ps-3 py-3">
                  <div class="form-check m-0">
                    <input class="form-check-input student-checkbox" type="checkbox" name="student_ids[]" value="<?= (int)$s['id'] ?>" style="border-color: #cbd5e1; cursor: pointer;" onchange="updateSelectedCount()">
                  </div>
                </td>

                <!-- Student Profile Cell -->
                <td class="py-3">
                  <div class="d-flex align-items-center gap-3">
                    <?php if (!empty($s['profile_image'])): ?>
                      <img src="<?= e(asset($s['profile_image'])) ?>" alt="" class="rounded-circle" style="width: 36px; height: 36px; object-fit: cover;">
                    <?php else: ?>
                      <div class="d-flex align-items-center justify-content-center rounded-circle fw-bold text-white shadow-2xs" 
                           style="width: 36px; height: 36px; font-size: 13px; background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);">
                        <?= e($initial) ?>
                      </div>
                    <?php endif; ?>
                    <div>
                      <a href="<?= e(url('students/' . $s['id'])) ?>" class="fw-semibold text-dark text-decoration-none hover-primary d-block" style="line-height: 1.25;">
                        <?= e($fullName) ?>
                      </a>
                      <div class="text-muted small" style="font-size: 11px;">
                        <?php if (!empty($s['roll_no'])): ?>
                          <span>Roll: <?= e($s['roll_no']) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($s['gender'])): ?>
                          <span class="ms-1">• <?= ucfirst(e($s['gender'])) ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </td>

                <!-- Admission No. -->
                <td class="py-3">
                  <span class="fw-medium text-secondary" style="font-family: monospace; font-size: 12px; letter-spacing: 0.02em;">
                    <?= e($s['admission_no']) ?>
                  </span>
                </td>

                <!-- Class -->
                <td class="py-3">
                  <span class="fw-medium text-dark">
                    <?= e($s['class_name'] ?? '—') ?>
                  </span>
                </td>

                <!-- Section -->
                <td class="py-3">
                  <?php if (!empty($s['section_name'])): ?>
                    <span class="badge bg-light text-secondary border fw-medium px-2 py-1" style="border-color: #e2e8f0 !important; font-size: 11px;">
                      <?= e($s['section_name']) ?>
                    </span>
                  <?php else: ?>
                    <span class="text-muted small">—</span>
                  <?php endif; ?>
                </td>

                <!-- Primary Parent / Guardian -->
                <td class="py-3">
                  <?php if ($parentName): ?>
                    <div class="fw-medium text-dark" style="line-height: 1.25;">
                      <?= e($parentName) ?>
                    </div>
                    <div class="text-muted small d-flex align-items-center gap-1" style="font-size: 11px;">
                      <span class="text-secondary"><?= e($parentRel) ?></span>
                      <?php if ($parentPhone): ?>
                        <span>• <?= e($parentPhone) ?></span>
                      <?php endif; ?>
                    </div>
                  <?php else: ?>
                    <span class="text-muted small" style="font-style: italic;">Not Assigned</span>
                  <?php endif; ?>
                </td>

                <!-- Status -->
                <td class="py-3">
                  <span class="badge rounded-pill d-inline-flex align-items-center gap-1 py-1 px-2 fw-medium" 
                        style="background: <?= $stInfo['bg'] ?>; color: <?= $stInfo['text'] ?>; font-size: 11px;">
                    <span style="width: 6px; height: 6px; border-radius: 50%; background-color: <?= $stInfo['dot'] ?>;"></span>
                    <?= e($stInfo['label']) ?>
                  </span>
                </td>

                <!-- Actions Cell -->
                <td class="pe-3 py-3 text-end">
                  <div class="d-inline-flex align-items-center gap-1">
                    
                    <!-- 1. View Profile -->
                    <a href="<?= e(url('students/' . $s['id'])) ?>" class="btn btn-sm btn-icon text-muted hover-icon p-1" title="View Profile" style="border-radius: 6px;">
                      <i data-lucide="eye" style="width: 15px; height: 15px;"></i>
                    </a>

                    <!-- 2. Quick Fee Modal Trigger (Preserves existing feature) -->
                    <?php if (hasPermission('finance.manage')): ?>
                      <button type="button" class="btn btn-sm btn-icon text-success hover-icon p-1" data-bs-toggle="modal" data-bs-target="#quickFeeModal<?= (int)$s['id'] ?>" title="Collect Fee / Quick Invoice" style="border-radius: 6px;">
                        <i data-lucide="dollar-sign" style="width: 15px; height: 15px;"></i>
                      </button>
                    <?php endif; ?>

                    <!-- 3. Edit Student -->
                    <?php if (hasPermission('students.edit')): ?>
                      <a href="<?= e(url('students/' . $s['id'] . '/edit')) ?>" class="btn btn-sm btn-icon text-muted hover-icon p-1" title="Edit Student" style="border-radius: 6px;">
                        <i data-lucide="edit-3" style="width: 15px; height: 15px;"></i>
                      </a>
                    <?php endif; ?>

                    <!-- 4. Safe Delete / Withdraw -->
                    <?php if (hasPermission('students.delete')): ?>
                      <button type="button" class="btn btn-sm btn-icon text-danger hover-icon p-1" data-bs-toggle="modal" data-bs-target="#deleteStudentModal<?= (int)$s['id'] ?>" title="Withdraw / Archive Student" style="border-radius: 6px;">
                        <i data-lucide="trash-2" style="width: 15px; height: 15px;"></i>
                      </button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Table Footer & Pagination -->
      <div class="p-3 border-top d-flex justify-content-between align-items-center flex-wrap gap-3 bg-white" style="border-color: #f1f5f9 !important;">
        <!-- Records Counter -->
        <div class="text-muted small">
          Showing <span class="fw-semibold text-dark"><?= $startRecord ?></span> to <span class="fw-semibold text-dark"><?= $endRecord ?></span> of <span class="fw-semibold text-dark"><?= $total ?></span> records
        </div>

        <!-- Limit / Rows Selector & Pagination Controls -->
        <div class="d-flex align-items-center gap-3">
          <!-- Rows Dropdown -->
          <div class="d-flex align-items-center gap-1">
            <span class="text-muted small" style="font-size: 12px;">Rows:</span>
            <select class="form-select form-select-sm" style="width: 70px; height: 30px; font-size: 12px; border-radius: 6px; border-color: #cbd5e1;" onchange="changeLimit(this.value)">
              <option value="10" <?= ($limit ?? 10) == 10 ? 'selected' : '' ?>>10</option>
              <option value="25" <?= ($limit ?? 10) == 25 ? 'selected' : '' ?>>25</option>
              <option value="50" <?= ($limit ?? 10) == 50 ? 'selected' : '' ?>>50</option>
              <option value="100" <?= ($limit ?? 10) == 100 ? 'selected' : '' ?>>100</option>
            </select>
          </div>

          <!-- Pagination Buttons -->
          <?php if (($totalPages ?? 1) > 1): ?>
            <nav aria-label="Page navigation">
              <ul class="pagination pagination-sm m-0 gap-1">
                <li class="page-item <?= ($page ?? 1) <= 1 ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('students?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) - 1])))) ?>">
                    <i data-lucide="chevron-left" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                  <?php if ($p == 1 || $p == $totalPages || ($p >= ($page - 2) && $p <= ($page + 2))): ?>
                    <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                      <a class="page-link rounded px-3" href="<?= e(url('students?' . http_build_query(array_merge($filters, ['page' => $p])))) ?>" 
                         style="<?= $p == $page ? 'background-color: #4f46e5; border-color: #4f46e5;' : '' ?>">
                        <?= $p ?>
                      </a>
                    </li>
                  <?php elseif ($p == 2 || $p == ($totalPages - 1)): ?>
                    <li class="page-item disabled"><span class="page-link rounded border-0 px-2">...</span></li>
                  <?php endif; ?>
                <?php endfor; ?>
                <li class="page-item <?= ($page ?? 1) >= $totalPages ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('students?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) + 1])))) ?>">
                    <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
              </ul>
            </nav>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</form>

<!-- QUICK FEE MODALS (Preserving existing Quick-Fee Feature per student) -->
<?php if (!empty($students) && hasPermission('finance.manage')): ?>
  <?php foreach ($students as $s): ?>
    <?php $sName = trim($s['first_name'] . ' ' . $s['last_name']); ?>
    <div class="modal fade" id="quickFeeModal<?= (int)$s['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
          <form method="post" action="<?= e(url('students/quick-fee')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">

            <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
              <div>
                <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Quick Fee Collection</h5>
                <span class="text-muted small"><?= e($sName) ?> • <?= e($s['admission_no']) ?> (<?= e($s['class_name'] ?? '') ?>)</span>
              </div>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
              <!-- Fee Type / Category -->
              <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Fee Type / Item <span class="text-danger">*</span></label>
                <select name="fee_type" class="form-select form-select-sm" required onchange="onFeeCategoryChange(this, <?= (int)$s['id'] ?>)" style="height: 38px; border-radius: 8px;">
                  <option value="" disabled selected>Select Fee Category...</option>
                  <?php if (!empty($feeCategories)): ?>
                    <?php foreach ($feeCategories as $fc): ?>
                      <option value="<?= e($fc['id']) ?>" data-amount="<?= (float)$fc['amount'] ?>"><?= e($fc['name']) ?> (Rs <?= number_format((float)$fc['amount']) ?>)</option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <option value="Admission Fee" data-amount="25000">Admission Fee (Rs 25,000)</option>
                    <option value="Monthly Tuition" data-amount="15000" selected>Monthly Fee (Rs 15,000)</option>
                    <option value="Uniform Fee" data-amount="4500">Uniform Fee (Rs 4,500)</option>
                    <option value="Exam Fee" data-amount="3000">Exam Fee (Rs 3,000)</option>
                    <option value="Transport Fee" data-amount="5000">Transport Fee (Rs 5,000)</option>
                  <?php endif; ?>
                </select>
              </div>

              <!-- Payment Method & Status -->
              <div class="row g-2 mb-3">
                <div class="col-6">
                  <label class="form-label small fw-semibold text-secondary">Payment Method</label>
                  <select name="payment_method" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                    <option value="cash" selected>💵 Cash</option>
                    <option value="online">🌐 Online Transfer</option>
                    <option value="bank">🏦 Bank Deposit</option>
                    <option value="card">💳 Card</option>
                  </select>
                </div>
                <div class="col-6">
                  <label class="form-label small fw-semibold text-secondary">Payment Status</label>
                  <select name="payment_status" class="form-select form-select-sm fw-semibold text-success" style="height: 38px; border-radius: 8px;">
                    <option value="paid" class="text-success fw-bold" selected>✔ Paid</option>
                    <option value="unpaid" class="text-danger fw-bold">⏳ Unpaid / Pending</option>
                  </select>
                </div>
              </div>

              <!-- Amount -->
              <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Amount (Rs) <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text bg-light text-muted border-secondary-subtle">Rs</span>
                  <input type="number" name="amount" id="feeAmountInput<?= (int)$s['id'] ?>" class="form-control" value="15000" min="0" required style="height: 38px;">
                </div>
              </div>

              <!-- Invoices Link helper -->
              <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                <span class="text-muted small">Need full breakdown?</span>
                <a href="<?= e(url('finance/invoices?student_id=' . $s['id'])) ?>" class="small text-primary fw-medium text-decoration-none">
                  View All Student Invoices →
                </a>
              </div>
            </div>

            <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
              <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
              <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
                <i data-lucide="check" style="width: 15px; height: 15px;"></i>
                <span>Save Fee Record</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- DELETE / WITHDRAW CONFIRMATION MODAL -->
    <?php if (hasPermission('students.delete')): ?>
      <div class="modal fade" id="deleteStudentModal<?= (int)$s['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
          <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
            <form method="post" action="<?= e(url('students/' . $s['id'] . '/delete')) ?>">
              <?= csrf_field() ?>
              <div class="modal-body p-4 text-center">
                <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger mb-3" style="width: 48px; height: 48px;">
                  <i data-lucide="alert-triangle" style="width: 24px; height: 24px;"></i>
                </div>
                <h6 class="fw-bold text-dark mb-1">Withdraw Student?</h6>
                <p class="text-muted small mb-0">Are you sure you want to mark <strong><?= e($fullName) ?></strong> as withdrawn? Historical academic & fee records will remain safe.</p>
              </div>
              <div class="modal-footer border-0 p-3 pt-0 justify-content-center">
                <button type="button" class="btn btn-sm btn-light px-3" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
                <button type="submit" class="btn btn-sm btn-danger px-3 fw-semibold" style="border-radius: 8px;">Withdraw</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    <?php endif; ?>
  <?php endforeach; ?>
<?php endif; ?>

<!-- BULK IMPORT MODAL -->
<?php if (hasPermission('students.create')): ?>
  <div class="modal fade" id="bulkImportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
        <form method="post" action="<?= e(url('students/bulk-import')) ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
            <div>
              <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Bulk Import Students</h5>
              <span class="text-muted small">Upload CSV file to admit multiple student records into the directory at once.</span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body p-4">
            <!-- Sample CSV Note -->
            <div class="alert alert-info border-0 rounded-3 d-flex align-items-center justify-content-between p-3 mb-4" style="background-color: #eff6ff; color: #1e40af;">
              <div class="d-flex align-items-center gap-2">
                <i data-lucide="info" style="width: 18px; height: 18px;"></i>
                <span class="small">Expected columns: <code>first_name, last_name, gender, admission_no, roll_no, parent_name, parent_phone</code></span>
              </div>
              <a href="data:text/csv;charset=utf-8,first_name,last_name,gender,admission_no,roll_no,parent_name,parent_phone%0AAli,Khan,male,ADM-101,1,Ahmed Khan,03001234567%0AFatima,Zahra,female,ADM-102,2,Tariq Zahra,03009876543" download="sample_students.csv" class="btn btn-sm btn-primary py-1 px-2 fw-semibold" style="font-size: 11px; border-radius: 6px;">
                Download Sample CSV
              </a>
            </div>

            <!-- Target Class & Section (Fallback for records missing class info) -->
            <div class="row g-3 mb-4">
              <div class="col-md-6">
                <label class="form-label small fw-semibold text-secondary">Assign To Class <span class="text-danger">*</span></label>
                <select name="class_id" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;">
                  <option value="" disabled selected>Select Class...</option>
                  <?php foreach ($classes as $c): ?>
                    <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-semibold text-secondary">Assign To Section</label>
                <select name="section_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                  <option value="">Auto / First Section</option>
                  <?php foreach ($classes as $c): ?>
                    <?php if (!empty($c['sections'])): ?>
                      <?php foreach ($c['sections'] as $sec): ?>
                        <option value="<?= (int)$sec['id'] ?>"><?= e($c['name'] . ' - ' . $sec['name']) ?></option>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <!-- File Upload -->
            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">Choose CSV File (.csv) <span class="text-danger">*</span></label>
              <input type="file" name="csv_file" accept=".csv" required class="form-control" style="border-radius: 8px; padding: 0.5rem 0.75rem;">
            </div>
          </div>

          <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
              <i data-lucide="upload" style="width: 15px; height: 15px;"></i>
              <span>Upload &amp; Import</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- Javascript & Reactive Features -->
<script>
// Handle Class filter dropdown change to dynamically filter Section options
function onClassFilterChange(classSelect) {
  const form = document.getElementById('studentsFilterForm');
  const sectionSelect = document.getElementById('sectionFilterSelect');
  const selectedClassId = classSelect.value;

  // Reset section select
  sectionSelect.value = '';
  form.submit();
}

// Quick fee category change handler
function onFeeCategoryChange(selectElem, studentId) {
  const opt = selectElem.options[selectElem.selectedIndex];
  const amount = opt.getAttribute('data-amount');
  const amountInput = document.getElementById('feeAmountInput' + studentId);
  if (amountInput && amount) {
    amountInput.value = parseFloat(amount);
  }
}

// Multi-select Checkbox Controls
function toggleSelectAll(masterCheckbox) {
  const checkboxes = document.querySelectorAll('.student-checkbox');
  checkboxes.forEach(cb => {
    cb.checked = masterCheckbox.checked;
  });
  updateSelectedCount();
}

function updateSelectedCount() {
  const checkboxes = document.querySelectorAll('.student-checkbox:checked');
  const count = checkboxes.length;
  const bar = document.getElementById('bulkActionBar');
  const badge = document.getElementById('selectedCountBadge');
  
  if (badge) badge.textContent = count;
  if (bar) {
    if (count > 0) {
      bar.classList.remove('d-none');
    } else {
      bar.classList.add('d-none');
    }
  }

  // Update master checkbox state
  const allCheckboxes = document.querySelectorAll('.student-checkbox');
  const master = document.getElementById('selectAllCheckbox');
  if (master && allCheckboxes.length > 0) {
    master.checked = count === allCheckboxes.length;
  }
}

function clearSelectedRows() {
  document.querySelectorAll('.student-checkbox').forEach(cb => cb.checked = false);
  const master = document.getElementById('selectAllCheckbox');
  if (master) master.checked = false;
  updateSelectedCount();
}

// Rows Limit Switcher
function changeLimit(newLimit) {
  const form = document.getElementById('studentsFilterForm');
  form.querySelector('input[name="limit"]').value = newLimit;
  form.submit();
}

// Sort By Column
function sortBy(column) {
  const form = document.getElementById('studentsFilterForm');
  const sortInput = form.querySelector('input[name="sort"]');
  const dirInput = form.querySelector('input[name="dir"]');

  if (sortInput.value === column) {
    dirInput.value = dirInput.value === 'asc' ? 'desc' : 'asc';
  } else {
    sortInput.value = column;
    dirInput.value = 'asc';
  }
  form.submit();
}

// Re-init lucide icons on render
document.addEventListener('DOMContentLoaded', function() {
  if (window.lucide) {
    lucide.createIcons();
  }
});
</script>

<style>
.hover-icon:hover {
  background-color: #f1f5f9 !important;
  color: #1e293b !important;
}
.hover-primary:hover {
  color: #4f46e5 !important;
}
.student-row:hover {
  background-color: #f8fafc !important;
}
</style>