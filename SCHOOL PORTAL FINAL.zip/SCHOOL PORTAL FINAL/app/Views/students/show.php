<?php
$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$admNo = $student['admission_no'] ?? 'N/A';
$rollNo = $student['roll_no'] ?? 'N/A';
$className = $student['class_name'] ?? 'Unassigned';
$sectionName = $student['section_name'] ?? '';
$status = strtolower((string)($student['status'] ?? 'active'));
$dob = !empty($student['date_of_birth']) ? date('M d, Y', strtotime((string)$student['date_of_birth'])) : 'N/A';
$admDate = !empty($student['admission_date']) ? date('M d, Y', strtotime((string)$student['admission_date'])) : 'N/A';

$totalDue = (float)($total_outstanding ?? 0);
$hasOverdue = $totalDue > 0;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div class="d-flex align-items-center gap-3">
    <a href="<?= e(url('students')) ?>" class="btn btn-outline-secondary btn-sm rounded-circle p-1" style="width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;">
      <i data-lucide="arrow-left" style="width:18px;height:18px;"></i>
    </a>
    <div class="d-flex align-items-center gap-3">
      <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-4 shadow-sm" style="width:52px;height:52px;">
        <?= strtoupper(substr($fullName ?: 'S', 0, 1)) ?>
      </div>
      <div>
        <h2 class="mb-0 fw-bold text-dark fs-4"><?= e($fullName) ?></h2>
        <div class="d-flex align-items-center gap-2 mt-1 text-muted small">
          <span class="badge bg-light text-dark border font-monospace">ADM: <?= e($admNo) ?></span>
          <span>&bull;</span>
          <span>Roll: <?= e((string)$rollNo) ?></span>
          <span>&bull;</span>
          <span><i data-lucide="book-open" style="width:12px;height:12px;" class="me-1"></i><?= e($className) ?> <?= e($sectionName ? '('.$sectionName.')' : '') ?></span>
          <span>&bull;</span>
          <span class="badge <?= $status === 'active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?> text-uppercase" style="font-size:10px;">
            <?= e($status) ?>
          </span>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex gap-2">
    <?php if (hasPermission('students.edit')): ?>
      <a href="<?= e(url('students/' . $student['id'] . '/edit')) ?>" class="btn btn-primary btn-sm d-flex align-items-center gap-1 px-3">
        <i data-lucide="edit-3" style="width:14px;height:14px;"></i> Edit Student
      </a>
    <?php endif; ?>
  </div>
</div>

<!-- Executive Metric Matrix -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Attendance Rate</div>
      <div class="fs-4 fw-bold text-success mt-1"><?= $attendance_rate ?>%</div>
      <div class="text-muted" style="font-size:11px;"><?= (int)($attendance_counts['present'] ?? 0) ?> Present (Last 90d)</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Fee Balance Due</div>
      <div class="fs-4 fw-bold <?= $hasOverdue ? 'text-danger' : 'text-success' ?> mt-1"><?= formatMoney($totalDue) ?></div>
      <div class="text-muted" style="font-size:11px;">
        <?= $hasOverdue ? 'Outstanding Balance' : 'Account Settled' ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Academic Standing</div>
      <div class="fs-4 fw-bold text-primary mt-1">
        <?php if (!empty($exam_results[0]['final_percentage'])): ?>
          <?= number_format((float)$exam_results[0]['final_percentage'], 1) ?>%
          <?php if (!empty($exam_results[0]['class_position'])): ?>
            <span class="fs-6 fw-normal text-muted">Rank #<?= e((string)$exam_results[0]['class_position']) ?></span>
          <?php endif; ?>
        <?php else: ?>
          Satisfactory
        <?php endif; ?>
      </div>
      <div class="text-muted" style="font-size:11px;">Latest Term Performance</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Enrollment Date</div>
      <div class="fs-5 fw-bold text-dark mt-1"><?= e($admDate) ?></div>
      <div class="text-muted" style="font-size:11px;">Official Admission</div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Left Column: Personal Dossier & Guardians -->
  <div class="col-lg-4">
    <!-- Personal Details -->
    <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white">
      <div class="card-header bg-white border-bottom pt-3 pb-2 px-4">
        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
          <i data-lucide="user" class="text-primary" style="width:16px;height:16px;"></i> Student Dossier
        </h6>
      </div>
      <div class="card-body p-4">
        <div class="mb-3">
          <div class="text-muted small">Date of Birth</div>
          <div class="fw-semibold text-dark"><?= e($dob) ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Gender</div>
          <div class="fw-semibold text-dark text-capitalize"><?= e($student['gender'] ?? 'Not Specified') ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Student Email</div>
          <div class="fw-semibold text-dark"><?= e($student['email'] ?: 'Not Provided') ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Contact Phone</div>
          <div class="fw-semibold text-dark"><?= e($student['phone'] ?: 'Not Provided') ?></div>
        </div>
        <?php if (!empty($student['address'])): ?>
          <div class="mb-3">
            <div class="text-muted small">Home Address</div>
            <div class="small text-secondary"><?= e($student['address']) ?></div>
          </div>
        <?php endif; ?>
        <?php if (!empty($student['emergency_contact'])): ?>
          <div class="mb-0 pt-2 border-top">
            <div class="text-danger small fw-semibold">Emergency Contact</div>
            <div class="fw-bold text-dark"><?= e($student['emergency_contact']) ?> &middot; <?= e($student['emergency_phone'] ?? '') ?></div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Guardian Info -->
    <div class="card border-0 shadow-sm rounded-4 bg-white">
      <div class="card-header bg-white border-bottom pt-3 pb-2 px-4">
        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
          <i data-lucide="users" class="text-primary" style="width:16px;height:16px;"></i> Linked Guardians
        </h6>
      </div>
      <div class="card-body p-4">
        <?php if (empty($parents)): ?>
          <div class="text-muted small">No guardian account linked to this student.</div>
        <?php else: ?>
          <div class="d-flex flex-column gap-3">
            <?php foreach ($parents as $p): ?>
              <div class="p-3 border rounded bg-light">
                <div class="fw-bold text-dark"><?= e($p['first_name'] . ' ' . $p['last_name']) ?></div>
                <div class="small text-muted mt-1">
                  <span class="badge bg-secondary-subtle text-secondary me-1"><?= e($p['relationship']) ?></span>
                  <?= e($p['phone'] ?: '') ?>
                </div>
                <?php if (!empty($p['email'])): ?>
                  <div class="small text-muted mt-1"><i data-lucide="mail" style="width:12px;height:12px;"></i> <?= e($p['email']) ?></div>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right Column: Tabs (Financials, Exams, Attendance, History) -->
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
      <div class="card-header bg-white border-bottom p-2">
        <ul class="nav nav-tabs border-0" id="studentDetailTabs" role="tablist">
          <li class="nav-item">
            <button class="nav-link active fw-semibold small" id="financials-tab" data-bs-toggle="tab" data-bs-target="#financials-pane" type="button" role="tab">
              <i data-lucide="receipt" style="width:14px;height:14px;" class="me-1"></i> Fee Invoices (<?= count($invoices ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link fw-semibold small" id="exams-tab" data-bs-toggle="tab" data-bs-target="#exams-pane" type="button" role="tab">
              <i data-lucide="award" style="width:14px;height:14px;" class="me-1"></i> Examination Records
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link fw-semibold small" id="history-tab" data-bs-toggle="tab" data-bs-target="#history-pane" type="button" role="tab">
              <i data-lucide="history" style="width:14px;height:14px;" class="me-1"></i> Academic History
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link fw-semibold small" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity-pane" type="button" role="tab">
              <i data-lucide="activity" style="width:14px;height:14px;" class="me-1"></i> Activity & Audit Trail (<?= count($timeline_logs ?? []) ?>)
            </button>
          </li>
        </ul>
      </div>

      <div class="card-body p-4">
        <div class="tab-content" id="studentTabContent">
          <!-- Financial Invoices Pane -->
          <div class="tab-pane fade show active" id="financials-pane" role="tabpanel">
            <?php if (empty($invoices)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="receipt" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No fee invoices recorded for this student.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Invoice No</th>
                      <th>Title</th>
                      <th>Due Date</th>
                      <th class="text-end">Total</th>
                      <th class="text-end">Due</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($invoices as $inv): 
                      $invSt = strtolower((string)$inv['status']);
                      $invBadge = match($invSt) {
                        'paid' => 'bg-success-subtle text-success',
                        'partial' => 'bg-warning-subtle text-warning-emphasis',
                        default => 'bg-danger-subtle text-danger',
                      };
                    ?>
                      <tr>
                        <td class="font-monospace small fw-bold">#<?= e($inv['invoice_no']) ?></td>
                        <td class="small fw-semibold"><?= e($inv['title']) ?></td>
                        <td class="small text-muted"><?= e($inv['due_date']) ?></td>
                        <td class="text-end small"><?= formatMoney((float)$inv['total_amount']) ?></td>
                        <td class="text-end small fw-bold <?= (float)$inv['due_amount'] > 0 ? 'text-danger' : 'text-success' ?>">
                          <?= formatMoney((float)$inv['due_amount']) ?>
                        </td>
                        <td class="text-center">
                          <span class="badge <?= $invBadge ?> text-uppercase" style="font-size:10px;">
                            <?= e($invSt) ?>
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Exams Pane -->
          <div class="tab-pane fade" id="exams-pane" role="tabpanel">
            <?php if (empty($exam_results)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="award" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No official examination results published yet for this student.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Assessment Title</th>
                      <th class="text-center">Total Marks</th>
                      <th class="text-center">Percentage</th>
                      <th class="text-center">Class Rank</th>
                      <th class="text-end">Official Transcript</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($exam_results as $er): ?>
                      <tr>
                        <td class="fw-semibold small"><?= e($er['exam_name']) ?></td>
                        <td class="text-center small"><?= e((string)$er['total_obtained_marks']) ?> / <?= e((string)$er['total_max_marks']) ?></td>
                        <td class="text-center fw-bold small text-primary"><?= number_format((float)$er['final_percentage'], 1) ?>%</td>
                        <td class="text-center small">
                          <?= !empty($er['class_position']) ? '#' . e((string)$er['class_position']) : 'N/A' ?>
                        </td>
                        <td class="text-end">
                          <a href="<?= e(url("exams/{$er['exam_id']}/report-card/{$student['id']}")) ?>" 
                             target="_blank" 
                             class="btn btn-sm btn-outline-primary py-1 px-2 d-inline-flex align-items-center gap-1"
                             style="font-size:11px;">
                            <i data-lucide="printer" style="width:12px;height:12px;"></i> View Transcript
                          </a>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Academic History Pane -->
          <div class="tab-pane fade" id="history-pane" role="tabpanel">
            <?php if (empty($history)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="history" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No past academic progression history on record.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Academic Session</th>
                      <th>Class & Section</th>
                      <th>Enrollment Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($history as $h): ?>
                      <tr>
                        <td class="fw-semibold small"><i data-lucide="calendar" style="width:12px;height:12px;" class="me-1 text-primary"></i> <?= e($h['academic_year']) ?></td>
                        <td class="small"><?= e(($h['class_name'] ?? '') . ' ' . ($h['section_name'] ?? '')) ?></td>
                        <td>
                          <span class="badge bg-primary-subtle text-primary rounded-pill px-2 py-1" style="font-size:10px;">
                            <?= e($h['result_status']) ?>
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Activity & Audit Timeline Pane -->
          <div class="tab-pane fade" id="activity-pane" role="tabpanel">
            <?php if (empty($timeline_logs)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="activity" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No logged audit actions or activities recorded for this student yet.</p>
              </div>
            <?php else: ?>
              <div class="timeline p-2">
                <?php foreach ($timeline_logs as $log): ?>
                  <div class="d-flex gap-3 mb-3 pb-3 border-bottom border-light">
                    <div class="rounded-circle bg-primary-subtle text-primary d-flex align-items-center justify-content-center flex-shrink-0" style="width: 32px; height: 32px;">
                      <i data-lucide="clock" style="width: 15px; height: 15px;"></i>
                    </div>
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="fw-bold text-dark small text-capitalize"><?= e(str_replace(['.', '_'], ' ', $log['action'])) ?></span>
                        <span class="text-muted" style="font-size: 11px;"><?= date('M j, Y g:i A', strtotime($log['created_at'])) ?></span>
                      </div>
                      <div class="text-muted small mb-1">
                        Initiated by <strong class="text-dark"><?= e($log['author_name'] ?? 'System') ?></strong>
                        <?php if (!empty($log['author_role'])): ?>
                          <span class="badge bg-light text-secondary border ms-1" style="font-size: 10px;"><?= e($log['author_role']) ?></span>
                        <?php endif; ?>
                      </div>
                      <div class="small text-secondary">
                        Module: <code><?= e($log['module']) ?></code> &middot; Entity: <?= e($log['entity_type']) ?> #<?= (int) $log['entity_id'] ?>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>