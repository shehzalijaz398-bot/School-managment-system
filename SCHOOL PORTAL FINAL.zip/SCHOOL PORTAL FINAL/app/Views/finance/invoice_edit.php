<div class="d-flex align-items-center mb-4">
    <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-light btn-sm me-3 d-flex align-items-center justify-content-center rounded-circle" style="width:36px;height:36px;">
        <i data-lucide="arrow-left" style="width:18px;"></i>
    </a>
    <div>
        <h2 class="mb-0 h4 fw-bold text-dark"><?= e($title) ?></h2>
        <div class="text-muted small">Modify invoice details (INV-<?= str_pad((string)$invoice['id'], 6, '0', STR_PAD_LEFT) ?>)</div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-4">
        <form method="post" action="<?= e(url("finance/invoices/{$invoice['id']}")) ?>">
            <?= csrf_field() ?>
            <div class="row g-4">
                <div class="col-md-12">
                    <label class="form-label text-muted fw-semibold small">Invoice Title *</label>
                    <input type="text" name="title" class="form-control" required value="<?= e($invoice['title'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted fw-semibold small">Amount *</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0 text-muted">$</span>
                        <input type="number" step="0.01" name="amount" class="form-control border-start-0 ps-0" required value="<?= e($invoice['amount'] ?? '') ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted fw-semibold small">Due Date *</label>
                    <input type="date" name="due_date" class="form-control" required value="<?= e($invoice['due_date'] ?? '') ?>">
                </div>
            </div>
            <div class="mt-4 pt-3 border-top d-flex gap-2">
                <button type="submit" class="btn btn-primary d-flex align-items-center gap-2">
                    <i data-lucide="save" style="width:16px;"></i> Save Changes
                </button>
                <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
