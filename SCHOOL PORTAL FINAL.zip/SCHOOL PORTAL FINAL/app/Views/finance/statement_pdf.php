<?php
$student = $student ?? [];
$school = $school ?? [];
$entries = $entries ?? [];
$asOf = $asOf ?? date('Y-m-d');
?>
<div class="print-container container mt-4 bg-white p-5 shadow-sm border rounded">
  <!-- Header -->
  <div class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
    <div>
      <h2 class="fw-bold mb-1"><?= htmlspecialchars($school['name'] ?? 'School Portal') ?></h2>
      <address class="text-muted small mb-0">
        <?= htmlspecialchars($school['address'] ?? '') ?><br>
        <?= htmlspecialchars($school['phone'] ?? '') ?> | <?= htmlspecialchars($school['email'] ?? '') ?>
      </address>
    </div>
    <div class="text-end">
      <h3 class="h4 text-uppercase text-primary fw-bold mb-1">Statement of Account</h3>
      <div class="small text-muted">Statement Date: <?= htmlspecialchars(date('M d, Y', strtotime((string)$asOf))) ?></div>
      <div class="small text-muted">Academic Session: <?= htmlspecialchars(date('Y')) ?></div>
    </div>
  </div>

  <!-- Student Info Box -->
  <div class="row mb-4">
    <div class="col-md-7">
      <div class="p-3 bg-light rounded border">
        <div class="text-muted small text-uppercase fw-bold">Student Profile</div>
        <div class="fs-5 fw-bold text-dark mt-1">
          <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
        </div>
        <div class="small text-muted">
          Admission No: <strong><?= htmlspecialchars($student['admission_no']) ?></strong> | 
          Class: <strong><?= htmlspecialchars($student['class_name'] ?? 'N/A') ?> <?= htmlspecialchars($student['section_name'] ?? '') ?></strong>
        </div>
        <?php if (!empty($student['parent_name'])): ?>
          <div class="small text-muted mt-1">Guardian / Parent: <?= htmlspecialchars($student['parent_name']) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-md-5">
      <div class="p-3 bg-light rounded border text-md-end">
        <div class="text-muted small text-uppercase fw-bold">Outstanding Balance</div>
        <?php
        $finalBalance = !empty($entries) ? (float) end($entries)['running_balance'] : 0.0;
        ?>
        <div class="fs-3 fw-bold <?= $finalBalance > 0 ? 'text-danger' : 'text-success' ?> font-monospace mt-1">
          $<?= number_format($finalBalance, 2) ?>
        </div>
        <div class="small text-muted">
          <?= $finalBalance > 0 ? 'Payment Required via School Portal / Cash Desk' : 'Account in Good Standing' ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Ledger Movements Table -->
  <table class="table table-bordered table-striped mb-4">
    <thead class="table-light text-uppercase small">
      <tr>
        <th style="width: 14%;">Date</th>
        <th style="width: 16%;">Reference #</th>
        <th style="width: 34%;">Transaction Particulars</th>
        <th class="text-end" style="width: 12%;">Invoiced ($)</th>
        <th class="text-end" style="width: 12%;">Paid ($)</th>
        <th class="text-end" style="width: 12%;">Balance ($)</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($entries)): ?>
        <tr>
          <td colspan="6" class="text-center py-4 text-muted">No financial movements recorded for this student.</td>
        </tr>
      <?php else: ?>
        <?php foreach ($entries as $e): ?>
          <tr>
            <td class="small"><?= htmlspecialchars($e['date'] ?? '') ?></td>
            <td class="font-monospace fw-bold text-dark small"><?= htmlspecialchars($e['reference'] ?? '') ?></td>
            <td class="small"><?= htmlspecialchars($e['description'] ?? '') ?></td>
            <td class="text-end font-monospace">
              <?= (float)$e['debit'] > 0 ? number_format((float)$e['debit'], 2) : '—' ?>
            </td>
            <td class="text-end font-monospace text-success">
              <?= (float)$e['credit'] > 0 ? number_format((float)$e['credit'], 2) : '—' ?>
            </td>
            <td class="text-end font-monospace fw-bold <?= (float)$e['running_balance'] > 0 ? 'text-danger' : 'text-dark' ?>">
              <?= number_format((float)$e['running_balance'], 2) ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
    <tfoot class="table-light border-top border-2 border-dark font-monospace fw-bold">
      <tr>
        <td colspan="5" class="text-end text-uppercase">Net Outstanding Balance Due:</td>
        <td class="text-end fs-5 <?= $finalBalance > 0 ? 'text-danger' : 'text-success' ?>">
          $<?= number_format($finalBalance, 2) ?>
        </td>
      </tr>
    </tfoot>
  </table>

  <!-- Official Signatures -->
  <div class="row pt-5 mt-5">
    <div class="col-6 text-center">
      <div class="border-top pt-2 small text-muted">Accounts Officer / Bursar Signature</div>
    </div>
    <div class="col-6 text-center">
      <div class="border-top pt-2 small text-muted">Institutional Stamp &amp; Principal Sign-off</div>
    </div>
  </div>
</div>
