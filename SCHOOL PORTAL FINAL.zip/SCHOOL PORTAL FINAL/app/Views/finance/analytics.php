<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= htmlspecialchars($title) ?></h1>
        <a href="<?= url('finance/reports/export-csv') ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="bi bi-download fa-sm text-white-50"></i> Export Financial Ledger (CSV)
        </a>
    </div>

    <!-- Chart row -->
    <div class="row">
        <!-- Monthly Collections Chart -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Monthly Fee Collection Trends</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area" style="position: relative; height: 300px; width: 100%;">
                        <canvas id="monthlyCollectionsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Expense Breakdown Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Expense Breakdown</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="position: relative; height: 250px; width: 100%;">
                        <canvas id="expenseBreakdownChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Defaulter Ratios Chart -->
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Fee Invoice Status (Defaulter Ratios)</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="position: relative; height: 300px; width: 100%;">
                        <canvas id="statusRatiosChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Monthly Collections
    const monthlyData = <?= json_encode($monthlyCollections) ?>;
    const months = monthlyData.map(item => item.month);
    const totals = monthlyData.map(item => item.total);

    new Chart(document.getElementById('monthlyCollectionsChart'), {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Collections',
                data: totals,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true
        }
    });

    // 2. Expense Breakdown
    const expenseData = <?= json_encode($expensesBreakdown) ?>;
    const expLabels = expenseData.map(item => item.category || 'Uncategorized');
    const expTotals = expenseData.map(item => item.total);

    new Chart(document.getElementById('expenseBreakdownChart'), {
        type: 'doughnut',
        data: {
            labels: expLabels,
            datasets: [{
                data: expTotals,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b']
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true
        }
    });

    // 3. Status Ratios
    const statusData = <?= json_encode($statusCounts) ?>;
    const statusLabels = statusData.map(item => item.status);
    const statusCounts = statusData.map(item => item.count);

    new Chart(document.getElementById('statusRatiosChart'), {
        type: 'pie',
        data: {
            labels: statusLabels,
            datasets: [{
                data: statusCounts,
                backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b']
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true
        }
    });
});
</script>
