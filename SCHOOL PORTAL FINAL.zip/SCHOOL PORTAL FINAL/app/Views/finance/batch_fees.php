<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i data-lucide="layers" class="text-primary me-2"></i> Mass Fee Generation</h2>
        <p class="text-muted mb-0">Generate bulk invoices for entire classes or the whole school instantly.</p>
    </div>
    <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-light border d-flex align-items-center gap-2 shadow-sm">
        <i data-lucide="arrow-left"></i> Back to Invoices
    </a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-0 p-4 pb-0">
                <h5 class="fw-bold mb-0">Batch Invoice Configuration</h5>
            </div>
            <div class="card-body p-4">
                <form method="post" action="<?= e(url('finance/fees/batch-generate')) ?>" id="massBillingForm">
                    <?= csrf_field() ?>
                    
                    <div class="row g-4 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-semibold">Target Class *</label>
                            <select name="class_id" class="form-select rounded-3 p-2" required>
                                <option value="">Select Target...</option>
                                <option value="all" class="fw-bold text-primary">All Classes (Entire School)</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>">Class <?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-semibold">Fee Category *</label>
                            <select name="fee_category_id" class="form-select rounded-3 p-2" required>
                                <option value="">Select Fee Type...</option>
                                <?php foreach ($categories as $cat): ?>
                                    <?php $amt = (float)($cat['amount'] ?? ($cat['default_amount'] ?? 0)); ?>
                                    <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?><?= $amt > 0 ? ' (' . e(formatMoney($amt)) . ')' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row g-4 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-semibold">Academic Year *</label>
                            <select name="academic_year_id" class="form-select rounded-3 p-2" required>
                                <?php foreach ($academic_years as $ay): ?>
                                    <option value="<?= $ay['id'] ?>" <?= $ay['is_active'] ? 'selected' : '' ?>><?= e($ay['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-semibold">Billing Month *</label>
                            <input type="month" name="billing_month" class="form-control rounded-3 p-2" value="<?= date('Y-m') ?>" required>
                        </div>
                    </div>

                    <div class="alert alert-info border-info bg-info bg-opacity-10 d-flex gap-3 align-items-center rounded-3 p-3 mb-4">
                        <i data-lucide="info" class="text-info" style="width:24px;height:24px;"></i>
                        <div class="small text-dark">
                            <strong>Note:</strong> The system will automatically inject transport fares into the invoice if a student is assigned to a transport route. Duplicates for the exact same category and month will be skipped automatically.
                        </div>
                    </div>

                    <button type="button" class="btn btn-primary btn-lg rounded-pill w-100 fw-bold shadow-sm d-flex align-items-center justify-content-center gap-2" onclick="confirmMassBilling()">
                        <i data-lucide="rocket"></i> Generate Mass Invoices
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function confirmMassBilling() {
    if (!document.getElementById('massBillingForm').checkValidity()) {
        document.getElementById('massBillingForm').reportValidity();
        return;
    }
    
    if (confirm("⚠️ Are you sure you want to process and generate bulk invoices for all matching students? This action cannot be undone.")) {
        document.getElementById('massBillingForm').submit();
    }
}
</script>
