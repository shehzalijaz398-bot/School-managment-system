<?php
$title = 'Student Fee Concessions & Waivers';
$adjustments = $adjustments ?? [];
$students = $students ?? [];
$categories = $categories ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="award" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Financial Aid &amp; Waivers
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Manage approved student tuition concessions, sibling discounts, staff child waivers, and merit aid.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newConcessionModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> Grant Concession
    </button>
    <a href="<?= e(url('finance/discounts')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="percent" style="width: 14px; height: 14px;"></i> Discount Catalog
    </a>
  </div>
</div>

<!-- Concessions Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3">Student Name</th>
            <th>Admission #</th>
            <th>Class</th>
            <th>Adjustment Type</th>
            <th>Category Scope</th>
            <th>Concession Value</th>
            <th>Reason / Justification</th>
            <th class="pe-3">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($adjustments)): ?>
            <tr>
              <td colspan="8" class="text-center py-4 text-muted">No student fee concessions or waivers recorded yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($adjustments as $a): ?>
              <tr>
                <td class="ps-3 fw-bold text-dark"><?= e($a['first_name'] . ' ' . $a['last_name']) ?></td>
                <td class="font-monospace text-muted small"><?= e($a['admission_no']) ?></td>
                <td><?= e($a['class_name'] ?? '—') ?></td>
                <td>
                  <span class="badge bg-info-subtle text-info border text-uppercase small">
                    <?= e($a['adjustment_type']) ?>
                  </span>
                </td>
                <td class="small text-muted"><?= e($a['category_name'] ?? 'All Tuition') ?></td>
                <td class="font-monospace fw-bold text-success">
                  <?= $a['calculation_type'] === 'percentage' ? e($a['value']) . '%' : formatMoney((float)$a['value']) ?>
                </td>
                <td class="small"><?= e($a['reason']) ?></td>
                <td class="pe-3">
                  <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0 small">
                    <?= ucfirst(e($a['status'])) ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Grant Concession -->
<div class="modal fade" id="newConcessionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('finance/concessions')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold">Grant Student Concession / Waiver</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Target Student <span class="text-danger">*</span></label>
            <select name="student_id" class="form-select form-select-sm" required>
              <option value="">-- Select Student --</option>
              <?php foreach ($students as $s): ?>
                <option value="<?= $s['id'] ?>">
                  <?= e($s['first_name'] . ' ' . $s['last_name']) ?> (<?= e($s['admission_no']) ?> - <?= e($s['class_name'] ?? '') ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Adjustment Type</label>
              <select name="adjustment_type" class="form-select form-select-sm">
                <option value="concession">Sibling Concession</option>
                <option value="scholarship">Merit Scholarship</option>
                <option value="waiver">Staff Child Waiver</option>
                <option value="special_discount">Hardship Relief</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Calculation Type</label>
              <select name="calculation_type" class="form-select form-select-sm">
                <option value="fixed">Fixed Dollar Amount ($)</option>
                <option value="percentage">Percentage Discount (%)</option>
              </select>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Discount Value <span class="text-danger">*</span></label>
            <input type="number" step="0.01" min="0" name="value" placeholder="e.g. 50.00 or 25" class="form-control form-control-sm" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Specific Fee Category (Optional)</label>
            <select name="fee_category_id" class="form-select form-select-sm">
              <option value="">-- Applies to Overall Invoice --</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Reason &amp; Committee Approval Note <span class="text-danger">*</span></label>
            <textarea name="reason" rows="2" class="form-control form-control-sm" placeholder="Provide governance justification..." required></textarea>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Grant Concession</button>
        </div>
      </form>
    </div>
  </div>
</div>
