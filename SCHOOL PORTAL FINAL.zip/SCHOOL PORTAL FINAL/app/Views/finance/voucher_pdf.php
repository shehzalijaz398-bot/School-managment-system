<?php
$voucher = $voucher ?? [];
$school = $school ?? [];
?>
<div class="print-container container mt-4 bg-white p-5 shadow-sm border rounded">
  <div class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
    <div>
      <h2 class="fw-bold mb-1"><?= htmlspecialchars($school['name'] ?? 'School Portal') ?></h2>
      <address class="text-muted small mb-0">
        <?= htmlspecialchars($school['address'] ?? '') ?><br>
        <?= htmlspecialchars($school['phone'] ?? '') ?> | <?= htmlspecialchars($school['email'] ?? '') ?>
      </address>
    </div>
    <div class="text-end">
      <h3 class="h4 text-uppercase text-primary fw-bold mb-1">Payment Voucher</h3>
      <div class="font-monospace fw-bold fs-5 text-dark"><?= htmlspecialchars($voucher['voucher_no']) ?></div>
      <div class="small text-muted">Date: <?= htmlspecialchars(date('M d, Y', strtotime((string)$voucher['created_at']))) ?></div>
      <span class="badge bg-success-subtle text-success border border-success-subtle text-uppercase px-2 py-1 mt-1">
        <?= htmlspecialchars($voucher['status']) ?>
      </span>
    </div>
  </div>

  <div class="row mb-4">
    <div class="col-md-6">
      <div class="p-3 bg-light rounded border">
        <div class="text-muted small text-uppercase fw-bold">Payee Details</div>
        <div class="fs-5 fw-bold text-dark mt-1"><?= htmlspecialchars($voucher['payee_name']) ?></div>
        <div class="small text-muted">Voucher Classification: <?= ucfirst(htmlspecialchars($voucher['voucher_type'])) ?></div>
        <?php if (!empty($voucher['reference_no'])): ?>
          <div class="small text-muted">Bill / Ref #: <?= htmlspecialchars($voucher['reference_no']) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-md-6">
      <div class="p-3 bg-light rounded border">
        <div class="text-muted small text-uppercase fw-bold">Disbursement Breakdown</div>
        <div class="d-flex justify-content-between align-items-center mt-1">
          <span class="text-muted small">Disbursement Method:</span>
          <span class="fw-semibold text-dark text-uppercase"><?= htmlspecialchars($voucher['payment_method']) ?></span>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-1">
          <span class="text-muted small">Accounting Ledger:</span>
          <span class="fw-semibold text-dark"><?= htmlspecialchars($voucher['account_name'] ?? 'General Operating') ?></span>
        </div>
      </div>
    </div>
  </div>

  <table class="table table-bordered mb-4">
    <thead class="table-light text-uppercase small">
      <tr>
        <th>Particulars / Description</th>
        <th class="text-end" style="width: 25%;">Amount ($)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <div class="fw-semibold text-dark"><?= htmlspecialchars($voucher['description'] ?: 'Official institutional disbursement') ?></div>
          <div class="small text-muted mt-1">Chargeable to: <?= htmlspecialchars($voucher['account_code'] ?? '5000') ?> - <?= htmlspecialchars($voucher['account_name'] ?? 'Operating Fund') ?></div>
        </td>
        <td class="text-end font-monospace fw-bold fs-5 text-dark">
          <?= number_format((float)$voucher['amount'], 2) ?>
        </td>
      </tr>
    </tbody>
    <tfoot class="table-light">
      <tr>
        <th class="text-end text-uppercase">Total Authorized Disbursement</th>
        <th class="text-end font-monospace fs-4 text-primary fw-bold">
          $<?= number_format((float)$voucher['amount'], 2) ?>
        </th>
      </tr>
    </tfoot>
  </table>

  <div class="row pt-5 mt-5">
    <div class="col-4 text-center">
      <div class="border-top pt-2 small text-muted">Prepared By / Cashier</div>
    </div>
    <div class="col-4 text-center">
      <div class="border-top pt-2 small text-muted">Accountant / Bursar</div>
    </div>
    <div class="col-4 text-center">
      <div class="border-top pt-2 small text-muted">Authorized Signatory / Principal</div>
    </div>
  </div>
</div>
