<?php
$title = 'Payment & Disbursement Vouchers';
$vouchers = $vouchers ?? [];
$accounts = $accounts ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="file-check" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Disbursements
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Issue, authorize, and archive formal payment vouchers with supporting invoices and audit attachments.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newVoucherModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> Create Payment Voucher
    </button>
    <a href="<?= e(url('finance/expenses')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Expenses
    </a>
  </div>
</div>

<!-- Vouchers Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3">Voucher #</th>
            <th>Payee Name</th>
            <th>Type</th>
            <th>Method</th>
            <th>Expense Account</th>
            <th class="text-end">Amount ($)</th>
            <th>Status</th>
            <th>Authorized By</th>
            <th class="text-end pe-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($vouchers)): ?>
            <tr>
              <td colspan="9" class="text-center py-4 text-muted">No disbursement vouchers recorded yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($vouchers as $v): ?>
              <tr>
                <td class="ps-3 font-monospace fw-bold text-primary"><?= e($v['voucher_no']) ?></td>
                <td class="fw-semibold text-dark"><?= e($v['payee_name']) ?></td>
                <td><span class="badge bg-light text-dark border text-uppercase small"><?= e($v['voucher_type']) ?></span></td>
                <td><?= ucfirst(e($v['payment_method'])) ?></td>
                <td class="small text-muted"><?= e($v['account_name'] ?? 'General Operating') ?></td>
                <td class="text-end font-monospace fw-bold text-dark fs-6"><?= number_format((float)$v['amount'], 2) ?></td>
                <td>
                  <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0 small">
                    <?= ucfirst(e($v['status'])) ?>
                  </span>
                </td>
                <td class="small text-muted"><?= e($v['approved_by_name'] ?? 'Admin') ?></td>
                <td class="text-end pe-3">
                  <a href="<?= e(url('finance/vouchers/' . $v['id'] . '/pdf')) ?>" target="_blank" class="btn btn-sm btn-outline-dark py-0 px-2">
                    <i data-lucide="printer" style="width: 13px; height: 13px;"></i> Print Voucher
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: New Payment Voucher -->
<div class="modal fade" id="newVoucherModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('finance/vouchers')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold">New Payment / Disbursement Voucher</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Payee Name (Vendor / Staff / Beneficiary) <span class="text-danger">*</span></label>
            <input type="text" name="payee_name" placeholder="e.g. Acme Stationery Supplies" class="form-control form-control-sm" required>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Amount ($) <span class="text-danger">*</span></label>
              <input type="number" step="0.01" min="0.01" name="amount" placeholder="0.00" class="form-control form-control-sm" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Payment Method</label>
              <select name="payment_method" class="form-select form-select-sm">
                <option value="cash">Cash in Hand</option>
                <option value="bank">Bank Transfer</option>
                <option value="cheque">Cheque</option>
                <option value="online">Online / Card</option>
              </select>
            </div>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Voucher Type</label>
              <select name="voucher_type" class="form-select form-select-sm">
                <option value="expense">Vendor Expense</option>
                <option value="salary_advance">Salary Advance</option>
                <option value="refund">Fee Refund</option>
                <option value="petty_cash">Petty Cash</option>
                <option value="other">Other Disbursement</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Expense Account</label>
              <select name="account_id" class="form-select form-select-sm">
                <option value="">-- General Operating --</option>
                <?php foreach ($accounts as $acc): ?>
                  <option value="<?= $acc['id'] ?>"><?= e($acc['code']) ?> - <?= e($acc['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Bill / Reference Number</label>
            <input type="text" name="reference_no" placeholder="e.g. INV-98421 or CHQ-4029" class="form-control form-control-sm">
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Disbursement Description</label>
            <textarea name="description" rows="2" class="form-control form-control-sm" placeholder="Provide expenditure details..."></textarea>
          </div>
          <div class="mb-2">
            <label class="form-label small fw-semibold">Supporting Invoice / Receipt Document (PDF or Image)</label>
            <input type="file" name="supporting_doc" accept=".pdf,.jpg,.jpeg,.png" class="form-control form-control-sm">
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Issue Voucher</button>
        </div>
      </form>
    </div>
  </div>
</div>
