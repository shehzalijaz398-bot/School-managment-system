<div class="panel">
  <h2>Invoice <?= e($invoice['invoice_no']) ?></h2>
  <p><?= e($student['first_name'].' '.$student['last_name']) ?> · <?= e($invoice['title']) ?> · <?= statusBadge($invoice['status']) ?></p>
  <table class="table"><thead><tr><th>Description</th><th>Amount</th></tr></thead><tbody>
  <?php foreach ($items as $it): ?><tr><td><?= e($it['description']) ?></td><td><?= e(formatMoney($it['amount'])) ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <p>Total: <strong><?= e(formatMoney($invoice['total_amount'])) ?></strong> · Paid: <strong><?= e(formatMoney($invoice['paid_amount'])) ?></strong></p>
  <h3>Payments</h3>
  <table class="table table-sm"><thead><tr><th>Receipt</th><th>Amount</th><th>Method</th><th>Date</th></tr></thead><tbody>
  <?php foreach ($payments as $p): ?><tr><td><?= e($p['receipt_no']) ?></td><td><?= e(formatMoney($p['amount'])) ?></td><td><?= e($p['payment_method']) ?></td><td><?= e(formatDate($p['payment_date'])) ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <?php if (hasPermission('finance.manage') && $invoice['status'] !== 'paid'): ?>
  <form method="post" action="<?= e(url('finance/invoices/'.$invoice['id'].'/payments')) ?>" class="row g-2 mt-3"><?= csrf_field() ?>
    <div class="col-md-3"><input name="amount" class="form-control" required placeholder="Amount"></div>
    <div class="col-md-3"><select name="payment_method" class="form-select"><option>cash</option><option>bank</option><option>card</option><option>online</option></select></div>
    <div class="col-md-3"><input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
    <div class="col-md-3"><button class="btn btn-primary w-100">Record Payment</button></div>
  </form>
  <?php endif; ?>
</div>
