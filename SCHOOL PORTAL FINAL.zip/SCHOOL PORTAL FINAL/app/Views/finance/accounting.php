<?php
$title = 'Double-Entry Accounting & Chart of Accounts';
$accounts = $accounts ?? [];
$journalEntries = $journalEntries ?? [];
$trialBalance = $trialBalance ?? [];
$balanceSheet = $balanceSheet ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="book-open" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded-pill small">
        GAAP Standard
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      General Ledger, automated double-entry postings, Chart of Accounts, and real-time trial balance balancing.
    </p>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newJournalModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> Post Journal Entry
    </button>
    <a href="<?= e(url('finance/trial-balance')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="scale" style="width: 14px; height: 14px;"></i> Trial Balance
    </a>
    <a href="<?= e(url('finance/balance-sheet')) ?>" class="btn btn-outline-info btn-sm d-flex align-items-center gap-1">
      <i data-lucide="file-text" style="width: 14px; height: 14px;"></i> Balance Sheet
    </a>
    <a href="<?= e(url('reports/income-statement')) ?>" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="trending-up" style="width: 14px; height: 14px;"></i> P&amp;L Statement
    </a>
  </div>
</div>

<!-- Accounting KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-primary">
      <div class="text-muted small fw-medium text-uppercase">Total Ledger Assets</div>
      <div class="h4 mb-0 fw-bold text-dark mt-1">
        <?= formatMoney((float) ($balanceSheet['total_assets'] ?? 0)) ?>
      </div>
      <div class="small text-muted mt-1">Cash, Bank &amp; Receivables</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-danger">
      <div class="text-muted small fw-medium text-uppercase">Total Liabilities</div>
      <div class="h4 mb-0 fw-bold text-dark mt-1">
        <?= formatMoney((float) ($balanceSheet['total_liabilities'] ?? 0)) ?>
      </div>
      <div class="small text-muted mt-1">Payables &amp; Deposits</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-success">
      <div class="text-muted small fw-medium text-uppercase">Net Operating Surplus</div>
      <div class="h4 mb-0 fw-bold <?= ((float)($balanceSheet['net_surplus'] ?? 0)) >= 0 ? 'text-success' : 'text-danger' ?> mt-1">
        <?= formatMoney((float) ($balanceSheet['net_surplus'] ?? 0)) ?>
      </div>
      <div class="small text-muted mt-1">Revenues minus Expenses</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 <?= ($trialBalance['is_balanced'] ?? true) ? 'border-info' : 'border-warning' ?>">
      <div class="text-muted small fw-medium text-uppercase">Ledger Balance Status</div>
      <div class="h5 mb-0 fw-bold <?= ($trialBalance['is_balanced'] ?? true) ? 'text-info' : 'text-danger' ?> mt-1 d-flex align-items-center gap-1">
        <?php if ($trialBalance['is_balanced'] ?? true): ?>
          <i data-lucide="check-circle-2" style="width: 18px; height: 18px;"></i> In Balance (100%)
        <?php else: ?>
          <i data-lucide="alert-triangle" style="width: 18px; height: 18px;"></i> Discrepancy: $<?= number_format((float)($trialBalance['discrepancy'] ?? 0), 2) ?>
        <?php endif; ?>
      </div>
      <div class="small text-muted mt-1">Debits equal Credits invariant</div>
    </div>
  </div>
</div>

<!-- Tabs: Chart of Accounts & Recent Journal Entries -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-header bg-white border-bottom p-3">
    <ul class="nav nav-tabs card-header-tabs" id="accountingTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active fw-semibold" id="coa-tab" data-bs-toggle="tab" data-bs-target="#coa" type="button" role="tab">
          <i data-lucide="list-tree" class="me-1" style="width: 16px; height: 16px;"></i> Chart of Accounts (<?= count($accounts) ?>)
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link fw-semibold" id="journal-tab" data-bs-toggle="tab" data-bs-target="#journal" type="button" role="tab">
          <i data-lucide="history" class="me-1" style="width: 16px; height: 16px;"></i> General Journal Entries (<?= count($journalEntries) ?>)
        </button>
      </li>
    </ul>
  </div>
  <div class="card-body p-0">
    <div class="tab-content" id="accountingTabsContent">
      <!-- Tab 1: Chart of Accounts -->
      <div class="tab-pane fade show active" id="coa" role="tabpanel">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
              <tr>
                <th class="ps-3">Code</th>
                <th>Account Name</th>
                <th>Classification</th>
                <th>Description</th>
                <th class="text-end">Current Balance</th>
                <th class="text-end pe-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($accounts)): ?>
                <tr>
                  <td colspan="6" class="text-center py-4 text-muted">No accounts found. Standard Chart of Accounts will be automatically initialized.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($accounts as $a): ?>
                  <tr>
                    <td class="ps-3 font-monospace fw-bold text-primary"><?= e($a['code']) ?></td>
                    <td class="fw-semibold text-dark">
                      <?= e($a['name']) ?>
                      <?php if (!empty($a['is_system'])): ?>
                        <span class="badge bg-light text-muted border ms-1 small">System</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php
                      $badgeClass = match ($a['type']) {
                          'asset' => 'bg-primary-subtle text-primary border-primary-subtle',
                          'liability' => 'bg-danger-subtle text-danger border-danger-subtle',
                          'equity' => 'bg-info-subtle text-info border-info-subtle',
                          'revenue' => 'bg-success-subtle text-success border-success-subtle',
                          'expense' => 'bg-warning-subtle text-warning border-warning-subtle',
                          default => 'bg-secondary-subtle text-secondary',
                      };
                      ?>
                      <span class="badge <?= $badgeClass ?> border px-2 py-1 text-uppercase small">
                        <?= e($a['type']) ?>
                      </span>
                    </td>
                    <td class="small text-muted"><?= e($a['description'] ?? '—') ?></td>
                    <td class="text-end fw-bold font-monospace">
                      <?= formatMoney((float) $a['current_balance']) ?>
                    </td>
                    <td class="text-end pe-3">
                      <a href="<?= e(url('finance/ledger/account/' . $a['id'])) ?>" class="btn btn-sm btn-outline-primary py-0 px-2">
                        View Ledger
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Tab 2: Journal Entries -->
      <div class="tab-pane fade" id="journal" role="tabpanel">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
              <tr>
                <th class="ps-3">Entry #</th>
                <th>Date</th>
                <th>Source / Ref</th>
                <th>Description</th>
                <th class="text-end">Total Debit</th>
                <th class="text-end">Total Credit</th>
                <th>Status</th>
                <th class="pe-3">Posted By</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($journalEntries)): ?>
                <tr>
                  <td colspan="8" class="text-center py-4 text-muted">No journal entries recorded yet. Automated entries will be generated when invoices and payments are recorded.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($journalEntries as $j): ?>
                  <tr>
                    <td class="ps-3 font-monospace fw-bold text-dark"><?= e($j['entry_no']) ?></td>
                    <td><?= e($j['entry_date']) ?></td>
                    <td>
                      <span class="badge bg-light text-dark border text-uppercase small">
                        <?= e($j['reference_type']) ?> <?= $j['reference_id'] ? '#' . e($j['reference_id']) : '' ?>
                      </span>
                    </td>
                    <td><?= e($j['description']) ?></td>
                    <td class="text-end font-monospace fw-semibold text-dark"><?= formatMoney((float)$j['total_debit']) ?></td>
                    <td class="text-end font-monospace fw-semibold text-dark"><?= formatMoney((float)$j['total_credit']) ?></td>
                    <td>
                      <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0 small">
                        <?= ucfirst(e($j['status'])) ?>
                      </span>
                    </td>
                    <td class="pe-3 small text-muted"><?= e($j['created_by_name'] ?? 'System Automation') ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Post Journal Entry -->
<div class="modal fade" id="newJournalModal" tabindex="-1" aria-labelledby="newJournalModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('finance/journal-entries')) ?>" id="journalEntryForm">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold" id="newJournalModalLabel">
            <i data-lucide="plus-circle" class="text-primary me-1" style="width: 20px; height: 20px;"></i>
            Post Double-Entry Journal Entry
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="row g-3 mb-3">
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Entry Date <span class="text-danger">*</span></label>
              <input type="date" name="entry_date" value="<?= date('Y-m-d') ?>" class="form-control form-control-sm" required>
            </div>
            <div class="col-md-8">
              <label class="form-label small fw-semibold">Description / Narration <span class="text-danger">*</span></label>
              <input type="text" name="description" placeholder="e.g. Monthly utility settlement or adjustment" class="form-control form-control-sm" required>
            </div>
          </div>

          <h6 class="fw-bold small text-muted text-uppercase mb-2">Debit &amp; Credit Ledger Lines (Min 2)</h6>
          <div class="table-responsive mb-3">
            <table class="table table-bordered table-sm align-middle" id="journalLinesTable">
              <thead class="table-light small">
                <tr>
                  <th style="width: 45%;">Account</th>
                  <th style="width: 25%;">Debit ($)</th>
                  <th style="width: 25%;">Credit ($)</th>
                  <th style="width: 5%;"></th>
                </tr>
              </thead>
              <tbody id="linesContainer">
                <tr>
                  <td>
                    <select name="account_id[]" class="form-select form-select-sm" required>
                      <option value="">-- Select Account --</option>
                      <?php foreach ($accounts as $acc): ?>
                        <option value="<?= $acc['id'] ?>"><?= e($acc['code']) ?> - <?= e($acc['name']) ?> (<?= ucfirst($acc['type']) ?>)</option>
                      <?php endforeach; ?>
                    </select>
                  </td>
                  <td>
                    <input type="number" step="0.01" min="0" name="debit[]" class="form-control form-control-sm debit-input" placeholder="0.00" oninput="calculateJournalTotals()">
                  </td>
                  <td>
                    <input type="number" step="0.01" min="0" name="credit[]" class="form-control form-control-sm credit-input" placeholder="0.00" oninput="calculateJournalTotals()">
                  </td>
                  <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-danger p-0 px-1" onclick="removeJournalLine(this)">✕</button>
                  </td>
                </tr>
                <tr>
                  <td>
                    <select name="account_id[]" class="form-select form-select-sm" required>
                      <option value="">-- Select Account --</option>
                      <?php foreach ($accounts as $acc): ?>
                        <option value="<?= $acc['id'] ?>"><?= e($acc['code']) ?> - <?= e($acc['name']) ?> (<?= ucfirst($acc['type']) ?>)</option>
                      <?php endforeach; ?>
                    </select>
                  </td>
                  <td>
                    <input type="number" step="0.01" min="0" name="debit[]" class="form-control form-control-sm debit-input" placeholder="0.00" oninput="calculateJournalTotals()">
                  </td>
                  <td>
                    <input type="number" step="0.01" min="0" name="credit[]" class="form-control form-control-sm credit-input" placeholder="0.00" oninput="calculateJournalTotals()">
                  </td>
                  <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-danger p-0 px-1" onclick="removeJournalLine(this)">✕</button>
                  </td>
                </tr>
              </tbody>
              <tfoot class="table-light fw-bold font-monospace">
                <tr>
                  <td class="text-end">Totals:</td>
                  <td><span id="totalDebitDisplay">$0.00</span></td>
                  <td><span id="totalCreditDisplay">$0.00</span></td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <button type="button" class="btn btn-outline-primary btn-sm" onclick="addJournalLine()">
              <i data-lucide="plus" style="width: 14px; height: 14px;"></i> Add Line
            </button>
            <div id="balanceAlert" class="small fw-semibold text-danger">
              ⚠️ Debits ($0.00) must equal Credits ($0.00).
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" id="submitJournalBtn" class="btn btn-primary btn-sm" disabled>Post Journal Entry</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function calculateJournalTotals() {
  let totalDebit = 0;
  let totalCredit = 0;

  document.querySelectorAll('.debit-input').forEach(input => {
    totalDebit += parseFloat(input.value) || 0;
  });
  document.querySelectorAll('.credit-input').forEach(input => {
    totalCredit += parseFloat(input.value) || 0;
  });

  totalDebit = Math.round(totalDebit * 100) / 100;
  totalCredit = Math.round(totalCredit * 100) / 100;

  document.getElementById('totalDebitDisplay').textContent = '$' + totalDebit.toFixed(2);
  document.getElementById('totalCreditDisplay').textContent = '$' + totalCredit.toFixed(2);

  const alertEl = document.getElementById('balanceAlert');
  const submitBtn = document.getElementById('submitJournalBtn');

  if (totalDebit > 0 && Math.abs(totalDebit - totalCredit) <= 0.01) {
    alertEl.className = 'small fw-semibold text-success';
    alertEl.innerHTML = '✓ Entry is balanced! ($' + totalDebit.toFixed(2) + ')';
    submitBtn.disabled = false;
  } else {
    alertEl.className = 'small fw-semibold text-danger';
    alertEl.innerHTML = '⚠️ Debits ($' + totalDebit.toFixed(2) + ') must equal Credits ($' + totalCredit.toFixed(2) + ').';
    submitBtn.disabled = true;
  }
}

function addJournalLine() {
  const container = document.getElementById('linesContainer');
  const firstRow = container.querySelector('tr');
  const newRow = firstRow.cloneNode(true);
  newRow.querySelectorAll('input').forEach(i => i.value = '');
  newRow.querySelector('select').selectedIndex = 0;
  container.appendChild(newRow);
  calculateJournalTotals();
}

function removeJournalLine(btn) {
  const container = document.getElementById('linesContainer');
  if (container.querySelectorAll('tr').length > 2) {
    btn.closest('tr').remove();
    calculateJournalTotals();
  } else {
    alert('A double-entry journal entry must have at least two lines.');
  }
}
</script>
