<?php
$currentRange = $range ?? 'month';
?>

<div class="cc-finance-wrapper">
    <!-- Breadcrumb & Header Bar -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                    <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Finance</a></li>
                    <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Dashboard</li>
                </ol>
            </nav>
            <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Finance</h2>
            <p class="text-muted small mb-0">School fee billings, collections, and student account balances.</p>
        </div>

        <!-- Right Controls: Range Switcher & Action Buttons -->
        <div class="d-flex flex-wrap align-items-center gap-2">
            <!-- Range Switcher -->
            <div class="p-1 bg-white border rounded-pill shadow-sm d-inline-flex align-items-center me-2">
                <a href="<?= e(url('finance?range=week')) ?>" 
                   class="btn btn-sm rounded-pill px-3 py-1 fw-medium shadow-none <?= ($currentRange === 'week') ? 'btn-primary text-white' : 'text-muted' ?>" 
                   style="<?= ($currentRange === 'week') ? 'background:#4f46e5; border-color:#4f46e5;' : '' ?> font-size: 0.82rem;">
                    Week
                </a>
                <a href="<?= e(url('finance?range=month')) ?>" 
                   class="btn btn-sm rounded-pill px-3 py-1 fw-medium shadow-none <?= ($currentRange === 'month') ? 'btn-primary text-white' : 'text-muted' ?>" 
                   style="<?= ($currentRange === 'month') ? 'background:#4f46e5; border-color:#4f46e5;' : '' ?> font-size: 0.82rem;">
                    Month
                </a>
                <a href="<?= e(url('finance?range=term')) ?>" 
                   class="btn btn-sm rounded-pill px-3 py-1 fw-medium shadow-none <?= ($currentRange === 'term') ? 'btn-primary text-white' : 'text-muted' ?>" 
                   style="<?= ($currentRange === 'term') ? 'background:#4f46e5; border-color:#4f46e5;' : '' ?> font-size: 0.82rem;">
                    Term
                </a>
                <a href="<?= e(url('finance?range=session')) ?>" 
                   class="btn btn-sm rounded-pill px-3 py-1 fw-medium shadow-none <?= ($currentRange === 'session') ? 'btn-primary text-white' : 'text-muted' ?>" 
                   style="<?= ($currentRange === 'session') ? 'background:#4f46e5; border-color:#4f46e5;' : '' ?> font-size: 0.82rem;">
                    Session
                </a>
            </div>

            <!-- Invoices Button -->
            <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-sm btn-white border border-light-subtle rounded-3 px-3 py-2 fw-medium text-dark shadow-sm d-flex align-items-center gap-1" style="font-size: 0.84rem; background: #fff;">
                <i data-lucide="file-text" style="width: 15px; height: 15px; color: #64748b;"></i> Invoices
            </a>

            <!-- Payments Button -->
            <a href="<?= e(url('finance/ledger')) ?>" class="btn btn-sm btn-white border border-light-subtle rounded-3 px-3 py-2 fw-medium text-dark shadow-sm d-flex align-items-center gap-1" style="font-size: 0.84rem; background: #fff;">
                <i data-lucide="credit-card" style="width: 15px; height: 15px; color: #64748b;"></i> Payments
            </a>

            <!-- + New Invoice Button -->
            <button type="button" class="btn btn-sm text-white rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm" 
                    style="background: #4f46e5; font-size: 0.84rem;" data-bs-toggle="modal" data-bs-target="#newInvoiceModal">
                <i data-lucide="plus" style="width: 15px; height: 15px;"></i> New Invoice
            </button>
        </div>
    </div>

    <!-- Top 4 KPI Cards -->
    <div class="row g-3 mb-4">
        <!-- 1. Total Collected -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-1 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-secondary small fw-medium">Total Collected</span>
                            <span class="badge rounded-pill fw-semibold" style="background: #ecfdf5; color: #059669; font-size: 0.76rem; border: 1px solid #a7f3d0;">
                                ↗ <?= number_format($collectedRate, 1) ?>%
                            </span>
                        </div>
                        <h3 class="fw-bold text-dark mb-2" style="font-size: 1.85rem; letter-spacing: -0.02em;">
                            ₹<?= number_format($totalCollected, 2) ?>
                        </h3>
                        
                        <!-- Progress bar with of Billed label -->
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <div class="progress flex-grow-1" style="height: 6px; background-color: #f1f5f9; border-radius: 999px;">
                                <div class="progress-bar rounded-pill" role="progressbar" style="width: <?= min(100, $collectedRate) ?>%; background-color: #10b981;" aria-valuenow="<?= $collectedRate ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <span class="text-muted" style="font-size: 0.72rem;">of ₹<?= number_format($totalBilled, 2) ?></span>
                        </div>
                    </div>
                    <div class="text-muted small pt-2 border-top" style="font-size: 0.75rem; border-color: #f1f5f9 !important;">
                        Active academic session revenue
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Total Billed -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-1 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-secondary small fw-medium">Total Billed</span>
                            <div class="rounded-2 d-flex align-items-center justify-content-center" style="width: 26px; height: 26px; background: #e0e7ff; color: #4338ca;">
                                <i data-lucide="receipt" style="width: 14px; height: 14px;"></i>
                            </div>
                        </div>
                        <h3 class="fw-bold text-dark mb-2" style="font-size: 1.85rem; letter-spacing: -0.02em;">
                            ₹<?= number_format($totalBilled, 2) ?>
                        </h3>
                        <div class="text-muted small mb-2" style="font-size: 0.78rem;">
                            Full session charges issued
                        </div>
                    </div>
                    <div class="text-muted small pt-2 border-top" style="font-size: 0.75rem; border-color: #f1f5f9 !important;">
                        Cumulative student fee billings
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. Outstanding Balance -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-1 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-secondary small fw-medium">Outstanding Balance</span>
                            <span class="badge rounded-pill fw-semibold" style="background: #fef2f2; color: #dc2626; font-size: 0.76rem; border: 1px solid #fecaca;">
                                <?= number_format($unpaidRate, 1) ?>% unpaid
                            </span>
                        </div>
                        <h3 class="fw-bold mb-2" style="font-size: 1.85rem; letter-spacing: -0.02em; color: #dc2626;">
                            ₹<?= number_format($outstandingBalance, 2) ?>
                        </h3>
                        <div class="text-muted small mb-2" style="font-size: 0.78rem;">
                            Remaining session balance
                        </div>
                    </div>
                    <div class="text-muted small pt-2 border-top" style="font-size: 0.75rem; border-color: #f1f5f9 !important;">
                        Pending student payments
                    </div>
                </div>
            </div>
        </div>

        <!-- 4. Past Due Invoices -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-1 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-secondary small fw-medium">Past Due Invoices</span>
                            <span class="badge rounded-pill fw-semibold d-inline-flex align-items-center gap-1" style="background: #fffbeb; color: #b45309; font-size: 0.76rem; border: 1px solid #fde68a;">
                                <i data-lucide="alert-circle" style="width: 12px; height: 12px;"></i> Action needed
                            </span>
                        </div>
                        <div class="d-flex align-items-baseline gap-2 mb-2">
                            <h3 class="fw-bold text-dark mb-0" style="font-size: 1.85rem; letter-spacing: -0.02em;">
                                <?= (int)$pastDueCount ?>
                            </h3>
                            <span class="text-muted small" style="font-size: 0.85rem;">invoices</span>
                        </div>
                        <div class="text-muted small mb-2" style="font-size: 0.78rem;">
                            Accounts past due deadline
                        </div>
                    </div>
                    <div class="pt-2 border-top" style="font-size: 0.75rem; border-color: #f1f5f9 !important;">
                        <a href="<?= e(url('reports/fees')) ?>" class="text-decoration-none fw-semibold d-flex align-items-center justify-content-between" style="color: #b45309;">
                            <span>Review overdue accounts</span>
                            <i data-lucide="arrow-right" style="width: 13px; height: 13px;"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Middle Row: Chart & Cycle Performance -->
    <div class="row g-3 mb-4">
        <!-- Inflow & Collections Chart -->
        <div class="col-12 col-xl-8">
            <div class="card border-0 shadow-sm rounded-4 h-100" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="fw-bold text-dark mb-1" style="font-size: 1.05rem;">Inflow & Collections</h5>
                            <p class="text-muted small mb-0" style="font-size: 0.82rem;">Billing volume compared with cash collections (October 2026)</p>
                        </div>
                        <!-- Legend -->
                        <div class="d-flex align-items-center gap-3" style="font-size: 0.82rem;">
                            <div class="d-flex align-items-center gap-1 text-secondary">
                                <span class="rounded-circle" style="width: 8px; height: 8px; background-color: #6366f1;"></span>
                                <span>Billed</span>
                            </div>
                            <div class="d-flex align-items-center gap-1 text-secondary">
                                <span class="rounded-circle" style="width: 8px; height: 8px; background-color: #10b981;"></span>
                                <span>Collected</span>
                            </div>
                        </div>
                    </div>

                    <!-- Canvas -->
                    <div style="position: relative; height: 290px; width: 100%;">
                        <canvas id="inflowCollectionsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cycle Performance Card -->
        <div class="col-12 col-xl-4">
            <div class="card border-0 shadow-sm rounded-4 h-100" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-4 d-flex flex-column justify-content-between">
                    <div>
                        <div class="mb-3">
                            <h5 class="fw-bold text-dark mb-1" style="font-size: 1.05rem;">Cycle Performance</h5>
                            <p class="text-muted small mb-0" style="font-size: 0.82rem;">October 2026</p>
                        </div>

                        <!-- Metric 1: Today's Inflow -->
                        <div class="p-3 rounded-3 bg-light bg-opacity-50 border d-flex justify-content-between align-items-center mb-3" style="border-color: #f1f5f9 !important;">
                            <div>
                                <span class="text-secondary small d-block mb-1" style="font-size: 0.8rem;">Today's Inflow</span>
                                <h4 class="fw-bold text-dark mb-0" style="font-size: 1.35rem; letter-spacing: -0.01em;">
                                    ₹<?= number_format($todayInflow, 2) ?>
                                </h4>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 42px; height: 42px; background: #ecfdf5; color: #059669;">
                                <i data-lucide="banknote" style="width: 20px; height: 20px;"></i>
                            </div>
                        </div>

                        <!-- Metric 2: 30-Day Collections -->
                        <div class="p-3 rounded-3 bg-light bg-opacity-50 border d-flex justify-content-between align-items-center mb-3" style="border-color: #f1f5f9 !important;">
                            <div>
                                <span class="text-secondary small d-block mb-1" style="font-size: 0.8rem;">30-Day Collections</span>
                                <h4 class="fw-bold text-dark mb-0" style="font-size: 1.35rem; letter-spacing: -0.01em;">
                                    ₹<?= number_format($thirtyDayCollections, 2) ?>
                                </h4>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 42px; height: 42px; background: #eff6ff; color: #2563eb;">
                                <i data-lucide="wallet" style="width: 20px; height: 20px;"></i>
                            </div>
                        </div>

                        <!-- Period Recovery Progress -->
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-2 small">
                                <span class="text-secondary fw-medium" style="font-size: 0.8rem;">Period Recovery</span>
                                <span class="fw-bold text-dark" style="font-size: 0.82rem;"><?= (int)$periodRecoveryRate ?>%</span>
                            </div>
                            <div class="progress mb-2" style="height: 6px; background-color: #f1f5f9; border-radius: 999px;">
                                <div class="progress-bar rounded-pill" role="progressbar" 
                                     style="width: <?= min(100, $periodRecoveryRate) ?>%; background: linear-gradient(90deg, #f59e0b, #d97706);" 
                                     aria-valuenow="<?= $periodRecoveryRate ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="text-muted" style="font-size: 0.74rem;">
                                ₹<?= number_format($thirtyDayCollections, 2) ?> collected of ₹<?= number_format($periodBilled, 2) ?> billed in this period.
                            </div>
                        </div>
                    </div>

                    <!-- Defaulters Report Link Button -->
                    <div class="pt-2">
                        <a href="<?= e(url('reports/fees')) ?>" class="btn btn-sm btn-white border w-100 rounded-3 py-2 text-secondary fw-semibold shadow-none d-flex align-items-center justify-content-center gap-2" style="background:#fff; font-size: 0.82rem; border-color: #e2e8f0;">
                            <i data-lucide="file-text" style="width: 14px; height: 14px;"></i> View Defaulters Report
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Section: Activity Ledger -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="border: 1px solid #eef2f6 !important;">
        <!-- Card Header with Filters -->
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <h5 class="fw-bold text-dark mb-0" style="font-size: 1.05rem;">Activity Ledger</h5>
                <p class="text-muted small mb-0" style="font-size: 0.82rem;">Recent student billings and settlement receipts.</p>
            </div>

            <div class="d-flex align-items-center gap-3">
                <!-- Activity Filter Tabs -->
                <div class="btn-group btn-group-sm rounded-pill p-1 bg-light border shadow-none" role="group">
                    <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium ledger-filter-btn active" data-filter="all" onclick="filterLedger('all', this)">
                        All Activity
                    </button>
                    <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium ledger-filter-btn" data-filter="invoice" onclick="filterLedger('invoice', this)">
                        <i data-lucide="file-text" style="width: 13px; height: 13px;"></i> Invoices
                    </button>
                    <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium ledger-filter-btn" data-filter="payment" onclick="filterLedger('payment', this)">
                        <i data-lucide="credit-card" style="width: 13px; height: 13px;"></i> Payments
                    </button>
                </div>

                <a href="<?= e(url('finance/invoices')) ?>" class="text-decoration-none text-muted small fw-semibold d-flex align-items-center gap-1" style="font-size: 0.82rem;">
                    <span>Manage invoices</span>
                    <i data-lucide="arrow-up-right" style="width: 13px; height: 13px;"></i>
                </a>
            </div>
        </div>

        <!-- Table -->
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="activityLedgerTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Reference
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Student / Account
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Timeline
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Channel
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Amount
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem;">
                            Status
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($allActivity)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i data-lucide="inbox" style="width: 36px; height: 36px; opacity: 0.4;" class="mb-2"></i>
                                <p class="mb-0 fw-medium">No recent financial transactions found.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($allActivity as $row): 
                            $actType = $row['activity_type'] ?? 'payment';
                            $studentName = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
                            $admNo = $row['admission_no'] ?? 'STU20260082';
                            $ref = $row['reference'] ?: 'TXN-' . str_pad((string)$row['id'], 4, '0', STR_PAD_LEFT);
                            $channel = ucfirst($row['channel'] ?: 'Card');
                            $amount = (float) $row['amount'];
                            $status = $row['status'] ?: 'Completed';
                            $dateFormatted = date('d/m/Y', strtotime($row['payment_date'] ?? date('Y-m-d')));
                            
                            $firstInit = mb_strtoupper(mb_substr($row['first_name'] ?? '', 0, 1));
                            $lastInit = mb_strtoupper(mb_substr($row['last_name'] ?? '', 0, 1));
                            $initials = ($firstInit . $lastInit) ?: 'ST';
                        ?>
                            <tr class="ledger-row" data-type="<?= e($actType) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Reference -->
                                <td class="py-3 px-4">
                                    <span class="font-monospace fw-semibold text-dark" style="font-size: 0.84rem;">
                                        <?= e($ref) ?>
                                    </span>
                                </td>

                                <!-- Student / Account -->
                                <td class="py-3 px-4">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="rounded-circle d-flex align-items-center justify-content-center fw-semibold flex-shrink-0" 
                                             style="width: 34px; height: 34px; background: #e0e7ff; color: #4338ca; font-size: 0.8rem;">
                                            <?= e($initials) ?>
                                        </div>
                                        <div>
                                            <div class="fw-semibold text-dark" style="font-size: 0.88rem;">
                                                <?= e($studentName) ?>
                                            </div>
                                            <span class="badge border bg-light text-muted font-monospace" style="font-size: 0.68rem; padding: 1px 5px;">
                                                <?= e($admNo) ?>
                                            </span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Timeline -->
                                <td class="py-3 px-3 text-secondary small" style="font-size: 0.82rem;">
                                    <?= e($dateFormatted) ?>
                                </td>

                                <!-- Channel -->
                                <td class="py-3 px-3">
                                    <span class="badge rounded-pill fw-medium bg-light text-secondary border px-2 py-1" style="font-size: 0.74rem;">
                                        <?= e($channel) ?>
                                    </span>
                                </td>

                                <!-- Amount -->
                                <td class="py-3 px-3 text-end fw-bold" style="font-size: 0.9rem; color: <?= ($actType === 'payment') ? '#059669' : '#1e293b' ?>;">
                                    <?= ($actType === 'payment') ? '+' : '' ?>₹<?= number_format($amount, 2) ?>
                                </td>

                                <!-- Status -->
                                <td class="py-3 px-4 text-center">
                                    <?php if ($status === 'Completed'): ?>
                                        <span class="badge rounded-pill fw-semibold" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-size: 0.74rem;">
                                            Completed
                                        </span>
                                    <?php elseif ($status === 'Overdue'): ?>
                                        <span class="badge rounded-pill fw-semibold" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-size: 0.74rem;">
                                            Overdue
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill fw-semibold" style="background: #fffbeb; color: #b45309; border: 1px solid #fde68a; font-size: 0.74rem;">
                                            Pending
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal: + New Invoice -->
<div class="modal fade" id="newInvoiceModal" tabindex="-1" aria-labelledby="newInvoiceModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header py-3 px-4 border-bottom">
                <h5 class="modal-title fw-bold text-dark" id="newInvoiceModalLabel">Issue Student Fee Invoice</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('finance/invoices')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Select Student</label>
                            <select name="student_id" class="form-select rounded-3 shadow-none border-light-subtle" required style="font-size: 0.86rem;">
                                <option value="">-- Choose student --</option>
                                <?php foreach ($students as $st): ?>
                                    <option value="<?= (int)$st['id'] ?>">
                                        <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Invoice Title</label>
                            <input type="text" name="title" class="form-control rounded-3 shadow-none border-light-subtle" 
                                   placeholder="e.g. Monthly Tuition Fee" required style="font-size: 0.86rem;">
                        </div>

                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Invoice Date</label>
                            <input type="date" name="invoice_date" value="<?= date('Y-m-d') ?>" class="form-control rounded-3 shadow-none border-light-subtle" required style="font-size: 0.86rem;">
                        </div>

                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Due Date</label>
                            <input type="date" name="due_date" value="<?= date('Y-m-d', strtotime('+15 days')) ?>" class="form-control rounded-3 shadow-none border-light-subtle" required style="font-size: 0.86rem;">
                        </div>

                        <div class="col-12">
                            <hr class="my-2 border-light-subtle">
                            <h6 class="fw-bold text-dark small text-uppercase mb-2" style="font-size: 0.78rem;">Invoice Items</h6>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="text" name="item_desc[]" value="Tuition & Academic Term Fee" class="form-control form-control-sm rounded-3" placeholder="Fee description" required>
                                </div>
                                <div class="col-3">
                                    <select name="item_category[]" class="form-select form-select-sm rounded-3">
                                        <option value="">Category</option>
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-3">
                                    <input type="number" step="0.01" name="item_amount[]" placeholder="Amount (₹)" class="form-control form-control-sm rounded-3" required>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Notes / Instructions</label>
                            <textarea name="notes" rows="2" class="form-control rounded-3 shadow-none border-light-subtle" placeholder="Additional remarks or payment instructions..." style="font-size: 0.85rem;"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer py-2 px-4 border-top">
                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Create Invoice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.ledger-filter-btn {
    border: none !important;
    background: transparent !important;
    color: #64748b !important;
    font-size: 0.78rem !important;
    transition: all 0.15s ease-in-out;
}
.ledger-filter-btn:hover {
    color: #1e293b !important;
}
.ledger-filter-btn.active {
    background: #ffffff !important;
    color: #0f172a !important;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08) !important;
    font-weight: 600 !important;
}
</style>

<!-- Chart.js initialization for Inflow & Collections Dual Spline -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    const ctx = document.getElementById('inflowCollectionsChart');
    if (ctx) {
        const labels = <?= json_encode($chartDays) ?>;
        const billedData = <?= json_encode($chartBilledData) ?>;
        const paidData = <?= json_encode($chartPaidData) ?>;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Billed',
                        data: billedData,
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99, 102, 241, 0.08)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2,
                        pointRadius: 0,
                        pointHoverRadius: 5,
                        pointHoverBackgroundColor: '#6366f1'
                    },
                    {
                        label: 'Collected',
                        data: paidData,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2.2,
                        pointRadius: 0,
                        pointHoverRadius: 5,
                        pointHoverBackgroundColor: '#10b981'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        padding: 10,
                        titleFont: { size: 12 },
                        bodyFont: { size: 12 },
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ₹' + Number(context.raw).toLocaleString('en-IN', {minimumFractionDigits: 2});
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: { size: 10 },
                            color: '#94a3b8',
                            maxRotation: 0,
                            callback: function(val, index) {
                                // Show every 2nd day (1 Oct, 3 Oct, 5 Oct...) to match screenshot
                                return (index % 2 === 0) ? this.getLabelForValue(val) : '';
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9',
                            borderDash: [3, 3]
                        },
                        ticks: {
                            font: { size: 10 },
                            color: '#94a3b8',
                            callback: function(value) {
                                return '₹' + Number(value).toLocaleString('en-IN');
                            }
                        }
                    }
                }
            }
        });
    }
});

// Activity Ledger Filter
function filterLedger(type, btn) {
    document.querySelectorAll('.ledger-filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const rows = document.querySelectorAll('.ledger-row');
    rows.forEach(row => {
        const rowType = row.getAttribute('data-type');
        if (type === 'all' || rowType === type) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>
