<?php
$totalCount = count($categories);
?>

<div class="cc-fee-types-wrapper">
    <!-- Breadcrumb & Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                    <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Finance</a></li>
                    <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Fee Types</li>
                </ol>
            </nav>
            <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Fee Types</h2>
            <p class="text-muted small mb-0">Manage fee templates, pricing defaults, and payment schedules for fee types.</p>
        </div>

        <!-- Top Right: + Add Fee Type Button -->
        <a href="<?= e(url('finance/fee-types/new')) ?>" class="btn btn-sm text-white rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm text-decoration-none" 
           style="background: #4f46e5; font-size: 0.84rem;">
            <i data-lucide="plus" style="width: 15px; height: 15px;"></i> Add Fee Type
        </a>
    </div>

    <!-- Filter Bar Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #eef2f6 !important;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('finance/fee-types')) ?>" id="feeTypesFilterForm" class="row g-2 align-items-center">
                <!-- Search Templates Input -->
                <div class="col-12 col-md-3">
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" name="q" id="feeLiveSearch" value="<?= e($search ?? '') ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search templates..." style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>

                <!-- Frequency Dropdown -->
                <div class="col-6 col-md-2">
                    <select name="frequency" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('feeTypesFilterForm').submit();">
                        <option value="">All Frequencies</option>
                        <option value="one_time" <?= (($frequency ?? '') === 'one_time') ? 'selected' : '' ?>>One Time</option>
                        <option value="monthly" <?= (($frequency ?? '') === 'monthly') ? 'selected' : '' ?>>Monthly</option>
                        <option value="term" <?= (($frequency ?? '') === 'term') ? 'selected' : '' ?>>Term</option>
                        <option value="annual" <?= (($frequency ?? '') === 'annual') ? 'selected' : '' ?>>Annual</option>
                    </select>
                </div>

                <!-- Scope Dropdown -->
                <div class="col-6 col-md-2">
                    <select name="scope" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('feeTypesFilterForm').submit();">
                        <option value="">All Scopes</option>
                        <option value="global" <?= (($scope ?? '') === 'global') ? 'selected' : '' ?>>Global</option>
                        <option value="class_specific" <?= (($scope ?? '') === 'class_specific') ? 'selected' : '' ?>>Class Specific</option>
                        <option value="optional" <?= (($scope ?? '') === 'optional') ? 'selected' : '' ?>>Optional</option>
                    </select>
                </div>

                <!-- Customizations Dropdown -->
                <div class="col-6 col-md-2">
                    <select name="customization" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('feeTypesFilterForm').submit();">
                        <option value="">All Customizations</option>
                        <option value="overrides">Has Overrides</option>
                        <option value="default">Default Only</option>
                    </select>
                </div>

                <!-- Status Dropdown -->
                <div class="col-6 col-md-3">
                    <select name="status" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('feeTypesFilterForm').submit();">
                        <option value="">All Statuses</option>
                        <option value="1" <?= (($status ?? '') === '1') ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= (($status ?? '') === '0') ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important;">
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="feeTypesTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 22%;">
                            Name
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 18%;">
                            Code
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 24%;">
                            Description
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 14%;">
                            Default Amount
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 10%;">
                            Frequency
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 6%;">
                            Status
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 6%;">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <div class="py-4">
                                    <i data-lucide="receipt" class="mb-2 text-muted" style="width: 40px; height: 40px; opacity: 0.35;"></i>
                                    <p class="mb-0 fw-medium">No fee templates found matching criteria.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($categories as $cat): 
                            $cId = (int)$cat['id'];
                            $name = $cat['name'];
                            $code = $cat['code'] ?: strtoupper(preg_replace('/[^A-Za-z0-9]/', '_', $name));
                            $desc = $cat['description'] ?: ('Standard ' . $name);
                            $amount = (float)($cat['amount'] ?? 0);
                            $freqRaw = $cat['frequency'] ?: 'one_time';
                            $freqLabel = ucwords(str_replace('_', ' ', $freqRaw));
                            $overrides = (int)($cat['overrides_count'] ?? 12);
                            $isActive = ((int)($cat['status'] ?? 1) === 1);
                        ?>
                            <tr class="fee-type-row" data-name="<?= e(strtolower($name)) ?>" data-code="<?= e(strtolower($code)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Name -->
                                <td class="py-3 px-4">
                                    <span class="fw-bold text-dark" style="font-size: 0.9rem;">
                                        <?= e($name) ?>
                                    </span>
                                </td>

                                <!-- Code -->
                                <td class="py-3 px-3">
                                    <span class="font-monospace text-muted fw-semibold" style="font-size: 0.8rem; letter-spacing: 0.02em;">
                                        <?= e($code) ?>
                                    </span>
                                </td>

                                <!-- Description -->
                                <td class="py-3 px-3 text-secondary small" style="font-size: 0.84rem;">
                                    <?= e($desc) ?>
                                </td>

                                <!-- Default Amount -->
                                <td class="py-3 px-3 text-end">
                                    <div class="fw-bold text-dark" style="font-size: 0.92rem;">
                                        ₹<?= number_format($amount, 2) ?>
                                    </div>
                                    <div class="text-muted small" style="font-size: 0.72rem;">
                                        <?= $overrides ?> overrides
                                    </div>
                                </td>

                                <!-- Frequency -->
                                <td class="py-3 px-3 text-center">
                                    <span class="badge rounded-pill fw-medium border px-2 py-1" style="background: #f8fafc; color: #475569; border-color: #e2e8f0 !important; font-size: 0.74rem;">
                                        <?= e($freqLabel) ?>
                                    </span>
                                </td>

                                <!-- Status -->
                                <td class="py-3 px-3 text-center">
                                    <?php if ($isActive): ?>
                                        <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-size: 0.74rem;">
                                            Active
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #f8fafc; color: #64748b; border: 1px solid #cbd5e1; font-size: 0.74rem;">
                                            Inactive
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <!-- Edit Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#editFeeTypeModal<?= $cId ?>" title="Edit Fee Type">
                                            <i data-lucide="edit-2" style="width: 14px; height: 14px;"></i>
                                        </button>

                                        <!-- Delete Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#deleteFeeTypeModal<?= $cId ?>" title="Delete Fee Type">
                                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    </div>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editFeeTypeModal<?= $cId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h5 class="modal-title fw-bold text-dark">Edit Fee Type</h5>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?= e(url('finance/fee-types/' . $cId)) ?>">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-body p-4">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Name</label>
                                                            <input type="text" name="name" value="<?= e($name) ?>" class="form-control rounded-3 shadow-none border-light-subtle" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Code</label>
                                                            <input type="text" name="code" value="<?= e($code) ?>" class="form-control rounded-3 shadow-none border-light-subtle font-monospace" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Description</label>
                                                            <input type="text" name="description" value="<?= e($desc) ?>" class="form-control rounded-3 shadow-none border-light-subtle">
                                                        </div>
                                                        <div class="row g-2 mb-3">
                                                            <div class="col-6">
                                                                <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Default Amount (₹)</label>
                                                                <input type="number" step="0.01" name="amount" value="<?= $amount ?>" class="form-control rounded-3 shadow-none border-light-subtle" required>
                                                            </div>
                                                            <div class="col-6">
                                                                <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Frequency</label>
                                                                <select name="frequency" class="form-select rounded-3 shadow-none border-light-subtle">
                                                                    <option value="one_time" <?= ($freqRaw === 'one_time') ? 'selected' : '' ?>>One Time</option>
                                                                    <option value="monthly" <?= ($freqRaw === 'monthly') ? 'selected' : '' ?>>Monthly</option>
                                                                    <option value="term" <?= ($freqRaw === 'term') ? 'selected' : '' ?>>Term</option>
                                                                    <option value="annual" <?= ($freqRaw === 'annual') ? 'selected' : '' ?>>Annual</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Status</label>
                                                            <select name="status" class="form-select rounded-3 shadow-none border-light-subtle">
                                                                <option value="1" <?= $isActive ? 'selected' : '' ?>>Active</option>
                                                                <option value="0" <?= !$isActive ? 'selected' : '' ?>>Inactive</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer py-2 px-4 border-top">
                                                        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteFeeTypeModal<?= $cId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-sm">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h6 class="modal-title fw-bold text-dark">Confirm Delete</h6>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?= e(url('finance/fee-types/' . $cId . '/delete')) ?>">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-body p-4 text-center">
                                                        <i data-lucide="alert-triangle" class="text-danger mb-2" style="width: 36px; height: 36px;"></i>
                                                        <p class="mb-0 small text-muted">Are you sure you want to remove <strong><?= e($name) ?></strong>?</p>
                                                    </div>
                                                    <div class="modal-footer py-2 px-4 border-top d-flex justify-content-between">
                                                        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-sm btn-danger px-3 fw-medium">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Table Footer / Pagination -->
        <div class="p-3 bg-white border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
            <span class="text-muted small" style="font-size: 0.8rem;">
                Showing 1 to <?= $totalCount ?> of <?= $totalCount ?> records
            </span>

            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small" style="font-size: 0.8rem;">Rows:</span>
                <select class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" style="width: 70px; height: 32px; font-size: 0.8rem;">
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Modal: + Add Fee Type -->
<div class="modal fade" id="addFeeTypeModal" tabindex="-1" aria-labelledby="addFeeTypeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header py-3 px-4 border-bottom">
                <h5 class="modal-title fw-bold text-dark" id="addFeeTypeModalLabel">Add New Fee Type</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('finance/fee-types')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Name</label>
                        <input type="text" name="name" class="form-control rounded-3 shadow-none border-light-subtle" placeholder="e.g. Laboratory Fee" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Code (Optional)</label>
                        <input type="text" name="code" class="form-control rounded-3 shadow-none border-light-subtle font-monospace" placeholder="e.g. LAB_FEE">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Description</label>
                        <input type="text" name="description" class="form-control rounded-3 shadow-none border-light-subtle" placeholder="e.g. Standard Laboratory Fee">
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Default Amount (₹)</label>
                            <input type="number" step="0.01" name="amount" placeholder="0.00" class="form-control rounded-3 shadow-none border-light-subtle" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Frequency</label>
                            <select name="frequency" class="form-select rounded-3 shadow-none border-light-subtle">
                                <option value="one_time">One Time</option>
                                <option value="monthly">Monthly</option>
                                <option value="term">Term</option>
                                <option value="annual">Annual</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Scope</label>
                        <select name="scope" class="form-select rounded-3 shadow-none border-light-subtle">
                            <option value="global" selected>Global</option>
                            <option value="class_specific">Class Specific</option>
                            <option value="optional">Optional</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer py-2 px-4 border-top">
                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Create Template</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.action-icon-btn {
    opacity: 0.65;
    transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
}
.action-icon-btn:hover {
    opacity: 1;
    transform: scale(1.1);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Client-side real-time live search
    const searchInput = document.getElementById('feeLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.fee-type-row');

            rows.forEach(row => {
                const name = row.getAttribute('data-name') || '';
                const code = row.getAttribute('data-code') || '';
                if (!query || name.includes(query) || code.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>
