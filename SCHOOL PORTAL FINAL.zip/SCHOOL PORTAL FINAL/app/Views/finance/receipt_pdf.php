<?php
$payment = $payment ?? [];
$school = $school ?? [];
?>
<div class="print-container container mt-4 bg-white p-5 shadow-sm border rounded">
  <!-- Header -->
  <div class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
    <div>
      <h2 class="fw-bold mb-1"><?= htmlspecialchars($school['name'] ?? 'School Portal') ?></h2>
      <address class="text-muted small mb-0">
        <?= htmlspecialchars($school['address'] ?? '') ?><br>
        <?= htmlspecialchars($school['phone'] ?? '') ?> | <?= htmlspecialchars($school['email'] ?? '') ?>
      </address>
    </div>
    <div class="text-end">
      <h3 class="h4 text-uppercase text-success fw-bold mb-1">Official Fee Receipt</h3>
      <div class="font-monospace fw-bold fs-5 text-dark"><?= htmlspecialchars($payment['receipt_no'] ?? 'RCP-' . $payment['id']) ?></div>
      <div class="small text-muted">Payment Date: <?= htmlspecialchars(date('M d, Y', strtotime((string)$payment['payment_date']))) ?></div>
      <span class="badge bg-success-subtle text-success border border-success-subtle text-uppercase px-2 py-1 mt-1">
        ✓ <?= htmlspecialchars($payment['status']) ?>
      </span>
    </div>
  </div>

  <!-- Student & Payment Metadata -->
  <div class="row mb-4">
    <div class="col-md-6">
      <div class="p-3 bg-light rounded border">
        <div class="text-muted small text-uppercase fw-bold">Received From</div>
        <div class="fs-5 fw-bold text-dark mt-1">
          <?= htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']) ?>
        </div>
        <div class="small text-muted">
          Admission No: <strong><?= htmlspecialchars($payment['admission_no']) ?></strong> | 
          Class: <strong><?= htmlspecialchars($payment['class_name'] ?? 'N/A') ?></strong>
        </div>
        <div class="small text-muted mt-1">
          Fee Invoice: <strong><?= htmlspecialchars($payment['invoice_no'] ?? 'N/A') ?></strong>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="p-3 bg-light rounded border">
        <div class="text-muted small text-uppercase fw-bold">Transaction Information</div>
        <div class="d-flex justify-content-between align-items-center mt-1">
          <span class="text-muted small">Payment Channel:</span>
          <span class="fw-bold text-dark text-uppercase"><?= htmlspecialchars($payment['payment_method']) ?></span>
        </div>
        <?php if (!empty($payment['reference_no'])): ?>
          <div class="d-flex justify-content-between align-items-center mt-1">
            <span class="text-muted small">Reference / Txn ID:</span>
            <span class="font-monospace text-dark"><?= htmlspecialchars($payment['reference_no']) ?></span>
          </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mt-1">
          <span class="text-muted small">Cashier / Collected By:</span>
          <span class="text-dark small"><?= htmlspecialchars($payment['cashier_name'] ?? 'Accounts Desk') ?></span>
        </div>
      </div>
    </div>
  </div>

  <!-- Receipt Particulars Table -->
  <table class="table table-bordered mb-4">
    <thead class="table-light text-uppercase small">
      <tr>
        <th>Fee Description</th>
        <th class="text-end" style="width: 25%;">Amount Paid ($)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <div class="fw-semibold text-dark">Tuition &amp; Educational Fees Settlement</div>
          <div class="small text-muted mt-1">Settlement against Invoice #<?= htmlspecialchars($payment['invoice_no'] ?? 'N/A') ?></div>
          <?php if (!empty($payment['notes'])): ?>
            <div class="small text-muted">Notes: <?= htmlspecialchars($payment['notes']) ?></div>
          <?php endif; ?>
        </td>
        <td class="text-end font-monospace fw-bold fs-5 text-success">
          <?= number_format((float)$payment['amount'], 2) ?>
        </td>
      </tr>
    </tbody>
    <tfoot class="table-light">
      <tr>
        <th class="text-end text-uppercase">Total Cash / Bank Received</th>
        <th class="text-end font-monospace fs-4 text-success fw-bold">
          $<?= number_format((float)$payment['amount'], 2) ?>
        </th>
      </tr>
    </tfoot>
  </table>

  <!-- Watermark stamp & signatures -->
  <div class="row pt-5 mt-5">
    <div class="col-6 text-center">
      <div class="border-top pt-2 small text-muted">Cashier / Receiving Officer</div>
    </div>
    <div class="col-6 text-center">
      <div class="border-top pt-2 small text-muted">Official School Stamp / Bursar Sign-off</div>
    </div>
  </div>
</div>
