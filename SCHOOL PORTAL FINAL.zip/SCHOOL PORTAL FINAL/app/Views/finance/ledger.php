<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i data-lucide="book-open" class="text-primary me-2"></i> Mass Ledger</h2>
        <p class="text-muted mb-0">View all outstanding invoices and collect mass payments.</p>
    </div>
</div>

<!-- Summary Widget -->
<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 rounded-4 position-relative overflow-hidden">
            <div class="card-body p-4">
                <div class="text-muted small fw-semibold text-uppercase mb-2">Total Outstanding</div>
                <h3 class="mb-0 fw-bold text-danger"><?= e(formatMoney($summary['total_outstanding'])) ?></h3>
                <div class="position-absolute bottom-0 end-0 p-3 opacity-25 text-danger">
                    <i data-lucide="alert-circle" style="width: 48px; height: 48px;"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 rounded-4 position-relative overflow-hidden">
            <div class="card-body p-4">
                <div class="text-muted small fw-semibold text-uppercase mb-2">Collected (This Month)</div>
                <h3 class="mb-0 fw-bold text-success"><?= e(formatMoney($summary['total_collected'])) ?></h3>
                <div class="position-absolute bottom-0 end-0 p-3 opacity-25 text-success">
                    <i data-lucide="check-circle" style="width: 48px; height: 48px;"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 rounded-4 position-relative overflow-hidden">
            <div class="card-body p-4">
                <div class="text-muted small fw-semibold text-uppercase mb-2">Overdue Invoices</div>
                <h3 class="mb-0 fw-bold text-warning"><?= e((string)$summary['overdue_count']) ?></h3>
                <div class="position-absolute bottom-0 end-0 p-3 opacity-25 text-warning">
                    <i data-lucide="clock" style="width: 48px; height: 48px;"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <form method="post" action="<?= e(url('finance/invoices/mass-collect')) ?>" id="massCollectForm">
        <?= csrf_field() ?>
        
        <div class="card-header bg-white border-0 p-4 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">Outstanding Invoices</h5>
            
            <?php if (hasPermission('finance.manage') && count($invoices) > 0): ?>
            <div class="d-flex align-items-center gap-3">
                <select name="payment_method" class="form-select form-select-sm rounded-pill px-3 shadow-sm" style="width: auto;" required>
                    <option value="cash">Cash</option>
                    <option value="bank">Bank Transfer</option>
                    <option value="card">Card / Online</option>
                    <option value="cheque">Cheque</option>
                </select>
                <button type="button" class="btn btn-primary rounded-pill shadow-sm d-flex align-items-center gap-2" onclick="confirmMassCollect()">
                    <i data-lucide="dollar-sign" style="width: 16px;"></i> Collect Selected
                </button>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light text-muted small text-uppercase">
                    <tr>
                        <th class="ps-4 border-0 py-3" style="width: 40px;">
                            <input class="form-check-input" type="checkbox" id="selectAllInvoices">
                        </th>
                        <th class="border-0 py-3">Invoice No</th>
                        <th class="border-0 py-3">Student</th>
                        <th class="border-0 py-3">Class</th>
                        <th class="border-0 py-3">Due Date</th>
                        <th class="border-0 py-3">Total Amount</th>
                        <th class="border-0 py-3">Outstanding</th>
                        <th class="pe-4 border-0 py-3 text-end">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($invoices)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">No outstanding invoices found.</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($invoices as $i): ?>
                        <?php
                            $isOverdue = strtotime($i['due_date']) < time();
                            $outstanding = $i['total_amount'] - $i['paid_amount'];
                        ?>
                        <tr>
                            <td class="ps-4 py-3">
                                <input class="form-check-input invoice-checkbox" type="checkbox" name="invoice_ids[]" value="<?= $i['id'] ?>">
                            </td>
                            <td class="fw-semibold text-primary py-3">
                                <a href="<?= e(url("finance/invoices/{$i['id']}")) ?>" class="text-decoration-none"><?= e($i['invoice_no']) ?></a>
                            </td>
                            <td class="py-3 fw-bold text-dark"><?= e($i['first_name'] . ' ' . $i['last_name']) ?> <span class="small text-muted ms-1">(<?= e($i['admission_no']) ?>)</span></td>
                            <td class="py-3 text-muted"><?= e($i['class_name']) ?></td>
                            <td class="py-3 <?= $isOverdue ? 'text-danger fw-bold' : 'text-muted' ?>">
                                <?= date('M d, Y', strtotime($i['due_date'])) ?>
                            </td>
                            <td class="py-3 text-muted"><?= e(formatMoney($i['total_amount'])) ?></td>
                            <td class="py-3 fw-bold text-danger"><?= e(formatMoney($outstanding)) ?></td>
                            <td class="pe-4 py-3 text-end"><?= statusBadge($i['status']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($totalPages > 1): ?>
        <div class="card-footer bg-white border-top p-4 d-flex justify-content-between align-items-center">
            <span class="text-muted small">Showing page <?= $page ?> of <?= $totalPages ?></span>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link rounded-start-pill" href="?page=<?= $page - 1 ?>">Previous</a>
                </li>
                <li class="page-item active"><span class="page-link"><?= $page ?></span></li>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link rounded-end-pill" href="?page=<?= $page + 1 ?>">Next</a>
                </li>
            </ul>
        </div>
        <?php endif; ?>
    </form>
</div>

<script>
document.getElementById('selectAllInvoices')?.addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.invoice-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
});

function confirmMassCollect() {
    const selected = document.querySelectorAll('.invoice-checkbox:checked').length;
    if (selected === 0) {
        alert('Please select at least one invoice to collect payment for.');
        return;
    }
    
    if (confirm(`⚠️ You are about to mass collect payment for ${selected} invoices. Are you sure you want to proceed?`)) {
        document.getElementById('massCollectForm').submit();
    }
}
</script>
