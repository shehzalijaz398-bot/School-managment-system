<?php
$ledger = $ledger ?? [];
$account = $ledger['account'] ?? [];
$lines = $ledger['lines'] ?? [];
$from = $from ?? date('Y-m-01');
$to = $to ?? date('Y-m-d');
$title = 'General Ledger — ' . ($account['name'] ?? 'Account');
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="book-marked" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        [<?= e($account['code'] ?? '') ?>] <?= e($account['name'] ?? '') ?>
      </h2>
      <span class="badge bg-secondary-subtle text-secondary border px-2 py-1 rounded-pill small text-uppercase">
        <?= e($account['type'] ?? '') ?>
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Account transaction ledger and running balance statement from <?= e($from) ?> to <?= e($to) ?>.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" onclick="window.print()" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Ledger
    </button>
    <a href="<?= e(url('finance/accounting')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Back to Accounts
    </a>
  </div>
</div>

<!-- Ledger Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-secondary">
      <div class="text-muted small fw-medium text-uppercase">Opening Balance (Prior to <?= e($from) ?>)</div>
      <div class="h4 mb-0 fw-bold font-monospace text-dark mt-1">
        <?= formatMoney((float)($ledger['opening_balance'] ?? 0)) ?>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-primary">
      <div class="text-muted small fw-medium text-uppercase">Closing Running Balance (As of <?= e($to) ?>)</div>
      <div class="h4 mb-0 fw-bold font-monospace text-primary mt-1">
        <?= formatMoney((float)($ledger['closing_balance'] ?? 0)) ?>
      </div>
    </div>
  </div>
</div>

<!-- Filter Card -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('finance/ledger/account/' . ($account['id'] ?? 0))) ?>" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small text-muted mb-1">From Date</label>
        <input type="date" name="from" value="<?= e($from) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4">
        <label class="form-label small text-muted mb-1">To Date</label>
        <input type="date" name="to" value="<?= e($to) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn btn-primary btn-sm w-100 d-flex align-items-center justify-content-center gap-1">
          <i data-lucide="filter" style="width: 14px; height: 14px;"></i> Filter Date Range
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Ledger Lines Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3" style="width: 12%;">Date</th>
            <th style="width: 15%;">Journal #</th>
            <th style="width: 12%;">Type</th>
            <th style="width: 25%;">Narration / Description</th>
            <th class="text-end" style="width: 12%;">Debit ($)</th>
            <th class="text-end" style="width: 12%;">Credit ($)</th>
            <th class="text-end pe-3" style="width: 12%;">Running Bal ($)</th>
          </tr>
        </thead>
        <tbody>
          <tr class="table-light text-muted small">
            <td class="ps-3"><?= e($from) ?></td>
            <td colspan="5"><em>Balance Brought Forward</em></td>
            <td class="text-end pe-3 font-monospace fw-bold text-dark"><?= number_format((float)($ledger['opening_balance'] ?? 0), 2) ?></td>
          </tr>
          <?php if (empty($lines)): ?>
            <tr>
              <td colspan="7" class="text-center py-4 text-muted">No journal transactions recorded for this account in the selected period.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($lines as $l): ?>
              <tr>
                <td class="ps-3 small"><?= e($l['entry_date']) ?></td>
                <td class="font-monospace fw-bold text-primary"><?= e($l['entry_no']) ?></td>
                <td><span class="badge bg-light text-dark border small text-uppercase"><?= e($l['reference_type']) ?></span></td>
                <td class="small"><?= e($l['narration'] ?: $l['entry_description']) ?></td>
                <td class="text-end font-monospace"><?= (float)$l['debit'] > 0 ? number_format((float)$l['debit'], 2) : '—' ?></td>
                <td class="text-end font-monospace"><?= (float)$l['credit'] > 0 ? number_format((float)$l['credit'], 2) : '—' ?></td>
                <td class="text-end pe-3 font-monospace fw-bold text-dark"><?= number_format((float)$l['running_balance'], 2) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
        <tfoot class="table-light border-top border-2 border-dark font-monospace fw-bold">
          <tr>
            <td colspan="6" class="ps-3 text-uppercase">Closing Balance</td>
            <td class="text-end pe-3 text-primary fs-6"><?= number_format((float)($ledger['closing_balance'] ?? 0), 2) ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
</div>
