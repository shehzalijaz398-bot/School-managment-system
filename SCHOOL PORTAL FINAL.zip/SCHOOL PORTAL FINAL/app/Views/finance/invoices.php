<?php
$totalInvoicesCount = count($invoices);

// Helper for CodeClove avatar initials
if (!function_exists('ccInvoiceInitials')) {
    function ccInvoiceInitials(string $firstName, string $lastName): string {
        $first = strtoupper(substr(trim($firstName), 0, 1));
        $parts = preg_split('/\s+/', trim($lastName));
        $lastWord = end($parts);
        $last = strtoupper(substr((string)$lastWord, 0, 1));
        return ($first ?: 'S') . ($last ?: 'T');
    }
}

// Avatar color palettes
$avatarColors = [
    ['bg' => '#ffedd5', 'color' => '#ea580c'], // orange/peach
    ['bg' => '#fce7f3', 'color' => '#db2777'], // pink/rose
    ['bg' => '#dbeafe', 'color' => '#2563eb'], // blue
    ['bg' => '#ede9fe', 'color' => '#7c3aed'], // purple
    ['bg' => '#e0e7ff', 'color' => '#4f46e5'], // indigo
    ['bg' => '#ccfbf1', 'color' => '#0d9488'], // teal
];
?>

<div class="cc-invoices-wrapper">
    <!-- Breadcrumb & Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                    <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Finance</a></li>
                    <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Invoices</li>
                </ol>
            </nav>
            <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Invoices</h2>
            <p class="text-muted small mb-0">Manage and track outstanding billing balances, fee invoices, and collections for the session.</p>
        </div>

        <!-- Top Right Actions -->
        <div class="d-flex align-items-center gap-2">
            <form method="POST" action="<?= e(url('finance/late-fees/apply')) ?>" class="d-inline" onsubmit="return confirm('Calculate and apply dynamic late fees to all overdue invoices past grace period?');">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-outline-warning text-dark rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm">
                    <i data-lucide="clock" style="width: 14px; height: 14px;"></i> Apply Late Fees
                </button>
            </form>
            <a href="<?= e(url('finance/reminders')) ?>" class="btn btn-sm btn-outline-primary rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm text-decoration-none">
                <i data-lucide="bell" style="width: 14px; height: 14px;"></i> Fee Reminders
            </a>
            <a href="<?= e(url('finance/invoices/new')) ?>" class="btn btn-sm text-white rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm text-decoration-none" 
               style="background: #4f46e5; font-size: 0.84rem;">
                <i data-lucide="plus" style="width: 15px; height: 15px;"></i> Create Invoice
            </a>
        </div>
    </div>

    <!-- 3 Top KPI Cards -->
    <div class="row g-3 mb-4">
        <!-- Card 1: Total Invoiced -->
        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-3 d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; background: #eef2ff; color: #6366f1;">
                        <i data-lucide="receipt" style="width: 20px; height: 20px;"></i>
                    </div>
                    <div>
                        <div class="fw-bold text-dark" style="font-size: 1.34rem; line-height: 1.2;">
                            ₹<?= number_format($kpiInvoiced ?? 142.50, 2) ?>
                        </div>
                        <div class="text-muted small fw-medium" style="font-size: 0.78rem;">
                            Total Invoiced
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 2: Total Collected -->
        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-3 d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; background: #ecfdf5; color: #10b981;">
                        <i data-lucide="check-circle" style="width: 20px; height: 20px;"></i>
                    </div>
                    <div>
                        <div class="fw-bold text-dark" style="font-size: 1.34rem; line-height: 1.2;">
                            ₹<?= number_format($kpiCollected ?? 94.10, 2) ?>
                        </div>
                        <div class="text-muted small fw-medium" style="font-size: 0.78rem;">
                            Total Collected
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card 3: Overdue Balance -->
        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 p-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-3 d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; background: #fffbeb; color: #f59e0b;">
                        <i data-lucide="clock" style="width: 20px; height: 20px;"></i>
                    </div>
                    <div>
                        <div class="fw-bold text-dark" style="font-size: 1.34rem; line-height: 1.2;">
                            ₹<?= number_format($kpiOverdue ?? 0.00, 2) ?>
                        </div>
                        <div class="text-muted small fw-medium" style="font-size: 0.78rem;">
                            Overdue Balance
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Bar Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('finance/invoices')) ?>" id="invoicesFilterForm" class="row g-2 align-items-end">
                <!-- Search Invoices -->
                <div class="col-12 col-md-3">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Search Invoices</label>
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" name="q" id="invoiceLiveSearch" value="<?= e($search ?? '') ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search by invoice #, student name, c" style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>

                <!-- Class -->
                <div class="col-6 col-md-2">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Class</label>
                    <select name="class_id" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('invoicesFilterForm').submit();">
                        <option value="">All classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ((string)($classId ?? '') === (string)$c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Academic Term -->
                <div class="col-6 col-md-2">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Academic Term</label>
                    <select name="term" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('invoicesFilterForm').submit();">
                        <option value="">All Terms</option>
                        <option value="term_1" <?= (($term ?? '') === 'term_1') ? 'selected' : '' ?>>Term 1</option>
                        <option value="term_2" <?= (($term ?? '') === 'term_2') ? 'selected' : '' ?>>Term 2</option>
                        <option value="annual" <?= (($term ?? '') === 'annual') ? 'selected' : '' ?>>Annual</option>
                    </select>
                </div>

                <!-- Status -->
                <div class="col-6 col-md-3">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Status</label>
                    <select name="status" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('invoicesFilterForm').submit();">
                        <option value="">All Statuses</option>
                        <option value="paid" <?= (($status ?? '') === 'paid') ? 'selected' : '' ?>>Paid</option>
                        <option value="unpaid" <?= (($status ?? '') === 'unpaid') ? 'selected' : '' ?>>Unpaid</option>
                        <option value="partially_paid" <?= (($status ?? '') === 'partially_paid') ? 'selected' : '' ?>>Partially Paid</option>
                    </select>
                </div>

                <!-- Date Range Button -->
                <div class="col-6 col-md-2 text-md-end">
                    <button type="button" class="btn btn-sm btn-white border border-light-subtle rounded-3 px-3 shadow-none text-secondary fw-medium d-inline-flex align-items-center justify-content-center gap-1 w-100" 
                            style="height: 38px; font-size: 0.86rem; background: #fff;" onclick="alert('Date range filter active');">
                        <i data-lucide="sliders-horizontal" style="width: 15px; height: 15px;"></i> Date Range
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Invoices Data Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="invoicesTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-3 text-center" style="width: 40px;">
                            <input type="checkbox" class="form-check-input shadow-none" id="selectAllInvoices">
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 14%;">
                            Invoice # <span class="text-muted" style="font-size: 0.65rem;">⇅</span>
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 30%;">
                            Student <span class="text-muted" style="font-size: 0.65rem;">⇅</span>
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 13%;">
                            Due Date <span class="text-muted" style="font-size: 0.65rem;">⇅</span>
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            Total <span class="text-muted" style="font-size: 0.65rem;">⇅</span>
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            Balance <span class="text-muted" style="font-size: 0.65rem;">⇅</span>
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 10%;">
                            Status
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 9%;">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($invoices)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <div class="py-4">
                                    <i data-lucide="receipt" class="mb-2 text-muted" style="width: 40px; height: 40px; opacity: 0.35;"></i>
                                    <p class="mb-0 fw-medium">No invoices found matching criteria.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($invoices as $idx => $inv): 
                            $invId = (int)$inv['id'];
                            $invNo = $inv['invoice_no'];
                            $fName = $inv['first_name'] ?? 'Student';
                            $lName = $inv['last_name'] ?? '';
                            $fullName = trim($fName . ' ' . $lName);
                            $admNo = $inv['admission_no'] ?? ('STU' . str_pad((string)$invId, 6, '0', STR_PAD_LEFT));
                            $dueDateRaw = $inv['due_date'] ?? date('Y-m-d');
                            $dueDateFmt = date('d/m/Y', strtotime($dueDateRaw));
                            $totalAmt = (float)($inv['total_amount'] ?? 0);
                            $paidAmt = (float)($inv['paid_amount'] ?? 0);
                            $balance = max(0.0, $totalAmt - $paidAmt);
                            $invStatus = strtolower($inv['status'] ?? 'paid');

                            // Compute initials & color
                            $initials = ccInvoiceInitials($fName, $lName);
                            $colorIndex = abs(crc32($admNo)) % count($avatarColors);
                            $pal = $avatarColors[$colorIndex];
                        ?>
                            <tr class="invoice-data-row" data-invoice-no="<?= e(strtolower($invNo)) ?>" data-student="<?= e(strtolower($fullName)) ?>" data-adm="<?= e(strtolower($admNo)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Checkbox -->
                                <td class="py-3 px-3 text-center">
                                    <input type="checkbox" class="form-check-input invoice-select-row shadow-none" value="<?= $invId ?>">
                                </td>

                                <!-- Invoice # -->
                                <td class="py-3 px-3">
                                    <a href="javascript:void(0)" class="text-dark fw-bold text-decoration-none font-monospace invoice-link" 
                                       data-bs-toggle="modal" data-bs-target="#viewInvoiceModal<?= $invId ?>" style="font-size: 0.86rem; letter-spacing: 0.02em;">
                                        <?= e($invNo) ?>
                                    </a>
                                </td>

                                <!-- Student -->
                                <td class="py-3 px-3">
                                    <div class="d-flex align-items-center gap-2">
                                        <!-- Avatar Pill -->
                                        <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold flex-shrink-0" 
                                             style="width: 32px; height: 32px; background: <?= $pal['bg'] ?>; color: <?= $pal['color'] ?>; font-size: 0.75rem;">
                                            <?= e($initials) ?>
                                        </div>
                                        <div class="lh-sm">
                                            <div class="fw-bold text-dark" style="font-size: 0.86rem; letter-spacing: -0.01em;">
                                                <?= e($fullName) ?>
                                            </div>
                                            <div class="text-muted font-monospace" style="font-size: 0.72rem;">
                                                <?= e($admNo) ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Due Date -->
                                <td class="py-3 px-3 text-secondary" style="font-size: 0.84rem;">
                                    <?= e($dueDateFmt) ?>
                                </td>

                                <!-- Total -->
                                <td class="py-3 px-3 text-end fw-bold text-dark" style="font-size: 0.88rem;">
                                    ₹<?= number_format($totalAmt, 2) ?>
                                </td>

                                <!-- Balance -->
                                <td class="py-3 px-3 text-end fw-medium <?= $balance > 0 ? 'text-danger fw-bold' : 'text-secondary' ?>" style="font-size: 0.88rem;">
                                    ₹<?= number_format($balance, 2) ?>
                                </td>

                                <!-- Status -->
                                <td class="py-3 px-3 text-center">
                                    <?php if ($invStatus === 'paid' || $balance <= 0): ?>
                                        <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-size: 0.74rem;">
                                            Paid
                                        </span>
                                    <?php elseif ($invStatus === 'partially_paid'): ?>
                                        <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #fffbeb; color: #d97706; border: 1px solid #fde68a; font-size: 0.74rem;">
                                            Partial
                                        </span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-size: 0.74rem;">
                                            Unpaid
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-3 text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <!-- Print / Voucher Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#viewInvoiceModal<?= $invId ?>" title="Print / View Invoice Voucher">
                                            <i data-lucide="printer" style="width: 14px; height: 14px;"></i>
                                        </button>

                                        <!-- Student Statement of Account PDF -->
                                        <a href="<?= e(url('finance/statement/' . $inv['student_id'] . '/pdf')) ?>" target="_blank" 
                                           class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" title="Print Student Statement of Account">
                                            <i data-lucide="file-text" style="width: 14px; height: 14px;"></i>
                                        </a>

                                        <!-- Delete Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#deleteInvoiceModal<?= $invId ?>" title="Delete Invoice">
                                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    </div>

                                    <!-- Print Voucher Modal -->
                                    <div class="modal fade" id="viewInvoiceModal<?= $invId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <i data-lucide="receipt" class="text-primary" style="width: 20px; height: 20px;"></i>
                                                        <h5 class="modal-title fw-bold text-dark mb-0">Fee Voucher: <?= e($invNo) ?></h5>
                                                    </div>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <button type="button" class="btn btn-sm btn-primary d-flex align-items-center gap-1 shadow-sm" onclick="printInvoiceVoucher('voucherPrintArea<?= $invId ?>')">
                                                            <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Voucher
                                                        </button>
                                                        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                </div>
                                                <div class="modal-body p-4" id="voucherPrintArea<?= $invId ?>">
                                                    <!-- Voucher Header -->
                                                    <div class="d-flex justify-content-between align-items-start border-bottom pb-3 mb-3">
                                                        <div>
                                                            <h4 class="fw-bold text-dark mb-1">Guiding Star International</h4>
                                                            <p class="text-muted small mb-0">Official Student Fee Voucher &amp; Billing Statement</p>
                                                        </div>
                                                        <div class="text-end">
                                                            <div class="badge bg-light text-dark border px-3 py-2 font-monospace fs-6">
                                                                <?= e($invNo) ?>
                                                            </div>
                                                            <div class="text-muted small mt-1">Due: <?= e($dueDateFmt) ?></div>
                                                        </div>
                                                    </div>

                                                    <!-- Student Info Box -->
                                                    <div class="row g-3 bg-light rounded-3 p-3 mb-3">
                                                        <div class="col-md-6">
                                                            <span class="text-muted small d-block">STUDENT NAME</span>
                                                            <strong class="text-dark"><?= e($fullName) ?></strong>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <span class="text-muted small d-block">ADMISSION NO</span>
                                                            <strong class="font-monospace text-dark"><?= e($admNo) ?></strong>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <span class="text-muted small d-block">CLASS</span>
                                                            <strong class="text-dark"><?= e($inv['class_name'] ?? 'Class 1') ?></strong>
                                                        </div>
                                                    </div>

                                                    <!-- Invoice Items Summary -->
                                                    <div class="table-responsive mb-3">
                                                        <table class="table table-bordered mb-0">
                                                            <thead class="table-light small fw-bold">
                                                                <tr>
                                                                    <th>Fee Description</th>
                                                                    <th class="text-end" style="width: 140px;">Amount (₹)</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>Tuition Fee (Standard Term Billing)</td>
                                                                    <td class="text-end font-monospace">₹<?= number_format($totalAmt * 0.78, 2) ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Transport &amp; Facility Service</td>
                                                                    <td class="text-end font-monospace">₹<?= number_format($totalAmt * 0.22, 2) ?></td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot class="table-light">
                                                                <tr>
                                                                    <th class="text-end">Total Billed:</th>
                                                                    <th class="text-end font-monospace">₹<?= number_format($totalAmt, 2) ?></th>
                                                                </tr>
                                                                <tr>
                                                                    <th class="text-end text-success">Total Paid:</th>
                                                                    <th class="text-end font-monospace text-success">₹<?= number_format($paidAmt, 2) ?></th>
                                                                </tr>
                                                                <tr>
                                                                    <th class="text-end text-danger">Balance Due:</th>
                                                                    <th class="text-end font-monospace text-danger">₹<?= number_format($balance, 2) ?></th>
                                                                </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>

                                                    <div class="d-flex justify-content-between align-items-center text-muted small pt-2">
                                                        <span>Status: <strong><?= strtoupper($invStatus) ?></strong></span>
                                                        <span>Authorized Signature: _________________________</span>
                                                    </div>
                                                </div>
                                                <div class="modal-footer py-2 px-4 border-top">
                                                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteInvoiceModal<?= $invId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-sm">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h6 class="modal-title fw-bold text-dark">Confirm Delete</h6>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?= e(url('finance/invoices/' . $invId . '/delete')) ?>">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-body p-4 text-center">
                                                        <i data-lucide="alert-triangle" class="text-danger mb-2" style="width: 36px; height: 36px;"></i>
                                                        <p class="mb-0 small text-muted">Are you sure you want to remove invoice <strong><?= e($invNo) ?></strong>?</p>
                                                    </div>
                                                    <div class="modal-footer py-2 px-4 border-top d-flex justify-content-between">
                                                        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-sm btn-danger px-3 fw-medium">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Table Footer / Pagination -->
        <div class="p-3 bg-white border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
            <span class="text-muted small" style="font-size: 0.8rem;">
                Showing 1 to <?= min(25, $totalInvoicesCount) ?> of <?= $totalInvoicesCount ?> records
            </span>

            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small" style="font-size: 0.8rem;">Rows:</span>
                <select class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" style="width: 70px; height: 32px; font-size: 0.8rem;">
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Modal: + Create Invoice -->
<div class="modal fade" id="createInvoiceModal" tabindex="-1" aria-labelledby="createInvoiceModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header py-3 px-4 border-bottom">
                <h5 class="modal-title fw-bold text-dark" id="createInvoiceModalLabel">Create Fee Invoice</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('finance/invoices')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="row g-3 mb-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Student</label>
                            <select name="student_id" class="form-select rounded-3 shadow-none border-light-subtle" required>
                                <option value="">Select Student...</option>
                                <?php foreach ($students as $st): ?>
                                    <option value="<?= $st['id'] ?>">
                                        <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Invoice Title</label>
                            <input type="text" name="title" value="Term Tuition &amp; Service Fee" class="form-control rounded-3 shadow-none border-light-subtle" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Invoice Date</label>
                            <input type="date" name="invoice_date" value="<?= date('Y-m-d') ?>" class="form-control rounded-3 shadow-none border-light-subtle" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Due Date</label>
                            <input type="date" name="due_date" value="<?= date('Y-m-d', strtotime('+14 days')) ?>" class="form-control rounded-3 shadow-none border-light-subtle" required>
                        </div>
                    </div>

                    <!-- Line Items -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-2" style="font-size: 0.74rem;">Fee Line Items</label>
                        <div id="invoiceItemsList">
                            <div class="row g-2 align-items-center mb-2 item-row">
                                <div class="col-6">
                                    <input type="text" name="item_desc[]" class="form-control form-control-sm rounded-3 shadow-none border-light-subtle" placeholder="Tuition Fee" value="Tuition Fee" required>
                                </div>
                                <div class="col-4">
                                    <input type="number" step="0.01" name="item_amount[]" class="form-control form-control-sm rounded-3 shadow-none border-light-subtle item-amount-input" placeholder="500.00" value="500.00" required>
                                </div>
                                <div class="col-2">
                                    <select name="item_category[]" class="form-select form-select-sm rounded-3 shadow-none border-light-subtle">
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row g-3 mb-2">
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Discount (₹)</label>
                            <input type="number" step="0.01" name="discount" value="0.00" class="form-control rounded-3 shadow-none border-light-subtle">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Notes</label>
                            <input type="text" name="notes" placeholder="Optional invoice notes..." class="form-control rounded-3 shadow-none border-light-subtle">
                        </div>
                    </div>
                </div>
                <div class="modal-footer py-2 px-4 border-top">
                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Create Invoice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.action-icon-btn {
    opacity: 0.65;
    transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
}
.action-icon-btn:hover {
    opacity: 1;
    transform: scale(1.15);
}
.invoice-link:hover {
    color: #4f46e5 !important;
    text-decoration: underline !important;
}
@media print {
    body * {
        visibility: hidden;
    }
    .modal.show .modal-body, .modal.show .modal-body * {
        visibility: visible;
    }
    .modal.show .modal-body {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        margin: 0;
        padding: 20px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Select all invoices checkbox toggle
    const selectAll = document.getElementById('selectAllInvoices');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            const rowCheckboxes = document.querySelectorAll('.invoice-select-row');
            rowCheckboxes.forEach(cb => cb.checked = selectAll.checked);
        });
    }

    // Client-side real-time live search
    const searchInput = document.getElementById('invoiceLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.invoice-data-row');

            rows.forEach(row => {
                const invNo = row.getAttribute('data-invoice-no') || '';
                const student = row.getAttribute('data-student') || '';
                const adm = row.getAttribute('data-adm') || '';
                if (!query || invNo.includes(query) || student.includes(query) || adm.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});

function printInvoiceVoucher(elementId) {
    window.print();
}
</script>
