<?php
$title = 'Payment Reconciliation & Ledger Integrity';
$rec = $reconciliation ?? [];
$methods = $rec['methods'] ?? [];
$discrepancies = $rec['discrepancies'] ?? [];
$from = $from ?? date('Y-m-01');
$to = $to ?? date('Y-m-d');
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="scale" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Audit & Verification
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Reconcile payment methods, cash deposits, verified transaction fees, and cross-check invoice ledger integrity.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('finance/refunds')) ?>" class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1">
      <i data-lucide="rotate-ccw" style="width: 14px; height: 14px;"></i> Refund Ledger
    </a>
    <a href="<?= e(url('finance/payments')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Payments
    </a>
  </div>
</div>

<!-- Date Filter Card -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('finance/reconciliation')) ?>" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small text-muted mb-1">From Date</label>
        <input type="date" name="from" value="<?= e($from) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4">
        <label class="form-label small text-muted mb-1">To Date</label>
        <input type="date" name="to" value="<?= e($to) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-1">
          <i data-lucide="filter" style="width: 14px; height: 14px;"></i> Filter Reconciliation
        </button>
        <button type="button" onclick="window.print()" class="btn btn-outline-dark btn-sm">
          <i data-lucide="printer" style="width: 14px; height: 14px;"></i>
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Reconciliation Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Gross Collections</div>
          <div class="fs-4 fw-bold text-primary"><?= formatMoney((float) ($rec['gross_collection'] ?? 0)) ?></div>
          <div class="text-muted" style="font-size: 11px;"><?= (int) ($rec['total_transactions'] ?? 0) ?> Total Transactions</div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="plus-circle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Refunds</div>
          <div class="fs-4 fw-bold text-danger">-<?= formatMoney((float) ($rec['total_refunds'] ?? 0)) ?></div>
          <div class="text-muted" style="font-size: 11px;"><?= (int) ($rec['refund_count'] ?? 0) ?> Processed Refunds</div>
        </div>
        <div class="rounded-3 p-2 bg-danger-subtle text-danger">
          <i data-lucide="minus-circle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Net Banked / Retained</div>
          <div class="fs-4 fw-bold text-success"><?= formatMoney((float) ($rec['net_collection'] ?? 0)) ?></div>
          <div class="text-muted" style="font-size: 11px;">Reconciled Total</div>
        </div>
        <div class="rounded-3 p-2 bg-success-subtle text-success">
          <i data-lucide="check-circle-2" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Ledger Discrepancies</div>
          <div class="fs-4 fw-bold <?= empty($discrepancies) ? 'text-success' : 'text-danger' ?>">
            <?= count($discrepancies) ?>
          </div>
          <div class="text-muted" style="font-size: 11px;"><?= empty($discrepancies) ? '100% Balanced' : 'Action Required' ?></div>
        </div>
        <div class="rounded-3 p-2 <?= empty($discrepancies) ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>">
          <i data-lucide="<?= empty($discrepancies) ? 'shield-check' : 'alert-triangle' ?>" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Payment Channels Breakdown -->
<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
      <div class="card-header bg-white border-bottom py-3">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="credit-card" class="text-primary" style="width: 18px; height: 18px;"></i>
          Collections by Payment Channel
        </h5>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Payment Channel</th>
                <th class="text-center">Transactions</th>
                <th class="text-end">Total Collected</th>
                <th class="text-end pe-3">% Share</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($methods)): ?>
                <tr><td colspan="4" class="text-center py-4 text-muted">No payments in selected date range.</td></tr>
              <?php else: 
                $gross = (float) ($rec['gross_collection'] ?? 0);
              ?>
                <?php foreach ($methods as $m): 
                  $share = $gross > 0 ? round(((float)$m['total_amount'] / $gross) * 100, 1) : 0;
                ?>
                  <tr>
                    <td class="ps-3 py-3 fw-bold text-dark text-capitalize">
                      <i data-lucide="wallet" class="me-1 text-muted" style="width: 14px; height: 14px;"></i>
                      <?= e($m['payment_method']) ?>
                    </td>
                    <td class="text-center">
                      <span class="badge bg-light text-dark border"><?= (int) $m['transaction_count'] ?></span>
                    </td>
                    <td class="text-end font-monospace fw-semibold text-primary">
                      <?= formatMoney((float) $m['total_amount']) ?>
                    </td>
                    <td class="text-end pe-3 small text-muted">
                      <?= $share ?>%
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Discrepancy & Anomaly Scanner -->
  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
      <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="shield-alert" class="text-primary" style="width: 18px; height: 18px;"></i>
          Ledger Integrity Scanner
        </h5>
        <span class="badge <?= empty($discrepancies) ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> px-2 py-1 rounded-pill small">
          <?= empty($discrepancies) ? 'Verified Clean' : count($discrepancies) . ' Anomalies' ?>
        </span>
      </div>
      <div class="card-body p-0">
        <?php if (empty($discrepancies)): ?>
          <div class="text-center py-5 px-3">
            <div class="rounded-circle bg-success-subtle text-success d-inline-flex p-3 mb-2">
              <i data-lucide="check-check" style="width: 32px; height: 32px;"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Zero Ledger Discrepancies</h6>
            <p class="text-muted small mb-0">Every invoice balance perfectly reconciles with payments minus refunds.</p>
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                  <th class="ps-3">Invoice #</th>
                  <th>Recorded Paid</th>
                  <th>Expected Paid</th>
                  <th class="text-end pe-3">Variance</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($discrepancies as $d): 
                  $diff = round((float)$d['paid_amount'] - (float)$d['expected_paid'], 2);
                ?>
                  <tr>
                    <td class="ps-3 font-monospace small fw-bold">
                      <a href="<?= e(url('finance/invoices/' . $d['id'])) ?>">#<?= e($d['invoice_no']) ?></a>
                    </td>
                    <td class="font-monospace small"><?= formatMoney((float) $d['paid_amount']) ?></td>
                    <td class="font-monospace small"><?= formatMoney((float) $d['expected_paid']) ?></td>
                    <td class="text-end pe-3 font-monospace fw-bold text-danger">
                      <?= $diff > 0 ? '+' : '' ?><?= formatMoney($diff) ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
