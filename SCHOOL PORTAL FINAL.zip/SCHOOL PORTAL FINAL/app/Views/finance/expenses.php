<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-hand-holding-usd text-danger me-2"></i> School Expenses</h2>
        <p class="text-muted mb-0">Track and manage operational costs, bills, and everyday expenditures.</p>
    </div>
    <?php if (hasPermission('finance.manage')): ?>
    <button class="btn btn-danger d-flex align-items-center gap-2 shadow-sm action-hover" data-bs-toggle="modal" data-bs-target="#addExpenseModal">
        <i class="fas fa-plus-circle"></i> Record Expense
    </button>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3" style="width: 15%;">Date</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3" style="width: 45%;">Expense Details</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3" style="width: 20%;">Category</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end px-4" style="width: 20%;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($expenses as $ex): ?>
                <tr class="expense-row">
                    <td class="px-4 py-3 text-sm">
                        <div class="d-flex align-items-center gap-2 text-secondary fw-semibold">
                            <i class="far fa-calendar-alt text-muted"></i> 
                            <?= e(formatDate($ex['expense_date'])) ?>
                        </div>
                    </td>
                    <td class="py-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm bg-danger-subtle text-danger rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 42px; height: 42px;">
                                <i class="fas fa-receipt"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($ex['title']) ?></h6>
                                <span class="text-xs text-muted"><i class="fas fa-info-circle me-1 text-light"></i> Transaction Record</span>
                            </div>
                        </div>
                    </td>
                    <td class="py-3 text-sm fw-medium">
                        <span class="badge bg-light text-dark border px-2 py-1"><i class="fas fa-tags text-muted me-1"></i> <?= e($ex['category'] ?: 'Uncategorized') ?></span>
                    </td>
                    <td class="py-3 text-sm fw-bold text-danger text-end px-4">
                        <?= e(formatMoney($ex['amount'])) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($expenses)): ?>
                <tr>
                    <td colspan="4" class="text-center py-5 text-muted">
                        <i class="fas fa-wallet fa-3x mb-3 text-light"></i>
                        <p class="mb-0">No expenses recorded yet.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (hasPermission('finance.manage')): ?>
<!-- Add Expense Modal -->
<div class="modal fade" id="addExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-danger text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-file-invoice-dollar me-2"></i> Record New Expense</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('finance/expenses')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Expense Title/Description <span class="text-danger">*</span></label>
                        <div class="input-group shadow-sm rounded-3 overflow-hidden">
                            <span class="input-group-text bg-white border-0"><i class="fas fa-edit text-muted"></i></span>
                            <input type="text" name="title" class="form-control border-0 bg-white" required placeholder="e.g. Electricity Bill, Stationery">
                        </div>
                    </div>
                    
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Amount <span class="text-danger">*</span></label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-dollar-sign text-muted"></i></span>
                                <input type="number" step="0.01" name="amount" class="form-control border-0 bg-white" required placeholder="0.00">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Expense Date</label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-calendar-day text-muted"></i></span>
                                <input type="date" name="expense_date" class="form-control border-0 bg-white" value="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Category</label>
                        <div class="input-group shadow-sm rounded-3 overflow-hidden">
                            <span class="input-group-text bg-white border-0"><i class="fas fa-folder-open text-muted"></i></span>
                            <input type="text" name="category" class="form-control border-0 bg-white" placeholder="e.g. Utilities, Maintenance, Transport">
                        </div>
                        <small class="text-muted mt-1 d-block">Organize expenses by typing a category name.</small>
                    </div>

                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-save me-1"></i> Save Expense</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
    /* Premium Hover Effects */
    .expense-row {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        border-radius: 12px;
    }
    .expense-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px -10px rgba(0, 0, 0, 0.1);
        z-index: 10;
        position: relative;
    }
    .expense-row:hover .avatar {
        transform: scale(1.1) rotate(5deg);
        box-shadow: 0 4px 10px rgba(220, 53, 69, 0.25) !important;
    }
    
    .bg-danger-subtle {
        background-color: #f8d7da !important;
    }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15) !important;
    }
    
    .table > :not(caption) > * > * {
        border-bottom-color: #f1f5f9;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #f5c2c7;
        box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
    }
</style>
