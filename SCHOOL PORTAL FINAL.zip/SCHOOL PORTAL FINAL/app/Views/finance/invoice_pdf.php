<div class="print-container container mt-4 bg-white p-5 shadow-sm">
    <div class="d-flex justify-content-between align-items-start mb-4">
        <div>
            <h2><?= htmlspecialchars($school['name'] ?? 'School Portal') ?></h2>
            <address>
                <?= htmlspecialchars($school['address'] ?? '') ?><br>
                <?= htmlspecialchars($school['phone'] ?? '') ?>
            </address>
        </div>
        <div class="text-end">
            <h1 class="h3 text-uppercase text-muted">Invoice</h1>
            <p class="mb-0"><strong>Invoice #:</strong> <?= htmlspecialchars($invoice['invoice_no']) ?></p>
            <p class="mb-0"><strong>Date:</strong> <?= htmlspecialchars($invoice['invoice_date']) ?></p>
            <p class="mb-0"><strong>Due Date:</strong> <?= htmlspecialchars($invoice['due_date']) ?></p>
        </div>
    </div>

    <?php if ($invoice['status'] === 'paid'): ?>
    <div class="watermark-paid" style="position: absolute; top: 40%; left: 35%; font-size: 8rem; color: rgba(40, 167, 69, 0.15); transform: rotate(-45deg); pointer-events: none; z-index: 0;">
        PAID
    </div>
    <?php elseif ($invoice['status'] === 'unpaid'): ?>
    <div class="watermark-unpaid" style="position: absolute; top: 40%; left: 25%; font-size: 8rem; color: rgba(220, 53, 69, 0.15); transform: rotate(-45deg); pointer-events: none; z-index: 0;">
        UNPAID
    </div>
    <?php endif; ?>

    <div class="row mb-4 position-relative" style="z-index: 1;">
        <div class="col-sm-6">
            <h6 class="mb-3 text-uppercase text-muted">Bill To:</h6>
            <div>
                <strong><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></strong>
            </div>
            <div>Admission No: <?= htmlspecialchars($student['admission_no']) ?></div>
            <div>Class: <?= htmlspecialchars($student['class_name'] ?? '') ?> <?= htmlspecialchars($student['section_name'] ?? '') ?></div>
        </div>
    </div>

    <table class="table table-striped table-bordered mb-4 position-relative" style="z-index: 1;">
        <thead class="table-light">
            <tr>
                <th>Description</th>
                <th class="text-end">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['description']) ?></td>
                <td class="text-end"><?= number_format((float)$item['amount'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td class="text-end fw-bold">Subtotal</td>
                <td class="text-end fw-bold"><?= number_format((float)$invoice['total_amount'] + (float)$invoice['discount'], 2) ?></td>
            </tr>
            <?php if ($invoice['discount'] > 0): ?>
            <tr>
                <td class="text-end fw-bold">Discount</td>
                <td class="text-end fw-bold text-danger">-<?= number_format((float)$invoice['discount'], 2) ?></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td class="text-end fw-bold fs-5">Total</td>
                <td class="text-end fw-bold fs-5"><?= number_format((float)$invoice['total_amount'], 2) ?></td>
            </tr>
            <tr>
                <td class="text-end fw-bold text-success">Paid</td>
                <td class="text-end fw-bold text-success"><?= number_format((float)$invoice['paid_amount'], 2) ?></td>
            </tr>
            <tr>
                <td class="text-end fw-bold text-danger">Balance Due</td>
                <td class="text-end fw-bold text-danger"><?= number_format((float)$invoice['total_amount'] - (float)$invoice['paid_amount'], 2) ?></td>
            </tr>
        </tfoot>
    </table>

    <div class="mt-5 text-center position-relative" style="z-index: 1;">
        <button onclick="window.print()" class="btn btn-primary d-print-none btn-lg px-5">
            <i class="bi bi-printer me-2"></i> Print PDF
        </button>
    </div>
</div>

<style>
@media print {
    body * {
        visibility: hidden;
    }
    .print-container, .print-container * {
        visibility: visible;
    }
    .print-container {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }
    .d-print-none { 
        display: none !important; 
    }
}
</style>
