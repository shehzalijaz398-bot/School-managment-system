<?php
$title = 'Class-wise Fee Structures & Installments';
$structures = $structures ?? [];
$classes = $classes ?? [];
$categories = $categories ?? [];
$selectedClass = $selectedClass ?? null;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="layers" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Tuition Matrix
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Define grade and class-specific fee schedules, installment breakdowns, and term billing rates.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newStructureModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> Add Fee Structure
    </button>
    <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Invoices
    </a>
  </div>
</div>

<!-- Class Filter Card -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('finance/fee-structures')) ?>" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small text-muted mb-1">Filter by Class / Grade</label>
        <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="">-- All Classes &amp; Grades --</option>
          <?php foreach ($classes as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $selectedClass == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <a href="<?= e(url('finance/fee-structures')) ?>" class="btn btn-outline-secondary btn-sm w-100">Reset</a>
      </div>
    </form>
  </div>
</div>

<!-- Structures Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3">Class</th>
            <th>Fee Category</th>
            <th>Fee Head Title</th>
            <th>Installment #</th>
            <th>Due Month</th>
            <th class="text-end pe-3">Standard Amount ($)</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($structures)): ?>
            <tr>
              <td colspan="6" class="text-center py-4 text-muted">No class fee structures configured yet. Click "Add Fee Structure" to establish rate matrix.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($structures as $s): ?>
              <tr>
                <td class="ps-3 fw-bold text-dark"><?= e($s['class_name']) ?></td>
                <td>
                  <span class="badge bg-light text-dark border">
                    <?= e($s['category_name']) ?> (<?= e($s['category_code']) ?>)
                  </span>
                </td>
                <td class="fw-semibold text-primary"><?= e($s['title']) ?></td>
                <td>Installment <?= e($s['installment_no']) ?></td>
                <td><?= $s['due_month'] ? 'Month ' . e($s['due_month']) : 'Per Term / Session' ?></td>
                <td class="text-end pe-3 font-monospace fw-bold fs-6"><?= number_format((float)$s['amount'], 2) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Add Fee Structure -->
<div class="modal fade" id="newStructureModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('finance/fee-structures')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold">Add Class Fee Structure</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Class / Grade <span class="text-danger">*</span></label>
            <select name="class_id" class="form-select form-select-sm" required>
              <option value="">-- Select Class --</option>
              <?php foreach ($classes as $c): ?>
                <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Fee Category <span class="text-danger">*</span></label>
            <select name="fee_category_id" class="form-select form-select-sm" required>
              <option value="">-- Select Category --</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?> (<?= e($cat['code']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Title / Description <span class="text-danger">*</span></label>
            <input type="text" name="title" placeholder="e.g. Term 1 Tuition Fee" class="form-control form-control-sm" required>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Amount ($) <span class="text-danger">*</span></label>
              <input type="number" step="0.01" min="0" name="amount" placeholder="0.00" class="form-control form-control-sm" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Installment #</label>
              <input type="number" min="1" max="12" name="installment_no" value="1" class="form-control form-control-sm">
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Save Fee Structure</button>
        </div>
      </form>
    </div>
  </div>
</div>
