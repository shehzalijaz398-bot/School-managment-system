<?php
$title = 'Trial Balance Statement';
$report = $report ?? [];
$accounts = $report['accounts'] ?? [];
$asOf = $asOf ?? date('Y-m-d');
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="scale" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <?php if ($report['is_balanced'] ?? true): ?>
        <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded-pill small">
          ✓ Verified In Balance
        </span>
      <?php else: ?>
        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1 rounded-pill small">
          ⚠️ Out of Balance
        </span>
      <?php endif; ?>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Cumulative debit and credit balances for all ledger accounts as of <?= e($asOf) ?>.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('finance/trial-balance?as_of=' . urlencode($asOf) . '&format=csv')) ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1">
      <i data-lucide="download" style="width: 14px; height: 14px;"></i> Export CSV
    </a>
    <button type="button" onclick="window.print()" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Statement
    </button>
    <a href="<?= e(url('finance/accounting')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Accounting
    </a>
  </div>
</div>

<!-- As of Date Filter -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('finance/trial-balance')) ?>" class="row g-2 align-items-end">
      <div class="col-md-6 col-lg-4">
        <label class="form-label small text-muted mb-1">Statement As Of Date</label>
        <input type="date" name="as_of" value="<?= e($asOf) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
          <i data-lucide="refresh-cw" style="width: 14px; height: 14px;"></i> Update Statement
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Trial Balance Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3" style="width: 15%;">Account Code</th>
            <th style="width: 40%;">Account Title</th>
            <th style="width: 15%;">Type</th>
            <th class="text-end" style="width: 15%;">Debit Balance ($)</th>
            <th class="text-end pe-3" style="width: 15%;">Credit Balance ($)</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($accounts)): ?>
            <tr>
              <td colspan="5" class="text-center py-4 text-muted">No accounts recorded.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($accounts as $a): ?>
              <tr>
                <td class="ps-3 font-monospace fw-bold text-primary"><?= e($a['code']) ?></td>
                <td class="fw-semibold text-dark">
                  <a href="<?= e(url('finance/ledger/account/' . $a['id'])) ?>" class="text-decoration-none text-dark">
                    <?= e($a['name']) ?>
                  </a>
                </td>
                <td><span class="badge bg-light text-muted border text-uppercase small"><?= e($a['type']) ?></span></td>
                <td class="text-end font-monospace">
                  <?= $a['debit_balance'] > 0 ? number_format((float)$a['debit_balance'], 2) : '—' ?>
                </td>
                <td class="text-end pe-3 font-monospace">
                  <?= $a['credit_balance'] > 0 ? number_format((float)$a['credit_balance'], 2) : '—' ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
        <tfoot class="table-light border-top border-2 border-dark font-monospace fw-bold">
          <tr>
            <td colspan="3" class="ps-3 text-uppercase">Total Ledger Balances</td>
            <td class="text-end text-primary fs-6"><?= number_format((float)($report['total_debit'] ?? 0), 2) ?></td>
            <td class="text-end pe-3 text-primary fs-6"><?= number_format((float)($report['total_credit'] ?? 0), 2) ?></td>
          </tr>
          <?php if (!($report['is_balanced'] ?? true)): ?>
            <tr class="table-danger text-danger">
              <td colspan="3" class="ps-3">DISCREPANCY (Debits ≠ Credits)</td>
              <td colspan="2" class="text-end pe-3">$<?= number_format((float)($report['discrepancy'] ?? 0), 2) ?></td>
            </tr>
          <?php endif; ?>
        </tfoot>
      </table>
    </div>
  </div>
</div>
