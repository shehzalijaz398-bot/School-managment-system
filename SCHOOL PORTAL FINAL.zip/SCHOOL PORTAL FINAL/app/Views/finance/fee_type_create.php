<?php
/**
 * CodeClove School Management Pro — New Fee Type View
 * Pixel-perfect match to official CodeClove Finance / Fee Types / New Fee Type workflow
 */
?>

<style>
.cc-fee-type-container {
  max-width: 1200px;
  margin: 0 auto;
}
.cc-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem 1.75rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
  margin-bottom: 1.5rem;
  transition: border-color 0.15s ease;
}
.cc-card:hover {
  border-color: #cbd5e1;
}
.cc-section-title {
  font-size: 0.76rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 1.25rem;
}
.cc-form-label {
  font-size: 0.82rem;
  font-weight: 600;
  color: #334155;
  margin-bottom: 0.35rem;
  display: block;
}
.cc-form-label .req {
  color: #dc2626;
  font-weight: 700;
}
.cc-input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.5rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
}
.cc-textarea {
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.65rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
  resize: vertical;
}
.cc-input:focus, .cc-textarea:focus {
  border-color: #4f46e5;
  outline: none;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.cc-input::placeholder, .cc-textarea::placeholder {
  color: #94a3b8;
  font-size: 0.84rem;
}
.cc-btn-cancel {
  border: 1px solid #e2e8f0;
  background: #ffffff;
  color: #475569;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.25rem;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.cc-btn-cancel:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-btn-submit {
  background: #4f46e5;
  border: 1px solid #4f46e5;
  color: #ffffff;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.5rem;
  border-radius: 8px;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(79, 70, 229, 0.2);
}
.cc-btn-submit:hover {
  background: #4338ca;
  border-color: #4338ca;
  color: #ffffff;
}
.cc-about-box {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem 1.5rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
}
.cc-about-title {
  font-size: 0.76rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 1rem;
}
.cc-about-text {
  font-size: 0.85rem;
  color: #475569;
  line-height: 1.55;
  margin-bottom: 1.25rem;
}
.cc-about-bullets {
  list-style: none;
  padding: 0;
  margin: 0;
}
.cc-about-bullets li {
  font-size: 0.83rem;
  color: #475569;
  margin-bottom: 0.65rem;
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
}
.cc-about-bullets li::before {
  content: "•";
  color: #64748b;
  font-size: 1rem;
  line-height: 1;
}
.cc-about-bullets strong {
  color: #1e293b;
  font-weight: 600;
}
</style>

<div class="cc-fee-type-container mb-5">

  <!-- 1. Breadcrumbs -->
  <nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-muted text-decoration-none">Finance</a></li>
      <li class="breadcrumb-item"><a href="<?= e(url('finance/fee-types')) ?>" class="text-muted text-decoration-none">Fee Types</a></li>
      <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">New Fee Type</li>
    </ol>
  </nav>

  <form method="post" action="<?= e(url('finance/fee-types')) ?>" id="newFeeTypeForm">
    <?= csrf_field() ?>

    <!-- 2. Page Header with Action Buttons -->
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
      <div>
        <div class="d-flex align-items-center gap-2 mb-1">
          <a href="<?= e(url('finance/fee-types')) ?>" class="btn btn-sm btn-white border d-inline-flex align-items-center justify-content-center text-muted" style="width: 32px; height: 32px; border-radius: 8px; background: #ffffff; border-color: #e2e8f0;" title="Back to Fee Types">
            <i data-lucide="arrow-left" style="width: 18px; height: 18px;"></i>
          </a>
          <h1 class="h3 fw-bold text-dark mb-0" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'New Fee Type') ?>
          </h1>
        </div>
        <p class="text-muted small mb-0 ps-1" style="margin-left: 36px;">Create a reusable fee template that can be applied to any invoice.</p>
      </div>

      <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('finance/fee-types')) ?>" class="btn cc-btn-cancel text-decoration-none">Cancel</a>
        <button type="submit" class="btn cc-btn-submit">Create Fee Type</button>
      </div>
    </div>

    <!-- 3. Main 2-Column Layout -->
    <div class="row g-4">

      <!-- LEFT COLUMN: Form Fields (col-lg-8) -->
      <div class="col-12 col-lg-8">
        <div class="cc-card">

          <!-- ==========================================
               SECTION 1: BASIC DETAILS
               ========================================== -->
          <div class="cc-section-title">
            <span>BASIC DETAILS</span>
          </div>

          <!-- Fee Name * -->
          <div class="mb-3">
            <label class="cc-form-label">Fee Name <span class="req">*</span></label>
            <input type="text" name="name" class="cc-input" required autofocus placeholder="e.g. Tuition Fee, Transport Fee, Exam Fee">
          </div>

          <!-- Unique Code & Default Amount (INR) (2 cols) -->
          <div class="row g-3 mb-3">
            <div class="col-12 col-md-6">
              <label class="cc-form-label">Unique Code</label>
              <input type="text" name="code" class="cc-input" placeholder="e.g. TUITION, TRANSPORT">
              <div class="text-muted mt-1" style="font-size: 11px;">Used in reports and bulk fee generation</div>
            </div>

            <div class="col-12 col-md-6">
              <label class="cc-form-label">Default Amount (INR)</label>
              <input type="number" step="0.01" min="0" name="amount" class="cc-input" value="0.00" placeholder="0.00">
            </div>
          </div>

          <!-- Description -->
          <div class="mb-4">
            <label class="cc-form-label">Description</label>
            <textarea name="description" rows="3" class="cc-textarea" placeholder="What charges are covered under this fee? (optional)"></textarea>
          </div>

          <!-- ==========================================
               SECTION 2: BILLING SETTINGS
               ========================================== -->
          <div class="pt-3 border-top">
            <div class="cc-section-title mt-2">
              <span>BILLING SETTINGS</span>
            </div>

            <!-- Billing Frequency & Scope (2 cols) -->
            <div class="row g-3 mb-3">
              <div class="col-12 col-md-6">
                <label class="cc-form-label">Billing Frequency</label>
                <select name="frequency" class="cc-input form-select">
                  <option value="one_time" selected>One Time &mdash; Registration, Exam, Activity</option>
                  <option value="monthly">Monthly &mdash; Recurring monthly fee</option>
                  <option value="term">Term &mdash; Billed once per academic term</option>
                  <option value="annual">Annual &mdash; Billed once per academic year</option>
                </select>
                <div class="text-muted mt-1" style="font-size: 11px;">How often this fee recurs in a school year</div>
              </div>

              <div class="col-12 col-md-6">
                <label class="cc-form-label">Scope</label>
                <select name="scope" class="cc-input form-select">
                  <option value="global" selected>Global &mdash; applies to all students</option>
                  <option value="class_specific">Class Specific &mdash; applies to selected grades</option>
                </select>
                <div class="text-muted mt-1" style="font-size: 11px;">Who this fee applies to</div>
              </div>
            </div>

            <!-- Status -->
            <div class="row g-3">
              <div class="col-12 col-md-6">
                <label class="cc-form-label">Status</label>
                <select name="status" class="cc-input form-select">
                  <option value="1" selected>Active &mdash; available when building invoices</option>
                  <option value="0">Inactive &mdash; hidden from invoice builder</option>
                </select>
              </div>
            </div>

          </div>

        </div>
      </div>

      <!-- RIGHT COLUMN: ABOUT FEE TYPES (col-lg-4) -->
      <div class="col-12 col-lg-4">
        <div class="cc-about-box">
          <div class="cc-about-title">
            <span>ABOUT FEE TYPES</span>
          </div>

          <p class="cc-about-text">
            Fee types are reusable templates. When you add a fee to an invoice, you pick a type and the default amount is auto-filled &mdash; you can adjust per invoice.
          </p>

          <ul class="cc-about-bullets">
            <li>
              <span>Set a <strong>Default Amount</strong> for most students</span>
            </li>
            <li>
              <span>Use <strong>Class Overrides</strong> when fees differ by grade</span>
            </li>
            <li>
              <span>Set <strong>Inactive</strong> to hide from invoice builder without deleting</span>
            </li>
          </ul>
        </div>
      </div>

    </div>

  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
</script>
