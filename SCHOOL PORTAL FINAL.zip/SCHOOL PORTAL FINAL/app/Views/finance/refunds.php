<?php
$title = 'Fee Refund Audit Ledger';
$refunds = $refunds ?? [];

$totAmount = 0.0;
foreach ($refunds as $r) {
    $totAmount += (float) ($r['amount'] ?? 0);
}
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="rotate-ccw" class="text-danger me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1 rounded-pill small">
        Financial Audit Trail
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Immutable ledger of all fee refunds, reversals, student concession adjustments, and processing staff.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-danger btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newRefundModal">
      <i data-lucide="plus" style="width: 14px; height: 14px;"></i> Process Refund
    </button>
    <a href="<?= e(url('finance/reconciliation')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="scale" style="width: 14px; height: 14px;"></i> Reconciliation
    </a>
  </div>
</div>

<!-- Metrics Row -->
<div class="row g-3 mb-4">
  <div class="col-md-4 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Refund Volume</div>
          <div class="fs-4 fw-bold text-danger"><?= formatMoney($totAmount) ?></div>
          <div class="text-muted" style="font-size: 11px;">Total Returned Funds</div>
        </div>
        <div class="rounded-3 p-2 bg-danger-subtle text-danger">
          <i data-lucide="arrow-down-left" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Refund Count</div>
          <div class="fs-4 fw-bold text-dark"><?= count($refunds) ?></div>
          <div class="text-muted" style="font-size: 11px;">Audited Transactions</div>
        </div>
        <div class="rounded-3 p-2 bg-light text-dark border">
          <i data-lucide="receipt" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4 col-12">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Audit Compliance</div>
          <div class="fs-4 fw-bold text-success">100% Traceable</div>
          <div class="text-muted" style="font-size: 11px;">Invoice &amp; Cashier Linked</div>
        </div>
        <div class="rounded-3 p-2 bg-success-subtle text-success">
          <i data-lucide="shield-check" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Refunds Ledger Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-header bg-white border-bottom py-3">
    <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
      <i data-lucide="file-spreadsheet" class="text-primary" style="width: 18px; height: 18px;"></i>
      Audited Refund Entries
    </h5>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr class="text-muted small text-uppercase" style="font-size: 11px;">
            <th class="ps-3">Refund #</th>
            <th>Receipt / Invoice</th>
            <th>Student</th>
            <th>Reason</th>
            <th>Method</th>
            <th class="text-end">Amount</th>
            <th>Processed By</th>
            <th class="text-end pe-3">Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($refunds)): ?>
            <tr>
              <td colspan="8" class="text-center py-5 text-muted">
                <i data-lucide="check-circle" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No refund transactions recorded.</p>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($refunds as $r): ?>
              <tr>
                <td class="ps-3 font-monospace small fw-bold text-danger">
                  <?= e($r['refund_no']) ?>
                </td>
                <td class="small">
                  <div><strong class="text-dark">RCP:</strong> <?= e($r['receipt_no']) ?></div>
                  <div class="text-muted font-monospace" style="font-size: 11px;">INV: <?= e($r['invoice_no']) ?></div>
                </td>
                <td>
                  <div class="fw-semibold text-dark small"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></div>
                  <div class="text-muted" style="font-size: 11px;"><?= e($r['admission_no']) ?></div>
                </td>
                <td class="small text-secondary" style="max-width: 200px;">
                  <?= e($r['reason']) ?>
                </td>
                <td>
                  <span class="badge bg-light text-dark border px-2 py-1 small text-capitalize">
                    <?= e($r['refund_method']) ?>
                  </span>
                </td>
                <td class="text-end font-monospace fw-bold text-danger">
                  -<?= formatMoney((float) $r['amount']) ?>
                </td>
                <td class="small text-muted">
                  <?= e($r['processed_by_name'] ?? 'Admin') ?>
                </td>
                <td class="text-end pe-3 small text-muted">
                  <?= date('M d, Y H:i', strtotime($r['created_at'])) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Process New Refund -->
<div class="modal fade" id="newRefundModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-4 border-0 shadow">
      <div class="modal-header border-bottom">
        <h5 class="modal-title fw-bold text-dark d-flex align-items-center gap-2">
          <i data-lucide="rotate-ccw" class="text-danger" style="width: 18px; height: 18px;"></i>
          Process Payment Refund
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" id="refundForm" onsubmit="return confirm('Are you sure you want to process this refund? Invoice balance will be automatically adjusted.');">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Payment ID to Refund *</label>
            <input type="number" id="refundPaymentId" class="form-control" required placeholder="e.g. 15" oninput="document.getElementById('refundForm').action = '<?= e(url('finance/payments/')) ?>/' + this.value + '/refund';">
            <div class="form-text small">Enter the numeric Payment ID from the payments ledger.</div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Refund Amount *</label>
            <input type="number" step="0.01" min="0.01" name="amount" class="form-control font-monospace" required placeholder="0.00">
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Refund Method</label>
            <select name="refund_method" class="form-select">
              <option value="cash">Cash Handover</option>
              <option value="bank">Bank Transfer</option>
              <option value="online">Online Payment Gateway</option>
              <option value="cheque">Cheque</option>
            </select>
          </div>
          <div class="mb-0">
            <label class="form-label small fw-semibold text-dark">Audit Reason for Refund *</label>
            <textarea name="reason" rows="2" class="form-control" required placeholder="Reason for fee refund (e.g. Overpayment, Course withdrawal, Concession applied)"></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger btn-sm d-flex align-items-center gap-1">
            <i data-lucide="check" style="width: 14px; height: 14px;"></i> Confirm &amp; Deduct
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
