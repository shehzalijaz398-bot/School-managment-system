<?php
$title = 'Balance Sheet Statement';
$report = $report ?? [];
$assets = $report['assets'] ?? [];
$liabilities = $report['liabilities'] ?? [];
$equity = $report['equity'] ?? [];
$asOf = $asOf ?? date('Y-m-d');
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="file-text" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Financial Position
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Statement of Assets, Liabilities, and Institutional Capital as of <?= e($asOf) ?>.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('finance/balance-sheet?as_of=' . urlencode($asOf) . '&format=csv')) ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1">
      <i data-lucide="download" style="width: 14px; height: 14px;"></i> Export CSV
    </a>
    <button type="button" onclick="window.print()" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Balance Sheet
    </button>
    <a href="<?= e(url('finance/accounting')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Accounting
    </a>
  </div>
</div>

<!-- As of Date Filter -->
<div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
  <div class="card-body p-3">
    <form method="GET" action="<?= e(url('finance/balance-sheet')) ?>" class="row g-2 align-items-end">
      <div class="col-md-6 col-lg-4">
        <label class="form-label small text-muted mb-1">Statement As Of Date</label>
        <input type="date" name="as_of" value="<?= e($asOf) ?>" class="form-control form-control-sm">
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
          <i data-lucide="refresh-cw" style="width: 14px; height: 14px;"></i> Update Statement
        </button>
      </div>
    </form>
  </div>
</div>

<div class="row g-4">
  <!-- Left Column: Assets -->
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
      <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
        <h5 class="mb-0 fw-bold text-dark">
          <i data-lucide="building" class="text-primary me-1" style="width: 18px; height: 18px;"></i>
          ASSETS
        </h5>
        <span class="badge bg-light text-muted border font-monospace">
          Total: <?= formatMoney((float)($report['total_assets'] ?? 0)) ?>
        </span>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
              <tr>
                <th class="ps-3">Code</th>
                <th>Account Title</th>
                <th class="text-end pe-3">Balance ($)</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($assets)): ?>
                <tr><td colspan="3" class="text-center py-3 text-muted">No asset accounts recorded.</td></tr>
              <?php else: ?>
                <?php foreach ($assets as $a): ?>
                  <tr>
                    <td class="ps-3 font-monospace text-primary fw-bold"><?= e($a['code']) ?></td>
                    <td><?= e($a['name']) ?></td>
                    <td class="text-end pe-3 font-monospace fw-semibold"><?= number_format((float)$a['balance'], 2) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
            <tfoot class="table-light border-top border-2 border-dark font-monospace fw-bold">
              <tr>
                <td colspan="2" class="ps-3 text-uppercase">Total Assets</td>
                <td class="text-end pe-3 text-primary fs-6"><?= number_format((float)($report['total_assets'] ?? 0), 2) ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Right Column: Liabilities & Institutional Equity -->
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
      <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
        <h5 class="mb-0 fw-bold text-dark">
          <i data-lucide="shield-check" class="text-success me-1" style="width: 18px; height: 18px;"></i>
          LIABILITIES &amp; EQUITY
        </h5>
        <span class="badge bg-light text-muted border font-monospace">
          Total: <?= formatMoney((float)($report['total_claims'] ?? 0)) ?>
        </span>
      </div>
      <div class="card-body p-0">
        <!-- Liabilities Section -->
        <div class="p-3 bg-light border-bottom fw-bold small text-uppercase text-muted">
          Liabilities
        </div>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <tbody>
              <?php if (empty($liabilities)): ?>
                <tr><td colspan="3" class="text-center py-2 text-muted small">No liabilities recorded.</td></tr>
              <?php else: ?>
                <?php foreach ($liabilities as $l): ?>
                  <tr>
                    <td class="ps-3 font-monospace text-danger fw-bold" style="width: 20%;"><?= e($l['code']) ?></td>
                    <td><?= e($l['name']) ?></td>
                    <td class="text-end pe-3 font-monospace fw-semibold" style="width: 30%;"><?= number_format((float)$l['balance'], 2) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
              <tr class="fw-bold bg-light">
                <td colspan="2" class="ps-3 small text-uppercase">Total Liabilities</td>
                <td class="text-end pe-3 font-monospace"><?= number_format((float)($report['total_liabilities'] ?? 0), 2) ?></td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Equity Section -->
        <div class="p-3 bg-light border-top border-bottom fw-bold small text-uppercase text-muted">
          Institutional Equity &amp; Operating Surplus
        </div>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <tbody>
              <?php foreach ($equity as $e): ?>
                <tr>
                  <td class="ps-3 font-monospace text-info fw-bold" style="width: 20%;"><?= e($e['code']) ?></td>
                  <td><?= e($e['name']) ?></td>
                  <td class="text-end pe-3 font-monospace fw-semibold" style="width: 30%;"><?= number_format((float)$e['balance'], 2) ?></td>
                </tr>
              <?php endforeach; ?>
              <tr class="fw-bold bg-light">
                <td colspan="2" class="ps-3 small text-uppercase">Total Equity</td>
                <td class="text-end pe-3 font-monospace"><?= number_format((float)($report['total_equity'] ?? 0), 2) ?></td>
              </tr>
            </tbody>
            <tfoot class="table-light border-top border-2 border-dark font-monospace fw-bold">
              <tr>
                <td colspan="2" class="ps-3 text-uppercase">Total Liabilities &amp; Equity</td>
                <td class="text-end pe-3 text-success fs-6"><?= number_format((float)($report['total_claims'] ?? 0), 2) ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
