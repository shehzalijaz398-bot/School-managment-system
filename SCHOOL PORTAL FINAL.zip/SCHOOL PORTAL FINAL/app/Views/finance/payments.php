<?php
$totalCount = count($payments);
?>

<div class="cc-payments-wrapper">
    <!-- Breadcrumb & Page Header -->
    <div class="mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Finance</a></li>
                <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Payments</li>
            </ol>
        </nav>
        <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Payments</h2>
        <p class="text-muted small mb-0">Journal ledger records of all manual payments and receipts collected for the current session.</p>
    </div>

    <!-- Filter Bar Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('finance/payments')) ?>" id="paymentsFilterForm" class="row g-2 align-items-end">
                <!-- Search Payments -->
                <div class="col-12 col-md-5">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Search Payments</label>
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" name="q" id="paymentLiveSearch" value="<?= e($search ?? '') ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search receipts, reference numbers, or students..." style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="col-6 col-md-3">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Payment Method</label>
                    <select name="method" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('paymentsFilterForm').submit();">
                        <option value="">All Methods</option>
                        <option value="card" <?= (($method ?? '') === 'card') ? 'selected' : '' ?>>Card</option>
                        <option value="cash" <?= (($method ?? '') === 'cash') ? 'selected' : '' ?>>Cash</option>
                        <option value="bank" <?= (($method ?? '') === 'bank') ? 'selected' : '' ?>>Bank Transfer</option>
                        <option value="online" <?= (($method ?? '') === 'online') ? 'selected' : '' ?>>Online</option>
                        <option value="cheque" <?= (($method ?? '') === 'cheque') ? 'selected' : '' ?>>Cheque</option>
                    </select>
                </div>

                <!-- Status -->
                <div class="col-6 col-md-2">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Status</label>
                    <select name="status" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('paymentsFilterForm').submit();">
                        <option value="">All Statuses</option>
                        <option value="completed" <?= (($status ?? '') === 'completed') ? 'selected' : '' ?>>Completed</option>
                        <option value="pending" <?= (($status ?? '') === 'pending') ? 'selected' : '' ?>>Pending</option>
                        <option value="failed" <?= (($status ?? '') === 'failed') ? 'selected' : '' ?>>Failed</option>
                        <option value="refunded" <?= (($status ?? '') === 'refunded') ? 'selected' : '' ?>>Refunded</option>
                    </select>
                </div>

                <!-- Date Range Button -->
                <div class="col-6 col-md-2 text-md-end">
                    <button type="button" class="btn btn-sm btn-white border border-light-subtle rounded-3 px-3 shadow-none text-secondary fw-medium d-inline-flex align-items-center justify-content-center gap-1 w-100" 
                            style="height: 38px; font-size: 0.86rem; background: #fff;" onclick="alert('Date range filter active');">
                        <i data-lucide="sliders-horizontal" style="width: 15px; height: 15px;"></i> Date Range
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Payments Data Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="paymentsTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 16%;">
                            Receipt #
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 28%;">
                            Student
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 16%;">
                            Invoice #
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 14%;">
                            Payment Date
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 10%;">
                            Method
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 10%;">
                            Amount
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 6%;">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <div class="py-4">
                                    <i data-lucide="receipt" class="mb-2 text-muted" style="width: 40px; height: 40px; opacity: 0.35;"></i>
                                    <p class="mb-0 fw-medium">No payment records found matching criteria.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($payments as $p): 
                            $pId = (int)$p['id'];
                            $receiptNo = $p['receipt_no'];
                            $fName = $p['first_name'] ?? 'Student';
                            $lName = $p['last_name'] ?? '';
                            $fullName = trim($fName . ' ' . $lName);
                            $admNo = $p['admission_no'] ?? ('STU' . str_pad((string)$pId, 6, '0', STR_PAD_LEFT));
                            $invNo = $p['invoice_no'] ?: ('INV' . substr($receiptNo, 3));
                            $payDateRaw = $p['payment_date'] ?? date('Y-m-d');
                            $payDateFmt = date('d/m/Y', strtotime($payDateRaw));
                            $methodRaw = strtolower($p['payment_method'] ?? 'card');
                            $methodLabel = ucwords($methodRaw);
                            $amount = (float)($p['amount'] ?? 0);
                        ?>
                            <tr class="payment-row" data-receipt="<?= e(strtolower($receiptNo)) ?>" data-student="<?= e(strtolower($fullName)) ?>" data-adm="<?= e(strtolower($admNo)) ?>" data-invoice="<?= e(strtolower($invNo)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Receipt # -->
                                <td class="py-3 px-4">
                                    <a href="javascript:void(0)" class="fw-bold text-dark text-decoration-none font-monospace payment-link" 
                                       data-bs-toggle="modal" data-bs-target="#receiptModal<?= $pId ?>" style="font-size: 0.86rem; letter-spacing: 0.02em;">
                                        <?= e($receiptNo) ?>
                                    </a>
                                </td>

                                <!-- Student -->
                                <td class="py-3 px-3">
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size: 0.88rem; letter-spacing: -0.01em;">
                                            <?= e($fullName) ?>
                                        </div>
                                        <div class="text-muted font-monospace" style="font-size: 0.72rem;">
                                            <?= e($admNo) ?>
                                        </div>
                                    </div>
                                </td>

                                <!-- Invoice # -->
                                <td class="py-3 px-3">
                                    <span class="font-monospace text-muted fw-semibold" style="font-size: 0.82rem; letter-spacing: 0.02em;">
                                        <?= e($invNo) ?>
                                    </span>
                                </td>

                                <!-- Payment Date -->
                                <td class="py-3 px-3 text-secondary" style="font-size: 0.84rem;">
                                    <?= e($payDateFmt) ?>
                                </td>

                                <!-- Method -->
                                <td class="py-3 px-3 text-center">
                                    <span class="badge rounded-pill fw-medium border px-2 py-1" style="background: #f8fafc; color: #475569; border-color: #e2e8f0 !important; font-size: 0.74rem;">
                                        <?= e($methodLabel) ?>
                                    </span>
                                </td>

                                <!-- Amount -->
                                <td class="py-3 px-3 text-end fw-bold" style="color: #059669; font-size: 0.90rem;">
                                    ₹<?= number_format($amount, 2) ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <!-- Print Receipt Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#receiptModal<?= $pId ?>" title="Quick Print Receipt">
                                            <i data-lucide="printer" style="width: 14px; height: 14px;"></i>
                                        </button>

                                        <!-- Standalone Fullpage PDF Receipt -->
                                        <a href="<?= e(url('finance/payments/' . $pId . '/pdf')) ?>" target="_blank" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" title="Open Official Printable PDF Receipt">
                                            <i data-lucide="file-text" style="width: 14px; height: 14px;"></i>
                                        </a>

                                        <!-- Refund / Rotate Action -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#refundModal<?= $pId ?>" title="Reverse / Refund Transaction">
                                            <i data-lucide="rotate-ccw" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    </div>

                                    <!-- Print Receipt Modal -->
                                    <div class="modal fade" id="receiptModal<?= $pId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom d-flex justify-content-between align-items-center">
                                                    <h5 class="modal-title fw-bold text-dark mb-0">Official Fee Receipt</h5>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <button type="button" class="btn btn-sm btn-primary d-flex align-items-center gap-1 shadow-sm" onclick="window.print()">
                                                            <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print
                                                        </button>
                                                        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                </div>
                                                <div class="modal-body p-4" id="printableReceipt<?= $pId ?>">
                                                    <div class="text-center mb-3 pb-3 border-bottom">
                                                        <h5 class="fw-bold text-dark mb-1">Guiding Star International</h5>
                                                        <p class="text-muted small mb-0">Cash &amp; Electronic Collection Voucher</p>
                                                    </div>

                                                    <div class="d-flex justify-content-between small text-muted mb-3">
                                                        <span>Receipt #: <strong class="font-monospace text-dark"><?= e($receiptNo) ?></strong></span>
                                                        <span>Date: <strong class="text-dark"><?= e($payDateFmt) ?></strong></span>
                                                    </div>

                                                    <div class="bg-light rounded-3 p-3 mb-3 small">
                                                        <div class="d-flex justify-content-between mb-1">
                                                            <span class="text-muted">Student:</span>
                                                            <strong class="text-dark"><?= e($fullName) ?></strong>
                                                        </div>
                                                        <div class="d-flex justify-content-between mb-1">
                                                            <span class="text-muted">Admission No:</span>
                                                            <strong class="font-monospace text-dark"><?= e($admNo) ?></strong>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <span class="text-muted">Invoice Ref:</span>
                                                            <span class="font-monospace text-dark"><?= e($invNo) ?></span>
                                                        </div>
                                                    </div>

                                                    <div class="p-3 rounded-3 mb-3 text-center" style="background: #ecfdf5; border: 1px solid #a7f3d0;">
                                                        <div class="text-muted small mb-1">AMOUNT PAID</div>
                                                        <div class="h3 fw-bold mb-0" style="color: #059669;">₹<?= number_format($amount, 2) ?></div>
                                                        <div class="text-muted small mt-1">Payment Method: <strong><?= e($methodLabel) ?></strong></div>
                                                    </div>

                                                    <div class="text-center text-muted small">
                                                        <span>Status: <strong class="text-success">COMPLETED / VERIFIED</strong></span>
                                                    </div>
                                                </div>
                                                <div class="modal-footer py-2 px-4 border-top">
                                                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Refund / Reversal Modal -->
                                    <div class="modal fade" id="refundModal<?= $pId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-sm">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h6 class="modal-title fw-bold text-dark">Reverse Receipt</h6>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body p-4 text-center">
                                                    <i data-lucide="rotate-ccw" class="text-warning mb-2" style="width: 36px; height: 36px;"></i>
                                                    <p class="mb-0 small text-muted">Receipt <strong><?= e($receiptNo) ?></strong> is recorded as verified. Reverse this entry?</p>
                                                </div>
                                                <div class="modal-footer py-2 px-4 border-top d-flex justify-content-between">
                                                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="button" class="btn btn-sm btn-warning px-3 fw-medium" data-bs-dismiss="modal" onclick="alert('Transaction reversal request submitted.');">Reverse</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Table Footer / Pagination -->
        <div class="p-3 bg-white border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
            <span class="text-muted small" style="font-size: 0.8rem;">
                Showing 1 to <?= min(25, $totalCount) ?> of <?= $totalCount ?> records
            </span>

            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small" style="font-size: 0.8rem;">Rows:</span>
                <select class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" style="width: 70px; height: 32px; font-size: 0.8rem;">
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
        </div>
    </div>
</div>

<style>
.action-icon-btn {
    opacity: 0.65;
    transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
}
.action-icon-btn:hover {
    opacity: 1;
    transform: scale(1.15);
}
.payment-link:hover {
    color: #4f46e5 !important;
    text-decoration: underline !important;
}
@media print {
    body * {
        visibility: hidden;
    }
    .modal.show .modal-body, .modal.show .modal-body * {
        visibility: visible;
    }
    .modal.show .modal-body {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        margin: 0;
        padding: 20px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Client-side real-time live search
    const searchInput = document.getElementById('paymentLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.payment-row');

            rows.forEach(row => {
                const receipt = row.getAttribute('data-receipt') || '';
                const student = row.getAttribute('data-student') || '';
                const adm = row.getAttribute('data-adm') || '';
                const inv = row.getAttribute('data-invoice') || '';
                if (!query || receipt.includes(query) || student.includes(query) || adm.includes(query) || inv.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>
