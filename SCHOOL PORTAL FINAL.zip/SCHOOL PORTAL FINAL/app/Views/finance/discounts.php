<?php
$title = 'Fee Discounts & Student Scholarships';
$discounts = $discounts ?? [];
$scholarships = $scholarships ?? [];
$students = $students ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="tag" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Fee Concessions
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Manage institutional scholarship policies, sibling discounts, merit fee waivers, and student allocations.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newDiscountModal">
      <i data-lucide="plus" style="width: 14px; height: 14px;"></i> New Discount Policy
    </button>
    <button type="button" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#awardScholarshipModal">
      <i data-lucide="award" style="width: 14px; height: 14px;"></i> Award Scholarship
    </button>
    <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Invoices
    </a>
  </div>
</div>

<div class="row g-4">
  <!-- Active Discount Policies -->
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
      <div class="card-header bg-white border-bottom py-3">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="percent" class="text-primary" style="width: 18px; height: 18px;"></i>
          Discount &amp; Waiver Policies
        </h5>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Policy &amp; Code</th>
                <th>Type</th>
                <th class="text-end pe-3">Value</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($discounts)): ?>
                <tr><td colspan="3" class="text-center py-4 text-muted small">No discount policies configured yet.</td></tr>
              <?php else: ?>
                <?php foreach ($discounts as $d): ?>
                  <tr>
                    <td class="ps-3 py-3">
                      <div class="fw-bold text-dark small"><?= e($d['name']) ?></div>
                      <code class="small text-muted"><?= e($d['code']) ?></code>
                    </td>
                    <td>
                      <span class="badge <?= $d['type'] === 'percentage' ? 'bg-info-subtle text-info' : 'bg-primary-subtle text-primary' ?> px-2 py-1 rounded-pill small">
                        <?= ucfirst(e($d['type'])) ?>
                      </span>
                    </td>
                    <td class="text-end pe-3 font-monospace fw-bold text-success">
                      <?= $d['type'] === 'percentage' ? ((float)$d['amount'] . '%') : formatMoney((float)$d['amount']) ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Awarded Student Scholarships -->
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
      <div class="card-header bg-white border-bottom py-3">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="award" class="text-success" style="width: 18px; height: 18px;"></i>
          Awarded Student Concessions &amp; Scholarships
        </h5>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Student</th>
                <th>Policy Applied</th>
                <th>Value</th>
                <th>Remarks</th>
                <th class="text-end pe-3">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($scholarships)): ?>
                <tr><td colspan="5" class="text-center py-5 text-muted small">No scholarships awarded to students yet.</td></tr>
              <?php else: ?>
                <?php foreach ($scholarships as $s): ?>
                  <tr>
                    <td class="ps-3 py-3">
                      <div class="fw-bold text-dark small"><?= e($s['first_name'] . ' ' . $s['last_name']) ?></div>
                      <div class="text-muted" style="font-size: 11px;"><?= e($s['class_name'] ?? 'Unassigned') ?> &middot; <?= e($s['admission_no']) ?></div>
                    </td>
                    <td>
                      <div class="small fw-semibold text-dark"><?= e($s['discount_name']) ?></div>
                      <code class="small text-muted"><?= e($s['discount_code']) ?></code>
                    </td>
                    <td class="font-monospace fw-semibold text-success small">
                      <?= $s['discount_type'] === 'percentage' ? ((float)$s['discount_amount'] . '%') : formatMoney((float)$s['discount_amount']) ?>
                    </td>
                    <td class="small text-secondary" style="max-width: 140px;">
                      <?= e($s['remarks'] ?: 'Merit / Policy Concession') ?>
                    </td>
                    <td class="text-end pe-3">
                      <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill small">
                        Active
                      </span>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal: New Discount Policy -->
<div class="modal fade" id="newDiscountModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-4 border-0 shadow">
      <div class="modal-header border-bottom">
        <h5 class="modal-title fw-bold text-dark d-flex align-items-center gap-2">
          <i data-lucide="tag" class="text-primary" style="width: 18px; height: 18px;"></i>
          New Discount / Scholarship Policy
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="<?= e(url('finance/discounts')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Policy Name *</label>
            <input type="text" name="name" class="form-control" required placeholder="e.g. Sibling Discount (20%)">
          </div>
          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Policy Code *</label>
              <input type="text" name="code" class="form-control text-uppercase" required placeholder="e.g. SIB20">
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Type *</label>
              <select name="type" class="form-select">
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed Amount ($)</option>
              </select>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Value / Amount *</label>
            <input type="number" step="0.01" min="0" name="amount" class="form-control font-monospace" required placeholder="e.g. 20.00">
          </div>
          <div class="mb-0">
            <label class="form-label small fw-semibold text-dark">Description</label>
            <textarea name="description" rows="2" class="form-control" placeholder="Eligibility criteria or policy remarks..."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
            <i data-lucide="check" style="width: 14px; height: 14px;"></i> Save Policy
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: Award Scholarship -->
<div class="modal fade" id="awardScholarshipModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-4 border-0 shadow">
      <div class="modal-header border-bottom">
        <h5 class="modal-title fw-bold text-dark d-flex align-items-center gap-2">
          <i data-lucide="award" class="text-success" style="width: 18px; height: 18px;"></i>
          Award Scholarship / Concession to Student
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="<?= e(url('finance/scholarships')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Select Student *</label>
            <select name="student_id" class="form-select" required>
              <option value="">-- Choose Student --</option>
              <?php foreach ($students as $st): ?>
                <option value="<?= (int) $st['id'] ?>">
                  <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?> &middot; <?= e($st['class_name'] ?? 'No class') ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Select Policy / Concession *</label>
            <select name="discount_id" class="form-select" required>
              <option value="">-- Choose Policy --</option>
              <?php foreach ($discounts as $d): ?>
                <option value="<?= (int) $d['id'] ?>">
                  <?= e($d['name']) ?> (<?= $d['type'] === 'percentage' ? ((float)$d['amount'] . '%') : formatMoney((float)$d['amount']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-0">
            <label class="form-label small fw-semibold text-dark">Remarks / Award Basis</label>
            <textarea name="remarks" rows="2" class="form-control" placeholder="e.g. Merit-based academic concession awarded by Principal..."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success btn-sm d-flex align-items-center gap-1">
            <i data-lucide="check" style="width: 14px; height: 14px;"></i> Award Concession
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
