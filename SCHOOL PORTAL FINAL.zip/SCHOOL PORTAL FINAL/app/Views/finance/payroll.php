<?php
/**
 * CodeClove School Management Pro — Payroll Management View
 * Pixel-perfect match to official CodeClove Finance / Payroll workflow
 */

$selectedMonth = $month ?? date('Y-m');
$monthTimestamp = strtotime($selectedMonth . '-01');
$monthDisplayName = date('F Y', $monthTimestamp);
$prevMonth = date('Y-m', strtotime('-1 month', $monthTimestamp));
$nextMonth = date('Y-m', strtotime('+1 month', $monthTimestamp));

// Avatar color helper
if (!function_exists('ccPayrollInitials')) {
    function ccPayrollInitials(string $firstName, string $lastName): string {
        $first = strtoupper(substr(trim($firstName), 0, 1));
        $parts = preg_split('/\s+/', trim($lastName));
        $lastWord = end($parts);
        $last = strtoupper(substr((string)$lastWord, 0, 1));
        return ($first ?: 'S') . ($last ?: 'T');
    }
}
?>

<style>
.cc-payroll-container {
  max-width: 1400px;
  margin: 0 auto;
}
.cc-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
}
.cc-kpi-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.25rem 1.4rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
  transition: transform 0.15s ease, border-color 0.15s ease;
}
.cc-kpi-card:hover {
  border-color: #cbd5e1;
}
.cc-btn-indigo {
  background: #4f46e5;
  border: 1px solid #4f46e5;
  color: #ffffff;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.5rem 1.25rem;
  border-radius: 8px;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(79, 70, 229, 0.2);
}
.cc-btn-indigo:hover {
  background: #4338ca;
  border-color: #4338ca;
  color: #ffffff;
}
.cc-btn-white {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  color: #334155;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.cc-btn-white:hover {
  background: #f8fafc;
  color: #0f172a;
  border-color: #cbd5e1;
}
.cc-table-header {
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
}
.cc-table-header th {
  font-size: 0.72rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 0.85rem 1rem;
  border-bottom: none;
}
.cc-table td {
  padding: 0.95rem 1rem;
  vertical-align: middle;
  border-bottom: 1px solid #f1f5f9;
  font-size: 0.86rem;
}
.cc-status-pill {
  font-size: 0.75rem;
  font-weight: 600;
  padding: 0.25rem 0.65rem;
  border-radius: 9999px;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
}
.cc-status-paid {
  background: rgba(16, 185, 129, 0.1);
  color: #059669;
  border: 1px solid rgba(16, 185, 129, 0.25);
}
.cc-status-approved {
  background: rgba(14, 165, 233, 0.1);
  color: #0284c7;
  border: 1px solid rgba(14, 165, 233, 0.25);
}
.cc-status-pending, .cc-status-draft {
  background: rgba(245, 158, 11, 0.1);
  color: #d97706;
  border: 1px solid rgba(245, 158, 11, 0.25);
}
.cc-avatar-circle {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.82rem;
  color: #4f46e5;
  background: #eef2ff;
  border: 1px solid rgba(79, 70, 229, 0.2);
  flex-shrink: 0;
}
.cc-avatar-circle img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
}
</style>

<div class="cc-payroll-container mb-5">

  <!-- 1. Breadcrumbs -->
  <nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-muted text-decoration-none">Finance</a></li>
      <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Payroll</li>
    </ol>
  </nav>

  <!-- 2. Page Header & Actions -->
  <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Payroll Management</h1>
      <p class="text-muted small mb-0">Manage employee salaries, generate monthly payroll drafts, and disburse compensation.</p>
    </div>

    <div class="d-flex align-items-center flex-wrap gap-2">
      <!-- Month Navigation Controls -->
      <div class="d-flex align-items-center bg-white border rounded-3 p-1 shadow-2xs" style="border-color: #e2e8f0;">
        <a href="<?= e(url('finance/payroll?month=' . $prevMonth)) ?>" class="btn btn-sm btn-link text-muted p-1" title="Previous Month">
          <i data-lucide="chevron-left" style="width: 16px; height: 16px;"></i>
        </a>
        <form method="get" action="<?= e(url('finance/payroll')) ?>" class="m-0 d-flex align-items-center">
          <input type="month" name="month" value="<?= e($selectedMonth) ?>" onchange="this.form.submit()" class="form-control form-control-sm border-0 fw-semibold text-dark p-1 text-center" style="width: 130px; font-size: 0.84rem; cursor: pointer;">
        </form>
        <a href="<?= e(url('finance/payroll?month=' . $nextMonth)) ?>" class="btn btn-sm btn-link text-muted p-1" title="Next Month">
          <i data-lucide="chevron-right" style="width: 16px; height: 16px;"></i>
        </a>
      </div>

      <!-- Auto-Generate Payroll Button -->
      <?php if (hasPermission('payroll.manage')): ?>
        <form method="post" action="<?= e(url('finance/payroll/generate')) ?>" class="m-0">
          <?= csrf_field() ?>
          <input type="hidden" name="month" value="<?= e($selectedMonth) ?>">
          <button type="submit" class="btn cc-btn-indigo d-inline-flex align-items-center gap-2">
            <i data-lucide="sparkles" style="width: 15px; height: 15px;"></i>
            <span>Generate Payroll</span>
          </button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <!-- 3. Top 4 KPI Summary Cards -->
  <div class="row g-3 mb-4">
    <!-- Card 1: Total Payroll Cost -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="cc-kpi-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-semibold">Total Payroll Cost</span>
          <div class="rounded-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; background: #eef2ff; color: #4f46e5;">
            <i data-lucide="receipt" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h4 fw-bold text-dark mb-1">
          ₹<?= number_format($kpiTotal ?? 0, 2) ?>
        </div>
        <div class="text-muted" style="font-size: 11px;">
          For <?= e($monthDisplayName) ?>
        </div>
      </div>
    </div>

    <!-- Card 2: Disbursed / Paid -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="cc-kpi-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-semibold">Disbursed (Paid)</span>
          <div class="rounded-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; background: #ecfdf5; color: #10b981;">
            <i data-lucide="check-circle-2" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h4 fw-bold text-success mb-1">
          ₹<?= number_format($kpiPaid ?? 0, 2) ?>
        </div>
        <div class="text-muted" style="font-size: 11px;">
          Completed transfers
        </div>
      </div>
    </div>

    <!-- Card 3: Pending Approval -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="cc-kpi-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-semibold">Pending Approval</span>
          <div class="rounded-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; background: #fffbeb; color: #f59e0b;">
            <i data-lucide="clock" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h4 fw-bold text-warning mb-1">
          ₹<?= number_format($kpiPending ?? 0, 2) ?>
        </div>
        <div class="text-muted" style="font-size: 11px;">
          Draft or pending slips
        </div>
      </div>
    </div>

    <!-- Card 4: Staff on Payroll -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="cc-kpi-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-semibold">Staff on Payroll</span>
          <div class="rounded-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; background: #f0f9ff; color: #0284c7;">
            <i data-lucide="users" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h4 fw-bold text-dark mb-1">
          <?= (int)($kpiStaffCount ?? 0) ?> Staff
        </div>
        <div class="text-muted" style="font-size: 11px;">
          Active employee records
        </div>
      </div>
    </div>
  </div>

  <!-- 4. Filter Control Bar Card -->
  <div class="cc-card p-3 mb-4">
    <form method="get" action="<?= e(url('finance/payroll')) ?>" class="row g-2 align-items-center m-0">
      <input type="hidden" name="month" value="<?= e($selectedMonth) ?>">

      <!-- Search Input -->
      <div class="col-12 col-md-5">
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
          <input type="text" name="q" value="<?= e($search ?? '') ?>" class="form-control form-control-sm ps-5 border-light-subtle rounded-3" placeholder="Search staff name, employee code, designation..." style="height: 38px; font-size: 0.85rem;">
        </div>
      </div>

      <!-- Department Filter -->
      <div class="col-12 col-sm-6 col-md-3">
        <select name="department_id" class="form-select form-select-sm border-light-subtle rounded-3" style="height: 38px; font-size: 0.85rem;" onchange="this.form.submit()">
          <option value="">All Departments</option>
          <?php foreach (($departments ?? []) as $d): ?>
            <option value="<?= (int)$d['id'] ?>" <?= (($departmentId ?? '') == $d['id']) ? 'selected' : '' ?>>
              <?= e($d['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Status Filter -->
      <div class="col-12 col-sm-6 col-md-3">
        <select name="status" class="form-select form-select-sm border-light-subtle rounded-3" style="height: 38px; font-size: 0.85rem;" onchange="this.form.submit()">
          <option value="">All Statuses</option>
          <option value="draft" <?= (($status ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option>
          <option value="pending" <?= (($status ?? '') === 'pending') ? 'selected' : '' ?>>Pending Approval</option>
          <option value="approved" <?= (($status ?? '') === 'approved') ? 'selected' : '' ?>>Approved</option>
          <option value="paid" <?= (($status ?? '') === 'paid') ? 'selected' : '' ?>>Paid / Disbursed</option>
        </select>
      </div>

      <div class="col-12 col-md-1 d-flex justify-content-end">
        <button type="submit" class="btn btn-sm btn-outline-secondary w-100" style="height: 38px;">
          Filter
        </button>
      </div>
    </form>
  </div>

  <!-- 5. Staff Payroll Records Table Card -->
  <div class="cc-card overflow-hidden">
    <div class="table-responsive">
      <table class="table cc-table table-hover align-middle mb-0">
        <thead class="cc-table-header">
          <tr>
            <th>STAFF MEMBER</th>
            <th>DEPARTMENT</th>
            <th class="text-end">BASIC SALARY</th>
            <th class="text-end">ALLOWANCES</th>
            <th class="text-end">DEDUCTIONS</th>
            <th class="text-end">NET SALARY</th>
            <th class="text-center">STATUS</th>
            <th class="text-end px-3">ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($rows)): ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <!-- Staff Member -->
                <td>
                  <div class="d-flex align-items-center gap-3">
                    <div class="cc-avatar-circle">
                      <?php if (!empty($r['profile_image'])): ?>
                        <img src="<?= e(asset($r['profile_image'])) ?>" alt="<?= e($r['first_name']) ?>">
                      <?php else: ?>
                        <span><?= e(ccPayrollInitials($r['first_name'] ?? 'Staff', $r['last_name'] ?? '')) ?></span>
                      <?php endif; ?>
                    </div>
                    <div>
                      <div class="fw-bold text-dark" style="font-size: 0.88rem;">
                        <?= e(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')) ?>
                      </div>
                      <div class="d-flex align-items-center gap-1.5 text-muted" style="font-size: 11px;">
                        <span class="badge bg-light text-secondary border px-1 py-0.5" style="font-size: 10px;"><?= e($r['employee_code'] ?? 'STAFF') ?></span>
                        <span>&bull;</span>
                        <span><?= e($r['designation_name'] ?? 'Faculty') ?></span>
                      </div>
                    </div>
                  </div>
                </td>

                <!-- Department -->
                <td>
                  <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px; font-weight: 500;">
                    <?= e($r['department_name'] ?? 'Academics') ?>
                  </span>
                </td>

                <!-- Basic Salary -->
                <td class="text-end fw-medium text-secondary">
                  ₹<?= number_format((float)$r['basic_salary'], 2) ?>
                </td>

                <!-- Allowances -->
                <td class="text-end text-success fw-medium">
                  +₹<?= number_format((float)$r['allowances'], 2) ?>
                </td>

                <!-- Deductions -->
                <td class="text-end text-danger fw-medium">
                  -₹<?= number_format((float)($r['deductions'] + $r['leave_deduction'] + $r['attendance_deduction']), 2) ?>
                </td>

                <!-- Net Salary -->
                <td class="text-end fw-bold text-dark" style="font-size: 0.94rem;">
                  ₹<?= number_format((float)$r['net_salary'], 2) ?>
                </td>

                <!-- Status Pill -->
                <td class="text-center">
                  <?php if ($r['status'] === 'paid'): ?>
                    <span class="cc-status-pill cc-status-paid">
                      <i data-lucide="check" style="width: 12px; height: 12px;"></i> Paid
                    </span>
                  <?php elseif ($r['status'] === 'approved'): ?>
                    <span class="cc-status-pill cc-status-approved">
                      <i data-lucide="shield-check" style="width: 12px; height: 12px;"></i> Approved
                    </span>
                  <?php else: ?>
                    <span class="cc-status-pill cc-status-pending">
                      <i data-lucide="clock" style="width: 12px; height: 12px;"></i> Draft
                    </span>
                  <?php endif; ?>
                </td>

                <!-- Actions -->
                <td class="text-end px-3">
                  <div class="d-flex align-items-center justify-content-end gap-1.5">
                    <!-- Approve Button -->
                    <?php if (in_array($r['status'], ['draft', 'pending'], true) && hasPermission('payroll.approve')): ?>
                      <form method="post" action="<?= e(url('finance/payroll/' . $r['id'] . '/approve')) ?>" class="m-0">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-success fw-semibold" style="height: 30px; font-size: 11px; border-radius: 6px;" title="Approve this payroll">
                          Approve
                        </button>
                      </form>
                    <?php endif; ?>

                    <!-- Mark Paid Button -->
                    <?php if ($r['status'] === 'approved' && hasPermission('payroll.manage')): ?>
                      <form method="post" action="<?= e(url('finance/payroll/' . $r['id'] . '/pay')) ?>" class="m-0">
                        <?= csrf_field() ?>
                        <input type="hidden" name="payment_date" value="<?= date('Y-m-d') ?>">
                        <input type="hidden" name="payment_method" value="bank_transfer">
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold" style="height: 30px; font-size: 11px; border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;" title="Disburse Salary">
                          Pay
                        </button>
                      </form>
                    <?php endif; ?>

                    <!-- View / Download Payslip -->
                    <a href="<?= e(url('hr/payroll/payslip/' . $r['id'])) ?>" target="_blank" class="btn btn-sm btn-light border text-muted d-inline-flex align-items-center justify-content-center p-0" style="width: 30px; height: 30px; border-radius: 6px;" title="View / Print Official Payslip PDF">
                      <i data-lucide="file-text" style="width: 14px; height: 14px;"></i>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="8" class="text-center py-5">
                <div class="py-4">
                  <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 56px; height: 56px; background: #f8fafc; border: 1px dashed #cbd5e1; color: #94a3b8;">
                    <i data-lucide="wallet" style="width: 26px; height: 26px;"></i>
                  </div>
                  <h5 class="fw-bold text-dark mb-1">No Payroll Records For <?= e($monthDisplayName) ?></h5>
                  <p class="text-muted small mb-3" style="max-width: 440px; margin: 0 auto;">
                    Click "Generate Payroll" above to automatically calculate monthly basic salaries, allowances, and statutory deductions for all active staff members.
                  </p>
                  <?php if (hasPermission('payroll.manage')): ?>
                    <form method="post" action="<?= e(url('finance/payroll/generate')) ?>" class="m-0 d-inline-block">
                      <?= csrf_field() ?>
                      <input type="hidden" name="month" value="<?= e($selectedMonth) ?>">
                      <button type="submit" class="btn cc-btn-indigo d-inline-flex align-items-center gap-2">
                        <i data-lucide="sparkles" style="width: 15px; height: 15px;"></i>
                        <span>Generate Payroll for <?= e($monthDisplayName) ?></span>
                      </button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
</script>
