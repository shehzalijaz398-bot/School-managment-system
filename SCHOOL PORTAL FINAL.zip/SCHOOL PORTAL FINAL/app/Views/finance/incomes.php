<?php
$layout = 'layouts/app';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-coins text-success me-2"></i> Incomes & Miscellaneous Revenue</h2>
        <p class="text-muted mb-0">Record and track institutional grants, donations, canteen revenue, and auxiliary income.</p>
    </div>
    <?php if (hasPermission('finance.manage')): ?>
    <button class="btn btn-success d-flex align-items-center gap-2 shadow-sm action-hover" data-bs-toggle="modal" data-bs-target="#addIncomeModal">
        <i class="fas fa-plus-circle"></i> Record Income
    </button>
    <?php endif; ?>
</div>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-xs text-uppercase fw-bold text-muted">Total Auxiliary Income</span>
                    <h3 class="h4 fw-bold text-success mb-0 mt-1"><?= e(formatMoney($totalIncome ?? 0)) ?></h3>
                </div>
                <div class="p-3 bg-success-subtle rounded-3 text-success">
                    <i class="fas fa-hand-holding-usd fa-lg"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-xs text-uppercase fw-bold text-muted">This Month (<?= date('M Y') ?>)</span>
                    <h3 class="h4 fw-bold text-primary mb-0 mt-1"><?= e(formatMoney($monthIncome ?? 0)) ?></h3>
                </div>
                <div class="p-3 bg-primary-subtle rounded-3 text-primary">
                    <i class="fas fa-calendar-check fa-lg"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-xs text-uppercase fw-bold text-muted">Records Logged</span>
                    <h3 class="h4 fw-bold text-dark mb-0 mt-1"><?= count($incomes ?? []) ?></h3>
                </div>
                <div class="p-3 bg-light rounded-3 text-secondary">
                    <i class="fas fa-file-invoice fa-lg"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Incomes Ledger Table -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="card-header bg-white border-bottom py-3 px-4">
        <form method="GET" action="<?= url('finance/incomes') ?>" class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-search text-muted"></i></span>
                    <input type="text" name="q" value="<?= e($search ?? '') ?>" class="form-control bg-light border-start-0" placeholder="Search title or notes...">
                </div>
            </div>
            <div class="col-md-4">
                <select name="category" class="form-select form-select-sm bg-light">
                    <option value="">All Categories</option>
                    <option value="Donation" <?= ($selectedCategory ?? '') === 'Donation' ? 'selected' : '' ?>>Donation</option>
                    <option value="Grant" <?= ($selectedCategory ?? '') === 'Grant' ? 'selected' : '' ?>>Government / Private Grant</option>
                    <option value="Canteen" <?= ($selectedCategory ?? '') === 'Canteen' ? 'selected' : '' ?>>Canteen & Cafeteria</option>
                    <option value="Books & Uniforms" <?= ($selectedCategory ?? '') === 'Books & Uniforms' ? 'selected' : '' ?>>Books & Uniform Sales</option>
                    <option value="Events" <?= ($selectedCategory ?? '') === 'Events' ? 'selected' : '' ?>>Events & Sponsorships</option>
                    <option value="Miscellaneous" <?= ($selectedCategory ?? '') === 'Miscellaneous' ? 'selected' : '' ?>>Miscellaneous</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary w-100"><i class="fas fa-filter me-1"></i> Filter</button>
                <?php if (!empty($search) || !empty($selectedCategory)): ?>
                <a href="<?= url('finance/incomes') ?>" class="btn btn-sm btn-light border"><i class="fas fa-times"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3" style="width: 15%;">Date</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3" style="width: 40%;">Income Title</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3" style="width: 20%;">Category</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end" style="width: 15%;">Amount</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-center px-4" style="width: 10%;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (($incomes ?? []) as $inc): ?>
                <tr>
                    <td class="px-4 py-3 text-sm">
                        <div class="d-flex align-items-center gap-2 text-secondary fw-semibold">
                            <i class="far fa-calendar-alt text-muted"></i> 
                            <?= e(formatDate($inc['income_date'])) ?>
                        </div>
                    </td>
                    <td class="py-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm bg-success-subtle text-success rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 38px; height: 38px;">
                                <i class="fas fa-arrow-down"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($inc['title']) ?></h6>
                                <?php if (!empty($inc['notes'])): ?>
                                <span class="text-xs text-muted"><?= e($inc['notes']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td class="py-3 text-sm fw-medium">
                        <span class="badge bg-light text-dark border px-2 py-1">
                            <i class="fas fa-tag text-success me-1"></i> <?= e($inc['category'] ?: 'Miscellaneous') ?>
                        </span>
                    </td>
                    <td class="py-3 text-sm fw-bold text-success text-end">
                        +<?= e(formatMoney($inc['amount'])) ?>
                    </td>
                    <td class="py-3 text-center px-4">
                        <?php if (hasPermission('finance.manage')): ?>
                        <div class="d-flex justify-content-center gap-1">
                            <button class="btn btn-sm btn-outline-secondary border-0 p-1 edit-income-btn" 
                                    data-id="<?= e($inc['id']) ?>"
                                    data-title="<?= e($inc['title']) ?>"
                                    data-amount="<?= e($inc['amount']) ?>"
                                    data-category="<?= e($inc['category']) ?>"
                                    data-date="<?= e($inc['income_date']) ?>"
                                    data-notes="<?= e($inc['notes']) ?>"
                                    title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= url('finance/incomes/' . $inc['id'] . '/delete') ?>" onsubmit="return confirm('Delete this income record?');" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger border-0 p-1" title="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                        <?php else: ?>
                        <span class="text-muted text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($incomes)): ?>
                <tr>
                    <td colspan="5" class="text-center py-5 text-muted">
                        <i class="fas fa-coins fa-3x mb-3 text-light"></i>
                        <p class="mb-0">No income records found.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Record Income -->
<div class="modal fade" id="addIncomeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header border-bottom py-3 px-4 bg-light">
                <h5 class="modal-title fw-bold text-gray-800"><i class="fas fa-plus-circle text-success me-2"></i> Record Income</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= url('finance/incomes') ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Income Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Annual Alumni Donation" required>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-dollar-sign"></i></span>
                                <input type="number" step="0.01" min="0.01" name="amount" class="form-control" placeholder="0.00" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Date <span class="text-danger">*</span></label>
                            <input type="date" name="income_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Category</label>
                        <select name="category" class="form-select">
                            <option value="Miscellaneous">Miscellaneous</option>
                            <option value="Donation">Donation</option>
                            <option value="Grant">Government / Private Grant</option>
                            <option value="Canteen">Canteen & Cafeteria</option>
                            <option value="Books & Uniforms">Books & Uniform Sales</option>
                            <option value="Events">Events & Sponsorships</option>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Notes / Memo</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Cheque number, donor details, or description..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4 bg-light">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success px-4"><i class="fas fa-check me-1"></i> Save Income</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Edit Income -->
<div class="modal fade" id="editIncomeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header border-bottom py-3 px-4 bg-light">
                <h5 class="modal-title fw-bold text-gray-800"><i class="fas fa-edit text-primary me-2"></i> Edit Income</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editIncomeForm" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Income Title <span class="text-danger">*</span></label>
                        <input type="text" id="edit_title" name="title" class="form-control" required>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Amount <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.01" id="edit_amount" name="amount" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Date <span class="text-danger">*</span></label>
                            <input type="date" id="edit_date" name="income_date" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Category</label>
                        <select id="edit_category" name="category" class="form-select">
                            <option value="Miscellaneous">Miscellaneous</option>
                            <option value="Donation">Donation</option>
                            <option value="Grant">Government / Private Grant</option>
                            <option value="Canteen">Canteen & Cafeteria</option>
                            <option value="Books & Uniforms">Books & Uniform Sales</option>
                            <option value="Events">Events & Sponsorships</option>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Notes / Memo</label>
                        <textarea id="edit_notes" name="notes" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4 bg-light">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4"><i class="fas fa-save me-1"></i> Update Income</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const editModal = new bootstrap.Modal(document.getElementById('editIncomeModal'));
    const editForm = document.getElementById('editIncomeForm');
    
    document.querySelectorAll('.edit-income-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            editForm.action = '<?= url("finance/incomes/") ?>' + id;
            document.getElementById('edit_title').value = this.getAttribute('data-title');
            document.getElementById('edit_amount').value = this.getAttribute('data-amount');
            document.getElementById('edit_date').value = this.getAttribute('data-date');
            document.getElementById('edit_category').value = this.getAttribute('data-category');
            document.getElementById('edit_notes').value = this.getAttribute('data-notes');
            editModal.show();
        });
    });
});
</script>
