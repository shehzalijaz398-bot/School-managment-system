<?php
$title = 'Automated Fee Reminders & Delivery History';
$logs = $logs ?? [];
$settings = $settings ?? [];
$overdueCount = $overdueCount ?? 0;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="bell" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-2 py-1 rounded-pill small">
        <?= $overdueCount ?> Overdue Invoice(s)
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Automated fee payment reminder dispatches, anti-duplicate rate-limiting, and immutable delivery audit history.
    </p>
  </div>
  <div class="d-flex gap-2">
    <form method="POST" action="<?= e(url('finance/reminders/dispatch')) ?>" class="d-inline">
      <?= csrf_field() ?>
      <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm">
        <i data-lucide="send" style="width: 14px; height: 14px;"></i> Dispatch Reminders Now
      </button>
    </form>
    <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Invoices
    </a>
  </div>
</div>

<!-- Notice Callout -->
<div class="alert alert-info border-0 shadow-sm rounded-3 d-flex align-items-center gap-3 mb-4">
  <i data-lucide="shield-check" class="text-primary" style="width: 24px; height: 24px; flex-shrink: 0;"></i>
  <div class="small">
    <strong>Duplicate Spam Prevention Active:</strong> Fee reminders enforce a mandatory 5-day suppression window per invoice. Parents will not be spammed with multiple alerts within the cooldown period unless manually overridden.
  </div>
</div>

<!-- Reminder Delivery Log Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
    <h6 class="mb-0 fw-bold text-dark">Recent Reminder Dispatches (<?= count($logs) ?>)</h6>
    <span class="badge bg-light text-muted border small">Last 100 Logs</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3">Sent Timestamp</th>
            <th>Invoice #</th>
            <th>Student</th>
            <th>Admission #</th>
            <th>Contact / Target</th>
            <th>Channel</th>
            <th class="text-end">Due Amount ($)</th>
            <th>Due Date</th>
            <th class="pe-3">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($logs)): ?>
            <tr>
              <td colspan="9" class="text-center py-4 text-muted">No fee reminders dispatched yet. Click "Dispatch Reminders Now" to trigger notifications.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($logs as $l): ?>
              <tr>
                <td class="ps-3 small text-muted"><?= e($l['sent_at']) ?></td>
                <td class="font-monospace fw-bold text-primary">
                  <a href="<?= e(url('finance/invoices/' . $l['invoice_id'])) ?>" class="text-decoration-none">
                    <?= e($l['invoice_no']) ?>
                  </a>
                </td>
                <td class="fw-semibold text-dark"><?= e($l['first_name'] . ' ' . $l['last_name']) ?></td>
                <td class="small text-muted font-monospace"><?= e($l['admission_no']) ?></td>
                <td class="small"><?= e($l['recipient_contact'] ?? 'In-App Portal') ?></td>
                <td>
                  <span class="badge bg-light text-dark border text-uppercase small">
                    <?= e($l['channel']) ?>
                  </span>
                </td>
                <td class="text-end font-monospace fw-bold text-danger"><?= number_format((float)$l['amount_due'], 2) ?></td>
                <td class="small text-muted"><?= e($l['due_date']) ?></td>
                <td class="pe-3">
                  <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0 small">
                    <?= ucfirst(e($l['status'])) ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
