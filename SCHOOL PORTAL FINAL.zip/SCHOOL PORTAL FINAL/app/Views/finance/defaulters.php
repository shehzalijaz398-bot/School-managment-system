<?php
$totalCount = count($defaulters);
?>

<div class="cc-defaulters-wrapper">
    <!-- Breadcrumb & Page Header -->
    <div class="mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Finance</a></li>
                <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-decoration-none text-muted">Dashboard</a></li>
                <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Defaulters Report</li>
            </ol>
        </nav>
        <div class="d-flex align-items-center gap-2 mb-1">
            <a href="<?= e(url('finance')) ?>" class="text-decoration-none text-dark fw-bold fs-5 me-1" title="Back to Finance">
                <i data-lucide="arrow-left" style="width: 20px; height: 20px;"></i>
            </a>
            <h2 class="h4 fw-bold text-dark mb-0" style="letter-spacing: -0.02em;">Invoice Defaulters Report</h2>
        </div>
        <p class="text-muted small mb-0" style="margin-left: 28px;">List of students with outstanding unpaid or partially paid overdue invoices.</p>
    </div>

    <!-- Filter Bar Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('finance/reports/defaulters')) ?>" id="defaultersFilterForm" class="row g-2 align-items-end">
                <!-- Search Students -->
                <div class="col-12 col-md-5">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Search Students</label>
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" name="q" id="defaulterLiveSearch" value="<?= e($search ?? '') ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search by student name, number, or invoice #..." style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>

                <!-- Class -->
                <div class="col-6 col-md-3">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Class</label>
                    <select name="class_id" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('defaultersFilterForm').submit();">
                        <option value="">All classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ((string)($classId ?? '') === (string)$c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Minimum Days Overdue -->
                <div class="col-6 col-md-3">
                    <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 0.76rem;">Minimum Days Overdue</label>
                    <input type="number" name="min_days" id="minDaysInput" value="<?= e($minDays ?? 30) ?>" 
                           class="form-control form-control-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                           style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('defaultersFilterForm').submit();">
                </div>

                <!-- Clear Filters -->
                <div class="col-12 col-md-1 text-md-end">
                    <a href="<?= e(url('finance/reports/defaulters')) ?>" class="text-decoration-none small text-secondary fw-semibold d-inline-flex align-items-center gap-1 py-2" style="font-size: 0.82rem; white-space: nowrap;">
                        ✕ Clear Filters
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="defaultersTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 22%;">
                            STUDENT NAME
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            CLASS
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 14%;">
                            INVOICE #
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            DUE DATE
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            DAYS OVERDUE
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            TOTAL BILLED
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-end" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            OUTSTANDING BALANCE
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 6%;">
                            ACTIONS
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($defaulters)): ?>
                        <!-- Exact CodeClove Empty State matching screenshot -->
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <div class="py-5 d-flex flex-column align-items-center justify-content-center">
                                    <div class="rounded-4 p-3 mb-3 d-flex align-items-center justify-content-center border" style="width: 54px; height: 54px; background: #fff; border-color: #e2e8f0 !important;">
                                        <i data-lucide="file-text" style="width: 24px; height: 24px; color: #94a3b8;"></i>
                                    </div>
                                    <h5 class="fw-bold text-dark mb-1" style="font-size: 1rem;">No Defaulters Found</h5>
                                    <p class="text-muted small mb-0">Hooray! No student matches the defaulter criteria for this academic session.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($defaulters as $d): 
                            $invId = (int)$d['id'];
                            $fName = $d['first_name'] ?? 'Student';
                            $lName = $d['last_name'] ?? '';
                            $fullName = trim($fName . ' ' . $lName);
                            $admNo = $d['admission_no'] ?? ('STU' . str_pad((string)$invId, 6, '0', STR_PAD_LEFT));
                            $invNo = $d['invoice_no'];
                            $className = $d['class_name'] ?? 'Class 1';
                            $dueDateFmt = date('d/m/Y', strtotime($d['due_date']));
                            $daysOverdue = (int)$d['days_overdue'];
                            $totalAmt = (float)$d['total_amount'];
                            $paidAmt = (float)$d['paid_amount'];
                            $balance = max(0.0, $totalAmt - $paidAmt);
                        ?>
                            <tr class="defaulter-row" data-student="<?= e(strtolower($fullName)) ?>" data-adm="<?= e(strtolower($admNo)) ?>" data-inv="<?= e(strtolower($invNo)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Student Name -->
                                <td class="py-3 px-4">
                                    <div>
                                        <span class="fw-bold text-dark" style="font-size: 0.88rem; letter-spacing: -0.01em;">
                                            <?= e($fullName) ?>
                                        </span>
                                        <div class="text-muted font-monospace" style="font-size: 0.72rem;">
                                            <?= e($admNo) ?>
                                        </div>
                                    </div>
                                </td>

                                <!-- Class -->
                                <td class="py-3 px-3 text-secondary" style="font-size: 0.84rem;">
                                    <?= e($className) ?>
                                </td>

                                <!-- Invoice # -->
                                <td class="py-3 px-3">
                                    <span class="font-monospace text-dark fw-semibold" style="font-size: 0.84rem; letter-spacing: 0.02em;">
                                        <?= e($invNo) ?>
                                    </span>
                                </td>

                                <!-- Due Date -->
                                <td class="py-3 px-3 text-secondary" style="font-size: 0.84rem;">
                                    <?= e($dueDateFmt) ?>
                                </td>

                                <!-- Days Overdue -->
                                <td class="py-3 px-3 text-center">
                                    <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-size: 0.74rem;">
                                        <?= $daysOverdue ?> days
                                    </span>
                                </td>

                                <!-- Total Billed -->
                                <td class="py-3 px-3 text-end text-dark fw-medium" style="font-size: 0.88rem;">
                                    ₹<?= number_format($totalAmt, 2) ?>
                                </td>

                                <!-- Outstanding Balance -->
                                <td class="py-3 px-3 text-end fw-bold text-danger" style="font-size: 0.90rem;">
                                    ₹<?= number_format($balance, 2) ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <!-- Send Reminder / Notice Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                title="Send Overdue Reminder" onclick="alert('Fee reminder notice dispatched for <?= e($fullName) ?> (<?= e($invNo) ?>)');">
                                            <i data-lucide="bell" style="width: 14px; height: 14px;"></i>
                                        </button>

                                        <!-- Collect Payment Link -->
                                        <a href="<?= e(url('finance/invoices')) ?>" class="text-secondary action-icon-btn text-decoration-none" title="Collect Fee">
                                            <i data-lucide="credit-card" style="width: 14px; height: 14px;"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (!empty($defaulters)): ?>
            <!-- Table Footer -->
            <div class="p-3 bg-white border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
                <span class="text-muted small" style="font-size: 0.8rem;">
                    Showing 1 to <?= min(25, $totalCount) ?> of <?= $totalCount ?> defaulters
                </span>

                <div class="d-flex align-items-center gap-2">
                    <span class="text-muted small" style="font-size: 0.8rem;">Rows:</span>
                    <select class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" style="width: 70px; height: 32px; font-size: 0.8rem;">
                        <option value="25" selected>25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.action-icon-btn {
    opacity: 0.65;
    transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
}
.action-icon-btn:hover {
    opacity: 1;
    transform: scale(1.15);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Client-side real-time live search
    const searchInput = document.getElementById('defaulterLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.defaulter-row');

            rows.forEach(row => {
                const student = row.getAttribute('data-student') || '';
                const adm = row.getAttribute('data-adm') || '';
                const inv = row.getAttribute('data-inv') || '';
                if (!query || student.includes(query) || adm.includes(query) || inv.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>
