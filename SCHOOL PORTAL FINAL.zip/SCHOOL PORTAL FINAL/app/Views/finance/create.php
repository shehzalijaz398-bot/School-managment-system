<?php
/**
 * CodeClove School Management Pro — Create Invoice View
 * Pixel-perfect match to official CodeClove Finance / Invoices / New Invoice workflow
 */
?>

<style>
.cc-invoice-container {
  max-width: 1200px;
  margin: 0 auto;
}
.cc-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem 1.75rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
  margin-bottom: 1.5rem;
  transition: border-color 0.15s ease;
}
.cc-card:hover {
  border-color: #cbd5e1;
}
.cc-section-title {
  font-size: 0.76rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.cc-form-label {
  font-size: 0.82rem;
  font-weight: 600;
  color: #334155;
  margin-bottom: 0.35rem;
  display: block;
}
.cc-form-label .req {
  color: #dc2626;
  font-weight: 700;
}
.cc-input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.5rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
}
.cc-input:focus {
  border-color: #4f46e5;
  outline: none;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.cc-input::placeholder {
  color: #94a3b8;
  font-size: 0.84rem;
}
.cc-input-group {
  position: relative;
}
.cc-input-icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #94a3b8;
  pointer-events: none;
}
.cc-btn-cancel, .cc-btn-draft {
  border: 1px solid #e2e8f0;
  background: #ffffff;
  color: #475569;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.25rem;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.cc-btn-cancel:hover, .cc-btn-draft:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-btn-issue {
  background: #4f46e5;
  border: 1px solid #4f46e5;
  color: #ffffff;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.5rem;
  border-radius: 8px;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(79, 70, 229, 0.2);
}
.cc-btn-issue:hover {
  background: #4338ca;
  border-color: #4338ca;
  color: #ffffff;
}
.cc-btn-add-fee {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  color: #334155;
  font-weight: 600;
  font-size: 0.82rem;
  padding: 0.35rem 0.85rem;
  border-radius: 7px;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  transition: all 0.15s ease;
}
.cc-btn-add-fee:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}
.cc-btn-delete-row {
  width: 36px;
  height: 38px;
  border-radius: 8px;
  background-color: #f87171;
  border: none;
  color: #ffffff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.15s ease;
}
.cc-btn-delete-row:hover {
  background-color: #ef4444;
}
.cc-fee-th {
  font-size: 0.72rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 0.45rem;
}
.cc-summary-sticky {
  position: sticky;
  top: 90px;
}
.cc-summary-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
  font-size: 0.9rem;
  color: #475569;
}
.cc-summary-net {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 0.75rem;
  margin-bottom: 1.5rem;
  font-size: 1.05rem;
  font-weight: 700;
  color: #0f172a;
}
</style>

<div class="cc-invoice-container mb-5">

  <!-- 1. Breadcrumbs -->
  <nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item"><a href="<?= e(url('finance')) ?>" class="text-muted text-decoration-none">Finance</a></li>
      <li class="breadcrumb-item"><a href="<?= e(url('finance/invoices')) ?>" class="text-muted text-decoration-none">Invoices</a></li>
      <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">New Invoice</li>
    </ol>
  </nav>

  <form method="post" action="<?= e(url('finance/invoices')) ?>" id="createInvoiceForm">
    <?= csrf_field() ?>

    <!-- 2. Page Header with Action Buttons -->
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
      <div>
        <div class="d-flex align-items-center gap-2 mb-1">
          <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-sm btn-white border d-inline-flex align-items-center justify-content-center text-muted" style="width: 32px; height: 32px; border-radius: 8px; background: #ffffff; border-color: #e2e8f0;" title="Back to Invoices">
            <i data-lucide="arrow-left" style="width: 18px; height: 18px;"></i>
          </a>
          <h1 class="h3 fw-bold text-dark mb-0" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Create Invoice') ?>
          </h1>
        </div>
        <p class="text-muted small mb-0 ps-1" style="margin-left: 36px;">Select a student, add fee line items, and issue the invoice.</p>
      </div>

      <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('finance/invoices')) ?>" class="btn cc-btn-cancel text-decoration-none">Cancel</a>
        <button type="submit" name="status" value="draft" class="btn cc-btn-draft">Save as Draft</button>
        <button type="submit" name="status" value="unpaid" class="btn cc-btn-issue">Issue Invoice</button>
      </div>
    </div>

    <!-- 3. Main 2-Column Layout -->
    <div class="row g-4">

      <!-- LEFT COLUMN: Forms and Line Items (col-lg-8) -->
      <div class="col-12 col-lg-8">

        <!-- ==========================================
             CARD 1: BILLING DETAILS
             ========================================== -->
        <div class="cc-card">
          <div class="cc-section-title">
            <span>BILLING DETAILS</span>
          </div>

          <!-- Row 1: Filter by Class & Filter by Section (2 cols) -->
          <div class="row g-3 mb-3">
            <div class="col-12 col-md-6">
              <label class="cc-form-label">Filter by Class</label>
              <select id="filterClassSelect" class="cc-input form-select" onchange="applyStudentFilters()">
                <option value="">Select..</option>
                <?php foreach (($classes ?? []) as $cls): ?>
                  <option value="<?= (int)$cls['id'] ?>"><?= e($cls['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <div class="text-muted mt-1" style="font-size: 11px;">Optional &mdash; narrows student list</div>
            </div>

            <div class="col-12 col-md-6">
              <label class="cc-form-label">Filter by Section</label>
              <select id="filterSectionSelect" class="cc-input form-select" onchange="applyStudentFilters()">
                <option value="">Select..</option>
                <?php foreach (($sections ?? []) as $sec): ?>
                  <option value="<?= (int)$sec['id'] ?>" data-class-id="<?= (int)$sec['class_id'] ?>"><?= e($sec['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <div class="text-muted mt-1" style="font-size: 11px;">Optional</div>
            </div>
          </div>

          <!-- Row 2: Student * (Full width searchable select) -->
          <div class="mb-3">
            <label class="cc-form-label">Student <span class="req">*</span></label>
            <div class="position-relative">
              <select name="student_id" id="studentSelect" class="cc-input form-select" required>
                <option value="">Type student name or ID to search...</option>
                <?php foreach (($students ?? []) as $st): ?>
                  <option value="<?= (int)$st['id'] ?>" 
                          data-class-id="<?= (int)$st['class_id'] ?>" 
                          data-section-id="<?= (int)$st['section_id'] ?>">
                    <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?>) <?= !empty($st['class_name']) ? '· Class ' . e($st['class_name']) : '' ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <!-- Row 3: Academic Term, Issue Date *, Due Date (3 cols) -->
          <div class="row g-3">
            <div class="col-12 col-md-4">
              <label class="cc-form-label">Academic Term</label>
              <select name="term" class="cc-input form-select">
                <option value="">Select..</option>
                <?php foreach (($terms ?? ['Term 1', 'Term 2', 'Term 3', 'Annual']) as $t): ?>
                  <option value="<?= e($t) ?>" <?= $t === 'Term 1' ? 'selected' : '' ?>><?= e($t) ?></option>
                <?php endforeach; ?>
              </select>
              <div class="text-muted mt-1" style="font-size: 11px;">Optional</div>
            </div>

            <div class="col-12 col-md-4">
              <label class="cc-form-label">Issue Date <span class="req">*</span></label>
              <div class="cc-input-group">
                <input type="date" name="invoice_date" class="cc-input" required value="<?= date('Y-m-d') ?>">
                <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
              </div>
            </div>

            <div class="col-12 col-md-4">
              <label class="cc-form-label">Due Date</label>
              <div class="cc-input-group">
                <input type="date" name="due_date" class="cc-input" placeholder="DD/MM/YYYY">
                <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
              </div>
              <div class="text-muted mt-1" style="font-size: 11px;">Leave blank if no due date</div>
            </div>
          </div>
        </div>

        <!-- ==========================================
             CARD 2: FEE SCHEDULE
             ========================================== -->
        <div class="cc-card">
          <div class="cc-section-title">
            <span>FEE SCHEDULE</span>
            <button type="button" class="btn cc-btn-add-fee" onclick="addFeeRow()">
              <i data-lucide="plus" style="width: 14px; height: 14px;"></i>
              <span>Add Fee</span>
            </button>
          </div>

          <!-- Fee Schedule Column Headers -->
          <div class="row g-2 mb-2 d-none d-md-flex">
            <div class="col-3 cc-fee-th">FEE TYPE</div>
            <div class="col-4 cc-fee-th">DESCRIPTION</div>
            <div class="col-2 cc-fee-th">AMOUNT (INR)</div>
            <div class="col-2 cc-fee-th">CONCESSION</div>
            <div class="col-1 cc-fee-th text-center"></div>
          </div>

          <!-- Fee Line Items Container -->
          <div id="feeRowsContainer">
            <!-- Row 1 (Default) -->
            <div class="fee-row row g-2 mb-2 align-items-center" data-row-idx="0">
              <div class="col-12 col-md-3">
                <select name="fee_type_id[]" class="cc-input form-select fee-type-select" onchange="handleFeeTypeChange(this)">
                  <option value="">Select..</option>
                  <?php foreach (($categories ?? []) as $cat): ?>
                    <option value="<?= (int)$cat['id'] ?>" data-name="<?= e($cat['name']) ?>" data-amount="<?= (float)($cat['default_amount'] ?? 0) ?>">
                      <?= e($cat['name']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-12 col-md-4">
                <input type="text" name="description[]" class="cc-input fee-desc-input" placeholder="e.g. Term 2 Tuition">
              </div>
              <div class="col-12 col-md-2">
                <input type="number" step="0.01" min="0" name="amount[]" class="cc-input fee-amount-input text-end" value="0" oninput="recalcInvoiceSummary()">
              </div>
              <div class="col-12 col-md-2">
                <input type="number" step="0.01" min="0" name="concession[]" class="cc-input fee-concession-input text-end" value="0" oninput="recalcInvoiceSummary()">
              </div>
              <div class="col-12 col-md-1 text-center">
                <button type="button" class="cc-btn-delete-row" onclick="removeFeeRow(this)" title="Remove fee item">
                  <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- ==========================================
             CARD 3: ADDITIONAL CONCESSION
             ========================================== -->
        <div class="cc-card">
          <div class="cc-section-title">
            <span>ADDITIONAL CONCESSION</span>
          </div>

          <div class="row g-3">
            <div class="col-12 col-md-5">
              <label class="cc-form-label">Concession Amount (INR)</label>
              <input type="number" step="0.01" min="0" name="additional_concession" id="additionalConcessionInput" class="cc-input text-end" value="0" oninput="recalcInvoiceSummary()">
            </div>
            <div class="col-12 col-md-7">
              <label class="cc-form-label">Reason</label>
              <input type="text" name="concession_reason" class="cc-input" placeholder="Concession reason...">
              <div class="text-muted mt-1" style="font-size: 11px;">e.g. Sibling discount, Merit scholarship</div>
            </div>
          </div>
        </div>

      </div>

      <!-- RIGHT COLUMN: INVOICE SUMMARY (col-lg-4) -->
      <div class="col-12 col-lg-4">
        <div class="cc-card cc-summary-sticky">
          <div class="cc-section-title">
            <span>INVOICE SUMMARY</span>
          </div>

          <!-- Fee Subtotal -->
          <div class="cc-summary-row">
            <span>Fee Subtotal</span>
            <span id="summarySubtotal" class="fw-semibold text-dark">₹0.00</span>
          </div>

          <!-- Concession / Discount Row (dynamic if > 0) -->
          <div class="cc-summary-row" id="summaryConcessionRow" style="display:none;">
            <span>Concessions</span>
            <span id="summaryConcession" class="text-danger fw-semibold">-₹0.00</span>
          </div>

          <hr class="my-3 text-muted opacity-25">

          <!-- Net Payable -->
          <div class="cc-summary-net">
            <span>Net Payable</span>
            <span id="summaryNetPayable">₹0.00</span>
          </div>

          <!-- Full Width Action Buttons -->
          <button type="submit" name="status" value="unpaid" class="btn cc-btn-issue w-100 mb-2" style="height: 42px;">
            Issue Invoice
          </button>
          <button type="submit" name="status" value="draft" class="btn cc-btn-draft w-100" style="height: 42px;">
            Save as Draft
          </button>

        </div>
      </div>

    </div>

  </form>
</div>

<!-- Category template options for Javascript row generator -->
<template id="feeCategoryOptionsTemplate">
  <option value="">Select..</option>
  <?php foreach (($categories ?? []) as $cat): ?>
    <option value="<?= (int)$cat['id'] ?>" data-name="<?= e($cat['name']) ?>" data-amount="<?= (float)($cat['default_amount'] ?? 0) ?>">
      <?= e($cat['name']) ?>
    </option>
  <?php endforeach; ?>
</template>

<script>
let rowCounter = 1;

function addFeeRow() {
    rowCounter++;
    const container = document.getElementById('feeRowsContainer');
    const optionsHtml = document.getElementById('feeCategoryOptionsTemplate').innerHTML;
    
    const row = document.createElement('div');
    row.className = 'fee-row row g-2 mb-2 align-items-center';
    row.setAttribute('data-row-idx', rowCounter);
    row.innerHTML = `
        <div class="col-12 col-md-3">
            <select name="fee_type_id[]" class="cc-input form-select fee-type-select" onchange="handleFeeTypeChange(this)">
                ${optionsHtml}
            </select>
        </div>
        <div class="col-12 col-md-4">
            <input type="text" name="description[]" class="cc-input fee-desc-input" placeholder="e.g. Term 2 Tuition">
        </div>
        <div class="col-12 col-md-2">
            <input type="number" step="0.01" min="0" name="amount[]" class="cc-input fee-amount-input text-end" value="0" oninput="recalcInvoiceSummary()">
        </div>
        <div class="col-12 col-md-2">
            <input type="number" step="0.01" min="0" name="concession[]" class="cc-input fee-concession-input text-end" value="0" oninput="recalcInvoiceSummary()">
        </div>
        <div class="col-12 col-md-1 text-center">
            <button type="button" class="cc-btn-delete-row" onclick="removeFeeRow(this)" title="Remove fee item">
                <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
            </button>
        </div>
    `;
    container.appendChild(row);
    if (typeof lucide !== 'undefined') lucide.createIcons();
    recalcInvoiceSummary();
}

function removeFeeRow(btn) {
    const row = btn.closest('.fee-row');
    const container = document.getElementById('feeRowsContainer');
    if (container.querySelectorAll('.fee-row').length > 1) {
        row.remove();
    } else {
        // Reset single row
        row.querySelector('.fee-type-select').value = '';
        row.querySelector('.fee-desc-input').value = '';
        row.querySelector('.fee-amount-input').value = '0';
        row.querySelector('.fee-concession-input').value = '0';
    }
    recalcInvoiceSummary();
}

function handleFeeTypeChange(select) {
    const row = select.closest('.fee-row');
    const selectedOption = select.options[select.selectedIndex];
    const descInput = row.querySelector('.fee-desc-input');
    const amountInput = row.querySelector('.fee-amount-input');

    if (selectedOption && selectedOption.value) {
        const catName = selectedOption.getAttribute('data-name');
        const defaultAmount = parseFloat(selectedOption.getAttribute('data-amount') || 0);

        if (!descInput.value) {
            descInput.value = catName || '';
        }
        if (parseFloat(amountInput.value || 0) === 0 && defaultAmount > 0) {
            amountInput.value = defaultAmount;
        }
    }
    recalcInvoiceSummary();
}

function recalcInvoiceSummary() {
    let subtotal = 0;
    let concessions = 0;

    document.querySelectorAll('.fee-row').forEach(row => {
        const amt = parseFloat(row.querySelector('.fee-amount-input').value || 0);
        const conc = parseFloat(row.querySelector('.fee-concession-input').value || 0);
        subtotal += amt;
        concessions += conc;
    });

    const addlConcession = parseFloat(document.getElementById('additionalConcessionInput').value || 0);
    concessions += addlConcession;

    const netPayable = Math.max(0, subtotal - concessions);

    document.getElementById('summarySubtotal').innerText = '₹' + subtotal.toFixed(2);
    
    const concRow = document.getElementById('summaryConcessionRow');
    if (concessions > 0) {
        concRow.style.display = 'flex';
        document.getElementById('summaryConcession').innerText = '-₹' + concessions.toFixed(2);
    } else {
        concRow.style.display = 'none';
    }

    document.getElementById('summaryNetPayable').innerText = '₹' + netPayable.toFixed(2);
}

function applyStudentFilters() {
    const classId = document.getElementById('filterClassSelect').value;
    const sectionId = document.getElementById('filterSectionSelect').value;
    const select = document.getElementById('studentSelect');
    const options = select.querySelectorAll('option');

    options.forEach(opt => {
        if (!opt.value) return; // keep placeholder
        const optClass = opt.getAttribute('data-class-id');
        const optSec = opt.getAttribute('data-section-id');

        let match = true;
        if (classId && optClass !== classId) match = false;
        if (sectionId && optSec !== sectionId) match = false;

        opt.style.display = match ? 'block' : 'none';
    });

    // Also filter sections dropdown when class changes
    const secSelect = document.getElementById('filterSectionSelect');
    secSelect.querySelectorAll('option').forEach(opt => {
        if (!opt.value) return;
        const optClass = opt.getAttribute('data-class-id');
        opt.style.display = (!classId || optClass === classId) ? 'block' : 'none';
    });
}

document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    recalcInvoiceSummary();
});
</script>
