<?php
$title = 'Department Budgets & Variance Analysis';
$budgets = $budgets ?? [];
$categories = $categories ?? [];
$fiscalYear = $fiscalYear ?? date('Y') . '-' . (date('Y') + 1);
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="pie-chart" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Fiscal Year <?= e($fiscalYear) ?>
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Track allocated departmental budgets against actual operational expenses with real-time variance analysis.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newBudgetModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> Allocate Budget
    </button>
    <a href="<?= e(url('finance/expenses')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i> Expenses
    </a>
  </div>
</div>

<!-- Budgets Table -->
<div class="card border-0 shadow-sm rounded-3 bg-white">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light small text-uppercase">
          <tr>
            <th class="ps-3">Department</th>
            <th>Expense Category</th>
            <th class="text-end">Allocated Budget ($)</th>
            <th class="text-end">Actual Spent ($)</th>
            <th class="text-end">Variance / Remaining ($)</th>
            <th style="width: 20%;">Budget Utilization</th>
            <th class="pe-3">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($budgets)): ?>
            <tr>
              <td colspan="7" class="text-center py-4 text-muted">No departmental budgets configured for this fiscal year. Click "Allocate Budget" to set expenditure controls.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($budgets as $b): ?>
              <tr>
                <td class="ps-3 fw-bold text-dark"><?= e($b['department']) ?></td>
                <td><?= e($b['category_name'] ?? 'General Expenditure') ?></td>
                <td class="text-end font-monospace fw-semibold"><?= number_format((float)$b['allocated_amount'], 2) ?></td>
                <td class="text-end font-monospace text-danger fw-semibold"><?= number_format((float)$b['actual_spent'], 2) ?></td>
                <td class="text-end font-monospace fw-bold <?= $b['variance'] >= 0 ? 'text-success' : 'text-danger' ?>">
                  <?= number_format((float)$b['variance'], 2) ?>
                </td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div class="progress flex-grow-1" style="height: 6px;">
                      <div class="progress-bar <?= $b['percent_used'] > 100 ? 'bg-danger' : ($b['percent_used'] > 85 ? 'bg-warning' : 'bg-primary') ?>" 
                           role="progressbar" style="width: <?= min(100, $b['percent_used']) ?>%;"></div>
                    </div>
                    <span class="small font-monospace"><?= $b['percent_used'] ?>%</span>
                  </div>
                </td>
                <td class="pe-3">
                  <?php if ($b['is_over_budget']): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle small px-2 py-0">Over Budget</span>
                  <?php else: ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle small px-2 py-0">On Track</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Allocate Budget -->
<div class="modal fade" id="newBudgetModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('finance/budgets')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fw-bold">Allocate Departmental Budget</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold">Department <span class="text-danger">*</span></label>
            <input type="text" name="department" placeholder="e.g. Science &amp; Labs, Athletics, Administration" class="form-control form-control-sm" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Fiscal Year</label>
            <input type="text" name="fiscal_year" value="<?= e($fiscalYear) ?>" class="form-control form-control-sm" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Expense Category Scope</label>
            <select name="category_id" class="form-select form-select-sm">
              <option value="">-- All Departmental Categories --</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Allocated Budget Cap ($) <span class="text-danger">*</span></label>
            <input type="number" step="0.01" min="1" name="allocated_amount" placeholder="0.00" class="form-control form-control-sm" required>
          </div>
          <div class="mb-2">
            <label class="form-label small fw-semibold">Allocation Notes</label>
            <textarea name="notes" rows="2" class="form-control form-control-sm" placeholder="Budget committee approval remarks..."></textarea>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Set Budget Allocation</button>
        </div>
      </form>
    </div>
  </div>
</div>
