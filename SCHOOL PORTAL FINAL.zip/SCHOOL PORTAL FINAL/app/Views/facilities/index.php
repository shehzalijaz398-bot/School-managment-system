<?php
$title = $title ?? 'Campus Facilities, Asset Lifecycle & Maintenance';
$activeTab = $tab ?? 'facilities';
?>

<div class="container-fluid px-3 px-md-4 py-3">
  <!-- Page Header & Breadcrumbs -->
  <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-3 mb-4">
    <div>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-1 text-muted" style="font-size: 0.825rem;">
          <li class="breadcrumb-item"><a href="<?= e(url('dashboard')) ?>" class="text-decoration-none">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?= e(url('inventory')) ?>" class="text-decoration-none">Operations</a></li>
          <li class="breadcrumb-item active" aria-current="page">Campus Facilities &amp; Assets</li>
        </ol>
      </nav>
      <h1 class="h3 fw-bold text-dark mb-0 d-flex align-items-center gap-2">
        <i data-lucide="building" class="text-primary" style="width: 28px; height: 28px;"></i>
        Campus Facilities &amp; Fixed Asset Lifecycle
      </h1>
      <p class="text-muted small mb-0 mt-1">Manage rooms, collision-free resource reservations, fixed asset depreciation, custody tracking, and maintenance work orders.</p>
    </div>

    <!-- Quick Actions -->
    <div class="d-flex align-items-center flex-wrap gap-2">
      <button type="button" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#newBookingModal">
        <i data-lucide="calendar-plus" style="width: 15px; height: 15px;"></i>
        <span>Reserve Facility</span>
      </button>
      <button type="button" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#newWorkOrderModal">
        <i data-lucide="wrench" style="width: 15px; height: 15px;"></i>
        <span>New Work Order</span>
      </button>
      <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newFacilityModal">
        <i data-lucide="plus" style="width: 15px; height: 15px;"></i>
        <span>Add Facility</span>
      </button>
    </div>
  </div>

  <!-- KPI Metrics Cards Row -->
  <div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
      <div class="card border-0 shadow-sm rounded-3 h-100 p-3 bg-white">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Campus Facilities</span>
          <div class="rounded-2 p-2 bg-primary bg-opacity-10 text-primary">
            <i data-lucide="building-2" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <div class="fs-4 fw-bold text-dark"><?= number_format($metrics['facilities_total']) ?></div>
        <div class="small text-muted mt-1">
          <span class="text-success fw-medium"><?= $metrics['facilities_available'] ?> Available</span> &bull; <?= number_format($metrics['facilities_capacity']) ?> seats cap.
        </div>
      </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
      <div class="card border-0 shadow-sm rounded-3 h-100 p-3 bg-white">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Active Reservations</span>
          <div class="rounded-2 p-2 bg-info bg-opacity-10 text-info">
            <i data-lucide="calendar-check-2" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <div class="fs-4 fw-bold text-dark"><?= number_format($metrics['bookings_upcoming']) ?></div>
        <div class="small text-muted mt-1">
          <span class="text-primary fw-medium"><?= $metrics['bookings_pending'] ?> Pending Approval</span>
        </div>
      </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
      <div class="card border-0 shadow-sm rounded-3 h-100 p-3 bg-white">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Fixed Assets (Net Book Value)</span>
          <div class="rounded-2 p-2 bg-success bg-opacity-10 text-success">
            <i data-lucide="banknote" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <div class="fs-4 fw-bold text-dark"><?= formatMoney($metrics['assets_net_book_value']) ?></div>
        <div class="small text-muted mt-1">
          <span>Cost: <?= formatMoney($metrics['assets_original_cost']) ?></span> &bull; <?= $metrics['assets_total'] ?> units
        </div>
      </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
      <div class="card border-0 shadow-sm rounded-3 h-100 p-3 bg-white">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Work Orders &amp; Maintenance</span>
          <div class="rounded-2 p-2 bg-warning bg-opacity-10 text-warning">
            <i data-lucide="alert-triangle" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <div class="fs-4 fw-bold text-dark"><?= number_format($metrics['work_orders_active']) ?></div>
        <div class="small text-muted mt-1">
          <span class="text-danger fw-medium"><?= $metrics['work_orders_urgent'] ?> Urgent</span> &bull; MTD: <?= formatMoney($metrics['work_orders_mtd_spend']) ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Segmented Tab Navigation -->
  <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
    <div class="card-body p-2 d-flex flex-wrap align-items-center justify-content-between gap-2 border-bottom">
      <ul class="nav nav-pills gap-1" id="facilityTabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link px-3 py-2 fw-medium <?= $activeTab === 'facilities' ? 'active' : '' ?>" href="<?= e(url('facilities?tab=facilities')) ?>">
            <i data-lucide="building" style="width: 15px; height: 15px; margin-right: 5px;"></i>
            Facilities &amp; Rooms
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-3 py-2 fw-medium <?= $activeTab === 'bookings' ? 'active' : '' ?>" href="<?= e(url('facilities?tab=bookings')) ?>">
            <i data-lucide="calendar" style="width: 15px; height: 15px; margin-right: 5px;"></i>
            Room Bookings &amp; Schedules
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-3 py-2 fw-medium <?= $activeTab === 'assets' ? 'active' : '' ?>" href="<?= e(url('facilities?tab=assets')) ?>">
            <i data-lucide="tag" style="width: 15px; height: 15px; margin-right: 5px;"></i>
            Fixed Assets &amp; Custody
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-3 py-2 fw-medium <?= $activeTab === 'work_orders' ? 'active' : '' ?>" href="<?= e(url('facilities?tab=work_orders')) ?>">
            <i data-lucide="wrench" style="width: 15px; height: 15px; margin-right: 5px;"></i>
            Maintenance Work Orders
          </a>
        </li>
      </ul>

      <?php if ($activeTab === 'assets'): ?>
        <div class="d-flex align-items-center gap-2">
          <a href="<?= e(url('facilities/assets/export-csv')) ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1">
            <i data-lucide="download" style="width: 14px; height: 14px;"></i>
            <span>Export Assets CSV</span>
          </a>
          <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#newAssetModal">
            <i data-lucide="plus" style="width: 14px; height: 14px;"></i>
            <span>Register Asset</span>
          </button>
        </div>
      <?php endif; ?>
    </div>

    <!-- TAB 1: CAMPUS FACILITIES -->
    <?php if ($activeTab === 'facilities'): ?>
      <div class="p-3">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 0.875rem;">
            <thead class="table-light text-muted" style="font-size: 0.775rem; text-transform: uppercase; letter-spacing: 0.04em;">
              <tr>
                <th style="min-width: 160px;">Facility / Room</th>
                <th>Type</th>
                <th>Location / Block</th>
                <th>Capacity</th>
                <th>Amenities</th>
                <th>Status</th>
                <th>Live Bookings</th>
                <th class="text-end" style="min-width: 120px;">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($facilities)): ?>
                <tr>
                  <td colspan="8" class="text-center py-5 text-muted">
                    <i data-lucide="building-2" style="width: 36px; height: 36px; opacity: 0.4;" class="mb-2"></i>
                    <p class="mb-1">No campus facilities registered yet.</p>
                    <button class="btn btn-sm btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#newFacilityModal">+ Register First Facility</button>
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach ($facilities as $fac): ?>
                  <?php 
                    $amenities = !empty($fac['amenities_json']) ? json_decode($fac['amenities_json'], true) : [];
                  ?>
                  <tr>
                    <td>
                      <div class="fw-bold text-dark"><?= e($fac['name']) ?></div>
                      <span class="badge bg-light text-muted border font-monospace" style="font-size: 0.7rem;"><?= e($fac['facility_code']) ?></span>
                    </td>
                    <td>
                      <span class="badge bg-secondary bg-opacity-10 text-secondary border-0">
                        <?= ucwords(str_replace('_', ' ', $fac['facility_type'])) ?>
                      </span>
                    </td>
                    <td>
                      <div><?= e($fac['building_block'] ?: 'Main Campus') ?></div>
                      <div class="small text-muted"><?= e($fac['floor'] ?: 'Ground Floor') ?></div>
                    </td>
                    <td>
                      <span class="fw-semibold"><?= (int)$fac['capacity'] ?></span> <span class="text-muted small">seats</span>
                    </td>
                    <td>
                      <div class="d-flex flex-wrap gap-1">
                        <?php if (!empty($amenities) && is_array($amenities)): ?>
                          <?php foreach (array_slice($amenities, 0, 3) as $am): ?>
                            <span class="badge bg-light text-dark border" style="font-size: 0.7rem;"><?= e($am) ?></span>
                          <?php endforeach; ?>
                          <?php if (count($amenities) > 3): ?>
                            <span class="badge bg-light text-muted border" style="font-size: 0.7rem;">+<?= count($amenities) - 3 ?></span>
                          <?php endif; ?>
                        <?php else: ?>
                          <span class="text-muted small">&mdash;</span>
                        <?php endif; ?>
                      </div>
                    </td>
                    <td>
                      <?php if ($fac['status'] === 'available'): ?>
                        <span class="badge bg-success bg-opacity-10 text-success border-0">Available</span>
                      <?php elseif ($fac['status'] === 'under_maintenance'): ?>
                        <span class="badge bg-warning bg-opacity-10 text-warning border-0">Maintenance</span>
                      <?php else: ?>
                        <span class="badge bg-secondary bg-opacity-10 text-secondary border-0">Inactive</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if ((int)$fac['active_bookings_count'] > 0): ?>
                        <span class="badge bg-info bg-opacity-10 text-info border-0"><?= (int)$fac['active_bookings_count'] ?> Active</span>
                      <?php else: ?>
                        <span class="text-muted small">None</span>
                      <?php endif; ?>
                    </td>
                    <td class="text-end">
                      <div class="d-inline-flex gap-1">
                        <button class="btn btn-outline-primary btn-sm p-1 px-2" title="Reserve" onclick="openReserveModal(<?= (int)$fac['id'] ?>, '<?= e(addslashes($fac['name'])) ?>')">
                          <i data-lucide="calendar-plus" style="width: 14px; height: 14px;"></i>
                        </button>
                        <form method="POST" action="<?= e(url('facilities/' . $fac['id'] . '/delete')) ?>" class="d-inline" onsubmit="return confirm('Remove facility <?= e(addslashes($fac['name'])) ?> from records?');">
                          <?= csrf_field() ?>
                          <button type="submit" class="btn btn-outline-danger btn-sm p-1 px-2" title="Delete">
                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>

    <!-- TAB 2: ROOM BOOKINGS & SCHEDULES -->
    <?php if ($activeTab === 'bookings'): ?>
      <div class="p-3">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 0.875rem;">
            <thead class="table-light text-muted" style="font-size: 0.775rem; text-transform: uppercase; letter-spacing: 0.04em;">
              <tr>
                <th>Booking Ref</th>
                <th>Facility</th>
                <th>Event / Purpose</th>
                <th>Time Window</th>
                <th>Requested By</th>
                <th>Attendees</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($bookings)): ?>
                <tr>
                  <td colspan="8" class="text-center py-5 text-muted">
                    <i data-lucide="calendar-x" style="width: 36px; height: 36px; opacity: 0.4;" class="mb-2"></i>
                    <p class="mb-1">No reservations booked yet.</p>
                    <button class="btn btn-sm btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#newBookingModal">Book Room Now</button>
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach ($bookings as $bk): ?>
                  <tr>
                    <td>
                      <span class="badge bg-light text-dark border font-monospace"><?= e($bk['booking_ref']) ?></span>
                    </td>
                    <td>
                      <div class="fw-semibold text-dark"><?= e($bk['facility_name']) ?></div>
                      <div class="small text-muted"><?= e($bk['building_block']) ?></div>
                    </td>
                    <td>
                      <div class="fw-medium text-dark"><?= e($bk['title']) ?></div>
                      <?php if (!empty($bk['purpose'])): ?>
                        <div class="small text-muted text-truncate" style="max-width: 200px;"><?= e($bk['purpose']) ?></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="small fw-semibold"><?= date('D, d M Y', strtotime($bk['start_time'])) ?></div>
                      <div class="small text-muted"><?= date('h:i A', strtotime($bk['start_time'])) ?> &ndash; <?= date('h:i A', strtotime($bk['end_time'])) ?></div>
                    </td>
                    <td>
                      <div><?= e($bk['requester_name'] ?: 'Staff User') ?></div>
                      <div class="small text-muted"><?= e($bk['requester_email'] ?: '') ?></div>
                    </td>
                    <td><?= (int)$bk['expected_attendees'] ?></td>
                    <td>
                      <?php 
                        $bStatus = $bk['status'];
                        $bBadgeClass = match($bStatus) {
                          'confirmed' => 'bg-success bg-opacity-10 text-success',
                          'pending' => 'bg-warning bg-opacity-10 text-warning',
                          'rejected' => 'bg-danger bg-opacity-10 text-danger',
                          'completed' => 'bg-info bg-opacity-10 text-info',
                          default => 'bg-secondary bg-opacity-10 text-secondary',
                        };
                      ?>
                      <span class="badge <?= $bBadgeClass ?> border-0">
                        <?= ucfirst($bStatus) ?>
                      </span>
                    </td>
                    <td class="text-end">
                      <div class="d-inline-flex gap-1">
                        <?php if ($bk['status'] === 'pending'): ?>
                          <form method="POST" action="<?= e(url('facilities/bookings/' . $bk['id'] . '/status')) ?>" class="d-inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="status" value="confirmed">
                            <button type="submit" class="btn btn-outline-success btn-sm p-1 px-2" title="Approve">
                              <i data-lucide="check" style="width: 14px; height: 14px;"></i>
                            </button>
                          </form>
                          <form method="POST" action="<?= e(url('facilities/bookings/' . $bk['id'] . '/status')) ?>" class="d-inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="btn btn-outline-danger btn-sm p-1 px-2" title="Reject">
                              <i data-lucide="x" style="width: 14px; height: 14px;"></i>
                            </button>
                          </form>
                        <?php elseif ($bk['status'] === 'confirmed'): ?>
                          <form method="POST" action="<?= e(url('facilities/bookings/' . $bk['id'] . '/status')) ?>" class="d-inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="status" value="completed">
                            <button type="submit" class="btn btn-outline-info btn-sm p-1 px-2" title="Mark Completed">
                              <i data-lucide="check-check" style="width: 14px; height: 14px;"></i>
                            </button>
                          </form>
                          <form method="POST" action="<?= e(url('facilities/bookings/' . $bk['id'] . '/status')) ?>" class="d-inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="status" value="cancelled">
                            <button type="submit" class="btn btn-outline-secondary btn-sm p-1 px-2" title="Cancel Booking">
                              <i data-lucide="ban" style="width: 14px; height: 14px;"></i>
                            </button>
                          </form>
                        <?php endif; ?>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>

    <!-- TAB 3: FIXED ASSETS & CUSTODY -->
    <?php if ($activeTab === 'assets'): ?>
      <div class="p-3">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 0.875rem;">
            <thead class="table-light text-muted" style="font-size: 0.775rem; text-transform: uppercase; letter-spacing: 0.04em;">
              <tr>
                <th>Asset Tag / Name</th>
                <th>Category</th>
                <th>Facility / Custody</th>
                <th>Purchase Cost</th>
                <th>Accumulated Dep.</th>
                <th>Net Book Value (NBV)</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($assets)): ?>
                <tr>
                  <td colspan="8" class="text-center py-5 text-muted">
                    <i data-lucide="tag" style="width: 36px; height: 36px; opacity: 0.4;" class="mb-2"></i>
                    <p class="mb-1">No fixed assets registered in the ledger yet.</p>
                    <button class="btn btn-sm btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#newAssetModal">+ Register First Asset</button>
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach ($assets as $ast): ?>
                  <tr>
                    <td>
                      <div class="fw-bold text-dark"><?= e($ast['name']) ?></div>
                      <span class="badge bg-light text-dark border font-monospace" style="font-size: 0.7rem;"><?= e($ast['asset_tag']) ?></span>
                      <?php if (!empty($ast['serial_number'])): ?>
                        <span class="text-muted small ms-1">S/N: <?= e($ast['serial_number']) ?></span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge bg-secondary bg-opacity-10 text-secondary border-0">
                        <?= ucwords(str_replace('_', ' ', $ast['category'])) ?>
                      </span>
                    </td>
                    <td>
                      <div class="fw-medium text-dark"><?= e($ast['facility_name'] ?: 'General Campus') ?></div>
                      <?php if (!empty($ast['assigned_user_name'])): ?>
                        <div class="small text-primary"><i data-lucide="user-check" style="width:12px;height:12px;"></i> <?= e($ast['assigned_user_name']) ?></div>
                      <?php else: ?>
                        <div class="small text-muted">In Asset Pool</div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="fw-semibold"><?= formatMoney((float)$ast['purchase_cost']) ?></div>
                      <div class="small text-muted"><?= e($ast['purchase_date']) ?></div>
                    </td>
                    <td>
                      <span class="text-danger fw-semibold">-<?= formatMoney((float)$ast['accumulated_depreciation']) ?></span>
                      <div class="small text-muted"><?= ucwords(str_replace('_', ' ', $ast['depreciation_method'])) ?></div>
                    </td>
                    <td>
                      <span class="fw-bold text-success fs-6"><?= formatMoney((float)$ast['calculated_net_book_value']) ?></span>
                    </td>
                    <td>
                      <?php 
                        $astStatus = $ast['status'];
                        $astBadge = match($astStatus) {
                          'in_service' => 'bg-success bg-opacity-10 text-success',
                          'under_maintenance' => 'bg-warning bg-opacity-10 text-warning',
                          'decommissioned' => 'bg-secondary bg-opacity-10 text-secondary',
                          'disposed' => 'bg-danger bg-opacity-10 text-danger',
                          default => 'bg-light text-dark',
                        };
                      ?>
                      <span class="badge <?= $astBadge ?> border-0">
                        <?= ucwords(str_replace('_', ' ', $astStatus)) ?>
                      </span>
                    </td>
                    <td class="text-end">
                      <div class="d-inline-flex gap-1">
                        <?php if (empty($ast['assigned_to_user_id'])): ?>
                          <button class="btn btn-outline-primary btn-sm p-1 px-2" title="Check Out" onclick="openCheckoutModal(<?= (int)$ast['id'] ?>, '<?= e(addslashes($ast['name'])) ?>')">
                            <i data-lucide="log-out" style="width: 14px; height: 14px;"></i>
                          </button>
                        <?php else: ?>
                          <button class="btn btn-outline-success btn-sm p-1 px-2" title="Check In" onclick="openCheckinModal(<?= (int)$ast['id'] ?>, '<?= e(addslashes($ast['name'])) ?>')">
                            <i data-lucide="log-in" style="width: 14px; height: 14px;"></i>
                          </button>
                        <?php endif; ?>
                        <form method="POST" action="<?= e(url('facilities/assets/' . $ast['id'] . '/delete')) ?>" class="d-inline" onsubmit="return confirm('Remove asset from register?');">
                          <?= csrf_field() ?>
                          <button type="submit" class="btn btn-outline-danger btn-sm p-1 px-2" title="Delete">
                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>

    <!-- TAB 4: MAINTENANCE WORK ORDERS -->
    <?php if ($activeTab === 'work_orders'): ?>
      <div class="p-3">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 0.875rem;">
            <thead class="table-light text-muted" style="font-size: 0.775rem; text-transform: uppercase; letter-spacing: 0.04em;">
              <tr>
                <th>Work Order No</th>
                <th>Issue / Description</th>
                <th>Facility / Asset</th>
                <th>Category</th>
                <th>Priority</th>
                <th>Technician</th>
                <th>Estimated Cost</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($workOrders)): ?>
                <tr>
                  <td colspan="9" class="text-center py-5 text-muted">
                    <i data-lucide="check-circle" style="width: 36px; height: 36px; opacity: 0.4;" class="mb-2"></i>
                    <p class="mb-1">All facility systems operational &mdash; no open maintenance tickets.</p>
                    <button class="btn btn-sm btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#newWorkOrderModal">+ Create Work Order</button>
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach ($workOrders as $wo): ?>
                  <tr>
                    <td>
                      <span class="badge bg-light text-dark border font-monospace"><?= e($wo['work_order_no']) ?></span>
                    </td>
                    <td>
                      <div class="fw-bold text-dark"><?= e($wo['title']) ?></div>
                      <?php if (!empty($wo['description'])): ?>
                        <div class="small text-muted text-truncate" style="max-width: 220px;"><?= e($wo['description']) ?></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if (!empty($wo['facility_name'])): ?>
                        <div class="small"><i data-lucide="building" style="width:12px;height:12px;"></i> <?= e($wo['facility_name']) ?></div>
                      <?php endif; ?>
                      <?php if (!empty($wo['asset_name'])): ?>
                        <div class="small text-muted"><i data-lucide="tag" style="width:12px;height:12px;"></i> <?= e($wo['asset_name']) ?> (<?= e($wo['asset_tag']) ?>)</div>
                      <?php endif; ?>
                      <?php if (empty($wo['facility_name']) && empty($wo['asset_name'])): ?>
                        <span class="text-muted small">General Campus</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge bg-light text-dark border"><?= ucwords($wo['category']) ?></span>
                    </td>
                    <td>
                      <?php 
                        $woPriority = $wo['priority'];
                        $prioBadge = match($woPriority) {
                          'urgent' => 'bg-danger text-white',
                          'high' => 'bg-warning text-dark',
                          'medium' => 'bg-info bg-opacity-10 text-info',
                          default => 'bg-light text-muted border',
                        };
                      ?>
                      <span class="badge <?= $prioBadge ?> border-0">
                        <?= ucfirst($woPriority) ?>
                      </span>
                    </td>
                    <td>
                      <div><?= e($wo['assigned_technician'] ?: 'In-house Staff') ?></div>
                      <?php if (!empty($wo['technician_phone'])): ?>
                        <div class="small text-muted"><?= e($wo['technician_phone']) ?></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="fw-semibold"><?= formatMoney((float)$wo['estimated_cost']) ?></div>
                      <?php if ((float)$wo['actual_cost'] > 0): ?>
                        <div class="small text-success">Act: <?= formatMoney((float)$wo['actual_cost']) ?></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php 
                        $woStatus = $wo['status'];
                        $statBadge = match($woStatus) {
                          'completed' => 'bg-success bg-opacity-10 text-success',
                          'in_progress' => 'bg-primary bg-opacity-10 text-primary',
                          'on_hold' => 'bg-warning bg-opacity-10 text-warning',
                          'cancelled' => 'bg-secondary bg-opacity-10 text-secondary',
                          default => 'bg-danger bg-opacity-10 text-danger',
                        };
                      ?>
                      <span class="badge <?= $statBadge ?> border-0">
                        <?= ucwords(str_replace('_', ' ', $woStatus)) ?>
                      </span>
                    </td>
                    <td class="text-end">
                      <button class="btn btn-outline-secondary btn-sm p-1 px-2" title="Update Status" onclick="openUpdateWoModal(<?= (int)$wo['id'] ?>, '<?= e(addslashes($wo['title'])) ?>', '<?= e($wo['status']) ?>', <?= (float)$wo['actual_cost'] ?>)">
                        <i data-lucide="edit-3" style="width: 14px; height: 14px;"></i>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ========================================================================= -->
<!-- MODALS                                                                    -->
<!-- ========================================================================= -->

<!-- Modal: New Facility -->
<div class="modal fade" id="newFacilityModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('facilities')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Register Campus Facility or Room</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="row g-3">
            <div class="col-md-8">
              <label class="form-label fw-semibold">Facility Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="e.g. Einstein Science Auditorium" required>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Facility Code</label>
              <input type="text" name="facility_code" class="form-control font-monospace" placeholder="e.g. AUD-01">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Facility Type</label>
              <select name="facility_type" class="form-select">
                <option value="smart_classroom">Smart Classroom</option>
                <option value="auditorium">Auditorium / Hall</option>
                <option value="laboratory">Science Laboratory</option>
                <option value="computer_lab">Computer Center / IT Lab</option>
                <option value="conference_room">Executive Conference Room</option>
                <option value="sports_facility">Sports Arena / Gymnasium</option>
                <option value="library_hall">Library Study Hall</option>
                <option value="other">Other Facility</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Seating Capacity</label>
              <input type="number" name="capacity" class="form-control" value="40" min="1">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Hourly Rate (₹)</label>
              <input type="number" step="0.01" name="hourly_rate" class="form-control" value="0.00">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Building Block</label>
              <input type="text" name="building_block" class="form-control" placeholder="e.g. Block A - Science Wing">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Floor / Level</label>
              <input type="text" name="floor" class="form-control" placeholder="e.g. 2nd Floor">
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold">Amenities (Comma-separated)</label>
              <input type="text" name="amenities" class="form-control" placeholder="4K Projector, Smart Board, Audio PA System, Air Conditioning, High-speed WiFi">
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold">Usage Rules &amp; Guidelines</label>
              <textarea name="rules_notes" class="form-control" rows="2" placeholder="e.g. Prior key checkout required from reception desk."></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Register Facility</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: New Booking -->
<div class="modal fade" id="newBookingModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('facilities/bookings')) ?>" id="facilityBookingForm">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Reserve Campus Facility</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <!-- Collision Alert Banner -->
          <div id="bookingConflictAlert" class="alert alert-danger d-none d-flex align-items-center gap-2 mb-3">
            <i data-lucide="alert-octagon" style="width: 20px; height: 20px;"></i>
            <span id="bookingConflictMessage"></span>
          </div>

          <div class="row g-3">
            <div class="col-md-12">
              <label class="form-label fw-semibold">Select Target Facility <span class="text-danger">*</span></label>
              <select name="facility_id" id="bookingFacilitySelect" class="form-select" required onchange="triggerConflictCheck()">
                <option value="">&mdash; Choose Facility &mdash;</option>
                <?php foreach ($facilities as $f): ?>
                  <option value="<?= (int)$f['id'] ?>"><?= e($f['name']) ?> (<?= e($f['building_block']) ?> &bull; Cap: <?= (int)$f['capacity'] ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-8">
              <label class="form-label fw-semibold">Event / Meeting Title <span class="text-danger">*</span></label>
              <input type="text" name="title" class="form-control" placeholder="e.g. Annual Inter-School Science Fair" required>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Expected Attendees</label>
              <input type="number" name="expected_attendees" class="form-control" value="25" min="1">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Reservation Start <span class="text-danger">*</span></label>
              <input type="datetime-local" name="start_time" id="bookingStartTime" class="form-control" required onchange="triggerConflictCheck()">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Reservation End <span class="text-danger">*</span></label>
              <input type="datetime-local" name="end_time" id="bookingEndTime" class="form-control" required onchange="triggerConflictCheck()">
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold">Event Purpose &amp; Special Setup Instructions</label>
              <textarea name="purpose" class="form-control" rows="2" placeholder="e.g. Need 4 microphones and projector screen tested prior to event."></textarea>
            </div>
            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conflict_override" value="1" id="conflictOverrideCheck">
                <label class="form-check-label text-muted small" for="conflictOverrideCheck">
                  Override schedule warnings (Administrative priority override)
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" id="submitBookingBtn" class="btn btn-primary px-4">Confirm Reservation</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: New Fixed Asset -->
<div class="modal fade" id="newAssetModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('facilities/assets')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Register Fixed Asset &amp; Depreciation Policy</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="row g-3">
            <div class="col-md-8">
              <label class="form-label fw-semibold">Asset Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="e.g. Sony Bravia 75-inch Interactive Display" required>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Asset Tag Code</label>
              <input type="text" name="asset_tag" class="form-control font-monospace" placeholder="Auto-generated if blank">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Asset Category</label>
              <select name="category" class="form-select">
                <option value="it_hardware">IT Hardware &amp; Computers</option>
                <option value="lab_equipment">Science &amp; Lab Equipment</option>
                <option value="av_multimedia">AV &amp; Multimedia</option>
                <option value="classroom_furniture">Furniture &amp; Fixtures</option>
                <option value="sports_gear">Sports Gear &amp; Gym</option>
                <option value="transport_vehicle">Fleet Vehicles</option>
                <option value="general">General Asset</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Assigned Facility / Lab</label>
              <select name="facility_id" class="form-select">
                <option value="">&mdash; None (General Campus) &mdash;</option>
                <?php foreach ($facilities as $f): ?>
                  <option value="<?= (int)$f['id'] ?>"><?= e($f['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Serial Number</label>
              <input type="text" name="serial_number" class="form-control font-monospace" placeholder="e.g. SN-8849-291X">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Purchase Date</label>
              <input type="date" name="purchase_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Purchase Cost (₹) <span class="text-danger">*</span></label>
              <input type="number" step="0.01" name="purchase_cost" class="form-control" placeholder="0.00" required>
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Salvage Value (₹)</label>
              <input type="number" step="0.01" name="salvage_value" class="form-control" value="0.00">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold">Useful Life (Years)</label>
              <input type="number" name="useful_life_years" class="form-control" value="5" min="1">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Depreciation Method</label>
              <select name="depreciation_method" class="form-select">
                <option value="straight_line">Straight Line (Equal Annual Amortization)</option>
                <option value="reducing_balance">Reducing Balance (Declining Book Value)</option>
                <option value="none">None (Zero Depreciation)</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Initial Operational Status</label>
              <select name="status" class="form-select">
                <option value="in_service">In Service / Active</option>
                <option value="under_maintenance">Under Maintenance</option>
                <option value="decommissioned">Decommissioned</option>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Register Asset</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: Asset Checkout -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" id="checkoutForm" action="">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Check Out Asset: <span id="checkoutAssetName" class="text-primary"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label fw-semibold">Assign Custody To (Staff Member)</label>
            <select name="assigned_to_id" class="form-select">
              <option value="">&mdash; Select Staff Custodian &mdash;</option>
              <?php foreach ($staffMembers as $sm): ?>
                <option value="<?= (int)$sm['id'] ?>"><?= e($sm['name']) ?> (<?= e($sm['role_name']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Custodian / Department Name</label>
            <input type="text" name="assigned_to_name" class="form-control" placeholder="e.g. Science Faculty / John Doe">
          </div>
          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-label fw-semibold">Condition on Dispatch</label>
              <select name="condition_state" class="form-select">
                <option value="excellent">Excellent</option>
                <option value="good" selected>Good</option>
                <option value="fair">Fair</option>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label fw-semibold">Expected Return Date</label>
              <input type="date" name="expected_return_date" class="form-control">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Checkout Notes</label>
            <textarea name="remarks" class="form-control" rows="2" placeholder="e.g. Issued for Term 2 chemistry experiments."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Confirm Checkout</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: Asset Checkin -->
<div class="modal fade" id="checkinModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" id="checkinForm" action="">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Return Asset: <span id="checkinAssetName" class="text-primary"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label fw-semibold">Condition on Return</label>
            <select name="condition_state" class="form-select">
              <option value="excellent">Excellent</option>
              <option value="good" selected>Good</option>
              <option value="fair">Fair</option>
              <option value="damaged">Damaged (Triggers Maintenance Review)</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Return Inspection Notes</label>
            <textarea name="remarks" class="form-control" rows="2" placeholder="Inspection comments upon return..."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success px-4">Receive Back Into Pool</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: New Work Order -->
<div class="modal fade" id="newWorkOrderModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('facilities/work-orders')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Create Maintenance Work Order</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="row g-3">
            <div class="col-md-8">
              <label class="form-label fw-semibold">Issue Title <span class="text-danger">*</span></label>
              <input type="text" name="title" class="form-control" placeholder="e.g. AC cooling unit leaking in Computer Lab A" required>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Priority Level</label>
              <select name="priority" class="form-select">
                <option value="low">Low</option>
                <option value="medium" selected>Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Impacted Facility (Optional)</label>
              <select name="facility_id" class="form-select">
                <option value="">&mdash; None (Campus General) &mdash;</option>
                <?php foreach ($facilities as $f): ?>
                  <option value="<?= (int)$f['id'] ?>"><?= e($f['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Impacted Fixed Asset (Optional)</label>
              <select name="asset_id" class="form-select">
                <option value="">&mdash; None &mdash;</option>
                <?php foreach ($assets as $a): ?>
                  <option value="<?= (int)$a['id'] ?>"><?= e($a['name']) ?> (<?= e($a['asset_tag']) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Category</label>
              <select name="category" class="form-select">
                <option value="electrical">Electrical</option>
                <option value="plumbing">Plumbing</option>
                <option value="hvac">HVAC &amp; Air Conditioning</option>
                <option value="carpentry">Carpentry &amp; Furniture</option>
                <option value="it_hardware">IT &amp; Networking Hardware</option>
                <option value="structural">Structural &amp; Civil</option>
                <option value="general" selected>General Repairs</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Assigned Technician / Vendor</label>
              <input type="text" name="assigned_technician" class="form-control" placeholder="e.g. Apex Facilities Ltd">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold">Technician Phone</label>
              <input type="text" name="technician_phone" class="form-control" placeholder="+91 98765 43210">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Estimated Repair Cost (₹)</label>
              <input type="number" step="0.01" name="estimated_cost" class="form-control" value="0.00">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Scheduled Date</label>
              <input type="date" name="scheduled_date" class="form-control" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold">Detailed Problem Description</label>
              <textarea name="description" class="form-control" rows="2" placeholder="Details of the fault or maintenance task..."></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Dispatch Work Order</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: Update Work Order -->
<div class="modal fade" id="updateWoModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" id="updateWoForm" action="">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3">
          <h5 class="modal-title fw-bold">Update Work Order: <span id="updateWoTitle" class="text-primary"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label fw-semibold">Progress Status</label>
            <select name="status" id="updateWoStatus" class="form-select">
              <option value="open">Open</option>
              <option value="in_progress">In Progress</option>
              <option value="on_hold">On Hold</option>
              <option value="completed">Completed / Resolved</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Actual Incurred Cost (₹)</label>
            <input type="number" step="0.01" name="actual_cost" id="updateWoActualCost" class="form-control" value="0.00">
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Resolution Notes</label>
            <textarea name="resolution_notes" class="form-control" rows="3" placeholder="Describe actions taken to resolve the issue..."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top p-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Save Updates</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openReserveModal(facId, facName) {
  const select = document.getElementById('bookingFacilitySelect');
  if (select) {
    select.value = facId;
  }
  const modal = new bootstrap.Modal(document.getElementById('newBookingModal'));
  modal.show();
}

function openCheckoutModal(assetId, assetName) {
  document.getElementById('checkoutAssetName').textContent = assetName;
  document.getElementById('checkoutForm').action = '<?= e(url('facilities/assets/')) ?>' + assetId + '/checkout';
  const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
  modal.show();
}

function openCheckinModal(assetId, assetName) {
  document.getElementById('checkinAssetName').textContent = assetName;
  document.getElementById('checkinForm').action = '<?= e(url('facilities/assets/')) ?>' + assetId + '/checkin';
  const modal = new bootstrap.Modal(document.getElementById('checkinModal'));
  modal.show();
}

function openUpdateWoModal(woId, title, status, cost) {
  document.getElementById('updateWoTitle').textContent = title;
  document.getElementById('updateWoStatus').value = status;
  document.getElementById('updateWoActualCost').value = cost;
  document.getElementById('updateWoForm').action = '<?= e(url('facilities/work-orders/')) ?>' + woId + '/update';
  const modal = new bootstrap.Modal(document.getElementById('updateWoModal'));
  modal.show();
}

function triggerConflictCheck() {
  const facId = document.getElementById('bookingFacilitySelect')?.value;
  const start = document.getElementById('bookingStartTime')?.value;
  const end = document.getElementById('bookingEndTime')?.value;
  const alertBox = document.getElementById('bookingConflictAlert');
  const alertMsg = document.getElementById('bookingConflictMessage');

  if (!facId || !start || !end) {
    alertBox?.classList.add('d-none');
    return;
  }

  fetch('<?= e(url('facilities/check-conflict')) ?>?facility_id=' + encodeURIComponent(facId) + '&start_time=' + encodeURIComponent(start) + '&end_time=' + encodeURIComponent(end))
    .then(r => r.json())
    .then(data => {
      if (data.conflict) {
        alertMsg.textContent = data.message;
        alertBox.classList.remove('d-none');
      } else {
        alertBox.classList.add('d-none');
      }
    })
    .catch(() => {});
}
</script>
