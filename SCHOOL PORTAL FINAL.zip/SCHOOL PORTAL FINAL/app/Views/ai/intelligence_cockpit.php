<?php
$title = 'AI Intelligence, Predictive Analytics & Smart Assistant Cockpit';
$telemetry = $telemetry ?? [];
$anomalies = $anomalies ?? [];
$feeForecast = $feeForecast ?? [];
$attendanceRisk = $attendanceRisk ?? [];
$connectivity = $connectivity ?? [];

$monthlyQuota = (int) ($telemetry['tenant_settings']['monthly_token_quota'] ?? 500000);
$totalTokens = (int) ($telemetry['total_tokens'] ?? 0);
$quotaPct = $monthlyQuota > 0 ? min(100.0, round(($totalTokens / $monthlyQuota) * 100, 1)) : 0.0;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="bot" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Phase 66 Native Engine
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Institutional RAG intelligence, predictive analytics with explicit uncertainty labeling, operational anomaly alerts, and productivity drafts.
    </p>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <button type="button" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1 shadow-sm" onclick="testAiConnectivity()">
      <i data-lucide="activity" style="width: 14px; height: 14px;"></i>
      <span>Test Provider API</span>
    </button>
    <a href="#report-section" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" onclick="switchTab('reports-tab')">
      <i data-lucide="file-text" style="width: 14px; height: 14px;"></i>
      <span>Generate AI Report</span>
    </a>
  </div>
</div>

<!-- AI Telemetry Top KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100 rounded-3">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Active AI Provider</span>
          <span class="badge <?= ($connectivity['reachable'] ?? false) ? 'bg-success' : 'bg-warning text-dark' ?> rounded-pill small">
            <?= ($connectivity['reachable'] ?? false) ? 'Connected' : 'Offline / Fallback' ?>
          </span>
        </div>
        <div class="h5 fw-bold mb-1 text-dark text-capitalize">
          <?= e($connectivity['provider'] ?? 'gemini') ?>
        </div>
        <div class="text-muted small d-flex justify-content-between">
          <span>Model: <?= e($connectivity['model'] ?? 'gemini-1.5-flash') ?></span>
          <span><?= ($connectivity['latency_ms'] ?? 0) > 0 ? e($connectivity['latency_ms']) . 'ms' : 'Local RAG' ?></span>
        </div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100 rounded-3">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Token Quota Utilization</span>
          <span class="text-primary small fw-semibold"><?= $quotaPct ?>%</span>
        </div>
        <div class="h5 fw-bold mb-1 text-dark">
          <?= number_format($totalTokens) ?> / <?= number_format($monthlyQuota) ?>
        </div>
        <div class="progress" style="height: 6px;">
          <div class="progress-bar <?= $quotaPct > 80 ? 'bg-danger' : ($quotaPct > 50 ? 'bg-warning' : 'bg-primary') ?>" role="progressbar" style="width: <?= $quotaPct ?>%"></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100 rounded-3">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Smart Operational Anomalies</span>
          <span class="badge bg-danger rounded-pill"><?= count($anomalies) ?></span>
        </div>
        <div class="h5 fw-bold mb-1 text-dark">
          <?= count($anomalies) ?> Active Flags
        </div>
        <div class="text-muted small">
          Attendance drops, overdue fees &amp; schedule checks
        </div>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100 rounded-3">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium">Estimated Token Cost</span>
          <span class="badge bg-info-subtle text-info rounded-pill">Usage Billing</span>
        </div>
        <div class="h5 fw-bold mb-1 text-success">
          $<?= number_format((float) ($telemetry['total_cost_usd'] ?? 0.0), 4) ?>
        </div>
        <div class="text-muted small">
          <?= number_format((int) ($telemetry['total_requests'] ?? 0)) ?> total prompt inferences
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Main Tabs -->
<ul class="nav nav-tabs nav-fill mb-4 bg-white p-2 rounded-3 shadow-sm border-0" id="aiCockpitTabs" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active fw-semibold d-flex align-items-center justify-content-center gap-2 py-2" id="insights-tab" data-bs-toggle="tab" data-bs-target="#tab-insights" type="button" role="tab">
      <i data-lucide="alert-triangle" style="width: 16px; height: 16px;"></i>
      <span>Smart Insights (<?= count($anomalies) ?>)</span>
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link fw-semibold d-flex align-items-center justify-content-center gap-2 py-2" id="predictive-tab" data-bs-toggle="tab" data-bs-target="#tab-predictive" type="button" role="tab">
      <i data-lucide="trending-up" style="width: 16px; height: 16px;"></i>
      <span>Predictive Analytics</span>
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link fw-semibold d-flex align-items-center justify-content-center gap-2 py-2" id="reports-tab" data-bs-toggle="tab" data-bs-target="#tab-reports" type="button" role="tab">
      <i data-lucide="file-text" style="width: 16px; height: 16px;"></i>
      <span>Natural-Language Reports</span>
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link fw-semibold d-flex align-items-center justify-content-center gap-2 py-2" id="productivity-tab" data-bs-toggle="tab" data-bs-target="#tab-productivity" type="button" role="tab">
      <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
      <span>AI Productivity Suite</span>
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link fw-semibold d-flex align-items-center justify-content-center gap-2 py-2" id="privacy-tab" data-bs-toggle="tab" data-bs-target="#tab-privacy" type="button" role="tab">
      <i data-lucide="shield-check" style="width: 16px; height: 16px;"></i>
      <span>Privacy &amp; Telemetry</span>
    </button>
  </li>
</ul>

<div class="tab-content" id="aiCockpitTabContent">
  <!-- Tab 1: Smart Insights & Operational Anomalies -->
  <div class="tab-pane fade show active" id="tab-insights" role="tabpanel">
    <div class="card border-0 shadow-sm rounded-3 mb-4">
      <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
        <div>
          <h5 class="fw-bold mb-0 text-dark">Real-Time Operational Anomalies &amp; Bottlenecks</h5>
          <p class="text-muted small mb-0">Continuously monitored using verified institutional ledger and attendance records.</p>
        </div>
        <button type="button" class="btn btn-sm btn-outline-primary" onclick="refreshInsights()">
          <i data-lucide="refresh-cw" style="width: 14px; height: 14px;" class="me-1"></i> Re-Scan
        </button>
      </div>
      <div class="card-body p-4 pt-1">
        <?php if (empty($anomalies)): ?>
          <div class="alert alert-success border-0 d-flex align-items-center gap-3 py-3 mb-0">
            <i data-lucide="check-circle" class="text-success" style="width: 28px; height: 28px;"></i>
            <div>
              <div class="fw-bold">No Operational Anomalies Detected</div>
              <div class="small text-muted">Attendance registers, timetable schedules, and fee collections are operating within standard tolerance levels.</div>
            </div>
          </div>
        <?php else: ?>
          <div class="d-flex flex-column gap-3">
            <?php foreach ($anomalies as $a): 
              $sev = $a['severity'] ?? 'info';
              $badgeClass = match($sev) {
                'critical' => 'bg-danger text-white',
                'warning' => 'bg-warning text-dark',
                default => 'bg-info text-white'
              };
            ?>
              <div class="p-3 rounded-3 border d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 bg-light-subtle">
                <div>
                  <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="badge <?= $badgeClass ?> text-uppercase fw-bold" style="font-size: 0.7rem;"><?= e($sev) ?></span>
                    <span class="fw-bold text-dark"><?= e($a['title']) ?></span>
                  </div>
                  <p class="text-muted small mb-1"><?= e($a['description']) ?></p>
                  <div class="small text-primary fw-medium">
                    <i data-lucide="arrow-right-circle" style="width: 14px; height: 14px;" class="me-1"></i>
                    <strong>Action:</strong> <?= e($a['action_recommendation']) ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Tab 2: Predictive Analytics Radar -->
  <div class="tab-pane fade" id="tab-predictive" role="tabpanel">
    <!-- Mandatory Disclaimer Banner -->
    <div class="alert alert-warning border border-warning-subtle d-flex align-items-start gap-3 py-3 mb-4 rounded-3 shadow-sm">
      <i data-lucide="alert-circle" class="text-warning flex-shrink-0 mt-1" style="width: 22px; height: 22px;"></i>
      <div>
        <div class="fw-bold text-dark mb-1">⚠️ [PREDICTIVE_ESTIMATE] Mandatory Uncertainty Notice</div>
        <div class="small text-muted">
          All analytical projections, velocity estimates, and dropout risks displayed in this module are statistical calculations derived from historical trend algorithms. 
          They are <strong>projections for strategic planning, never factual guarantees</strong>. They do not factor in unrecorded medical leaves, external macroeconomic shifts, or sudden family relocations.
        </div>
      </div>
    </div>

    <div class="row g-4">
      <!-- 30-Day Fee Collection Projection -->
      <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 h-100">
          <div class="card-header bg-white border-0 py-3">
            <div class="d-flex align-items-center justify-content-between">
              <h6 class="fw-bold mb-0 text-dark">💳 Fee Collection Velocity Forecast (30-Day)</h6>
              <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                Confidence: <?= $feeForecast['confidence_pct'] ?? 0 ?>%
              </span>
            </div>
          </div>
          <div class="card-body p-4 pt-1">
            <?php if (!($feeForecast['sufficient_data'] ?? false)): ?>
              <div class="alert alert-secondary border-0 small mb-0">
                <strong><?= e($feeForecast['badge'] ?? '[DATA_SPARSE_WARNING]') ?>:</strong>
                <?= e($feeForecast['message'] ?? 'Insufficient transaction history.') ?>
              </div>
            <?php else: ?>
              <div class="d-flex align-items-baseline gap-2 mb-2">
                <span class="h3 fw-bold text-success mb-0">$<?= number_format((float) ($feeForecast['projected_amount'] ?? 0.0), 2) ?></span>
                <span class="text-muted small">projected collections</span>
              </div>
              <p class="text-muted small mb-3"><?= e($feeForecast['explanation'] ?? '') ?></p>
              <div class="p-3 bg-light rounded-3 small">
                <div class="fw-bold text-dark mb-1">Algorithmic Limitations:</div>
                <ul class="mb-0 ps-3 text-muted">
                  <?php foreach (($feeForecast['limitations'] ?? []) as $lim): ?>
                    <li><?= e($lim) ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Student Attendance Retention Risk Radar -->
      <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 h-100">
          <div class="card-header bg-white border-0 py-3">
            <div class="d-flex align-items-center justify-content-between">
              <h6 class="fw-bold mb-0 text-dark">📅 Attendance Retention Risk Cohorts</h6>
              <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                Statutory 75% Threshold
              </span>
            </div>
          </div>
          <div class="card-body p-4 pt-1">
            <?php if (!($attendanceRisk['sufficient_data'] ?? false)): ?>
              <div class="alert alert-secondary border-0 small mb-0">
                <strong><?= e($attendanceRisk['badge'] ?? '[DATA_SPARSE_WARNING]') ?>:</strong>
                <?= e($attendanceRisk['message'] ?? 'Insufficient longitudinal attendance logs.') ?>
              </div>
            <?php elseif (empty($attendanceRisk['at_risk_students'])): ?>
              <div class="alert alert-success border-0 small mb-0">
                ✅ No student cohorts are currently trending below the 75% attendance threshold.
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                  <thead class="table-light small">
                    <tr>
                      <th>Student</th>
                      <th>Class</th>
                      <th>Current Rate</th>
                      <th>Risk Probability</th>
                    </tr>
                  </thead>
                  <tbody class="small">
                    <?php foreach ($attendanceRisk['at_risk_students'] as $s): ?>
                      <tr>
                        <td class="fw-bold"><?= e($s['name']) ?></td>
                        <td><?= e($s['class']) ?></td>
                        <td><span class="badge bg-warning text-dark"><?= e($s['current_rate']) ?>%</span></td>
                        <td><span class="text-danger fw-bold"><?= e($s['projected_risk_score']) ?>%</span></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tab 3: Natural-Language Report Generator Desk -->
  <div class="tab-pane fade" id="tab-reports" role="tabpanel">
    <div class="card border-0 shadow-sm rounded-3 mb-4">
      <div class="card-header bg-white border-0 py-3">
        <h5 class="fw-bold mb-0 text-dark">Natural-Language Report Synthesis Desk</h5>
        <p class="text-muted small mb-0">Request institutional summaries in plain English. The engine executes verified SQL calculations and formats executive statements.</p>
      </div>
      <div class="card-body p-4 pt-1">
        <!-- Quick Prompt Chips -->
        <div class="d-flex flex-wrap gap-2 mb-3">
          <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="askReport('Show attendance trends for the last 30 days')">
            📊 Attendance Trends
          </button>
          <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="askReport('Summarize fee collections and overdue arrears')">
            💳 Fee Collection Audit
          </button>
          <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="askReport('Show student admissions and demographic breakdown')">
            🎓 Admissions Census
          </button>
          <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="askReport('Analyze recent academic examination performance')">
            📝 Exam Performance
          </button>
          <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="askReport('List pending operational tasks and unsubmitted registers')">
            📋 Operational Backlog
          </button>
        </div>

        <div class="input-group mb-3">
          <input type="text" id="reportPromptInput" class="form-control" placeholder="Ask a report question (e.g. 'Summarize our fee collection and overdue arrears')...">
          <button class="btn btn-primary d-flex align-items-center gap-1" type="button" id="btnRunReport" onclick="submitReportRequest()">
            <i data-lucide="play" style="width: 14px; height: 14px;"></i>
            <span>Generate Report</span>
          </button>
        </div>

        <!-- Output Pane -->
        <div id="reportOutputCard" class="p-4 border rounded-3 bg-light d-none">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1">
              [VERIFIED_STATISTICS] Institutional Ledger Output
            </span>
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="printReportOutput()">
              <i data-lucide="printer" style="width: 14px; height: 14px;" class="me-1"></i> Print Report
            </button>
          </div>
          <div id="reportOutputContent" class="markdown-body bg-white p-3 rounded-2 border"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tab 4: AI Productivity Suite -->
  <div class="tab-pane fade" id="tab-productivity" role="tabpanel">
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 h-100">
          <div class="card-header bg-white border-0 py-3">
            <h6 class="fw-bold mb-0 text-dark">📢 Draft Institutional Announcement</h6>
            <p class="text-muted small mb-0">Generate formal circulars for parents, faculty, or students with one click.</p>
          </div>
          <div class="card-body p-4 pt-1">
            <div class="mb-3">
              <label class="form-label small fw-bold">Notice Type</label>
              <select id="draftType" class="form-select form-select-sm">
                <option value="holiday">Holiday / Weather Closure</option>
                <option value="ptm">Parent-Teacher Meeting (PTM)</option>
                <option value="fees">Tuition Fee Due Reminder</option>
                <option value="general">General Administrative Circular</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label small fw-bold">Topic / Occasion</label>
              <input type="text" id="draftTopic" class="form-control form-control-sm" placeholder="e.g. National Day Holiday / Term 1 PTM" value="Term Consultation">
            </div>
            <div class="mb-3">
              <label class="form-label small fw-bold">Target Audience</label>
              <select id="draftAudience" class="form-select form-select-sm">
                <option value="parents">Parents &amp; Guardians</option>
                <option value="students">Students</option>
                <option value="teachers">Faculty &amp; Staff</option>
                <option value="all" selected>Entire School Community</option>
              </select>
            </div>
            <button type="button" class="btn btn-primary btn-sm w-100" onclick="generateDraft()">
              <i data-lucide="sparkles" style="width: 14px; height: 14px;" class="me-1"></i> Draft Circular
            </button>

            <div id="draftResultBox" class="mt-3 p-3 bg-light rounded-3 border d-none">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="small fw-bold text-dark" id="draftResultTitle">Notice Draft</span>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="copyDraft()">Copy Text</button>
              </div>
              <textarea id="draftResultText" class="form-control font-monospace small" rows="8" readonly></textarea>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 h-100">
          <div class="card-header bg-white border-0 py-3">
            <h6 class="fw-bold mb-0 text-dark">🧭 Interactive Workflow Guides</h6>
            <p class="text-muted small mb-0">Step-by-step procedures for complex administrative workflows.</p>
          </div>
          <div class="card-body p-4 pt-1">
            <div class="mb-3">
              <label class="form-label small fw-bold">Select Workflow</label>
              <select id="workflowKey" class="form-select form-select-sm" onchange="loadWorkflowGuide()">
                <option value="fee_concession">Fee Concessions &amp; Scholarships</option>
                <option value="student_promotion">End-of-Year Student Promotion &amp; Rollover</option>
              </select>
            </div>
            <div id="workflowGuideBox" class="p-3 bg-light rounded-3 border small">
              <div class="fw-bold text-dark mb-2" id="wfTitle">Fee Concessions &amp; Scholarships</div>
              <ol class="ps-3 mb-0 text-muted" id="wfSteps">
                <li>Navigate to **Finance > Concessions** in the main navigation menu.</li>
                <li>Click the **+ Grant Concession** button in the top right.</li>
                <li>Select the target student from the search autocomplete.</li>
                <li>Choose the Fee Category (e.g. Tuition Fee, Transport).</li>
                <li>Choose the adjustment type: Percentage (%) or Fixed Amount ($).</li>
                <li>Enter the concession value and the official justification reason.</li>
                <li>Click **Save Concession**. The discount will automatically apply to future invoice runs.</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tab 5: Privacy, Secret Management & Telemetry -->
  <div class="tab-pane fade" id="tab-privacy" role="tabpanel">
    <div class="card border-0 shadow-sm rounded-3 mb-4">
      <div class="card-header bg-white border-0 py-3">
        <h5 class="fw-bold mb-0 text-dark">Zero-Trust Privacy, Secret Management &amp; Retention Controls</h5>
        <p class="text-muted small mb-0">Enforcing strict tenant isolation, PII scrubbing, secret redaction, and conversation lifecycles.</p>
      </div>
      <div class="card-body p-4 pt-1">
        <div class="row g-4">
          <div class="col-md-6">
            <h6 class="fw-bold text-dark mb-2">🔒 Privacy Guardrails Enforced</h6>
            <ul class="list-group list-group-flush small mb-3">
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span>PII Redaction (Phone, Credit Cards, CNIC/SSN, Emails)</span>
                <span class="badge bg-success">Active</span>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span>Multi-Tenant Memory Boundary Validation</span>
                <span class="badge bg-success">Enforced</span>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span>Secret API Key Masking in Diagnostic Strings</span>
                <span class="badge bg-success">Active</span>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span>Response Caching for Token Optimization</span>
                <span class="badge bg-primary">Enabled</span>
              </li>
            </ul>
          </div>

          <div class="col-md-6">
            <h6 class="fw-bold text-dark mb-2">🗑️ Conversation Retention Purge</h6>
            <p class="text-muted small">
              Permanently delete conversation records older than the configured threshold to adhere to privacy mandates.
            </p>
            <div class="input-group input-group-sm mb-3">
              <span class="input-group-text">Retention Window</span>
              <input type="number" id="retentionDaysInput" class="form-control" value="30" min="7" max="365">
              <span class="input-group-text">days</span>
              <button class="btn btn-outline-danger" type="button" onclick="purgeRetentionLogs()">Purge Expired</button>
            </div>
            <div id="purgeResultMsg" class="small text-muted"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function switchTab(tabId) {
  const triggerEl = document.getElementById(tabId);
  if (triggerEl) {
    const tab = new bootstrap.Tab(triggerEl);
    tab.show();
  }
}

function askReport(query) {
  document.getElementById('reportPromptInput').value = query;
  submitReportRequest();
}

function submitReportRequest() {
  const input = document.getElementById('reportPromptInput');
  const query = input.value.trim();
  if (!query) return;

  const btn = document.getElementById('btnRunReport');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Synthesizing...';

  const outputCard = document.getElementById('reportOutputCard');
  const outputContent = document.getElementById('reportOutputContent');

  fetch('<?= e(url('api/ai/reports/generate')) ?>', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: query })
  })
  .then(res => res.json())
  .then(data => {
    btn.disabled = false;
    btn.innerHTML = '<i data-lucide="play" style="width: 14px; height: 14px;"></i><span>Generate Report</span>';
    outputCard.classList.remove('d-none');
    outputContent.innerHTML = formatMarkdownToHtml(data.content || 'No content generated.');
    if (window.lucide) lucide.createIcons();
  })
  .catch(err => {
    btn.disabled = false;
    btn.innerHTML = '<i data-lucide="play" style="width: 14px; height: 14px;"></i><span>Generate Report</span>';
    alert('Report generation failed: ' + err.message);
  });
}

function formatMarkdownToHtml(md) {
  // Simple markdown renderer for headers, tables, bold, and bullet points
  let html = md
    .replace(/^### (.*$)/gim, '<h4 class="fw-bold text-dark mt-3 mb-2">$1</h4>')
    .replace(/^#### (.*$)/gim, '<h5 class="fw-bold text-dark mt-3 mb-2">$1</h5>')
    .replace(/^##### (.*$)/gim, '<h6 class="fw-bold text-dark mt-2 mb-1">$1</h6>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code class="bg-light text-primary px-1 rounded">$1</code>')
    .replace(/^\> \[!WARNING\]\n\> (.*$)/gim, '<div class="alert alert-warning py-2 small mb-2">$1</div>')
    .replace(/^\> \[!NOTE\]\n\> (.*$)/gim, '<div class="alert alert-info py-2 small mb-2">$1</div>')
    .replace(/^\- (.*$)/gim, '<li class="mb-1">$1</li>')
    .replace(/\n\n/g, '<br>');

  // Format tables
  if (html.includes('|')) {
    const lines = html.split('<br>');
    let inTable = false;
    let tableHtml = '<div class="table-responsive"><table class="table table-bordered table-sm my-2">';
    let result = [];

    for (let line of lines) {
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        if (!inTable) {
          inTable = true;
          tableHtml = '<div class="table-responsive my-2"><table class="table table-bordered table-sm mb-0"><tbody class="small">';
        }
        if (line.includes('---')) continue; // Skip separator line
        const cols = line.split('|').filter(c => c !== '');
        tableHtml += '<tr>' + cols.map(c => '<td class="p-2">' + c.trim() + '</td>').join('') + '</tr>';
      } else {
        if (inTable) {
          inTable = false;
          tableHtml += '</tbody></table></div>';
          result.push(tableHtml);
        }
        result.push(line);
      }
    }
    if (inTable) {
      tableHtml += '</tbody></table></div>';
      result.push(tableHtml);
    }
    html = result.join('<br>');
  }

  return html;
}

function printReportOutput() {
  const content = document.getElementById('reportOutputContent').innerHTML;
  const printWindow = window.open('', '', 'height=600,width=800');
  printWindow.document.write('<html><head><title>Official Institutional AI Report</title>');
  printWindow.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">');
  printWindow.document.write('</head><body class="p-4">');
  printWindow.document.write(content);
  printWindow.document.write('</body></html>');
  printWindow.document.close();
  printWindow.print();
}

function testAiConnectivity() {
  fetch('<?= e(url('api/ai/provider/test')) ?>', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  })
  .then(res => res.json())
  .then(data => {
    const r = data.result || {};
    alert(r.message || 'Connectivity check completed.');
  })
  .catch(err => alert('Connectivity test error: ' + err.message));
}

function refreshInsights() {
  fetch('<?= e(url('api/ai/insights')) ?>')
  .then(res => res.json())
  .then(data => {
    alert('Anomaly scan refreshed. Found ' + (data.total_anomalies || 0) + ' active flags.');
    location.reload();
  })
  .catch(err => alert('Re-scan error: ' + err.message));
}

function generateDraft() {
  const type = document.getElementById('draftType').value;
  const topic = document.getElementById('draftTopic').value;
  const audience = document.getElementById('draftAudience').value;

  fetch('<?= e(url('api/ai/productivity/draft')) ?>', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: type, topic: topic, target_audience: audience })
  })
  .then(res => res.json())
  .then(data => {
    const draft = data.draft || {};
    document.getElementById('draftResultBox').classList.remove('d-none');
    document.getElementById('draftResultTitle').textContent = draft.title || 'Circular Draft';
    document.getElementById('draftResultText').value = draft.content || '';
  })
  .catch(err => alert('Drafting error: ' + err.message));
}

function copyDraft() {
  const text = document.getElementById('draftResultText').value;
  navigator.clipboard.writeText(text);
  alert('Circular draft copied to clipboard!');
}

function purgeRetentionLogs() {
  const days = document.getElementById('retentionDaysInput').value;
  if (!confirm('Are you sure you want to permanently purge AI chat logs older than ' + days + ' days?')) return;

  fetch('<?= e(url('api/ai/privacy/purge')) ?>', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ retention_days: days })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('purgeResultMsg').textContent = data.message || 'Retention purge completed.';
  })
  .catch(err => alert('Purge error: ' + err.message));
}
</script>
