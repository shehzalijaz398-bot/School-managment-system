<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #fff; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:15px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
  .sa-stat-icon { width:48px; height:48px; border-radius:12px; display:flex; justify-content:center; align-items:center; }
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.8rem; font-weight: 800; color: var(--sa-text); line-height: 1; margin-top:5px; }

  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .severity-info { color: #3b82f6; background: #eff6ff; }
  .severity-warning { color: #b45309; background: #fef3c7; }
  .severity-high { color: #c2410c; background: #ffedd5; }
  .severity-critical { color: #b91c1c; background: #fef2f2; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Activity & Audit Logs</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Central security monitoring and immutable audit trails.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('superadmin/audit/export')) ?>" class="btn btn-dark fw-bold" style="border-radius:8px;"><i data-lucide="download" style="width:16px;height:16px;"></i> Export Audit CSV</a>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon severity-info"><i data-lucide="list"></i></div>
        <div><div class="sa-stat-label">Total Events</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon" style="background:#f1f5f9; color:#475569;"><i data-lucide="calendar"></i></div>
        <div><div class="sa-stat-label">Today's Events</div><div class="sa-stat-val"><?= number_format($analytics['today']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon severity-warning"><i data-lucide="shield"></i></div>
        <div><div class="sa-stat-label">Security Logs</div><div class="sa-stat-val"><?= number_format($analytics['security']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon severity-critical"><i data-lucide="alert-triangle"></i></div>
        <div><div class="sa-stat-label">Critical Actions</div><div class="sa-stat-val"><?= number_format($analytics['critical']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/audit')) ?>" class="row g-2 align-items-end">
            <div class="col-md-2">
                <label class="form-label small fw-bold">Tenant / School</label>
                <select name="school_id" class="form-select form-select-sm">
                    <option value="">All Schools</option>
                    <?php foreach($schools ?? [] as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= ($filters['school_id']??'')==$s['id']?'selected':'' ?>><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">User</label>
                <select name="user_id" class="form-select form-select-sm">
                    <option value="">All Users</option>
                    <?php foreach($users as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= ($filters['user_id']??'')==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">Module</label>
                <select name="module" class="form-select form-select-sm">
                    <option value="">All Modules</option>
                    <option value="auth" <?= ($filters['module']??'')=='auth'?'selected':'' ?>>Authentication</option>
                    <option value="security" <?= ($filters['module']??'')=='security'?'selected':'' ?>>Security</option>
                    <option value="schools" <?= ($filters['module']??'')=='schools'?'selected':'' ?>>Schools</option>
                    <option value="billing" <?= ($filters['module']??'')=='billing'?'selected':'' ?>>Billing</option>
                    <option value="platform_users" <?= ($filters['module']??'')=='platform_users'?'selected':'' ?>>Users</option>
                    <option value="announcements" <?= ($filters['module']??'')=='announcements'?'selected':'' ?>>Announcements</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">Severity</label>
                <select name="severity" class="form-select form-select-sm">
                    <option value="">All</option>
                    <option value="info" <?= ($filters['severity']??'')=='info'?'selected':'' ?>>Info</option>
                    <option value="warning" <?= ($filters['severity']??'')=='warning'?'selected':'' ?>>Warning</option>
                    <option value="high" <?= ($filters['severity']??'')=='high'?'selected':'' ?>>High</option>
                    <option value="critical" <?= ($filters['severity']??'')=='critical'?'selected':'' ?>>Critical</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">From</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?= e($filters['date_from']??'') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">To</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?= e($filters['date_to']??'') ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark btn-sm w-100 fw-bold">Search</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Timestamp</th>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Module / Target</th>
                    <th>Severity</th>
                    <th>IP Address</th>
                    <th class="text-end pe-4">Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($logs as $log): ?>
                <tr>
                    <td class="ps-4 fw-bold text-muted" style="font-size:0.85rem;">
                        <?= date('M d, Y H:i:s', strtotime($log['created_at'])) ?>
                    </td>
                    <td>
                        <div class="fw-bold"><?= e($log['actor_name'] ?: ($log['actor_id'] ? 'System/SchoolUser#'.$log['actor_id'] : 'System')) ?></div>
                        <div class="small text-muted text-uppercase" style="font-size:0.7rem;"><?= e($log['actor_type']) ?></div>
                    </td>
                    <td class="fw-bold"><?= e(str_replace('_', ' ', $log['action'])) ?></td>
                    <td>
                        <span class="badge bg-light text-dark border"><?= e($log['module']) ?></span>
                        <?php if(!empty($log['school_name'])): ?>
                            <div class="small text-primary fw-semibold mt-1"><i data-lucide="building" style="width:12px;height:12px;"></i> <?= e($log['school_name']) ?></div>
                        <?php endif; ?>
                        <?php if($log['entity_type']): ?>
                            <div class="small text-muted mt-1"><?= e($log['entity_type']) ?> #<?= $log['entity_id'] ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php $sev = $log['severity'] ?? 'info'; ?>
                        <span class="badge severity-<?= $sev ?> border text-uppercase" style="border-color: currentColor !important;">
                            <?= e($sev) ?>
                        </span>
                    </td>
                    <td class="small font-monospace text-muted"><?= e($log['ip_address'] ?? '-') ?></td>
                    <td class="text-end pe-4">
                        <button class="btn btn-light btn-sm fw-bold" onclick="viewAuditDetails(<?= htmlspecialchars(json_encode([
                            'id' => $log['id'],
                            'timestamp' => $log['created_at'],
                            'actor' => $log['actor_name'] ?: 'System',
                            'type' => $log['actor_type'],
                            'action' => $log['action'],
                            'module' => $log['module'],
                            'ip' => $log['ip_address'],
                            'agent' => $log['user_agent'],
                            'old' => $log['old_values'] ? json_decode($log['old_values']) : null,
                            'new' => $log['new_values'] ? json_decode($log['new_values']) : null
                        ])) ?>)">View</button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($logs)): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No audit logs match your criteria.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Audit Detail Modal -->
<div class="modal fade" id="auditDetailModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius:12px; border:none; box-shadow:0 10px 30px rgba(0,0,0,0.1);">
      <div class="modal-header border-bottom-0 pb-0 bg-light rounded-top">
        <h5 class="modal-title fw-bold">Audit Event Detail</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body bg-light">
          <div class="row g-3 mb-4">
              <div class="col-md-6">
                  <div class="sa-card mb-0 p-3 h-100">
                      <h6 class="fw-bold text-muted small text-uppercase mb-2">Event Information</h6>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">Event ID:</strong> <span id="ad_id" class="font-monospace"></span></div>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">Timestamp:</strong> <span id="ad_time"></span></div>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">Module:</strong> <span id="ad_module" class="badge bg-dark"></span></div>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">Action:</strong> <span id="ad_action" class="fw-bold text-primary"></span></div>
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="sa-card mb-0 p-3 h-100">
                      <h6 class="fw-bold text-muted small text-uppercase mb-2">Actor & Security</h6>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">Actor:</strong> <span id="ad_actor"></span> <span id="ad_type" class="badge bg-secondary ms-1"></span></div>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">IP Address:</strong> <span id="ad_ip" class="font-monospace text-muted"></span></div>
                      <div class="mb-1"><strong style="width:100px;display:inline-block;">User Agent:</strong></div>
                      <div id="ad_agent" class="small text-muted" style="word-break:break-all; line-height:1.2;"></div>
                  </div>
              </div>
          </div>
          
          <div class="sa-card mb-0 p-3" id="ad_diff_container" style="display:none;">
              <h6 class="fw-bold text-muted small text-uppercase mb-3">Data Mutations (Before & After)</h6>
              <div class="row">
                  <div class="col-md-6 border-end">
                      <div class="fw-bold text-danger mb-2">Before (Old Values)</div>
                      <pre id="ad_old" class="p-2 bg-white rounded border small" style="white-space:pre-wrap;"></pre>
                  </div>
                  <div class="col-md-6">
                      <div class="fw-bold text-success mb-2">After (New Values)</div>
                      <pre id="ad_new" class="p-2 bg-white rounded border small" style="white-space:pre-wrap;"></pre>
                  </div>
              </div>
          </div>
      </div>
      <div class="modal-footer border-top-0 pt-0 bg-light rounded-bottom">
        <button type="button" class="btn btn-dark fw-bold px-4" style="border-radius:8px;" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
function viewAuditDetails(data) {
    document.getElementById('ad_id').innerText = data.id;
    document.getElementById('ad_time').innerText = data.timestamp;
    document.getElementById('ad_module').innerText = data.module.toUpperCase();
    document.getElementById('ad_action').innerText = data.action;
    
    document.getElementById('ad_actor').innerText = data.actor;
    document.getElementById('ad_type').innerText = data.type;
    document.getElementById('ad_ip').innerText = data.ip || 'Unknown';
    document.getElementById('ad_agent').innerText = data.agent || 'Unknown';
    
    const diffContainer = document.getElementById('ad_diff_container');
    if (data.old || data.new) {
        diffContainer.style.display = 'block';
        document.getElementById('ad_old').innerText = data.old ? JSON.stringify(data.old, null, 2) : 'N/A';
        document.getElementById('ad_new').innerText = data.new ? JSON.stringify(data.new, null, 2) : 'N/A';
    } else {
        diffContainer.style.display = 'none';
    }
    
    new bootstrap.Modal(document.getElementById('auditDetailModal')).show();
}
</script>
