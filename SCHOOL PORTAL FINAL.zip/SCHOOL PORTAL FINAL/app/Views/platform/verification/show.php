<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  
  .badge-status-not_submitted { background: #f1f5f9; color: #475569; }
  .badge-status-pending { background: #fef3c7; color: #b45309; }
  .badge-status-pending_review { background: #fef3c7; color: #b45309; }
  .badge-status-under_review { background: #dbeafe; color: #1e40af; }
  .badge-status-verified, .badge-status-approved { background: #dcfce7; color: #166534; }
  .badge-status-rejected { background: #fee2e2; color: #991b1b; }
  
  .doc-card { border: 1px solid var(--sa-border); border-radius: 12px; margin-bottom: 15px; background: white; transition: all 0.2s; }
  .doc-card:hover { border-color: #cbd5e1; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
  .doc-header { padding: 15px 20px; border-bottom: 1px solid var(--sa-border); display:flex; justify-content:space-between; align-items:center; background:#f8fafc; border-radius: 12px 12px 0 0; }
  .doc-body { padding: 20px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Verification Profile</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Review documents and verify the legitimacy of <strong class="text-dark"><?= e($school['name']) ?></strong>.</p>
  </div>
  <a href="<?= e(url('superadmin/verification')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Verification</a>
</div>

<div class="row">
    <!-- Meta -->
    <div class="col-lg-4">
        <div class="sa-card p-4">
            <h6 class="fw-bold text-muted small text-uppercase mb-4">School Master Record</h6>
            
            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Global Verification Status</div>
                <?php $vStatus = $school['verification_status'] ?: 'not_submitted'; ?>
                <span class="badge badge-status-<?= e($vStatus) ?> border text-uppercase" style="border-color:currentColor!important; padding:6px 12px; font-size:0.8rem;">
                    <?= e(str_replace('_', ' ', $vStatus)) ?>
                </span>
            </div>
            
            <form method="post" action="<?= e(url('superadmin/verification/'.$school['id'].'/status')) ?>" class="mb-4 pb-4 border-bottom">
                <?= csrf_field() ?>
                <div class="mb-2 small fw-bold">Update Global Status:</div>
                <div class="input-group">
                    <select name="status" class="form-select form-select-sm fw-bold">
                        <option value="pending_review" <?= $vStatus=='pending_review'?'selected':'' ?>>Pending Review</option>
                        <option value="under_review" <?= $vStatus=='under_review'?'selected':'' ?>>Under Review</option>
                        <option value="verified" <?= $vStatus=='verified'?'selected':'' ?>>Verified</option>
                        <option value="rejected" <?= $vStatus=='rejected'?'selected':'' ?>>Rejected</option>
                    </select>
                    <button type="submit" class="btn btn-dark btn-sm fw-bold">Save</button>
                </div>
            </form>

            <div class="mb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">School Owner</div>
                <div class="fw-bold text-dark"><?= e($school['owner_name'] ?: 'N/A') ?></div>
                <div class="small text-muted"><?= e($school['owner_email'] ?: 'N/A') ?></div>
            </div>

            <div class="mb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Country / Region</div>
                <div class="fw-bold text-dark"><?= e($school['country'] ?: 'Not specified') ?></div>
            </div>
            
            <div class="mb-0">
                <div class="small text-muted fw-bold text-uppercase mb-1">Registered At</div>
                <div class="fw-bold text-dark small"><?= date('M d, Y', strtotime($school['created_at'])) ?></div>
            </div>
        </div>
        
        <div class="sa-card p-4 bg-light">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Required Document Types</h6>
            <ul class="list-unstyled small mb-0">
                <?php foreach($docTypes as $t): ?>
                    <li class="mb-2">
                        <?php if($t['is_required']): ?>
                            <span class="text-danger fw-bold">*</span>
                        <?php endif; ?>
                        <?= e($t['name']) ?> 
                        <?php if($t['requires_expiry']): ?>
                            <span class="badge bg-secondary ms-1" style="font-size:0.6rem;">Expiry Required</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    
    <!-- Documents -->
    <div class="col-lg-8">
        <h5 class="fw-bold mb-4">Submitted Documents</h5>
        
        <?php foreach($documents as $doc): ?>
            <div class="doc-card shadow-sm">
                <div class="doc-header">
                    <div>
                        <div class="fw-bold text-dark" style="font-size:1.05rem;"><?= e($doc['type_name']) ?></div>
                        <div class="small text-muted">Submitted <?= date('M d, Y', strtotime($doc['created_at'])) ?></div>
                    </div>
                    <div>
                        <span class="badge badge-status-<?= e($doc['status']) ?> border text-uppercase" style="border-color:currentColor!important; padding:6px 12px; font-size:0.75rem;">
                            <?= e(str_replace('_', ' ', $doc['status'])) ?>
                        </span>
                    </div>
                </div>
                <div class="doc-body">
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="small text-muted text-uppercase fw-bold mb-1">Document Number</div>
                            <div class="fw-bold text-dark"><?= e($doc['document_number'] ?: 'Not Provided') ?></div>
                        </div>
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="small text-muted text-uppercase fw-bold mb-1">Issue Date</div>
                            <div class="fw-bold text-dark"><?= $doc['issue_date'] ? date('M d, Y', strtotime($doc['issue_date'])) : 'N/A' ?></div>
                        </div>
                        <div class="col-md-4">
                            <div class="small text-muted text-uppercase fw-bold mb-1">Expiry Date</div>
                            <div class="fw-bold text-dark">
                                <?php if($doc['expiry_date']): ?>
                                    <?php $isExp = strtotime($doc['expiry_date']) < time(); ?>
                                    <span class="<?= $isExp ? 'text-danger' : '' ?>">
                                        <?= date('M d, Y', strtotime($doc['expiry_date'])) ?>
                                        <?= $isExp ? ' (Expired)' : '' ?>
                                    </span>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <a href="<?= e($doc['file_path']) ?>" target="_blank" class="btn btn-outline-primary btn-sm fw-bold px-4" style="border-radius:6px;">
                            <i data-lucide="eye" style="width:16px;height:16px;"></i> Secure View Document
                        </a>
                        <span class="ms-2 small text-muted"><i data-lucide="lock" style="width:12px;height:12px;"></i> Sensitive Data</span>
                    </div>
                    
                    <div class="bg-light p-3 rounded border">
                        <h6 class="fw-bold text-muted small text-uppercase border-bottom pb-2 mb-3">Review Panel</h6>
                        <form method="post" action="<?= e(url('superadmin/verification/'.$school['id'].'/documents/'.$doc['id'].'/review')) ?>">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold small">Action <span class="text-danger">*</span></label>
                                <select name="status" class="form-select fw-bold" required>
                                    <option value="pending" <?= $doc['status']=='pending'?'selected':'' ?>>Keep Pending</option>
                                    <option value="approved" <?= $doc['status']=='approved'?'selected':'' ?>>Approve Document</option>
                                    <option value="rejected" <?= $doc['status']=='rejected'?'selected':'' ?>>Reject Document</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold small">Review Notes / Rejection Reason</label>
                                <textarea name="review_notes" class="form-control" rows="2" placeholder="Will be shown to the school if rejected..."><?= e($doc['review_notes']) ?></textarea>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="small text-muted">
                                    <?php if($doc['reviewed_by']): ?>
                                        Last reviewed by <?= e($doc['reviewer_name']) ?> on <?= date('M d, Y', strtotime($doc['reviewed_at'])) ?>
                                    <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-dark fw-bold" style="border-radius:8px;">Submit Review</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <?php if(empty($documents)): ?>
            <div class="sa-card text-center py-5">
                <div class="text-muted mb-3"><i data-lucide="file-x" style="width:48px;height:48px;opacity:0.5;"></i></div>
                <h5 class="fw-bold">No Documents Submitted</h5>
                <p class="text-muted">This school has not submitted any verification documents yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
