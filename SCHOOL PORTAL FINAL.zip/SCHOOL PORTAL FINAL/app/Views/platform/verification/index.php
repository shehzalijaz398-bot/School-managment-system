<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .badge-status-not_submitted { background: #f1f5f9; color: #475569; }
  .badge-status-pending_review { background: #fef3c7; color: #b45309; }
  .badge-status-under_review { background: #dbeafe; color: #1e40af; }
  .badge-status-verified { background: #dcfce7; color: #166534; }
  .badge-status-rejected { background: #fee2e2; color: #991b1b; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Documents & Verification</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Review legal entity documents and verify tenant schools.</p>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="building"></i></div>
        <div><div class="sa-stat-label">Total Schools</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="shield-check"></i></div>
        <div><div class="sa-stat-label">Verified</div><div class="sa-stat-val"><?= number_format($analytics['verified']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="clock"></i></div>
        <div><div class="sa-stat-label">Pending Review</div><div class="sa-stat-val"><?= number_format($analytics['pending']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="x-circle"></i></div>
        <div><div class="sa-stat-label">Rejected</div><div class="sa-stat-val"><?= number_format($analytics['rejected']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="calendar-off"></i></div>
        <div><div class="sa-stat-label">Expiring Docs</div><div class="sa-stat-val"><?= number_format($analytics['expiring']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/verification')) ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small fw-bold">Search School</label>
                <input type="text" name="q" class="form-control" placeholder="Search by name or code..." value="<?= e($filters['q']??'') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold">Verification Status</label>
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="not_submitted" <?= ($filters['status']??'')=='not_submitted'?'selected':'' ?>>Not Submitted</option>
                    <option value="pending_review" <?= ($filters['status']??'')=='pending_review'?'selected':'' ?>>Pending Review</option>
                    <option value="under_review" <?= ($filters['status']??'')=='under_review'?'selected':'' ?>>Under Review</option>
                    <option value="verified" <?= ($filters['status']??'')=='verified'?'selected':'' ?>>Verified</option>
                    <option value="rejected" <?= ($filters['status']??'')=='rejected'?'selected':'' ?>>Rejected</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">School</th>
                    <th>Code</th>
                    <th>Country / Region</th>
                    <th>Owner</th>
                    <th>Verification Status</th>
                    <th>Registered At</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($schools as $s): ?>
                <tr>
                    <td class="ps-4 fw-bold text-dark"><?= e($s['name']) ?></td>
                    <td class="font-monospace text-muted"><?= e($s['code']) ?></td>
                    <td><?= e($s['country'] ?: 'Not specified') ?></td>
                    <td><?= e($s['owner_name'] ?: 'No Owner') ?></td>
                    <td>
                        <?php $vStatus = $s['verification_status'] ?: 'not_submitted'; ?>
                        <span class="badge badge-status-<?= e($vStatus) ?> border text-uppercase" style="border-color:currentColor!important; padding:5px 8px; font-size:0.75rem;">
                            <?= e(str_replace('_', ' ', $vStatus)) ?>
                        </span>
                    </td>
                    <td class="small text-muted">
                        <?= date('M d, Y', strtotime($s['created_at'])) ?>
                    </td>
                    <td class="text-end pe-4">
                        <a href="<?= e(url('superadmin/verification/'.$s['id'])) ?>" class="btn btn-light btn-sm fw-bold">Review Profile</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($schools)): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No records found matching your criteria.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
