<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-shield-lock-fill text-danger me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
        <form method="POST" action="<?= url('superadmin/security/emergency-lock') ?>" class="d-inline" onsubmit="return confirm('CRITICAL WARNING: This will instantly drop ALL active session tokens across all tenant boundaries. All active users will be immediately disconnected. Proceed with Emergency Lockdown?')">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-danger shadow-sm fw-bold px-4 pulse-danger">
                <i class="bi bi-exclamation-triangle-fill text-white-50 me-2"></i> TRIGGER EMERGENCY LOCKDOWN
            </button>
        </form>
    </div>

    <style>
        .pulse-danger {
            animation: pulse-animation 2s infinite;
        }
        @keyframes pulse-animation {
            0% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(220, 53, 69, 0); }
            100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0); }
        }
        .bg-cyber { background-color: #0f172a; color: #38bdf8; font-family: 'Courier New', Courier, monospace; }
        .text-neon { color: #38bdf8; text-shadow: 0 0 5px rgba(56, 189, 248, 0.5); }
    </style>

    <!-- Counter Row -->
    <div class="row">
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Active Failed Logins (24h)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $failedLogins ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-person-x fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                Blocked IP Addresses</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $blockedIps ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-shield-x fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Critical System Warnings</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $warnings ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-exclamation-octagon fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Panels -->
    <div class="row">
        <!-- Firewall Controls & Blocklist -->
        <div class="col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">IP Firewall Overrides</h6>
                    <span class="badge bg-danger"><i class="bi bi-record-circle-fill"></i> Active</span>
                </div>
                <div class="card-body">
                    <!-- Manual Override Form -->
                    <form method="POST" action="<?= url('superadmin/security/ip-block') ?>" class="mb-4 bg-light p-3 rounded border border-primary border-opacity-25">
                        <?= csrf_field() ?>
                        <div class="row g-2 align-items-center">
                            <div class="col-sm-5">
                                <label class="form-label small fw-bold text-muted mb-1">IP Address</label>
                                <input type="text" class="form-control" name="ip_address" placeholder="192.168.1.1" required>
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label small fw-bold text-muted mb-1">Action</label>
                                <select class="form-select fw-bold" name="action">
                                    <option value="block" class="text-danger">Blacklist IP</option>
                                    <option value="unblock" class="text-success">Whitelist IP</option>
                                </select>
                            </div>
                            <div class="col-sm-3 d-flex align-items-end mt-4">
                                <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm">Execute</button>
                            </div>
                        </div>
                    </form>

                    <h6 class="fw-bold mb-3 text-secondary text-uppercase fs-6 border-bottom pb-2">Active Blocked Registry</h6>
                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table table-hover table-bordered align-middle">
                            <thead class="table-dark sticky-top text-uppercase" style="font-size: 0.8rem;">
                                <tr>
                                    <th>IP Vector</th>
                                    <th>Detected Reason</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($blocked as $b): ?>
                                <tr>
                                    <td class="fw-bold <?= $b['is_blacklisted'] ? 'text-danger' : 'text-success' ?>">
                                        <?= htmlspecialchars($b['ip_address']) ?>
                                        <div class="small text-muted fw-normal"><?= date('M d, H:i', strtotime($b['created_at'])) ?></div>
                                    </td>
                                    <td class="small text-muted" style="max-width: 150px;">
                                        <?= htmlspecialchars($b['reason']) ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($b['is_blacklisted']): ?>
                                        <form method="POST" action="<?= url('superadmin/security/ip-block') ?>" class="d-inline">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="ip_address" value="<?= $b['ip_address'] ?>">
                                            <input type="hidden" name="action" value="unblock">
                                            <button class="btn btn-sm btn-outline-success shadow-sm" title="Whitelist & Unblock" onclick="return confirm('Whitelist this IP address?')">
                                                <i class="bi bi-unlock-fill"></i>
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <span class="badge bg-success">Whitelisted</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($blocked)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-4"><i class="bi bi-shield-check fs-2 d-block mb-2"></i>No blacklisted IPs found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Telemetry Logs -->
        <div class="col-lg-7">
            <div class="card shadow mb-4 border-0">
                <div class="card-header py-3 bg-dark d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 fw-bold text-neon"><i class="bi bi-terminal-fill me-2"></i> Live Intrusion Telemetry Stream</h6>
                    <span class="spinner-grow spinner-grow-sm text-info" role="status" aria-hidden="true"></span>
                </div>
                <div class="card-body bg-cyber p-0 border border-dark rounded-bottom">
                    <div class="table-responsive" style="max-height: 575px; overflow-y: auto;">
                        <table class="table table-sm table-borderless table-hover mb-0 text-light" style="font-size: 0.85rem;">
                            <thead class="sticky-top bg-dark text-white-50 border-bottom border-secondary">
                                <tr>
                                    <th class="ps-3">Timestamp</th>
                                    <th>Vector IP</th>
                                    <th>Target Payload</th>
                                    <th>Severity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($logs as $log): ?>
                                <tr class="border-bottom border-secondary border-opacity-25">
                                    <td class="text-white-50 ps-3">[<?= date('H:i:s', strtotime($log['created_at'])) ?>]</td>
                                    <td class="<?= $log['severity'] === 'Critical' ? 'text-danger fw-bold' : 'text-neon' ?>"><?= htmlspecialchars($log['ip_address']) ?></td>
                                    <td class="text-warning text-truncate" style="max-width: 180px;" title="<?= htmlspecialchars($log['attempted_email']) ?>"><?= htmlspecialchars($log['attempted_email'] ?? $log['event_type']) ?></td>
                                    <td>
                                        <?php if($log['severity'] === 'Critical'): ?>
                                            <span class="badge bg-danger rounded-0 border border-danger shadow-sm">CRITICAL</span>
                                        <?php elseif($log['severity'] === 'Warning'): ?>
                                            <span class="badge bg-warning text-dark rounded-0 border border-warning shadow-sm">WARNING</span>
                                        <?php else: ?>
                                            <span class="badge bg-info text-dark rounded-0 border border-info">INFO</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($logs)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">Awaiting telemetry data...</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
