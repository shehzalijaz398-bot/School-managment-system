<?php 
$c = $counts ?? []; 
// We now have $planCounts from controller
?>
<style>
  .sa-card {
    transition: transform 0.2s, box-shadow 0.2s;
    background: var(--sa-card);
    border: 1px solid var(--sa-border);
    border-radius: var(--sa-radius);
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    height: 100%;
    position: relative;
    overflow: hidden;
  }
  .sa-card.clickable {
    cursor: pointer;
  }
  .sa-card.clickable:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 24px rgba(0,0,0,0.06);
    border-color: var(--sa-primary);
  }
  .sa-stat-box { position: relative; z-index: 2; }
  .sa-stat-icon { transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
  .sa-card:hover .sa-stat-icon { transform: scale(1.1) rotate(5deg); }
  
  .sa-action-btn { position: relative; overflow: hidden; display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 16px; border-radius: 8px; background: var(--sa-card); border: 1px solid var(--sa-border); color: var(--sa-text); font-weight: 600; font-size: 0.9rem; margin-bottom: 8px; text-decoration: none; transition: all 0.2s; }
  .sa-action-btn svg { width: 18px; height: 18px; color: var(--sa-primary); }
  .sa-action-btn:hover { background: #f8fafc; border-color: var(--sa-primary); color: var(--sa-primary); }
  .sa-action-btn.primary { background: var(--sa-primary); color: #fff; border-color: var(--sa-primary); }
  .sa-action-btn.primary svg { color: #fff; }
  .sa-action-btn.primary:hover { background: var(--sa-sidebar-hover); border-color: var(--sa-sidebar-hover); }
  
  .sa-nav-pills .nav-link { color: var(--sa-muted); font-weight: 600; font-size: 0.85rem; border-radius: 20px; padding: 6px 16px; margin-right: 4px; transition: all 0.2s; }
  .sa-nav-pills .nav-link:hover { background: rgba(25,94,216,0.05); color: var(--sa-primary); }
  .sa-nav-pills .nav-link.active { background: var(--sa-primary); color: #fff; box-shadow: 0 4px 10px rgba(25,94,216,0.2); }
  
  .sa-table { width: 100%; border-collapse: separate; border-spacing: 0; }
  .sa-table th { text-align: left; padding: 12px 16px; font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); border-bottom: 1px solid var(--sa-border); }
  .sa-table td { padding: 12px 16px; font-size: 0.9rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
  .sa-table tr:hover td { background: #f8fafc; cursor: pointer; }
  .sa-table tr:last-child td { border-bottom: none; }
  
  .skeleton-loader { background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%); background-size: 200% 100%; animation: loading 1.5s infinite; border-radius: 4px; }
  @keyframes loading { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
  
  .health-card { padding: 12px; border-radius: 8px; border: 1px solid var(--sa-border); display: flex; align-items: center; gap: 12px; background: #fff; margin-bottom: 10px; }
  .health-card .icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Platform Control Center</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage your SaaS operations, financials, and tenants globally.</p>
  </div>
  
  <ul class="nav sa-nav-pills" id="dateFilter">
    <li class="nav-item"><a class="nav-link" href="#" data-period="today">Today</a></li>
    <li class="nav-item"><a class="nav-link" href="#" data-period="7d">7 Days</a></li>
    <li class="nav-item"><a class="nav-link active" href="#" data-period="30d">30 Days</a></li>
    <li class="nav-item"><a class="nav-link" href="#" data-period="3m">3 Months</a></li>
    <li class="nav-item"><a class="nav-link" href="#" data-period="12m">1 Year</a></li>
  </ul>
</div>

<!-- 1. KPI Cards -->
<div class="row g-3 mb-4" id="kpi-container">
  <!-- Filled via JS -->
  <?php for($i=0; $i<8; $i++): ?>
  <div class="col-md-3">
    <div class="sa-card"><div class="skeleton-loader" style="height: 60px; width: 100%;"></div></div>
  </div>
  <?php endfor; ?>
</div>

<div class="row g-4 mb-4">
  <!-- 2. Analytics (Charts) -->
  <div class="col-md-8">
    <div class="sa-card">
      <div class="sa-card-header d-flex justify-content-between">
        <h3 class="sa-card-title">Revenue & Growth Overview</h3>
        <div style="display:flex; gap: 15px; font-size:0.8rem; font-weight:600;">
            <div id="stat-new" style="color:var(--sa-success-text);"><i data-lucide="arrow-up-right" style="width:14px;height:14px;"></i> <span class="val">-</span> New</div>
            <div id="stat-churn" style="color:var(--sa-danger-text);"><i data-lucide="arrow-down-right" style="width:14px;height:14px;"></i> <span class="val">-</span> Churned</div>
        </div>
      </div>
      <div style="height: 280px; position: relative;">
        <canvas id="revenueChart"></canvas>
      </div>
    </div>
  </div>
  
  <div class="col-md-4">
    <div class="sa-card">
      <div class="sa-card-header">
        <h3 class="sa-card-title">Subscription Distribution</h3>
      </div>
      <div style="height: 200px; display:flex; justify-content:center; align-items:center;">
        <canvas id="planChart"></canvas>
      </div>
      <div id="plan-legend" style="margin-top:1rem; display:flex; flex-wrap:wrap; gap:10px; font-size:0.75rem; font-weight:600; justify-content: center;">
        <!-- Filled via JS -->
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- 4. School Activity -->
  <div class="col-md-6">
    <div class="sa-card">
      <div class="sa-card-header d-flex justify-content-between">
        <h3 class="sa-card-title">School Activity</h3>
        <select class="form-select form-select-sm" id="activityFilter" style="width:150px; font-size:0.8rem; border-radius: 8px;">
          <option value="recent">Recent Signups</option>
          <option value="pending">Pending Approvals</option>
          <option value="activated">Recently Activated</option>
          <option value="expiring">Expiring Soon</option>
          <option value="suspended">Recently Suspended</option>
        </select>
      </div>
      <div class="table-responsive" style="min-height: 250px;">
        <table class="sa-table" id="activityTable">
          <thead><tr><th>School</th><th>Plan</th><th>Status</th><th>Date</th></tr></thead>
          <tbody><!-- Filled via JS --></tbody>
        </table>
      </div>
      <div class="mt-2 text-end">
        <a href="<?= e(url('superadmin/schools')) ?>" style="font-size:0.85rem; font-weight:600; color: var(--sa-primary); text-decoration: none;">View All Schools &rarr;</a>
      </div>
    </div>
  </div>

  <!-- 5. Financial Snapshot -->
  <div class="col-md-6">
    <div class="sa-card">
      <div class="sa-card-header d-flex justify-content-between">
        <h3 class="sa-card-title">Financial Snapshot</h3>
        <select class="form-select form-select-sm" id="financialFilter" style="width:150px; font-size:0.8rem; border-radius: 8px;">
          <option value="recent_payments">Recent Payments</option>
          <option value="outstanding">Outstanding Invoices</option>
          <option value="overdue">Overdue Payments</option>
        </select>
      </div>
      <div class="table-responsive" style="min-height: 250px;">
        <table class="sa-table" id="financialTable">
          <thead><tr><th>School</th><th>Ref/Invoice</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody><!-- Filled via JS --></tbody>
        </table>
      </div>
      <div class="mt-2 text-end">
        <a href="<?= e(url('superadmin/invoices')) ?>" style="font-size:0.85rem; font-weight:600; color: var(--sa-primary); text-decoration: none;">Manage Billing &rarr;</a>
      </div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- 6. Platform Health -->
  <div class="col-md-8">
    <div class="sa-card">
      <div class="sa-card-header">
        <h3 class="sa-card-title">Platform Health</h3>
      </div>
      <div class="row g-3">
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: var(--sa-success-bg); color: var(--sa-success-text);"><i data-lucide="server"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">System Status</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['status']) ?></div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: var(--sa-primary-bg); color: var(--sa-primary-text);"><i data-lucide="database"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">Database</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['db_status']) ?></div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: var(--sa-info-bg); color: var(--sa-info-text);"><i data-lucide="hard-drive"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">Storage</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['storage']) ?></div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: var(--sa-warning-bg); color: var(--sa-warning-text);"><i data-lucide="clock"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">Cron / Queue</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['cron_status']) ?></div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: var(--sa-success-bg); color: var(--sa-success-text);"><i data-lucide="users"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">Active Users (1h)</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['active_users']) ?></div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="health-card">
            <div class="icon" style="background: <?= $health['errors'] > 0 ? 'var(--sa-danger-bg)' : 'var(--sa-success-bg)' ?>; color: <?= $health['errors'] > 0 ? 'var(--sa-danger-text)' : 'var(--sa-success-text)' ?>;"><i data-lucide="alert-triangle"></i></div>
            <div>
              <div style="font-size:0.75rem; color:var(--sa-muted); font-weight:600;">Platform Errors</div>
              <div style="font-size:0.9rem; font-weight:700; color:var(--sa-text);"><?= e($health['errors']) ?></div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-3 text-end">
        <a href="<?= e(url('superadmin/system')) ?>" style="font-size:0.85rem; font-weight:600; color: var(--sa-primary); text-decoration: none;">View System Details &rarr;</a>
      </div>
    </div>
  </div>

  <!-- 7. Quick Actions -->
  <div class="col-md-4">
    <div class="sa-card">
      <div class="sa-card-header">
        <h3 class="sa-card-title">Quick Actions</h3>
      </div>
      <a href="<?= e(url('superadmin/schools/create')) ?>" class="sa-action-btn primary"><i data-lucide="plus-circle"></i> Add New School</a>
      <a href="<?= e(url('superadmin/announcements')) ?>" class="sa-action-btn"><i data-lucide="megaphone"></i> Create Announcement</a>
      <a href="<?= e(url('superadmin/invoices')) ?>" class="sa-action-btn"><i data-lucide="file-text"></i> Create Invoice</a>
      <a href="<?= e(url('superadmin/plans')) ?>" class="sa-action-btn"><i data-lucide="credit-card"></i> Manage Plans</a>
      <a href="<?= e(url('superadmin/reports')) ?>" class="sa-action-btn"><i data-lucide="bar-chart-2"></i> View Reports</a>
      <a href="<?= e(url('superadmin/support')) ?>" class="sa-action-btn"><i data-lucide="headphones"></i> Support Tickets</a>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let revChart, pChart;
    let dashboardData = {};

    const currSymbol = '<?= e(platform_setting("default_currency", "PKR") === "PKR" ? "Rs. " : (platform_setting("default_currency", "USD") === "USD" ? "$" : platform_setting("default_currency", "PKR") . " ")) ?>';

    function initCharts() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        let gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, '#195ed8');
        gradient.addColorStop(1, 'rgba(25, 94, 216, 0.15)');

        revChart = new Chart(ctx, {
            type: 'bar',
            data: { labels: [], datasets: [{ label: 'Monthly Revenue', data: [], backgroundColor: gradient, borderRadius: 6, barPercentage: 0.5, hoverBackgroundColor: '#1e40af' }] },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { backgroundColor: 'rgba(15, 31, 58, 0.9)', titleFont: { size: 13, family: "'Inter', sans-serif" }, bodyFont: { size: 14, weight: 'bold', family: "'Inter', sans-serif" }, padding: 12, cornerRadius: 8, displayColors: false, callbacks: { label: function(c) { return currSymbol + c.parsed.y.toLocaleString(); } } }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { family: "'Inter', sans-serif", size: 12 } } },
                    y: { beginAtZero: true, border: { display: false }, grid: { color: '#f1f5f9' }, ticks: { font: { family: "'Inter', sans-serif", size: 12 }, color: '#64748b', callback: function(v) { return currSymbol + v.toLocaleString(); }, padding: 10 } }
                },
                animation: { duration: 800, easing: 'easeOutQuart' }
            }
        });
        
        const ctxPlan = document.getElementById('planChart').getContext('2d');
        pChart = new Chart(ctxPlan, {
            type: 'doughnut',
            data: { labels: [], datasets: [{ data: [], backgroundColor: ['#195ed8', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6'], borderWidth: 2, borderColor: '#ffffff', hoverOffset: 4, cutout: '72%' }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(15, 31, 58, 0.9)', titleFont: { size: 13, family: "'Inter', sans-serif" }, bodyFont: { size: 14, weight: 'bold', family: "'Inter', sans-serif" }, padding: 12, cornerRadius: 8 } }, animation: { animateScale: true, duration: 800 } }
        });
    }

    function formatMoney(amount) { return currSymbol + parseFloat(amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}); }
    function formatDate(dateStr) {
        if(!dateStr || dateStr.startsWith('0000-00-00')) return '-';
        const d = new Date(dateStr.replace(' ', 'T'));
        if(isNaN(d.getTime())) return '-';
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }
    function ucf(str) { if(!str) return ''; return str.charAt(0).toUpperCase() + str.slice(1); }

    function fetchDashboardData(period = '30d') {
        fetch('<?= url("superadmin/dashboard/data") ?>?period=' + period)
            .then(r => r.json())
            .then(data => {
                dashboardData = data;
                renderKPIs(data.kpi);
                renderAnalytics(data.analytics);
                renderActivity(document.getElementById('activityFilter').value);
                renderFinancial(document.getElementById('financialFilter').value);
                lucide.createIcons();
            })
            .catch(err => console.error('Error fetching dashboard data:', err));
    }

    function renderKPIs(kpi) {
        const baseUrl = '<?= url("superadmin/schools") ?>';
        const invoiceUrl = '<?= url("superadmin/invoices") ?>';
        
        const cards = [
            { label: 'Total Schools', value: kpi.total, icon: 'building', color: 'primary', link: baseUrl },
            { label: 'Active Schools', value: kpi.active, icon: 'check-circle-2', color: 'success', link: baseUrl + '?status=active' },
            { label: 'Trial Schools', value: kpi.trial, icon: 'clock', color: 'warning', link: baseUrl + '?status=trial' },
            { label: 'Suspended', value: kpi.suspended, icon: 'pause-circle', color: 'danger', link: baseUrl + '?status=suspended' },
            { label: 'Expired', value: kpi.expired, icon: 'x-circle', color: 'danger', link: baseUrl + '?status=expired' },
            { label: 'Pending Payments', value: formatMoney(kpi.pending_payments), icon: 'alert-circle', color: 'warning', link: invoiceUrl + '?status=overdue' },
            { label: 'Total Revenue', value: formatMoney(kpi.total_revenue), icon: 'bar-chart', color: 'info', link: '<?= url("superadmin/reports") ?>' },
            { label: 'Current MRR', value: formatMoney(kpi.mrr), icon: 'dollar-sign', color: 'primary', isGradient: true, link: '<?= url("superadmin/reports") ?>' }
        ];

        let html = '';
        cards.forEach(c => {
            let bgStyle = c.isGradient ? 'background: linear-gradient(135deg, #1e40af 0%, #195ed8 100%); color: white; border: none;' : '';
            let iconStyle = c.isGradient ? 'background: rgba(255,255,255,0.2); color: white;' : '';
            let valStyle = c.isGradient ? 'color: white;' : '';
            let labStyle = c.isGradient ? 'color: rgba(255,255,255,0.8);' : '';
            
            html += `
            <div class="col-md-3">
                <div class="sa-card clickable" style="${bgStyle}" onclick="window.location.href='${c.link}'">
                    <div class="sa-stat-box">
                        <div class="sa-stat-icon ${c.color}" style="${iconStyle}"><i data-lucide="${c.icon}"></i></div>
                        <div class="sa-stat-content">
                            <div class="sa-stat-label" style="${labStyle}">${c.label}</div>
                            <div class="sa-stat-value" style="${valStyle}">${c.value}</div>
                        </div>
                    </div>
                </div>
            </div>`;
        });
        document.getElementById('kpi-container').innerHTML = html;
    }

    function renderAnalytics(analytics) {
        document.querySelector('#stat-new .val').innerText = analytics.new_schools;
        document.querySelector('#stat-churn .val').innerText = analytics.churned_schools;

        revChart.data.labels = analytics.chart_labels;
        revChart.data.datasets[0].data = analytics.chart_values;
        revChart.update();

        const planLabels = analytics.plan_labels || ['Starter', 'Professional', 'Enterprise'];
        const planValues = analytics.plan_values || [];
        const planColors = ['#195ed8', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6'];

        pChart.data.labels = planLabels;
        pChart.data.datasets[0].data = planValues;
        pChart.data.datasets[0].backgroundColor = planColors.slice(0, planLabels.length);
        pChart.update();
        
        let legendHtml = '';
        planLabels.forEach((label, idx) => {
            let count = planValues[idx] || 0;
            let color = planColors[idx % planColors.length];
            legendHtml += `
                <div style="display:flex; align-items:center; gap:6px; font-size:0.8rem; font-weight:600;">
                    <span style="width:10px;height:10px;border-radius:50%;background:${color};display:inline-block;"></span>
                    <span>${label} (${count})</span>
                </div>`;
        });
        document.getElementById('plan-legend').innerHTML = legendHtml;
    }

    function renderActivity(type) {
        const tbody = document.querySelector('#activityTable tbody');
        let data = dashboardData.activity[type] || [];
        let html = '';
        if(data.length === 0) {
            html = `<tr><td colspan="4" class="text-center text-muted py-4">No schools found for this filter.</td></tr>`;
        } else {
            data.forEach(s => {
                let badgeClass = (s.subscription_status === 'active') ? 'success' : ((s.subscription_status === 'expired' || s.subscription_status === 'suspended') ? 'danger' : 'warning');
                html += `<tr onclick="window.location.href='<?= url("superadmin/schools/") ?>${s.id}'">
                    <td>
                        <div style="font-weight:600; color:var(--sa-text);">${s.name}</div>
                        <div style="font-size:0.75rem; color:var(--sa-muted);">${s.code}</div>
                    </td>
                    <td><span class="sa-badge plan">${s.plan_name || 'Standard'}</span></td>
                    <td><span class="sa-badge ${s.subscription_status}">${ucf(s.subscription_status)}</span></td>
                    <td style="color:var(--sa-muted); font-size:0.8rem;">${formatDate(s.updated_at || s.created_at)}</td>
                </tr>`;
            });
        }
        tbody.innerHTML = html;
        lucide.createIcons();
    }

    function renderFinancial(type) {
        const tbody = document.querySelector('#financialTable tbody');
        let data = dashboardData.financial[type] || [];
        let html = '';
        if(data.length === 0) {
            html = `<tr><td colspan="4" class="text-center text-muted py-4">No records found for this filter.</td></tr>`;
        } else {
            data.forEach(r => {
                let isPayment = type === 'recent_payments';
                let amount = isPayment ? r.amount : r.total_amount;
                let status = isPayment ? r.payment_status : r.status;
                let ref = isPayment ? r.reference_number : r.invoice_number;
                let dateField = isPayment ? r.paid_at : r.due_date;
                let urlStr = isPayment ? '<?= url("superadmin/invoices/") ?>' + r.invoice_id : '<?= url("superadmin/invoices/") ?>' + r.id;
                
                let badgeClass = (status === 'paid') ? 'success' : ((status === 'overdue') ? 'danger' : 'warning');
                
                html += `<tr onclick="window.location.href='${urlStr}'">
                    <td>
                        <div style="font-weight:600; color:var(--sa-text);">${r.school_name}</div>
                        <div style="font-size:0.75rem; color:var(--sa-muted);">${formatDate(dateField)}</div>
                    </td>
                    <td style="font-family:monospace; font-size:0.8rem;">${ref || '-'}</td>
                    <td style="font-weight:700;">${formatMoney(amount)}</td>
                    <td><span class="sa-badge ${badgeClass}">${ucf(status)}</span></td>
                </tr>`;
            });
        }
        tbody.innerHTML = html;
        lucide.createIcons();
    }

    // Event Listeners
    document.querySelectorAll('#dateFilter .nav-link').forEach(el => {
        el.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('#dateFilter .nav-link').forEach(n => n.classList.remove('active'));
            this.classList.add('active');
            fetchDashboardData(this.dataset.period);
        });
    });

    document.getElementById('activityFilter').addEventListener('change', function() { renderActivity(this.value); });
    document.getElementById('financialFilter').addEventListener('change', function() { renderFinancial(this.value); });

    initCharts();
    fetchDashboardData('30d'); // Initial load
});
</script>
