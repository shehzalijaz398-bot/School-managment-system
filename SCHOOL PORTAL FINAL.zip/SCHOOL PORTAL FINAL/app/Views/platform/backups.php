<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-server text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
        <form method="POST" action="<?= url('superadmin/system/backups/trigger') ?>" class="d-inline" onsubmit="return confirm('Initiate an instant high-performance snapshot of the entire system architecture? This process will consume CPU/IO resources briefly.')">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary shadow-sm fw-bold px-4 pulse-primary">
                <i class="bi bi-box-seam me-2"></i> 📦 Trigger Instant Snapshot
            </button>
        </form>
    </div>

    <!-- Status Widgets -->
    <div class="row mb-4">
        <div class="col-xl-4 col-md-6 mb-4 mb-xl-0">
            <div class="card shadow h-100 py-2 border-left-info border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Encrypted Vault Size</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($totalSize / 1024 / 1024, 2) ?> MB</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-hdd-stack fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 mb-4 mb-xl-0">
            <div class="card shadow h-100 py-2 border-left-success border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Last Architecture Checkpoint</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= htmlspecialchars($timeElapsed) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-clock-history fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6">
            <div class="card shadow h-100 py-2 border-left-primary border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">AWS S3 Cloud API Sync</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <span class="badge bg-success shadow-sm"><i class="bi bi-cloud-check-fill me-1"></i> <?= htmlspecialchars($cloudStatus) ?></span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-cloud-arrow-up fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- History Data Grid -->
    <div class="card shadow mb-4 border-0">
        <div class="card-header py-3 bg-dark d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-archive-fill me-2"></i> Disaster Recovery Vault History</h6>
            <span class="badge bg-danger shadow-sm border border-danger">Auto-purge Rule > 30 Days</span>
        </div>
        <div class="card-body bg-light p-0">
            <div class="table-responsive">
                <table class="table table-hover table-bordered bg-white mb-0 align-middle">
                    <thead class="table-dark sticky-top">
                        <tr>
                            <th class="ps-3">Snapshot ID</th>
                            <th>Archive Filename (AES-256)</th>
                            <th>Payload Size</th>
                            <th>Timestamp</th>
                            <th>Sync State</th>
                            <th class="text-center pe-3">Disaster Recovery Operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($backups as $b): ?>
                        <tr>
                            <td class="fw-bold text-secondary ps-3">#<?= htmlspecialchars($b['id']) ?></td>
                            <td class="font-monospace text-primary fw-bold"><i class="bi bi-file-earmark-lock2-fill text-warning me-2"></i><?= htmlspecialchars($b['file_name']) ?></td>
                            <td class="fw-bold"><?= number_format($b['file_size'] / 1024 / 1024, 3) ?> <span class="text-muted small">MB</span></td>
                            <td class="small fw-bold text-dark"><?= date('M d, Y H:i:s', strtotime($b['created_at'])) ?></td>
                            <td>
                                <?php if($b['storage_location'] === 'aws_s3_sync_pending'): ?>
                                    <span class="badge bg-info text-dark shadow-sm border border-info"><i class="bi bi-arrow-repeat"></i> Syncing...</span>
                                <?php else: ?>
                                    <span class="badge bg-success shadow-sm border border-success"><i class="bi bi-check-circle-fill"></i> S3 Secured</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center pe-3">
                                <form method="POST" action="<?= url("superadmin/system/backups/{$b['id']}/restore") ?>" onsubmit="return confirmRollback(this, '<?= addslashes($b['file_name']) ?>')">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="btn btn-sm btn-danger fw-bold shadow">
                                        ⚠️ Rollback System to This Checkpoint
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($backups)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-5"><i class="bi bi-hdd-network fs-1 d-block mb-3 text-gray-300"></i> Vault empty. Trigger a snapshot to begin infrastructure protection.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmRollback(form, filename) {
        // Absolute JavaScript system override warning overlay as requested
        const input = prompt("⚠️ CRITICAL OVERRIDE: Rolling back will destroy all current operational data and restore the architecture to state [" + filename + "].\n\nType 'CONFIRM' to execute rollback:");
        if (input === 'CONFIRM') {
            const btn = form.querySelector('button');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Restoring Architecture...';
            btn.classList.add('disabled');
            btn.setAttribute('disabled', 'disabled');
            return true;
        }
        alert("Rollback aborted. System integrity maintained.");
        return false;
    }
</script>
<style>
    .pulse-primary { animation: pulse-primary-anim 2s infinite; }
    @keyframes pulse-primary-anim {
        0% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(78, 115, 223, 0); }
        100% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0); }
    }
</style>
