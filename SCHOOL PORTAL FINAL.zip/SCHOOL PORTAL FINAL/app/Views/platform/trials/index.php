<style>
  .sa-card {
    transition: transform 0.2s, box-shadow 0.2s;
    background: var(--sa-card);
    border: 1px solid var(--sa-border);
    border-radius: var(--sa-radius);
    padding: 1.25rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
  }
  .sa-stat-box { display: flex; align-items: center; gap: 15px; }
  .sa-stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; justify-content: center; align-items: center; }
  .sa-stat-icon svg { width: 24px; height: 24px; }
  .sa-stat-icon.primary { background: var(--sa-primary-bg); color: var(--sa-primary-text); }
  .sa-stat-icon.success { background: var(--sa-success-bg); color: var(--sa-success-text); }
  .sa-stat-icon.warning { background: var(--sa-warning-bg); color: var(--sa-warning-text); }
  .sa-stat-icon.danger { background: var(--sa-danger-bg); color: var(--sa-danger-text); }
  .sa-stat-icon.info { background: #e0f2fe; color: #0284c7; }
  
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; letter-spacing: 0.5px; }
  .sa-stat-value { font-size: 1.5rem; font-weight: 800; color: var(--sa-text); line-height: 1.2; }

  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  .sa-table-container { background: var(--sa-card); border-radius: var(--sa-radius); border: 1px solid var(--sa-border); overflow: hidden; }
  .sa-table { width: 100%; border-collapse: separate; border-spacing: 0; }
  .sa-table th { background: #f8fafc; padding: 12px 16px; font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); border-bottom: 1px solid var(--sa-border); text-transform: uppercase; letter-spacing: 0.5px; }
  .sa-table td { padding: 12px 16px; font-size: 0.9rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
  .sa-table tr:hover td { background: #f8fafc; }
  .sa-table tr:last-child td { border-bottom: none; }
  
  .badge-trial-active { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; font-weight: 600; }
  .badge-trial-warning { background: #fef9c3; color: #854d0e; border: 1px solid #fef08a; font-weight: 600; }
  .badge-trial-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; font-weight: 600; }
  .badge-trial-info { background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-weight: 600; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Trial &amp; Lifecycle Management</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Monitor 30-day institution trials, inspect remaining grace periods, and audit manual extensions.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('superadmin/schools')) ?>" class="btn btn-outline-secondary" style="border-radius:8px; font-weight:600;">
      <i data-lucide="school" style="width:16px;height:16px;"></i> All Schools
    </a>
  </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon info"><i data-lucide="clock"></i></div>
        <div>
          <div class="sa-stat-label">Active Trials</div>
          <div class="sa-stat-value"><?= e((string)$counts['active']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon warning"><i data-lucide="alert-circle"></i></div>
        <div>
          <div class="sa-stat-label">Expiring in 7 Days</div>
          <div class="sa-stat-value"><?= e((string)$counts['expiring_soon']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon danger"><i data-lucide="x-circle"></i></div>
        <div>
          <div class="sa-stat-label">Expired Trials</div>
          <div class="sa-stat-value"><?= e((string)$counts['expired']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon success"><i data-lucide="check-check"></i></div>
        <div>
          <div class="sa-stat-label">Converted to Paid</div>
          <div class="sa-stat-value"><?= e((string)$counts['converted']) ?></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Filter Tabs & Search -->
<div class="filter-bar">
  <form method="get" action="<?= e(url('superadmin/trials')) ?>" class="row g-2 align-items-center">
    <div class="col-md-4">
      <div class="position-relative">
        <i data-lucide="search" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--sa-muted); width:16px;height:16px;"></i>
        <input type="text" name="q" class="form-control" placeholder="Search school name, code, owner email..." value="<?= e($q ?? '') ?>" style="padding-left:36px; border-radius:8px;">
      </div>
    </div>
    <div class="col-md-6">
      <div class="btn-group" role="group">
        <a href="<?= e(url('superadmin/trials?filter=all'.(!empty($q)?'&q='.urlencode($q):''))) ?>" class="btn btn-sm <?= ($filter === 'all' || empty($filter)) ? 'btn-dark' : 'btn-outline-secondary' ?>">All (<?= $counts['total'] ?>)</a>
        <a href="<?= e(url('superadmin/trials?filter=active'.(!empty($q)?'&q='.urlencode($q):''))) ?>" class="btn btn-sm <?= $filter === 'active' ? 'btn-info text-white' : 'btn-outline-secondary' ?>">Active Trials (<?= $counts['active'] ?>)</a>
        <a href="<?= e(url('superadmin/trials?filter=expiring_soon'.(!empty($q)?'&q='.urlencode($q):''))) ?>" class="btn btn-sm <?= $filter === 'expiring_soon' ? 'btn-warning text-dark' : 'btn-outline-secondary' ?>">Expiring Soon (<?= $counts['expiring_soon'] ?>)</a>
        <a href="<?= e(url('superadmin/trials?filter=expired'.(!empty($q)?'&q='.urlencode($q):''))) ?>" class="btn btn-sm <?= $filter === 'expired' ? 'btn-danger' : 'btn-outline-secondary' ?>">Expired (<?= $counts['expired'] ?>)</a>
        <a href="<?= e(url('superadmin/trials?filter=converted'.(!empty($q)?'&q='.urlencode($q):''))) ?>" class="btn btn-sm <?= $filter === 'converted' ? 'btn-success' : 'btn-outline-secondary' ?>">Converted (<?= $counts['converted'] ?>)</a>
      </div>
    </div>
    <div class="col-md-2 text-end">
      <button type="submit" class="btn btn-dark w-100" style="border-radius:8px; font-weight:600;">Search</button>
    </div>
  </form>
</div>

<!-- Trials Table -->
<div class="sa-table-container table-responsive">
  <table class="sa-table">
    <thead>
      <tr>
        <th>School Identity</th>
        <th>Owner / Administrator</th>
        <th>Selected Plan</th>
        <th>Registration Date</th>
        <th>Trial Expiry</th>
        <th>Remaining Duration</th>
        <th class="text-end">Lifecycle Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if(empty($items)): ?>
      <tr>
        <td colspan="7" class="text-center py-5 text-muted">
          <i data-lucide="inbox" style="width:48px;height:48px;color:var(--sa-border);margin-bottom:10px;"></i>
          <p class="mb-0">No institutions found matching the selected trial criteria.</p>
        </td>
      </tr>
      <?php else: ?>
        <?php foreach($items as $item): ?>
        <tr>
          <td>
            <div style="font-weight:700; color:var(--sa-text);"><?= e($item['name']) ?></div>
            <div style="font-size:0.75rem; color:var(--sa-muted); font-family:monospace;"><?= e($item['code']) ?></div>
          </td>
          <td>
            <div style="font-size:0.85rem; font-weight:600; color:var(--sa-text);"><?= e($item['owner_name'] ?: 'School Administrator') ?></div>
            <div style="font-size:0.75rem; color:var(--sa-muted);"><?= e($item['owner_email'] ?: $item['email']) ?></div>
          </td>
          <td>
            <span class="badge bg-light text-dark border"><?= e($item['plan_name'] ?: 'Standard Plan') ?></span>
          </td>
          <td style="color:var(--sa-muted); font-size:0.85rem;">
            <?= date('M d, Y', strtotime($item['created_at'])) ?>
          </td>
          <td>
            <div style="font-size:0.85rem; font-weight:600; color:var(--sa-text);">
              <?= !empty($item['trial_ends_at']) ? date('M d, Y', strtotime($item['trial_ends_at'])) : 'No date set' ?>
            </div>
            <div style="font-size:0.75rem; color:var(--sa-muted);">
              <?= !empty($item['trial_ends_at']) ? date('h:i A', strtotime($item['trial_ends_at'])) : '' ?>
            </div>
          </td>
          <td>
            <span class="badge badge-trial-<?= e($item['badge_class']) ?> px-2.5 py-1.5 rounded-pill">
              <?= e($item['badge_label']) ?>
            </span>
          </td>
          <td class="text-end">
            <div class="d-inline-flex gap-1">
              <button type="button" class="btn btn-sm btn-outline-primary" 
                      onclick="openExtendModal(<?= (int)$item['id'] ?>, '<?= e(addslashes($item['name'])) ?>', '<?= e($item['trial_ends_at'] ?? '') ?>')"
                      title="Controlled Trial Extension">
                <i data-lucide="clock-plus" style="width:14px;height:14px;"></i> Extend
              </button>
              <a href="<?= e(url('superadmin/schools/' . $item['id'])) ?>" class="btn btn-sm btn-light" title="Manage School">
                <i data-lucide="sliders" style="width:14px;height:14px;"></i>
              </a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Controlled Trial Extension Modal -->
<div class="modal fade" id="extendTrialModal" tabindex="-1" aria-labelledby="extendTrialModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="post" id="extendTrialForm" action="">
        <?= csrf_field() ?>
        <div class="modal-header bg-dark text-white">
          <h5 class="modal-title h6 fw-bold" id="extendTrialModalLabel">
            <i data-lucide="clock-plus" class="me-1"></i> Authorize Manual Trial Extension
          </h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="alert alert-info border-0 small mb-3">
            <i data-lucide="shield-alert" class="me-1"></i>
            Manual trial extensions are governed by platform compliance rules. Every extension logs the operator ID, prior expiry, new expiry, and mandatory business justification.
          </div>

          <div class="mb-3">
            <label class="form-label small fw-bold text-muted">Target Institution</label>
            <div id="modalSchoolName" class="fw-bold fs-6 text-dark"></div>
            <div class="text-muted small mt-1">Current Expiry: <span id="modalCurrentExpiry" class="font-monospace fw-semibold text-danger"></span></div>
          </div>

          <div class="mb-3">
            <label for="extendDays" class="form-label small fw-bold text-secondary">Extension Duration</label>
            <select name="days" id="extendDays" class="form-select" required>
              <option value="7">7 Days (Standard Grace Period)</option>
              <option value="14" selected>14 Days (Two Weeks Extension)</option>
              <option value="30">30 Days (Full Month Extension)</option>
              <option value="60">60 Days (Executive Exception)</option>
            </select>
          </div>

          <div class="mb-3">
            <label for="extendReason" class="form-label small fw-bold text-secondary">
              Business Justification / Reason <span class="text-danger">*</span>
            </label>
            <textarea name="reason" id="extendReason" rows="3" class="form-control" 
                      placeholder="e.g. School board meeting scheduled for budget approval next Tuesday; requested extension." required></textarea>
            <div class="form-text small" style="font-size:11px;">Mandatory for immutable compliance audit trail.</div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold">
            <i data-lucide="check" style="width:16px;height:16px;"></i> Authorize &amp; Apply Extension
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function openExtendModal(schoolId, schoolName, currentExpiry) {
    var form = document.getElementById('extendTrialForm');
    form.action = '<?= url("superadmin/trials") ?>/' + schoolId + '/extend';
    document.getElementById('modalSchoolName').textContent = schoolName;
    document.getElementById('modalCurrentExpiry').textContent = currentExpiry ? currentExpiry : 'Not set / Expired';
    document.getElementById('extendReason').value = '';
    
    var modal = new bootstrap.Modal(document.getElementById('extendTrialModal'));
    modal.show();
  }
</script>
