<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Edit Announcement</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Update platform-level communication settings.</p>
  </div>
  <a href="<?= e(url('superadmin/announcements')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to List</a>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="sa-card p-4">
            <form method="post" action="<?= e(url('superadmin/announcements/'.$announcement['id'])) ?>">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?= e($announcement['title']) ?>" required>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Type</label>
                        <select name="type" class="form-select">
                            <option value="general" <?= ($announcement['type']??'')=='general'?'selected':'' ?>>General</option>
                            <option value="important" <?= ($announcement['type']??'')=='important'?'selected':'' ?>>Important</option>
                            <option value="maintenance" <?= ($announcement['type']??'')=='maintenance'?'selected':'' ?>>Maintenance</option>
                            <option value="billing" <?= ($announcement['type']??'')=='billing'?'selected':'' ?>>Billing</option>
                            <option value="system_update" <?= ($announcement['type']??'')=='system_update'?'selected':'' ?>>System Update</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Priority</label>
                        <select name="priority" class="form-select">
                            <option value="normal" <?= ($announcement['priority']??'')=='normal'?'selected':'' ?>>Normal</option>
                            <option value="important" <?= ($announcement['priority']??'')=='important'?'selected':'' ?>>Important</option>
                            <option value="urgent" <?= ($announcement['priority']??'')=='urgent'?'selected':'' ?>>Urgent</option>
                        </select>
                    </div>
                </div>

                <?php 
                    $td = json_decode($announcement['target_data'] ?? '{}', true) ?: []; 
                ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Target Audience</label>
                    <select name="audience" id="audience_select_edit" class="form-select" onchange="toggleAudienceOptionsEdit()">
                        <option value="all" <?= $announcement['audience']=='all'?'selected':'' ?>>All Schools</option>
                        <option value="specific_school" <?= $announcement['audience']=='specific_school'?'selected':'' ?>>Specific School</option>
                        <option value="by_status" <?= $announcement['audience']=='by_status'?'selected':'' ?>>Schools by Status</option>
                        <option value="by_plan" <?= $announcement['audience']=='by_plan'?'selected':'' ?>>Schools by Subscription Plan</option>
                    </select>
                </div>
                
                <div id="audience_specific_school_edit" class="mb-3" style="display:<?= $announcement['audience']=='specific_school'?'block':'none' ?>;">
                    <label class="form-label fw-bold small text-muted">Select School</label>
                    <select name="school_id" class="form-select">
                        <option value="">Choose...</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= $announcement['school_id']==$s['id']?'selected':'' ?>><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div id="audience_by_status_edit" class="mb-3" style="display:<?= $announcement['audience']=='by_status'?'block':'none' ?>;">
                    <label class="form-label fw-bold small text-muted">Select Status</label>
                    <select name="target_status" class="form-select">
                        <option value="active" <?= ($td['status']??'')=='active'?'selected':'' ?>>Active</option>
                        <option value="trial" <?= ($td['status']??'')=='trial'?'selected':'' ?>>Trial</option>
                        <option value="suspended" <?= ($td['status']??'')=='suspended'?'selected':'' ?>>Suspended</option>
                    </select>
                </div>
                <div id="audience_by_plan_edit" class="mb-3" style="display:<?= $announcement['audience']=='by_plan'?'block':'none' ?>;">
                    <label class="form-label fw-bold small text-muted">Select Plan</label>
                    <select name="target_plan_id" class="form-select">
                        <?php foreach($plans as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= ($td['plan_id']??'')==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">Message Content <span class="text-danger">*</span></label>
                    <textarea name="body" class="form-control" rows="8" required><?= e($announcement['body']) ?></textarea>
                </div>
                
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= $announcement['status']=='draft'?'selected':'' ?>>Draft</option>
                            <option value="scheduled" <?= $announcement['status']=='scheduled'?'selected':'' ?>>Scheduled</option>
                            <option value="published" <?= $announcement['status']=='published'?'selected':'' ?>>Published</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Expiry Date (Optional)</label>
                        <input type="datetime-local" name="expiry_date" class="form-control" value="<?= $announcement['expiry_date'] ? date('Y-m-d\TH:i', strtotime($announcement['expiry_date'])) : '' ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary fw-bold px-5" style="border-radius:8px;">Update Announcement</button>
            </form>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="sa-card bg-light">
            <h5 class="fw-bold mb-3">Delivery Tracker</h5>
            <p class="text-muted small">Tracking notifications delivered via platform notification endpoints.</p>
            <hr>
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted fw-bold">Published:</span>
                <span><?= $announcement['published_at'] ? date('M d, Y H:i', strtotime($announcement['published_at'])) : 'N/A' ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted fw-bold">Expires:</span>
                <span><?= $announcement['expiry_date'] ? date('M d, Y H:i', strtotime($announcement['expiry_date'])) : 'Never' ?></span>
            </div>
        </div>
    </div>
</div>

<script>
function toggleAudienceOptionsEdit() {
    const aud = document.getElementById('audience_select_edit').value;
    document.getElementById('audience_specific_school_edit').style.display = (aud === 'specific_school') ? 'block' : 'none';
    document.getElementById('audience_by_status_edit').style.display = (aud === 'by_status') ? 'block' : 'none';
    document.getElementById('audience_by_plan_edit').style.display = (aud === 'by_plan') ? 'block' : 'none';
}
</script>
