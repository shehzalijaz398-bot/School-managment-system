<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Platform Announcements</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Communicate updates, maintenance, and alerts directly to your tenants.</p>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createAnnouncementModal" style="border-radius:8px;"><i data-lucide="bell-plus" style="width:16px;height:16px;"></i> Create Announcement</button>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="message-square"></i></div>
        <div><div class="sa-stat-label">Total</div><div class="sa-stat-val"><?= e($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
        <div><div class="sa-stat-label">Published</div><div class="sa-stat-val"><?= e($analytics['published']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-info"><i data-lucide="calendar"></i></div>
        <div><div class="sa-stat-label">Scheduled</div><div class="sa-stat-val"><?= e($analytics['scheduled']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-secondary"><i data-lucide="edit-3"></i></div>
        <div><div class="sa-stat-label">Drafts</div><div class="sa-stat-val"><?= e($analytics['draft']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/announcements')) ?>" class="row g-2">
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="published" <?= ($filters['status']??'')==='published'?'selected':'' ?>>Published</option>
                    <option value="draft" <?= ($filters['status']??'')==='draft'?'selected':'' ?>>Draft</option>
                    <option value="scheduled" <?= ($filters['status']??'')==='scheduled'?'selected':'' ?>>Scheduled</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Title & Type</th>
                    <th>Audience</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Published At</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($items as $i): ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold"><?= e($i['title']) ?></div>
                        <div class="small text-muted text-uppercase" style="font-size:0.75rem;"><?= e($i['type'] ?? 'General') ?></div>
                    </td>
                    <td>
                        <?php 
                            if($i['audience'] === 'all') echo '<span class="badge bg-light text-dark border">All Schools</span>';
                            elseif($i['audience'] === 'specific_school') echo '<span class="badge bg-info text-dark">'.e($i['target_school_name']).'</span>';
                            elseif($i['audience'] === 'by_status') echo '<span class="badge bg-secondary">Filtered Status</span>';
                            elseif($i['audience'] === 'by_plan') echo '<span class="badge bg-secondary">Filtered Plan</span>';
                            else echo '<span class="badge bg-light text-dark">'.e($i['audience']).'</span>';
                        ?>
                    </td>
                    <td>
                        <?php 
                            $pc = 'secondary';
                            if(($i['priority']??'') === 'important') $pc = 'warning text-dark';
                            if(($i['priority']??'') === 'urgent') $pc = 'danger';
                        ?>
                        <span class="badge bg-<?= $pc ?> text-uppercase"><?= e($i['priority'] ?? 'normal') ?></span>
                    </td>
                    <td>
                        <?php 
                            $sc = 'secondary';
                            if($i['status'] === 'published') $sc = 'success';
                            if($i['status'] === 'scheduled') $sc = 'info text-dark';
                        ?>
                        <span class="badge bg-<?= $sc ?> text-uppercase"><?= e($i['status']) ?></span>
                    </td>
                    <td class="text-muted small">
                        <?php if($i['published_at']): ?>
                            <?= date('M d, Y H:i', strtotime($i['published_at'])) ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td class="text-end pe-4">
                        <div class="dropdown">
                            <button class="btn btn-light btn-sm" data-bs-toggle="dropdown"><i data-lucide="more-vertical" style="width:16px;height:16px;"></i></button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                <li><a class="dropdown-item fw-bold" href="<?= e(url('superadmin/announcements/'.$i['id'].'/edit')) ?>">Edit / View</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <?php if($i['status'] === 'draft' || $i['status'] === 'scheduled'): ?>
                                <li>
                                    <form method="post" action="<?= e(url('superadmin/announcements/'.$i['id'].'/status')) ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="status" value="published">
                                        <button class="dropdown-item text-success fw-bold">Publish Now</button>
                                    </form>
                                </li>
                                <?php endif; ?>
                                <li>
                                    <form method="post" action="<?= e(url('superadmin/announcements/'.$i['id'].'/delete')) ?>" onsubmit="return confirm('Delete this announcement permanently?');">
                                        <?= csrf_field() ?>
                                        <button class="dropdown-item text-danger fw-bold">Delete</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($items)): ?>
                <tr><td colspan="6" class="text-center py-5 text-muted">No platform announcements found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createAnnouncementModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius:12px; border:none;">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold">Compose Platform Announcement</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('superadmin/announcements')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Title <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Type</label>
                    <select name="type" class="form-select">
                        <option value="general">General</option>
                        <option value="important">Important</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="billing">Billing</option>
                        <option value="system_update">System Update</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Priority</label>
                    <select name="priority" class="form-select">
                        <option value="normal">Normal</option>
                        <option value="important">Important</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label fw-bold small">Target Audience</label>
                <select name="audience" id="audience_select" class="form-select" onchange="toggleAudienceOptions()">
                    <option value="all">All Schools</option>
                    <option value="specific_school">Specific School</option>
                    <option value="by_status">Schools by Status</option>
                    <option value="by_plan">Schools by Subscription Plan</option>
                </select>
            </div>
            
            <div id="audience_specific_school" class="mb-3" style="display:none;">
                <label class="form-label fw-bold small text-muted">Select School</label>
                <select name="school_id" class="form-select">
                    <option value="">Choose...</option>
                    <?php foreach($schools as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="audience_by_status" class="mb-3" style="display:none;">
                <label class="form-label fw-bold small text-muted">Select Status</label>
                <select name="target_status" class="form-select">
                    <option value="active">Active</option>
                    <option value="trial">Trial</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>
            <div id="audience_by_plan" class="mb-3" style="display:none;">
                <label class="form-label fw-bold small text-muted">Select Plan</label>
                <select name="target_plan_id" class="form-select">
                    <?php foreach($plans as $p): ?>
                        <option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold small">Message Content <span class="text-danger">*</span></label>
                <textarea name="body" class="form-control" rows="6" required></textarea>
                <div class="form-text">Supports basic text formatting. This will appear on the school's dashboard.</div>
            </div>
            
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Status</label>
                    <select name="status" class="form-select">
                        <option value="published">Publish Now</option>
                        <option value="draft">Save as Draft</option>
                        <option value="scheduled">Schedule</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Expiry Date (Optional)</label>
                    <input type="datetime-local" name="expiry_date" class="form-control">
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Save & Proceed</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleAudienceOptions() {
    const aud = document.getElementById('audience_select').value;
    document.getElementById('audience_specific_school').style.display = (aud === 'specific_school') ? 'block' : 'none';
    document.getElementById('audience_by_status').style.display = (aud === 'by_status') ? 'block' : 'none';
    document.getElementById('audience_by_plan').style.display = (aud === 'by_plan') ? 'block' : 'none';
}
</script>
