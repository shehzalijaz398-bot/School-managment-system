<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Platform Users & Access</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage who has access to the Super Admin platform and what they can do.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('superadmin/roles')) ?>" class="btn btn-outline-secondary fw-bold" style="border-radius:8px;"><i data-lucide="shield" style="width:16px;height:16px;"></i> Roles & Permissions</a>
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#inviteUserModal" style="border-radius:8px;"><i data-lucide="user-plus" style="width:16px;height:16px;"></i> Invite Platform User</button>
  </div>
</div>

<div class="row mb-3">
    <div class="col-12">
        <div class="alert alert-info py-2 small fw-bold mb-0">
            <i data-lucide="info" style="width:16px;height:16px;"></i> <strong>Note:</strong> This module is ONLY for managing Super Admin SaaS staff (e.g., Billing Admins, Support Agents). Do NOT manage school principals, teachers, or students here.
        </div>
    </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="users"></i></div>
        <div><div class="sa-stat-label">Total Users</div><div class="sa-stat-val"><?= e($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="user-check"></i></div>
        <div><div class="sa-stat-label">Active</div><div class="sa-stat-val"><?= e($analytics['active']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="mail"></i></div>
        <div><div class="sa-stat-label">Pending Invites</div><div class="sa-stat-val"><?= e($analytics['pending']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="user-x"></i></div>
        <div><div class="sa-stat-label">Suspended</div><div class="sa-stat-val"><?= e($analytics['suspended']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/users')) ?>" class="row g-2">
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="1" <?= ($filters['status']??'')==='1'?'selected':'' ?>>Active</option>
                    <option value="2" <?= ($filters['status']??'')==='2'?'selected':'' ?>>Pending Invitation</option>
                    <option value="0" <?= ($filters['status']??'')==='0'?'selected':'' ?>>Suspended</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
            </div>
        </form>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Name & Email</th>
                    <th>Role</th>
                    <th>School Access</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th class="text-end pe-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold"><?= e($u['name']) ?></div>
                        <div class="small text-muted"><?= e($u['email']) ?></div>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark border"><?= e($u['role_name'] ?? 'Super Admin') ?></span>
                    </td>
                    <td>
                        <?php if($u['school_access'] === 'all'): ?>
                            <span class="badge bg-secondary">All Schools</span>
                        <?php else: 
                            $c = count(json_decode((string) ($u['school_access'] ?? ''), true) ?: []);
                        ?>
                            <span class="badge bg-info text-dark"><?= $c ?> Specific School(s)</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($u['status'] == 1): ?>
                            <span class="badge bg-success">Active</span>
                        <?php elseif($u['status'] == 2): ?>
                            <span class="badge bg-warning text-dark">Pending Invite</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Suspended</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small">
                        <?= $u['last_login_at'] ? date('M d, Y H:i', strtotime($u['last_login_at'])) : 'Never' ?>
                    </td>
                    <td class="text-end pe-4">
                        <?php if($u['id'] != 1 || platform_user_id() == 1): ?>
                        <div class="dropdown">
                            <button class="btn btn-light btn-sm" data-bs-toggle="dropdown"><i data-lucide="more-vertical" style="width:16px;height:16px;"></i></button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                <li>
                                    <button class="dropdown-item fw-bold" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $u['id'] ?>">Edit User</button>
                                </li>
                                <?php if($u['id'] != 1): ?>
                                <li>
                                    <form method="post" action="<?= e(url('superadmin/users/'.$u['id'].'/status')) ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="status" value="<?= $u['status']==1 ? '0' : '1' ?>">
                                        <button class="dropdown-item <?= $u['status']==1 ? 'text-danger' : 'text-success' ?> fw-bold"><?= $u['status']==1 ? 'Suspend Access' : 'Reactivate' ?></button>
                                    </form>
                                </li>
                                <li>
                                    <form method="post" action="<?= e(url('superadmin/users/'.$u['id'].'/revoke')) ?>">
                                        <?= csrf_field() ?>
                                        <button class="dropdown-item fw-bold">Revoke Sessions</button>
                                    </form>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <?php else: ?>
                            <span class="text-muted small">Restricted</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Invite User Modal -->
<div class="modal fade" id="inviteUserModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:12px; border:none;">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold">Invite Platform User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('superadmin/users')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Email Address <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Assign Role <span class="text-danger">*</span></label>
                <select name="role_id" class="form-select" required>
                    <?php foreach($roles as $r): ?>
                        <option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <hr>
            <h6 class="fw-bold mb-2">School Access Scope</h6>
            <div class="mb-3">
                <select name="school_access_type" class="form-select mb-2" onchange="document.getElementById('invite_schools').style.display = this.value === 'selected' ? 'block' : 'none';">
                    <option value="all">Can access ALL schools</option>
                    <option value="selected">Can only access selected schools</option>
                </select>
                <div id="invite_schools" style="display:none;">
                    <select name="schools[]" class="form-select" multiple size="4">
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text small">Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</div>
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Send Invitation</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Modals -->
<?php foreach($users as $u): if($u['id'] == 1 && platform_user_id() != 1) continue; ?>
<div class="modal fade" id="editUserModal<?= $u['id'] ?>" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:12px; border:none;">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold">Edit User: <?= e($u['name']) ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('superadmin/users/'.$u['id'])) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= e($u['name']) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Assign Role <span class="text-danger">*</span></label>
                <select name="role_id" class="form-select" required <?= $u['id']==1 ? 'disabled':'' ?>>
                    <?php foreach($roles as $r): ?>
                        <option value="<?= $r['id'] ?>" <?= $u['role_id']==$r['id']?'selected':'' ?>><?= e($r['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if($u['id']==1): ?><input type="hidden" name="role_id" value="1"><?php endif; ?>
            </div>
            
            <?php if($u['id'] != 1): ?>
            <hr>
            <h6 class="fw-bold mb-2">School Access Scope</h6>
            <div class="mb-3">
                <?php $isAll = ($u['school_access'] === 'all'); $sel = json_decode($u['school_access']??'[]', true) ?: []; ?>
                <select name="school_access_type" class="form-select mb-2" onchange="document.getElementById('edit_schools_<?= $u['id'] ?>').style.display = this.value === 'selected' ? 'block' : 'none';">
                    <option value="all" <?= $isAll ? 'selected':'' ?>>Can access ALL schools</option>
                    <option value="selected" <?= !$isAll ? 'selected':'' ?>>Can only access selected schools</option>
                </select>
                <div id="edit_schools_<?= $u['id'] ?>" style="display:<?= !$isAll ? 'block' : 'none' ?>;">
                    <select name="schools[]" class="form-select" multiple size="4">
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= in_array($s['id'], $sel) ? 'selected':'' ?>><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endforeach; ?>
