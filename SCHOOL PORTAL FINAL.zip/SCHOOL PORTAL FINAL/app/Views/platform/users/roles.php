<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .nav-pills .nav-link { color: var(--sa-text); font-weight: 600; border-radius: 8px; margin-bottom: 5px; }
  .nav-pills .nav-link.active { background: var(--sa-primary); color: white; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Roles & Permissions</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Configure RBAC (Role-Based Access Control) for your platform staff.</p>
  </div>
  <a href="<?= e(url('superadmin/users')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Users</a>
</div>

<div class="row">
    <div class="col-md-3">
        <div class="sa-card p-3">
            <h6 class="fw-bold mb-3 text-uppercase small text-muted">Platform Roles</h6>
            <div class="nav flex-column nav-pills" id="roles-tab" role="tablist" aria-orientation="vertical">
                <?php foreach($roles as $index => $r): ?>
                    <button class="nav-link text-start <?= $index===0?'active':'' ?>" id="role-tab-<?= $r['id'] ?>" data-bs-toggle="pill" data-bs-target="#role-<?= $r['id'] ?>" type="button" role="tab">
                        <?= e($r['name']) ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="col-md-9">
        <div class="tab-content" id="roles-tabContent">
            <?php foreach($roles as $index => $r): ?>
            <div class="tab-pane fade <?= $index===0?'show active':'' ?>" id="role-<?= $r['id'] ?>" role="tabpanel">
                <div class="sa-card">
                    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                        <div>
                            <h4 class="fw-bold mb-1"><?= e($r['name']) ?></h4>
                            <p class="text-muted small mb-0"><?= e($r['description'] ?? 'Manage permissions for this role.') ?></p>
                        </div>
                    </div>
                    
                    <form method="post" action="<?= e(url('superadmin/roles/'.$r['id'])) ?>">
                        <?= csrf_field() ?>
                        
                        <?php if($r['id'] == 1): ?>
                            <div class="alert alert-warning fw-bold">
                                <i data-lucide="alert-triangle" style="width:16px;height:16px;"></i> The Super Admin role has immutable full access.
                            </div>
                        <?php endif; ?>

                        <div class="row g-4">
                            <?php foreach($groupedPerms as $module => $perms): ?>
                            <div class="col-md-6">
                                <div class="p-3 border rounded bg-light h-100">
                                    <h6 class="fw-bold text-uppercase mb-3" style="color:var(--sa-primary);"><?= e(ucfirst($module)) ?> Module</h6>
                                    <?php foreach($perms as $p): 
                                        $hasPerm = in_array($p['id'], $roleMap[$r['id']] ?? []);
                                    ?>
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="<?= $p['id'] ?>" id="perm_<?= $r['id'] ?>_<?= $p['id'] ?>" <?= $hasPerm || $r['id']==1 ? 'checked' : '' ?> <?= $r['id']==1 ? 'disabled' : '' ?>>
                                        <label class="form-check-label small fw-bold" for="perm_<?= $r['id'] ?>_<?= $p['id'] ?>">
                                            <?= e($p['name']) ?>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <?php if($r['id'] != 1): ?>
                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary fw-bold px-5" style="border-radius:8px;">Save Permissions</button>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
