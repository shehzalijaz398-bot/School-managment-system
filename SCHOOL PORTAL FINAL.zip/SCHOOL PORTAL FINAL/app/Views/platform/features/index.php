<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .module-list-item { display: flex; align-items: flex-start; padding: 1.2rem; border: 1px solid #e2e8f0; border-radius: 12px; background: white; margin-bottom: 1rem; transition: all 0.2s ease; }
  .module-list-item:hover { border-color: #cbd5e1; box-shadow: 0 4px 12px rgba(0,0,0,0.03); }
  
  .module-icon-box { width: 48px; height: 48px; border-radius: 12px; background: #f1f5f9; display: flex; justify-content: center; align-items: center; color: #64748b; font-weight: 800; font-size: 1.2rem; flex-shrink: 0; margin-right: 1.2rem; }
  .module-content { flex-grow: 1; }
  
  .badge-status-enabled { background: #dcfce7; color: #166534; }
  .badge-status-disabled { background: #f1f5f9; color: #475569; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Features & Modules</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Globally toggle platform capabilities before they are assigned to subscription plans.</p>
  </div>
</div>

<div class="alert alert-primary bg-light border-primary py-2 px-3 small fw-bold mb-4 d-flex align-items-center">
    <i data-lucide="info" class="me-2 text-primary" style="width:18px;height:18px;"></i> 
    Global Status overrides Plan Availability. If a module is Disabled globally, it cannot be accessed by any school, regardless of their subscription plan.
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="box"></i></div>
        <div><div class="sa-stat-label">Total Modules</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
        <div><div class="sa-stat-label">Globally Enabled</div><div class="sa-stat-val"><?= number_format($analytics['enabled']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-muted"><i data-lucide="x-circle"></i></div>
        <div><div class="sa-stat-label">Globally Disabled</div><div class="sa-stat-val"><?= number_format($analytics['disabled']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="shield"></i></div>
        <div><div class="sa-stat-label">Core Systems</div><div class="sa-stat-val"><?= number_format($analytics['core']) ?></div></div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <?php foreach($grouped as $category => $modules): ?>
            <h5 class="fw-bold mb-3 mt-4 border-bottom pb-2" style="color:var(--sa-muted);"><?= e($category) ?></h5>
            
            <?php foreach($modules as $m): ?>
                <div class="module-list-item <?= $m['is_enabled'] == 0 ? 'opacity-75' : '' ?>">
                    <div class="module-icon-box"><?= e(strtoupper(substr($m['name'], 0, 1))) ?></div>
                    <div class="module-content">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <h6 class="fw-bold text-dark mb-0">
                                <?= e($m['name']) ?>
                                <?php if($m['is_core']): ?>
                                    <span class="badge bg-primary ms-2" style="font-size:0.65rem;">CORE</span>
                                <?php endif; ?>
                            </h6>
                            <span class="badge badge-status-<?= $m['is_enabled'] ? 'enabled' : 'disabled' ?> border text-uppercase" style="border-color:currentColor!important; padding:4px 8px; font-size:0.65rem;">
                                <?= $m['is_enabled'] ? 'Enabled' : 'Disabled' ?>
                            </span>
                        </div>
                        <p class="small text-muted mb-2"><?= e($m['description']) ?></p>
                        <div class="small fw-bold text-dark">
                            Key: <span class="font-monospace text-muted"><?= e($m['module_key']) ?></span>
                        </div>
                    </div>
                    
                    <div class="ms-3 align-self-center">
                        <?php if($m['is_core']): ?>
                            <button type="button" class="btn btn-light btn-sm fw-bold text-muted" disabled title="Core modules cannot be disabled.">Core Required</button>
                        <?php else: ?>
                            <form method="post" action="<?= e(url('superadmin/features/'.$m['id'].'/toggle')) ?>" onsubmit="return confirm('<?= $m['is_enabled'] ? 'Are you sure you want to disable this globally? All schools will immediately lose access.' : 'Enable this module globally?' ?>');">
                                <?= csrf_field() ?>
                                <?php if($m['is_enabled']): ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm fw-bold">Disable</button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-dark btn-sm fw-bold px-3">Enable</button>
                                <?php endif; ?>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>
    
    <div class="col-lg-4">
        <div class="sa-card bg-light mt-4">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Plan Architecture</h6>
            <p class="small text-muted mb-3">Modules enabled here are added to the global pool. You must still assign them to specific Subscription Plans in order for schools to access them.</p>
            <a href="<?= e(url('superadmin/plans')) ?>" class="btn btn-primary btn-sm w-100 fw-bold">Manage Subscription Plans &rarr;</a>
        </div>
        
        <div class="sa-card">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Active Subscriptions</h6>
            <?php if(empty($plans)): ?>
                <p class="small text-muted">No active plans found.</p>
            <?php else: ?>
                <ul class="list-unstyled mb-0">
                    <?php foreach($plans as $p): ?>
                        <li class="mb-2 pb-2 border-bottom">
                            <div class="fw-bold text-dark small"><?= e($p['name']) ?></div>
                            <div class="text-muted" style="font-size:0.75rem;">$<?= e(number_format($p['monthly_price'], 2)) ?> / month</div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
