<style>
  .sa-card {
    transition: transform 0.2s, box-shadow 0.2s;
    background: var(--sa-card);
    border: 1px solid var(--sa-border);
    border-radius: var(--sa-radius);
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    margin-bottom: 1.5rem;
  }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:15px; }
  .sa-stat-icon { width:48px; height:48px; border-radius:12px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.5rem; font-weight: 800; color: var(--sa-text); line-height:1.2; }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  
  .nav-tabs .nav-link { font-weight: 600; color: var(--sa-muted); border: none; border-bottom: 2px solid transparent; padding: 12px 24px; }
  .nav-tabs .nav-link.active { color: var(--sa-primary); border-bottom: 2px solid var(--sa-primary); background: transparent; }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .table td { font-size: 0.9rem; vertical-align: middle; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">SaaS Billing & Invoices</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage platform revenue, tenant subscriptions, and payments.</p>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createInvoiceModal" style="border-radius:8px;"><i data-lucide="plus-circle" style="width:16px;height:16px;"></i> Create Manual Invoice</button>
  </div>
</div>

<div class="sa-card p-0 mb-4">
    <ul class="nav nav-tabs px-4 pt-3" id="billingTabs" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-overview">Overview</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-invoices">All Invoices</button></li>
    </ul>

    <div class="tab-content p-4">
        <!-- Overview Tab -->
        <div class="tab-pane fade show active" id="tab-overview">
            <div class="sa-stat-grid">
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-primary"><i data-lucide="file-text"></i></div>
                    <div><div class="sa-stat-label">Total Invoiced</div><div class="sa-stat-val">$<?= number_format($analytics['total_invoiced'],2) ?></div></div>
                </div>
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
                    <div><div class="sa-stat-label">Total Paid</div><div class="sa-stat-val">$<?= number_format($analytics['total_paid'],2) ?></div></div>
                </div>
                <div class="sa-stat-card" style="background: linear-gradient(135deg, #b91c1c, #dc2626); color:white;">
                    <div class="sa-stat-icon" style="background:rgba(255,255,255,0.2); color:white;"><i data-lucide="alert-triangle"></i></div>
                    <div><div class="sa-stat-label" style="color:rgba(255,255,255,0.8);">Overdue Amount</div><div class="sa-stat-val" style="color:white;">$<?= number_format($analytics['overdue'],2) ?></div></div>
                </div>
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-info"><i data-lucide="pie-chart"></i></div>
                    <div><div class="sa-stat-label">Outstanding Balance</div><div class="sa-stat-val">$<?= number_format($analytics['outstanding'],2) ?></div></div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="border rounded p-3 bg-light">
                        <h5 class="fw-bold mb-3">Billing System Isolation Notice</h5>
                        <p class="text-muted small mb-0"><strong>CRITICAL:</strong> This module is exclusively for SaaS subscription billing between the platform and schools. It is fundamentally disconnected from the internal Student Fees module used by individual schools. Records here live in <code>subscription_invoices</code> and <code>subscription_payments</code>.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Invoices Tab -->
        <div class="tab-pane fade" id="tab-invoices">
            <div class="filter-bar mb-3 p-3">
                <form method="get" action="<?= e(url('superadmin/invoices')) ?>" class="row g-2">
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="">All Statuses</option>
                            <?php foreach(['draft','issued','pending','partially_paid','paid','overdue','cancelled'] as $st): ?>
                                <option value="<?= $st ?>" <?= ($filters['status']??'')===$st?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$st)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
                    </div>
                </form>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>School</th>
                            <th>Plan</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($invoices as $inv): ?>
                        <tr>
                            <td class="fw-bold"><a href="<?= e(url('superadmin/invoices/'.$inv['id'])) ?>"><?= e($inv['invoice_no']) ?></a></td>
                            <td>
                                <div class="fw-bold"><?= e($inv['school_name']) ?></div>
                                <div class="small text-muted"><?= e($inv['school_code']) ?></div>
                            </td>
                            <td><span class="badge bg-light text-dark border"><?= e($inv['plan_name'] ?? 'Custom') ?></span></td>
                            <td class="fw-bold">$<?= number_format($inv['total_amount'],2) ?></td>
                            <td>$<?= number_format($inv['paid_amount'],2) ?></td>
                            <td><?= $inv['due_date'] ? date('M d, Y', strtotime($inv['due_date'])) : '-' ?></td>
                            <td>
                                <?php 
                                    $sc = 'warning';
                                    if(in_array($inv['status'], ['paid','issued'])) $sc = 'success';
                                    if(in_array($inv['status'], ['overdue','cancelled'])) $sc = 'danger';
                                    if($inv['status'] === 'draft') $sc = 'secondary';
                                ?>
                                <span class="badge bg-<?= $sc ?>"><?= ucfirst(str_replace('_',' ',$inv['status'])) ?></span>
                            </td>
                            <td class="text-end">
                                <a href="<?= e(url('superadmin/invoices/'.$inv['id'])) ?>" class="btn btn-light btn-sm fw-bold">View</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($invoices)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No invoices found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Create Invoice Modal -->
<div class="modal fade" id="createInvoiceModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:12px; border:none; box-shadow:0 10px 30px rgba(0,0,0,0.1);">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold">Create Manual Invoice</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('superadmin/invoices')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Select Tenant (School) <span class="text-danger">*</span></label>
                <select name="school_id" class="form-select" required>
                    <option value="">Choose...</option>
                    <?php foreach($schools as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Description / Line Item <span class="text-danger">*</span></label>
                <input type="text" name="description" class="form-control" value="SaaS Subscription Fee" required>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Amount ($) <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="amount" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Due Date <span class="text-danger">*</span></label>
                    <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" required>
                </div>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Period Start</label>
                    <input type="date" name="billing_period_start" class="form-control" value="<?= date('Y-m-01') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Period End</label>
                    <input type="date" name="billing_period_end" class="form-control" value="<?= date('Y-m-t') ?>">
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Internal Notes</label>
                <textarea name="notes" class="form-control" rows="2"></textarea>
            </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Generate Draft Invoice</button>
        </div>
      </form>
    </div>
  </div>
</div>
