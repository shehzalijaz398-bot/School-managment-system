<div class="text-center mb-4">
  <h2><?= e($platform) ?></h2>
  <h4>Subscription Invoice <?= e($invoice['invoice_no']) ?></h4>
</div>
<p><strong>Bill To:</strong> <?= e($invoice['school_name']) ?> (<?= e($invoice['school_code']) ?>)<br>
<?= e($invoice['school_email'] ?? '') ?><br><?= e($invoice['address'] ?? '') ?></p>
<p>Period: <?= e(formatDate($invoice['billing_period_start'])) ?> — <?= e(formatDate($invoice['billing_period_end'])) ?><br>
Due: <?= e(formatDate($invoice['due_date'])) ?> · Status: <?= e($invoice['status']) ?></p>
<table class="table table-bordered"><thead><tr><th>Description</th><th>Amount</th></tr></thead><tbody>
<?php foreach ($items as $it): ?><tr><td><?= e($it['description']) ?></td><td><?= e(formatMoney($it['amount'])) ?></td></tr><?php endforeach; ?>
</tbody><tfoot><tr><th>Total</th><th><?= e(formatMoney($invoice['total_amount'])) ?></th></tr>
<tr><th>Paid</th><th><?= e(formatMoney($invoice['paid_amount'])) ?></th></tr></tfoot></table>
