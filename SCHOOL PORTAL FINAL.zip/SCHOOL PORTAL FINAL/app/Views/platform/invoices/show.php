<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-header-card { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; border-radius: var(--sa-radius); padding: 2rem; margin-bottom: 1.5rem; position: relative; overflow: hidden; }
  .sa-header-card h2 { font-weight: 800; margin-bottom: 0.5rem; }
  .sa-header-bg-icon { position: absolute; right: -20px; top: -20px; color: rgba(255,255,255,0.05); width: 150px; height: 150px; }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .table td { font-size: 0.9rem; vertical-align: middle; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
    <a href="<?= e(url('superadmin/invoices')) ?>" class="btn btn-light btn-sm fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Invoices</a>
    <div class="d-flex gap-2">
        <a href="<?= e(url('superadmin/invoices/'.$invoice['id'].'/print')) ?>" target="_blank" class="btn btn-outline-secondary btn-sm fw-bold"><i data-lucide="printer" style="width:16px;height:16px;"></i> Print / PDF</a>
        
        <form method="post" action="<?= e(url('superadmin/invoices/'.$invoice['id'].'/status')) ?>" style="margin:0;">
            <?= csrf_field() ?>
            <?php if($invoice['status'] === 'draft'): ?>
                <input type="hidden" name="status" value="issued">
                <button type="submit" class="btn btn-primary btn-sm fw-bold"><i data-lucide="send" style="width:16px;height:16px;"></i> Issue Invoice</button>
            <?php elseif(in_array($invoice['status'], ['issued','pending','overdue'])): ?>
                <input type="hidden" name="status" value="cancelled">
                <button type="submit" class="btn btn-danger btn-sm fw-bold" onclick="return confirm('Cancel this invoice?');"><i data-lucide="x-circle" style="width:16px;height:16px;"></i> Cancel Invoice</button>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="sa-header-card">
    <i data-lucide="file-text" class="sa-header-bg-icon"></i>
    <div class="row" style="position:relative; z-index:2;">
        <div class="col-md-6">
            <h2>Invoice <?= e($invoice['invoice_no']) ?></h2>
            <div style="color: rgba(255,255,255,0.8); font-size: 0.95rem;">
                <strong><?= e($invoice['school_name']) ?></strong> (<?= e($invoice['school_code']) ?>)<br>
                <?= e($invoice['address'] ?? 'No address') ?><br>
                <?= e($invoice['email'] ?? 'No email') ?> | <?= e($invoice['phone'] ?? 'No phone') ?>
            </div>
            <div class="mt-3">
                <?php 
                    $sc = 'warning';
                    if(in_array($invoice['status'], ['paid','issued'])) $sc = 'success';
                    if(in_array($invoice['status'], ['overdue','cancelled'])) $sc = 'danger';
                    if($invoice['status'] === 'draft') $sc = 'secondary';
                ?>
                <span class="badge bg-<?= $sc ?> fs-6 py-2 px-3"><?= ucfirst(str_replace('_',' ',$invoice['status'])) ?></span>
            </div>
        </div>
        <div class="col-md-6 text-md-end mt-4 mt-md-0" style="color: rgba(255,255,255,0.9);">
            <div class="row">
                <div class="col-6 col-md-12 mb-3">
                    <div style="font-size:0.8rem; text-transform:uppercase; font-weight:700;">Issue Date</div>
                    <div style="font-size:1.1rem; font-weight:700;"><?= date('M d, Y', strtotime($invoice['created_at'])) ?></div>
                </div>
                <div class="col-6 col-md-12 mb-3">
                    <div style="font-size:0.8rem; text-transform:uppercase; font-weight:700;">Due Date</div>
                    <div style="font-size:1.1rem; font-weight:700; color: <?= strtotime($invoice['due_date']) < time() && !in_array($invoice['status'], ['paid','cancelled']) ? '#f87171' : 'inherit' ?>;"><?= $invoice['due_date'] ? date('M d, Y', strtotime($invoice['due_date'])) : '-' ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="sa-card p-0">
            <div class="p-4 border-bottom bg-light d-flex justify-content-between align-items-center" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
                <h5 class="fw-bold m-0">Line Items</h5>
                <span class="badge bg-dark">Period: <?= date('M d, Y', strtotime($invoice['billing_period_start'])) ?> - <?= date('M d, Y', strtotime($invoice['billing_period_end'])) ?></span>
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Description</th>
                            <th class="text-end pe-4">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td class="ps-4 fw-bold"><?= e($item['description']) ?></td>
                            <td class="text-end pe-4">$<?= number_format($item['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr style="background: #f8fafc;">
                            <td class="text-end fw-bold ps-4">Subtotal</td>
                            <td class="text-end fw-bold pe-4">$<?= number_format($invoice['total_amount'], 2) ?></td>
                        </tr>
                        <tr style="background: #f8fafc;">
                            <td class="text-end fw-bold ps-4 text-success">Total Paid</td>
                            <td class="text-end fw-bold pe-4 text-success">-$<?= number_format($invoice['paid_amount'], 2) ?></td>
                        </tr>
                        <tr>
                            <td class="text-end fs-5 fw-bold ps-4">Amount Due</td>
                            <td class="text-end fs-5 fw-bold pe-4">$<?= number_format($invoice['total_amount'] - $invoice['paid_amount'], 2) ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="sa-card p-0">
            <div class="p-4 border-bottom">
                <h5 class="fw-bold m-0">Payment History</h5>
            </div>
            <div class="table-responsive p-3">
                <table class="table table-sm table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Method</th>
                            <th>Reference</th>
                            <th>Status</th>
                            <th class="text-end">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($payments as $p): ?>
                        <tr>
                            <td><?= date('M d, Y H:i', strtotime($p['paid_at'])) ?></td>
                            <td><?= ucfirst(str_replace('_',' ',$p['payment_method'])) ?></td>
                            <td><?= e($p['transaction_reference'] ?: '-') ?></td>
                            <td><span class="badge bg-success"><?= ucfirst($p['payment_status']) ?></span></td>
                            <td class="text-end fw-bold">$<?= number_format($p['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($payments)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">No payments recorded.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="sa-card">
            <h5 class="fw-bold mb-4">Record Manual Payment</h5>
            <?php if($invoice['status'] === 'paid'): ?>
                <div class="alert alert-success">This invoice is fully paid.</div>
            <?php elseif($invoice['status'] === 'cancelled'): ?>
                <div class="alert alert-danger">This invoice is cancelled.</div>
            <?php elseif($invoice['status'] === 'draft'): ?>
                <div class="alert alert-secondary">Issue this invoice first before recording payments.</div>
            <?php else: ?>
            <form method="post" action="<?= e(url('superadmin/invoices/'.$invoice['id'].'/payments')) ?>">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Amount ($) <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="amount" class="form-control fw-bold" value="<?= number_format($invoice['total_amount'] - $invoice['paid_amount'], 2, '.','') ?>" max="<?= number_format($invoice['total_amount'] - $invoice['paid_amount'], 2, '.','') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Payment Method <span class="text-danger">*</span></label>
                    <select name="payment_method" class="form-select" required>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="cash">Cash</option>
                        <option value="wallet">Wallet</option>
                        <option value="other">Other Offline</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Reference / Trx No.</label>
                    <input type="text" name="transaction_reference" class="form-control">
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Internal Notes</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
                <button type="submit" class="btn btn-dark w-100 fw-bold" style="border-radius:8px;">Record Payment</button>
            </form>
            <?php endif; ?>
        </div>
        
        <?php if($invoice['notes']): ?>
        <div class="sa-card bg-light">
            <h6 class="fw-bold text-muted text-uppercase small mb-2">Invoice Notes</h6>
            <p class="mb-0 small"><?= nl2br(e($invoice['notes'])) ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
