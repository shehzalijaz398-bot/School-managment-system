<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .health-item { display:flex; justify-content:space-between; align-items:center; padding: 12px 0; border-bottom: 1px solid #f1f5f9; }
  .health-item:last-child { border-bottom: none; }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .nav-pills .nav-link { color: var(--sa-muted); font-weight: 600; font-size: 0.9rem; border-radius: 8px; margin-bottom: 5px; }
  .nav-pills .nav-link.active { background-color: var(--sa-primary); color: white; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Security Center</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Monitor authentication boundaries, IP restrictions, and critical security alerts.</p>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-danger fw-bold" style="border-radius:8px;" data-bs-toggle="modal" data-bs-target="#emergencyModal"><i data-lucide="alert-triangle" style="width:16px;height:16px;"></i> Emergency Controls</button>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="shield"></i></div>
        <div><div class="sa-stat-label">2FA Enabled (Admins)</div><div class="sa-stat-val"><?= number_format($analytics['2fa_enabled']) ?></div></div>
    </div>
    <div class="sa-stat-card" style="border-color: <?= $analytics['failed_logins'] > 50 ? '#fca5a5' : '#e2e8f0' ?>;">
        <div class="sa-stat-icon text-warning"><i data-lucide="user-x"></i></div>
        <div><div class="sa-stat-label">Failed Logins (24h)</div><div class="sa-stat-val <?= $analytics['failed_logins'] > 50 ? 'text-danger' : '' ?>"><?= number_format($analytics['failed_logins']) ?></div></div>
    </div>
    <div class="sa-stat-card" style="border-color: <?= $analytics['critical_alerts'] > 0 ? '#fca5a5' : '#e2e8f0' ?>;">
        <div class="sa-stat-icon text-danger"><i data-lucide="siren"></i></div>
        <div><div class="sa-stat-label">Critical Alerts (7d)</div><div class="sa-stat-val <?= $analytics['critical_alerts'] > 0 ? 'text-danger' : '' ?>"><?= number_format($analytics['critical_alerts']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="ban"></i></div>
        <div><div class="sa-stat-label">Blocked IPs</div><div class="sa-stat-val"><?= number_format($analytics['blocked_ips']) ?></div></div>
    </div>
</div>

<div class="row">
    <!-- Left Column: Navigation & Health -->
    <div class="col-lg-3">
        <div class="sa-card p-3 mb-4">
            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist">
                <button class="nav-link text-start active" data-bs-toggle="pill" data-bs-target="#tab-sessions" type="button"><i data-lucide="activity" style="width:16px;height:16px;" class="me-2"></i> Active Sessions</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-alerts" type="button"><i data-lucide="bell" style="width:16px;height:16px;" class="me-2"></i> Security Alerts</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-ip" type="button"><i data-lucide="globe" style="width:16px;height:16px;" class="me-2"></i> IP Management</button>
                <a href="<?= e(url('superadmin/settings')) ?>" class="nav-link text-start"><i data-lucide="settings" style="width:16px;height:16px;" class="me-2"></i> Security Settings &rarr;</a>
            </div>
        </div>
        
        <div class="sa-card p-4">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">System Health Checklist</h6>
            <div class="health-item">
                <span class="small fw-bold text-dark">HTTPS / SSL</span>
                <?= $health['https'] ? '<span class="badge bg-success">Secure</span>' : '<span class="badge bg-danger">Insecure</span>' ?>
            </div>
            <div class="health-item">
                <span class="small fw-bold text-dark">Debug Mode</span>
                <?= !$health['debug_mode'] ? '<span class="badge bg-success">Off</span>' : '<span class="badge bg-danger">Enabled (Risk)</span>' ?>
            </div>
            <div class="health-item">
                <span class="small fw-bold text-dark">Database Connection</span>
                <span class="badge bg-success">Secure</span>
            </div>
            <div class="health-item">
                <span class="small fw-bold text-dark">PHP Version</span>
                <span class="small fw-bold text-muted"><?= e($health['php_version']) ?></span>
            </div>
        </div>
    </div>
    
    <!-- Right Column: Content -->
    <div class="col-lg-9">
        <div class="tab-content" id="v-pills-tabContent">
            
            <!-- Sessions Tab -->
            <div class="tab-pane fade show active" id="tab-sessions">
                <div class="sa-card p-0">
                    <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold m-0">Recent Login Sessions (12h)</h5>
                        <span class="small text-muted">Sourced from Audit Logs</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">User</th>
                                    <th>Role</th>
                                    <th>IP Address</th>
                                    <th>Login Time</th>
                                    <th>Device / Browser</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($activeSessions as $s): ?>
                                <tr>
                                    <td class="ps-4 fw-bold text-dark"><?= e($s['name']) ?></td>
                                    <td><span class="badge bg-light text-dark border text-uppercase"><?= e($s['role']) ?></span></td>
                                    <td class="font-monospace text-muted"><?= e($s['ip_address'] ?: 'Unknown') ?></td>
                                    <td class="small fw-bold"><?= date('H:i:s, M d', strtotime($s['created_at'])) ?></td>
                                    <td class="small text-muted" style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?= e($s['user_agent']) ?>">
                                        <?= e($s['user_agent'] ?: 'Unknown') ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($activeSessions)): ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">No recent logins detected.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Alerts Tab -->
            <div class="tab-pane fade" id="tab-alerts">
                <div class="sa-card p-0">
                    <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold m-0">Security Alerts (High / Critical)</h5>
                        <a href="<?= e(url('superadmin/audit')) ?>" class="btn btn-outline-dark btn-sm fw-bold">Full Audit Log</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Timestamp</th>
                                    <th>Severity</th>
                                    <th>Action</th>
                                    <th>Module</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($alerts as $a): ?>
                                <tr>
                                    <td class="ps-4 small fw-bold text-dark"><?= date('M d, Y H:i:s', strtotime($a['created_at'])) ?></td>
                                    <td>
                                        <span class="badge <?= $a['severity']==='critical' ? 'bg-danger' : 'bg-warning' ?> text-uppercase">
                                            <?= e($a['severity']) ?>
                                        </span>
                                    </td>
                                    <td class="fw-bold"><?= e($a['action']) ?></td>
                                    <td class="small text-muted"><?= e($a['module']) ?></td>
                                    <td class="font-monospace small text-muted"><?= e($a['ip_address'] ?: 'N/A') ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($alerts)): ?>
                                <tr><td colspan="5" class="text-center py-5 text-muted">No high or critical alerts recorded.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- IP Management Tab -->
            <div class="tab-pane fade" id="tab-ip">
                <div class="sa-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold m-0">IP Management</h5>
                        <button class="btn btn-primary btn-sm fw-bold" data-bs-toggle="collapse" data-bs-target="#addIpForm"><i data-lucide="plus" style="width:14px;height:14px;"></i> Add IP Rule</button>
                    </div>
                    
                    <div class="collapse mb-4" id="addIpForm">
                        <div class="card card-body bg-light border-0">
                            <form method="post" action="<?= e(url('superadmin/security/ip')) ?>">
                                <?= csrf_field() ?>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">IP Address</label>
                                        <input type="text" name="ip_address" class="form-control" required placeholder="192.168.1.1">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">Rule Type</label>
                                        <select name="type" class="form-select">
                                            <option value="blocked">Blocked (Blacklist)</option>
                                            <option value="whitelist">Allowed (Whitelist)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label small fw-bold">Reason / Note</label>
                                        <input type="text" name="reason" class="form-control" placeholder="Suspicious activity...">
                                    </div>
                                    <div class="col-12 text-end mt-3">
                                        <button type="submit" class="btn btn-dark fw-bold">Save IP Rule</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="table-responsive border rounded">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">IP Address</th>
                                    <th>Type</th>
                                    <th>Reason / Note</th>
                                    <th>Added On</th>
                                    <th class="text-end pe-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($ips as $ip): ?>
                                <tr>
                                    <td class="ps-4 font-monospace fw-bold text-dark"><?= e($ip['ip_address']) ?></td>
                                    <td>
                                        <span class="badge <?= $ip['type']==='blocked' ? 'bg-danger' : 'bg-success' ?> text-uppercase">
                                            <?= e($ip['type']) ?>
                                        </span>
                                    </td>
                                    <td class="small text-muted"><?= e($ip['reason'] ?: 'None') ?></td>
                                    <td class="small fw-bold"><?= date('M d, Y', strtotime($ip['created_at'])) ?></td>
                                    <td class="text-end pe-4">
                                        <form method="post" action="<?= e(url('superadmin/security/ip/'.$ip['id'].'/remove')) ?>">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-light btn-sm fw-bold text-danger">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($ips)): ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">No IP rules configured.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- Emergency Modal -->
<div class="modal fade" id="emergencyModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:12px; border:2px solid #dc2626;">
      <div class="modal-header bg-danger text-white border-bottom-0 pb-3">
        <h5 class="modal-title fw-bold"><i data-lucide="alert-triangle" class="me-2"></i> Emergency Controls</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4 bg-light">
        <p class="small text-dark fw-bold mb-4">Use these controls only during active security breaches or critical operational incidents. These actions are heavily audited.</p>
        
        <form method="post" action="<?= e(url('superadmin/security/emergency/lock_all')) ?>" class="mb-4 sa-card p-3 border-danger shadow-sm" onsubmit="return confirm('WARNING: This will instantly lock all other Super Admins out of the system. Are you absolutely sure?');">
            <?= csrf_field() ?>
            <h6 class="fw-bold text-danger mb-2">Lock All Other Admin Accounts</h6>
            <p class="small text-muted mb-3">Instantly disables access for all platform users except you. Useful if you suspect an admin account compromise.</p>
            <button type="submit" class="btn btn-danger btn-sm fw-bold w-100">EXECUTE LOCKOUT</button>
        </form>
        
        <form method="post" action="<?= e(url('superadmin/security/emergency/maintenance')) ?>" class="sa-card p-3 border-warning shadow-sm mb-0" onsubmit="return confirm('WARNING: This drops all school traffic instantly. Are you sure?');">
            <?= csrf_field() ?>
            <h6 class="fw-bold text-warning mb-2" style="color:#b45309!important;">Enable Global Maintenance Mode</h6>
            <p class="small text-muted mb-3">Instantly drops all tenant traffic and displays a 503 Maintenance screen to all schools. You will retain access.</p>
            <button type="submit" class="btn btn-warning btn-sm fw-bold w-100" style="color:#78350f;">EXECUTE MAINTENANCE OVERRIDE</button>
        </form>
      </div>
    </div>
  </div>
</div>
