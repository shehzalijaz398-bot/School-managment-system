<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:42px; height:42px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.15rem; font-weight: 800; color: var(--sa-text); }
  
  .nav-tabs .nav-link { color: var(--sa-muted); font-weight: 600; border: none; border-bottom: 2px solid transparent; }
  .nav-tabs .nav-link.active { color: var(--sa-text); border-bottom-color: var(--sa-primary); background: transparent; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Refunds & Credits</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage subscription payment reversals and manual account credits.</p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-outline-dark fw-bold" data-bs-toggle="modal" data-bs-target="#grantCreditModal">
      <i data-lucide="plus-circle" style="width:16px;height:16px;" class="me-1"></i> Grant Credit
    </button>
    <button type="button" class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#issueRefundModal">
      <i data-lucide="undo" style="width:16px;height:16px;" class="me-1"></i> Issue Refund
    </button>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="undo-2"></i></div>
        <div>
            <div class="sa-stat-label">Total Refunded</div>
            <div class="sa-stat-val text-danger">-$<?= e(number_format($analytics['total_refunded'], 2)) ?></div>
        </div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="gift"></i></div>
        <div>
            <div class="sa-stat-label">Credits Granted</div>
            <div class="sa-stat-val text-success">+$<?= e(number_format($analytics['total_credits_granted'], 2)) ?></div>
        </div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="credit-card"></i></div>
        <div>
            <div class="sa-stat-label">Credits Redeemed</div>
            <div class="sa-stat-val">-$<?= e(number_format($analytics['total_credits_redeemed'], 2)) ?></div>
        </div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="coins"></i></div>
        <div>
            <div class="sa-stat-label">Outstanding Liability</div>
            <div class="sa-stat-val">$<?= e(number_format($analytics['outstanding_credit'], 2)) ?></div>
        </div>
    </div>
</div>

<div class="sa-card p-0">
    <ul class="nav nav-tabs px-4 pt-3 border-bottom" id="financeTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active px-3 pb-3" data-bs-toggle="tab" data-bs-target="#refunds-tab" type="button" role="tab">Refund History</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#credits-tab" type="button" role="tab">Credit Ledger</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#balances-tab" type="button" role="tab">School Balances</button>
        </li>
    </ul>
    
    <div class="tab-content" id="financeTabsContent">
        <!-- Refunds Tab -->
        <div class="tab-pane fade show active" id="refunds-tab" role="tabpanel">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>School</th>
                            <th>Invoice Ref</th>
                            <th>Amount</th>
                            <th>Reason</th>
                            <th class="text-end pe-4">Authorized By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($refunds as $r): ?>
                        <tr>
                            <td class="ps-4 small text-muted fw-bold"><?= date('M d, Y H:i', strtotime($r['created_at'])) ?></td>
                            <td><div class="fw-bold text-dark"><?= e($r['school_name']) ?></div></td>
                            <td><span class="font-monospace text-muted">#<?= str_pad($r['invoice_id'], 6, '0', STR_PAD_LEFT) ?></span></td>
                            <td class="fw-bold text-danger">-$<?= e(number_format($r['amount'], 2)) ?></td>
                            <td class="small text-muted" style="max-width:250px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="<?= e($r['reason']) ?>"><?= e($r['reason']) ?></td>
                            <td class="text-end pe-4 small text-muted"><?= e($r['admin_name']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($refunds)): ?>
                            <tr><td colspan="6" class="text-center text-muted py-5">No refunds have been issued.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Credits Tab -->
        <div class="tab-pane fade" id="credits-tab" role="tabpanel">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>School</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Reason / Ref</th>
                            <th class="text-end pe-4">Authorized By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($credits as $c): ?>
                        <tr>
                            <td class="ps-4 small text-muted fw-bold"><?= date('M d, Y H:i', strtotime($c['created_at'])) ?></td>
                            <td><div class="fw-bold text-dark"><?= e($c['school_name']) ?></div></td>
                            <td>
                                <span class="badge bg-<?= $c['type'] === 'granted' ? 'success' : 'secondary' ?> text-uppercase" style="font-size:0.65rem;">
                                    <?= e($c['type']) ?>
                                </span>
                            </td>
                            <td class="fw-bold <?= $c['type'] === 'granted' ? 'text-success' : 'text-dark' ?>">
                                <?= $c['type'] === 'granted' ? '+' : '-' ?>$<?= e(number_format($c['amount'], 2)) ?>
                            </td>
                            <td class="small text-muted" style="max-width:250px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;">
                                <?php if($c['type'] === 'redeemed'): ?>
                                    Applied to Invoice #<?= str_pad($c['reference_id'], 6, '0', STR_PAD_LEFT) ?>
                                <?php else: ?>
                                    <?= e($c['reason']) ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4 small text-muted"><?= e($c['admin_name'] ?: 'System') ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($credits)): ?>
                            <tr><td colspan="6" class="text-center text-muted py-5">No credit transactions found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Balances Tab -->
        <div class="tab-pane fade" id="balances-tab" role="tabpanel">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">School Name</th>
                            <th class="text-end pe-4">Current Credit Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($schools as $s): ?>
                        <?php if($s['credit_balance'] > 0): ?>
                        <tr>
                            <td class="ps-4 fw-bold text-dark"><?= e($s['name']) ?></td>
                            <td class="text-end pe-4 fw-bold text-success">$<?= e(number_format($s['credit_balance'], 2)) ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Grant Credit -->
<div class="modal fade" id="grantCreditModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/refunds/credit')) ?>" class="modal-content" onsubmit="return confirm('Are you sure you want to grant this credit?');">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Grant Account Credit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-4">Credit will be automatically applied to the school's next subscription invoice.</p>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Select School</label>
                    <select name="school_id" class="form-select fw-bold" required>
                        <option value="">-- Choose School --</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?> (Bal: $<?= e(number_format($s['credit_balance'], 2)) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Credit Amount ($) <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="amount" class="form-control fw-bold text-success" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Reason for Credit <span class="text-danger">*</span></label>
                    <textarea name="reason" class="form-control" rows="2" required placeholder="e.g. Compensation for downtime..."></textarea>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-dark fw-bold px-4">Grant Credit</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Issue Refund -->
<div class="modal fade" id="issueRefundModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/refunds/issue')) ?>" class="modal-content" onsubmit="return confirm('Are you sure you want to process this refund?');">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold text-danger">Issue Refund</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Select School</label>
                    <select id="refund_school_id" class="form-select fw-bold" required onchange="loadInvoices(this.value)">
                        <option value="">-- Choose School --</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Select Eligible Invoice <span class="text-danger">*</span></label>
                    <select name="invoice_id" id="refund_invoice_id" class="form-select font-monospace" required disabled>
                        <option value="">-- Select School First --</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Refund Amount ($) <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="amount" id="refund_amount" class="form-control fw-bold text-danger" required>
                    <div class="form-text small" id="refund_max_text">Max Refundable: $0.00</div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Reason for Refund <span class="text-danger">*</span></label>
                    <textarea name="reason" class="form-control" rows="2" required placeholder="e.g. Accidental double charge..."></textarea>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger fw-bold px-4">Process Refund</button>
            </div>
        </form>
    </div>
</div>

<script>
let invoicesData = {};

function loadInvoices(schoolId) {
    const invSelect = document.getElementById('refund_invoice_id');
    const amtInput = document.getElementById('refund_amount');
    const maxText = document.getElementById('refund_max_text');
    
    invSelect.innerHTML = '<option value="">Loading...</option>';
    invSelect.disabled = true;
    amtInput.value = '';
    maxText.innerText = 'Max Refundable: $0.00';
    
    if (!schoolId) {
        invSelect.innerHTML = '<option value="">-- Select School First --</option>';
        return;
    }
    
    fetch('<?= e(url('superadmin/refunds/invoices/')) ?>' + schoolId)
        .then(res => res.json())
        .then(data => {
            invoicesData = {};
            if(data.length === 0) {
                invSelect.innerHTML = '<option value="">No eligible paid invoices found</option>';
            } else {
                invSelect.innerHTML = '<option value="">-- Select Invoice --</option>';
                data.forEach(inv => {
                    invoicesData[inv.id] = inv.refundable;
                    if(inv.refundable > 0) {
                        invSelect.innerHTML += `<option value="${inv.id}">#${String(inv.id).padStart(6,'0')} (Paid: $${inv.paid_amount})</option>`;
                    }
                });
                invSelect.disabled = false;
            }
        });
}

document.getElementById('refund_invoice_id').addEventListener('change', function() {
    const val = this.value;
    const maxText = document.getElementById('refund_max_text');
    const amtInput = document.getElementById('refund_amount');
    if(val && invoicesData[val] !== undefined) {
        const max = parseFloat(invoicesData[val]);
        maxText.innerText = 'Max Refundable: $' + max.toFixed(2);
        amtInput.max = max;
        amtInput.value = max;
    } else {
        maxText.innerText = 'Max Refundable: $0.00';
        amtInput.max = 0;
    }
});
</script>
