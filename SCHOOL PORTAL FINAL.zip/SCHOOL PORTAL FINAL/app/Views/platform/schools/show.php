<style>
  .sa-header-card { background: linear-gradient(135deg, #1e40af 0%, #195ed8 100%); color: white; border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; position: relative; overflow: hidden; }
  .sa-header-card h2 { font-weight: 800; margin-bottom: 0.2rem; }
  .sa-header-card code { background: rgba(255,255,255,0.2); color: white; padding: 2px 6px; border-radius: 4px; }
  .sa-header-bg-icon { position: absolute; right: -20px; top: -20px; color: rgba(255,255,255,0.1); width: 150px; height: 150px; }
  
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-card-title { font-size: 1.1rem; font-weight: 700; color: var(--sa-text); margin-bottom: 1.2rem; display: flex; align-items: center; gap: 8px; }
  .sa-card-title i { color: var(--sa-primary); }
  
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; }
  .sa-stat-item { background: #f8fafc; padding: 1rem; border-radius: 8px; border: 1px solid #e2e8f0; }
  .sa-stat-item .label { font-size: 0.75rem; color: var(--sa-muted); font-weight: 600; text-transform: uppercase; margin-bottom: 4px; }
  .sa-stat-item .value { font-size: 1.25rem; color: var(--sa-text); font-weight: 800; }
  
  .sa-info-list { list-style: none; padding: 0; margin: 0; }
  .sa-info-list li { display: flex; justify-content: space-between; padding: 0.75rem 0; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }
  .sa-info-list li:last-child { border-bottom: none; }
  .sa-info-list .key { color: var(--sa-muted); font-weight: 600; }
  .sa-info-list .val { color: var(--sa-text); font-weight: 600; text-align: right; }
  
  .sa-action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .sa-action-btn { display: flex; align-items: center; justify-content: center; gap: 6px; padding: 10px; border-radius: 8px; font-weight: 600; font-size: 0.85rem; border: 1px solid var(--sa-border); background: #fff; color: var(--sa-text); transition: all 0.2s; text-decoration: none; cursor: pointer; }
  .sa-action-btn:hover { background: #f8fafc; border-color: var(--sa-primary); color: var(--sa-primary); }
  .sa-action-btn.danger:hover { background: var(--sa-danger-bg); border-color: var(--sa-danger-text); color: var(--sa-danger-text); }
  .sa-action-btn.warning:hover { background: var(--sa-warning-bg); border-color: var(--sa-warning-text); color: var(--sa-warning-text); }
  
  .nav-tabs .nav-link { font-weight: 600; color: var(--sa-muted); border: none; border-bottom: 2px solid transparent; padding: 10px 20px; }
  .nav-tabs .nav-link.active { color: var(--sa-primary); border-bottom: 2px solid var(--sa-primary); background: transparent; }
  .nav-tabs .nav-link:hover:not(.active) { color: var(--sa-text); border-bottom: 2px solid #e2e8f0; }
  
  .table { margin-bottom: 0; }
  .table th { border-top: none; font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .table td { font-size: 0.9rem; vertical-align: middle; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
    <a href="<?= e(url('superadmin/schools')) ?>" class="btn btn-light btn-sm fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Schools</a>
    <div class="d-flex gap-2">
        <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/impersonate')) ?>" onsubmit="return confirm('Start support impersonation for this school?');" style="margin:0;">
            <?= csrf_field() ?>
            <input type="hidden" name="mode" value="read_only">
            <button type="submit" class="btn btn-warning btn-sm fw-bold"><i data-lucide="user-check" style="width:16px;height:16px;"></i> Support Impersonation</button>
        </form>
        <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/delete')) ?>" onsubmit="return confirm('CRITICAL ACTION: Are you absolutely sure you want to hard delete this school? ALL data will be permanently wiped. This cannot be undone.');" style="margin:0;">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-danger btn-sm fw-bold"><i data-lucide="trash-2" style="width:16px;height:16px;"></i> Delete School</button>
        </form>
    </div>
</div>

<div class="sa-header-card">
    <i data-lucide="building" class="sa-header-bg-icon"></i>
    <div class="d-flex justify-content-between align-items-start" style="position:relative; z-index:2;">
        <div>
            <h2><?= e($school['name']) ?></h2>
            <div style="font-size: 0.95rem; color: rgba(255,255,255,0.8); margin-bottom: 15px;">
                Code: <code><?= e($school['code']) ?></code> &bull; UUID: <span style="font-family:monospace;"><?= e($school['school_uuid'] ?? 'N/A') ?></span>
            </div>
            <div>
                <?php 
                    $sc = 'warning';
                    if($school['subscription_status'] === 'active') $sc = 'success';
                    if(in_array($school['subscription_status'],['suspended','expired','cancelled'])) $sc = 'danger';
                ?>
                <span class="badge bg-<?= $sc ?> fs-6 py-2 px-3"><?= ucfirst(str_replace('_',' ',$school['subscription_status'])) ?></span>
                <span class="badge bg-light text-dark fs-6 py-2 px-3 ms-2"><?= e($plan['name'] ?? 'No Plan') ?></span>
            </div>
        </div>
        <div class="text-end" style="color: rgba(255,255,255,0.9);">
            <div style="font-size:0.8rem; text-transform:uppercase; font-weight:700;">Registration Date</div>
            <div style="font-size:1.1rem; font-weight:700; margin-bottom:10px;"><?= date('M d, Y', strtotime($school['created_at'])) ?></div>
            <div style="font-size:0.8rem; text-transform:uppercase; font-weight:700;">Subscription Expiry</div>
            <div style="font-size:1.1rem; font-weight:700;"><?= $school['subscription_ends_at'] ? date('M d, Y', strtotime($school['subscription_ends_at'])) : 'Lifetime / None' ?></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Status & Usage -->
    <div class="col-lg-4">
        <div class="sa-card p-0">
            <div class="p-4 border-bottom">
                <h3 class="sa-card-title m-0"><i data-lucide="settings"></i> Lifecycle & Status</h3>
            </div>
            <div class="p-4">
                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/status')) ?>" class="mb-4" onsubmit="return confirm('Confirm changing platform status for <?= e(addslashes($school['name'])) ?>?');">
                    <?= csrf_field() ?>
                    <label class="form-label fw-bold" style="font-size:0.85rem;">Platform Status</label>
                    <div class="d-flex gap-2">
                        <select name="subscription_status" class="form-select form-select-sm">
                            <?php foreach (['pending','trial','active','past_due','suspended','expired','cancelled','archived'] as $st): ?>
                                <option value="<?= $st ?>" <?= $school['subscription_status']===$st?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$st)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm fw-bold">Update</button>
                    </div>
                </form>

                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/plan')) ?>" class="mb-4" onsubmit="return confirm('Confirm updating plan for <?= e(addslashes($school['name'])) ?>?');">
                    <?= csrf_field() ?>
                    <label class="form-label fw-bold" style="font-size:0.85rem;">Subscription Plan</label>
                    <div class="d-flex gap-2">
                        <select name="plan_id" class="form-select form-select-sm">
                            <?php foreach ($plans as $p): ?>
                                <option value="<?= (int)$p['id'] ?>" <?= (int)$school['plan_id']===(int)$p['id']?'selected':'' ?>><?= e($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm fw-bold">Change</button>
                    </div>
                </form>

                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/extend')) ?>" class="mb-4" onsubmit="return confirm('Confirm extending days for this school?');">
                    <?= csrf_field() ?>
                    <label class="form-label fw-bold" style="font-size:0.85rem;">Extend Days (Trial/Active)</label>
                    <div class="d-flex gap-2">
                        <input type="number" name="days" value="30" min="1" class="form-control form-control-sm">
                        <button type="submit" class="btn btn-outline-primary btn-sm fw-bold">Add Days</button>
                    </div>
                </form>

                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/activate')) ?>" onsubmit="return confirm('Confirm activating paid subscription for <?= e(addslashes($school['name'])) ?>?');">
                    <?= csrf_field() ?>
                    <label class="form-label fw-bold" style="font-size:0.85rem;">Activate Subscription</label>
                    <div class="d-flex gap-2">
                        <select name="billing_cycle" class="form-select form-select-sm">
                            <option value="monthly">Monthly</option>
                            <option value="annual">Annual</option>
                        </select>
                        <button type="submit" class="btn btn-success btn-sm fw-bold">Activate</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="sa-card p-0">
            <div class="p-4 border-bottom">
                <h3 class="sa-card-title m-0"><i data-lucide="sliders"></i> Usage & Custom Limits</h3>
            </div>
            <div class="p-4">
                <div class="sa-stat-grid mb-4">
                    <div class="sa-stat-item">
                        <div class="label">Students</div>
                        <div class="value"><?= (int)$usage['students'] ?> <span style="font-size:0.8rem; color:var(--sa-muted); font-weight:600;">/ <?= $plan && $plan['student_limit'] ? $plan['student_limit'] : '∞' ?></span></div>
                    </div>
                    <div class="sa-stat-item">
                        <div class="label">Teachers</div>
                        <div class="value"><?= (int)$usage['teachers'] ?> <span style="font-size:0.8rem; color:var(--sa-muted); font-weight:600;">/ <?= $plan && $plan['teacher_limit'] ? $plan['teacher_limit'] : '∞' ?></span></div>
                    </div>
                </div>

                <?php 
                  $cl = json_decode($school['custom_limits'] ?? '{}', true) ?: []; 
                  $c_stu = $cl['max_students'] ?? 0;
                  $c_tea = $cl['max_teachers'] ?? 0;
                  $c_str = $cl['storage_mb'] ?? 0;
                ?>
                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/limits')) ?>">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size:0.85rem;">Override Student Limit (0 for plan limit)</label>
                        <input type="number" name="max_students" value="<?= $c_stu ?>" class="form-control form-control-sm">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size:0.85rem;">Override Teacher Limit (0 for plan limit)</label>
                        <input type="number" name="max_teachers" value="<?= $c_tea ?>" class="form-control form-control-sm">
                    </div>
                    <button type="submit" class="btn btn-dark btn-sm w-100 fw-bold">Save Custom Limits</button>
                </form>
            </div>
        </div>

        <div class="sa-card p-0">
            <div class="p-4 border-bottom">
                <h3 class="sa-card-title m-0"><i data-lucide="file-text"></i> Internal Notes</h3>
            </div>
            <div class="p-4">
                <form method="post" action="<?= e(url('superadmin/schools/'.$school['id'].'/notes')) ?>">
                    <?= csrf_field() ?>
                    <textarea name="notes" class="form-control mb-3" rows="5" placeholder="Add private notes about this tenant..."><?= e($school['notes'] ?? '') ?></textarea>
                    <button type="submit" class="btn btn-primary btn-sm fw-bold">Save Notes</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Right Column: Details & Tabs -->
    <div class="col-lg-8">
        <div class="sa-card p-0 mb-4">
            <ul class="nav nav-tabs px-4 pt-3" id="schoolTabs" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-profile">Profile & Info</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-users">Users</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-billing">Billing & Subscriptions</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-audit">Activity Logs</button></li>
            </ul>

            <div class="tab-content p-4">
                <!-- Profile Tab -->
                <div class="tab-pane fade show active" id="tab-profile">
                    <h5 class="fw-bold mb-3">School Information</h5>
                    <ul class="sa-info-list mb-4">
                        <li><span class="key">Name</span><span class="val"><?= e($school['name']) ?></span></li>
                        <li><span class="key">Contact Email</span><span class="val"><?= e($school['email']) ?></span></li>
                        <li><span class="key">Phone</span><span class="val"><?= e($school['phone'] ?? 'N/A') ?></span></li>
                        <li><span class="key">Location</span><span class="val"><?= e($school['city'] ?? 'N/A') ?>, <?= e($school['country'] ?? 'N/A') ?></span></li>
                        <li><span class="key">Address</span><span class="val"><?= e($school['address'] ?? 'N/A') ?></span></li>
                    </ul>

                    <h5 class="fw-bold mb-3">Platform Configurations</h5>
                    <ul class="sa-info-list mb-4">
                        <li><span class="key">Current Plan</span><span class="val"><?= e($plan['name'] ?? 'N/A') ?></span></li>
                        <li><span class="key">Custom Domain</span><span class="val"><?= e($school['custom_domain'] ?? 'Not configured') ?></span></li>
                        <li><span class="key">Total Employees</span><span class="val"><?= (int)$usage['employees'] ?></span></li>
                    </ul>
                </div>

                <!-- Users Tab -->
                <div class="tab-pane fade" id="tab-users">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last Login</th></tr></thead>
                            <tbody>
                                <?php foreach($users as $u): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold"><?= e($u['name']) ?></div>
                                        <div class="text-muted" style="font-size:0.8rem;"><?= e($u['email']) ?></div>
                                    </td>
                                    <td><span class="badge bg-light text-dark border"><?= e($u['role_name']) ?></span></td>
                                    <td>
                                        <?php if($u['status'] == 1): ?><span class="badge bg-success">Active</span>
                                        <?php else: ?><span class="badge bg-danger">Disabled</span><?php endif; ?>
                                    </td>
                                    <td class="text-muted" style="font-size:0.85rem;"><?= $u['last_login_at'] ? date('M d, Y H:i', strtotime($u['last_login_at'])) : 'Never' ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Billing Tab -->
                <div class="tab-pane fade" id="tab-billing">
                    <h5 class="fw-bold mb-3">Recent Subscriptions</h5>
                    <div class="table-responsive mb-4">
                        <table class="table table-sm">
                            <thead><tr><th>Plan</th><th>Cycle</th><th>End Date</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php foreach($subscriptions as $sub): ?>
                                <tr>
                                    <td class="fw-bold"><?= e($sub['plan_name']) ?></td>
                                    <td><?= ucfirst($sub['billing_cycle']) ?></td>
                                    <td><?= $sub['end_date'] ? date('M d, Y', strtotime($sub['end_date'])) : '-' ?></td>
                                    <td><span class="badge bg-<?= $sub['status']==='active'?'success':'secondary' ?>"><?= ucfirst($sub['status']) ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <h5 class="fw-bold mb-3">Recent Invoices</h5>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead><tr><th>Invoice No</th><th>Total</th><th>Paid</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php foreach($invoices as $inv): ?>
                                <tr>
                                    <td><a href="<?= e(url('superadmin/invoices/'.$inv['id'])) ?>" class="fw-bold"><?= e($inv['invoice_no']) ?></a></td>
                                    <td>$<?= number_format($inv['total_amount'],2) ?></td>
                                    <td>$<?= number_format($inv['paid_amount'],2) ?></td>
                                    <td>
                                        <?php 
                                            $bc = 'warning';
                                            if($inv['status']==='paid') $bc = 'success';
                                            if($inv['status']==='overdue') $bc = 'danger';
                                        ?>
                                        <span class="badge bg-<?= $bc ?>"><?= ucfirst($inv['status']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Audit Tab -->
                <div class="tab-pane fade" id="tab-audit">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead><tr><th>Date</th><th>Action</th><th>Details</th></tr></thead>
                            <tbody>
                                <?php foreach($activity as $a): ?>
                                <tr>
                                    <td class="text-muted" style="font-size:0.85rem; width:150px;"><?= date('M d, Y H:i', strtotime($a['created_at'])) ?></td>
                                    <td class="fw-bold"><?= e($a['action']) ?></td>
                                    <td><pre style="margin:0; font-size:0.75rem; background:#f8fafc; padding:4px; border-radius:4px;"><?= e(substr(print_r(json_decode($a['new_values'] ?? '{}', true), true), 0, 100)) ?></pre></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
