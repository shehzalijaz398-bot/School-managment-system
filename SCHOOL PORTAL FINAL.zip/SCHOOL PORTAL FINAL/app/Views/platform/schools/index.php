<style>
  .sa-card {
    transition: transform 0.2s, box-shadow 0.2s;
    background: var(--sa-card);
    border: 1px solid var(--sa-border);
    border-radius: var(--sa-radius);
    padding: 1.25rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
  }
  .sa-stat-box { display: flex; align-items: center; gap: 15px; }
  .sa-stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; justify-content: center; align-items: center; }
  .sa-stat-icon svg { width: 24px; height: 24px; }
  .sa-stat-icon.primary { background: var(--sa-primary-bg); color: var(--sa-primary-text); }
  .sa-stat-icon.success { background: var(--sa-success-bg); color: var(--sa-success-text); }
  .sa-stat-icon.warning { background: var(--sa-warning-bg); color: var(--sa-warning-text); }
  .sa-stat-icon.danger { background: var(--sa-danger-bg); color: var(--sa-danger-text); }
  
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; letter-spacing: 0.5px; }
  .sa-stat-value { font-size: 1.5rem; font-weight: 800; color: var(--sa-text); line-height: 1.2; }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  
  .sa-table-container { background: var(--sa-card); border-radius: var(--sa-radius); border: 1px solid var(--sa-border); overflow: hidden; }
  .sa-table { width: 100%; border-collapse: separate; border-spacing: 0; }
  .sa-table th { background: #f8fafc; padding: 12px 16px; font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); border-bottom: 1px solid var(--sa-border); text-transform: uppercase; letter-spacing: 0.5px; }
  .sa-table td { padding: 12px 16px; font-size: 0.9rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
  .sa-table tr:hover td { background: #f8fafc; }
  .sa-table tr:last-child td { border-bottom: none; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Schools Overview</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage platform tenants, subscriptions, and onboarding lifecycle.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="#" class="btn btn-outline-secondary" onclick="window.print()" style="border-radius:8px; font-weight:600;"><i data-lucide="download" style="width:16px;height:16px;"></i> Export</a>
    <a href="<?= e(url('superadmin/schools/create')) ?>" class="btn btn-primary" style="background:var(--sa-primary); border:none; border-radius:8px; font-weight:600;"><i data-lucide="plus-circle" style="width:16px;height:16px;"></i> Add New School</a>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon primary"><i data-lucide="building"></i></div>
        <div>
          <div class="sa-stat-label">Total Schools</div>
          <div class="sa-stat-value"><?= e($counts['total']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon success"><i data-lucide="check-circle-2"></i></div>
        <div>
          <div class="sa-stat-label">Active & Trial</div>
          <div class="sa-stat-value"><?= e($counts['active'] + $counts['trial']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon warning"><i data-lucide="clock"></i></div>
        <div>
          <div class="sa-stat-label">Pending Approval</div>
          <div class="sa-stat-value"><?= e($counts['pending']) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="sa-card">
      <div class="sa-stat-box">
        <div class="sa-stat-icon danger"><i data-lucide="alert-triangle"></i></div>
        <div>
          <div class="sa-stat-label">Suspended / Past Due</div>
          <div class="sa-stat-value"><?= e($counts['suspended'] + $counts['past_due']) ?></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="filter-bar">
  <form method="get" action="<?= e(url('superadmin/schools')) ?>" class="row g-2 align-items-center">
    <div class="col-md-3">
      <div class="position-relative">
        <i data-lucide="search" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--sa-muted); width:16px;height:16px;"></i>
        <input type="text" name="q" class="form-control" placeholder="Search name, code, email..." value="<?= e($filters['q'] ?? '') ?>" style="padding-left:36px; border-radius:8px;">
      </div>
    </div>
    <div class="col-md-2">
      <select name="status" class="form-select" style="border-radius:8px;">
        <option value="">All Statuses</option>
        <?php foreach(['pending','trial','active','past_due','suspended','expired','cancelled','archived'] as $s): ?>
          <option value="<?= $s ?>" <?= ($filters['status'] ?? '') === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <select name="plan_id" class="form-select" style="border-radius:8px;">
        <option value="">All Plans</option>
        <?php foreach($plans as $p): ?>
          <option value="<?= $p['id'] ?>" <?= ($filters['plan_id'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-dark w-100" style="border-radius:8px; font-weight:600;">Filter</button>
    </div>
    <div class="col-md-3 text-end d-flex gap-2 justify-content-end">
        <select id="bulkActionSelect" class="form-select" style="border-radius:8px; width: 140px; display:inline-block;">
            <option value="">Bulk Actions</option>
            <option value="activate">Activate Selected</option>
            <option value="suspend">Suspend Selected</option>
        </select>
        <button type="button" class="btn btn-primary" onclick="executeBulkAction()" style="border-radius:8px; font-weight:600;">Apply</button>
    </div>
  </form>
</div>

<form id="bulkForm" method="post" action="<?= e(url('superadmin/schools/bulk')) ?>">
<?= csrf_field() ?>
<input type="hidden" name="action" id="bulkActionInput" value="">
<div class="sa-table-container table-responsive">
  <table class="sa-table">
    <thead>
      <tr>
        <th style="width:40px;"><input type="checkbox" id="selectAll" class="form-check-input"></th>
        <th>School Name</th>
        <th>Location</th>
        <th>Plan</th>
        <th>Status</th>
        <th>Joined</th>
        <th class="text-end">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if(empty($result['data'])): ?>
      <tr>
        <td colspan="7" class="text-center py-5 text-muted">
            <i data-lucide="search-x" style="width:48px;height:48px;color:var(--sa-border);margin-bottom:10px;"></i>
            <p>No schools found matching your criteria.</p>
        </td>
      </tr>
      <?php else: ?>
        <?php foreach($result['data'] as $s): ?>
        <tr>
          <td><input type="checkbox" name="ids[]" value="<?= e($s['id']) ?>" class="form-check-input chk-school"></td>
          <td>
            <div style="font-weight:700; color:var(--sa-text);"><?= e($s['name']) ?></div>
            <div style="font-size:0.75rem; color:var(--sa-muted);"><?= e($s['email']) ?> &bull; <?= e($s['code']) ?></div>
          </td>
          <td>
             <div style="font-size:0.85rem; color:var(--sa-text);"><?= e($s['city'] ?: 'Unknown') ?></div>
             <div style="font-size:0.75rem; color:var(--sa-muted);"><?= e($s['country'] ?: 'Unknown') ?></div>
          </td>
          <td><span class="sa-badge plan"><?= e($s['plan_name'] ?: 'Standard') ?></span></td>
          <td>
              <?php 
                $statusColor = 'warning';
                if ($s['subscription_status'] === 'active') $statusColor = 'success';
                if (in_array($s['subscription_status'], ['suspended', 'expired', 'cancelled'])) $statusColor = 'danger';
              ?>
              <span class="sa-badge <?= $statusColor ?>"><?= ucfirst(str_replace('_',' ',$s['subscription_status'])) ?></span>
          </td>
          <td style="color:var(--sa-muted); font-size:0.85rem;"><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
          <td class="text-end">
            <a href="<?= e(url('superadmin/schools/'.$s['id'])) ?>" class="btn btn-sm btn-light" style="border-radius:6px; font-weight:600;">Manage</a>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</form>

<?php 
$lastPage = (int) ($result['last_page'] ?? $result['pages'] ?? 1);
$currentPage = (int) ($result['current_page'] ?? $result['page'] ?? 1);
if ($lastPage > 1): 
?>
<div class="d-flex justify-content-between align-items-center mt-4">
    <div style="font-size:0.85rem; color:var(--sa-muted);">
        Showing page <?= e($currentPage) ?> of <?= e($lastPage) ?>
    </div>
    <div class="btn-group">
        <?php if($currentPage > 1): ?>
            <a href="?page=<?= $currentPage - 1 ?>&<?= http_build_query($filters ?? []) ?>" class="btn btn-outline-secondary btn-sm" style="border-radius:8px 0 0 8px;">Previous</a>
        <?php endif; ?>
        <?php if($currentPage < $lastPage): ?>
            <a href="?page=<?= $currentPage + 1 ?>&<?= http_build_query($filters ?? []) ?>" class="btn btn-outline-secondary btn-sm" style="border-radius:0 8px 8px 0;">Next</a>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<script>
document.getElementById('selectAll').addEventListener('change', function() {
    document.querySelectorAll('.chk-school').forEach(cb => cb.checked = this.checked);
});
function executeBulkAction() {
    const action = document.getElementById('bulkActionSelect').value;
    if(!action) { alert('Please select a bulk action.'); return; }
    const checked = document.querySelectorAll('.chk-school:checked');
    if(checked.length === 0) { alert('Please select at least one school.'); return; }
    if(confirm('Are you sure you want to perform this bulk action?')) {
        document.getElementById('bulkActionInput').value = action;
        document.getElementById('bulkForm').submit();
    }
}
</script>
