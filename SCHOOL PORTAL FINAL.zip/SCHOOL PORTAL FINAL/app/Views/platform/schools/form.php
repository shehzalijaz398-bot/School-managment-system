<div class="panel">
  <h2>Create School Tenant</h2>
  <form method="post" action="<?= e(url('superadmin/schools')) ?>">
    <?= csrf_field() ?>
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">School name</label><input name="name" class="form-control" required></div>
      <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
      <div class="col-md-4"><label class="form-label">Phone</label><input name="phone" class="form-control"></div>
      <div class="col-md-4"><label class="form-label">City</label><input name="city" class="form-control"></div>
      <div class="col-md-4"><label class="form-label">Country</label><input name="country" class="form-control"></div>
      <div class="col-md-6"><label class="form-label">Plan</label>
        <select name="plan_id" class="form-select" required>
          <?php foreach ($plans as $p): ?><option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?> (<?= e(formatMoney($p['monthly_price'])) ?>/mo)</option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 d-flex align-items-end"><label class="form-check"><input type="checkbox" name="start_trial" value="1" checked class="form-check-input"> Start trial</label></div>
      <div class="col-12"><hr><h5>First School Administrator</h5></div>
      <div class="col-md-4"><input name="admin_name" class="form-control" placeholder="Admin name" required></div>
      <div class="col-md-4"><input name="admin_email" type="email" class="form-control" placeholder="Admin email" required></div>
      <div class="col-md-4"><input name="admin_password" type="password" class="form-control" placeholder="Password" required minlength="8"></div>
      <div class="col-12"><textarea name="notes" class="form-control" placeholder="Account notes"></textarea></div>
    </div>
    <button class="btn btn-primary mt-3">Provision School</button>
  </form>
</div>
