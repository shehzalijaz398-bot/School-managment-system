<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .progress-sm { height: 6px; border-radius: 3px; background-color: #f1f5f9; margin-top: 5px; }
  
  .badge-override { background-color: #fef3c7; color: #92400e; border: 1px solid #fcd34d; font-size: 0.65rem; padding: 2px 6px; }
  .badge-plan { background-color: #f1f5f9; color: #64748b; font-size: 0.65rem; padding: 2px 6px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Usage & Limits</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Monitor tenant resource consumption and manage custom capacity overrides.</p>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="building"></i></div>
        <div><div class="sa-stat-label">Total Schools</div><div class="sa-stat-val"><?= number_format($analytics['total_schools']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="users"></i></div>
        <div><div class="sa-stat-label">Total Students</div><div class="sa-stat-val"><?= number_format($analytics['total_students']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="graduation-cap"></i></div>
        <div><div class="sa-stat-label">Total Teachers</div><div class="sa-stat-val"><?= number_format($analytics['total_teachers']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="sliders"></i></div>
        <div><div class="sa-stat-label">Active Overrides</div><div class="sa-stat-val"><?= number_format($analytics['overridden_schools']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4">School & Plan</th>
                    <th style="width: 25%;">Student Usage</th>
                    <th style="width: 25%;">Teacher Usage</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($schools as $s): ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold text-dark"><?= e($s['name']) ?></div>
                        <div class="small text-muted d-flex align-items-center mt-1">
                            <span class="me-2"><?= e($s['plan_name'] ?: 'No Plan') ?></span>
                            <span class="badge bg-<?= $s['subscription_status'] === 'active' ? 'success' : 'secondary' ?>" style="font-size:0.6rem;"><?= e($s['subscription_status']) ?></span>
                        </div>
                    </td>
                    <td>
                        <?php 
                            $used = $s['usage']['students'];
                            $limit = $s['active_student_limit'];
                            $pct = $limit ? min(100, round(($used / $limit) * 100)) : 0;
                            $color = $pct > 90 ? 'bg-danger' : ($pct > 75 ? 'bg-warning' : 'bg-primary');
                        ?>
                        <div class="d-flex justify-content-between align-items-end small">
                            <span class="fw-bold text-dark"><?= number_format($used) ?> <span class="text-muted fw-normal">/ <?= $limit === null ? '&infin;' : number_format($limit) ?></span></span>
                            <?php if($s['is_student_overridden']): ?>
                                <span class="badge-override rounded">Custom Override</span>
                            <?php else: ?>
                                <span class="badge-plan rounded border">Plan Limit</span>
                            <?php endif; ?>
                        </div>
                        <?php if($limit !== null): ?>
                            <div class="progress progress-sm"><div class="progress-bar <?= $color ?>" style="width: <?= $pct ?>%"></div></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php 
                            $used = $s['usage']['teachers'];
                            $limit = $s['active_teacher_limit'];
                            $pct = $limit ? min(100, round(($used / $limit) * 100)) : 0;
                            $color = $pct > 90 ? 'bg-danger' : ($pct > 75 ? 'bg-warning' : 'bg-success');
                        ?>
                        <div class="d-flex justify-content-between align-items-end small">
                            <span class="fw-bold text-dark"><?= number_format($used) ?> <span class="text-muted fw-normal">/ <?= $limit === null ? '&infin;' : number_format($limit) ?></span></span>
                            <?php if($s['is_teacher_overridden']): ?>
                                <span class="badge-override rounded">Custom Override</span>
                            <?php else: ?>
                                <span class="badge-plan rounded border">Plan Limit</span>
                            <?php endif; ?>
                        </div>
                        <?php if($limit !== null): ?>
                            <div class="progress progress-sm"><div class="progress-bar <?= $color ?>" style="width: <?= $pct ?>%"></div></div>
                        <?php endif; ?>
                    </td>
                    <td class="text-end pe-4">
                        <a href="<?= e(url('superadmin/usage/'.$s['id'])) ?>" class="btn btn-light btn-sm fw-bold">Manage Limits</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($schools)): ?>
                    <tr><td colspan="4" class="text-center text-muted py-5">No schools found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
