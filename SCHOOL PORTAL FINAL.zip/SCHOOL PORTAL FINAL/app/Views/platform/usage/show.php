<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .badge-plan { background-color: #f1f5f9; color: #64748b; font-size: 0.7rem; padding: 4px 8px; border-radius: 4px; border: 1px solid #e2e8f0; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Custom Limits: <?= e($school['name']) ?></h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Override standard plan limits for this specific school without upgrading their subscription.</p>
  </div>
  <a href="<?= e(url('superadmin/usage')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Usage List</a>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="sa-card">
            <div class="alert alert-warning bg-light border-warning py-2 px-3 small fw-bold mb-4 d-flex align-items-center">
                <i data-lucide="alert-circle" class="me-2 text-warning" style="width:18px;height:18px;"></i> 
                Leave override fields blank to enforce the standard Plan Limits.
            </div>

            <form method="post" action="<?= e(url('superadmin/usage/'.$school['id'])) ?>" onsubmit="return confirm('Apply these custom limits?');">
                <?= csrf_field() ?>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small text-dark">Student Limit Override</label>
                        <div class="input-group">
                            <input type="number" name="override_student_limit" class="form-control fw-bold" value="<?= e($school['override_student_limit']) ?>" placeholder="e.g. 500">
                        </div>
                        <div class="form-text small d-flex justify-content-between">
                            <span>Current Usage: <?= number_format($school['usage']['students']) ?></span>
                            <span class="badge-plan">Plan Limit: <?= $school['student_limit'] === null ? 'Unlimited' : number_format($school['student_limit']) ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small text-dark">Teacher Limit Override</label>
                        <div class="input-group">
                            <input type="number" name="override_teacher_limit" class="form-control fw-bold" value="<?= e($school['override_teacher_limit']) ?>" placeholder="e.g. 50">
                        </div>
                        <div class="form-text small d-flex justify-content-between">
                            <span>Current Usage: <?= number_format($school['usage']['teachers']) ?></span>
                            <span class="badge-plan">Plan Limit: <?= $school['teacher_limit'] === null ? 'Unlimited' : number_format($school['teacher_limit']) ?></span>
                        </div>
                    </div>
                </div>

                <div class="row mb-4 border-top pt-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small text-dark">Employee Limit Override</label>
                        <div class="input-group">
                            <input type="number" name="override_employee_limit" class="form-control fw-bold" value="<?= e($school['override_employee_limit']) ?>" placeholder="e.g. 30">
                        </div>
                        <div class="form-text small d-flex justify-content-between">
                            <span>Current Usage: <?= number_format($school['usage']['employees']) ?></span>
                            <span class="badge-plan">Plan Limit: <?= $school['employee_limit'] === null ? 'Unlimited' : number_format($school['employee_limit']) ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small text-dark">Storage Limit Override (MB)</label>
                        <div class="input-group">
                            <input type="number" name="override_storage_limit_mb" class="form-control fw-bold" value="<?= e($school['override_storage_limit_mb']) ?>" placeholder="e.g. 2048">
                        </div>
                        <div class="form-text small d-flex justify-content-between">
                            <span class="badge-plan">Plan Limit: <?= $school['storage_limit_mb'] === null ? 'Unlimited' : number_format($school['storage_limit_mb']) ?> MB</span>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end pt-3 border-top mt-4">
                    <button type="submit" class="btn btn-dark fw-bold px-4">Save Custom Limits</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="sa-card bg-light">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Plan Details</h6>
            <div class="mb-3">
                <span class="small text-muted d-block">Current Plan</span>
                <span class="fw-bold text-dark fs-5"><?= e($school['plan_name'] ?: 'No Active Plan') ?></span>
            </div>
            <div>
                <span class="small text-muted d-block">Subscription Status</span>
                <span class="badge bg-<?= $school['subscription_status'] === 'active' ? 'success' : 'secondary' ?> text-uppercase"><?= e($school['subscription_status']) ?></span>
            </div>
        </div>
        
        <div class="sa-card">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">How Overrides Work</h6>
            <p class="small text-muted" style="line-height:1.6;">
                Overrides take absolute precedence over Subscription Plan limits. If you grant a school an override of 500 Students, the system will allow 500 Students regardless of whether their plan restricts them to 100.
            </p>
            <p class="small text-muted mb-0" style="line-height:1.6;">
                If you clear the override (leave the input blank), the system instantly falls back to enforcing the standard Plan limits. This is fully audited.
            </p>
        </div>
    </div>
</div>
