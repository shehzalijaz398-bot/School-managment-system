<?php
$a = $analytics ?? [];
$stats = $a['verified_statistics'] ?? [];
$tenants = $stats['tenants'] ?? [];
$revenue = $stats['revenue'] ?? [];
$anomalies = $a['anomalies'] ?? [];
$ai = $a['ai_interpretation'] ?? [];
$period = $activePeriod ?? '30d';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">
      <i class="fas fa-brain text-primary me-2"></i> Platform AI Analytics &amp; Macro Intelligence
    </h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">
      Platform-wide multi-tenant aggregation, revenue velocity, and infrastructure health.
    </p>
  </div>

  <div class="d-flex align-items-center gap-2">
    <div class="btn-group">
      <a href="<?= e(url('superadmin/analytics?period=7d')) ?>" class="btn btn-sm <?= $period === '7d' ? 'btn-primary' : 'btn-outline-secondary' ?>">7 Days</a>
      <a href="<?= e(url('superadmin/analytics?period=30d')) ?>" class="btn btn-sm <?= $period === '30d' ? 'btn-primary' : 'btn-outline-secondary' ?>">30 Days</a>
      <a href="<?= e(url('superadmin/analytics?period=90d')) ?>" class="btn btn-sm <?= $period === '90d' ? 'btn-primary' : 'btn-outline-secondary' ?>">90 Days</a>
      <a href="<?= e(url('superadmin/analytics?period=1y')) ?>" class="btn btn-sm <?= $period === '1y' ? 'btn-primary' : 'btn-outline-secondary' ?>">1 Year</a>
    </div>

    <button type="button" class="btn btn-sm btn-primary shadow-sm" onclick="window.triggerChatbotPrompt('Analyze SaaS platform growth, subscription tiers, and backup vault health')">
      <i class="fas fa-robot me-1"></i> Ask Platform AI
    </button>
  </div>
</div>

<!-- 1. AI Executive Platform Intelligence Brief -->
<div class="card border-0 shadow-sm rounded-4 mb-4" style="background: linear-gradient(135deg, #ffffff 0%, #fbfbfe 100%); border-left: 5px solid #195ed8 !important;">
  <div class="card-body p-4">
    <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom">
      <div class="d-flex align-items-center gap-2">
        <div class="avatar bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
          <i class="fas fa-sparkles"></i>
        </div>
        <div>
          <h5 class="fw-bold mb-0 text-dark">Super Administrator Macro Intelligence</h5>
          <small class="text-muted">Scope: System-Wide SaaS Central Control (Zero Student PII)</small>
        </div>
      </div>

      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-success-subtle text-success border border-success-subtle">
          <i class="fas fa-shield-alt me-1"></i> [VERIFIED_STATISTICS] Grounded
        </span>
        <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
          <i class="fas fa-robot me-1"></i> [AI_INTERPRETATION] Model
        </span>
      </div>
    </div>

    <div class="text-dark" style="font-size: 13.5px; line-height: 1.6;">
      <?= nl2br(e($ai['executive_summary'] ?? 'Compiling platform intelligence...')) ?>
    </div>
  </div>
</div>

<!-- 2. Macro KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-12 col-sm-6 col-lg-3">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
      <small class="text-muted fw-bold text-uppercase">Total Tenants</small>
      <h3 class="fw-bold mb-0 text-dark"><?= (int)($tenants['total'] ?? 0) ?></h3>
      <div class="text-muted small mt-2">
        <?= (int)($tenants['active'] ?? 0) ?> Active · <?= (int)($tenants['trial'] ?? 0) ?> Trials · <?= (int)($tenants['suspended'] ?? 0) ?> Suspended
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-lg-3">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
      <div class="d-flex justify-content-between align-items-center">
        <small class="text-muted fw-bold text-uppercase">Subscription Billings</small>
        <?php $delta = (float)($revenue['growth_percentage'] ?? 0.0); ?>
        <span class="badge <?= $delta >= 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>">
          <?= $delta >= 0 ? '+' : '' ?><?= $delta ?>%
        </span>
      </div>
      <h3 class="fw-bold mb-0 text-dark">$<?= number_format((float)($revenue['current_period_amount'] ?? 0.0), 2) ?></h3>
      <div class="text-muted small mt-2">
        Prior cycle: $<?= number_format((float)($revenue['prior_period_amount'] ?? 0.0), 2) ?>
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-lg-3">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
      <small class="text-muted fw-bold text-uppercase">Platform Capacity</small>
      <h3 class="fw-bold mb-0 text-dark"><?= number_format((int)($stats['platform_students'] ?? 0)) ?></h3>
      <div class="text-muted small mt-2">
        Active enrolled students across all schools
      </div>
    </div>
  </div>

  <div class="col-12 col-sm-6 col-lg-3">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
      <small class="text-muted fw-bold text-uppercase">Vault Resilience</small>
      <h3 class="fw-bold mb-0 text-success"><?= (int)($stats['vault']['completed_backups'] ?? 0) ?> Snapshots</h3>
      <div class="text-muted small mt-2">
        Latest: <?= e($stats['vault']['latest_backup'] ?? 'None') ?>
      </div>
    </div>
  </div>
</div>

<!-- 3. Plan Distribution Table -->
<div class="card border-0 shadow-sm rounded-4 mb-4">
  <div class="card-header bg-white border-bottom py-3">
    <h6 class="fw-bold mb-0 text-dark">Active Subscription Tier Distribution</h6>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>Plan Tier</th>
          <th>Monthly Rate</th>
          <th>Active School Tenants</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach (($stats['plan_distribution'] ?? []) as $plan): ?>
        <tr>
          <td><strong><?= e($plan['name'] ?? 'Custom Plan') ?></strong></td>
          <td>$<?= number_format((float)($plan['monthly_price'] ?? 0.0), 2) ?>/mo</td>
          <td><span class="badge bg-primary-subtle text-primary fw-bold"><?= (int)($plan['school_count'] ?? 0) ?> Institutions</span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
