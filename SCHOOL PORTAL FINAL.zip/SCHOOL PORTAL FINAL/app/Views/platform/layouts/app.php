<?php
$user = \Core\PlatformAuth::user();
$platformName = platform_setting('platform_name', 'School Portal SaaS');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title ?? 'Platform') ?> · <?= e($platformName) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
  <link href="<?= e(asset('css/superadmin.css')) ?>" rel="stylesheet">
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="platform-body">
<?php if (!empty($_SESSION['impersonation'])): ?>
  <div class="bg-warning text-dark text-center py-2 fw-semibold">
    Support Mode active for school #<?= (int)$_SESSION['impersonation']['school_id'] ?>
    <form method="post" action="<?= e(url('superadmin/impersonation/stop')) ?>" class="d-inline"><?= csrf_field() ?>
      <button class="btn btn-sm btn-dark ms-2">Return to Platform</button>
    </form>
  </div>
<?php endif; ?>
<div class="platform-shell">
  <div class="platform-sidebar-overlay" id="platformSidebarOverlay" onclick="document.getElementById('platformSidebar').classList.remove('show'); this.classList.remove('is-visible');"></div>
  <aside class="platform-side" id="platformSidebar">
    <div class="platform-brand">
      <div class="platform-brand-icon"><i data-lucide="shield-check" style="width: 22px; height: 22px; color: #fff;"></i></div>
      <span><?= e($platformName) ?></span>
      <button type="button" class="btn btn-sm btn-link text-white d-lg-none ms-auto p-1 text-decoration-none" aria-label="Close menu" onclick="document.getElementById('platformSidebar').classList.remove('show'); document.getElementById('platformSidebarOverlay').classList.remove('is-visible');">
        <i data-lucide="x" style="width: 20px; height: 20px;"></i>
      </button>
    </div>
    <div class="platform-nav-menu">
      <?php
        $items = [
          ['Overview','superadmin/dashboard','layout-dashboard'],
          ['Schools','superadmin/schools','school'],
          ['Trials','superadmin/trials','clock'],
          ['Subscriptions & Plans','superadmin/plans','credit-card'],
          ['SaaS Billing','superadmin/invoices','receipt'],
          ['Analytics','superadmin/reports','bar-chart-2'],
          ['Audit Logs','superadmin/audit','activity'],
          ['Settings','superadmin/settings','settings'],
          ['Platform Health','superadmin/system','cpu'],
          ['Support','superadmin/support','headphones'],
          ['Announcements','superadmin/announcements','megaphone'],
        ];
        $cur = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '', '/');
        foreach ($items as [$label,$path,$icon]):
      ?>
        <a class="<?= str_contains($cur, trim($path,'/')) ? 'active' : '' ?>" href="<?= e(url($path)) ?>">
          <i data-lucide="<?= $icon ?>"></i> <span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
    
    <div class="sa-sidebar-footer">
      <div class="sa-user-profile">
        <div class="sa-user-avatar">SA</div>
        <div class="sa-user-info">
          <span class="name">Super Admin</span>
          <span class="role"><?= e($user['email'] ?? 'superadmin@platform.local') ?></span>
        </div>
        <form method="post" action="<?= e(url('superadmin/logout')) ?>" style="margin-left:auto;"><?= csrf_field() ?>
          <button style="background:transparent; border:none; color:#94a3b8; cursor:pointer;" title="Logout"><i data-lucide="log-out" style="width: 18px; height: 18px;"></i></button>
        </form>
      </div>
    </div>
  </aside>
  <div class="platform-main">
    <header class="platform-top">
      <div class="d-flex align-items-center gap-2 gap-sm-3">
        <button class="platform-toggle btn btn-sm btn-outline-secondary d-lg-none" type="button" aria-label="Toggle navigation" onclick="document.getElementById('platformSidebar').classList.toggle('show'); document.getElementById('platformSidebarOverlay').classList.toggle('is-visible');">
          <i data-lucide="menu" style="width: 18px; height: 18px;"></i>
        </button>
        <h4 style="margin:0; font-weight:700; color:var(--sa-text); font-size: 1.15rem;"><?= e($title ?? 'Dashboard') ?></h4>
      </div>
      <div class="d-flex align-items-center gap-2 gap-sm-3">
        <form action="<?= e(url('superadmin/schools')) ?>" method="get" class="sa-top-search d-none d-md-block">
          <i data-lucide="search"></i>
          <input type="text" name="q" placeholder="Search schools, users, or anything..." value="<?= e($_GET['q'] ?? '') ?>">
        </form>
        
        <?php
          $saUserId = $user['id'] ?? 0;
          $notifications = \Core\Database::fetchAll("SELECT * FROM platform_notifications WHERE user_id IS NULL OR user_id = ? ORDER BY created_at DESC LIMIT 5", [$saUserId]);
          $unreadCount = \Core\Database::fetch("SELECT COUNT(*) c FROM platform_notifications WHERE (user_id IS NULL OR user_id = ?) AND is_read = 0", [$saUserId])['c'] ?? 0;
        ?>
        <div class="dropdown">
          <div data-bs-toggle="dropdown" aria-expanded="false" style="position:relative; cursor:pointer; padding: 4px;">
            <i data-lucide="bell" style="color:var(--sa-muted); width:20px; height:20px;"></i>
            <?php if ($unreadCount > 0): ?>
            <span style="position:absolute; top:-2px; right:-2px; background:var(--sa-danger-bg); color:var(--sa-danger-text); width:16px; height:16px; border-radius:50%; font-size:10px; display:flex; align-items:center; justify-content:center; font-weight:bold;"><?= $unreadCount ?></span>
            <?php endif; ?>
          </div>
          <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" style="width: 320px; max-width: calc(100vw - 24px); border-radius: 12px; padding: 0;">
            <li class="p-3 border-bottom d-flex justify-content-between align-items-center" style="background:#f8fafc; border-radius:12px 12px 0 0;">
              <span class="fw-bold" style="font-size:0.9rem;">Notifications</span>
            </li>
            <?php if (empty($notifications)): ?>
              <li class="p-4 text-center text-muted small">No recent notifications</li>
            <?php else: ?>
              <?php foreach ($notifications as $n): ?>
                <li class="border-bottom">
                  <a class="dropdown-item py-3 px-3 <?= !$n['is_read'] ? 'bg-light' : '' ?>" href="<?= e($n['link'] ?? '#') ?>" style="white-space: normal; transition: background 0.2s;">
                    <div class="fw-bold mb-1" style="font-size: 0.85rem; color:var(--sa-text);"><?= e($n['title']) ?></div>
                    <div class="text-muted" style="font-size: 0.8rem; line-height: 1.3;"><?= e($n['message']) ?></div>
                    <div class="text-muted mt-2" style="font-size: 0.7rem; display:flex; align-items:center; gap:4px;">
                      <i data-lucide="clock" style="width:12px;height:12px;"></i>
                      <?= e(date('M d, g:i A', strtotime($n['created_at']))) ?>
                    </div>
                  </a>
                </li>
              <?php endforeach; ?>
              <li><a href="#" class="dropdown-item text-center py-2 small fw-bold" style="color:var(--sa-primary);">View all notifications</a></li>
            <?php endif; ?>
          </ul>
        </div>

        <div style="display:flex; align-items:center; gap:8px; cursor:pointer;">
          <div style="width:34px; height:34px; min-width:34px; background:var(--sa-primary-bg); color:var(--sa-primary-text); border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px;">
            SA
          </div>
          <div class="d-none d-sm-block">
            <div style="font-size:0.82rem; font-weight:700; line-height:1.2; color:var(--sa-text);">Super Admin</div>
            <div style="font-size:0.68rem; color:var(--sa-muted);">Platform Admin</div>
          </div>
        </div>
      </div>
    </header>
    <main class="p-3 p-md-4 flex-grow-1" style="background:var(--sa-bg);">
      <?php require base_path('app/Views/partials/flash.php'); ?>
      <?= $content ?>
    </main>
  </div>
</div>
<?php require base_path('app/Views/partials/ai_chat_widget.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<script src="<?= e(asset('js/custom-select.js')) ?>"></script>
<script>
  lucide.createIcons();
</script>
</body>
</html>
