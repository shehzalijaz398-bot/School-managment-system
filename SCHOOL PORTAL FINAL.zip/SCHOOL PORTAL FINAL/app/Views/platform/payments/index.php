<div class="panel"><h2>Payments</h2>
<table class="table"><thead><tr><th>School</th><th>Invoice</th><th>Amount</th><th>Method</th><th>Status</th><th>Paid</th></tr></thead><tbody>
<?php foreach ($payments as $p): ?>
<tr><td><?= e($p['school_name']) ?></td><td><?= e($p['invoice_no']) ?></td><td><?= e(formatMoney($p['amount'])) ?></td><td><?= e($p['payment_method']) ?></td><td><?= statusBadge($p['payment_status']) ?></td><td><?= e(formatDate($p['paid_at'], 'd M Y H:i')) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
