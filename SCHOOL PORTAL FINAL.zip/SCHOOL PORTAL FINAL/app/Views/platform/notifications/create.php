<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Compose Notification</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Send targeted system alerts and emails to your tenant schools.</p>
  </div>
  <a href="<?= e(url('superadmin/notifications')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Center</a>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="sa-card">
            <form method="post" action="<?= e(url('superadmin/notifications')) ?>" id="composeForm">
                <?= csrf_field() ?>
                
                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Target Audience</h6>
                <div class="mb-4">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="target" id="t_all" value="all" checked onchange="toggleSchoolSelect()">
                        <label class="form-check-label fw-bold small" for="t_all">All Schools</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="target" id="t_active" value="active" onchange="toggleSchoolSelect()">
                        <label class="form-check-label fw-bold small" for="t_active">Active Schools Only</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="target" id="t_selected" value="selected" onchange="toggleSchoolSelect()">
                        <label class="form-check-label fw-bold small" for="t_selected">Selected Schools</label>
                    </div>
                </div>

                <div class="mb-4" id="schoolSelectBlock" style="display:none;">
                    <label class="form-label fw-bold small">Select Schools</label>
                    <select name="school_ids[]" class="form-select" multiple size="6">
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text small">Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</div>
                </div>

                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Message Configuration</h6>
                
                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Type</label>
                        <select name="type" class="form-select">
                            <option value="system">System Update</option>
                            <option value="billing">Billing / Invoice</option>
                            <option value="security">Security Alert</option>
                            <option value="maintenance">Maintenance</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Priority</label>
                        <select name="priority" class="form-select">
                            <option value="low">Low</option>
                            <option value="normal" selected>Normal</option>
                            <option value="high">High</option>
                            <option value="critical">Critical</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Channel</label>
                        <select name="channel" class="form-select">
                            <option value="in_app">In-App Notification</option>
                            <option value="email">Email</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">Notification Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required placeholder="E.g., Scheduled Maintenance Downtime">
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small">Message Content <span class="text-danger">*</span></label>
                    <textarea name="message" class="form-control" rows="6" required placeholder="Write your notification message here..."></textarea>
                    <div class="form-text small">Supports variables: {school_name}, {owner_name}</div>
                </div>
                
                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Delivery Schedule</h6>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Schedule Date/Time (Optional)</label>
                    <input type="datetime-local" name="scheduled_at" class="form-control" style="max-width: 300px;">
                    <div class="form-text small">Leave blank to send immediately.</div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                    <button type="button" class="btn btn-outline-secondary fw-bold" onclick="document.getElementById('composeForm').reset();toggleSchoolSelect();">Clear Form</button>
                    <button type="submit" class="btn btn-primary fw-bold px-5" style="border-radius:8px;">Dispatch Notification</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="sa-card bg-light">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Notification Guidelines</h6>
            <ul class="small mb-0 ps-3 text-muted" style="line-height:1.6;">
                <li class="mb-2"><strong>Tenant Isolation:</strong> Notifications are securely routed only to the specified target schools.</li>
                <li class="mb-2"><strong>Critical Priority:</strong> Use "Critical" priority for security breaches or immediate data-loss warnings. These will bypass standard do-not-disturb settings.</li>
                <li class="mb-2"><strong>In-App vs Email:</strong> In-App messages appear in the school portal's bell icon. Emails will generate an actual email dispatch to the school owner.</li>
                <li><strong>Scheduled Delivery:</strong> Use the schedule feature for planned maintenance alerts rather than sending them days in advance.</li>
            </ul>
        </div>
    </div>
</div>

<script>
function toggleSchoolSelect() {
    const isSelected = document.getElementById('t_selected').checked;
    document.getElementById('schoolSelectBlock').style.display = isSelected ? 'block' : 'none';
}
</script>
