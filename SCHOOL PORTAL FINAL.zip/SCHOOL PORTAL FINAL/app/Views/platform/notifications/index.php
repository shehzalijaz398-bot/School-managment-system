<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .badge-status-delivered { background: #dbeafe; color: #1e40af; }
  .badge-status-read { background: #dcfce7; color: #166534; }
  .badge-status-failed { background: #fee2e2; color: #991b1b; }
  .badge-status-scheduled { background: #fef3c7; color: #b45309; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Notification Center</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Track system notifications and broadcast custom alerts to schools.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('superadmin/notifications/create')) ?>" class="btn btn-primary fw-bold" style="border-radius:8px;"><i data-lucide="bell-ring" style="width:16px;height:16px;"></i> Compose Notification</a>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="radio"></i></div>
        <div><div class="sa-stat-label">Total Sent</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="send"></i></div>
        <div><div class="sa-stat-label">Delivered</div><div class="sa-stat-val"><?= number_format($analytics['delivered']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="check-check"></i></div>
        <div><div class="sa-stat-label">Read</div><div class="sa-stat-val"><?= number_format($analytics['read']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="alert-triangle"></i></div>
        <div><div class="sa-stat-label">Failed</div><div class="sa-stat-val"><?= number_format($analytics['failed']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="clock"></i></div>
        <div><div class="sa-stat-label">Scheduled</div><div class="sa-stat-val"><?= number_format($analytics['scheduled']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/notifications')) ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small fw-bold">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Search title or content..." value="<?= e($filters['q']??'') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold">Status</label>
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="delivered" <?= ($filters['status']??'')=='delivered'?'selected':'' ?>>Delivered</option>
                    <option value="read" <?= ($filters['status']??'')=='read'?'selected':'' ?>>Read</option>
                    <option value="failed" <?= ($filters['status']??'')=='failed'?'selected':'' ?>>Failed</option>
                    <option value="scheduled" <?= ($filters['status']??'')=='scheduled'?'selected':'' ?>>Scheduled</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold">Type</label>
                <select name="type" class="form-select">
                    <option value="">All Types</option>
                    <option value="system" <?= ($filters['type']??'')=='system'?'selected':'' ?>>System</option>
                    <option value="billing" <?= ($filters['type']??'')=='billing'?'selected':'' ?>>Billing</option>
                    <option value="security" <?= ($filters['type']??'')=='security'?'selected':'' ?>>Security</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Notification Detail</th>
                    <th>Target</th>
                    <th>Type / Priority</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($notifications as $n): ?>
                <tr>
                    <td class="ps-4" style="max-width:300px;">
                        <div class="fw-bold text-dark text-truncate" title="<?= e($n['title']) ?>"><?= e($n['title']) ?></div>
                        <div class="small text-muted text-truncate" title="<?= e($n['message']) ?>"><?= e($n['message']) ?></div>
                    </td>
                    <td>
                        <?php if($n['school_name']): ?>
                            <div class="fw-bold text-primary"><i data-lucide="building" style="width:12px;height:12px;"></i> <?= e($n['school_name']) ?></div>
                        <?php endif; ?>
                        <?php if($n['user_name']): ?>
                            <div class="small text-muted"><i data-lucide="user" style="width:12px;height:12px;"></i> <?= e($n['user_name']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark border text-uppercase me-1"><?= e($n['type']) ?></span>
                        <?php if($n['priority'] === 'critical'): ?>
                            <span class="badge bg-danger text-uppercase">Critical</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php 
                            $stat = $n['status'];
                            if ($n['is_read'] && $stat === 'delivered') $stat = 'read';
                        ?>
                        <span class="badge badge-status-<?= e($stat) ?> border text-uppercase" style="border-color:currentColor!important; padding:5px 8px; font-size:0.75rem;">
                            <?= e($stat) ?>
                        </span>
                        <?php if($stat === 'failed'): ?>
                            <div class="small text-danger mt-1" style="max-width:150px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="<?= e($n['failed_reason']) ?>"><?= e($n['failed_reason']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="small text-muted">
                        <?= $n['scheduled_at'] && strtotime($n['scheduled_at']) > time() ? '<span class="text-warning fw-bold">Scheduled:</span><br>' : '' ?>
                        <?= date('M d, Y H:i', strtotime($n['scheduled_at'] ?? $n['created_at'])) ?>
                    </td>
                    <td class="text-end pe-4">
                        <?php if($stat === 'failed'): ?>
                            <form method="post" action="<?= e(url('superadmin/notifications/'.$n['id'].'/retry')) ?>">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-outline-danger btn-sm fw-bold">Retry</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($notifications)): ?>
                <tr><td colspan="6" class="text-center py-5 text-muted">No notifications found matching your criteria.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
