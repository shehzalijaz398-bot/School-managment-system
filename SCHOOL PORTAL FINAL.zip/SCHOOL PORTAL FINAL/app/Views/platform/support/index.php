<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .filter-bar { background: var(--sa-card); padding: 15px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .badge-status-open { background: #fee2e2; color: #991b1b; }
  .badge-status-in_progress { background: #dbeafe; color: #1e40af; }
  .badge-status-waiting { background: #fef3c7; color: #b45309; }
  .badge-status-resolved { background: #dcfce7; color: #166534; }
  .badge-status-closed { background: #f1f5f9; color: #475569; }
  
  .badge-priority-urgent { background: #dc2626; color: white; }
  .badge-priority-high { background: #f97316; color: white; }
  .badge-priority-medium { background: #3b82f6; color: white; }
  .badge-priority-low { background: #94a3b8; color: white; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Support & Helpdesk</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage platform-level technical and billing support for tenant schools.</p>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createTicketModal" style="border-radius:8px;"><i data-lucide="plus" style="width:16px;height:16px;"></i> Create Ticket for School</button>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="inbox"></i></div>
        <div><div class="sa-stat-label">Total Tickets</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="alert-circle"></i></div>
        <div><div class="sa-stat-label">Open</div><div class="sa-stat-val"><?= number_format($analytics['open']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-warning"><i data-lucide="clock"></i></div>
        <div><div class="sa-stat-label">Pending/Waiting</div><div class="sa-stat-val"><?= number_format($analytics['pending']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="activity"></i></div>
        <div><div class="sa-stat-label">In Progress</div><div class="sa-stat-val"><?= number_format($analytics['in_progress']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
        <div><div class="sa-stat-label">Resolved</div><div class="sa-stat-val"><?= number_format($analytics['resolved']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="filter-bar border-0 border-bottom mb-0 p-3" style="border-radius:var(--sa-radius) var(--sa-radius) 0 0;">
        <form method="get" action="<?= e(url('superadmin/support')) ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small fw-bold">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Search ticket # or subject..." value="<?= e($filters['q']??'') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">Status</label>
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="open" <?= ($filters['status']??'')=='open'?'selected':'' ?>>Open</option>
                    <option value="in_progress" <?= ($filters['status']??'')=='in_progress'?'selected':'' ?>>In Progress</option>
                    <option value="waiting" <?= ($filters['status']??'')=='waiting'?'selected':'' ?>>Waiting on School</option>
                    <option value="resolved" <?= ($filters['status']??'')=='resolved'?'selected':'' ?>>Resolved</option>
                    <option value="closed" <?= ($filters['status']??'')=='closed'?'selected':'' ?>>Closed</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-bold">Priority</label>
                <select name="priority" class="form-select">
                    <option value="">All Priorities</option>
                    <option value="urgent" <?= ($filters['priority']??'')=='urgent'?'selected':'' ?>>Urgent</option>
                    <option value="high" <?= ($filters['priority']??'')=='high'?'selected':'' ?>>High</option>
                    <option value="medium" <?= ($filters['priority']??'')=='medium'?'selected':'' ?>>Medium</option>
                    <option value="low" <?= ($filters['priority']??'')=='low'?'selected':'' ?>>Low</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold">School</label>
                <select name="school_id" class="form-select">
                    <option value="">All Schools</option>
                    <?php foreach($schools as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= ($filters['school_id']??'')==$s['id']?'selected':'' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 fw-bold">Filter</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th class="ps-4">Ticket</th>
                    <th>School</th>
                    <th>Category</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Assigned To</th>
                    <th>Last Updated</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($tickets as $t): ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold text-dark"><?= e($t['ticket_number']) ?></div>
                        <div class="small text-muted" style="max-width:200px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= e($t['subject']) ?></div>
                    </td>
                    <td>
                        <div class="fw-bold"><?= e($t['school_name']) ?></div>
                    </td>
                    <td><span class="badge bg-light text-dark border text-uppercase"><?= e(str_replace('_', ' ', $t['category'])) ?></span></td>
                    <td><span class="badge badge-priority-<?= e($t['priority']) ?> text-uppercase"><?= e($t['priority']) ?></span></td>
                    <td><span class="badge badge-status-<?= e($t['status']) ?> border text-uppercase" style="border-color:currentColor!important;"><?= e(str_replace('_', ' ', $t['status'])) ?></span></td>
                    <td><?= e($t['assigned_name'] ?: 'Unassigned') ?></td>
                    <td class="small text-muted">
                        <?= $t['updated_at'] ? date('M d, Y H:i', strtotime($t['updated_at'])) : '-' ?>
                    </td>
                    <td class="text-end pe-4">
                        <a href="<?= e(url('superadmin/support/'.$t['id'])) ?>" class="btn btn-light btn-sm fw-bold">View Ticket</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($tickets)): ?>
                <tr><td colspan="8" class="text-center py-5 text-muted">No tickets found matching your criteria.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Create Ticket Modal -->
<div class="modal fade" id="createTicketModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius:12px; border:none;">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold">Create Platform Support Ticket</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('superadmin/support')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="alert alert-info py-2 small fw-bold mb-3">
                <i data-lucide="info" style="width:16px;height:16px;"></i> This creates a ticket on behalf of a School Owner. They will see it in their School Portal.
            </div>
            
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">School <span class="text-danger">*</span></label>
                    <select name="school_id" class="form-select" required>
                        <option value="">Select School...</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Category</label>
                    <select name="category" class="form-select">
                        <option value="technical">Technical</option>
                        <option value="billing">Billing</option>
                        <option value="account">Account Access</option>
                        <option value="other" selected>Other</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Priority</label>
                    <select name="priority" class="form-select">
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold small">Subject <span class="text-danger">*</span></label>
                    <input type="text" name="subject" class="form-control" required placeholder="Brief summary of the issue...">
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold small">Initial Message / Description <span class="text-danger">*</span></label>
                    <textarea name="message" class="form-control" rows="5" required placeholder="Detailed description of the issue..."></textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Create Ticket</button>
        </div>
      </form>
    </div>
  </div>
</div>
