<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  
  .badge-status-open { background: #fee2e2; color: #991b1b; }
  .badge-status-in_progress { background: #dbeafe; color: #1e40af; }
  .badge-status-waiting { background: #fef3c7; color: #b45309; }
  .badge-status-resolved { background: #dcfce7; color: #166534; }
  .badge-status-closed { background: #f1f5f9; color: #475569; }
  
  .badge-priority-urgent { background: #dc2626; color: white; }
  .badge-priority-high { background: #f97316; color: white; }
  .badge-priority-medium { background: #3b82f6; color: white; }
  .badge-priority-low { background: #94a3b8; color: white; }

  .chat-thread { display: flex; flex-direction: column; gap: 1.5rem; }
  .chat-msg { display: flex; flex-direction: column; max-width: 85%; }
  .msg-school { align-self: flex-start; }
  .msg-platform { align-self: flex-end; }
  .msg-internal { align-self: center; max-width: 95%; width: 100%; }

  .msg-bubble { padding: 1rem 1.2rem; border-radius: 12px; font-size: 0.95rem; line-height: 1.5; position: relative; }
  .msg-school .msg-bubble { background: #f1f5f9; color: #1e293b; border-bottom-left-radius: 2px; }
  .msg-platform .msg-bubble { background: var(--sa-primary); color: white; border-bottom-right-radius: 2px; }
  .msg-internal .msg-bubble { background: #fffbeb; color: #92400e; border: 1px dashed #fcd34d; border-radius: 8px; }

  .msg-meta { font-size: 0.75rem; color: var(--sa-muted); margin-bottom: 4px; display:flex; align-items:center; gap:8px; }
  .msg-school .msg-meta { justify-content: flex-start; }
  .msg-platform .msg-meta { justify-content: flex-end; }
  .msg-internal .msg-meta { justify-content: flex-start; font-weight: bold; color: #b45309; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;"><?= e($ticket['ticket_number']) ?></h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;"><?= e($ticket['subject']) ?></p>
  </div>
  <a href="<?= e(url('superadmin/support')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Tickets</a>
</div>

<div class="row">
    <!-- Main Thread -->
    <div class="col-lg-8">
        <div class="sa-card p-4">
            <h6 class="fw-bold text-muted small text-uppercase mb-4">Conversation History</h6>
            
            <div class="chat-thread mb-5">
                <?php foreach($messages as $m): ?>
                    <?php if($m['is_internal']): ?>
                        <div class="chat-msg msg-internal">
                            <div class="msg-meta">
                                <i data-lucide="lock" style="width:12px;height:12px;"></i> INTERNAL NOTE by <?= e($m['sender_name']) ?> &bull; <?= date('M d, H:i', strtotime($m['created_at'])) ?>
                            </div>
                            <div class="msg-bubble"><?= nl2br(e($m['message'])) ?></div>
                        </div>
                    <?php elseif($m['sender_type'] === 'school'): ?>
                        <div class="chat-msg msg-school">
                            <div class="msg-meta">
                                <span class="fw-bold text-dark"><?= e($m['sender_name']) ?> (School)</span> &bull; <?= date('M d, H:i', strtotime($m['created_at'])) ?>
                            </div>
                            <div class="msg-bubble"><?= nl2br(e($m['message'])) ?></div>
                        </div>
                    <?php else: ?>
                        <div class="chat-msg msg-platform">
                            <div class="msg-meta">
                                <?= date('M d, H:i', strtotime($m['created_at'])) ?> &bull; <span class="fw-bold text-dark">You (<?= e($m['sender_name']) ?>)</span>
                            </div>
                            <div class="msg-bubble shadow-sm"><?= nl2br(e($m['message'])) ?></div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php if(empty($messages)): ?>
                    <div class="text-center text-muted py-4">No messages yet.</div>
                <?php endif; ?>
            </div>
            
            <hr class="mb-4">
            
            <form method="post" action="<?= e(url('superadmin/support/'.$ticket['id'].'/reply')) ?>">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Reply or add Internal Note</label>
                    <textarea name="message" rows="4" class="form-control" required placeholder="Type your message here..."></textarea>
                </div>
                <div class="row g-3 align-items-center mb-4">
                    <div class="col-md-4">
                        <select name="status" class="form-select form-select-sm fw-bold">
                            <option value="in_progress" <?= $ticket['status']=='in_progress'?'selected':'' ?>>Set Status: In Progress</option>
                            <option value="waiting" <?= $ticket['status']=='waiting'?'selected':'' ?>>Set Status: Waiting on School</option>
                            <option value="resolved" <?= $ticket['status']=='resolved'?'selected':'' ?>>Set Status: Resolved</option>
                            <option value="closed" <?= $ticket['status']=='closed'?'selected':'' ?>>Set Status: Closed</option>
                            <option value="open" <?= $ticket['status']=='open'?'selected':'' ?>>Set Status: Open</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select name="assign_to" class="form-select form-select-sm fw-bold">
                            <option value="">Assign To...</option>
                            <?php foreach($agents as $a): ?>
                                <option value="<?= $a['id'] ?>" <?= $ticket['assigned_to']==$a['id']?'selected':'' ?>><?= e($a['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="form-check form-switch d-inline-block text-start me-3">
                            <input class="form-check-input" type="checkbox" name="is_internal" value="1" id="is_internal">
                            <label class="form-check-label small fw-bold text-danger" for="is_internal" title="Hidden from school">Internal Note</label>
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-primary fw-bold px-4" style="border-radius:8px;">Send Message</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Sidebar Meta -->
    <div class="col-lg-4">
        <div class="sa-card p-4">
            <h6 class="fw-bold text-muted small text-uppercase mb-4">Ticket Details</h6>
            
            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Status</div>
                <span class="badge badge-status-<?= e($ticket['status']) ?> text-uppercase border" style="border-color:currentColor!important; padding:6px 12px; font-size:0.75rem;"><?= e(str_replace('_', ' ', $ticket['status'])) ?></span>
            </div>
            
            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Priority</div>
                <span class="badge badge-priority-<?= e($ticket['priority']) ?> text-uppercase" style="padding:6px 12px; font-size:0.75rem;"><?= e($ticket['priority']) ?></span>
            </div>

            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Category</div>
                <div class="fw-bold text-dark text-uppercase"><?= e(str_replace('_', ' ', $ticket['category'])) ?></div>
            </div>

            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">School</div>
                <div class="fw-bold text-dark"><?= e($ticket['school_name']) ?></div>
                <a href="<?= e(url('superadmin/schools/'.$ticket['school_id'])) ?>" class="small text-decoration-none">View School Profile &rarr;</a>
            </div>

            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Assigned Agent</div>
                <div class="fw-bold text-dark"><?= e($ticket['assigned_name'] ?: 'Unassigned') ?></div>
            </div>

            <div class="mb-3 border-bottom pb-3">
                <div class="small text-muted fw-bold text-uppercase mb-1">Created At</div>
                <div class="small fw-bold text-dark"><?= date('F d, Y H:i A', strtotime($ticket['created_at'])) ?></div>
            </div>

            <div class="mb-0">
                <div class="small text-muted fw-bold text-uppercase mb-1">Last Update</div>
                <div class="small fw-bold text-dark"><?= $ticket['updated_at'] ? date('F d, Y H:i A', strtotime($ticket['updated_at'])) : '-' ?></div>
            </div>
        </div>
        
        <div class="sa-card p-4 bg-light">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Impersonation Setup</h6>
            <p class="small text-muted mb-3">If you need to reproduce this issue directly, you can securely impersonate the School Owner account. This action is heavily audited.</p>
            <form method="post" action="<?= e(url('superadmin/schools/'.$ticket['school_id'].'/impersonate')) ?>">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-outline-danger btn-sm fw-bold w-100"><i data-lucide="shield-alert" style="width:14px;height:14px;"></i> Impersonate School</button>
            </form>
        </div>
    </div>
</div>
