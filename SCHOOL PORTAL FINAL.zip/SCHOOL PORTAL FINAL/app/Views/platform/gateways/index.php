<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .gateway-logo { width: 48px; height: 48px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 900; background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Payment Gateways</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Configure SaaS subscription payment processors and API keys securely.</p>
  </div>
</div>

<div class="row">
    <?php foreach($gateways as $g): ?>
    <?php 
        $creds = $g['credentials'] ? json_decode($g['credentials'], true) : [];
        $methods = $g['supported_methods'] ? json_decode($g['supported_methods'], true) : [];
    ?>
    <div class="col-lg-6 mb-4">
        <div class="sa-card h-100 <?= $g['status'] == 1 ? 'border-primary' : '' ?>" style="<?= $g['status'] == 1 ? 'box-shadow: 0 4px 12px rgba(13,110,253,0.1);' : '' ?>">
            <div class="d-flex justify-content-between align-items-start mb-4 border-bottom pb-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="gateway-logo">
                        <?= substr($g['name'], 0, 1) ?>
                    </div>
                    <div>
                        <h5 class="fw-bold text-dark mb-1"><?= e($g['name']) ?></h5>
                        <div class="d-flex gap-2 align-items-center">
                            <?php if($g['status'] == 1): ?>
                                <span class="badge bg-success" style="font-size:0.65rem; text-transform:uppercase;">Active</span>
                                <span class="badge bg-<?= $g['mode'] === 'live' ? 'danger' : 'warning text-dark' ?>" style="font-size:0.65rem; text-transform:uppercase;">
                                    <?= e($g['mode']) ?> MODE
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary" style="font-size:0.65rem; text-transform:uppercase;">Disabled</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-light btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#editGatewayModal<?= $g['id'] ?>">Configure</button>
                    <?php if($g['status'] == 1): ?>
                        <form method="post" action="<?= e(url('superadmin/gateways/'.$g['id'].'/test')) ?>" style="margin:0;">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-outline-primary btn-sm fw-bold" title="Ping API"><i data-lucide="zap" style="width:14px;height:14px;"></i></button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="row">
                <div class="col-6 mb-3">
                    <span class="d-block small text-muted text-uppercase fw-bold mb-1">Currency</span>
                    <span class="fw-bold text-dark font-monospace"><?= e($g['currency']) ?></span>
                </div>
                <div class="col-6 mb-3">
                    <span class="d-block small text-muted text-uppercase fw-bold mb-1">Webhook Secret</span>
                    <?php if(!empty($g['webhook_secret'])): ?>
                        <span class="badge bg-light text-success border border-success"><i data-lucide="check" style="width:12px;height:12px;" class="me-1"></i> Configured</span>
                    <?php else: ?>
                        <span class="badge bg-light text-muted border">Not Set</span>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <span class="d-block small text-muted text-uppercase fw-bold mb-1">Supported Methods</span>
                    <div class="d-flex gap-1 flex-wrap">
                        <?php foreach($methods as $m): ?>
                            <span class="badge bg-light text-dark border"><?= e(strtoupper(str_replace('_', ' ', $m))) ?></span>
                        <?php endforeach; ?>
                        <?php if(empty($methods)): ?>
                            <span class="small text-muted">None specified</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal fade" id="editGatewayModal<?= $g['id'] ?>" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <form method="post" action="<?= e(url('superadmin/gateways/'.$g['id'].'/update')) ?>" class="modal-content">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom-0 pb-0">
                    <h5 class="modal-title fw-bold">Configure <?= e($g['name']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    
                    <div class="row mb-4 bg-light p-3 rounded mx-0 border">
                        <div class="col-md-6 d-flex align-items-center">
                            <div class="form-check form-switch mb-0">
                                <input class="form-check-input" type="checkbox" name="status" id="status<?= $g['id'] ?>" value="1" <?= $g['status'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold" for="status<?= $g['id'] ?>">Enable Gateway</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-muted">Environment Mode</label>
                            <select name="mode" class="form-select fw-bold <?= $g['mode'] === 'live' ? 'border-danger text-danger' : 'border-warning text-warning' ?>">
                                <option value="test" <?= $g['mode'] === 'test' ? 'selected' : '' ?>>TEST / SANDBOX</option>
                                <option value="live" <?= $g['mode'] === 'live' ? 'selected' : '' ?>>LIVE / PRODUCTION</option>
                            </select>
                        </div>
                    </div>
                    
                    <h6 class="fw-bold mb-3 border-bottom pb-2">API Credentials</h6>
                    <div class="alert alert-info py-2 px-3 small border-0 bg-light text-muted d-flex mb-4">
                        <i data-lucide="shield" style="width:16px;height:16px;" class="me-2 flex-shrink-0 mt-1"></i>
                        <div>Credentials are encrypted. Leave fields blank to keep existing secrets unchanged. Ensure you paste the correct keys matching your selected Mode (Test/Live).</div>
                    </div>
                    
                    <?php if($g['gateway_key'] === 'stripe'): ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Publishable Key</label>
                                <input type="text" name="credentials[public_key]" class="form-control font-monospace" placeholder="<?= !empty($creds['public_key']) ? 'pk_...' : '' ?>" value="<?= e($creds['public_key'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Secret Key <span class="text-danger">*</span></label>
                                <input type="password" name="credentials[secret_key]" class="form-control font-monospace" placeholder="<?= !empty($creds['secret_key']) ? '••••••••••••••••' : 'sk_...' ?>">
                            </div>
                        </div>
                    <?php elseif($g['gateway_key'] === 'paypal'): ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Client ID</label>
                                <input type="text" name="credentials[client_id]" class="form-control font-monospace" placeholder="<?= !empty($creds['client_id']) ? '••••••••••••••••' : '' ?>" value="<?= e($creds['client_id'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Client Secret <span class="text-danger">*</span></label>
                                <input type="password" name="credentials[client_secret]" class="form-control font-monospace" placeholder="<?= !empty($creds['client_secret']) ? '••••••••••••••••' : '' ?>">
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">API Key / Public Key</label>
                                <input type="text" name="credentials[api_key]" class="form-control font-monospace" placeholder="<?= !empty($creds['api_key']) ? '••••••••••••••••' : '' ?>" value="<?= e($creds['api_key'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">API Secret / Private Key <span class="text-danger">*</span></label>
                                <input type="password" name="credentials[api_secret]" class="form-control font-monospace" placeholder="<?= !empty($creds['api_secret']) ? '••••••••••••••••' : '' ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <h6 class="fw-bold mb-3 mt-5 border-bottom pb-2">Operational Settings</h6>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Default Processing Currency</label>
                            <input type="text" name="currency" class="form-control text-uppercase font-monospace fw-bold" value="<?= e($g['currency']) ?>" maxlength="3" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Supported Payment Methods</label>
                            <input type="text" name="supported_methods" class="form-control" value="<?= e(implode(', ', $methods)) ?>" placeholder="card, bank_transfer, upi">
                            <div class="form-text small">Comma separated. Determines what UI options render on the checkout page.</div>
                        </div>
                    </div>
                    
                    <div class="mb-2">
                        <label class="form-label fw-bold small">Webhook Signing Secret</label>
                        <input type="password" name="webhook_secret" class="form-control font-monospace" placeholder="<?= !empty($g['webhook_secret']) ? '••••••••••••••••' : 'whsec_...' ?>">
                        <div class="form-text small">Required for verifying incoming webhooks (e.g. payment success, subscription canceled).</div>
                    </div>
                    
                </div>
                <div class="modal-footer border-top-0 pt-0">
                    <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-dark fw-bold px-4">Save Configuration</button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
