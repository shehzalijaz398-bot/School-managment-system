<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Edit Coupon: <?= e($coupon['code']) ?></h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Update promotional settings and limitations.</p>
  </div>
  <a href="<?= e(url('superadmin/coupons')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back</a>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="sa-card">
            <form method="post" action="<?= e(url('superadmin/coupons/'.$coupon['id'].'/update')) ?>">
                <?= csrf_field() ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Coupon Code <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control font-monospace fw-bold text-uppercase" value="<?= e($coupon['code']) ?>" required>
                    </div>
                    <div class="col-md-6 mt-md-0 mt-3 d-flex align-items-end">
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" name="status" id="status" value="1" <?= $coupon['status'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold small" for="status">Active (Can be applied)</label>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small">Description</label>
                    <input type="text" name="description" class="form-control" value="<?= e($coupon['description']) ?>">
                </div>

                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Discount Rules</h6>
                <div class="row mb-4">
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Discount Type</label>
                        <select name="type" class="form-select fw-bold">
                            <option value="percentage" <?= $coupon['type']==='percentage'?'selected':'' ?>>Percentage (%)</option>
                            <option value="fixed" <?= $coupon['type']==='fixed'?'selected':'' ?>>Fixed Amount ($)</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Discount Amount <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="amount" class="form-control" value="<?= e($coupon['amount']) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Min Subscription ($)</label>
                        <input type="number" step="0.01" name="min_subscription_amount" class="form-control" value="<?= e($coupon['min_subscription_amount']) ?>">
                    </div>
                </div>

                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Validity & Limits</h6>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Valid From</label>
                        <input type="datetime-local" name="valid_from" class="form-control" value="<?= $coupon['valid_from'] ? date('Y-m-d\TH:i', strtotime($coupon['valid_from'])) : '' ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Valid Until</label>
                        <input type="datetime-local" name="valid_until" class="form-control" value="<?= $coupon['valid_until'] ? date('Y-m-d\TH:i', strtotime($coupon['valid_until'])) : '' ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Global Usage Limit</label>
                        <input type="number" name="usage_limit" class="form-control" value="<?= e($coupon['usage_limit']) ?>" placeholder="Leave blank for unlimited">
                        <div class="form-text small">Max number of times this coupon can be used across all schools. (Currently used: <?= $coupon['used_count'] ?>)</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Per-School Limit</label>
                        <input type="number" name="per_school_limit" class="form-control" value="<?= e($coupon['per_school_limit']) ?>" min="1">
                        <div class="form-text small">How many times a single school can use this coupon.</div>
                    </div>
                </div>

                <h6 class="fw-bold text-muted small text-uppercase mb-3 border-bottom pb-2">Applicable Plans (Optional)</h6>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Restrict to Specific Plans</label>
                    <select name="plans[]" class="form-select" multiple size="4">
                        <?php foreach($plans as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= in_array($p['id'], $coupon['plans']) ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text small">Leave unselected to allow on all plans. Hold Ctrl/Cmd to select multiple.</div>
                </div>

                <div class="d-flex justify-content-between pt-3 border-top">
                    <button type="button" class="btn btn-outline-danger fw-bold" onclick="if(confirm('Delete this coupon? This cannot be undone.')){ document.getElementById('deleteForm').submit(); }">Delete</button>
                    <button type="submit" class="btn btn-dark fw-bold px-4" style="border-radius:8px;">Save Changes</button>
                </div>
            </form>
            
            <form id="deleteForm" method="post" action="<?= e(url('superadmin/coupons/'.$coupon['id'].'/delete')) ?>">
                <?= csrf_field() ?>
            </form>
        </div>
    </div>
</div>
