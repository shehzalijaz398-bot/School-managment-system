<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Coupon Usage: <?= e($coupon['code']) ?></h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Track which schools have redeemed this promotional code.</p>
  </div>
  <a href="<?= e(url('superadmin/coupons')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Coupons</a>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="sa-card bg-light">
            <h6 class="fw-bold text-muted small text-uppercase mb-3">Coupon Details</h6>
            <div class="mb-3">
                <span class="small text-muted d-block">Code</span>
                <span class="fw-bold text-dark font-monospace fs-5"><?= e($coupon['code']) ?></span>
            </div>
            <div class="mb-3">
                <span class="small text-muted d-block">Discount</span>
                <span class="fw-bold text-dark fs-5"><?= $coupon['type'] === 'percentage' ? e(number_format($coupon['amount'])) . '%' : '$' . e(number_format($coupon['amount'], 2)) ?> OFF</span>
            </div>
            <div class="mb-3">
                <span class="small text-muted d-block">Usage Stats</span>
                <span class="fw-bold text-dark fs-5"><?= number_format($coupon['used_count']) ?> / <?= $coupon['usage_limit'] ? number_format($coupon['usage_limit']) : '&infin;' ?></span>
            </div>
        </div>
    </div>
    
    <div class="col-lg-8">
        <div class="sa-card p-0">
            <div class="p-4 border-bottom">
                <h6 class="fw-bold m-0">Recent Redemptions</h6>
                <p class="small text-muted mb-0">Showing the latest 50 times this coupon was applied to an invoice.</p>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>School</th>
                            <th>Invoice ID</th>
                            <th class="text-end pe-4">Discount Applied</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($usages as $u): ?>
                        <tr>
                            <td class="ps-4 small fw-bold text-muted"><?= date('M d, Y H:i', strtotime($u['created_at'])) ?></td>
                            <td><div class="fw-bold text-dark"><?= e($u['school_name']) ?></div></td>
                            <td>
                                <?php if($u['invoice_id']): ?>
                                    <span class="font-monospace text-muted">#<?= str_pad($u['invoice_id'], 6, '0', STR_PAD_LEFT) ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4 fw-bold text-success">
                                -$<?= e(number_format($u['discount_amount'], 2)) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($usages)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-5">This coupon has not been used yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
