<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .badge-status-active { background: #dcfce7; color: #166534; }
  .badge-status-disabled { background: #f1f5f9; color: #475569; }
  .badge-status-expired, .badge-status-exhausted { background: #fee2e2; color: #991b1b; }
  .badge-status-scheduled { background: #fef3c7; color: #92400e; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Coupons & Discounts</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage promotional codes and billing discounts for schools.</p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('superadmin/coupons/create')) ?>" class="btn btn-primary fw-bold" style="border-radius:8px;"><i data-lucide="plus" style="width:16px;height:16px;"></i> Create Coupon</a>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="ticket"></i></div>
        <div><div class="sa-stat-label">Total Coupons</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
        <div><div class="sa-stat-label">Active</div><div class="sa-stat-val"><?= number_format($analytics['active']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-danger"><i data-lucide="x-circle"></i></div>
        <div><div class="sa-stat-label">Exhausted</div><div class="sa-stat-val"><?= number_format($analytics['exhausted']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-primary"><i data-lucide="tag"></i></div>
        <div><div class="sa-stat-label">Total Uses</div><div class="sa-stat-val"><?= number_format($analytics['total_used']) ?></div></div>
    </div>
</div>

<div class="sa-card p-0">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4">Code / Status</th>
                    <th>Discount</th>
                    <th>Usage Limit</th>
                    <th>Validity</th>
                    <th class="text-end pe-4">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($coupons as $c): ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold text-dark font-monospace fs-5"><?= e($c['code']) ?></div>
                        <div class="mt-1">
                            <span class="badge badge-status-<?= e($c['computed_status']) ?> border text-uppercase" style="border-color:currentColor!important; font-size:0.65rem;">
                                <?= e($c['computed_status']) ?>
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="fw-bold text-dark">
                            <?= $c['type'] === 'percentage' ? e(number_format($c['amount'])) . '%' : '$' . e(number_format($c['amount'], 2)) ?> OFF
                        </div>
                        <?php if($c['min_subscription_amount'] > 0): ?>
                            <div class="small text-muted">Min: $<?= e(number_format($c['min_subscription_amount'], 2)) ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="fw-bold text-dark"><?= number_format($c['used_count']) ?> / <?= $c['usage_limit'] ? number_format($c['usage_limit']) : '&infin;' ?></div>
                        <div class="small text-muted">Limit: <?= $c['per_school_limit'] ?> per school</div>
                    </td>
                    <td class="small">
                        <?php if($c['valid_from'] || $c['valid_until']): ?>
                            <div class="text-muted"><span class="fw-bold">From:</span> <?= $c['valid_from'] ? date('M d, Y', strtotime($c['valid_from'])) : 'Anytime' ?></div>
                            <div class="text-muted"><span class="fw-bold">Until:</span> <?= $c['valid_until'] ? date('M d, Y', strtotime($c['valid_until'])) : 'Forever' ?></div>
                        <?php else: ?>
                            <span class="text-muted">Lifetime</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end pe-4">
                        <a href="<?= e(url('superadmin/coupons/'.$c['id'])) ?>" class="btn btn-light btn-sm fw-bold">Usage</a>
                        <a href="<?= e(url('superadmin/coupons/'.$c['id'].'/edit')) ?>" class="btn btn-light btn-sm fw-bold">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($coupons)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-5">No coupons found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
