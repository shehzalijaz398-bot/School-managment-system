<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
  .superadmin-auth-shell {
    min-height: 85vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem 1rem;
  }
  .superadmin-login-card {
    max-width: 440px;
    width: 100%;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    box-shadow: 0 20px 40px -10px rgba(15, 23, 42, 0.12), 0 1px 3px rgba(0,0,0,0.05);
    padding: 2.5rem;
    position: relative;
    overflow: hidden;
  }
  .superadmin-top-stripe {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #1e40af 0%, #0284c7 50%, #38bdf8 100%);
  }
  .superadmin-badge-icon {
    width: 58px;
    height: 58px;
    border-radius: 14px;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    color: #38bdf8;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    box-shadow: 0 8px 16px rgba(15, 23, 42, 0.2);
  }
</style>

<div class="superadmin-auth-shell">
  <div class="superadmin-login-card">
    <div class="superadmin-top-stripe"></div>

    <div class="text-center mb-4">
      <div class="superadmin-badge-icon mb-3">
        <i class="bi bi-shield-lock-fill"></i>
      </div>
      <div class="text-uppercase fw-bold text-primary small" style="letter-spacing: 0.1em; font-size: 11px;">
        SaaS Platform Control Plane
      </div>
      <h1 class="h4 fw-bold text-dark mt-1 mb-1">Super Admin Console</h1>
      <p class="text-muted small mb-0">Authorized global system operators and SaaS management only</p>
    </div>

    <!-- Flash Messages -->
    <?php require base_path('app/Views/partials/flash.php'); ?>

    <form method="post" action="<?= e(url('superadmin/login')) ?>" id="superadminLoginForm">
      <?= csrf_field() ?>

      <div class="mb-3">
        <label for="email" class="form-label small fw-bold text-secondary mb-1">Administrator Email</label>
        <div class="input-group">
          <span class="input-group-text bg-light border-end-0 text-muted">
            <i class="bi bi-person-badge"></i>
          </span>
          <input type="email" name="email" id="email" class="form-control border-start-0" 
                 placeholder="admin@platform.local" 
                 value="<?= e((string) old('email', '')) ?>" 
                 required autofocus style="height: 44px; font-size: 14px;">
        </div>
      </div>

      <div class="mb-4">
        <label for="password" class="form-label small fw-bold text-secondary mb-1">Master Password</label>
        <div class="input-group">
          <span class="input-group-text bg-light border-end-0 text-muted">
            <i class="bi bi-key-fill"></i>
          </span>
          <input type="password" name="password" id="password" class="form-control border-start-0" 
                 placeholder="Enter secure master key" required style="height: 44px; font-size: 14px;">
        </div>
      </div>

      <button type="submit" class="btn btn-dark w-100 py-2.5 fw-bold d-flex align-items-center justify-content-center gap-2 shadow-sm" style="border-radius: 8px;">
        <i class="bi bi-box-arrow-in-right"></i>
        <span>Authenticate to Platform Control Panel</span>
      </button>
    </form>

    <div class="mt-4 pt-3 border-top text-center">
      <div class="small text-muted mb-2">School Principal, Teacher, or Student?</div>
      <a href="<?= e(url('login')) ?>" class="btn btn-sm btn-outline-secondary w-100 fw-semibold rounded-pill py-2">
        <i class="bi bi-arrow-left me-1"></i> Switch to School Portal Sign In
      </a>
    </div>

    <div class="text-center mt-3">
      <span class="badge bg-light text-muted border small font-monospace">
        <i class="bi bi-lock me-1 text-success"></i> Strict Multi-Tenant Isolation Enforced
      </span>
    </div>
  </div>
</div>
