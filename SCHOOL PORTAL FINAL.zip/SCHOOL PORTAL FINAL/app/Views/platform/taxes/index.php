<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Tax & Regional Settings</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Configure default locale settings and global tax rules for SaaS subscription billing.</p>
  </div>
  <button type="button" class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createTaxModal">
    <i data-lucide="plus" style="width:16px;height:16px;" class="me-1"></i> Add Tax Rule
  </button>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="sa-card">
            <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="globe" style="width:20px;height:20px;" class="me-2 text-primary"></i> Regional Defaults</h5>
            <form method="post" action="<?= e(url('superadmin/taxes/settings')) ?>">
                <?= csrf_field() ?>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Default Country</label>
                    <input type="text" name="default_country" class="form-control" value="<?= e($settings['default_country'] ?? 'United States') ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Default Currency (ISO)</label>
                    <input type="text" name="default_currency" class="form-control font-monospace text-uppercase" value="<?= e($settings['default_currency'] ?? 'USD') ?>" maxlength="3">
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">System Timezone</label>
                    <input type="text" name="default_timezone" class="form-control" value="<?= e($settings['default_timezone'] ?? 'UTC') ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Date Format</label>
                    <select name="date_format" class="form-select">
                        <option value="Y-m-d" <?= ($settings['date_format'] ?? '') === 'Y-m-d' ? 'selected' : '' ?>>YYYY-MM-DD (2026-12-31)</option>
                        <option value="d/m/Y" <?= ($settings['date_format'] ?? '') === 'd/m/Y' ? 'selected' : '' ?>>DD/MM/YYYY (31/12/2026)</option>
                        <option value="m/d/Y" <?= ($settings['date_format'] ?? '') === 'm/d/Y' ? 'selected' : '' ?>>MM/DD/YYYY (12/31/2026)</option>
                        <option value="M d, Y" <?= ($settings['date_format'] ?? '') === 'M d, Y' ? 'selected' : '' ?>>MMM DD, YYYY (Dec 31, 2026)</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small text-dark">Number Format</label>
                    <select name="number_format" class="form-select">
                        <option value="1,234.56" <?= ($settings['number_format'] ?? '') === '1,234.56' ? 'selected' : '' ?>>1,234.56 (US/UK)</option>
                        <option value="1.234,56" <?= ($settings['number_format'] ?? '') === '1.234,56' ? 'selected' : '' ?>>1.234,56 (EU)</option>
                    </select>
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-dark fw-bold w-100">Save Regional Settings</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="col-lg-8">
        <div class="sa-card p-0">
            <div class="p-4 border-bottom bg-light">
                <h5 class="fw-bold text-dark mb-1"><i data-lucide="percent" style="width:20px;height:20px;" class="me-2 text-primary"></i> SaaS Tax Rules</h5>
                <p class="small text-muted mb-0 ms-4">These taxes will be automatically calculated and appended to SaaS subscription invoices.</p>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4">Tax Name</th>
                            <th>Rate</th>
                            <th>Type</th>
                            <th>Applicable Regions</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($taxes as $t): ?>
                        <tr class="<?= $t['status'] == 0 ? 'opacity-50' : '' ?>">
                            <td class="ps-4 fw-bold text-dark">
                                <?= e($t['name']) ?>
                                <?php if($t['status'] == 0): ?>
                                    <span class="badge bg-secondary ms-2" style="font-size:0.65rem;">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-dark fs-5"><?= number_format($t['rate'], 2) ?>%</td>
                            <td>
                                <span class="badge bg-<?= $t['type'] === 'inclusive' ? 'info' : 'primary' ?> text-uppercase" style="font-size:0.65rem;">
                                    <?= e($t['type']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if(empty($t['regions'])): ?>
                                    <span class="badge bg-dark text-uppercase" style="font-size:0.65rem;">Global (All)</span>
                                <?php else: ?>
                                    <?php foreach(json_decode($t['regions'], true) as $r): ?>
                                        <span class="badge bg-light text-dark border me-1"><?= e($r) ?></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <button type="button" class="btn btn-light btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#editTaxModal<?= $t['id'] ?>">Edit</button>
                            </td>
                        </tr>
                        
                        <!-- Edit Modal -->
                        <div class="modal fade" id="editTaxModal<?= $t['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form method="post" action="<?= e(url('superadmin/taxes/'.$t['id'].'/update')) ?>" class="modal-content">
                                    <?= csrf_field() ?>
                                    <div class="modal-header border-bottom-0 pb-0">
                                        <h5 class="modal-title fw-bold">Edit Tax Rule</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold small text-dark">Tax Name</label>
                                            <input type="text" name="name" class="form-control fw-bold" value="<?= e($t['name']) ?>" required>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-6">
                                                <label class="form-label fw-bold small text-dark">Rate (%)</label>
                                                <input type="number" step="0.01" name="rate" class="form-control fw-bold" value="<?= e($t['rate']) ?>" required>
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label fw-bold small text-dark">Tax Type</label>
                                                <select name="type" class="form-select fw-bold">
                                                    <option value="exclusive" <?= $t['type'] === 'exclusive' ? 'selected' : '' ?>>Exclusive (+)</option>
                                                    <option value="inclusive" <?= $t['type'] === 'inclusive' ? 'selected' : '' ?>>Inclusive (Included)</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <label class="form-label fw-bold small text-dark">Applicable Regions (Comma separated)</label>
                                            <input type="text" name="regions" class="form-control" value="<?= $t['regions'] ? e(implode(', ', json_decode($t['regions'], true))) : '' ?>" placeholder="US, CA, UK">
                                            <div class="form-text small">Leave blank to apply globally to all schools.</div>
                                        </div>
                                        <div class="form-check form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="status" id="status<?= $t['id'] ?>" value="1" <?= $t['status'] == 1 ? 'checked' : '' ?>>
                                            <label class="form-check-label fw-bold small" for="status<?= $t['id'] ?>">Active</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-top-0 pt-0 d-flex justify-content-between">
                                        <button type="button" class="btn btn-outline-danger fw-bold" onclick="if(confirm('Delete this tax rule?')){ document.getElementById('deleteTaxForm<?= $t['id'] ?>').submit(); }">Delete</button>
                                        <button type="submit" class="btn btn-dark fw-bold px-4">Save Changes</button>
                                    </div>
                                </form>
                                <form id="deleteTaxForm<?= $t['id'] ?>" method="post" action="<?= e(url('superadmin/taxes/'.$t['id'].'/delete')) ?>"><?= csrf_field() ?></form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <?php if(empty($taxes)): ?>
                            <tr><td colspan="5" class="text-center text-muted py-5">No tax rules configured. SaaS invoices will not charge tax.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="p-4 bg-light border-top">
                <p class="small text-muted mb-0 fw-bold"><i data-lucide="info" style="width:14px;height:14px;" class="me-1"></i> Inclusive vs Exclusive</p>
                <p class="small text-muted mb-0 mt-1" style="line-height:1.6;">
                    <strong>Exclusive (+):</strong> Tax is calculated and added ON TOP of the subscription plan price. (e.g., $100 Plan + 10% Tax = $110 Total).<br>
                    <strong>Inclusive:</strong> The subscription plan price already includes the tax. The system calculates the tax portion backward. (e.g., $100 Plan = $90.91 Base + $9.09 Tax).
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Create Tax -->
<div class="modal fade" id="createTaxModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/taxes/store')) ?>" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Create New Tax Rule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Tax Name</label>
                    <input type="text" name="name" class="form-control fw-bold" required placeholder="e.g. VAT, GST, Sales Tax">
                </div>
                <div class="row mb-3">
                    <div class="col-6">
                        <label class="form-label fw-bold small text-dark">Rate (%)</label>
                        <input type="number" step="0.01" name="rate" class="form-control fw-bold" required placeholder="e.g. 15.00">
                    </div>
                    <div class="col-6">
                        <label class="form-label fw-bold small text-dark">Tax Type</label>
                        <select name="type" class="form-select fw-bold">
                            <option value="exclusive">Exclusive (+)</option>
                            <option value="inclusive">Inclusive (Included)</option>
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small text-dark">Applicable Regions (Comma separated)</label>
                    <input type="text" name="regions" class="form-control" placeholder="US, CA, UK">
                    <div class="form-text small">Leave blank to apply globally to all schools.</div>
                </div>
                <div class="form-check form-switch mb-2">
                    <input class="form-check-input" type="checkbox" name="status" id="statusNew" value="1" checked>
                    <label class="form-check-label fw-bold small" for="statusNew">Active</label>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Create Tax Rule</button>
            </div>
        </form>
    </div>
</div>
