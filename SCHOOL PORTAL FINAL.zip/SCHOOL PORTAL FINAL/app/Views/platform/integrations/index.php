<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:40px; height:40px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); }
  
  .integration-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2.5rem; }
  .integration-card { background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.5rem; transition: all 0.2s ease; position: relative; display: flex; flex-direction: column; height: 100%; }
  .integration-card:hover { border-color: #cbd5e1; box-shadow: 0 4px 12px rgba(0,0,0,0.05); transform: translateY(-2px); }
  
  .ic-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.2rem; }
  .ic-icon-placeholder { width: 48px; height: 48px; border-radius: 12px; background: #f1f5f9; display: flex; justify-content: center; align-items: center; color: #64748b; font-weight: 800; font-size: 1.2rem; }
  
  .badge-status-connected { background: #dcfce7; color: #166534; }
  .badge-status-disconnected { background: #f1f5f9; color: #475569; }
  .badge-status-error { background: #fee2e2; color: #991b1b; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Integrations Center</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage third-party API connections, webhooks, and external cloud services.</p>
  </div>
</div>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-dark"><i data-lucide="blocks"></i></div>
        <div><div class="sa-stat-label">Available APIs</div><div class="sa-stat-val"><?= number_format($analytics['total']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-success"><i data-lucide="link"></i></div>
        <div><div class="sa-stat-label">Connected</div><div class="sa-stat-val"><?= number_format($analytics['connected']) ?></div></div>
    </div>
    <div class="sa-stat-card">
        <div class="sa-stat-icon text-muted"><i data-lucide="unlink"></i></div>
        <div><div class="sa-stat-label">Disconnected</div><div class="sa-stat-val"><?= number_format($analytics['disconnected']) ?></div></div>
    </div>
    <div class="sa-stat-card" style="border-color: <?= $analytics['error'] > 0 ? '#fca5a5' : '#e2e8f0' ?>;">
        <div class="sa-stat-icon text-danger"><i data-lucide="alert-circle"></i></div>
        <div><div class="sa-stat-label">Failing Connections</div><div class="sa-stat-val <?= $analytics['error'] > 0 ? 'text-danger' : '' ?>"><?= number_format($analytics['error']) ?></div></div>
    </div>
</div>

<?php foreach($grouped as $category => $items): ?>
    <h5 class="fw-bold mb-3 border-bottom pb-2" style="color:var(--sa-muted);"><?= e($category) ?></h5>
    <div class="integration-grid">
        <?php foreach($items as $i): ?>
            <div class="integration-card">
                <div class="ic-header">
                    <div class="ic-icon-placeholder"><?= e(strtoupper(substr($i['name'], 0, 1))) ?></div>
                    <span class="badge badge-status-<?= e($i['status']) ?> border text-uppercase" style="border-color:currentColor!important; padding:5px 8px; font-size:0.7rem;">
                        <?= e($i['status']) ?>
                    </span>
                </div>
                
                <h6 class="fw-bold text-dark mb-1"><?= e($i['name']) ?></h6>
                <div class="small text-muted mb-3">Environment: <span class="fw-bold text-dark text-capitalize"><?= e($i['environment']) ?></span></div>
                
                <div class="small mb-4" style="flex-grow: 1;">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Last Checked:</span>
                        <span class="fw-bold text-dark"><?= $i['last_checked_at'] ? date('M d, H:i', strtotime($i['last_checked_at'])) : 'Never' ?></span>
                    </div>
                </div>
                
                <div class="pt-3 border-top mt-auto">
                    <a href="<?= e(url('superadmin/integrations/'.$i['provider_id'])) ?>" class="btn btn-light btn-sm fw-bold w-100">Configure & Logs &rarr;</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>
