<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .badge-status-connected, .badge-status-success { background: #dcfce7; color: #166534; }
  .badge-status-disconnected { background: #f1f5f9; color: #475569; }
  .badge-status-error, .badge-status-failed { background: #fee2e2; color: #991b1b; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Configure: <?= e($integration['name']) ?></h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage API keys, webhooks, and view integration logs.</p>
  </div>
  <a href="<?= e(url('superadmin/integrations')) ?>" class="btn btn-light fw-bold"><i data-lucide="arrow-left" style="width:16px;height:16px;"></i> Back to Integrations</a>
</div>

<div class="row">
    <div class="col-lg-5">
        <div class="sa-card">
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <h6 class="fw-bold m-0">Connection Status</h6>
                <span class="badge badge-status-<?= e($integration['status']) ?> border text-uppercase" style="border-color:currentColor!important; padding:6px 12px;">
                    <?= e($integration['status']) ?>
                </span>
            </div>
            
            <form method="post" action="<?= e(url('superadmin/integrations/'.$integration['provider_id'].'/test')) ?>" class="mb-4">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-outline-primary btn-sm fw-bold w-100"><i data-lucide="zap" style="width:14px;height:14px;"></i> Test Connection / Ping API</button>
            </form>

            <form method="post" action="<?= e(url('superadmin/integrations/'.$integration['provider_id'])) ?>">
                <?= csrf_field() ?>
                
                <h6 class="fw-bold text-muted small text-uppercase mb-3 mt-2">API Configuration</h6>
                
                <div class="mb-3">
                    <label class="form-label fw-bold small">Status</label>
                    <select name="status" class="form-select fw-bold">
                        <option value="connected" <?= $integration['status']=='connected'?'selected':'' ?>>Connected (Active)</option>
                        <option value="disconnected" <?= $integration['status']=='disconnected'?'selected':'' ?>>Disconnected (Disabled)</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small">Environment</label>
                    <select name="environment" class="form-select fw-bold">
                        <option value="test" <?= $integration['environment']=='test'?'selected':'' ?>>Test / Sandbox</option>
                        <option value="live" <?= $integration['environment']=='live'?'selected':'' ?>>Live / Production</option>
                    </select>
                </div>

                <div class="alert alert-warning py-2 small fw-bold mb-3">
                    <i data-lucide="lock" style="width:14px;height:14px;"></i> Passwords and secret keys are encrypted at rest and will not be displayed here once saved.
                </div>

                <?php if(in_array($integration['category'], ['Payment Gateways', 'SMS Providers'])): ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">API Public Key / Client ID</label>
                        <input type="text" name="credentials[public_key]" class="form-control" value="<?= e($integration['credentials_decoded']['public_key'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">API Secret Key</label>
                        <input type="password" name="credentials[secret_key]" class="form-control" placeholder="<?= !empty($integration['credentials_decoded']['secret_key']) ? '••••••••••••••••' : 'Enter secret key...' ?>">
                    </div>
                <?php else: ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">API Bearer Token</label>
                        <input type="password" name="credentials[token]" class="form-control" placeholder="<?= !empty($integration['credentials_decoded']['token']) ? '••••••••••••••••' : 'Enter API token...' ?>">
                    </div>
                <?php endif; ?>

                <h6 class="fw-bold text-muted small text-uppercase mb-3 mt-4 border-top pt-3">Webhook Configuration</h6>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Webhook Endpoint URL</label>
                    <input type="url" name="webhook_url" class="form-control" value="<?= e($integration['webhook_url'] ?? '') ?>" placeholder="https://...">
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-dark fw-bold px-4" style="border-radius:8px;">Save Configuration</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="col-lg-7">
        <div class="sa-card p-0 h-100 d-flex flex-column">
            <div class="p-4 border-bottom">
                <h6 class="fw-bold m-0">Integration Audit Logs</h6>
                <p class="small text-muted mb-0">Recent events, connection tests, and webhook traces.</p>
            </div>
            <div class="table-responsive flex-grow-1" style="max-height: 600px; overflow-y: auto;">
                <table class="table table-hover mb-0">
                    <thead class="bg-light sticky-top">
                        <tr>
                            <th class="ps-4">Timestamp</th>
                            <th>Event</th>
                            <th>Status</th>
                            <th>Message / Payload</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $log): ?>
                        <tr>
                            <td class="ps-4 small fw-bold text-dark" style="white-space:nowrap;"><?= date('M d, H:i:s', strtotime($log['created_at'])) ?></td>
                            <td><span class="badge bg-light text-dark border text-uppercase"><?= e($log['event']) ?></span></td>
                            <td>
                                <span class="badge badge-status-<?= e($log['status']) ?> border text-uppercase" style="border-color:currentColor!important; padding:4px 8px; font-size:0.65rem;">
                                    <?= e($log['status']) ?>
                                </span>
                            </td>
                            <td class="small text-muted" style="max-width: 250px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?= e($log['message']) ?>">
                                <?= e($log['message']) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($logs)): ?>
                        <tr><td colspan="4" class="text-center py-5 text-muted">No logs recorded for this integration yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
