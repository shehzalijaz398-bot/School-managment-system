<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.2rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:12px; }
  .sa-stat-icon { width:42px; height:42px; border-radius:10px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.75rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.15rem; font-weight: 800; color: var(--sa-text); }
  
  .health-healthy { color: #16a34a; }
  .health-warning { color: #d97706; }
  .health-critical { color: #dc2626; }
  .bg-healthy { background-color: #dcfce7; }
  .bg-warning-light { background-color: #fef3c7; }
  .bg-critical { background-color: #fee2e2; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">System Health & Monitoring</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Real-time infrastructure metrics, background jobs, and application status.</p>
  </div>
  
  <div class="d-flex gap-2">
      <form method="post" action="<?= e(url('superadmin/system/cache/all')) ?>" onsubmit="return confirm('Clear ALL application caches? This may temporarily impact performance.');">
        <?= csrf_field() ?>
        <button class="btn btn-outline-dark fw-bold"><i data-lucide="trash-2" style="width:16px;height:16px;" class="me-1"></i> Flush Caches</button>
      </form>
      
      <form method="post" action="<?= e(url('superadmin/system/maintenance')) ?>" onsubmit="return confirm('<?= $health['is_maintenance'] ? 'Disable maintenance mode?' : 'ENABLE maintenance mode? This blocks all tenant traffic.' ?>');">
        <?= csrf_field() ?>
        <?php if($health['is_maintenance']): ?>
            <button class="btn btn-success fw-bold"><i data-lucide="power" style="width:16px;height:16px;" class="me-1"></i> Go Live</button>
        <?php else: ?>
            <button class="btn btn-danger fw-bold"><i data-lucide="alert-triangle" style="width:16px;height:16px;" class="me-1"></i> Maintenance Mode</button>
        <?php endif; ?>
      </form>
  </div>
</div>

<?php if($health['is_maintenance']): ?>
    <div class="alert alert-danger border-danger fw-bold d-flex align-items-center">
        <i data-lucide="alert-triangle" class="me-2"></i> SYSTEM IS CURRENTLY IN MAINTENANCE MODE. ALL SCHOOL TRAFFIC IS BLOCKED.
    </div>
<?php endif; ?>

<div class="sa-stat-grid">
    <div class="sa-stat-card">
        <div class="sa-stat-icon <?= 'health-' . strtolower($health['status']) ?> <?= $health['status'] === 'Healthy' ? 'bg-healthy' : ($health['status'] === 'Warning' ? 'bg-warning-light' : 'bg-critical') ?>">
            <i data-lucide="activity"></i>
        </div>
        <div>
            <div class="sa-stat-label">Platform Health</div>
            <div class="sa-stat-val <?= 'health-' . strtolower($health['status']) ?>"><?= e($health['status']) ?></div>
        </div>
    </div>
    
    <div class="sa-stat-card">
        <div class="sa-stat-icon <?= 'health-' . strtolower($queue['status']) ?> <?= $queue['status'] === 'Healthy' ? 'bg-healthy' : ($queue['status'] === 'Warning' ? 'bg-warning-light' : 'bg-critical') ?>">
            <i data-lucide="layers"></i>
        </div>
        <div>
            <div class="sa-stat-label">Queue Workers</div>
            <div class="sa-stat-val <?= 'health-' . strtolower($queue['status']) ?>"><?= e($queue['status']) ?></div>
        </div>
    </div>
    
    <div class="sa-stat-card">
        <div class="sa-stat-icon <?= 'health-' . strtolower($cron['status']) ?> <?= $cron['status'] === 'Healthy' ? 'bg-healthy' : ($cron['status'] === 'Warning' ? 'bg-warning-light' : 'bg-critical') ?>">
            <i data-lucide="clock"></i>
        </div>
        <div>
            <div class="sa-stat-label">Cron Tasks</div>
            <div class="sa-stat-val <?= 'health-' . strtolower($cron['status']) ?>"><?= e($cron['status']) ?></div>
        </div>
    </div>
    
    <div class="sa-stat-card">
        <div class="sa-stat-icon <?= $server['disk_usage_percent'] > 90 ? 'health-critical bg-critical' : 'health-healthy bg-healthy' ?>">
            <i data-lucide="hard-drive"></i>
        </div>
        <div>
            <div class="sa-stat-label">Storage Usage</div>
            <div class="sa-stat-val <?= $server['disk_usage_percent'] > 90 ? 'health-critical' : '' ?>"><?= e($server['disk_usage_percent']) ?>%</div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="sa-card">
            <h6 class="fw-bold mb-4 border-bottom pb-2"><i data-lucide="server" style="width:18px;height:18px;" class="me-2 text-primary"></i> Server & Application</h6>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">PHP Version</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['php_version']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">App Version</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['app_version']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">OS Architecture</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['os']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">System Time</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['server_time']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">Memory Limit</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['memory_limit']) ?></div>
            </div>
            <div class="row mb-0">
                <div class="col-6 small text-muted text-uppercase fw-bold">Upload Max</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($server['upload_max']) ?></div>
            </div>
        </div>
        
        <div class="sa-card">
            <h6 class="fw-bold mb-4 border-bottom pb-2"><i data-lucide="database" style="width:18px;height:18px;" class="me-2 text-primary"></i> Database Health</h6>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">Connection</div>
                <div class="col-6 fw-bold text-end">
                    <?php if($health['db_ok']): ?>
                        <span class="badge bg-success">OK (<?= e($health['db_ping']) ?>ms)</span>
                    <?php else: ?>
                        <span class="badge bg-danger">OFFLINE</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">DB Engine Version</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($health['db_version']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">Total Size</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($health['db_size']) ?> MB</div>
            </div>
            <div class="row mb-0">
                <div class="col-6 small text-muted text-uppercase fw-bold">Total Tables</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($health['db_tables']) ?></div>
            </div>
        </div>
        
        <div class="sa-card p-0">
            <div class="p-4 border-bottom bg-light">
                <h6 class="fw-bold m-0"><i data-lucide="folder" style="width:18px;height:18px;" class="me-2 text-primary"></i> Directory Storage</h6>
            </div>
            <div class="p-4">
                <div class="row mb-3">
                    <div class="col-6 small text-muted text-uppercase fw-bold">Uploads Directory</div>
                    <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($storage['uploads']) ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-6 small text-muted text-uppercase fw-bold">Cache Directory</div>
                    <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($storage['cache']) ?></div>
                </div>
                <div class="row mb-0">
                    <div class="col-6 small text-muted text-uppercase fw-bold">Logs Directory</div>
                    <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($storage['logs']) ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="sa-card">
            <h6 class="fw-bold mb-4 border-bottom pb-2"><i data-lucide="layers" style="width:18px;height:18px;" class="me-2 text-primary"></i> Queue Workers</h6>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">Pending Jobs</div>
                <div class="col-6 fw-bold text-dark font-monospace text-end"><?= e($queue['pending']) ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-6 small text-muted text-uppercase fw-bold">Failed Jobs</div>
                <div class="col-6 fw-bold font-monospace text-end <?= $queue['failed'] > 0 ? 'text-danger' : 'text-success' ?>">
                    <?= e($queue['failed']) ?>
                </div>
            </div>
            <?php if($queue['failed'] > 0): ?>
                <div class="alert alert-danger small py-2 px-3 mt-3 mb-0 border-0">
                    <i data-lucide="alert-circle" style="width:14px;height:14px;" class="me-1"></i> Jobs are failing. Check `platform_failed_jobs` table.
                </div>
            <?php endif; ?>
        </div>
        
        <div class="sa-card p-0">
            <div class="p-4 border-bottom bg-light d-flex justify-content-between align-items-center">
                <h6 class="fw-bold m-0"><i data-lucide="clock" style="width:18px;height:18px;" class="me-2 text-primary"></i> Scheduled Tasks (Cron)</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4">Task Name</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Next Run</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($cron['tasks'] as $c): ?>
                        <tr>
                            <td class="ps-4 fw-bold text-dark small"><?= e($c['name']) ?></td>
                            <td>
                                <?php if($c['status'] === 'idle'): ?>
                                    <span class="badge bg-secondary">Idle</span>
                                <?php elseif($c['status'] === 'running'): ?>
                                    <span class="badge bg-primary">Running</span>
                                <?php elseif($c['status'] === 'error'): ?>
                                    <span class="badge bg-danger">Error</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Completed</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4 font-monospace small text-muted">
                                <?= $c['next_run_at'] ? date('M d, H:i', strtotime($c['next_run_at'])) : '-' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($cron['tasks'])): ?>
                            <tr><td colspan="3" class="text-center text-muted py-4 small">No cron tasks registered.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="sa-card p-0 border-danger">
            <div class="p-4 border-bottom bg-danger text-white">
                <h6 class="fw-bold m-0"><i data-lucide="alert-triangle" style="width:18px;height:18px;" class="me-2 text-white"></i> Recent System Errors</h6>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <tbody>
                        <?php foreach($errors as $e): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-danger small"><?= e($e['level']) ?></div>
                                <div class="small text-muted font-monospace mt-1" style="max-width: 300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?= e($e['message']) ?>"><?= e($e['message']) ?></div>
                            </td>
                            <td class="text-end pe-4 small text-muted font-monospace">
                                <?= date('M d, H:i', strtotime($e['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($errors)): ?>
                            <tr><td colspan="2" class="text-center text-success fw-bold py-5"><i data-lucide="check-circle" class="me-1"></i> No recent system errors detected.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>
