<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .nav-tabs .nav-link { color: var(--sa-muted); font-weight: 600; border: none; border-bottom: 2px solid transparent; }
  .nav-tabs .nav-link.active { color: var(--sa-text); border-bottom-color: var(--sa-primary); background: transparent; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Communication Providers</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Configure SMTP, SMS, and WhatsApp gateways for platform notifications.</p>
  </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <form method="post" action="<?= e(url('superadmin/communication')) ?>" class="sa-card p-0" id="commsForm">
            <?= csrf_field() ?>
            
            <ul class="nav nav-tabs px-4 pt-3 border-bottom" id="commsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active px-3 pb-3" data-bs-toggle="tab" data-bs-target="#email-tab" type="button" role="tab"><i data-lucide="mail" style="width:16px;height:16px;" class="me-2"></i> Email (SMTP)</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#sms-tab" type="button" role="tab"><i data-lucide="message-square" style="width:16px;height:16px;" class="me-2"></i> SMS Gateway</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#whatsapp-tab" type="button" role="tab"><i data-lucide="message-circle" style="width:16px;height:16px;" class="me-2"></i> WhatsApp API</button>
                </li>
            </ul>
            
            <div class="tab-content p-4" id="commsTabsContent">
                
                <!-- Email Tab -->
                <div class="tab-pane fade show active" id="email-tab" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                        <div>
                            <h6 class="fw-bold mb-1">Email Delivery</h6>
                            <p class="small text-muted mb-0">If disabled, the system will attempt to fallback to native PHP mail().</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="notif_email" id="notif_email" value="1" <?= ($settings['notif_email'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold small" for="notif_email">Enable SMTP</label>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-bold small">SMTP Host</label>
                            <input type="text" name="smtp_host" class="form-control" value="<?= e($settings['smtp_host'] ?? '') ?>" placeholder="e.g. smtp.mailgun.org">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold small">SMTP Port</label>
                            <input type="number" name="smtp_port" class="form-control" value="<?= e($settings['smtp_port'] ?? '587') ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">SMTP Username</label>
                            <input type="text" name="smtp_username" class="form-control" value="<?= e($settings['smtp_username'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">SMTP Password</label>
                            <input type="password" name="smtp_password" class="form-control" placeholder="<?= !empty($settings['smtp_password']) ? '••••••••••••••••' : 'Enter password...' ?>">
                            <div class="form-text small">Leave blank to keep existing password.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-4 border-bottom pb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-bold small">Encryption</label>
                            <select name="smtp_encryption" class="form-select">
                                <option value="tls" <?= ($settings['smtp_encryption'] ?? '') === 'tls' ? 'selected' : '' ?>>TLS</option>
                                <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                <option value="none" <?= ($settings['smtp_encryption'] ?? '') === 'none' ? 'selected' : '' ?>>None</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold small">From Email</label>
                            <input type="email" name="smtp_from_email" class="form-control" value="<?= e($settings['smtp_from_email'] ?? '') ?>" placeholder="noreply@domain.com">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold small">From Name</label>
                            <input type="text" name="smtp_from_name" class="form-control" value="<?= e($settings['smtp_from_name'] ?? '') ?>" placeholder="School Portal">
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" class="btn btn-dark fw-bold px-4">Save Configuration</button>
                    </div>
                </div>

                <!-- SMS Tab -->
                <div class="tab-pane fade" id="sms-tab" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                        <div>
                            <h6 class="fw-bold mb-1">SMS Gateway</h6>
                            <p class="small text-muted mb-0">Deliver critical notifications via text message.</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="notif_sms" id="notif_sms" value="1" <?= ($settings['notif_sms'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold small" for="notif_sms">Enable SMS</label>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">SMS Provider</label>
                            <select name="sms_provider" class="form-select">
                                <option value="twilio" <?= ($settings['sms_provider'] ?? '') === 'twilio' ? 'selected' : '' ?>>Twilio</option>
                                <option value="nexmo" <?= ($settings['sms_provider'] ?? '') === 'nexmo' ? 'selected' : '' ?>>Vonage (Nexmo)</option>
                                <option value="aws_sns" <?= ($settings['sms_provider'] ?? '') === 'aws_sns' ? 'selected' : '' ?>>AWS SNS</option>
                                <option value="custom" <?= ($settings['sms_provider'] ?? '') === 'custom' ? 'selected' : '' ?>>Custom API</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Sender ID / Phone Number</label>
                            <input type="text" name="sms_sender_id" class="form-control" value="<?= e($settings['sms_sender_id'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-4 border-bottom pb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">API Key / Account SID</label>
                            <input type="password" name="sms_api_key" class="form-control font-monospace" placeholder="<?= !empty($settings['sms_api_key']) ? '••••••••••••••••' : 'Enter API Key' ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">API Secret / Auth Token</label>
                            <input type="password" name="sms_api_secret" class="form-control font-monospace" placeholder="<?= !empty($settings['sms_api_secret']) ? '••••••••••••••••' : 'Enter API Secret' ?>">
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" class="btn btn-dark fw-bold px-4">Save Configuration</button>
                    </div>
                </div>

                <!-- WhatsApp Tab -->
                <div class="tab-pane fade" id="whatsapp-tab" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                        <div>
                            <h6 class="fw-bold mb-1">WhatsApp Business API</h6>
                            <p class="small text-muted mb-0">Send templated WhatsApp messages to users.</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="notif_whatsapp" id="notif_whatsapp" value="1" <?= ($settings['notif_whatsapp'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold small" for="notif_whatsapp">Enable WhatsApp</label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Provider</label>
                        <select name="wa_provider" class="form-select">
                            <option value="meta" <?= ($settings['wa_provider'] ?? '') === 'meta' ? 'selected' : '' ?>>Meta Official API (Cloud API)</option>
                            <option value="twilio" <?= ($settings['wa_provider'] ?? '') === 'twilio' ? 'selected' : '' ?>>Twilio WhatsApp</option>
                        </select>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Phone Number ID</label>
                            <input type="text" name="wa_phone_number_id" class="form-control" value="<?= e($settings['wa_phone_number_id'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Business Account ID</label>
                            <input type="text" name="wa_business_account_id" class="form-control" value="<?= e($settings['wa_business_account_id'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="mb-4 border-bottom pb-4">
                        <label class="form-label fw-bold small">Permanent Access Token</label>
                        <input type="password" name="wa_api_key" class="form-control font-monospace" placeholder="<?= !empty($settings['wa_api_key']) ? '••••••••••••••••' : 'Enter Access Token' ?>">
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" class="btn btn-dark fw-bold px-4">Save Configuration</button>
                    </div>
                </div>
                
            </div>
        </form>
    </div>
    
    <div class="col-lg-4">
        <div class="sa-card bg-light border-0">
            <h6 class="fw-bold text-dark small text-uppercase mb-3"><i data-lucide="zap" style="width:16px;height:16px;" class="me-1 text-primary"></i> Connection Testing</h6>
            <p class="small text-muted mb-4">Verify that your configurations are correct by sending a test message before deploying to production.</p>
            
            <form method="post" action="<?= e(url('superadmin/communication/test-email')) ?>" class="mb-3 p-3 bg-white border rounded">
                <?= csrf_field() ?>
                <label class="form-label fw-bold small">Test Email Connection</label>
                <div class="input-group">
                    <input type="email" name="test_email" class="form-control form-control-sm" placeholder="user@domain.com" required>
                    <button class="btn btn-outline-primary btn-sm fw-bold" type="submit">Ping</button>
                </div>
            </form>
            
            <form method="post" action="<?= e(url('superadmin/communication/test-sms')) ?>" class="mb-3 p-3 bg-white border rounded">
                <?= csrf_field() ?>
                <label class="form-label fw-bold small">Test SMS Delivery</label>
                <div class="input-group">
                    <input type="text" name="test_phone" class="form-control form-control-sm" placeholder="+1234567890" required>
                    <button class="btn btn-outline-primary btn-sm fw-bold" type="submit">Ping</button>
                </div>
            </form>
            
            <form method="post" action="<?= e(url('superadmin/communication/test-whatsapp')) ?>" class="mb-0 p-3 bg-white border rounded">
                <?= csrf_field() ?>
                <label class="form-label fw-bold small">Test WhatsApp API</label>
                <div class="input-group">
                    <input type="text" name="test_wa_phone" class="form-control form-control-sm" placeholder="+1234567890" required>
                    <button class="btn btn-outline-primary btn-sm fw-bold" type="submit">Ping</button>
                </div>
            </form>
            
        </div>
        
        <div class="alert alert-warning py-2 px-3 small fw-bold mt-3 border-warning d-flex">
            <i data-lucide="shield" style="width:16px;height:16px;" class="me-2 flex-shrink-0 mt-1"></i>
            <div>Passwords, Tokens, and API Secrets are encrypted at rest and never exposed to the UI after being successfully saved.</div>
        </div>
    </div>
</div>
