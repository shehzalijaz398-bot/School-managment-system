<style>
  .sa-card {
    transition: transform 0.2s, box-shadow 0.2s;
    background: var(--sa-card);
    border: 1px solid var(--sa-border);
    border-radius: var(--sa-radius);
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    margin-bottom: 1.5rem;
  }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #f8fafc; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:15px; }
  .sa-stat-icon { width:48px; height:48px; border-radius:12px; background:white; display:flex; justify-content:center; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.5rem; font-weight: 800; color: var(--sa-text); line-height:1.2; }
  
  .plan-card { border: 2px solid var(--sa-border); border-radius: 12px; padding: 1.5rem; background: #fff; position: relative; display: flex; flex-direction: column; height: 100%; transition: all 0.3s; }
  .plan-card:hover { border-color: var(--sa-primary); box-shadow: 0 10px 20px rgba(0,0,0,0.05); transform: translateY(-3px); }
  .plan-card.inactive { opacity: 0.7; filter: grayscale(1); }
  .plan-header { margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #f1f5f9; }
  .plan-name { font-size: 1.25rem; font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem; }
  .plan-price { font-size: 2rem; font-weight: 800; color: var(--sa-text); }
  .plan-price small { font-size: 1rem; font-weight: 600; color: var(--sa-muted); }
  
  .feature-list { list-style: none; padding: 0; margin: 0 0 1.5rem 0; flex-grow: 1; }
  .feature-list li { padding: 8px 0; font-size: 0.9rem; color: var(--sa-text); display: flex; align-items: center; gap: 8px; border-bottom: 1px dashed #f1f5f9; }
  .feature-list li i { color: var(--sa-primary); width: 16px; height: 16px; }
  
  .nav-tabs .nav-link { font-weight: 600; color: var(--sa-muted); border: none; border-bottom: 2px solid transparent; padding: 12px 24px; }
  .nav-tabs .nav-link.active { color: var(--sa-primary); border-bottom: 2px solid var(--sa-primary); background: transparent; }
  
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  .table td { font-size: 0.9rem; vertical-align: middle; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Subscriptions & Plans</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage platform tiers, features, and active school subscriptions.</p>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createPlanModal" style="border-radius:8px;"><i data-lucide="plus-circle" style="width:16px;height:16px;"></i> Create Plan</button>
  </div>
</div>

<div class="sa-card p-0 mb-4">
    <ul class="nav nav-tabs px-4 pt-3" id="planTabs" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-analytics">Overview</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-plans">Pricing Plans</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-subs">Active Subscriptions</button></li>
    </ul>

    <div class="tab-content p-4">
        <!-- Analytics Tab -->
        <div class="tab-pane fade show active" id="tab-analytics">
            <div class="sa-stat-grid">
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-primary"><i data-lucide="credit-card"></i></div>
                    <div><div class="sa-stat-label">Total Plans</div><div class="sa-stat-val"><?= e($analytics['total_plans']) ?></div></div>
                </div>
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-success"><i data-lucide="check-circle"></i></div>
                    <div><div class="sa-stat-label">Active Plans</div><div class="sa-stat-val"><?= e($analytics['active_plans']) ?></div></div>
                </div>
                <div class="sa-stat-card" style="background: linear-gradient(135deg, #1e40af, #195ed8); color:white;">
                    <div class="sa-stat-icon" style="background:rgba(255,255,255,0.2); color:white;"><i data-lucide="dollar-sign"></i></div>
                    <div><div class="sa-stat-label" style="color:rgba(255,255,255,0.8);">Monthly MRR</div><div class="sa-stat-val" style="color:white;">$<?= number_format($analytics['mrr'],2) ?></div></div>
                </div>
                <div class="sa-stat-card">
                    <div class="sa-stat-icon text-info"><i data-lucide="trending-up"></i></div>
                    <div><div class="sa-stat-label">Annual ARR</div><div class="sa-stat-val">$<?= number_format($analytics['arr'],2) ?></div></div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold mb-3">Plan Distribution</h5>
                        <?php foreach($plans as $p): if($p['status']==2) continue; ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="fw-bold"><?= e($p['name']) ?></span>
                                <span class="badge bg-light text-dark border"><?= e($p['school_count']) ?> Schools</span>
                            </div>
                            <div class="progress mb-3" style="height: 8px;">
                                <div class="progress-bar bg-primary" style="width: <?= $analytics['total_plans'] ? ($p['school_count'] * 10) : 0 ?>%"></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="border rounded p-3 bg-light">
                        <h5 class="fw-bold mb-3">Subscription Analytics</h5>
                        <p class="text-muted small mb-0">Platform subscription logic strictly adheres to DB tables (<code>plans</code>, <code>subscriptions</code>, <code>subscription_payments</code>). Billing flows seamlessly without interfering with the internal school portal fee system.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Plans Tab -->
        <div class="tab-pane fade" id="tab-plans">
            <div class="row g-4">
                <?php foreach($plans as $p): ?>
                <div class="col-md-4">
                    <div class="plan-card <?= $p['status'] == 0 ? 'inactive' : '' ?>">
                        <?php if($p['status'] == 0): ?>
                            <span class="badge bg-warning position-absolute top-0 end-0 mt-3 me-3">Draft / Inactive</span>
                        <?php endif; ?>
                        
                        <div class="plan-header">
                            <div class="plan-name"><?= e($p['name']) ?></div>
                            <div class="text-muted small mb-2"><?= e($p['description']) ?></div>
                            <div class="plan-price">$<?= number_format((float)$p['monthly_price'], 2) ?> <small>/ month</small></div>
                            <div style="font-size:0.8rem; font-weight:600; color:var(--sa-primary);">Or $<?= number_format((float)$p['annual_price'], 2) ?> / year</div>
                        </div>
                        
                        <div style="font-size:0.8rem; font-weight:700; color:var(--sa-muted); text-transform:uppercase; margin-bottom:10px;">Limits & Features</div>
                        <ul class="feature-list">
                            <li><i data-lucide="users"></i> <strong><?= $p['student_limit'] ? number_format($p['student_limit']) : 'Unlimited' ?></strong> Students</li>
                            <li><i data-lucide="user-check"></i> <strong><?= $p['teacher_limit'] ? number_format($p['teacher_limit']) : 'Unlimited' ?></strong> Teachers</li>
                            <li><i data-lucide="hard-drive"></i> <strong><?= $p['storage_limit_mb'] ? number_format($p['storage_limit_mb']) . ' MB' : 'Unlimited' ?></strong> Storage</li>
                            <li><i data-lucide="calendar"></i> <strong><?= $p['trial_days'] ?></strong> Days Trial</li>
                            <?php foreach(array_slice($p['features'], 0, 4) as $f): ?>
                                <li><i data-lucide="check"></i> <?= e($f['name']) ?></li>
                            <?php endforeach; ?>
                            <?php if(count($p['features']) > 4): ?>
                                <li class="text-muted small fst-italic border-0">...and <?= count($p['features']) - 4 ?> more modules</li>
                            <?php endif; ?>
                        </ul>
                        
                        <div class="d-flex gap-2 mt-auto">
                            <button class="btn btn-outline-primary btn-sm flex-grow-1 fw-bold" onclick="editPlan(<?= htmlspecialchars(json_encode($p)) ?>)">Edit</button>
                            <form method="post" action="<?= e(url('superadmin/plans/'.$p['id'].'/duplicate')) ?>" class="m-0 flex-grow-1">
                                <?= csrf_field() ?>
                                <button class="btn btn-outline-secondary btn-sm w-100 fw-bold">Duplicate</button>
                            </form>
                        </div>
                        <div class="mt-2">
                            <form method="post" action="<?= e(url('superadmin/plans/'.$p['id'].'/status')) ?>" onsubmit="return confirm('Change status?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="status" value="<?= $p['status'] == 1 ? 0 : 1 ?>">
                                <?php if($p['status'] == 1): ?>
                                    <button class="btn btn-outline-warning btn-sm w-100 fw-bold">Deactivate Plan</button>
                                <?php else: ?>
                                    <button class="btn btn-success btn-sm w-100 fw-bold">Activate Plan</button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Subscriptions Tab -->
        <div class="tab-pane fade" id="tab-subs">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>School</th>
                            <th>Plan</th>
                            <th>Cycle</th>
                            <th>Status</th>
                            <th>Expiry</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($subscriptions as $s): ?>
                        <tr>
                            <td><a href="<?= e(url('superadmin/schools/'.$s['school_id'])) ?>" class="fw-bold"><?= e($s['school_name']) ?></a></td>
                            <td><span class="badge bg-light text-dark border"><?= e($s['plan_name']) ?></span></td>
                            <td><span class="text-muted" style="text-transform:capitalize;"><?= e($s['billing_cycle']) ?></span></td>
                            <td>
                                <?php 
                                    $sc = 'warning';
                                    if($s['subscription_status'] === 'active') $sc = 'success';
                                    if(in_array($s['subscription_status'],['cancelled','expired','suspended'])) $sc = 'danger';
                                ?>
                                <span class="badge bg-<?= $sc ?>"><?= ucfirst($s['subscription_status']) ?></span>
                            </td>
                            <td><?= $s['end_date'] ? date('M d, Y', strtotime($s['end_date'])) : '-' ?></td>
                            <td class="text-end">
                                <div class="dropdown">
                                    <button class="btn btn-light btn-sm" data-bs-toggle="dropdown"><i data-lucide="more-vertical" style="width:16px;height:16px;"></i></button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                        <li><a class="dropdown-item fw-bold text-primary" href="<?= e(url('superadmin/schools/'.$s['school_id'])) ?>">Manage School</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form method="post" action="<?= e(url('superadmin/subscriptions/'.$s['id'].'/action')) ?>">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="pause">
                                                <button class="dropdown-item">Pause Subscription</button>
                                            </form>
                                        </li>
                                        <li>
                                            <form method="post" action="<?= e(url('superadmin/subscriptions/'.$s['id'].'/action')) ?>" onsubmit="return confirm('Cancel subscription?');">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="cancel">
                                                <button class="dropdown-item text-danger fw-bold">Cancel Subscription</button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($subscriptions)): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No subscriptions found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Plan Modal (Create/Edit) -->
<div class="modal fade" id="createPlanModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius:12px; border:none; box-shadow:0 10px 30px rgba(0,0,0,0.1);">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold" id="planModalTitle">Create New Plan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" id="planForm" action="<?= e(url('superadmin/plans')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Plan Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" id="plan_name" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Slug <span class="text-danger">*</span></label>
                    <input type="text" name="slug" id="plan_slug" class="form-control" required>
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold small">Description</label>
                    <input type="text" name="description" id="plan_desc" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Monthly Price ($)</label>
                    <input type="number" step="0.01" name="monthly_price" id="plan_monthly" class="form-control" value="0">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Annual Price ($)</label>
                    <input type="number" step="0.01" name="annual_price" id="plan_annual" class="form-control" value="0">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Trial Days</label>
                    <input type="number" name="trial_days" id="plan_trial" class="form-control" value="14">
                </div>
                <div class="col-12"><hr></div>
                <h6 class="fw-bold">Limits (Leave blank for Unlimited)</h6>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Max Students</label>
                    <input type="number" name="student_limit" id="plan_stu_lim" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Max Teachers</label>
                    <input type="number" name="teacher_limit" id="plan_tea_lim" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Max Employees</label>
                    <input type="number" name="employee_limit" id="plan_emp_lim" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Storage (MB)</label>
                    <input type="number" name="storage_limit_mb" id="plan_sto_lim" class="form-control">
                </div>
                <div class="col-12"><hr></div>
                <h6 class="fw-bold">Module Access</h6>
                <div class="row g-2">
                    <?php 
                    $currentModule = '';
                    foreach($features as $f): 
                        if($f['module'] !== $currentModule) {
                            $currentModule = $f['module'];
                            echo '<div class="col-12 mt-2"><div class="fw-bold small text-primary text-uppercase">'.e($currentModule).'</div></div>';
                        }
                    ?>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input feature-cb" type="checkbox" name="features[]" value="<?= $f['id'] ?>" id="f_<?= $f['id'] ?>">
                            <label class="form-check-label small" for="f_<?= $f['id'] ?>"><?= e($f['name']) ?></label>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;">Save Plan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function editPlan(plan) {
    document.getElementById('planModalTitle').innerText = 'Edit Plan';
    document.getElementById('planForm').action = '<?= url("superadmin/plans/") ?>' + plan.id;
    
    document.getElementById('plan_name').value = plan.name;
    document.getElementById('plan_slug').value = plan.slug;
    document.getElementById('plan_desc').value = plan.description || '';
    document.getElementById('plan_monthly').value = plan.monthly_price;
    document.getElementById('plan_annual').value = plan.annual_price;
    document.getElementById('plan_trial').value = plan.trial_days;
    
    document.getElementById('plan_stu_lim').value = plan.student_limit || '';
    document.getElementById('plan_tea_lim').value = plan.teacher_limit || '';
    document.getElementById('plan_emp_lim').value = plan.employee_limit || '';
    document.getElementById('plan_sto_lim').value = plan.storage_limit_mb || '';
    
    document.querySelectorAll('.feature-cb').forEach(cb => cb.checked = false);
    if(plan.features) {
        plan.features.forEach(f => {
            let el = document.getElementById('f_' + f.id);
            if(el) el.checked = true;
        });
    }
    
    new bootstrap.Modal(document.getElementById('createPlanModal')).show();
}

document.getElementById('createPlanModal').addEventListener('hidden.bs.modal', function () {
    document.getElementById('planModalTitle').innerText = 'Create New Plan';
    document.getElementById('planForm').action = '<?= url("superadmin/plans") ?>';
    document.getElementById('planForm').reset();
});
</script>
