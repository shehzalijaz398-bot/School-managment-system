<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .sa-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem; }
  .sa-stat-card { background: #fff; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0; display:flex; flex-direction:column; gap:8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
  .sa-stat-label { font-size: 0.8rem; font-weight: 600; color: var(--sa-muted); text-transform: uppercase; }
  .sa-stat-val { font-size: 1.8rem; font-weight: 800; color: var(--sa-text); line-height: 1; }
  .sa-stat-growth { font-size: 0.8rem; font-weight: 600; padding: 2px 8px; border-radius: 4px; display:inline-block; width:fit-content; }
  .growth-up { background: #dcfce7; color: #166534; }
  .growth-down { background: #fee2e2; color: #991b1b; }
  .growth-flat { background: #f1f5f9; color: #475569; }

  .filter-bar { background: var(--sa-card); padding: 15px 20px; border-radius: var(--sa-radius); border: 1px solid var(--sa-border); margin-bottom: 20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }
  
  .chart-container { position: relative; height: 300px; width: 100%; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Reports & Analytics</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Monitor platform growth, revenue, and school engagement.</p>
  </div>
</div>

<div class="filter-bar">
    <div class="d-flex align-items-center gap-3">
        <label class="fw-bold small text-uppercase text-muted m-0">Date Range:</label>
        <select id="date_range" class="form-select form-select-sm" style="width:200px; font-weight:600;">
            <option value="today">Today</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d" selected>Last 30 Days</option>
            <option value="3m">Last 3 Months</option>
            <option value="6m">Last 6 Months</option>
            <option value="12m">Last 12 Months</option>
        </select>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-dark btn-sm fw-bold" onclick="exportData('schools')"><i data-lucide="download" style="width:14px;height:14px;"></i> Export Schools</button>
        <button class="btn btn-outline-dark btn-sm fw-bold" onclick="exportData('revenue')"><i data-lucide="download" style="width:14px;height:14px;"></i> Export Revenue</button>
    </div>
</div>

<div id="loader" class="text-center py-5">
    <div class="spinner-border text-primary" role="status"></div>
    <div class="mt-2 fw-bold text-muted">Compiling Analytics...</div>
</div>

<div id="dashboard_content" style="display:none;">
    <!-- KPI Cards -->
    <div class="sa-stat-grid">
        <div class="sa-stat-card">
            <div class="sa-stat-label">Total / Active Schools</div>
            <div class="d-flex align-items-baseline gap-2">
                <div class="sa-stat-val" id="kpi_total_schools">0</div>
                <div class="text-muted fw-bold small">/ <span id="kpi_active_schools">0</span> active</div>
            </div>
        </div>
        <div class="sa-stat-card">
            <div class="sa-stat-label">New Schools</div>
            <div class="sa-stat-val" id="kpi_new_schools">0</div>
            <div class="sa-stat-growth" id="kpi_new_schools_growth">0%</div>
        </div>
        <div class="sa-stat-card">
            <div class="sa-stat-label">Period Revenue</div>
            <div class="sa-stat-val" id="kpi_revenue">$0</div>
            <div class="sa-stat-growth" id="kpi_revenue_growth">0%</div>
        </div>
        <div class="sa-stat-card">
            <div class="sa-stat-label">Current MRR</div>
            <div class="sa-stat-val" id="kpi_mrr">$0</div>
            <div class="text-muted fw-bold" style="font-size:0.75rem;">ARR: <span id="kpi_arr">$0</span></div>
        </div>
    </div>

    <!-- Charts Row 1 -->
    <div class="row g-4 mb-4">
        <div class="col-lg-8">
            <div class="sa-card h-100">
                <h6 class="fw-bold text-uppercase small text-muted mb-4">Revenue Trend (Paid)</h6>
                <div class="chart-container"><canvas id="chartRevenueTrend"></canvas></div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="sa-card h-100">
                <h6 class="fw-bold text-uppercase small text-muted mb-4">Revenue by Plan</h6>
                <div class="chart-container"><canvas id="chartRevByPlan"></canvas></div>
            </div>
        </div>
    </div>

    <!-- Charts Row 2 -->
    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="sa-card h-100">
                <h6 class="fw-bold text-uppercase small text-muted mb-4">School Growth (New Registrations)</h6>
                <div class="chart-container"><canvas id="chartSchoolGrowth"></canvas></div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="sa-card h-100">
                <h6 class="fw-bold text-uppercase small text-muted mb-4">Active Plan Distribution</h6>
                <div class="chart-container"><canvas id="chartPlanDist"></canvas></div>
            </div>
        </div>
    </div>
</div>

<script>
let charts = {};

function formatMoney(amount) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
}
function formatNumber(num) {
    return new Intl.NumberFormat('en-US').format(num);
}
function setGrowth(elId, val) {
    const el = document.getElementById(elId);
    if(val > 0) { el.className = 'sa-stat-growth growth-up'; el.innerText = '+' + val + '%'; }
    else if(val < 0) { el.className = 'sa-stat-growth growth-down'; el.innerText = val + '%'; }
    else { el.className = 'sa-stat-growth growth-flat'; el.innerText = '0%'; }
}

function renderChart(id, type, data, options = {}) {
    if(charts[id]) charts[id].destroy();
    const ctx = document.getElementById(id).getContext('2d');
    
    let chartOpts = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: type==='pie'||type==='doughnut', position: 'bottom' } }
    };
    
    if(type === 'line' || type === 'bar') {
        chartOpts.scales = {
            y: { beginAtZero: true, grid: { borderDash: [2, 2] } },
            x: { grid: { display: false } }
        };
    }

    charts[id] = new Chart(ctx, {
        type: type,
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Data',
                data: data.values,
                backgroundColor: type==='pie'||type==='doughnut' ? ['#0ea5e9','#3b82f6','#6366f1','#8b5cf6','#d946ef','#f43f5e'] : 'rgba(59, 130, 246, 0.2)',
                borderColor: type==='pie'||type==='doughnut' ? '#fff' : '#3b82f6',
                borderWidth: 2,
                fill: type==='line',
                tension: 0.3
            }]
        },
        options: { ...chartOpts, ...options }
    });
}

function loadData() {
    document.getElementById('loader').style.display = 'block';
    document.getElementById('dashboard_content').style.display = 'none';
    
    const range = document.getElementById('date_range').value;
    fetch('<?= url("superadmin/reports/data") ?>?range=' + range)
        .then(r => r.json())
        .then(data => {
            // KPIs
            document.getElementById('kpi_total_schools').innerText = formatNumber(data.overview.total_schools);
            document.getElementById('kpi_active_schools').innerText = formatNumber(data.overview.active_schools);
            document.getElementById('kpi_new_schools').innerText = formatNumber(data.overview.new_schools);
            setGrowth('kpi_new_schools_growth', data.overview.new_schools_growth);
            
            document.getElementById('kpi_revenue').innerText = formatMoney(data.overview.revenue);
            setGrowth('kpi_revenue_growth', data.overview.revenue_growth);
            
            document.getElementById('kpi_mrr').innerText = formatMoney(data.overview.mrr);
            document.getElementById('kpi_arr').innerText = formatMoney(data.overview.arr);

            // Charts
            renderChart('chartRevenueTrend', 'line', data.charts.revenue_trend);
            renderChart('chartSchoolGrowth', 'bar', data.charts.school_growth);
            renderChart('chartRevByPlan', 'doughnut', data.charts.revenue_by_plan);
            renderChart('chartPlanDist', 'pie', data.charts.plan_distribution);

            document.getElementById('loader').style.display = 'none';
            document.getElementById('dashboard_content').style.display = 'block';
        });
}

function exportData(type) {
    const range = document.getElementById('date_range').value;
    window.location.href = '<?= url("superadmin/reports/export") ?>?type=' + type + '&range=' + range;
}

document.getElementById('date_range').addEventListener('change', loadData);
document.addEventListener('DOMContentLoaded', loadData);
</script>
