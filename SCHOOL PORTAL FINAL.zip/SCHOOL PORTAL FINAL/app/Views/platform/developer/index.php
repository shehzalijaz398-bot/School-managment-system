<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .nav-tabs .nav-link { color: var(--sa-muted); font-weight: 600; border: none; border-bottom: 2px solid transparent; }
  .nav-tabs .nav-link.active { color: var(--sa-text); border-bottom-color: var(--sa-primary); background: transparent; }
  .table th { font-size: 0.8rem; text-transform: uppercase; color: var(--sa-muted); }
  
  .secret-flash-box { background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 1.5rem; text-align: center; margin-bottom: 2rem; position: relative; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">API & Developer Center</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage API keys, OAuth clients, and Webhook dispatch configurations.</p>
  </div>
</div>

<?php if (isset($_SESSION['flash_api_key'])): ?>
    <div class="alert alert-success border-success secret-flash-box">
        <h5 class="fw-bold text-success mb-2"><i data-lucide="key" class="me-2"></i> API Key Generated Successfully</h5>
        <p class="small text-muted mb-3">Copy this key now. It is hashed immediately and <strong>will never be shown again</strong>.</p>
        <div class="input-group mx-auto" style="max-width: 500px;">
            <input type="text" class="form-control font-monospace fw-bold text-center" value="<?= e($_SESSION['flash_api_key']) ?>" readonly id="flashApiKey">
            <button class="btn btn-dark fw-bold" onclick="navigator.clipboard.writeText(document.getElementById('flashApiKey').value); alert('Copied!');">Copy</button>
        </div>
    </div>
    <?php unset($_SESSION['flash_api_key']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['flash_webhook_secret'])): ?>
    <div class="alert alert-success border-success secret-flash-box">
        <h5 class="fw-bold text-success mb-2"><i data-lucide="shield" class="me-2"></i> Webhook Secret Generated</h5>
        <p class="small text-muted mb-3">Use this secret to verify the `X-Platform-Signature` header on incoming payloads. <strong>It will never be shown again</strong>.</p>
        <div class="input-group mx-auto" style="max-width: 500px;">
            <input type="text" class="form-control font-monospace fw-bold text-center" value="<?= e($_SESSION['flash_webhook_secret']) ?>" readonly id="flashWhSecret">
            <button class="btn btn-dark fw-bold" onclick="navigator.clipboard.writeText(document.getElementById('flashWhSecret').value); alert('Copied!');">Copy</button>
        </div>
    </div>
    <?php unset($_SESSION['flash_webhook_secret']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['flash_oauth'])): ?>
    <div class="alert alert-success border-success secret-flash-box">
        <h5 class="fw-bold text-success mb-2"><i data-lucide="lock" class="me-2"></i> OAuth Client Registered</h5>
        <p class="small text-muted mb-3">Store these credentials securely. The Client Secret <strong>will never be shown again</strong>.</p>
        <div class="mx-auto text-start" style="max-width: 500px;">
            <label class="small fw-bold">Client ID</label>
            <input type="text" class="form-control font-monospace mb-2" value="<?= e($_SESSION['flash_oauth']['client_id']) ?>" readonly>
            <label class="small fw-bold">Client Secret</label>
            <input type="text" class="form-control font-monospace mb-2" value="<?= e($_SESSION['flash_oauth']['client_secret']) ?>" readonly>
        </div>
    </div>
    <?php unset($_SESSION['flash_oauth']); ?>
<?php endif; ?>

<div class="sa-card p-0">
    <ul class="nav nav-tabs px-4 pt-3 border-bottom" id="devTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active px-3 pb-3" data-bs-toggle="tab" data-bs-target="#keys-tab" type="button" role="tab"><i data-lucide="key" style="width:16px;height:16px;" class="me-1"></i> API Keys</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#webhooks-tab" type="button" role="tab"><i data-lucide="webhook" style="width:16px;height:16px;" class="me-1"></i> Webhooks</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link px-3 pb-3" data-bs-toggle="tab" data-bs-target="#oauth-tab" type="button" role="tab"><i data-lucide="lock" style="width:16px;height:16px;" class="me-1"></i> OAuth Clients</button>
        </li>
    </ul>
    
    <div class="tab-content" id="devTabsContent">
        <!-- API Keys Tab -->
        <div class="tab-pane fade show active" id="keys-tab" role="tabpanel">
            <div class="d-flex justify-content-end p-3 border-bottom bg-light">
                <button class="btn btn-primary btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createApiKeyModal">Generate New Key</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4">Name / Token Prefix</th>
                            <th>Tenant / School Scope</th>
                            <th>Status</th>
                            <th>Permissions</th>
                            <th>Last Used</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($apiKeys as $k): ?>
                        <tr class="<?= $k['status'] == 0 ? 'opacity-50' : '' ?>">
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?= e($k['name']) ?></div>
                                <div class="font-monospace small text-muted"><?= e($k['token_prefix']) ?>...</div>
                            </td>
                            <td>
                                <?php if($k['school_id']): ?>
                                    <span class="badge bg-light text-dark border"><?= e($k['school_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger text-white">Global Platform Access</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($k['status'] == 1): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Revoked</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php foreach(json_decode($k['scopes'], true) as $s): ?>
                                    <span class="badge bg-light text-muted border border-secondary" style="font-size:0.6rem;"><?= e($s) ?></span>
                                <?php endforeach; ?>
                            </td>
                            <td class="small text-muted">
                                <?= $k['last_used_at'] ? date('M d, Y H:i', strtotime($k['last_used_at'])) : 'Never' ?>
                            </td>
                            <td class="text-end pe-4">
                                <?php if($k['status'] == 1): ?>
                                    <form method="post" action="<?= e(url('superadmin/developer/api-keys/'.$k['id'].'/revoke')) ?>" onsubmit="return confirm('Revoke this key? All active integrations using it will fail immediately.');">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-outline-danger btn-sm fw-bold">Revoke</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($apiKeys)): ?><tr><td colspan="6" class="text-center text-muted py-5">No API keys generated.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Webhooks Tab -->
        <div class="tab-pane fade" id="webhooks-tab" role="tabpanel">
            <div class="d-flex justify-content-end p-3 border-bottom bg-light">
                <button class="btn btn-primary btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createWebhookModal">Register Webhook</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4">Endpoint URL</th>
                            <th>Tenant Scope</th>
                            <th>Events</th>
                            <th>Last Delivery</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($webhooks as $w): ?>
                        <tr class="<?= $w['status'] == 0 ? 'opacity-50' : '' ?>">
                            <td class="ps-4">
                                <div class="font-monospace small text-dark fw-bold" style="word-break: break-all; max-width: 300px;"><?= e($w['url']) ?></div>
                                <?php if($w['status'] == 1): ?>
                                    <span class="badge bg-success" style="font-size:0.6rem;">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary" style="font-size:0.6rem;">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($w['school_id']): ?>
                                    <span class="badge bg-light text-dark border"><?= e($w['school_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger text-white">Global Events</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php foreach(json_decode($w['events'], true) as $ev): ?>
                                    <span class="badge bg-light text-muted border border-secondary" style="font-size:0.6rem;"><?= e($ev) ?></span>
                                <?php endforeach; ?>
                            </td>
                            <td class="small">
                                <?php if($w['last_delivery_at']): ?>
                                    <span class="d-block text-muted"><?= date('M d, H:i', strtotime($w['last_delivery_at'])) ?></span>
                                    <span class="badge <?= $w['last_response_code'] == 200 ? 'bg-success' : 'bg-danger' ?> mt-1">HTTP <?= $w['last_response_code'] ?></span>
                                <?php else: ?>
                                    <span class="text-muted">Never fired</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <div class="d-flex justify-content-end gap-2">
                                    <form method="post" action="<?= e(url('superadmin/developer/webhooks/'.$w['id'].'/ping')) ?>">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-light btn-sm fw-bold text-primary" title="Ping Endpoint">Ping</button>
                                    </form>
                                    <form method="post" action="<?= e(url('superadmin/developer/webhooks/'.$w['id'].'/toggle')) ?>">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-outline-dark btn-sm fw-bold"><?= $w['status']==1 ? 'Disable' : 'Enable' ?></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($webhooks)): ?><tr><td colspan="5" class="text-center text-muted py-5">No webhooks registered.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- OAuth Clients Tab -->
        <div class="tab-pane fade" id="oauth-tab" role="tabpanel">
            <div class="d-flex justify-content-end p-3 border-bottom bg-light">
                <button class="btn btn-primary btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createOauthModal">Create OAuth Client</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4">Application Name</th>
                            <th>Client ID</th>
                            <th>Tenant Scope</th>
                            <th>Redirect URIs</th>
                            <th class="text-end pe-4">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($oauthClients as $c): ?>
                        <tr class="<?= $c['status'] == 0 ? 'opacity-50' : '' ?>">
                            <td class="ps-4 fw-bold text-dark"><?= e($c['name']) ?></td>
                            <td class="font-monospace small text-muted"><?= e($c['client_id']) ?></td>
                            <td>
                                <?php if($c['school_id']): ?>
                                    <span class="badge bg-light text-dark border"><?= e($c['school_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger text-white">Global</span>
                                <?php endif; ?>
                            </td>
                            <td class="small text-muted" style="max-width: 200px; word-break: break-all;">
                                <?= e(implode(', ', json_decode($c['redirect_uris'], true))) ?>
                            </td>
                            <td class="text-end pe-4">
                                <form method="post" action="<?= e(url('superadmin/developer/oauth/'.$c['id'].'/toggle')) ?>">
                                    <?= csrf_field() ?>
                                    <?php if($c['status'] == 1): ?>
                                        <button class="btn btn-success btn-sm fw-bold">Active (Revoke)</button>
                                    <?php else: ?>
                                        <button class="btn btn-outline-secondary btn-sm fw-bold">Disabled (Restore)</button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($oauthClients)): ?><tr><td colspan="5" class="text-center text-muted py-5">No OAuth clients created.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Create API Key -->
<div class="modal fade" id="createApiKeyModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/developer/api-keys')) ?>" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Generate API Key</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Key Name (Identifier) <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. Zapier Integration">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Tenant Isolation (Optional)</label>
                    <select name="school_id" class="form-select fw-bold">
                        <option value="">-- Global Platform Access (DANGEROUS) --</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>">Restrict to: <?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small text-dark">Permissions (Scopes)</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="scopes[]" value="read" checked>
                        <label class="form-check-label small">Read Data</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="scopes[]" value="write">
                        <label class="form-check-label small">Write Data</label>
                    </div>
                </div>
                <div class="alert alert-warning py-2 px-3 small border-0 d-flex mb-0">
                    <i data-lucide="alert-triangle" class="me-2 mt-1"></i>
                    <div>The raw token will only be shown once immediately after creation. It is irreversibly hashed in the database.</div>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Generate</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Create Webhook -->
<div class="modal fade" id="createWebhookModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/developer/webhooks')) ?>" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Register Webhook</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Endpoint URL <span class="text-danger">*</span></label>
                    <input type="url" name="url" class="form-control font-monospace" required placeholder="https://api.example.com/webhook">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Tenant Scope (Optional)</label>
                    <select name="school_id" class="form-select fw-bold">
                        <option value="">-- Global Events --</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>">Restrict to: <?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Events to receive</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="events[]" value="student.created" checked>
                        <label class="form-check-label small">student.created</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="events[]" value="invoice.paid">
                        <label class="form-check-label small">invoice.paid</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="events[]" value="attendance.marked">
                        <label class="form-check-label small">attendance.marked</label>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Register</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Create OAuth Client -->
<div class="modal fade" id="createOauthModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('superadmin/developer/oauth')) ?>" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold">Create OAuth Client</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Application Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. CRM Integration">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Tenant Scope (Optional)</label>
                    <select name="school_id" class="form-select fw-bold">
                        <option value="">-- Global Auth --</option>
                        <?php foreach($schools as $s): ?>
                            <option value="<?= $s['id'] ?>">Restrict to: <?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-dark">Redirect URIs</label>
                    <textarea name="redirect_uris" class="form-control font-monospace" rows="2" placeholder="https://app.com/callback, https://test.app.com/callback"></textarea>
                    <div class="form-text small">Comma separated list of valid callback URLs.</div>
                </div>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4">Create Client</button>
            </div>
        </form>
    </div>
</div>
