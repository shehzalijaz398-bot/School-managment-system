<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-speedometer2 text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
        <form method="POST" action="<?= url('superadmin/performance/clear-all') ?>" class="d-inline" id="purgeForm">
            <?= csrf_field() ?>
            <button type="button" class="btn btn-danger shadow-sm fw-bold px-4" id="purgeBtn">
                <i class="bi bi-lightning-fill me-2"></i> ⚡ Purge Application Cache Matrix
            </button>
        </form>
    </div>

    <div class="alert alert-dark border-0 shadow-sm mb-4">
        <div class="d-flex align-items-center">
            <i class="bi bi-cpu display-4 text-primary me-4"></i>
            <div>
                <h5 class="fw-bold mb-1">Architecture State: Highly Available</h5>
                <p class="mb-0 text-muted small">Global tenant SQL operations are currently being intercepted and statically cached via automated AES-256 hashed fragment vectors bounded securely by absolute <code>Auth::schoolId()</code> isolation logic.</p>
            </div>
        </div>
    </div>

    <!-- Active Real-Time Telemetry Metrics -->
    <div class="row">
        <!-- Cache Store Size -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card shadow h-100 py-2 border-left-primary">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Cache Store Size</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?= number_format($cacheSize / 1024 / 1024, 3) ?> <span class="small text-muted fs-6">MB</span></div>
                            <div class="text-xs text-muted mt-1 fw-bold"><?= number_format($cacheFiles) ?> Active Hashed Fragments</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-folder-symlink fs-1 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cache Hit Ratio -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card shadow h-100 py-2 border-left-success">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Cache Hit / Miss Ratio</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $hitRatio ?>%</div>
                            <div class="text-xs mt-1 fw-bold text-success"><i class="bi bi-arrow-up text-success"></i> Highly Optimized</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-pie-chart-fill fs-1 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Memory Utilization -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card shadow h-100 py-2 border-left-info">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Memory Util.</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?= number_format($memoryUsage / 1024 / 1024, 2) ?> <span class="small text-muted fs-6">MB</span></div>
                            <div class="text-xs mt-1 fw-bold text-muted">Active Execution Limit Node</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-memory fs-1 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Avg DB Execution Speed -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card shadow h-100 py-2 border-left-warning">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Avg Query Speed</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $avgQuerySpeed ?> <span class="small text-muted fs-6">ms</span></div>
                            <div class="text-xs mt-1 fw-bold text-warning"><i class="bi bi-activity text-warning"></i> Buffered Cursors Active</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-database-fill-gear fs-1 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optimization Rules -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-dark">
            <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-code-square me-2"></i> Automated Injection Parameters</h6>
        </div>
        <div class="card-body bg-light">
            <ul class="list-group list-group-flush shadow-sm border rounded">
                <li class="list-group-item bg-white py-3">
                    <i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Tenant Scoped Hashing:</strong> All cached SQL queries are mathematically bound to the active `Auth::schoolId()`. Cross-tenant data bleeds are physically impossible.
                </li>
                <li class="list-group-item bg-white py-3">
                    <i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Real-Time TTL Invalidation:</strong> <code>INSERT</code>, <code>UPDATE</code>, or <code>DELETE</code> operations trigger an instantaneous <code>unlink()</code> purge loop destroying ONLY that specific school's cached payload arrays.
                </li>
                <li class="list-group-item bg-white py-3">
                    <i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Buffered Optimizer Streams:</strong> Heavy reporting arrays are natively wrapped within <code>EXPLAIN</code> paths optimizing system RAM thresholds during mass rendering cycles.
                </li>
            </ul>
        </div>
    </div>
</div>

<script>
    // Asynchronous JavaScript interface animation block
    document.getElementById('purgeBtn').addEventListener('click', function(e) {
        if(confirm('CRITICAL WARNING: You are about to instantly drop the entire global cache matrix. This will spike DB I/O as cache rebuilds. Proceed?')) {
            const btn = e.target.closest('button');
            
            // Trigger animation
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Deprecating Fragments...';
            btn.classList.add('disabled', 'btn-secondary');
            btn.classList.remove('btn-danger');
            
            // Overlay effect
            document.body.style.opacity = '0.7';
            document.body.style.transition = 'opacity 0.3s ease';
            
            setTimeout(() => {
                document.getElementById('purgeForm').submit();
            }, 600);
        }
    });
</script>
