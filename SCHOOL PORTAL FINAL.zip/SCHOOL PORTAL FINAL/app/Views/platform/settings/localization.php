<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-globe2 text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
    </div>

    <div class="row">
        <!-- New Translation Form -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-header py-3 bg-light">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-translate me-2"></i> Append Translation Dictionary</h6>
                </div>
                <div class="card-body bg-white">
                    <form method="POST" action="<?= url('superadmin/settings/languages') ?>">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Target Locale / Language <span class="text-danger">*</span></label>
                            <select class="form-select shadow-sm border-primary border-opacity-50" name="locale_code" required>
                                <option value="" disabled selected>Select Language Code...</option>
                                <?php foreach($languages as $lang): ?>
                                    <option value="<?= htmlspecialchars($lang['locale_code']) ?>">
                                        <?= htmlspecialchars($lang['language_name']) ?> (<?= strtoupper($lang['locale_code']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Translation Key Token <span class="text-danger">*</span></label>
                            <input type="text" class="form-control shadow-sm font-monospace text-danger" name="translation_key" placeholder="e.g. dashboard.welcome_text" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark small">Translated String Value <span class="text-danger">*</span></label>
                            <textarea class="form-control shadow-sm" name="translated_value" rows="3" placeholder="Enter translated text here..." required></textarea>
                        </div>

                        <div class="d-grid mt-2">
                            <button type="submit" class="btn btn-primary fw-bold shadow">
                                <i class="bi bi-hdd-network me-1"></i> Bind Translation Node
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Translation Grid -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3 bg-dark d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-table me-2"></i> Master Translation Matrix</h6>
                </div>
                <div class="card-body bg-light p-0">
                    <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                        <table class="table table-hover table-bordered bg-white mb-0 align-middle">
                            <thead class="table-dark sticky-top text-uppercase small">
                                <tr>
                                    <th class="ps-3">Locale</th>
                                    <th>Token Key</th>
                                    <th>Translated String</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($translations as $t): ?>
                                <tr>
                                    <td class="ps-3 fw-bold text-primary">
                                        <?= strtoupper(htmlspecialchars($t['locale_code'])) ?>
                                    </td>
                                    <td>
                                        <code class="text-danger fw-bold"><?= htmlspecialchars($t['translation_key']) ?></code>
                                    </td>
                                    <td>
                                        <div class="text-dark" style="max-width: 300px; white-space: normal;">
                                            <?= htmlspecialchars($t['translated_value']) ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($translations)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-5"><i class="bi bi-slash-circle fs-1 d-block mb-3 text-gray-300"></i> Dictionary is empty.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
