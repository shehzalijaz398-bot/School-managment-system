<style>
  .sa-card { background: var(--sa-card); border: 1px solid var(--sa-border); border-radius: var(--sa-radius); padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
  .settings-sidebar { border-right: 1px solid var(--sa-border); padding-right: 1rem; }
  .nav-pills .nav-link { color: var(--sa-muted); font-weight: 600; font-size: 0.9rem; padding: 0.75rem 1rem; border-radius: 8px; margin-bottom: 5px; }
  .nav-pills .nav-link.active { background-color: var(--sa-primary); color: white; }
  .nav-pills .nav-link:hover:not(.active) { background-color: #f1f5f9; }
  .setting-group { margin-bottom: 2rem; }
  .setting-group-title { font-size: 0.85rem; font-weight: 800; color: var(--sa-muted); text-transform: uppercase; margin-bottom: 1rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.5rem; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 gap-3">
  <div>
    <h2 style="font-weight: 800; color: var(--sa-text); margin-bottom: 0.25rem;">Platform Settings</h2>
    <p style="color: var(--sa-muted); font-size: 0.95rem;">Manage global configurations, regional defaults, and SaaS infrastructure.</p>
  </div>
</div>

<div class="sa-card p-0">
    <div class="row g-0">
        <!-- Sidebar Navigation -->
        <div class="col-md-3 settings-sidebar p-4 bg-light" style="border-radius: var(--sa-radius) 0 0 var(--sa-radius);">
            <div class="mb-4">
                <input type="text" id="settingsSearch" class="form-control form-control-sm" placeholder="Search settings..." onkeyup="filterSettings()">
            </div>
            
            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <button class="nav-link text-start active" data-bs-toggle="pill" data-bs-target="#tab-general" type="button"><i data-lucide="settings" style="width:16px;height:16px;" class="me-2"></i> General</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-regional" type="button"><i data-lucide="globe" style="width:16px;height:16px;" class="me-2"></i> Regional & Localization</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-registration" type="button"><i data-lucide="user-plus" style="width:16px;height:16px;" class="me-2"></i> Registration & Onboarding</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-billing" type="button"><i data-lucide="credit-card" style="width:16px;height:16px;" class="me-2"></i> Billing & Tax</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-email" type="button"><i data-lucide="mail" style="width:16px;height:16px;" class="me-2"></i> SMTP & Email</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-notifications" type="button"><i data-lucide="bell" style="width:16px;height:16px;" class="me-2"></i> Notifications</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-security" type="button"><i data-lucide="shield" style="width:16px;height:16px;" class="me-2"></i> Security</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-maintenance" type="button"><i data-lucide="tool" style="width:16px;height:16px;" class="me-2"></i> Maintenance</button>
                <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-privacy" type="button"><i data-lucide="lock" style="width:16px;height:16px;" class="me-2"></i> Data & Privacy</button>
            </div>
        </div>
        
        <!-- Tab Content -->
        <div class="col-md-9 p-4">
            <form method="post" action="<?= e(url('superadmin/settings')) ?>" id="settingsForm">
                <?= csrf_field() ?>
                
                <div class="tab-content" id="v-pills-tabContent">
                    
                    <!-- General Tab -->
                    <div class="tab-pane fade show active" id="tab-general">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">General Settings</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save General</button>
                        </div>
                        
                        <div class="setting-group">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Platform Name <span class="text-danger">*</span></label>
                                    <input type="text" name="platform_name" class="form-control searchable" value="<?= e($settings['platform_name'] ?? 'School SaaS') ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Platform URL <span class="text-danger">*</span></label>
                                    <input type="url" name="platform_url" class="form-control searchable" value="<?= e($settings['platform_url'] ?? url('')) ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Support Email <span class="text-danger">*</span></label>
                                    <input type="email" name="support_email" class="form-control searchable" value="<?= e($settings['support_email'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Support Phone</label>
                                    <input type="text" name="support_phone" class="form-control searchable" value="<?= e($settings['support_phone'] ?? '') ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Regional Tab -->
                    <div class="tab-pane fade" id="tab-regional">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Regional & Localization</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Regional</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Timezone</label>
                                <input type="text" name="default_timezone" class="form-control searchable" value="<?= e($settings['default_timezone'] ?? 'UTC') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Currency</label>
                                <input type="text" name="default_currency" class="form-control searchable" value="<?= e($settings['default_currency'] ?? 'USD') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Date Format</label>
                                <input type="text" name="date_format" class="form-control searchable" value="<?= e($settings['date_format'] ?? 'Y-m-d') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Language</label>
                                <input type="text" name="default_language" class="form-control searchable" value="<?= e($settings['default_language'] ?? 'en') ?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Registration & Onboarding Tab -->
                    <div class="tab-pane fade" id="tab-registration">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Registration & Onboarding</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Registration</button>
                        </div>
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input searchable" type="checkbox" name="reg_enabled" id="reg_enabled" value="1" <?= ($settings['reg_enabled']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small" for="reg_enabled">Allow New School Registration</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input searchable" type="checkbox" name="reg_approval_req" id="reg_approval_req" value="1" <?= ($settings['reg_approval_req']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small" for="reg_approval_req">Registration Requires Manual Approval</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input searchable" type="checkbox" name="reg_email_verif_req" id="reg_email_verif_req" value="1" <?= ($settings['reg_email_verif_req']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small" for="reg_email_verif_req">Require Email Verification</label>
                                </div>
                                <div class="form-check form-switch">
                                    <input class="form-check-input searchable" type="checkbox" name="reg_doc_verif_req" id="reg_doc_verif_req" value="1" <?= ($settings['reg_doc_verif_req']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small" for="reg_doc_verif_req">Require Document Verification before Activation</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Trial Days</label>
                                <input type="number" name="default_trial_days" class="form-control searchable" value="<?= e($settings['default_trial_days'] ?? '14') ?>" min="0">
                            </div>
                        </div>
                    </div>

                    <!-- Billing & Tax Tab -->
                    <div class="tab-pane fade" id="tab-billing">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Billing & Tax</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Billing</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input searchable" type="checkbox" name="tax_enabled" id="tax_enabled" value="1" <?= ($settings['tax_enabled']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small" for="tax_enabled">Enable Global Tax Configuration</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Tax Rate (%)</label>
                                <input type="number" step="0.01" name="default_tax_rate" class="form-control searchable" value="<?= e($settings['default_tax_rate'] ?? '0') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Tax/VAT Number</label>
                                <input type="text" name="tax_vat_number" class="form-control searchable" value="<?= e($settings['tax_vat_number'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Invoice Prefix</label>
                                <input type="text" name="invoice_prefix" class="form-control searchable" value="<?= e($settings['invoice_prefix'] ?? 'INV-') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Default Invoice Due Days</label>
                                <input type="number" name="invoice_due_days" class="form-control searchable" value="<?= e($settings['invoice_due_days'] ?? '7') ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Offline Payment Instructions</label>
                                <textarea name="payment_instructions" class="form-control searchable" rows="3" placeholder="Bank details, transfer instructions..."><?= e($settings['payment_instructions'] ?? '') ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- SMTP & Email Tab -->
                    <div class="tab-pane fade" id="tab-email">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">SMTP & Email Configuration</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Email</button>
                        </div>
                        <div class="alert alert-warning py-2 small fw-bold mb-4">
                            <i data-lucide="alert-triangle" style="width:14px;height:14px;"></i> Passwords are never returned to the UI or stored in plaintext logs.
                        </div>
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">SMTP Host</label>
                                <input type="text" name="smtp_host" class="form-control searchable" value="<?= e($settings['smtp_host'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">SMTP Port</label>
                                <input type="text" name="smtp_port" class="form-control searchable" value="<?= e($settings['smtp_port'] ?? '587') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">SMTP Username</label>
                                <input type="text" name="smtp_username" class="form-control searchable" value="<?= e($settings['smtp_username'] ?? '') ?>" autocomplete="off">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">SMTP Password</label>
                                <input type="password" name="smtp_password" class="form-control searchable" placeholder="<?= isset($settings['smtp_password']) ? '•••••••• (Set)' : '' ?>" autocomplete="new-password">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Encryption</label>
                                <select name="smtp_encryption" class="form-select searchable">
                                    <option value="tls" <?= ($settings['smtp_encryption']??'')=='tls'?'selected':'' ?>>TLS</option>
                                    <option value="ssl" <?= ($settings['smtp_encryption']??'')=='ssl'?'selected':'' ?>>SSL</option>
                                    <option value="none" <?= ($settings['smtp_encryption']??'')=='none'?'selected':'' ?>>None</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">From Email</label>
                                <input type="email" name="smtp_from_email" class="form-control searchable" value="<?= e($settings['smtp_from_email'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">From Name</label>
                                <input type="text" name="smtp_from_name" class="form-control searchable" value="<?= e($settings['smtp_from_name'] ?? '') ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Notifications Tab -->
                    <div class="tab-pane fade" id="tab-notifications">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Notification Preferences</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Notifications</button>
                        </div>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input searchable" type="checkbox" name="notif_inapp" id="notif_inapp" value="1" <?= ($settings['notif_inapp']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small" for="notif_inapp">Enable Global In-App Notifications</label>
                        </div>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input searchable" type="checkbox" name="notif_email" id="notif_email" value="1" <?= ($settings['notif_email']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small" for="notif_email">Enable Global Email Notifications</label>
                        </div>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input searchable" type="checkbox" name="notif_sms" id="notif_sms" value="1" <?= ($settings['notif_sms']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small" for="notif_sms">Enable SMS Dispatch (Requires Gateway)</label>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input searchable" type="checkbox" name="notif_whatsapp" id="notif_whatsapp" value="1" <?= ($settings['notif_whatsapp']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small" for="notif_whatsapp">Enable WhatsApp Dispatch (Requires API)</label>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Notification Log Retention (Days)</label>
                                <input type="number" name="notif_retention_days" class="form-control searchable" value="<?= e($settings['notif_retention_days'] ?? '90') ?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Security Tab -->
                    <div class="tab-pane fade" id="tab-security">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Security Policies</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Security</button>
                        </div>
                        <div class="row g-4">
                            <div class="col-md-12">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input searchable" type="checkbox" name="sec_force_2fa" id="sec_force_2fa" value="1" <?= ($settings['sec_force_2fa']??'0')=='1'?'checked':'' ?>>
                                    <label class="form-check-label fw-bold small text-danger" for="sec_force_2fa">Force 2FA for all Platform Users</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Min Password Length</label>
                                <input type="number" name="sec_min_pass_len" class="form-control searchable" value="<?= e($settings['sec_min_pass_len'] ?? '8') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Login Attempt Limit</label>
                                <input type="number" name="sec_login_limit" class="form-control searchable" value="<?= e($settings['sec_login_limit'] ?? '5') ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Session Timeout (Minutes)</label>
                                <input type="number" name="sec_session_timeout" class="form-control searchable" value="<?= e($settings['sec_session_timeout'] ?? '120') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Allowed IP Whitelist (Comma separated)</label>
                                <textarea name="sec_allowed_ips" class="form-control searchable" rows="3"><?= e($settings['sec_allowed_ips'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Blocked IP Blacklist (Comma separated)</label>
                                <textarea name="sec_blocked_ips" class="form-control searchable" rows="3"><?= e($settings['sec_blocked_ips'] ?? '') ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Maintenance Tab -->
                    <div class="tab-pane fade" id="tab-maintenance">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Maintenance Mode</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Maintenance</button>
                        </div>
                        <div class="alert alert-danger py-2 small fw-bold mb-4">
                            <i data-lucide="power" style="width:14px;height:14px;"></i> Maintenance mode explicitly drops traffic from tenant portals and returns a 503 HTTP state.
                        </div>
                        
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input searchable" type="checkbox" name="maint_mode" id="maint_mode" value="1" <?= ($settings['maint_mode']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small text-danger" for="maint_mode">Activate Maintenance Mode Immediately</label>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input searchable" type="checkbox" name="maint_allow_admin" id="maint_allow_admin" value="1" <?= ($settings['maint_allow_admin']??'0')=='1'?'checked':'' ?>>
                            <label class="form-check-label fw-bold small" for="maint_allow_admin">Allow Super Admin Access During Maintenance</label>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">Maintenance Display Message</label>
                            <textarea name="maint_message" class="form-control searchable" rows="3" placeholder="We are currently performing system upgrades..."><?= e($settings['maint_message'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- Data & Privacy Tab -->
                    <div class="tab-pane fade" id="tab-privacy">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold m-0">Data & Privacy</h5>
                            <button type="submit" class="btn btn-primary btn-sm fw-bold px-4">Save Privacy</button>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Audit Log Retention (Days)</label>
                                <input type="number" name="privacy_audit_retention" class="form-control searchable" value="<?= e($settings['privacy_audit_retention'] ?? '365') ?>">
                                <div class="form-text small">Use 0 for infinite retention.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Account Deletion Rule</label>
                                <select name="privacy_account_deletion" class="form-select searchable">
                                    <option value="soft" <?= ($settings['privacy_account_deletion']??'')=='soft'?'selected':'' ?>>Soft Delete (Retain Data)</option>
                                    <option value="hard" <?= ($settings['privacy_account_deletion']??'')=='hard'?'selected':'' ?>>Hard Delete (Wipe Data)</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Privacy Policy URL</label>
                                <input type="url" name="privacy_policy_url" class="form-control searchable" value="<?= e($settings['privacy_policy_url'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Terms of Service URL</label>
                                <input type="url" name="privacy_terms_url" class="form-control searchable" value="<?= e($settings['privacy_terms_url'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let originalValues = {};
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('#settingsForm input, #settingsForm select, #settingsForm textarea');
    inputs.forEach(input => {
        if(input.name && input.name !== 'csrf_token' && input.name !== '_method') {
            originalValues[input.name] = input.type === 'checkbox' ? input.checked : input.value;
            input.addEventListener('change', checkUnsavedChanges);
            input.addEventListener('keyup', checkUnsavedChanges);
        }
    });
});

let isDirty = false;
function checkUnsavedChanges() {
    isDirty = false;
    const inputs = document.querySelectorAll('#settingsForm input, #settingsForm select, #settingsForm textarea');
    inputs.forEach(input => {
        if(input.name && input.name !== 'csrf_token' && input.name !== '_method' && input.type !== 'hidden') {
            let current = input.type === 'checkbox' ? input.checked : input.value;
            if(current !== originalValues[input.name]) {
                isDirty = true;
            }
        }
    });
    
    // Highlight save buttons if dirty
    const btns = document.querySelectorAll('#settingsForm button[type="submit"]');
    btns.forEach(b => {
        if(isDirty) {
            b.classList.remove('btn-primary');
            b.classList.add('btn-warning');
            b.innerHTML = 'Unsaved Changes (Save)';
        } else {
            b.classList.add('btn-primary');
            b.classList.remove('btn-warning');
            b.innerHTML = b.innerHTML.replace('Unsaved Changes (Save)', 'Save');
        }
    });
}

window.addEventListener('beforeunload', function(e) {
    if(isDirty) {
        e.preventDefault();
        e.returnValue = '';
    }
});

function filterSettings() {
    const q = document.getElementById('settingsSearch').value.toLowerCase();
    
    // Simple logic: if a tab has a match in any 'searchable' input or its label, show that tab
    const tabs = document.querySelectorAll('.tab-pane');
    tabs.forEach(tab => {
        let match = false;
        const searchables = tab.querySelectorAll('.searchable');
        searchables.forEach(s => {
            const label = s.closest('div').querySelector('label');
            if(s.name.toLowerCase().includes(q) || (label && label.innerText.toLowerCase().includes(q))) {
                match = true;
            }
        });
        
        const tabId = tab.id;
        const navLink = document.querySelector(`button[data-bs-target="#${tabId}"]`);
        if(match || q === '') {
            navLink.style.display = 'block';
        } else {
            navLink.style.display = 'none';
        }
    });
}
</script>
