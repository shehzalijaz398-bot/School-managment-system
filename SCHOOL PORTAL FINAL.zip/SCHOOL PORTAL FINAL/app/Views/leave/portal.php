<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Leave Applications</h1>
        <p class="text-muted small mb-0">Apply for leave, track application status, and review approvals</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#applyLeaveModal" style="font-weight: 500; font-size: 13px;">
            <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
            <span>Apply for Leave</span>
        </button>
    </div>
</div>

<?php if ($isParent && !empty($children) && count($children) > 1): ?>
<!-- Child Switcher for Parents -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-3 d-flex align-items-center flex-wrap gap-2">
        <span class="text-muted small fw-semibold me-2 d-flex align-items-center gap-1">
            <i data-lucide="users" style="width: 14px; height: 14px;"></i> Select Child:
        </span>
        <?php foreach ($children as $c): ?>
            <a href="<?= e(url('portal/leaves?student_id=' . $c['id'])) ?>" 
               class="btn btn-sm rounded-pill px-3 py-1 d-flex align-items-center gap-2 <?= ((int)$selectedStudentId === (int)$c['id']) ? 'btn-primary' : 'btn-outline-secondary' ?>"
               style="font-size: 12px; font-weight: 500;">
                <i data-lucide="user" style="width: 13px; height: 13px;"></i>
                <span><?= e(trim($c['first_name'] . ' ' . $c['last_name'])) ?></span>
                <?php if (!empty($c['class_name'])): ?>
                    <span class="badge bg-white bg-opacity-25 ms-1"><?= e($c['class_name']) ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Student Info Pill Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-3 d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
            <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 44px; height: 44px; background: #e0e7ff; color: #4338ca; font-size: 16px;">
                <?= e(strtoupper(substr($student['first_name'] ?? 'S', 0, 1))) ?>
            </div>
            <div>
                <h6 class="mb-0 fw-bold text-dark" style="font-size: 14px;"><?= e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></h6>
                <div class="text-muted small d-flex align-items-center gap-2" style="font-size: 12px;">
                    <span><i data-lucide="book-open" style="width: 12px; height: 12px;" class="me-1"></i> Class: <?= e($student['class_name'] ?? 'N/A') ?><?= !empty($student['section_name']) ? ' (' . e($student['section_name']) . ')' : '' ?></span>
                    <span>•</span>
                    <span>Admission: <?= e($student['admission_no'] ?? 'N/A') ?></span>
                    <?php if (!empty($student['roll_no'])): ?>
                        <span>•</span>
                        <span>Roll: <?= e($student['roll_no']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-pill bg-light text-dark border px-3 py-2 small" style="font-size: 12px;">
                <i data-lucide="shield-check" style="width: 13px; height: 13px; stroke: #16a34a;" class="me-1"></i> Student Portal Active
            </span>
        </div>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eff6ff; width: 34px; height: 34px;">
                        <i data-lucide="file-text" style="width: 16px; height: 16px; stroke: #2563eb;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Applications</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <?php if (($stats['pending'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark px-2 py-1" style="font-size: 10px;">Pending</span>
                    <?php endif; ?>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['pending'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Under Review</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="check-circle-2" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['approved'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Approved Leaves</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 34px; height: 34px;">
                        <i data-lucide="x-circle" style="width: 16px; height: 16px; stroke: #dc2626;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['rejected'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Rejected Applications</div>
            </div>
        </div>
    </div>
</div>

<!-- Applications History Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
        <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
            <i data-lucide="history" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
            <span>Leave Applications History</span>
        </h6>
        <span class="text-muted small"><?= count($leaves) ?> records found</span>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                <tr>
                    <th class="px-3 py-3">Leave Type</th>
                    <th class="py-3">Dates &amp; Duration</th>
                    <th class="py-3">Reason</th>
                    <th class="py-3">Attachment</th>
                    <th class="py-3">Status</th>
                    <th class="py-3">Feedback / Remarks</th>
                    <th class="text-end px-3 py-3">Actions</th>
                </tr>
            </thead>
            <tbody style="font-size: 13px;">
                <?php if (!empty($leaves)): ?>
                    <?php foreach ($leaves as $l): ?>
                        <tr>
                            <td class="px-3 py-3 fw-semibold text-dark">
                                <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                    <i data-lucide="tag" style="width: 11px; height: 11px;" class="me-1"></i>
                                    <?= e($l['leave_type'] ?? 'General Leave') ?>
                                </span>
                            </td>
                            <td class="py-3">
                                <div class="fw-semibold text-dark mb-0" style="font-size: 13px;">
                                    <?= e(date('d M Y', strtotime($l['start_date']))) ?> &rarr; <?= e(date('d M Y', strtotime($l['end_date']))) ?>
                                </div>
                                <span class="badge rounded-pill px-2 py-0" style="background: #f1f5f9; color: #475569; font-size: 10px;">
                                    <i data-lucide="calendar" style="width: 10px; height: 10px;" class="me-1"></i>
                                    <?= (float)$l['days'] ?> <?= ((float)$l['days'] == 1) ? 'Day' : 'Days' ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 200px;">
                                <div class="text-truncate text-secondary" title="<?= e($l['reason'] ?? '') ?>">
                                    <?= !empty($l['reason']) ? e($l['reason']) : '<span class="text-muted fst-italic">None provided</span>' ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php if (!empty($l['attachment'])): ?>
                                    <a href="<?= e(url($l['attachment'])) ?>" target="_blank" class="btn btn-sm btn-light rounded-pill px-2 py-1 border d-inline-flex align-items-center gap-1" style="font-size: 11px;" title="View Attachment">
                                        <i data-lucide="paperclip" style="width: 12px; height: 12px; stroke: #2563eb;"></i>
                                        <span>View</span>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3">
                                <?php
                                    $st = strtolower($l['status'] ?? 'pending');
                                    $badgeBg = match($st) {
                                        'approved' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                        'rejected' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                        'cancelled' => 'background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;',
                                        default => 'background: #fef3c7; color: #b45309; border: 1px solid #fde68a;',
                                    };
                                ?>
                                <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                    <?= ucfirst($st) ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 180px;">
                                <?php if (!empty($l['review_notes'])): ?>
                                    <div class="small text-dark text-truncate" title="<?= e($l['review_notes']) ?>">
                                        <i data-lucide="message-square" style="width: 11px; height: 11px; stroke: #4f46e5;" class="me-1"></i>
                                        <?= e($l['review_notes']) ?>
                                    </div>
                                    <?php if (!empty($l['reviewer_name'])): ?>
                                        <div class="text-muted" style="font-size: 10px;">By: <?= e($l['reviewer_name']) ?></div>
                                    <?php endif; ?>
                                <?php elseif ($l['status'] === 'pending'): ?>
                                    <span class="text-muted small fst-italic">Waiting for approval</span>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end px-3 py-3">
                                <div class="d-flex align-items-center justify-content-end gap-1">
                                    <button type="button" class="btn btn-sm btn-light rounded-pill px-2 py-1 border btn-view-leave-detail" 
                                            data-id="<?= (int)$l['id'] ?>"
                                            data-type="<?= e($l['leave_type'] ?? 'Leave') ?>"
                                            data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                            data-days="<?= (float)$l['days'] ?>"
                                            data-reason="<?= e($l['reason'] ?? '') ?>"
                                            data-status="<?= e(ucfirst($l['status'])) ?>"
                                            data-status-raw="<?= e($l['status']) ?>"
                                            data-attachment="<?= !empty($l['attachment']) ? e(url($l['attachment'])) : '' ?>"
                                            data-reviewer="<?= e($l['reviewer_name'] ?? '') ?>"
                                            data-notes="<?= e($l['review_notes'] ?? '') ?>"
                                            data-submitted="<?= e(date('d M Y, h:i A', strtotime($l['created_at']))) ?>"
                                            title="View Details">
                                        <i data-lucide="eye" style="width: 13px; height: 13px;"></i>
                                    </button>

                                    <?php if ($l['status'] === 'pending'): ?>
                                        <form method="post" action="<?= e(url('leave/' . $l['id'] . '/cancel')) ?>" onsubmit="return confirm('Are you sure you want to cancel this leave application?');" class="d-inline m-0">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1" title="Cancel Application" style="font-size: 11px;">
                                                <i data-lucide="x" style="width: 12px; height: 12px;"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <div class="p-4 text-center">
                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                    <i data-lucide="calendar-x-2" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No Leave Applications Found</h6>
                                <p class="text-muted small mb-3">You haven't submitted any leave requests yet.</p>
                                <button class="btn btn-primary btn-sm rounded-pill px-3 py-2" data-bs-toggle="modal" data-bs-target="#applyLeaveModal">
                                    <i data-lucide="plus" style="width: 14px; height: 14px;" class="me-1"></i> Apply for Leave Now
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Apply for Leave -->
<div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 text-white" style="background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%);">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 p-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                        <i data-lucide="calendar-plus" style="width: 16px; height: 16px; stroke: #ffffff;"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold text-white mb-0" style="font-size: 16px;">Apply for Student Leave</h5>
                        <div class="text-white text-opacity-75 small" style="font-size: 11px;">Submit request for class teacher &amp; school approval</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <form method="post" action="<?= e(url('leave')) ?>" enctype="multipart/form-data" id="portalLeaveForm">
                <?= csrf_field() ?>
                <input type="hidden" name="student_id" value="<?= (int)$selectedStudentId ?>">

                <div class="modal-body px-4 py-4 bg-light">
                    <?php if ($isParent && !empty($children) && count($children) > 1): ?>
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Applying for Child <span class="text-danger">*</span></label>
                        <select name="student_id" class="form-select rounded-3 shadow-sm border-0" required>
                            <?php foreach ($children as $c): ?>
                                <option value="<?= (int)$c['id'] ?>" <?= ((int)$selectedStudentId === (int)$c['id']) ? 'selected' : '' ?>>
                                    <?= e(trim($c['first_name'] . ' ' . $c['last_name'])) ?> &mdash; Class: <?= e($c['class_name'] ?? 'N/A') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Leave Type <span class="text-danger">*</span></label>
                        <select name="leave_type_id" class="form-select rounded-3 shadow-sm border-0" required>
                            <option value="">-- Select Leave Category --</option>
                            <?php foreach ($types as $t): ?>
                                <option value="<?= (int)$t['id'] ?>"><?= e($t['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label text-sm fw-semibold text-dark">From Date <span class="text-danger">*</span></label>
                            <input type="date" name="start_date" id="portalStartDate" class="form-control rounded-3 shadow-sm border-0" required value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label text-sm fw-semibold text-dark">To Date <span class="text-danger">*</span></label>
                            <input type="date" name="end_date" id="portalEndDate" class="form-control rounded-3 shadow-sm border-0" required value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>

                    <!-- Dynamic Day Duration Badge -->
                    <div class="p-2 px-3 rounded-3 mb-3 d-flex align-items-center justify-content-between" style="background: #eef2ff; border: 1px solid #c7d2fe;">
                        <span class="text-dark small fw-medium" style="font-size: 12px;">
                            <i data-lucide="info" style="width: 14px; height: 14px; stroke: #4f46e5;" class="me-1"></i> Total Calculated Days:
                        </span>
                        <span class="badge rounded-pill bg-primary fw-bold px-3 py-1" id="portalCalculatedDays" style="font-size: 12px;">1 Day</span>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Reason / Description <span class="text-danger">*</span></label>
                        <textarea name="reason" rows="3" class="form-control rounded-3 shadow-sm border-0" placeholder="Please mention reason for leave (e.g. Fever, Doctor appointment, Family wedding)..." required></textarea>
                    </div>

                    <div class="mb-2">
                        <label class="form-label text-sm fw-semibold text-dark d-flex justify-content-between align-items-center">
                            <span>Doctor's Note / Document <span class="text-muted fw-normal">(Optional)</span></span>
                            <span class="text-muted small" style="font-size: 11px;">JPG, PNG, PDF (Max 5MB)</span>
                        </label>
                        <input type="file" name="attachment" class="form-control rounded-3 shadow-sm border-0" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                        <div class="form-text" style="font-size: 11px;">Attach doctor's prescription, hospital slip, or signed parent application letter.</div>
                    </div>
                </div>

                <div class="modal-footer px-4 py-3 bg-white border-top-0 d-flex justify-content-between">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm">
                        <i data-lucide="send" style="width: 14px; height: 14px;"></i>
                        <span>Submit Application</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: View Leave Details -->
<div class="modal fade" id="leaveDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 bg-light">
                <h5 class="modal-title fw-bold text-dark mb-0 d-flex align-items-center gap-2" style="font-size: 16px;">
                    <i data-lucide="file-text" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    <span>Leave Application Details</span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 py-4">
                <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                    <div>
                        <div class="text-muted small" style="font-size: 11px;">LEAVE TYPE</div>
                        <h6 class="fw-bold text-dark mb-0" id="detailType">-</h6>
                    </div>
                    <div>
                        <div class="text-muted small text-end" style="font-size: 11px;">STATUS</div>
                        <div id="detailStatusBadge">-</div>
                    </div>
                </div>

                <div class="row g-3 mb-3 pb-3 border-bottom">
                    <div class="col-6">
                        <div class="text-muted small" style="font-size: 11px;">DATES</div>
                        <div class="fw-semibold text-dark small" id="detailDates">-</div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small" style="font-size: 11px;">DURATION</div>
                        <div class="fw-semibold text-dark small" id="detailDays">-</div>
                    </div>
                    <div class="col-12">
                        <div class="text-muted small" style="font-size: 11px;">SUBMITTED ON</div>
                        <div class="fw-semibold text-dark small" id="detailSubmitted">-</div>
                    </div>
                </div>

                <div class="mb-3 pb-3 border-bottom">
                    <div class="text-muted small mb-1" style="font-size: 11px;">REASON</div>
                    <p class="text-dark small mb-0 p-2 rounded-3 bg-light" id="detailReason">-</p>
                </div>

                <div class="mb-3 pb-3 border-bottom" id="detailAttachmentContainer" style="display: none;">
                    <div class="text-muted small mb-1" style="font-size: 11px;">SUPPORTING ATTACHMENT</div>
                    <a href="#" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 d-inline-flex align-items-center gap-2" id="detailAttachmentLink">
                        <i data-lucide="paperclip" style="width: 14px; height: 14px;"></i>
                        <span>Download / View Document</span>
                    </a>
                </div>

                <div id="detailReviewContainer" style="display: none;">
                    <div class="text-muted small mb-1" style="font-size: 11px;">REVIEWER FEEDBACK &amp; NOTES</div>
                    <div class="p-3 rounded-3" style="background: #f8fafc; border: 1px solid #e2e8f0;">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i data-lucide="user-check" style="width: 14px; height: 14px; stroke: #16a34a;"></i>
                            <span class="fw-semibold text-dark small" id="detailReviewer">Admin</span>
                        </div>
                        <p class="text-secondary small mb-0" id="detailNotes">No additional remarks.</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer px-4 py-3 bg-light border-top-0">
                <button type="button" class="btn btn-secondary rounded-pill px-4 fw-semibold w-100" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Dynamic duration calculator for Portal
    const startInput = document.getElementById('portalStartDate');
    const endInput = document.getElementById('portalEndDate');
    const badge = document.getElementById('portalCalculatedDays');

    function updatePortalDays() {
        if (!startInput || !endInput || !badge) return;
        const sVal = startInput.value;
        const eVal = endInput.value;
        if (!sVal || !eVal) return;

        const sDate = new Date(sVal);
        const eDate = new Date(eVal);

        if (eDate < sDate) {
            badge.textContent = 'Invalid (End before Start)';
            badge.className = 'badge rounded-pill bg-danger fw-bold px-3 py-1';
            return;
        }

        const diffTime = Math.abs(eDate - sDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        badge.textContent = diffDays + (diffDays === 1 ? ' Day' : ' Days');
        badge.className = 'badge rounded-pill bg-primary fw-bold px-3 py-1';
    }

    if (startInput && endInput) {
        startInput.addEventListener('change', updatePortalDays);
        endInput.addEventListener('change', updatePortalDays);
        updatePortalDays();
    }

    // Details modal trigger
    document.querySelectorAll('.btn-view-leave-detail').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.getElementById('detailType').textContent = this.dataset.type || '-';
            document.getElementById('detailDates').textContent = this.dataset.dates || '-';
            document.getElementById('detailDays').textContent = (this.dataset.days || '1') + ' Days';
            document.getElementById('detailReason').textContent = this.dataset.reason || 'None provided.';
            document.getElementById('detailSubmitted').textContent = this.dataset.submitted || '-';

            const rawSt = (this.dataset.statusRaw || 'pending').toLowerCase();
            let badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#fef3c7; color:#b45309;">Pending</span>';
            if (rawSt === 'approved') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#dcfce7; color:#15803d;">Approved</span>';
            } else if (rawSt === 'rejected') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#fee2e2; color:#b91c1c;">Rejected</span>';
            } else if (rawSt === 'cancelled') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#f1f5f9; color:#64748b;">Cancelled</span>';
            }
            document.getElementById('detailStatusBadge').innerHTML = badgeHtml;

            // Attachment
            const attachLink = this.dataset.attachment;
            const attachContainer = document.getElementById('detailAttachmentContainer');
            if (attachLink) {
                document.getElementById('detailAttachmentLink').href = attachLink;
                attachContainer.style.display = 'block';
            } else {
                attachContainer.style.display = 'none';
            }

            // Review notes
            const reviewContainer = document.getElementById('detailReviewContainer');
            if (rawSt === 'approved' || rawSt === 'rejected') {
                document.getElementById('detailReviewer').textContent = this.dataset.reviewer ? 'Reviewed by: ' + this.dataset.reviewer : 'Reviewed by Staff/Admin';
                document.getElementById('detailNotes').textContent = this.dataset.notes || 'No remarks provided.';
                reviewContainer.style.display = 'block';
            } else {
                reviewContainer.style.display = 'none';
            }

            const modal = new bootstrap.Modal(document.getElementById('leaveDetailModal'));
            modal.show();
        });
    });
});
</script>
