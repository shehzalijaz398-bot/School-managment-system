<?php
$layout = 'layouts/app';

$activeTab = $tab ?? 'students';
$isTeacherMode = ($viewMode === 'teacher');
$isAdminMode = ($viewMode === 'admin');
$isStaffMode = ($viewMode === 'staff');
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Leave Management') ?>
        </h1>
        <p class="text-muted small mb-0">
            <?php if ($isAdminMode): ?>
                Review student &amp; staff leave applications, manage approval workflows, and synchronize attendance
            <?php elseif ($isTeacherMode): ?>
                Review class student leaves and submit your own leave applications for admin approval
            <?php else: ?>
                View leave requests, submit time-off applications, and track approval status
            <?php endif; ?>
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <?php if ($isAdminMode || $isTeacherMode): ?>
            <a href="<?= e(url('leave/export-csv?type=' . ($activeTab === 'staff' ? 'staff' : 'student') . '&status=' . urlencode($filters['status'] ?? '') . '&class_id=' . (int)($filters['class_id'] ?? 0))) ?>" 
               class="btn btn-outline-secondary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
               style="font-size: 13px; font-weight: 500;">
                <i data-lucide="download" style="width: 15px; height: 15px;"></i>
                <span>Export CSV</span>
            </a>
        <?php endif; ?>

        <?php if (!empty($employeeId)): ?>
            <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                    data-bs-toggle="modal" data-bs-target="#requestStaffLeaveModal" 
                    style="font-size: 13px; font-weight: 500;">
                <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
                <span>Apply for Leave</span>
            </button>
        <?php endif; ?>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <?php if (($stats['pending_total'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark px-2 py-1" style="font-size: 10px; font-weight: 600;">Action Required</span>
                    <?php endif; ?>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['pending_total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Pending Approvals</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="check-circle-2" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['approved_month'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Approved (This Month)</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 34px; height: 34px;">
                        <i data-lucide="x-circle" style="width: 16px; height: 16px; stroke: #dc2626;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['rejected_month'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Rejected Applications</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="calendar-off" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-secondary border px-2 py-0" style="font-size: 10px;">Today</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['on_leave_today'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Currently on Leave</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs & Filter Section -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-3" style="border-color: #f1f5f9 !important;">
        <!-- Navigation Tabs -->
        <ul class="nav nav-pills gap-2" id="leaveTabs">
            <?php if ($isAdminMode): ?>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'students') ? 'active' : '' ?>" 
                       href="<?= e(url('leave?tab=students')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="graduation-cap" style="width: 16px; height: 16px;"></i>
                        <span>Student Leaves</span>
                        <?php if (!empty($stats['pending_students'])): ?>
                            <span class="badge rounded-pill bg-danger text-white ms-1" style="font-size: 10px;"><?= (int)$stats['pending_students'] ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'staff') ? 'active' : '' ?>" 
                       href="<?= e(url('leave?tab=staff')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="briefcase" style="width: 16px; height: 16px;"></i>
                        <span>Staff Leaves</span>
                        <?php if (!empty($stats['pending_staff'])): ?>
                            <span class="badge rounded-pill bg-danger text-white ms-1" style="font-size: 10px;"><?= (int)$stats['pending_staff'] ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'my') ? 'active' : '' ?>" 
                       href="<?= e(url('leave?tab=my')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="user" style="width: 16px; height: 16px;"></i>
                        <span>My Leaves</span>
                    </a>
                </li>
            <?php elseif ($isTeacherMode): ?>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'students') ? 'active' : '' ?>" 
                       href="<?= e(url('leave?tab=students')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="graduation-cap" style="width: 16px; height: 16px;"></i>
                        <span>My Class Student Leaves</span>
                        <?php if (!empty($stats['pending_total'])): ?>
                            <span class="badge rounded-pill bg-danger text-white ms-1" style="font-size: 10px;"><?= (int)$stats['pending_total'] ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'my') ? 'active' : '' ?>" 
                       href="<?= e(url('leave?tab=my')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="user" style="width: 16px; height: 16px;"></i>
                        <span>My Leave Requests</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 active" 
                       href="<?= e(url('leave?tab=my')) ?>" style="font-size: 13px; font-weight: 500;">
                        <i data-lucide="user" style="width: 16px; height: 16px;"></i>
                        <span>My Leave Records</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>

        <div class="text-muted small">
            <?php
                $count = match($activeTab) {
                    'staff' => count($staffLeaves ?? []),
                    'my' => count($myLeaves ?? []),
                    default => count($studentLeaves ?? []),
                };
                echo "Showing <strong>{$count}</strong> records";
            ?>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card-body p-3 bg-light border-bottom" style="border-color: #f1f5f9 !important;">
        <form method="get" action="<?= e(url('leave')) ?>" class="row g-2 align-items-center">
            <input type="hidden" name="tab" value="<?= e($activeTab) ?>">

            <div class="col-12 col-md-4">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0 rounded-start-pill text-muted px-3">
                        <i data-lucide="search" style="width: 14px; height: 14px;"></i>
                    </span>
                    <input type="text" name="q" value="<?= e($filters['q'] ?? '') ?>" 
                           class="form-control form-control-sm border-start-0 rounded-end-pill shadow-none" 
                           placeholder="<?= ($activeTab === 'staff') ? 'Search staff by name, code...' : 'Search student by name, roll, adm no...' ?>">
                </div>
            </div>

            <div class="col-6 col-md-2">
                <select name="status" class="form-select form-select-sm rounded-pill shadow-none">
                    <option value="">All Statuses</option>
                    <option value="pending" <?= (($filters['status'] ?? '') === 'pending') ? 'selected' : '' ?>>Pending</option>
                    <option value="approved" <?= (($filters['status'] ?? '') === 'approved') ? 'selected' : '' ?>>Approved</option>
                    <option value="rejected" <?= (($filters['status'] ?? '') === 'rejected') ? 'selected' : '' ?>>Rejected</option>
                    <option value="cancelled" <?= (($filters['status'] ?? '') === 'cancelled') ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>

            <?php if ($activeTab === 'students' && !empty($classes)): ?>
                <div class="col-6 col-md-2">
                    <select name="class_id" id="filterClassId" class="form-select form-select-sm rounded-pill shadow-none">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $cls): ?>
                            <option value="<?= (int)$cls['id'] ?>" <?= ((int)($filters['class_id'] ?? 0) === (int)$cls['id']) ? 'selected' : '' ?>>
                                <?= e($cls['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php elseif ($activeTab === 'staff' && !empty($departments)): ?>
                <div class="col-6 col-md-2">
                    <select name="department_id" class="form-select form-select-sm rounded-pill shadow-none">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= (int)$d['id'] ?>" <?= ((int)($filters['department_id'] ?? 0) === (int)$d['id']) ? 'selected' : '' ?>>
                                <?= e($d['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <div class="col-12 col-md-auto ms-auto d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-dark rounded-pill px-3 d-flex align-items-center gap-1 shadow-sm">
                    <i data-lucide="filter" style="width: 13px; height: 13px;"></i> Filter
                </button>
                <a href="<?= e(url('leave?tab=' . $activeTab)) ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- Tab 1: Student Leaves Table -->
    <?php if ($activeTab === 'students'): ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                <tr>
                    <th class="px-3 py-3">Student</th>
                    <th class="py-3">Class &amp; Section</th>
                    <th class="py-3">Leave Category</th>
                    <th class="py-3">Dates &amp; Duration</th>
                    <th class="py-3">Reason</th>
                    <th class="py-3">Document</th>
                    <th class="py-3">Status</th>
                    <th class="text-end px-3 py-3">Actions</th>
                </tr>
            </thead>
            <tbody style="font-size: 13px;">
                <?php if (!empty($studentLeaves)): ?>
                    <?php foreach ($studentLeaves as $l): ?>
                        <tr>
                            <td class="px-3 py-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 36px; height: 36px; background: #e0e7ff; color: #4338ca; font-size: 13px;">
                                        <?= e(strtoupper(substr($l['student_name'] ?? 'S', 0, 1))) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size: 13px;"><?= e($l['student_name']) ?></div>
                                        <div class="text-muted" style="font-size: 11px;">Adm: <?= e($l['admission_no'] ?? 'N/A') ?><?= !empty($l['roll_no']) ? ' • Roll: ' . e($l['roll_no']) : '' ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="py-3">
                                <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                    <?= e($l['class_name'] ?? 'N/A') ?><?= !empty($l['section_name']) ? ' &bull; ' . e($l['section_name']) : '' ?>
                                </span>
                            </td>
                            <td class="py-3">
                                <span class="badge rounded-pill px-2 py-1" style="background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; font-size: 11px;">
                                    <?= e($l['leave_type'] ?? 'General') ?>
                                </span>
                            </td>
                            <td class="py-3">
                                <div class="fw-semibold text-dark" style="font-size: 12px;">
                                    <?= e(date('d M Y', strtotime($l['start_date']))) ?> &rarr; <?= e(date('d M Y', strtotime($l['end_date']))) ?>
                                </div>
                                <span class="badge rounded-pill px-2 py-0" style="background: #f1f5f9; color: #475569; font-size: 10px;">
                                    <?= (float)$l['days'] ?> <?= ((float)$l['days'] == 1) ? 'Day' : 'Days' ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 180px;">
                                <div class="text-truncate text-secondary" title="<?= e($l['reason'] ?? '') ?>">
                                    <?= !empty($l['reason']) ? e($l['reason']) : '<span class="text-muted fst-italic">None</span>' ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php if (!empty($l['attachment'])): ?>
                                    <a href="<?= e(url($l['attachment'])) ?>" target="_blank" class="btn btn-sm btn-light rounded-pill px-2 py-1 border d-inline-flex align-items-center gap-1" style="font-size: 11px;">
                                        <i data-lucide="paperclip" style="width: 12px; height: 12px; stroke: #2563eb;"></i> View
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3">
                                <?php
                                    $st = strtolower($l['status'] ?? 'pending');
                                    $badgeBg = match($st) {
                                        'approved' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                        'rejected' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                        'cancelled' => 'background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;',
                                        default => 'background: #fef3c7; color: #b45309; border: 1px solid #fde68a;',
                                    };
                                ?>
                                <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                    <?= ucfirst($st) ?>
                                </span>
                            </td>
                            <td class="text-end px-3 py-3">
                                <div class="d-flex align-items-center justify-content-end gap-1">
                                    <?php if ($l['status'] === 'pending' && ($isAdminMode || $isTeacherMode)): ?>
                                        <button type="button" class="btn btn-sm btn-success rounded-pill px-2 py-1 btn-review-leave"
                                                data-id="<?= (int)$l['id'] ?>"
                                                data-name="<?= e($l['student_name']) ?>"
                                                data-meta="Class: <?= e($l['class_name'] ?? 'N/A') ?>"
                                                data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                                data-days="<?= (float)$l['days'] ?>"
                                                data-reason="<?= e($l['reason'] ?? '') ?>"
                                                data-action="approved"
                                                data-tab="students"
                                                title="Approve Leave">
                                            <i data-lucide="check" style="width: 13px; height: 13px;"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1 btn-review-leave"
                                                data-id="<?= (int)$l['id'] ?>"
                                                data-name="<?= e($l['student_name']) ?>"
                                                data-meta="Class: <?= e($l['class_name'] ?? 'N/A') ?>"
                                                data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                                data-days="<?= (float)$l['days'] ?>"
                                                data-reason="<?= e($l['reason'] ?? '') ?>"
                                                data-action="rejected"
                                                data-tab="students"
                                                title="Reject Leave">
                                            <i data-lucide="x" style="width: 13px; height: 13px;"></i>
                                        </button>
                                    <?php endif; ?>

                                    <button type="button" class="btn btn-sm btn-light rounded-pill px-2 py-1 border btn-view-leave-detail" 
                                            data-id="<?= (int)$l['id'] ?>"
                                            data-name="<?= e($l['student_name']) ?>"
                                            data-type="<?= e($l['leave_type'] ?? 'Leave') ?>"
                                            data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                            data-days="<?= (float)$l['days'] ?>"
                                            data-reason="<?= e($l['reason'] ?? '') ?>"
                                            data-status="<?= e(ucfirst($l['status'])) ?>"
                                            data-status-raw="<?= e($l['status']) ?>"
                                            data-attachment="<?= !empty($l['attachment']) ? e(url($l['attachment'])) : '' ?>"
                                            data-reviewer="<?= e($l['reviewer_name'] ?? '') ?>"
                                            data-notes="<?= e($l['review_notes'] ?? '') ?>"
                                            data-submitted="<?= e(date('d M Y, h:i A', strtotime($l['created_at']))) ?>"
                                            title="View Details">
                                        <i data-lucide="eye" style="width: 13px; height: 13px;"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <div class="p-4 text-center">
                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                    <i data-lucide="calendar-check" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No Student Leave Requests</h6>
                                <p class="text-muted small mb-0">No matching student leave requests found for the selected filters.</p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tab 2: Staff Leaves Table -->
    <?php elseif ($activeTab === 'staff'): ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                <tr>
                    <th class="px-3 py-3">Employee</th>
                    <th class="py-3">Department &amp; Designation</th>
                    <th class="py-3">Leave Type</th>
                    <th class="py-3">Dates &amp; Duration</th>
                    <th class="py-3">Reason</th>
                    <th class="py-3">Document</th>
                    <th class="py-3">Status</th>
                    <th class="text-end px-3 py-3">Actions</th>
                </tr>
            </thead>
            <tbody style="font-size: 13px;">
                <?php if (!empty($staffLeaves)): ?>
                    <?php foreach ($staffLeaves as $l): ?>
                        <tr>
                            <td class="px-3 py-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 36px; height: 36px; background: #fef3c7; color: #b45309; font-size: 13px;">
                                        <?= e(strtoupper(substr($l['employee_name'] ?? 'E', 0, 1))) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size: 13px;"><?= e($l['employee_name']) ?></div>
                                        <div class="text-muted" style="font-size: 11px;">Code: <?= e($l['employee_code'] ?? 'N/A') ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="py-3">
                                <div class="text-dark fw-medium small"><?= e($l['department_name'] ?? 'General') ?></div>
                                <div class="text-muted" style="font-size: 11px;"><?= e($l['designation_name'] ?? 'Staff') ?></div>
                            </td>
                            <td class="py-3">
                                <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                    <?= e($l['leave_type'] ?? 'Staff Leave') ?>
                                    <?php if (isset($l['is_paid']) && (int)$l['is_paid'] === 1): ?>
                                        <span class="text-success ms-1">• Paid</span>
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td class="py-3">
                                <div class="fw-semibold text-dark" style="font-size: 12px;">
                                    <?= e(date('d M Y', strtotime($l['start_date']))) ?> &rarr; <?= e(date('d M Y', strtotime($l['end_date']))) ?>
                                </div>
                                <span class="badge rounded-pill px-2 py-0" style="background: #f1f5f9; color: #475569; font-size: 10px;">
                                    <?= (float)$l['days'] ?> <?= ((float)$l['days'] == 1) ? 'Day' : 'Days' ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 180px;">
                                <div class="text-truncate text-secondary" title="<?= e($l['reason'] ?? '') ?>">
                                    <?= !empty($l['reason']) ? e($l['reason']) : '<span class="text-muted fst-italic">None</span>' ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php if (!empty($l['attachment'])): ?>
                                    <a href="<?= e(url($l['attachment'])) ?>" target="_blank" class="btn btn-sm btn-light rounded-pill px-2 py-1 border d-inline-flex align-items-center gap-1" style="font-size: 11px;">
                                        <i data-lucide="paperclip" style="width: 12px; height: 12px; stroke: #2563eb;"></i> View
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3">
                                <?php
                                    $st = strtolower($l['status'] ?? 'pending');
                                    $badgeBg = match($st) {
                                        'approved' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                        'rejected' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                        'cancelled' => 'background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;',
                                        default => 'background: #fef3c7; color: #b45309; border: 1px solid #fde68a;',
                                    };
                                ?>
                                <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                    <?= ucfirst($st) ?>
                                </span>
                            </td>
                            <td class="text-end px-3 py-3">
                                <div class="d-flex align-items-center justify-content-end gap-1">
                                    <?php if ($l['status'] === 'pending' && $isAdminMode): ?>
                                        <button type="button" class="btn btn-sm btn-success rounded-pill px-2 py-1 btn-review-leave"
                                                data-id="<?= (int)$l['id'] ?>"
                                                data-name="<?= e($l['employee_name']) ?>"
                                                data-meta="Dept: <?= e($l['department_name'] ?? 'Staff') ?>"
                                                data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                                data-days="<?= (float)$l['days'] ?>"
                                                data-reason="<?= e($l['reason'] ?? '') ?>"
                                                data-action="approved"
                                                data-tab="staff"
                                                title="Approve Staff Leave">
                                            <i data-lucide="check" style="width: 13px; height: 13px;"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1 btn-review-leave"
                                                data-id="<?= (int)$l['id'] ?>"
                                                data-name="<?= e($l['employee_name']) ?>"
                                                data-meta="Dept: <?= e($l['department_name'] ?? 'Staff') ?>"
                                                data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                                data-days="<?= (float)$l['days'] ?>"
                                                data-reason="<?= e($l['reason'] ?? '') ?>"
                                                data-action="rejected"
                                                data-tab="staff"
                                                title="Reject Staff Leave">
                                            <i data-lucide="x" style="width: 13px; height: 13px;"></i>
                                        </button>
                                    <?php endif; ?>

                                    <button type="button" class="btn btn-sm btn-light rounded-pill px-2 py-1 border btn-view-leave-detail" 
                                            data-id="<?= (int)$l['id'] ?>"
                                            data-name="<?= e($l['employee_name']) ?>"
                                            data-type="<?= e($l['leave_type'] ?? 'Leave') ?>"
                                            data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                            data-days="<?= (float)$l['days'] ?>"
                                            data-reason="<?= e($l['reason'] ?? '') ?>"
                                            data-status="<?= e(ucfirst($l['status'])) ?>"
                                            data-status-raw="<?= e($l['status']) ?>"
                                            data-attachment="<?= !empty($l['attachment']) ? e(url($l['attachment'])) : '' ?>"
                                            data-reviewer="<?= e($l['reviewer_name'] ?? '') ?>"
                                            data-notes="<?= e($l['review_notes'] ?? '') ?>"
                                            data-submitted="<?= e(date('d M Y, h:i A', strtotime($l['created_at']))) ?>"
                                            title="View Details">
                                        <i data-lucide="eye" style="width: 13px; height: 13px;"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <div class="p-4 text-center">
                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                    <i data-lucide="briefcase" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No Staff Leave Applications</h6>
                                <p class="text-muted small mb-0">No staff leave requests found for the selected filters.</p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tab 3: My Leaves Table -->
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                <tr>
                    <th class="px-3 py-3">Leave Type</th>
                    <th class="py-3">Dates &amp; Duration</th>
                    <th class="py-3">Reason</th>
                    <th class="py-3">Attachment</th>
                    <th class="py-3">Status</th>
                    <th class="py-3">Feedback / Remarks</th>
                    <th class="text-end px-3 py-3">Actions</th>
                </tr>
            </thead>
            <tbody style="font-size: 13px;">
                <?php if (!empty($myLeaves)): ?>
                    <?php foreach ($myLeaves as $l): ?>
                        <tr>
                            <td class="px-3 py-3 fw-semibold text-dark">
                                <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                    <?= e($l['leave_type'] ?? 'Leave') ?>
                                </span>
                            </td>
                            <td class="py-3">
                                <div class="fw-semibold text-dark" style="font-size: 12px;">
                                    <?= e(date('d M Y', strtotime($l['start_date']))) ?> &rarr; <?= e(date('d M Y', strtotime($l['end_date']))) ?>
                                </div>
                                <span class="badge rounded-pill px-2 py-0" style="background: #f1f5f9; color: #475569; font-size: 10px;">
                                    <?= (float)$l['days'] ?> <?= ((float)$l['days'] == 1) ? 'Day' : 'Days' ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 200px;">
                                <div class="text-truncate text-secondary" title="<?= e($l['reason'] ?? '') ?>">
                                    <?= !empty($l['reason']) ? e($l['reason']) : '<span class="text-muted fst-italic">None</span>' ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php if (!empty($l['attachment'])): ?>
                                    <a href="<?= e(url($l['attachment'])) ?>" target="_blank" class="btn btn-sm btn-light rounded-pill px-2 py-1 border d-inline-flex align-items-center gap-1" style="font-size: 11px;">
                                        <i data-lucide="paperclip" style="width: 12px; height: 12px; stroke: #2563eb;"></i> View
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3">
                                <?php
                                    $st = strtolower($l['status'] ?? 'pending');
                                    $badgeBg = match($st) {
                                        'approved' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                        'rejected' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                        'cancelled' => 'background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;',
                                        default => 'background: #fef3c7; color: #b45309; border: 1px solid #fde68a;',
                                    };
                                ?>
                                <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                    <?= ucfirst($st) ?>
                                </span>
                            </td>
                            <td class="py-3" style="max-width: 180px;">
                                <?php if (!empty($l['review_notes'])): ?>
                                    <div class="small text-dark text-truncate" title="<?= e($l['review_notes']) ?>">
                                        <i data-lucide="message-square" style="width: 11px; height: 11px; stroke: #4f46e5;" class="me-1"></i>
                                        <?= e($l['review_notes']) ?>
                                    </div>
                                    <?php if (!empty($l['reviewer_name'])): ?>
                                        <div class="text-muted" style="font-size: 10px;">By: <?= e($l['reviewer_name']) ?></div>
                                    <?php endif; ?>
                                <?php elseif ($l['status'] === 'pending'): ?>
                                    <span class="text-muted small fst-italic">Waiting for approval</span>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end px-3 py-3">
                                <div class="d-flex align-items-center justify-content-end gap-1">
                                    <button type="button" class="btn btn-sm btn-light rounded-pill px-2 py-1 border btn-view-leave-detail" 
                                            data-id="<?= (int)$l['id'] ?>"
                                            data-type="<?= e($l['leave_type'] ?? 'Leave') ?>"
                                            data-dates="<?= e(date('d M Y', strtotime($l['start_date']))) ?> to <?= e(date('d M Y', strtotime($l['end_date']))) ?>"
                                            data-days="<?= (float)$l['days'] ?>"
                                            data-reason="<?= e($l['reason'] ?? '') ?>"
                                            data-status="<?= e(ucfirst($l['status'])) ?>"
                                            data-status-raw="<?= e($l['status']) ?>"
                                            data-attachment="<?= !empty($l['attachment']) ? e(url($l['attachment'])) : '' ?>"
                                            data-reviewer="<?= e($l['reviewer_name'] ?? '') ?>"
                                            data-notes="<?= e($l['review_notes'] ?? '') ?>"
                                            data-submitted="<?= e(date('d M Y, h:i A', strtotime($l['created_at']))) ?>"
                                            title="View Details">
                                        <i data-lucide="eye" style="width: 13px; height: 13px;"></i>
                                    </button>

                                    <?php if ($l['status'] === 'pending'): ?>
                                        <form method="post" action="<?= e(url('leave/' . $l['id'] . '/cancel')) ?>" onsubmit="return confirm('Are you sure you want to cancel this leave application?');" class="d-inline m-0">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1" title="Cancel Request" style="font-size: 11px;">
                                                <i data-lucide="x" style="width: 12px; height: 12px;"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <div class="p-4 text-center">
                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                    <i data-lucide="calendar" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No Leave Requests Found</h6>
                                <p class="text-muted small mb-3">You haven't applied for any leave yet.</p>
                                <?php if (!empty($employeeId)): ?>
                                    <button class="btn btn-primary btn-sm rounded-pill px-3 py-2" data-bs-toggle="modal" data-bs-target="#requestStaffLeaveModal">
                                        <i data-lucide="plus" style="width: 14px; height: 14px;" class="me-1"></i> Apply for Leave
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Modal: Apply for Staff Leave -->
<div class="modal fade" id="requestStaffLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 text-white" style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 p-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                        <i data-lucide="calendar-plus" style="width: 16px; height: 16px; stroke: #ffffff;"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold text-white mb-0" style="font-size: 16px;">Submit Staff Leave Application</h5>
                        <div class="text-white text-opacity-75 small" style="font-size: 11px;">Request time-off for school administration review</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <form method="post" action="<?= e(url('leave')) ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="employee_id" value="<?= (int)$employeeId ?>">

                <div class="modal-body px-4 py-4 bg-light">
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Leave Type <span class="text-danger">*</span></label>
                        <select name="leave_type_id" class="form-select rounded-3 shadow-sm border-0" required>
                            <option value="">-- Select Leave Category --</option>
                            <?php foreach ($staffTypes as $t): ?>
                                <option value="<?= (int)$t['id'] ?>"><?= e($t['name']) ?> <?= !empty($t['is_paid']) ? '(Paid)' : '(Unpaid)' ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label text-sm fw-semibold text-dark">Start Date <span class="text-danger">*</span></label>
                            <input type="date" name="start_date" id="staffStartDate" class="form-control rounded-3 shadow-sm border-0" required value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label text-sm fw-semibold text-dark">End Date <span class="text-danger">*</span></label>
                            <input type="date" name="end_date" id="staffEndDate" class="form-control rounded-3 shadow-sm border-0" required value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>

                    <!-- Dynamic Day Duration Badge -->
                    <div class="p-2 px-3 rounded-3 mb-3 d-flex align-items-center justify-content-between" style="background: #eff6ff; border: 1px solid #bfdbfe;">
                        <span class="text-dark small fw-medium" style="font-size: 12px;">
                            <i data-lucide="info" style="width: 14px; height: 14px; stroke: #2563eb;" class="me-1"></i> Total Duration:
                        </span>
                        <span class="badge rounded-pill bg-primary fw-bold px-3 py-1" id="staffCalculatedDays" style="font-size: 12px;">1 Day</span>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Reason / Description <span class="text-danger">*</span></label>
                        <textarea name="reason" rows="3" class="form-control rounded-3 shadow-sm border-0" placeholder="Please provide reason for your leave request..." required></textarea>
                    </div>

                    <div class="mb-2">
                        <label class="form-label text-sm fw-semibold text-dark d-flex justify-content-between align-items-center">
                            <span>Document / Certificate <span class="text-muted fw-normal">(Optional)</span></span>
                            <span class="text-muted small" style="font-size: 11px;">JPG, PNG, PDF (Max 5MB)</span>
                        </label>
                        <input type="file" name="attachment" class="form-control rounded-3 shadow-sm border-0" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                    </div>
                </div>

                <div class="modal-footer px-4 py-3 bg-white border-top-0 d-flex justify-content-between">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm">
                        <i data-lucide="send" style="width: 14px; height: 14px;"></i>
                        <span>Submit Application</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Review / Approval Form -->
<div class="modal fade" id="reviewLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 text-white" id="reviewModalHeader" style="background: #16a34a;">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 p-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                        <i data-lucide="check-square" style="width: 16px; height: 16px; stroke: #ffffff;" id="reviewModalIcon"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold text-white mb-0" style="font-size: 16px;" id="reviewModalTitle">Review Leave Application</h5>
                        <div class="text-white text-opacity-75 small" style="font-size: 11px;" id="reviewModalSubtitle">Take action on leave request</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form method="post" id="reviewLeaveForm">
                <?= csrf_field() ?>
                <input type="hidden" name="status" id="reviewInputStatus" value="approved">
                <input type="hidden" name="redirect_tab" id="reviewInputTab" value="students">

                <div class="modal-body px-4 py-4 bg-light">
                    <!-- Applicant Summary Box -->
                    <div class="p-3 rounded-3 bg-white border mb-3 shadow-sm" style="border-color: #e2e8f0 !important;">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold text-dark" id="reviewApplicantName">-</span>
                            <span class="badge rounded-pill bg-primary px-2 py-1" id="reviewDurationBadge">-</span>
                        </div>
                        <div class="text-muted small" id="reviewApplicantMeta">-</div>
                        <div class="text-secondary small mt-2 p-2 rounded-2 bg-light fst-italic" id="reviewApplicantReason">Reason: -</div>
                    </div>

                    <!-- Status Radio Options -->
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold text-dark">Action Decision <span class="text-danger">*</span></label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="decision_radio" id="decisionApprove" value="approved" checked>
                                <label class="form-check-label fw-semibold text-success" for="decisionApprove">
                                    <i data-lucide="check" style="width: 14px; height: 14px;" class="me-1"></i> Approve Leave
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="decision_radio" id="decisionReject" value="rejected">
                                <label class="form-check-label fw-semibold text-danger" for="decisionReject">
                                    <i data-lucide="x" style="width: 14px; height: 14px;" class="me-1"></i> Reject Application
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-2">
                        <label class="form-label text-sm fw-semibold text-dark">Reviewer Remarks / Feedback</label>
                        <textarea name="review_notes" id="reviewNotesInput" rows="3" class="form-control rounded-3 shadow-sm border-0" placeholder="Optional notes for applicant (e.g. Approved by Class Teacher, or reason if rejected)..."></textarea>
                    </div>
                </div>

                <div class="modal-footer px-4 py-3 bg-white border-top-0 d-flex justify-content-between">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-semibold" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm" id="reviewSubmitBtn">
                        <i data-lucide="check-circle" style="width: 15px; height: 15px;"></i>
                        <span>Confirm Approval</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: View Leave Details -->
<div class="modal fade" id="leaveDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 bg-light">
                <h5 class="modal-title fw-bold text-dark mb-0 d-flex align-items-center gap-2" style="font-size: 16px;">
                    <i data-lucide="file-text" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    <span>Leave Request Details</span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 py-4">
                <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                    <div>
                        <div class="text-muted small" style="font-size: 11px;">APPLICANT / TYPE</div>
                        <h6 class="fw-bold text-dark mb-0" id="detailApplicant">-</h6>
                    </div>
                    <div>
                        <div class="text-muted small text-end" style="font-size: 11px;">STATUS</div>
                        <div id="detailStatusBadge">-</div>
                    </div>
                </div>

                <div class="row g-3 mb-3 pb-3 border-bottom">
                    <div class="col-6">
                        <div class="text-muted small" style="font-size: 11px;">DATES</div>
                        <div class="fw-semibold text-dark small" id="detailDates">-</div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small" style="font-size: 11px;">DURATION</div>
                        <div class="fw-semibold text-dark small" id="detailDays">-</div>
                    </div>
                    <div class="col-12">
                        <div class="text-muted small" style="font-size: 11px;">SUBMITTED ON</div>
                        <div class="fw-semibold text-dark small" id="detailSubmitted">-</div>
                    </div>
                </div>

                <div class="mb-3 pb-3 border-bottom">
                    <div class="text-muted small mb-1" style="font-size: 11px;">REASON</div>
                    <p class="text-dark small mb-0 p-2 rounded-3 bg-light" id="detailReason">-</p>
                </div>

                <div class="mb-3 pb-3 border-bottom" id="detailAttachmentContainer" style="display: none;">
                    <div class="text-muted small mb-1" style="font-size: 11px;">ATTACHMENT</div>
                    <a href="#" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 d-inline-flex align-items-center gap-2" id="detailAttachmentLink">
                        <i data-lucide="paperclip" style="width: 14px; height: 14px;"></i>
                        <span>Download Document</span>
                    </a>
                </div>

                <div id="detailReviewContainer" style="display: none;">
                    <div class="text-muted small mb-1" style="font-size: 11px;">REVIEWER FEEDBACK &amp; NOTES</div>
                    <div class="p-3 rounded-3" style="background: #f8fafc; border: 1px solid #e2e8f0;">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i data-lucide="user-check" style="width: 14px; height: 14px; stroke: #16a34a;"></i>
                            <span class="fw-semibold text-dark small" id="detailReviewer">Reviewer</span>
                        </div>
                        <p class="text-secondary small mb-0" id="detailNotes">No additional remarks.</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer px-4 py-3 bg-light border-top-0">
                <button type="button" class="btn btn-secondary rounded-pill px-4 fw-semibold w-100" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Dynamic duration calculator for Staff application
    const staffStart = document.getElementById('staffStartDate');
    const staffEnd = document.getElementById('staffEndDate');
    const staffBadge = document.getElementById('staffCalculatedDays');

    function updateStaffDays() {
        if (!staffStart || !staffEnd || !staffBadge) return;
        const sVal = staffStart.value;
        const eVal = staffEnd.value;
        if (!sVal || !eVal) return;

        const sDate = new Date(sVal);
        const eDate = new Date(eVal);

        if (eDate < sDate) {
            staffBadge.textContent = 'Invalid (End before Start)';
            staffBadge.className = 'badge rounded-pill bg-danger fw-bold px-3 py-1';
            return;
        }

        const diffTime = Math.abs(eDate - sDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        staffBadge.textContent = diffDays + (diffDays === 1 ? ' Day' : ' Days');
        staffBadge.className = 'badge rounded-pill bg-primary fw-bold px-3 py-1';
    }

    if (staffStart && staffEnd) {
        staffStart.addEventListener('change', updateStaffDays);
        staffEnd.addEventListener('change', updateStaffDays);
        updateStaffDays();
    }

    // Review Modal Setup
    const reviewForm = document.getElementById('reviewLeaveForm');
    const reviewStatusInput = document.getElementById('reviewInputStatus');
    const reviewHeader = document.getElementById('reviewModalHeader');
    const reviewTitle = document.getElementById('reviewModalTitle');
    const reviewSubmitBtn = document.getElementById('reviewSubmitBtn');
    const radioApprove = document.getElementById('decisionApprove');
    const radioReject = document.getElementById('decisionReject');

    function syncDecisionUI(action) {
        reviewStatusInput.value = action;
        if (action === 'approved') {
            reviewHeader.style.background = '#16a34a';
            reviewTitle.textContent = 'Approve Leave Application';
            reviewSubmitBtn.className = 'btn btn-success rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm';
            reviewSubmitBtn.innerHTML = '<i data-lucide="check-circle" style="width: 15px; height: 15px;"></i><span>Confirm Approval</span>';
            radioApprove.checked = true;
        } else {
            reviewHeader.style.background = '#dc2626';
            reviewTitle.textContent = 'Reject Leave Application';
            reviewSubmitBtn.className = 'btn btn-danger rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm';
            reviewSubmitBtn.innerHTML = '<i data-lucide="x-circle" style="width: 15px; height: 15px;"></i><span>Confirm Rejection</span>';
            radioReject.checked = true;
        }
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    if (radioApprove && radioReject) {
        radioApprove.addEventListener('change', function() { if (this.checked) syncDecisionUI('approved'); });
        radioReject.addEventListener('change', function() { if (this.checked) syncDecisionUI('rejected'); });
    }

    document.querySelectorAll('.btn-review-leave').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const action = this.dataset.action || 'approved';
            const name = this.dataset.name || 'Applicant';
            const meta = this.dataset.meta || '';
            const dates = this.dataset.dates || '';
            const days = this.dataset.days || '1';
            const reason = this.dataset.reason || 'None provided';
            const tab = this.dataset.tab || 'students';

            reviewForm.action = '<?= e(url('leave/')) ?>' + id + '/review';
            document.getElementById('reviewInputTab').value = tab;
            document.getElementById('reviewApplicantName').textContent = name;
            document.getElementById('reviewApplicantMeta').textContent = meta + ' • ' + dates;
            document.getElementById('reviewDurationBadge').textContent = days + ' Days';
            document.getElementById('reviewApplicantReason').textContent = 'Reason: ' + reason;
            document.getElementById('reviewNotesInput').value = (action === 'approved' ? 'Approved' : '');

            syncDecisionUI(action);

            const modal = new bootstrap.Modal(document.getElementById('reviewLeaveModal'));
            modal.show();
        });
    });

    // Details modal trigger
    document.querySelectorAll('.btn-view-leave-detail').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.getElementById('detailApplicant').textContent = (this.dataset.name ? this.dataset.name + ' - ' : '') + (this.dataset.type || 'Leave');
            document.getElementById('detailDates').textContent = this.dataset.dates || '-';
            document.getElementById('detailDays').textContent = (this.dataset.days || '1') + ' Days';
            document.getElementById('detailReason').textContent = this.dataset.reason || 'None provided.';
            document.getElementById('detailSubmitted').textContent = this.dataset.submitted || '-';

            const rawSt = (this.dataset.statusRaw || 'pending').toLowerCase();
            let badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#fef3c7; color:#b45309;">Pending</span>';
            if (rawSt === 'approved') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#dcfce7; color:#15803d;">Approved</span>';
            } else if (rawSt === 'rejected') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#fee2e2; color:#b91c1c;">Rejected</span>';
            } else if (rawSt === 'cancelled') {
                badgeHtml = '<span class="badge rounded-pill px-2 py-1" style="background:#f1f5f9; color:#64748b;">Cancelled</span>';
            }
            document.getElementById('detailStatusBadge').innerHTML = badgeHtml;

            // Attachment
            const attachLink = this.dataset.attachment;
            const attachContainer = document.getElementById('detailAttachmentContainer');
            if (attachLink) {
                document.getElementById('detailAttachmentLink').href = attachLink;
                attachContainer.style.display = 'block';
            } else {
                attachContainer.style.display = 'none';
            }

            // Review notes
            const reviewContainer = document.getElementById('detailReviewContainer');
            if (rawSt === 'approved' || rawSt === 'rejected') {
                document.getElementById('detailReviewer').textContent = this.dataset.reviewer ? 'Reviewed by: ' + this.dataset.reviewer : 'Reviewed by Staff/Admin';
                document.getElementById('detailNotes').textContent = this.dataset.notes || 'No remarks provided.';
                reviewContainer.style.display = 'block';
            } else {
                reviewContainer.style.display = 'none';
            }

            const modal = new bootstrap.Modal(document.getElementById('leaveDetailModal'));
            modal.show();
        });
    });
});
</script>
