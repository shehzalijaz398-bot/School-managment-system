<?php
$layout = 'layouts/app';
$activeTab = $tab ?? 'items';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Inventory & Asset Management') ?>
        </h1>
        <p class="text-muted small mb-0">
            Track physical equipment, stationery, sports assets, suppliers, and stock transactions
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('inventory/export-csv')) ?>" 
           class="btn btn-outline-secondary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
           style="font-size: 13px; font-weight: 500;">
            <i data-lucide="download" style="width: 15px; height: 15px;"></i>
            <span>Export CSV</span>
        </a>
        <button class="btn btn-outline-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
                data-bs-toggle="modal" data-bs-target="#newTransactionModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="arrow-left-right" style="width: 15px; height: 15px;"></i>
            <span>Record Stock In/Out</span>
        </button>
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                data-bs-toggle="modal" data-bs-target="#newItemModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
            <span>Add Item</span>
        </button>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="box" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Active SKUs</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_items'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Registered Items</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="dollar-sign" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 10px;">Valuation</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0">Rs. <?= number_format((float)($stats['valuation'] ?? 0), 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Stock Asset Value</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="alert-triangle" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <?php if (($stats['low_stock'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark px-2 py-1" style="font-size: 10px; font-weight: 600;">Reorder Needed</span>
                    <?php endif; ?>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['low_stock'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Low Stock Alerts</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fdf2f8; width: 34px; height: 34px;">
                        <i data-lucide="refresh-cw" style="width: 16px; height: 16px; stroke: #db2777;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">This Month</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['tx_count'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Stock In/Out Logs</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs Navigation -->
<ul class="nav nav-pills gap-2 mb-4 p-1 bg-white rounded-3 shadow-sm border" style="width: fit-content;">
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'items' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('inventory?tab=items')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="package" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Items Registry (<?= count($items) ?>)
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'transactions' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('inventory?tab=transactions')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="arrow-left-right" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Stock Log &amp; Movements
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'suppliers' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('inventory?tab=suppliers')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="truck" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Suppliers &amp; Vendors (<?= count($suppliers) ?>)
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'categories' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('inventory?tab=categories')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="tags" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Item Categories (<?= count($categories) ?>)
        </a>
    </li>
</ul>

<!-- Tab 1: Items Registry -->
<?php if ($activeTab === 'items'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <!-- Filter bar -->
        <form method="GET" action="<?= e(url('inventory')) ?>" class="row g-2 align-items-center mb-3">
            <input type="hidden" name="tab" value="items">
            <div class="col-md-4">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
                    <input type="text" name="q" class="form-control border-start-0" placeholder="Search by name, code or room..." value="<?= e($filters['q'] ?? '') ?>">
                </div>
            </div>
            <div class="col-md-3">
                <select name="category_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= (int)$cat['id'] ?>" <?= ((int)($filters['category_id'] ?? 0) === (int)$cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Statuses</option>
                    <option value="active" <?= ($filters['status'] ?? '') === 'active' ? 'selected' : '' ?>>Active Only</option>
                    <option value="discontinued" <?= ($filters['status'] ?? '') === 'discontinued' ? 'selected' : '' ?>>Discontinued</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary w-100">Filter</button>
                <?php if (!empty($filters['q']) || !empty($filters['category_id']) || !empty($filters['status'])): ?>
                    <a href="<?= e(url('inventory?tab=items')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Code / Item</th>
                        <th>Category</th>
                        <th>Unit Price</th>
                        <th>Stock Balance</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">
                                <i data-lucide="inbox" style="width: 28px; height: 28px; opacity: 0.5;"></i>
                                <div class="mt-2">No inventory items found. Click "Add Item" to register your first asset.</div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($items as $it): 
                            $isLow = ((int)$it['quantity'] <= (int)$it['min_threshold']);
                        ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark"><?= e($it['name']) ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><span class="badge bg-light text-dark font-monospace"><?= e($it['item_code']) ?></span></div>
                                </td>
                                <td>
                                    <span class="badge rounded-pill bg-light text-secondary border px-2 py-1">
                                        <?= e($it['category_name'] ?? 'Uncategorized') ?>
                                    </span>
                                </td>
                                <td class="fw-medium">Rs. <?= number_format((float)$it['unit_price'], 2) ?></td>
                                <td>
                                    <span class="badge rounded-pill <?= $isLow ? 'bg-danger text-white' : 'bg-success-subtle text-success' ?> px-2 py-1" style="font-size: 12px;">
                                        <?= (int)$it['quantity'] ?> <?= e($it['unit']) ?>
                                    </span>
                                    <?php if ($isLow): ?>
                                        <div class="text-danger" style="font-size: 10px; font-weight: 600;">Low stock! (Min: <?= (int)$it['min_threshold'] ?>)</div>
                                    <?php endif; ?>
                                </td>
                                <td><?= e($it['location'] ?: '—') ?></td>
                                <td>
                                    <?php if ($it['status'] === 'active'): ?>
                                        <span class="badge bg-success-subtle text-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Discontinued</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-3">
                                    <button class="btn btn-sm btn-outline-secondary py-1 px-2" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editItemModal<?= (int)$it['id'] ?>" title="Edit">
                                        <i data-lucide="edit-3" style="width: 14px; height: 14px;"></i>
                                    </button>
                                    <form method="POST" action="<?= e(url('inventory/items/' . $it['id'] . '/delete')) ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this item?');">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger py-1 px-2" title="Delete">
                                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit Item Modal -->
                            <div class="modal fade" id="editItemModal<?= (int)$it['id'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4 border-0 shadow">
                                        <form method="POST" action="<?= e(url('inventory/items/' . $it['id'])) ?>">
                                            <?= csrf_field() ?>
                                            <div class="modal-header border-0 pb-0">
                                                <h5 class="modal-title fw-bold">Edit Item: <?= e($it['name']) ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold">Item Name *</label>
                                                    <input type="text" name="name" class="form-control" value="<?= e($it['name']) ?>" required>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label small fw-bold">Item Code</label>
                                                        <input type="text" name="item_code" class="form-control" value="<?= e($it['item_code']) ?>">
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="form-label small fw-bold">Category</label>
                                                        <select name="category_id" class="form-select">
                                                            <option value="">None</option>
                                                            <?php foreach ($categories as $cat): ?>
                                                                <option value="<?= (int)$cat['id'] ?>" <?= ((int)$it['category_id'] === (int)$cat['id']) ? 'selected' : '' ?>>
                                                                    <?= e($cat['name']) ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-4">
                                                        <label class="form-label small fw-bold">Unit</label>
                                                        <input type="text" name="unit" class="form-control" value="<?= e($it['unit']) ?>" required>
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label small fw-bold">Unit Price</label>
                                                        <input type="number" step="0.01" name="unit_price" class="form-control" value="<?= (float)$it['unit_price'] ?>">
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label small fw-bold">Min Threshold</label>
                                                        <input type="number" name="min_threshold" class="form-control" value="<?= (int)$it['min_threshold'] ?>">
                                                    </div>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-8">
                                                        <label class="form-label small fw-bold">Storage Location / Room</label>
                                                        <input type="text" name="location" class="form-control" value="<?= e($it['location'] ?? '') ?>">
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label small fw-bold">Status</label>
                                                        <select name="status" class="form-select">
                                                            <option value="active" <?= $it['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                                                            <option value="discontinued" <?= $it['status'] === 'discontinued' ? 'selected' : '' ?>>Discontinued</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0 pt-0">
                                                <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-primary rounded-pill px-4">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tab 2: Transactions -->
<?php if ($activeTab === 'transactions'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">Recent Stock Movements (In &amp; Out)</h6>
            <button class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#newTransactionModal">
                <i data-lucide="plus" style="width: 14px; height: 14px; margin-right: 4px;"></i> New Movement
            </button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Date / Ref</th>
                        <th>Item</th>
                        <th>Type</th>
                        <th>Quantity</th>
                        <th>Supplier / Destination</th>
                        <th>Logged By</th>
                        <th class="pe-3">Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">No stock transactions logged yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($transactions as $t): ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-medium text-dark"><?= date('M d, Y H:i', strtotime($t['created_at'])) ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><?= e($t['reference_no'] ?: '—') ?></div>
                                </td>
                                <td>
                                    <span class="fw-bold text-dark"><?= e($t['item_name']) ?></span>
                                    <div class="text-muted font-monospace" style="font-size: 11px;"><?= e($t['item_code']) ?></div>
                                </td>
                                <td>
                                    <?php if ($t['type'] === 'in'): ?>
                                        <span class="badge bg-success-subtle text-success"><i data-lucide="arrow-down-left" style="width: 12px; height: 12px;"></i> STOCK IN</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger"><i data-lucide="arrow-up-right" style="width: 12px; height: 12px;"></i> STOCK OUT</span>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold">
                                    <?= ($t['type'] === 'in' ? '+' : '-') . (int)$t['quantity'] ?> <?= e($t['unit']) ?>
                                </td>
                                <td>
                                    <?= e($t['supplier_name'] ?? ($t['issued_to_type'] ? ucfirst($t['issued_to_type']) : 'General')) ?>
                                </td>
                                <td><?= e($t['user_name'] ?? 'System') ?></td>
                                <td class="pe-3 text-muted small"><?= e($t['notes'] ?: '—') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tab 3: Suppliers -->
<?php if ($activeTab === 'suppliers'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">Registered Vendors &amp; Suppliers</h6>
            <button class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#newSupplierModal">
                <i data-lucide="plus" style="width: 14px; height: 14px; margin-right: 4px;"></i> Add Supplier
            </button>
        </div>
        <div class="row g-3">
            <?php if (empty($suppliers)): ?>
                <div class="col-12 text-center py-4 text-muted">No suppliers registered. Click "Add Supplier" to add one.</div>
            <?php else: ?>
                <?php foreach ($suppliers as $s): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 border rounded-3 p-3 shadow-sm bg-white">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <div class="fw-bold text-dark h6 mb-0"><?= e($s['name']) ?></div>
                                <span class="badge bg-light text-secondary border"><?= (int)$s['transaction_count'] ?> orders</span>
                            </div>
                            <div class="small text-muted mb-2">
                                <i data-lucide="user" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($s['contact_person'] ?: 'N/A') ?>
                            </div>
                            <div class="small text-muted mb-2">
                                <i data-lucide="phone" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($s['phone'] ?: 'N/A') ?>
                            </div>
                            <div class="small text-muted mb-2">
                                <i data-lucide="mail" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($s['email'] ?: 'N/A') ?>
                            </div>
                            <?php if (!empty($s['address'])): ?>
                                <div class="small text-muted border-top pt-2 mt-auto">
                                    <i data-lucide="map-pin" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($s['address']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tab 4: Categories -->
<?php if ($activeTab === 'categories'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">Item Categories</h6>
            <button class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#newCategoryModal">
                <i data-lucide="plus" style="width: 14px; height: 14px; margin-right: 4px;"></i> Add Category
            </button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Category Name</th>
                        <th>Description</th>
                        <th>Associated Items</th>
                        <th class="pe-3">Created</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                        <tr><td colspan="4" class="text-center py-4 text-muted">No categories created.</td></tr>
                    <?php else: ?>
                        <?php foreach ($categories as $cat): ?>
                            <tr>
                                <td class="ps-3 fw-bold text-dark"><?= e($cat['name']) ?></td>
                                <td class="text-muted"><?= e($cat['description'] ?: '—') ?></td>
                                <td>
                                    <span class="badge bg-primary-subtle text-primary"><?= (int)$cat['item_count'] ?> Items</span>
                                </td>
                                <td class="pe-3 text-muted"><?= date('M d, Y', strtotime($cat['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modal: New Item -->
<div class="modal fade" id="newItemModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('inventory/items')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Register New Inventory Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Item Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Physics Optical Prism Set" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Item Code (Leave blank for auto)</label>
                            <input type="text" name="item_code" class="form-control" placeholder="ITM-XXX">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Category</label>
                            <select name="category_id" class="form-select">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-bold">Unit *</label>
                            <input type="text" name="unit" class="form-control" placeholder="pcs, boxes, sets" value="pcs" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Initial Stock</label>
                            <input type="number" name="quantity" class="form-control" value="0" min="0">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Unit Price (Rs.)</label>
                            <input type="number" step="0.01" name="unit_price" class="form-control" value="0.00" min="0">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Min Threshold (Alert Level)</label>
                            <input type="number" name="min_threshold" class="form-control" value="5" min="1">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Storage Location / Shelf</label>
                            <input type="text" name="location" class="form-control" placeholder="e.g. Lab A Cupboard 2">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Create Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Movement (Stock In / Out) -->
<div class="modal fade" id="newTransactionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('inventory/transactions')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Record Stock Movement (In / Out)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Select Item *</label>
                        <select name="item_id" class="form-select" required>
                            <option value="">-- Choose Inventory Item --</option>
                            <?php foreach ($items as $it): ?>
                                <option value="<?= (int)$it['id'] ?>">
                                    <?= e($it['name']) ?> (Current: <?= (int)$it['quantity'] ?> <?= e($it['unit']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Movement Type *</label>
                            <select name="type" class="form-select" required>
                                <option value="in">STOCK IN (Purchase / Restock)</option>
                                <option value="out">STOCK OUT (Issue / Consume / Damaged)</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Quantity *</label>
                            <input type="number" name="quantity" class="form-control" min="1" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Supplier (If Stock In)</label>
                            <select name="supplier_id" class="form-select">
                                <option value="">None / Existing</option>
                                <?php foreach ($suppliers as $s): ?>
                                    <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Issued To (If Stock Out)</label>
                            <select name="issued_to_type" class="form-select">
                                <option value="general">General / Classroom</option>
                                <option value="department">Science / IT Lab</option>
                                <option value="staff">Staff Member</option>
                                <option value="student">Student</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Reference / Invoice #</label>
                            <input type="text" name="reference_no" class="form-control" placeholder="e.g. PO-9812">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Unit Price Override (Optional)</label>
                            <input type="number" step="0.01" name="unit_price" class="form-control" placeholder="Leave empty for item default">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Notes / Reason</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="e.g. Annual science fair distribution"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Post Transaction</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Supplier -->
<div class="modal fade" id="newSupplierModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('inventory/suppliers')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Register Vendor / Supplier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Company / Vendor Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Oxford Press Dist." required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Contact Person</label>
                            <input type="text" name="contact_person" class="form-control" placeholder="Representative name">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="+92 300 0000000">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="vendor@example.com">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Business Address</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="Shop/Office location"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Save Supplier</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Category -->
<div class="modal fade" id="newCategoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('inventory/categories')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Create Item Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Category Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Musical Instruments" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Description</label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Brief category notes"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Create Category</button>
                </div>
            </form>
        </div>
    </div>
</div>
