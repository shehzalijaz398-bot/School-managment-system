<?php
$layout = 'layouts/app';
?>

<!-- Back link & Header -->
<div class="mb-4">
    <a href="<?= e(url('assignments?tab=assignments')) ?>" class="text-secondary text-decoration-none small d-inline-flex align-items-center gap-1 mb-2">
        <i data-lucide="arrow-left" style="width: 14px; height: 14px;"></i>
        <span>Back to Assignments &amp; Home Tasks</span>
    </a>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;"><?= e($assignment['title']) ?></h1>
            <div class="d-flex align-items-center gap-2 text-muted small flex-wrap">
                <span class="badge rounded-pill bg-primary px-3 py-1"><?= e($assignment['subject_name']) ?></span>
                <span>•</span>
                <span>Class: <strong><?= e($assignment['class_name']) ?><?= !empty($assignment['section_name']) ? ' (' . e($assignment['section_name']) . ')' : '' ?></strong></span>
                <span>•</span>
                <span>Assigned: <?= e(date('d M Y', strtotime($assignment['assigned_date']))) ?></span>
                <span>•</span>
                <span>Deadline: <strong><?= e(date('d M Y', strtotime($assignment['due_date']))) ?></strong></span>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2 border border-success-subtle" style="font-size: 13px;">
                <i data-lucide="award" style="width: 14px; height: 14px;" class="me-1"></i>
                Max Marks: <?= (float)$assignment['max_marks'] ?>
            </span>
        </div>
    </div>
</div>

<!-- 4 Submissions Progress Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eff6ff; width: 34px; height: 34px;">
                        <i data-lucide="users" style="width: 16px; height: 16px; stroke: #2563eb;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Class Strength</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="check-circle" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['submitted'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Submitted Work</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fdf2f8; width: 34px; height: 34px;">
                        <i data-lucide="award" style="width: 16px; height: 16px; stroke: #db2777;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['graded'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Graded &amp; Evaluated</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['pending'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Awaiting Submission</div>
            </div>
        </div>
    </div>
</div>

<!-- Assignment Instructions Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-4">
        <h6 class="fw-bold text-dark mb-2 d-flex align-items-center gap-2">
            <i data-lucide="info" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
            <span>Assignment Instructions &amp; Description</span>
        </h6>
        <div class="p-3 rounded-3 mb-3" style="background: #f8fafc; border: 1px solid #f1f5f9; color: #334155; line-height: 1.6; font-size: 13px;">
            <?= !empty($assignment['description']) ? nl2br(e($assignment['description'])) : '<span class="text-muted fst-italic">No additional instructions provided.</span>' ?>
        </div>

        <?php if (!empty($assignment['attachment'])): ?>
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small fw-semibold">Worksheet / Teacher Attachment:</span>
                <a href="<?= e(url($assignment['attachment'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1 d-inline-flex align-items-center gap-2" style="font-size: 12px;">
                    <i data-lucide="paperclip" style="width: 13px; height: 13px;"></i>
                    <span>Download Worksheet File</span>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Student Submissions & Grading Console -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
        <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
            <i data-lucide="clipboard-check" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
            <span>Student Submissions &amp; Evaluation Cockpit</span>
        </h6>
        <span class="text-muted small"><?= count($submissions) ?> students in class</span>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                <tr>
                    <th class="px-3 py-3">Roll &amp; Student</th>
                    <th class="py-3">Status</th>
                    <th class="py-3">Submitted At</th>
                    <th class="py-3">Submitted Work</th>
                    <th class="py-3" style="min-width: 280px;">Marks &amp; Feedback Evaluation</th>
                </tr>
            </thead>
            <tbody style="font-size: 13px;">
                <?php if (!empty($submissions)): ?>
                    <?php foreach ($submissions as $sub): ?>
                        <tr>
                            <td class="px-3 py-3">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                        #<?= e($sub['roll_no'] ?? '-') ?>
                                    </span>
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size: 13px;"><?= e(trim($sub['first_name'] . ' ' . $sub['last_name'])) ?></div>
                                        <div class="text-muted" style="font-size: 11px;">Adm: <?= e($sub['admission_no'] ?? 'N/A') ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php
                                    $subSt = strtolower($sub['submission_status'] ?? 'pending');
                                    $badgeBg = match($subSt) {
                                        'graded' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                        'submitted' => 'background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe;',
                                        'late' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                        default => 'background: #fffbeb; color: #b45309; border: 1px solid #fde68a;',
                                    };
                                    $badgeText = match($subSt) {
                                        'graded' => 'Graded',
                                        'submitted' => 'Submitted',
                                        'late' => 'Late Submission',
                                        default => 'Pending',
                                    };
                                ?>
                                <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                    <?= $badgeText ?>
                                </span>
                            </td>
                            <td class="py-3 text-muted small">
                                <?= !empty($sub['submitted_at']) ? e(date('d M Y, h:i A', strtotime($sub['submitted_at']))) : '&mdash;' ?>
                            </td>
                            <td class="py-3">
                                <div class="d-flex align-items-center gap-2">
                                    <?php if (!empty($sub['student_attachment'])): ?>
                                        <a href="<?= e(url($sub['student_attachment'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-2 py-1 d-inline-flex align-items-center gap-1" style="font-size: 11px;" title="Download Homework Document">
                                            <i data-lucide="paperclip" style="width: 12px; height: 12px;"></i> Document
                                        </a>
                                    <?php endif; ?>

                                    <?php if (!empty($sub['student_content'])): ?>
                                        <button type="button" class="btn btn-sm btn-light border rounded-pill px-2 py-1 btn-view-content" 
                                                data-student="<?= e(trim($sub['first_name'] . ' ' . $sub['last_name'])) ?>"
                                                data-content="<?= e($sub['student_content']) ?>"
                                                style="font-size: 11px;" title="Read student answer notes">
                                            <i data-lucide="file-text" style="width: 12px; height: 12px;"></i> Read Text
                                        </button>
                                    <?php endif; ?>

                                    <?php if (empty($sub['student_attachment']) && empty($sub['student_content'])): ?>
                                        <span class="text-muted small">&mdash;</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?php if (!empty($sub['submission_id'])): ?>
                                    <form method="post" action="<?= e(url('assignments/submissions/' . $sub['submission_id'] . '/grade')) ?>" class="d-flex align-items-center gap-2 m-0">
                                        <?= csrf_field() ?>
                                        <div class="input-group input-group-sm" style="width: 120px;">
                                            <input type="number" step="0.5" min="0" max="<?= (float)$assignment['max_marks'] ?>" 
                                                   name="marks" class="form-control form-control-sm text-center fw-bold shadow-none" 
                                                   value="<?= e((string)($sub['marks'] ?? '')) ?>" placeholder="Marks" required>
                                            <span class="input-group-text bg-light text-muted px-2" style="font-size: 11px;">/ <?= (float)$assignment['max_marks'] ?></span>
                                        </div>

                                        <input type="text" name="teacher_comment" class="form-control form-control-sm shadow-none" 
                                               placeholder="Remarks / Feedback..." value="<?= e($sub['teacher_comment'] ?? '') ?>" style="font-size: 12px; width: 140px;">

                                        <button type="submit" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm d-flex align-items-center gap-1" style="font-size: 12px;">
                                            <i data-lucide="check" style="width: 13px; height: 13px;"></i>
                                            <span>Save</span>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small fst-italic">Waiting for student to submit</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">
                            No students enrolled in this class and section.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: View Student Answer Text -->
<div class="modal fade" id="contentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 bg-light">
                <h5 class="modal-title fw-bold text-dark mb-0 d-flex align-items-center gap-2" style="font-size: 16px;">
                    <i data-lucide="file-text" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    <span id="contentStudentTitle">Student Written Work</span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 py-4">
                <p class="text-dark small p-3 rounded-3 bg-light mb-0" id="contentBody" style="line-height: 1.6; white-space: pre-wrap; font-size: 13px;">-</p>
            </div>
            <div class="modal-footer px-4 py-3 bg-light border-top-0">
                <button type="button" class="btn btn-secondary rounded-pill px-4 fw-semibold w-100" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    document.querySelectorAll('.btn-view-content').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.getElementById('contentStudentTitle').textContent = (this.dataset.student || 'Student') + ' - Answers & Notes';
            document.getElementById('contentBody').textContent = this.dataset.content || 'No text provided.';
            const modal = new bootstrap.Modal(document.getElementById('contentModal'));
            modal.show();
        });
    });
});
</script>