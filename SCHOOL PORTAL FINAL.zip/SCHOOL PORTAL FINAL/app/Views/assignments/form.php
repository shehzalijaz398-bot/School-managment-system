<?php
$layout = 'layouts/app';
$currentMode = $mode ?? ($_GET['mode'] ?? 'diary');
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-dark d-flex align-items-center gap-2">
            <i data-lucide="<?= ($currentMode === 'assignment') ? 'file-plus' : 'calendar-plus' ?>" style="stroke: #4f46e5; width: 24px; height: 24px;"></i>
            <span><?= ($currentMode === 'assignment') ? 'Create Graded Assignment / Project' : 'Post Daily School Diary (Home Tasks)' ?></span>
        </h2>
        <p class="text-muted small mb-0">
            <?= ($currentMode === 'assignment') ? 'Assign homework or coursework with deadlines, max marks, and worksheet file attachments.' : 'Record and broadcast daily homework for all subjects in one class.' ?>
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <!-- Mode Switcher Buttons -->
        <a href="<?= e(url('assignments/create?mode=diary')) ?>" class="btn btn-sm rounded-pill px-3 py-2 <?= ($currentMode === 'diary') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size: 12px; font-weight: 500;">
            <i data-lucide="calendar" style="width: 13px; height: 13px;" class="me-1"></i> Daily Diary Mode
        </a>
        <a href="<?= e(url('assignments/create?mode=assignment')) ?>" class="btn btn-sm rounded-pill px-3 py-2 <?= ($currentMode === 'assignment') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size: 12px; font-weight: 500;">
            <i data-lucide="file-text" style="width: 13px; height: 13px;" class="me-1"></i> Graded Assignment Mode
        </a>
        <a href="<?= e(url('assignments')) ?>" class="btn btn-sm btn-light border rounded-pill px-3 py-2 text-secondary" style="font-size: 12px;">
            <i data-lucide="arrow-left" style="width: 13px; height: 13px;" class="me-1"></i> Back
        </a>
    </div>
</div>

<?php if ($currentMode === 'assignment'): ?>
<!-- MODE 1: GRADED ASSIGNMENT / PROJECT FORM -->
<form method="post" action="<?= e(url('assignments')) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="mode" value="assignment">

    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3" style="border-color: #f1f5f9 !important;">
            <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
                <i data-lucide="clipboard-list" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                <span>Assignment Information</span>
            </h6>
        </div>
        <div class="card-body p-4">
            <div class="row g-3 mb-3">
                <div class="col-12 col-md-8">
                    <label class="form-label text-sm fw-semibold text-dark">Assignment Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control rounded-3 shadow-sm border-0 bg-light" placeholder="e.g. Chapter 4 Math Exercises, Science Lab Report..." required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Maximum Marks <span class="text-danger">*</span></label>
                    <input type="number" step="1" min="1" name="max_marks" class="form-control rounded-3 shadow-sm border-0 bg-light" value="100" required>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Class <span class="text-danger">*</span></label>
                    <select name="class_id" id="assignClassSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= (int)$c['id'] ?>" data-sections='<?= e(json_encode($c['sections'])) ?>'><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Section <span class="text-danger">*</span></label>
                    <select name="section_id" id="assignSectionSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="">-- Select Section --</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Subject <span class="text-danger">*</span></label>
                    <select name="subject_id" id="assignSubjectSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="">-- Select Subject --</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Assigned Date <span class="text-danger">*</span></label>
                    <input type="date" name="assigned_date" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Due Date (Deadline) <span class="text-danger">*</span></label>
                    <input type="date" name="due_date" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= date('Y-m-d', strtotime('+3 days')) ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Publish Status</label>
                    <select name="status" class="form-select rounded-3 shadow-sm border-0 bg-light">
                        <option value="published" selected>Published (Visible to Students)</option>
                        <option value="draft">Draft (Saved only for Teacher)</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label text-sm fw-semibold text-dark">Instructions / Problem Statements</label>
                <textarea name="description" rows="4" class="form-control rounded-3 shadow-sm border-0 bg-light" placeholder="Write detailed homework instructions, questions, reading requirements, or guidelines..."></textarea>
            </div>

            <div class="mb-2">
                <label class="form-label text-sm fw-semibold text-dark d-flex justify-content-between align-items-center">
                    <span>Worksheet / Attachment File <span class="text-muted fw-normal">(Optional)</span></span>
                    <span class="text-muted small" style="font-size: 11px;">PDF, DOCX, PNG, JPG, ZIP (Max 15MB)</span>
                </label>
                <input type="file" name="attachment" class="form-control rounded-3 shadow-sm border-0 bg-light" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.zip,.txt">
            </div>
        </div>

        <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center">
            <a href="<?= e(url('assignments')) ?>" class="btn btn-light rounded-pill px-4 fw-medium">Cancel</a>
            <button type="submit" class="btn btn-primary rounded-pill px-4 fw-medium d-flex align-items-center gap-2 shadow-sm">
                <i data-lucide="send" style="width: 15px; height: 15px;"></i>
                <span>Publish Assignment</span>
            </button>
        </div>
    </div>
</form>

<?php else: ?>
<!-- MODE 2: DAILY DIARY BATCH FORM -->
<form method="post" action="<?= e(url('assignments')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="mode" value="diary">

    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3" style="border-color: #f1f5f9 !important;">
            <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
                <i data-lucide="calendar-days" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                <span>Select Diary Class &amp; Date</span>
            </h6>
        </div>
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Date <span class="text-danger">*</span></label>
                    <input type="date" name="date" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Class <span class="text-danger">*</span></label>
                    <select name="class_id" id="classSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= (int)$c['id'] ?>" data-sections='<?= e(json_encode($c['sections'])) ?>'><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Section <span class="text-danger">*</span></label>
                    <select name="section_id" id="sectionSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="">Select Section</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3" style="border-color: #f1f5f9 !important;">
            <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
                <i data-lucide="book-open" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                <span>Subject Homework Tasks</span>
            </h6>
            <div class="text-muted small" style="font-size: 11px;">Fill in the homework for each subject. Leave blank if no task is assigned for that subject.</div>
        </div>

        <div class="card-body p-4" id="subjectsContainer">
            <div class="text-center py-5 text-muted" id="placeholderMessage">
                <i data-lucide="arrow-up-circle" style="width:40px;height:40px;stroke:#94a3b8;margin-bottom:0.75rem;"></i>
                <h6 class="fw-bold text-dark">Please select a Class above</h6>
                <p class="small text-muted mb-0">The subjects assigned to that class will appear here automatically.</p>
            </div>
        </div>

        <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center">
            <span class="text-muted small"><i data-lucide="info" style="width:13px;height:13px;" class="me-1"></i> Empty subject rows will be skipped.</span>
            <button type="submit" class="btn btn-primary rounded-pill px-4 fw-medium d-flex align-items-center gap-2 shadow-sm" id="btnSubmit" disabled>
                <i data-lucide="send" style="width: 15px; height: 15px;"></i>
                <span>Publish Daily Diary</span>
            </button>
        </div>
    </div>
</form>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Dynamic section handling for Graded Assignment mode
    const assignClass = document.getElementById('assignClassSelect');
    const assignSec = document.getElementById('assignSectionSelect');
    if (assignClass && assignSec) {
        assignClass.addEventListener('change', function() {
            assignSec.innerHTML = '<option value="">-- Select Section --</option>';
            const opt = this.options[this.selectedIndex];
            if (opt && opt.dataset.sections) {
                const secs = JSON.parse(opt.dataset.sections);
                secs.forEach(s => {
                    const o = document.createElement('option');
                    o.value = s.id;
                    o.textContent = s.name;
                    assignSec.appendChild(o);
                });
            }
        });
    }

    // Dynamic subject loading for Diary mode
    const classSelect = document.getElementById('classSelect');
    const sectionSelect = document.getElementById('sectionSelect');
    const subjectsContainer = document.getElementById('subjectsContainer');
    const placeholderMessage = document.getElementById('placeholderMessage');
    const btnSubmit = document.getElementById('btnSubmit');

    if (classSelect) {
        const allSubjects = <?= json_encode($subjects) ?>;
        const classSubjectsMap = <?= json_encode($classSubjectsMap ?? []) ?>;

        classSelect.addEventListener('change', function() {
            const classId = this.value;
            const selectedOption = this.options[this.selectedIndex];

            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            if (classId && selectedOption.dataset.sections) {
                const sections = JSON.parse(selectedOption.dataset.sections);
                sections.forEach(sec => {
                    const opt = document.createElement('option');
                    opt.value = sec.id;
                    opt.textContent = sec.name;
                    sectionSelect.appendChild(opt);
                });
            }

            if (!classId) {
                subjectsContainer.innerHTML = '';
                subjectsContainer.appendChild(placeholderMessage);
                placeholderMessage.style.display = 'block';
                btnSubmit.disabled = true;
                return;
            }

            const assignedSubjectIds = classSubjectsMap[classId] || [];

            if (assignedSubjectIds.length === 0) {
                subjectsContainer.innerHTML = `
                    <div class="text-center py-4 text-muted">
                        <i data-lucide="folder-minus" style="width:36px;height:36px;stroke:#94a3b8;margin-bottom:0.5rem;"></i>
                        <h6 class="fw-bold text-dark">No Subjects Assigned</h6>
                        <p class="small text-muted mb-0">This class does not have subjects assigned yet. Please assign subjects in the Class settings first.</p>
                    </div>
                `;
                if (typeof lucide !== 'undefined') lucide.createIcons();
                btnSubmit.disabled = true;
                return;
            }

            let html = '<div class="row g-3">';
            assignedSubjectIds.forEach(subjectId => {
                const subject = allSubjects.find(s => parseInt(s.id) === parseInt(subjectId));
                if (subject) {
                    html += `
                        <div class="col-12 col-md-6">
                            <div class="p-3 rounded-3 border h-100 bg-white shadow-sm" style="border-color:#e2e8f0 !important;">
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <div class="rounded-circle p-2 d-flex align-items-center justify-content-center" style="background:#e0e7ff; color:#4338ca; width:28px; height:28px;">
                                        <i data-lucide="book" style="width:14px;height:14px;"></i>
                                    </div>
                                    <h6 class="mb-0 fw-bold text-dark" style="font-size:13px;">${subject.name}</h6>
                                </div>
                                <textarea name="tasks[${subject.id}]" class="form-control rounded-3 border-0 bg-light" rows="2" placeholder="Write home task for ${subject.name}..." style="font-size:13px;"></textarea>
                            </div>
                        </div>
                    `;
                }
            });
            html += '</div>';

            subjectsContainer.innerHTML = html;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            btnSubmit.disabled = false;
        });
    }
});
</script>