<?php
$layout = 'layouts/app';

$tab = $_GET['tab'] ?? 'diary';

// Separate into Daily Diary tasks and Graded Assignments
$diaryList = [];
$gradedList = [];

foreach ($assignments as $a) {
    if ((float)$a['max_marks'] > 0) {
        $gradedList[] = $a;
    } else {
        $diaryList[] = $a;
    }
}

// Group diary tasks by date + class + section
$groupedDiaries = [];
foreach ($diaryList as $a) {
    $key = $a['assigned_date'] . '_' . $a['class_id'] . '_' . $a['section_id'];
    if (!isset($groupedDiaries[$key])) {
        $groupedDiaries[$key] = [
            'date' => $a['assigned_date'],
            'class_name' => $a['class_name'],
            'section_name' => $a['section_name'],
            'teacher_name' => $a['teacher_name'] ?? 'Class Teacher',
            'tasks' => []
        ];
    }
    $groupedDiaries[$key]['tasks'][] = $a;
}
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Home Tasks &amp; Daily Diary</h1>
        <p class="text-muted small mb-0">Publish daily class diaries, assign graded projects, and evaluate student submissions</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('assignments/create?mode=diary')) ?>" class="btn btn-outline-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="calendar-plus" style="width: 15px; height: 15px;"></i>
            <span>Post Daily Diary</span>
        </a>
        <a href="<?= e(url('assignments/create?mode=assignment')) ?>" class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
            <span>Create Graded Assignment</span>
        </a>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eff6ff; width: 34px; height: 34px;">
                        <i data-lucide="book-marked" style="width: 16px; height: 16px; stroke: #2563eb;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Published Tasks</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="check-circle-2" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-0" style="font-size: 10px;">Active</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['active'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Currently Active</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <?php if (($stats['due_today'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark px-2 py-0" style="font-size: 10px;">Due Today</span>
                    <?php endif; ?>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['due_today'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Deadline Today</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fdf2f8; width: 34px; height: 34px;">
                        <i data-lucide="inbox" style="width: 16px; height: 16px; stroke: #db2777;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['submissions'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Student Submissions</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs & Filter Section -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-3" style="border-color: #f1f5f9 !important;">
        <ul class="nav nav-pills gap-2" id="taskTabs">
            <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($tab === 'diary') ? 'active' : '' ?>" 
                   href="<?= e(url('assignments?tab=diary')) ?>" style="font-size: 13px; font-weight: 500;">
                    <i data-lucide="calendar-days" style="width: 15px; height: 15px;"></i>
                    <span>Daily School Diary</span>
                    <span class="badge rounded-pill bg-light text-dark border ms-1" style="font-size: 10px;"><?= count($groupedDiaries) ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($tab === 'assignments') ? 'active' : '' ?>" 
                   href="<?= e(url('assignments?tab=assignments')) ?>" style="font-size: 13px; font-weight: 500;">
                    <i data-lucide="file-check" style="width: 15px; height: 15px;"></i>
                    <span>Graded Assignments &amp; Projects</span>
                    <span class="badge rounded-pill bg-light text-dark border ms-1" style="font-size: 10px;"><?= count($gradedList) ?></span>
                </a>
            </li>
        </ul>

        <div class="text-muted small">
            <?= ($tab === 'diary') ? count($groupedDiaries) . ' class diaries found' : count($gradedList) . ' assignments found' ?>
        </div>
    </div>

    <!-- Filter Toolbar -->
    <div class="card-body p-3 bg-light border-bottom" style="border-color: #f1f5f9 !important;">
        <form method="get" action="<?= e(url('assignments')) ?>" class="row g-2 align-items-center">
            <input type="hidden" name="tab" value="<?= e($tab) ?>">

            <div class="col-12 col-md-3">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0 rounded-start-pill text-muted px-3">
                        <i data-lucide="search" style="width: 14px; height: 14px;"></i>
                    </span>
                    <input type="text" name="q" value="<?= e($filters['q'] ?? '') ?>" 
                           class="form-control form-control-sm border-start-0 rounded-end-pill shadow-none" 
                           placeholder="Search title, description...">
                </div>
            </div>

            <div class="col-6 col-md-2">
                <select name="class_id" class="form-select form-select-sm rounded-pill shadow-none">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $cls): ?>
                        <option value="<?= (int)$cls['id'] ?>" <?= ((int)($filters['class_id'] ?? 0) === (int)$cls['id']) ? 'selected' : '' ?>>
                            <?= e($cls['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-6 col-md-2">
                <select name="subject_id" class="form-select form-select-sm rounded-pill shadow-none">
                    <option value="">All Subjects</option>
                    <?php foreach ($subjects as $sub): ?>
                        <option value="<?= (int)$sub['id'] ?>" <?= ((int)($filters['subject_id'] ?? 0) === (int)$sub['id']) ? 'selected' : '' ?>>
                            <?= e($sub['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-6 col-md-2">
                <input type="date" name="date" class="form-control form-control-sm rounded-pill shadow-none" value="<?= e($filters['date'] ?? '') ?>" title="Filter by Assigned Date">
            </div>

            <div class="col-12 col-md-auto ms-auto d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-dark rounded-pill px-3 d-flex align-items-center gap-1 shadow-sm">
                    <i data-lucide="filter" style="width: 13px; height: 13px;"></i> Filter
                </button>
                <a href="<?= e(url('assignments?tab=' . $tab)) ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- VIEW 1: DAILY DIARY VIEW -->
    <?php if ($tab === 'diary'): ?>
        <div class="card-body p-4">
            <?php if (!empty($groupedDiaries)): ?>
                <div class="row g-4">
                    <?php foreach ($groupedDiaries as $diary): ?>
                        <div class="col-12 col-md-6 col-xl-4">
                            <div class="card border h-100 shadow-sm rounded-4 overflow-hidden" style="border-color: #e2e8f0 !important; background: #ffffff;">
                                <div class="p-3 border-bottom d-flex justify-content-between align-items-center" style="background: #f8fafc; border-color: #f1f5f9 !important;">
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size: 14px;">
                                            <?= e($diary['class_name']) ?><?= !empty($diary['section_name']) ? ' &bull; ' . e($diary['section_name']) : '' ?>
                                        </div>
                                        <div class="text-muted small" style="font-size: 11px;">
                                            <i data-lucide="calendar" style="width: 11px; height: 11px;" class="me-1"></i>
                                            <?= e(date('l, d M Y', strtotime($diary['date']))) ?>
                                        </div>
                                    </div>
                                    <span class="badge rounded-pill bg-primary px-3 py-1" style="font-size: 11px;">
                                        <?= count($diary['tasks']) ?> Subjects
                                    </span>
                                </div>

                                <div class="p-3">
                                    <?php foreach ($diary['tasks'] as $t): ?>
                                        <div class="p-2 px-3 rounded-3 mb-2" style="background: #f8fafc; border: 1px solid #f1f5f9;">
                                            <div class="d-flex justify-content-between align-items-center mb-1">
                                                <span class="fw-bold text-primary small" style="font-size: 12px;">
                                                    <i data-lucide="book" style="width: 12px; height: 12px;" class="me-1"></i>
                                                    <?= e($t['subject_name']) ?>
                                                </span>
                                                <form method="post" action="<?= e(url('assignments/' . $t['id'] . '/delete')) ?>" onsubmit="return confirm('Delete this homework entry?');" class="d-inline m-0">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="btn btn-sm btn-link text-danger p-0 border-0" title="Delete Task" style="font-size: 11px;">
                                                        <i data-lucide="trash-2" style="width: 12px; height: 12px;"></i>
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="text-secondary small" style="font-size: 12px; line-height: 1.4; white-space: pre-wrap;">
                                                <?= e($t['description'] ?? '') ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                        <i data-lucide="calendar-x-2" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                    </div>
                    <h6 class="fw-bold text-dark mb-1">No Daily Diaries Found</h6>
                    <p class="text-muted small mb-3">No daily homework diaries match your filter criteria.</p>
                    <a href="<?= e(url('assignments/create?mode=diary')) ?>" class="btn btn-primary btn-sm rounded-pill px-3 py-2">
                        <i data-lucide="plus" style="width: 14px; height: 14px;" class="me-1"></i> Post Today's School Diary
                    </a>
                </div>
            <?php endif; ?>
        </div>

    <!-- VIEW 2: GRADED ASSIGNMENTS TABLE -->
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                    <tr>
                        <th class="px-3 py-3">Assignment &amp; Subject</th>
                        <th class="py-3">Class &amp; Section</th>
                        <th class="py-3">Deadlines</th>
                        <th class="py-3">Max Marks</th>
                        <th class="py-3">Submissions Progress</th>
                        <th class="py-3">Status</th>
                        <th class="text-end px-3 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody style="font-size: 13px;">
                    <?php if (!empty($gradedList)): ?>
                        <?php foreach ($gradedList as $a): ?>
                            <tr>
                                <td class="px-3 py-3">
                                    <div class="fw-bold text-dark" style="font-size: 13px;"><?= e($a['title']) ?></div>
                                    <div class="text-muted d-flex align-items-center gap-1" style="font-size: 11px;">
                                        <span class="badge rounded-pill bg-light text-dark border px-2 py-0"><?= e($a['subject_name']) ?></span>
                                        <span>•</span>
                                        <span>By <?= e($a['teacher_name'] ?? 'Teacher') ?></span>
                                        <?php if (!empty($a['attachment'])): ?>
                                            <span>•</span>
                                            <a href="<?= e(url($a['attachment'])) ?>" target="_blank" class="text-primary text-decoration-none d-inline-flex align-items-center gap-1">
                                                <i data-lucide="paperclip" style="width: 10px; height: 10px;"></i> File
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="py-3">
                                    <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                        <?= e($a['class_name']) ?><?= !empty($a['section_name']) ? ' &bull; ' . e($a['section_name']) : '' ?>
                                    </span>
                                </td>
                                <td class="py-3">
                                    <div class="fw-semibold text-dark" style="font-size: 12px;">
                                        Due: <?= e(date('d M Y', strtotime($a['due_date']))) ?>
                                    </div>
                                    <div class="text-muted" style="font-size: 10px;">Assigned: <?= e(date('d M Y', strtotime($a['assigned_date']))) ?></div>
                                </td>
                                <td class="py-3 fw-semibold text-dark">
                                    <?= (float)$a['max_marks'] ?> Marks
                                </td>
                                <td class="py-3">
                                    <?php
                                        $totSt = (int)($a['total_students'] ?? 0);
                                        $subSt = (int)($a['submitted_count'] ?? 0);
                                        $grdSt = (int)($a['graded_count'] ?? 0);
                                        $pct = ($totSt > 0) ? round(($subSt / $totSt) * 100) : 0;
                                    ?>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="fw-bold text-dark small" style="font-size: 12px;"><?= $subSt ?> / <?= $totSt ?></span>
                                        <span class="text-muted" style="font-size: 10px;">Submitted (<?= $pct ?>%)</span>
                                    </div>
                                    <div class="progress" style="height: 6px; border-radius: 3px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $pct ?>%;" aria-valuenow="<?= $pct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <div class="text-muted mt-1" style="font-size: 10px;"><?= $grdSt ?> Graded</div>
                                </td>
                                <td class="py-3">
                                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 11px; font-weight: 600;">
                                        <?= ucfirst($a['status'] ?? 'published') ?>
                                    </span>
                                </td>
                                <td class="text-end px-3 py-3">
                                    <div class="d-flex align-items-center justify-content-end gap-1">
                                        <a href="<?= e(url('assignments/' . $a['id'])) ?>" class="btn btn-sm btn-primary rounded-pill px-3 py-1 d-inline-flex align-items-center gap-1 shadow-sm" style="font-size: 12px;">
                                            <i data-lucide="check-square" style="width: 13px; height: 13px;"></i>
                                            <span>Submissions &amp; Grade</span>
                                        </a>

                                        <a href="<?= e(url('assignments/' . $a['id'] . '/edit')) ?>" class="btn btn-sm btn-light border rounded-pill px-2 py-1" title="Edit Assignment">
                                            <i data-lucide="pencil" style="width: 12px; height: 12px;"></i>
                                        </a>

                                        <form method="post" action="<?= e(url('assignments/' . $a['id'] . '/delete')) ?>" onsubmit="return confirm('Are you sure you want to delete this assignment?');" class="d-inline m-0">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-2 py-1" title="Delete Assignment">
                                                <i data-lucide="trash-2" style="width: 12px; height: 12px;"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="p-4 text-center">
                                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                        <i data-lucide="file-x-2" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                    </div>
                                    <h6 class="fw-bold text-dark mb-1">No Graded Assignments</h6>
                                    <p class="text-muted small mb-3">No graded assignments have been published yet.</p>
                                    <a href="<?= e(url('assignments/create?mode=assignment')) ?>" class="btn btn-primary btn-sm rounded-pill px-3 py-2">
                                        <i data-lucide="plus" style="width: 14px; height: 14px;" class="me-1"></i> Create First Assignment
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
</script>