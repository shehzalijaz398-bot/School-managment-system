<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-dark d-flex align-items-center gap-2">
            <i data-lucide="edit-3" style="stroke: #4f46e5; width: 24px; height: 24px;"></i>
            <span>Edit Assignment / Task</span>
        </h2>
        <p class="text-muted small mb-0">Update assignment details, submission deadlines, instructions, and worksheets</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('assignments/' . $assignment['id'])) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-2" style="font-size: 12px;">
            <i data-lucide="eye" style="width: 13px; height: 13px;" class="me-1"></i> View Submissions
        </a>
        <a href="<?= e(url('assignments')) ?>" class="btn btn-sm btn-light border rounded-pill px-3 py-2 text-secondary" style="font-size: 12px;">
            <i data-lucide="arrow-left" style="width: 13px; height: 13px;" class="me-1"></i> Back
        </a>
    </div>
</div>

<form method="post" action="<?= e(url('assignments/' . $assignment['id'])) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3" style="border-color: #f1f5f9 !important;">
            <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 14px;">
                <i data-lucide="clipboard-list" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                <span>Assignment Details</span>
            </h6>
        </div>
        <div class="card-body p-4">
            <div class="row g-3 mb-3">
                <div class="col-12 col-md-8">
                    <label class="form-label text-sm fw-semibold text-dark">Assignment Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= e($assignment['title']) ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Maximum Marks</label>
                    <input type="number" step="0.5" min="0" name="max_marks" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= (float)$assignment['max_marks'] ?>" required>
                    <div class="form-text text-muted" style="font-size: 11px;">Set to 0 for daily home tasks/diary</div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Class <span class="text-danger">*</span></label>
                    <select name="class_id" id="editClassSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= (int)$c['id'] ?>" data-sections='<?= e(json_encode($c['sections'])) ?>' <?= ((int)$assignment['class_id'] === (int)$c['id']) ? 'selected' : '' ?>>
                                <?= e($c['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Section <span class="text-danger">*</span></label>
                    <select name="section_id" id="editSectionSelect" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <option value="<?= (int)$assignment['section_id'] ?>"><?= e($assignment['section_name'] ?? 'Section') ?></option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Subject <span class="text-danger">*</span></label>
                    <select name="subject_id" class="form-select rounded-3 shadow-sm border-0 bg-light" required>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= (int)$s['id'] ?>" <?= ((int)$assignment['subject_id'] === (int)$s['id']) ? 'selected' : '' ?>>
                                <?= e($s['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Assigned Date <span class="text-danger">*</span></label>
                    <input type="date" name="assigned_date" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= e($assignment['assigned_date']) ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Due Date (Deadline) <span class="text-danger">*</span></label>
                    <input type="date" name="due_date" class="form-control rounded-3 shadow-sm border-0 bg-light" value="<?= e($assignment['due_date']) ?>" required>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label text-sm fw-semibold text-dark">Publish Status</label>
                    <select name="status" class="form-select rounded-3 shadow-sm border-0 bg-light">
                        <option value="published" <?= $assignment['status'] === 'published' ? 'selected' : '' ?>>Published (Visible to Students)</option>
                        <option value="draft" <?= $assignment['status'] === 'draft' ? 'selected' : '' ?>>Draft (Saved only for Teacher)</option>
                        <option value="closed" <?= $assignment['status'] === 'closed' ? 'selected' : '' ?>>Closed (Submissions Locked)</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label text-sm fw-semibold text-dark">Instructions / Problem Statements</label>
                <textarea name="description" rows="4" class="form-control rounded-3 shadow-sm border-0 bg-light"><?= e($assignment['description'] ?? '') ?></textarea>
            </div>

            <div class="mb-2">
                <label class="form-label text-sm fw-semibold text-dark d-flex justify-content-between align-items-center">
                    <span>Worksheet / Attachment File</span>
                    <span class="text-muted small" style="font-size: 11px;">PDF, DOCX, PNG, JPG, ZIP (Leave empty to keep existing)</span>
                </label>
                <input type="file" name="attachment" class="form-control rounded-3 shadow-sm border-0 bg-light" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.zip,.txt">
                <?php if (!empty($assignment['attachment'])): ?>
                    <div class="mt-2 text-muted small d-flex align-items-center gap-2">
                        <span>Current File:</span>
                        <a href="<?= e(url($assignment['attachment'])) ?>" target="_blank" class="badge bg-light text-primary border text-decoration-none">
                            <i data-lucide="paperclip" style="width: 11px; height: 11px;" class="me-1"></i> View Existing Document
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center">
            <a href="<?= e(url('assignments')) ?>" class="btn btn-light rounded-pill px-4 fw-medium">Cancel</a>
            <button type="submit" class="btn btn-primary rounded-pill px-4 fw-medium d-flex align-items-center gap-2 shadow-sm">
                <i data-lucide="save" style="width: 15px; height: 15px;"></i>
                <span>Update Assignment</span>
            </button>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    const classSelect = document.getElementById('editClassSelect');
    const sectionSelect = document.getElementById('editSectionSelect');
    const currentSectionId = <?= (int)$assignment['section_id'] ?>;

    function populateSections() {
        const opt = classSelect.options[classSelect.selectedIndex];
        sectionSelect.innerHTML = '<option value="">-- Select Section --</option>';
        if (opt && opt.dataset.sections) {
            try {
                const sections = JSON.parse(opt.dataset.sections);
                sections.forEach(s => {
                    const o = document.createElement('option');
                    o.value = s.id;
                    o.textContent = s.name;
                    if (parseInt(s.id) === currentSectionId) {
                        o.selected = true;
                    }
                    sectionSelect.appendChild(o);
                });
            } catch(e) {}
        }
    }

    classSelect.addEventListener('change', populateSections);
    populateSections();
});
</script>
