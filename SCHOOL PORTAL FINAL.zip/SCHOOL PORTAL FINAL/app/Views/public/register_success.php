<?php
$registration = $registration ?? [];
$isProvisioned = $isProvisioned ?? false;
$statusLabel = $statusLabel ?? 'Pending Verification';
$loginUrl = $loginUrl ?? url('login');

// Robust Education Levels Parser (Handles JSON, comma-separated strings, or arrays)
$levelsList = [];
if (!empty($registration['education_levels'])) {
    if (is_array($registration['education_levels'])) {
        $levelsList = array_map('trim', array_map('ucfirst', $registration['education_levels']));
    } elseif (is_string($registration['education_levels'])) {
        $json = json_decode($registration['education_levels'], true);
        if (is_array($json)) {
            $levelsList = array_map('trim', array_map('ucfirst', $json));
        } else {
            $parts = explode(',', $registration['education_levels']);
            $levelsList = array_filter(array_map('trim', array_map('ucfirst', $parts)));
        }
    }
}
$levelsText = !empty($levelsList) ? implode(', ', $levelsList) : 'General Academic Levels';

// Address formatting
if (!empty($registration['address'])) {
    $fullAddress = $registration['address'];
} else {
    $addressComponents = array_filter([
        !empty($registration['house_number']) ? 'House/Plot: ' . $registration['house_number'] : '',
        !empty($registration['street']) ? $registration['street'] : '',
        !empty($registration['area']) ? $registration['area'] : '',
        !empty($registration['city']) ? $registration['city'] : '',
        !empty($registration['province']) ? $registration['province'] : '',
        !empty($registration['country']) ? $registration['country'] : '',
    ]);
    $fullAddress = !empty($addressComponents) ? implode(', ', $addressComponents) : 'Campus address not specified';
}

// Academic session
$sessionStart = !empty($registration['academic_year_start']) ? $registration['academic_year_start'] : '';
$sessionEnd = !empty($registration['academic_year_end']) ? $registration['academic_year_end'] : '';
$sessionCycle = ($sessionStart || $sessionEnd) ? trim($sessionStart . ' — ' . ($sessionEnd ?: 'Annual'), ' —') : 'Annual Academic Session';

// Registration date and trial expiry
$registrationDate = !empty($registration['created_at']) 
    ? date('d M Y, h:i A', strtotime($registration['created_at'])) 
    : date('d M Y, h:i A');

$trialExpiry = !empty($registration['trial_ends_at']) 
    ? date('d M Y', strtotime($registration['trial_ends_at'])) 
    : date('d M Y', strtotime('+30 days'));

$voucherNo = 'VCH-REG-' . date('Y', !empty($registration['created_at']) ? strtotime($registration['created_at']) : time()) . '-' . str_pad((string)($registration['id'] ?? 1), 5, '0', STR_PAD_LEFT);

// School Logo - Base64 Data URI for 100% reliable local & PDF rendering without CORS/404 issues
$logoDataUri = '';
if (!empty($registration['logo'])) {
    $cleanLogo = ltrim($registration['logo'], '/');
    $possibleLogoFiles = [
        defined('BASE_PATH') ? BASE_PATH . '/public/' . $cleanLogo : null,
        defined('BASE_PATH') ? BASE_PATH . '/' . $cleanLogo : null,
        dirname(__DIR__, 2) . '/public/' . $cleanLogo,
    ];
    foreach ($possibleLogoFiles as $file) {
        if ($file && file_exists($file) && is_file($file)) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $mimeMap = [
                'jpg'  => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'png'  => 'image/png',
                'gif'  => 'image/gif',
                'webp' => 'image/webp',
                'svg'  => 'image/svg+xml',
            ];
            $mime = $mimeMap[$ext] ?? (function_exists('mime_content_type') ? mime_content_type($file) : 'image/jpeg');
            $logoDataUri = 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($file));
            break;
        }
    }
    if (empty($logoDataUri)) {
        $logoDataUri = url($cleanLogo);
    }
}
?>

<!-- On-Screen Action & Status Bar (Hidden during Print & PDF) -->
<div class="screen-wrapper py-4 px-3 d-print-none">
  <div class="container" style="max-width: 860px;">
    
    <!-- Top Flash Alert -->
    <div class="alert alert-success border-0 shadow-sm d-flex align-items-center justify-content-between p-3 mb-4 rounded-3">
      <div class="d-flex align-items-center gap-3">
        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; min-width: 44px;">
          <i class="bi bi-check-lg fs-4"></i>
        </div>
        <div>
          <h5 class="alert-heading mb-0 fw-bold text-success">Registration Successful!</h5>
          <p class="mb-0 text-secondary small">Your institution portal has been provisioned. Download or print your official voucher below.</p>
        </div>
      </div>
      <a href="<?= e($loginUrl) ?>" class="btn btn-success fw-bold px-3 py-2 text-nowrap d-none d-md-inline-flex align-items-center gap-1 shadow-sm">
        <span>Go to Login</span>
        <i class="bi bi-arrow-right"></i>
      </a>
    </div>

    <!-- Screen Action Buttons -->
    <div class="card border-0 shadow-sm mb-4 rounded-3">
      <div class="card-body p-3">
        <div class="row g-2 align-items-center">
          <div class="col-md-5">
            <a href="<?= e($loginUrl) ?>" class="btn btn-primary w-100 fw-bold py-2 shadow-sm d-flex align-items-center justify-content-center gap-2">
              <i class="bi bi-box-arrow-in-right fs-5"></i>
              <span>Login to School Portal Now</span>
            </a>
          </div>
          <div class="col-md-4">
            <button type="button" class="btn btn-outline-danger w-100 fw-semibold py-2 d-flex align-items-center justify-content-center gap-2" id="downloadPdfBtn">
              <i class="bi bi-file-earmark-pdf-fill fs-5"></i>
              <span id="downloadBtnText">Download PDF Voucher</span>
            </button>
          </div>
          <div class="col-md-3">
            <button type="button" class="btn btn-outline-secondary w-100 fw-semibold py-2 d-flex align-items-center justify-content-center gap-2" onclick="window.print()">
              <i class="bi bi-printer fs-5"></i>
              <span>Print</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex align-items-center justify-content-between mb-2">
      <span class="text-uppercase fw-bold text-muted small" style="letter-spacing: 0.05em;"><i class="bi bi-file-text me-1"></i> Official Voucher Preview</span>
      <span class="badge bg-secondary-subtle text-secondary border px-2 py-1 small">A4 Document Ready</span>
    </div>

  </div>
</div>

<!-- ========================================================================= -->
<!-- OFFICIAL REGISTRATION VOUCHER CONTAINER (Rendered on Screen & in PDF/Print) -->
<!-- ========================================================================= -->
<div class="voucher-page-wrap">
  <div id="printableVoucher" class="voucher-document">
    
    <!-- Outer Elegant Border Frame -->
    <div class="voucher-border-frame">

      <!-- Header Banner -->
      <div class="voucher-header">
        <div class="row align-items-center">
          <div class="col-7">
            <div class="d-flex align-items-center gap-3">
              <?php if (!empty($logoDataUri)): ?>
                <img src="<?= $logoDataUri ?>" alt="School Logo" class="school-voucher-logo">
              <?php else: ?>
                <div class="voucher-logo-placeholder">
                  <i class="bi bi-mortarboard-fill"></i>
                </div>
              <?php endif; ?>
              <div>
                <div class="voucher-system-tag">School Portal SaaS · Cloud ERP</div>
                <h1 class="voucher-school-title mb-0"><?= e($registration['school_name'] ?: 'School Portal Institution') ?></h1>
                <div class="voucher-school-sub">Official Registration Voucher & Onboarding Certificate</div>
              </div>
            </div>
          </div>
          <div class="col-5 text-end">
            <div class="voucher-meta-box">
              <div class="voucher-no"><span class="lbl">VOUCHER NO:</span> <strong><?= e($voucherNo) ?></strong></div>
              <div class="voucher-date"><span class="lbl">DATE:</span> <?= e($registrationDate) ?></div>
              <div class="voucher-badge-status">
                <span class="v-badge <?= $isProvisioned ? 'v-badge-success' : 'v-badge-warning' ?>">
                  <?= $isProvisioned ? 'PROVISIONED & ACTIVE (30-DAY TRIAL)' : 'PENDING VERIFICATION' ?>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Highlight Band: School Code & Direct Login -->
      <div class="voucher-highlight-band">
        <div class="row g-2 align-items-center text-center text-md-start">
          <div class="col-md-4">
            <div class="small text-muted text-uppercase fw-semibold" style="font-size: 0.72rem;">Assigned School Code</div>
            <div class="voucher-school-code"><?= e($registration['school_code'] ?? 'PENDING') ?></div>
          </div>
          <div class="col-md-4 text-md-center">
            <div class="small text-muted text-uppercase fw-semibold" style="font-size: 0.72rem;">Cloud Tenant ID</div>
            <div class="fw-bold text-dark font-monospace" style="font-size: 1.05rem;">TENANT-#<?= str_pad((string)($registration['school_id'] ?? $registration['id']), 4, '0', STR_PAD_LEFT) ?></div>
          </div>
          <div class="col-md-4 text-md-end">
            <div class="small text-muted text-uppercase fw-semibold" style="font-size: 0.72rem;">Direct Portal Access</div>
            <div class="text-primary fw-bold font-monospace" style="font-size: 0.82rem;">
              <span><?= e(parse_url(url('/'), PHP_URL_HOST) ?: 'localhost') ?>/login</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Information Grid Sections -->
      <div class="voucher-body">
        
        <!-- Section 1 & 2: Institutional Profile & Academic Structure -->
        <div class="row g-3 mb-3">
          
          <!-- Box 1: Institutional Profile -->
          <div class="col-6">
            <div class="voucher-section-box h-100">
              <div class="section-title">
                <i class="bi bi-building me-1 text-primary"></i> 1. Institutional Identity & Campus
              </div>
              <table class="voucher-data-table">
                <tr>
                  <td class="v-lbl">School Name:</td>
                  <td class="v-val fw-bold text-dark"><?= e($registration['school_name']) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Institution Type:</td>
                  <td class="v-val"><?= e(ucfirst(str_replace('_', ' ', $registration['school_type'] ?? 'Private School'))) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Official Email:</td>
                  <td class="v-val font-monospace"><?= e($registration['email']) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Official Phone:</td>
                  <td class="v-val"><?= !empty($registration['phone']) ? e($registration['phone']) : 'N/A' ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Official Website:</td>
                  <td class="v-val"><?= !empty($registration['website']) ? e($registration['website']) : 'Not Provided' ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Campus Address:</td>
                  <td class="v-val">
                    <div><?= e($fullAddress) ?></div>
                  </td>
                </tr>
              </table>
            </div>
          </div>

          <!-- Box 2: Academic Configuration -->
          <div class="col-6">
            <div class="voucher-section-box h-100">
              <div class="section-title">
                <i class="bi bi-mortarboard me-1 text-primary"></i> 2. Academic Framework & Capacity
              </div>
              <table class="voucher-data-table">
                <tr>
                  <td class="v-lbl">Education Levels:</td>
                  <td class="v-val fw-semibold text-dark"><?= e($levelsText) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Curriculum / Board:</td>
                  <td class="v-val"><?= !empty($registration['curriculum']) ? e($registration['curriculum']) : 'General Curriculum' ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Session Cycle:</td>
                  <td class="v-val"><?= e($sessionCycle) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Projected Students:</td>
                  <td class="v-val fw-bold text-dark"><?= number_format((int)($registration['estimated_students'] ?? 0)) ?> Students</td>
                </tr>
                <tr>
                  <td class="v-lbl">Faculty & Staff:</td>
                  <td class="v-val"><?= number_format((int)($registration['estimated_staff'] ?? 0)) ?> Members</td>
                </tr>
                <tr>
                  <td class="v-lbl">Academic Year:</td>
                  <td class="v-val"><?= date('Y') ?> — <?= date('Y') + 1 ?> Cycle</td>
                </tr>
              </table>
            </div>
          </div>

        </div>

        <!-- Section 3 & 4: Administrator & Commercial Subscription -->
        <div class="row g-3 mb-3">
          
          <!-- Box 3: Primary Administrator -->
          <div class="col-6">
            <div class="voucher-section-box h-100">
              <div class="section-title">
                <i class="bi bi-person-badge me-1 text-primary"></i> 3. Primary Administrator / Custodian
              </div>
              <table class="voucher-data-table">
                <tr>
                  <td class="v-lbl">Full Name:</td>
                  <td class="v-val fw-bold text-dark"><?= e($registration['contact_person']) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Login Email:</td>
                  <td class="v-val font-monospace fw-semibold text-primary"><?= e($registration['email']) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Contact Phone:</td>
                  <td class="v-val"><?= !empty($registration['phone']) ? e($registration['phone']) : 'N/A' ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Assigned Role:</td>
                  <td class="v-val"><span class="badge bg-primary-subtle text-primary border border-primary-subtle">School Super Administrator</span></td>
                </tr>
                <tr>
                  <td class="v-lbl">Account Access:</td>
                  <td class="v-val text-success fw-semibold"><i class="bi bi-shield-check me-1"></i> Full Tenant Administration</td>
                </tr>
              </table>
            </div>
          </div>

          <!-- Box 4: Commercial Subscription & Trial Status -->
          <div class="col-6">
            <div class="voucher-section-box h-100">
              <div class="section-title">
                <i class="bi bi-credit-card me-1 text-primary"></i> 4. Subscription Plan & Billing Summary
              </div>
              <table class="voucher-data-table">
                <tr>
                  <td class="v-lbl">Selected Plan:</td>
                  <td class="v-val fw-bold text-dark"><?= e($registration['plan_name'] ?? 'Standard Package') ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Regular Fee:</td>
                  <td class="v-val">
                    <?= !empty($registration['monthly_price']) ? 'Rs. ' . number_format((float)$registration['monthly_price'], 2) . ' / month' : 'Free Trial' ?>
                  </td>
                </tr>
                <tr>
                  <td class="v-lbl">Trial Period:</td>
                  <td class="v-val text-success fw-bold">30 Days Free Trial</td>
                </tr>
                <tr>
                  <td class="v-lbl">Trial Expiry:</td>
                  <td class="v-val fw-semibold text-danger"><?= e($trialExpiry) ?></td>
                </tr>
                <tr>
                  <td class="v-lbl">Initial Payment:</td>
                  <td class="v-val fw-bold text-success font-monospace" style="font-size: 1.05rem;">
                    Rs. 0.00 (Trial Waived)
                  </td>
                </tr>
              </table>
            </div>
          </div>

        </div>

        <!-- Section 5: Step-by-Step Onboarding Guidance -->
        <div class="voucher-instruction-box mb-3">
          <div class="instruction-title">
            <i class="bi bi-info-circle-fill me-1 text-primary"></i> Next Steps & Important Login Instructions
          </div>
          <div class="row g-2 mt-1">
            <div class="col-4">
              <div class="step-card">
                <div class="step-num">Step 1</div>
                <div class="step-txt">Sign in at <strong><?= e(url('login')) ?></strong> using School Code <strong><?= e($registration['school_code'] ?? '') ?></strong> and your admin credentials.</div>
              </div>
            </div>
            <div class="col-4">
              <div class="step-card">
                <div class="step-num">Step 2</div>
                <div class="step-txt">Configure academic sessions, classes, sections, and add faculty & staff credentials.</div>
              </div>
            </div>
            <div class="col-4">
              <div class="step-card">
                <div class="step-num">Step 3</div>
                <div class="step-txt">Keep your School Code <strong><?= e($registration['school_code'] ?? 'Pending') ?></strong> secure for system support and billing.</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Verification & Signatures Block -->
        <div class="voucher-footer">
          <div class="row align-items-end">
            <div class="col-4 text-center">
              <div class="sig-seal-wrap">
                <div class="sig-seal">
                  <div class="sig-seal-inner">
                    <span>SCHOOL PORTAL</span>
                    <i class="bi bi-patch-check-fill"></i>
                    <small>OFFICIALLY ISSUED</small>
                  </div>
                </div>
              </div>
              <div class="sig-line"></div>
              <div class="sig-title">System Registrar & Automation</div>
              <div class="sig-sub">Digital Cloud Verification</div>
            </div>
            <div class="col-4 text-center">
              <div class="barcode-simulation">
                <div class="barcode-lines"></div>
                <div class="barcode-text"><?= e($voucherNo) ?></div>
              </div>
              <div class="computer-gen-disclaimer">
                Computer-generated official document.<br>No manual signature required.
              </div>
            </div>
            <div class="col-4 text-center">
              <div style="height: 55px;"></div>
              <div class="sig-line"></div>
              <div class="sig-title">Primary School Administrator</div>
              <div class="sig-sub"><?= e($registration['contact_person']) ?> (Authorized Signatory)</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<!-- ========================================================================= -->
<!-- STYLES FOR VOUCHER (Screen Display, PDF Rendering, and Print Layout)      -->
<!-- ========================================================================= -->
<style>
  /* Base reset for voucher page */
  .voucher-page-wrap {
    display: flex;
    justify-content: center;
    padding: 0 1rem 3rem 1rem;
    background: #f1f5f9;
  }

  /* Fixed A4 dimensions for perfect 1-page PDF export */
  .voucher-document {
    width: 794px;
    min-height: 1122px;
    max-width: 100%;
    background: #ffffff;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
    border-radius: 8px;
    box-sizing: border-box;
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #1e293b;
    margin: 0 auto;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  .voucher-border-frame {
    border: 2px solid #0f172a;
    padding: 22px 24px 18px 24px;
    border-radius: 6px;
    margin: 10px;
    box-sizing: border-box;
    background: #ffffff;
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 1102px;
  }

  .voucher-body {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-top: 6px;
  }

  /* Header styles */
  .voucher-header {
    border-bottom: 2px solid #0f172a;
    padding-bottom: 12px;
    margin-bottom: 12px;
  }
  .voucher-system-tag {
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #4f46e5;
  }
  .voucher-school-title {
    font-size: 1.40rem;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.25;
    letter-spacing: -0.02em;
    word-break: break-word;
  }
  .voucher-school-sub {
    font-size: 0.80rem;
    font-weight: 600;
    color: #64748b;
  }
  .voucher-logo-placeholder {
    width: 58px;
    height: 58px;
    min-width: 58px;
    background: #0f172a;
    color: #ffffff;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.85rem;
    flex-shrink: 0;
  }
  .school-voucher-logo {
    width: 60px;
    height: 60px;
    min-width: 60px;
    max-width: 60px;
    max-height: 60px;
    object-fit: contain;
    border-radius: 6px;
    border: 1px solid #cbd5e1;
    padding: 2px;
    background: #ffffff;
    flex-shrink: 0;
  }
  .voucher-meta-box {
    font-size: 0.80rem;
    line-height: 1.4;
  }
  .voucher-meta-box .lbl {
    color: #64748b;
    font-weight: 600;
    font-size: 0.72rem;
  }
  .voucher-no {
    font-family: monospace;
    font-size: 0.95rem;
    color: #0f172a;
  }
  .voucher-date {
    font-size: 0.78rem;
    color: #334155;
  }
  .v-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    margin-top: 4px;
  }
  .v-badge-success {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #86efac;
  }
  .v-badge-warning {
    background: #fef3c7;
    color: #b45309;
    border: 1px solid #fde68a;
  }

  /* Highlight Band */
  .voucher-highlight-band {
    background: #f8fafc;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 10px 14px;
    margin-bottom: 12px;
  }
  .voucher-school-code {
    font-family: monospace;
    font-size: 1.25rem;
    font-weight: 800;
    color: #1d4ed8;
    letter-spacing: 0.05em;
  }

  /* Section Boxes */
  .voucher-section-box {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 10px 12px;
    background: #ffffff;
    height: 100%;
  }
  .section-title {
    font-size: 0.78rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: #0f172a;
    border-bottom: 1px solid #e2e8f0;
    padding-bottom: 5px;
    margin-bottom: 6px;
  }
  .voucher-data-table {
    width: 100%;
    table-layout: fixed;
    border-collapse: collapse;
    font-size: 0.76rem;
  }
  .voucher-data-table td {
    padding: 3.5px 0;
    vertical-align: top;
    word-break: break-word;
    overflow-wrap: anywhere;
  }
  .voucher-data-table .v-lbl {
    width: 36%;
    color: #64748b;
    font-weight: 600;
    font-size: 0.74rem;
  }
  .voucher-data-table .v-val {
    width: 64%;
    color: #1e293b;
    font-size: 0.76rem;
  }

  /* Instructions */
  .voucher-instruction-box {
    background: #f8fafc;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 10px 12px;
    margin-top: 8px;
    margin-bottom: 8px;
  }
  .instruction-title {
    font-size: 0.76rem;
    font-weight: 800;
    text-transform: uppercase;
    color: #0f172a;
    letter-spacing: 0.03em;
    margin-bottom: 5px;
  }
  .step-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 5px;
    padding: 7px 9px;
    height: 100%;
    word-break: break-word;
    overflow-wrap: anywhere;
  }
  .step-num {
    font-size: 0.70rem;
    font-weight: 800;
    color: #2563eb;
    text-transform: uppercase;
    margin-bottom: 2px;
  }
  .step-txt {
    font-size: 0.70rem;
    color: #334155;
    line-height: 1.35;
    word-break: break-word;
    overflow-wrap: anywhere;
  }

  /* Footer & Signatures */
  .voucher-footer {
    border-top: 1px dashed #cbd5e1;
    padding-top: 12px;
    margin-top: auto;
  }
  .sig-line {
    border-top: 1px solid #0f172a;
    margin: 0 15px 3px 15px;
  }
  .sig-title {
    font-size: 0.72rem;
    font-weight: 700;
    color: #0f172a;
  }
  .sig-sub {
    font-size: 0.66rem;
    color: #64748b;
    word-break: break-word;
  }
  .sig-seal-wrap {
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .sig-seal {
    width: 44px;
    height: 44px;
    border: 2px dashed #15803d;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #15803d;
    padding: 2px;
  }
  .sig-seal-inner {
    text-align: center;
    font-size: 0.46rem;
    font-weight: 800;
    line-height: 1;
  }
  .sig-seal-inner i {
    font-size: 0.72rem;
    display: block;
    margin: 1px 0;
  }
  .barcode-simulation {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 36px;
  }
  .barcode-lines {
    width: 130px;
    height: 18px;
    background: repeating-linear-gradient(
      90deg,
      #0f172a,
      #0f172a 2px,
      transparent 2px,
      transparent 4px,
      #0f172a 4px,
      #0f172a 7px,
      transparent 7px,
      transparent 9px
    );
  }
  .barcode-text {
    font-family: monospace;
    font-size: 0.64rem;
    color: #64748b;
    margin-top: 1px;
  }
  .computer-gen-disclaimer {
    font-size: 0.62rem;
    color: #94a3b8;
    line-height: 1.25;
    margin-top: 3px;
  }

  /* =========================================================
     PRINT MEDIA STYLES (window.print() or Ctrl+P)
     ========================================================= */
  @media print {
    html, body {
      background: #ffffff !important;
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      height: 100% !important;
    }
    .d-print-none, .screen-wrapper, nav, header, footer {
      display: none !important;
    }
    .voucher-page-wrap {
      padding: 0 !important;
      margin: 0 !important;
      background: #ffffff !important;
      display: block !important;
      width: 100% !important;
      height: 100% !important;
    }
    .voucher-document {
      width: 100% !important;
      height: 280mm !important;
      min-height: 280mm !important;
      max-width: 100% !important;
      box-shadow: none !important;
      border-radius: 0 !important;
      margin: 0 !important;
      padding: 0 !important;
      display: flex !important;
      flex-direction: column !important;
    }
    .voucher-border-frame {
      margin: 0 !important;
      border: 1.5pt solid #0f172a !important;
      padding: 16pt 18pt 14pt 18pt !important;
      flex: 1 !important;
      height: 100% !important;
      min-height: 275mm !important;
      display: flex !important;
      flex-direction: column !important;
      justify-content: space-between !important;
      box-sizing: border-box !important;
    }
    .voucher-body {
      flex: 1 !important;
      display: flex !important;
      flex-direction: column !important;
      justify-content: space-between !important;
    }
    @page {
      size: A4 portrait;
      margin: 8mm;
    }
  }
</style>

<!-- ========================================================================= -->
<!-- PDF EXPORT SCRIPT (html2pdf with zero scroll offset & pixel-perfect A4)   -->
<!-- ========================================================================= -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
  document.getElementById('downloadPdfBtn').addEventListener('click', function() {
    var btn = this;
    var btnText = document.getElementById('downloadBtnText');
    var originalHtml = btnText.innerHTML;
    
    // UI Loading indicator
    btn.disabled = true;
    btnText.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Generating PDF...';

    var src = document.getElementById('printableVoucher');

    // Create an isolated staging wrapper at page (0,0) with exact A4 aspect ratio (794px x 1122px)
    var stagingWrapper = document.createElement('div');
    stagingWrapper.id = 'pdf-staging-container';
    stagingWrapper.style.cssText = 'position: absolute; left: 0; top: 0; width: 794px; min-width: 794px; max-width: 794px; height: 1122px; min-height: 1122px; max-height: 1122px; background: #ffffff; z-index: 999999; margin: 0; padding: 0; box-sizing: border-box;';

    // Deep clone the voucher to prevent any flexbox centering or window scroll clipping
    var clone = src.cloneNode(true);
    clone.style.cssText = 'width: 794px !important; min-width: 794px !important; max-width: 794px !important; height: 1122px !important; min-height: 1122px !important; max-height: 1122px !important; margin: 0 !important; box-shadow: none !important; border-radius: 0 !important; background: #ffffff !important; box-sizing: border-box !important; display: flex !important; flex-direction: column !important;';

    var frame = clone.querySelector('.voucher-border-frame');
    if (frame) {
      frame.style.cssText = 'margin: 10px !important; border: 2px solid #0f172a !important; padding: 22px 24px 18px 24px !important; box-sizing: border-box !important; background: #ffffff !important; flex: 1 !important; height: 1102px !important; min-height: 1102px !important; display: flex !important; flex-direction: column !important; justify-content: space-between !important;';
    }

    var vBody = clone.querySelector('.voucher-body');
    if (vBody) {
      vBody.style.cssText = 'flex: 1 !important; display: flex !important; flex-direction: column !important; justify-content: space-between !important;';
    }

    stagingWrapper.appendChild(clone);
    document.body.appendChild(stagingWrapper);

    // Save previous scroll and scroll window to (0,0) for exact coordinate alignment
    var prevScrollX = window.scrollX || window.pageXOffset || 0;
    var prevScrollY = window.scrollY || window.pageYOffset || 0;
    window.scrollTo(0, 0);

    var opt = {
      margin:       0, // 0 margin so 794x1122 fills 100% of A4 page with no blank bottom space
      filename:     'School_Registration_Voucher.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { 
        scale: 2, 
        useCORS: true,
        scrollX: 0,
        scrollY: 0,
        x: 0,
        y: 0,
        width: 794,
        height: 1122,
        windowWidth: 794,
        windowHeight: 1122,
        logging: false 
      },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(clone).save().then(function() {
      if (stagingWrapper && stagingWrapper.parentNode) {
        stagingWrapper.parentNode.removeChild(stagingWrapper);
      }
      window.scrollTo(prevScrollX, prevScrollY);
      btn.disabled = false;
      btnText.innerHTML = originalHtml;
    }).catch(function(err) {
      console.error('PDF generation error:', err);
      if (stagingWrapper && stagingWrapper.parentNode) {
        stagingWrapper.parentNode.removeChild(stagingWrapper);
      }
      window.scrollTo(prevScrollX, prevScrollY);
      btn.disabled = false;
      btnText.innerHTML = originalHtml;
      alert('Could not download PDF directly. You can use the Print button to Save as PDF.');
    });
  });
</script>
