<div class="container py-4 py-md-5">
  <div class="text-center max-w-700 mx-auto mb-4 mb-md-5">
    <a href="<?= e(url('/')) ?>" class="d-inline-flex align-items-center gap-1 text-decoration-none text-muted small mb-3">
      <i class="bi bi-arrow-left"></i> Back to Homepage
    </a>
    <h1 class="display-6 fw-bold font-heading mb-2">Transparent, Scalable Pricing</h1>
    <p class="text-muted lead fs-6">Every plan includes a 30-day unrestricted free trial with complete institutional access.</p>
  </div>
  
  <div class="row g-3 g-lg-4 justify-content-center">
    <?php foreach ($plans as $p): ?>
      <?php $isPopular = ($p['slug'] ?? '') === 'professional'; ?>
      <div class="col-12 col-md-6 col-lg-4">
        <div class="card h-100 border rounded-4 p-4 shadow-sm position-relative <?= $isPopular ? 'border-primary' : '' ?>" style="<?= $isPopular ? 'border-width: 2px !important;' : '' ?>">
          <?php if ($isPopular): ?>
            <span class="badge bg-primary position-absolute top-0 end-0 m-3 px-3 py-1 rounded-pill">Most Popular</span>
          <?php endif; ?>
          <div class="mb-3">
            <h3 class="h4 fw-bold mb-1"><?= e($p['name']) ?></h3>
            <p class="text-muted small mb-0"><?= e($p['description']) ?></p>
          </div>
          <div class="mb-3 pb-3 border-bottom">
            <div class="d-flex align-items-baseline gap-1">
              <span class="fs-2 fw-bold text-dark"><?= e(formatMoney($p['monthly_price'])) ?></span>
              <span class="text-muted small">/month</span>
            </div>
            <div class="text-muted small mt-1">Billed annually: <?= e(formatMoney($p['annual_price'])) ?> / yr</div>
          </div>
          <ul class="list-unstyled d-flex flex-column gap-2 mb-4 flex-grow-1 small">
            <li class="d-flex align-items-center gap-2">
              <i class="bi bi-check-circle-fill text-success"></i>
              <span>Students: <strong><?= e((string)($p['student_limit'] ?? 'Unlimited')) ?></strong></span>
            </li>
            <li class="d-flex align-items-center gap-2">
              <i class="bi bi-check-circle-fill text-success"></i>
              <span>Faculty & Staff: <strong><?= e((string)($p['teacher_limit'] ?? 'Unlimited')) ?></strong></span>
            </li>
            <li class="d-flex align-items-center gap-2">
              <i class="bi bi-check-circle-fill text-success"></i>
              <span>Free Trial: <strong><?= (int)$p['trial_days'] ?> Days</strong></span>
            </li>
            <li class="d-flex align-items-center gap-2">
              <i class="bi bi-check-circle-fill text-success"></i>
              <span>Full Data Isolation & Backups</span>
            </li>
          </ul>
          <a class="btn <?= $isPopular ? 'btn-primary' : 'btn-outline-primary' ?> w-100 py-2 rounded-3 fw-semibold" href="<?= e(url('register?plan='.$p['id'])) ?>">
            Start <?= (int)$p['trial_days'] ?>-Day Free Trial
          </a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
