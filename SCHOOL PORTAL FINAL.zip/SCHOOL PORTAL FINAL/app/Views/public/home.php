<?php
/**
 * Public SaaS Landing Page
 * Responsive, modern, and aligned with all platform features and multi-stakeholder workflows.
 */
$platformName = platform_setting('platform_name', 'School Portal');
$plansList = $plans ?? [];

$currPrefix = platform_setting('default_currency', 'PKR') === 'PKR' ? 'Rs. ' : (platform_setting('default_currency', 'USD') === 'USD' ? '$' : platform_setting('default_currency', 'PKR') . ' ');
?>
<!-- Fonts & Icon Sets -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Outfit:wght@500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
:root {
  --sp-navy: #070e1b;
  --sp-dark-surface: #0e1726;
  --sp-primary: #0284c7;
  --sp-primary-hover: #0369a1;
  --sp-cyan: #06b6d4;
  --sp-accent: #3b82f6;
  --sp-emerald: #10b981;
  --sp-amber: #f59e0b;
  --sp-text: #0f172a;
  --sp-text-muted: #64748b;
  --sp-bg-light: #f8fafc;
  --sp-border-light: #e2e8f0;
  --sp-card-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.05), 0 4px 10px -2px rgba(0, 0, 0, 0.03);
}

body {
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  color: var(--sp-text);
  background-color: #ffffff;
  overflow-x: hidden;
  line-height: 1.6;
}

h1, h2, h3, h4, .font-heading {
  font-family: 'Outfit', 'Plus Jakarta Sans', sans-serif;
  letter-spacing: -0.02em;
}

/* --------------------------------------------------------------------------
   STICKY NAVBAR (Modern Glassmorphism & Micro-Interactions)
   -------------------------------------------------------------------------- */
.saas-navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1040;
  background: rgba(255, 255, 255, 0.94);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(226, 232, 240, 0.85);
  box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  padding-top: 0.75rem !important;
  padding-bottom: 0.75rem !important;
}

.saas-navbar.scrolled {
  background: rgba(255, 255, 255, 0.98);
  box-shadow: 0 10px 30px -5px rgba(15, 23, 42, 0.08);
  padding-top: 0.55rem !important;
  padding-bottom: 0.55rem !important;
}

.saas-brand-wrap {
  transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  flex-shrink: 0;
}
.saas-brand-wrap:hover {
  transform: scale(1.02);
}
.saas-brand-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 900;
  font-size: 19px;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35);
  transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.saas-brand-wrap:hover .saas-brand-icon {
  transform: rotate(-8deg) scale(1.1);
  box-shadow: 0 6px 20px rgba(2, 132, 199, 0.5);
}

.nav-link-custom {
  color: #334155;
  font-weight: 600;
  font-size: 0.88rem;
  padding: 0.45rem 0.72rem;
  border-radius: 8px;
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap !important;
  flex-shrink: 0;
  position: relative;
}

.nav-link-custom i {
  font-size: 0.95rem;
  color: #64748b;
  transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), color 0.25s ease;
}

.nav-link-custom:hover {
  color: #0284c7;
  background: rgba(2, 132, 199, 0.08);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.08);
}

.nav-link-custom:hover i {
  color: #0284c7;
  transform: translateY(-2px) scale(1.18);
}

.nav-link-custom.active {
  color: #0284c7;
  background: rgba(2, 132, 199, 0.09);
}

.nav-link-custom.active i {
  color: #0284c7;
}

.nav-link-custom::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  width: 0;
  height: 2.5px;
  background: linear-gradient(90deg, #0284c7, #38bdf8);
  border-radius: 2px;
  transition: all 0.28s cubic-bezier(0.16, 1, 0.3, 1);
  transform: translateX(-50%);
  box-shadow: 0 2px 6px rgba(2, 132, 199, 0.4);
}

.nav-link-custom:hover::after,
.nav-link-custom.active::after {
  width: 65%;
}

.btn-saas-outline {
  border: 1.5px solid #cbd5e1;
  color: #1e293b !important;
  font-weight: 600;
  font-size: 0.88rem;
  padding: 0.5rem 1.15rem;
  border-radius: 50px;
  background: #ffffff;
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  white-space: nowrap !important;
  flex-shrink: 0;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}

.btn-saas-outline i {
  transition: transform 0.2s ease;
}

.btn-saas-outline:hover {
  border-color: #0284c7;
  color: #0284c7 !important;
  background: #f0f9ff;
  transform: translateY(-2px);
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.18);
}

.btn-saas-outline:hover i {
  transform: translateX(2px);
}

.btn-saas-primary {
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
  color: #ffffff !important;
  font-weight: 700;
  font-size: 0.88rem;
  padding: 0.52rem 1.35rem;
  border-radius: 50px;
  border: none;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35);
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  white-space: nowrap !important;
  flex-shrink: 0;
  position: relative;
  overflow: hidden;
}

.btn-saas-primary::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: linear-gradient(
    60deg,
    transparent 20%,
    rgba(255, 255, 255, 0.28) 50%,
    transparent 80%
  );
  transform: rotate(25deg) translateY(-100%);
  transition: transform 0.75s ease;
}

.btn-saas-primary:hover::before {
  transform: rotate(25deg) translateY(100%);
}

.btn-saas-primary i {
  transition: transform 0.22s ease;
}

.btn-saas-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(2, 132, 199, 0.45);
  background: linear-gradient(135deg, #0369a1 0%, #0284c7 100%);
}

.btn-saas-primary:hover i {
  transform: translateX(3px);
}

/* On desktop laptops and monitors below 1400px: hide desktop nav link icons & compact padding to ensure zero button overflow */
@media (max-width: 1399.98px) {
  .saas-navbar .nav-link-custom i {
    display: none !important;
  }
}
@media (min-width: 1400px) {
  .saas-navbar .nav-link-custom i {
    display: inline-block !important;
  }
}
@media (min-width: 992px) and (max-width: 1399.98px) {
  .saas-navbar .nav-link-custom {
    padding: 0.35rem 0.52rem !important;
    font-size: 0.83rem !important;
  }
  .saas-navbar .btn-saas-outline {
    padding: 0.42rem 0.9rem !important;
    font-size: 0.82rem !important;
  }
  .saas-navbar .btn-saas-primary {
    padding: 0.42rem 1.05rem !important;
    font-size: 0.82rem !important;
  }
}

/* --------------------------------------------------------------------------
   HERO SECTION
   -------------------------------------------------------------------------- */
.saas-hero {
  position: relative;
  background: radial-gradient(120% 100% at 50% 0%, #0f172a 0%, #070e1b 100%);
  color: #ffffff;
  padding: 9.5rem 0 6rem;
  overflow: hidden;
}

.hero-mesh-grid {
  position: absolute;
  inset: 0;
  background-image: linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
  background-size: 48px 48px;
  pointer-events: none;
}

.hero-glow-blob {
  position: absolute;
  width: 650px;
  height: 650px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(2, 132, 199, 0.22) 0%, rgba(2, 132, 199, 0) 70%);
  top: -150px;
  right: -100px;
  pointer-events: none;
  filter: blur(40px);
}

.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(2, 132, 199, 0.15);
  border: 1px solid rgba(2, 132, 199, 0.35);
  padding: 6px 16px;
  border-radius: 50px;
  font-size: 0.82rem;
  font-weight: 700;
  color: #38bdf8;
  margin-bottom: 1.5rem;
}

.hero-title-main {
  font-size: 3.5rem;
  font-weight: 900;
  line-height: 1.12;
  margin-bottom: 1.5rem;
  background: linear-gradient(180deg, #ffffff 0%, #e2e8f0 100%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}

@media (max-width: 768px) {
  .hero-title-main { font-size: 2.4rem; }
}

.hero-description {
  font-size: 1.15rem;
  color: #94a3b8;
  line-height: 1.65;
  margin-bottom: 2rem;
  max-width: 580px;
}

/* Hero Dashboard Mockup */
.mockup-window {
  background: rgba(15, 23, 42, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 18px;
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05);
  overflow: hidden;
  transition: transform 0.3s ease;
}

.mockup-window:hover {
  transform: translateY(-4px);
}

.mockup-topbar {
  background: rgba(0, 0, 0, 0.35);
  padding: 12px 18px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.mockup-dots {
  display: flex;
  gap: 6px;
}

.mockup-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.mockup-dot.r { background: #ef4444; }
.mockup-dot.y { background: #f59e0b; }
.mockup-dot.g { background: #10b981; }

/* --------------------------------------------------------------------------
   SECTION HEADINGS & UTILITIES
   -------------------------------------------------------------------------- */
.section-tag {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #e0f2fe;
  color: #0369a1;
  font-size: 0.8rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 5px 14px;
  border-radius: 50px;
  margin-bottom: 1rem;
}

.section-heading {
  font-size: 2.4rem;
  font-weight: 800;
  color: #0f172a;
  margin-bottom: 1rem;
}

.section-lead {
  font-size: 1.1rem;
  color: #64748b;
  max-width: 680px;
  margin: 0 auto;
}

/* --------------------------------------------------------------------------
   FEATURE CARDS
   -------------------------------------------------------------------------- */
.feature-card {
  background: #ffffff;
  border: 1px solid var(--sp-border-light);
  border-radius: 16px;
  padding: 2rem 1.75rem;
  height: 100%;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  position: relative;
  overflow: hidden;
}

.feature-card:hover {
  transform: translateY(-5px);
  border-color: #93c5fd;
  box-shadow: 0 16px 36px -10px rgba(2, 132, 199, 0.12);
}

.feature-icon-box {
  width: 52px;
  height: 52px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
  margin-bottom: 1.25rem;
  background: #f0f9ff;
  color: var(--sp-primary);
  border: 1px solid #e0f2fe;
}

.feature-card:hover .feature-icon-box {
  background: var(--sp-primary);
  color: #ffffff;
}

.feature-title {
  font-size: 1.15rem;
  font-weight: 700;
  color: #0f172a;
  margin-bottom: 0.65rem;
}

.feature-desc {
  font-size: 0.92rem;
  color: #64748b;
  line-height: 1.55;
  margin-bottom: 0;
}

.badge-live {
  font-size: 0.7rem;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 50px;
  background: #dcfce7;
  color: #15803d;
}

/* --------------------------------------------------------------------------
   STAKEHOLDER SOLUTIONS
   -------------------------------------------------------------------------- */
.stakeholder-nav-pill {
  border: none;
  background: transparent;
  color: #64748b;
  font-weight: 700;
  font-size: 0.95rem;
  padding: 10px 22px;
  border-radius: 50px;
  transition: all 0.2s ease;
  cursor: pointer;
}

.stakeholder-nav-pill.active {
  background: #0284c7;
  color: #ffffff;
  box-shadow: 0 4px 14px rgba(2, 132, 199, 0.3);
}

.stakeholder-card {
  background: #ffffff;
  border: 1px solid var(--sp-border-light);
  border-radius: 20px;
  box-shadow: var(--sp-card-shadow);
  padding: 2.5rem;
}

/* --------------------------------------------------------------------------
   HOW IT WORKS STEPPER
   -------------------------------------------------------------------------- */
.step-item-card {
  background: #ffffff;
  border: 1px solid var(--sp-border-light);
  border-radius: 16px;
  padding: 2rem;
  position: relative;
  height: 100%;
}

.step-num-badge {
  position: absolute;
  top: -16px;
  left: 24px;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
  color: #fff;
  font-weight: 800;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 10px rgba(2, 132, 199, 0.35);
}

/* --------------------------------------------------------------------------
   PRICING
   -------------------------------------------------------------------------- */
.pricing-card-saas {
  background: #ffffff;
  border: 2px solid var(--sp-border-light);
  border-radius: 20px;
  padding: 2.5rem 2rem;
  height: 100%;
  position: relative;
  transition: all 0.3s ease;
}

.pricing-card-saas.popular {
  border-color: #0284c7;
  box-shadow: 0 20px 40px -10px rgba(2, 132, 199, 0.2);
  transform: scale(1.03);
}

@media (max-width: 991px) {
  .pricing-card-saas.popular { transform: none; }
}

.popular-tag {
  position: absolute;
  top: -14px;
  left: 50%;
  transform: translateX(-50%);
  background: #0284c7;
  color: #ffffff;
  font-weight: 800;
  font-size: 0.75rem;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  padding: 4px 14px;
  border-radius: 50px;
  box-shadow: 0 4px 10px rgba(2, 132, 199, 0.4);
}

.trial-banner-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #ecfdf5;
  border: 1px solid #a7f3d0;
  color: #047857;
  font-size: 0.8rem;
  font-weight: 700;
  padding: 4px 12px;
  border-radius: 50px;
  margin-bottom: 1.25rem;
}

/* --------------------------------------------------------------------------
   ACCORDION & FAQ
   -------------------------------------------------------------------------- */
.saas-faq .accordion-item {
  border: 1px solid var(--sp-border-light);
  border-radius: 12px !important;
  margin-bottom: 12px;
  overflow: hidden;
}

.saas-faq .accordion-button {
  font-weight: 700;
  font-size: 1.05rem;
  color: #0f172a;
  background: #ffffff;
  box-shadow: none;
  padding: 1.25rem 1.5rem;
}

.saas-faq .accordion-button:not(.collapsed) {
  color: var(--sp-primary);
  background: #f8fafc;
}

/* --------------------------------------------------------------------------
   FOOTER
   -------------------------------------------------------------------------- */
.saas-footer {
  background: #070e1b;
  color: #94a3b8;
  padding: 5rem 0 2.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
}

.footer-heading-col {
  color: #ffffff;
  font-weight: 700;
  font-size: 0.95rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 1.25rem;
}

.footer-link-item {
  color: #94a3b8;
  text-decoration: none;
  font-size: 0.9rem;
  display: block;
  margin-bottom: 0.65rem;
  transition: color 0.2s;
}

.footer-link-item:hover {
  color: #38bdf8;
}
</style>

<!-- =========================================================================
     1. NAVIGATION BAR
     ========================================================================= -->
<nav class="saas-navbar py-2" id="mainSaasNav">
  <div class="container-fluid px-3 px-lg-4 px-xxl-5 d-flex align-items-center justify-content-between">
    <!-- Brand -->
    <a href="<?= e(url('/')) ?>" class="d-flex align-items-center gap-2 text-decoration-none saas-brand-wrap">
      <div class="saas-brand-icon">
        <i class="bi bi-mortarboard-fill"></i>
      </div>
      <div>
        <span class="fw-bold fs-5 text-dark font-heading"><?= e($platformName) ?></span>
        <span class="badge text-bg-light border text-muted ms-1 small" style="font-size:10px;">SaaS</span>
      </div>
    </a>

    <!-- Nav Items (Desktop) -->
    <div class="d-none d-lg-flex align-items-center gap-1">
      <a href="#home" class="nav-link-custom"><i class="bi bi-house-door"></i><span>Home</span></a>
      <a href="#features" class="nav-link-custom"><i class="bi bi-stars"></i><span>Features</span></a>
      <a href="#solutions" class="nav-link-custom"><i class="bi bi-mortarboard"></i><span>Solutions</span></a>
      <a href="#how-it-works" class="nav-link-custom"><i class="bi bi-diagram-3"></i><span>How It Works</span></a>
      <a href="#pricing" class="nav-link-custom"><i class="bi bi-tags"></i><span>Pricing</span></a>
      <a href="#security" class="nav-link-custom"><i class="bi bi-shield-check"></i><span>Security</span></a>
      <a href="#faq" class="nav-link-custom"><i class="bi bi-question-circle"></i><span>FAQ</span></a>
      <a href="#contact" class="nav-link-custom"><i class="bi bi-headset"></i><span>Contact</span></a>
    </div>

    <!-- Actions (Desktop & Mobile) -->
    <div class="d-flex align-items-center gap-2 flex-shrink-0">
      <a href="<?= e(url('login')) ?>" class="btn btn-saas-outline d-none d-sm-inline-flex">
        <i class="bi bi-box-arrow-in-right"></i>
        <span>Log In</span>
      </a>
      <a href="<?= e(url('register')) ?>" class="btn btn-saas-primary">
        <span class="d-none d-xxl-inline">Register Your School</span>
        <span class="d-inline d-xxl-none">Register</span>
        <i class="bi bi-arrow-right-short fs-5"></i>
      </a>
      <!-- Mobile Hamburger Toggle -->
      <button class="btn btn-light d-lg-none border ms-1 rounded-3 p-2 d-flex align-items-center justify-content-center" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuOffcanvas" aria-controls="mobileMenuOffcanvas" aria-label="Toggle navigation" style="width: 40px; height: 40px;">
        <i class="bi bi-list fs-4"></i>
      </button>
    </div>
  </div>
</nav>

<!-- Mobile Offcanvas Drawer -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="mobileMenuOffcanvas" aria-labelledby="mobileMenuLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
      <div class="saas-brand-icon" style="width:34px; height:34px; font-size:16px;">
        <i class="bi bi-mortarboard-fill"></i>
      </div>
      <h5 class="offcanvas-title fw-bold font-heading mb-0" id="mobileMenuLabel">
        <?= e($platformName) ?>
      </h5>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body d-flex flex-column justify-content-between p-4">
    <div class="d-flex flex-column gap-2 fs-6">
      <a href="#home" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-house-door me-2 text-primary"></i>Home</a>
      <a href="#features" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-stars me-2 text-primary"></i>Features & Modules</a>
      <a href="#solutions" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-mortarboard me-2 text-primary"></i>Stakeholder Solutions</a>
      <a href="#how-it-works" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-diagram-3 me-2 text-primary"></i>How It Works</a>
      <a href="#pricing" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-tags me-2 text-primary"></i>Subscription Pricing</a>
      <a href="#security" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-shield-check me-2 text-primary"></i>Enterprise Security</a>
      <a href="#faq" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-question-circle me-2 text-primary"></i>FAQ</a>
      <a href="#contact" class="nav-link-custom py-2 px-3 rounded-3" data-bs-dismiss="offcanvas"><i class="bi bi-headset me-2 text-primary"></i>Contact & Support</a>
    </div>
    <div class="pt-4 border-top d-flex flex-column gap-2">
      <a href="<?= e(url('login')) ?>" class="btn btn-outline-dark w-100 py-2.5 fw-bold rounded-pill d-flex align-items-center justify-content-center gap-2">
        <i class="bi bi-box-arrow-in-right"></i> Sign In to Dashboard
      </a>
      <a href="<?= e(url('register')) ?>" class="btn btn-saas-primary w-100 py-2.5 justify-content-center">
        <span>Register Your School</span>
        <i class="bi bi-arrow-right-short fs-5"></i>
      </a>
    </div>
  </div>
</div>

<!-- =========================================================================
     2. HERO SECTION
     ========================================================================= -->
<section id="home" class="saas-hero">
  <div class="hero-mesh-grid"></div>
  <div class="hero-glow-blob"></div>

  <div class="container position-relative" style="z-index: 10;">
    <div class="row align-items-center g-5">
      <!-- Left Hero Text -->
      <div class="col-lg-6">
        <div class="hero-badge">
          <i class="bi bi-shield-check"></i>
          <span>Multi-Tenant School Management Platform</span>
          <span style="opacity:0.4;">•</span>
          <span class="text-white">Montessori to Matric</span>
        </div>

        <h1 class="hero-title-main">
          One Smart Platform to Manage Your Entire School.
        </h1>

        <p class="hero-description">
          Streamline admissions, class allocations, biometric attendance, examination rank tabulations, double-entry fees, and HR payroll. Purpose-built for <strong>Montessori, Primary, Middle, and Matric-level</strong> private and network institutions.
        </p>

        <!-- CTA Buttons -->
        <div class="d-flex flex-wrap align-items-center gap-3 mb-4">
          <a href="<?= e(url('register')) ?>" class="btn btn-saas-primary fs-6 px-4 py-3">
            <span>Start Your 30-Day Free Trial</span>
            <i class="bi bi-arrow-right-short fs-4"></i>
          </a>
          <a href="#features" class="btn btn-outline-light rounded-pill px-4 py-3 fw-semibold fs-6">
            <i class="bi bi-grid-3x3-gap-fill me-1"></i> Explore Features
          </a>
        </div>

        <!-- Trust Features Checklist -->
        <div class="d-flex flex-wrap gap-4 text-white-50 small fw-semibold pt-2">
          <div class="d-flex align-items-center gap-1.5 text-white">
            <i class="bi bi-check-circle-fill text-info"></i> 30-Day Free Trial
          </div>
          <div class="d-flex align-items-center gap-1.5 text-white">
            <i class="bi bi-check-circle-fill text-info"></i> No Credit Card Required
          </div>
          <div class="d-flex align-items-center gap-1.5 text-white">
            <i class="bi bi-check-circle-fill text-info"></i> Strict Tenant Isolation
          </div>
        </div>
      </div>

      <!-- Right Dashboard Interactive Live Mockup -->
      <div class="col-lg-6">
        <div class="mockup-window">
          <div class="mockup-topbar">
            <div class="mockup-dots">
              <span class="mockup-dot r"></span>
              <span class="mockup-dot y"></span>
              <span class="mockup-dot g"></span>
            </div>
            <div class="small text-white-50 font-monospace" style="font-size:11px;">
              <i class="bi bi-lock-fill text-success me-1"></i> portal.school-erp.cloud/dashboard
            </div>
            <span class="badge bg-success-subtle text-success rounded-pill fw-bold" style="font-size:10px;">LIVE WORKSPACE</span>
          </div>

          <div class="p-4" style="background:#091222;">
            <!-- Mockup Header Stats -->
            <div class="row g-2 mb-3">
              <div class="col-6 col-md-3">
                <div class="p-2.5 rounded-3 border" style="background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08) !important;">
                  <div class="text-white-50 small" style="font-size:11px;">Students</div>
                  <div class="h5 fw-bold text-white mb-0">842</div>
                  <div class="text-success small" style="font-size:10px;">+18% term intake</div>
                </div>
              </div>
              <div class="col-6 col-md-3">
                <div class="p-2.5 rounded-3 border" style="background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08) !important;">
                  <div class="text-white-50 small" style="font-size:11px;">Attendance</div>
                  <div class="h5 fw-bold text-info mb-0">98.4%</div>
                  <div class="text-white-50 small" style="font-size:10px;">Biometric sync</div>
                </div>
              </div>
              <div class="col-6 col-md-3">
                <div class="p-2.5 rounded-3 border" style="background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08) !important;">
                  <div class="text-white-50 small" style="font-size:11px;">Fee Vouchers</div>
                  <div class="h5 fw-bold text-white mb-0">Rs. 1.2M</div>
                  <div class="text-success small" style="font-size:10px;">Row-locked receipts</div>
                </div>
              </div>
              <div class="col-6 col-md-3">
                <div class="p-2.5 rounded-3 border" style="background:rgba(255,255,255,0.03); border-color:rgba(255,255,255,0.08) !important;">
                  <div class="text-white-50 small" style="font-size:11px;">AI Alert Risk</div>
                  <div class="h5 fw-bold text-warning mb-0">3 Alerts</div>
                  <div class="text-warning small" style="font-size:10px;">Retention tensor</div>
                </div>
              </div>
            </div>

            <!-- Mockup Active Academic Panel -->
            <div class="p-3 rounded-3 border mb-3" style="background:rgba(255,255,255,0.02); border-color:rgba(255,255,255,0.08) !important;">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="fw-bold text-white small"><i class="bi bi-clock-history text-info me-1.5"></i> Academic Today · Matric & Primary Sections</div>
                <span class="badge bg-primary text-white" style="font-size:10px;">Term 1 Final Session</span>
              </div>
              <div class="d-flex flex-column gap-2">
                <div class="d-flex align-items-center justify-content-between p-2 rounded" style="background:rgba(255,255,255,0.03);">
                  <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-dark border text-info">Class 10-A</span>
                    <span class="text-white small">Mathematics · Midterm Grading Tabulation</span>
                  </div>
                  <span class="text-success small fw-bold">✓ 38/38 Marks Tabulated</span>
                </div>
                <div class="d-flex align-items-center justify-content-between p-2 rounded" style="background:rgba(255,255,255,0.03);">
                  <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-dark border text-info">Class 5-Green</span>
                    <span class="text-white small">Biometric Morning Attendance Sync</span>
                  </div>
                  <span class="text-info small fw-bold">100% Present</span>
                </div>
              </div>
            </div>

            <!-- Mockup Bottom Footer -->
            <div class="d-flex justify-content-between align-items-center pt-2 text-white-50 small" style="font-size:11.5px;">
              <span><i class="bi bi-shield-fill-check text-success me-1"></i> Isolated Database Tenant Guard</span>
              <span class="text-info fw-semibold">Next-Gen SaaS Engine &bull; Pure PHP 8.2+</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     3. FEATURES & ACTUAL CAPABILITIES
     ========================================================================= -->
<section id="features" class="py-5 bg-white">
  <div class="container py-4">
    <div class="text-center mb-5">
      <div class="section-tag"><i class="bi bi-stars"></i> System Capabilities</div>
      <h2 class="section-heading">Everything You Need to Run Your School</h2>
      <p class="section-lead">
        Comprehensive enterprise modules verified in active production. Fully integrated with zero manual patchwork.
      </p>
    </div>

    <div class="row g-4">
      <!-- Feature 1 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-person-vcard-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Student & Admission 360°</h3>
          <p class="feature-desc">
            End-to-end online admissions, auto-generated student codes, dynamic profiles, sibling/family tree grouping, and one-click session promotions.
          </p>
        </div>
      </div>

      <!-- Feature 2 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-diagram-3-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Classes, Sections & Subjects</h3>
          <p class="feature-desc">
            Organize Montessori to Matric classes, section quotas, multi-term academic sessions, and core vs elective subject curriculums.
          </p>
        </div>
      </div>

      <!-- Feature 3 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-fingerprint"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Biometric Student & Staff Attendance</h3>
          <p class="feature-desc">
            Real-time biometric attendance machine synchronization, instant absence triggers, manual teacher registers, and monthly attendance reports.
          </p>
        </div>
      </div>

      <!-- Feature 4 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-award-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Exams & Competition Grading</h3>
          <p class="feature-desc">
            Standard Competition Ranking (1224), customizable grading scales, automated marks tabulation, and beautiful printable report cards.
          </p>
        </div>
      </div>

      <!-- Feature 5 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-receipt-cutoff"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Double-Entry Fee Billing & Ledgers</h3>
          <p class="feature-desc">
            Automated recurring monthly fee vouchers, row-locked receipts with concurrency protection, running balance ledgers, and defaulter tracking.
          </p>
        </div>
      </div>

      <!-- Feature 6 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-briefcase-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Staff HR & Automated Payroll</h3>
          <p class="feature-desc">
            Employee profiles, digital multi-tier leave request workflows, automated attendance penalty salary deductions, and itemized pay slips.
          </p>
        </div>
      </div>

      <!-- Feature 7 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-calendar-week-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Clash-Free Timetables & Homework</h3>
          <p class="feature-desc">
            Automated scheduling algorithms preventing teacher double-booking and room clashes, with a digital homework desk for file submissions.
          </p>
        </div>
      </div>

      <!-- Feature 8 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-bus-front-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Campus Logistics: Transport & Library</h3>
          <p class="feature-desc">
            Barcode/ISBN book circulation with automated overdue fines, vehicle fleet routing, student stop allocations, and hostel bed management.
          </p>
        </div>
      </div>

      <!-- Feature 9 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-patch-check-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Certificates & Noticeboard</h3>
          <p class="feature-desc">
            Instant generation of verified Transfer Certificates (TC) and Character Certificates, with targeted campus broadcast announcements.
          </p>
        </div>
      </div>

      <!-- Feature 10 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-phone-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">Parent & Student Dedicated Portals</h3>
          <p class="feature-desc">
            Mobile-first responsive access for parents and students to monitor live attendance, fee vouchers, exam dates, and teacher announcements.
          </p>
        </div>
      </div>

      <!-- Feature 11 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box"><i class="bi bi-cpu-fill"></i></div>
            <span class="badge-live">✓ AVAILABLE</span>
          </div>
          <h3 class="feature-title">AI Retention & Predictive Analytics</h3>
          <p class="feature-desc">
            10-dimensional machine learning retention tensor calculating student academic trajectory, attendance stability, and dropout risk alerts.
          </p>
        </div>
      </div>

      <!-- Feature 12 -->
      <div class="col-md-6 col-lg-4">
        <div class="feature-card" style="border-style:dashed; background:#fafafa;">
          <div class="d-flex justify-content-between align-items-start">
            <div class="feature-icon-box text-muted" style="background:#f1f5f9;"><i class="bi bi-whatsapp"></i></div>
            <span class="badge bg-secondary-subtle text-secondary small fw-bold">CONFIGURABLE GATEWAY</span>
          </div>
          <h3 class="feature-title">Async WhatsApp & SMS Dispatcher</h3>
          <p class="feature-desc">
            High-throughput background queue engine to dispatch automated fee reminders and emergency school announcements via SMS & WhatsApp APIs.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     4. SOLUTIONS BY STAKEHOLDER
     ========================================================================= -->
<section id="solutions" class="py-5 bg-light">
  <div class="container py-4">
    <div class="text-center mb-5">
      <div class="section-tag"><i class="bi bi-people-fill"></i> Tailored Workspaces</div>
      <h2 class="section-heading">Built for Every School Stakeholder</h2>
      <p class="section-lead">
        Role-specific permissions and dedicated interfaces designed to empower administrators, faculty, parents, and students.
      </p>

      <!-- Stakeholder Nav Switcher -->
      <div class="d-flex flex-wrap justify-content-center gap-2 mt-4" id="stakeholderNav">
        <button class="stakeholder-nav-pill active" onclick="switchStakeholder('owners', this)">School Owners</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('principals', this)">Principals</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('teachers', this)">Teachers</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('accountants', this)">Accountants</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('hr', this)">HR Staff</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('parents', this)">Parents</button>
        <button class="stakeholder-nav-pill" onclick="switchStakeholder('students', this)">Students</button>
      </div>
    </div>

    <!-- Stakeholder Content Cards -->
    <div class="stakeholder-card mt-4" id="stakeholderContent">
      <div class="row align-items-center g-4">
        <div class="col-lg-6">
          <span class="badge bg-primary text-white mb-2" id="stkBadge">Executive Control</span>
          <h3 class="h2 fw-bold text-dark font-heading mb-3" id="stkTitle">School Owners & Trustees</h3>
          <p class="text-muted fs-6 mb-4" id="stkDesc">
            Gain complete institutional clarity with real-time financial transparency, multi-branch performance metrics, fee collection summaries, and audit logs. Eliminate revenue leakage and monitor student growth trends from any device.
          </p>
          <ul class="list-unstyled d-flex flex-column gap-2 text-dark" id="stkList">
            <li><i class="bi bi-check-circle-fill text-success me-2"></i> Real-time fee collection ledgers and defaulter tracking</li>
            <li><i class="bi bi-check-circle-fill text-success me-2"></i> Single login to supervise multiple school campuses</li>
            <li><i class="bi bi-check-circle-fill text-success me-2"></i> Immutable transaction audit trails with row-level locks</li>
          </ul>
        </div>
        <div class="col-lg-6">
          <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg, #070e1b 0%, #0f172a 100%);">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3 border-secondary">
              <span class="fw-bold" id="stkCardHeader">Owner Executive Dashboard</span>
              <span class="badge text-bg-info text-dark">Live Metrics</span>
            </div>
            <div class="row g-3">
              <div class="col-6">
                <div class="small text-white-50">Total Collections</div>
                <div class="h4 fw-bold text-white mb-0" id="stkStat1">Rs. 2,450,000</div>
              </div>
              <div class="col-6">
                <div class="small text-white-50">Enrolled Students</div>
                <div class="h4 fw-bold text-info mb-0" id="stkStat2">842 Students</div>
              </div>
              <div class="col-6">
                <div class="small text-white-50">Operational Branches</div>
                <div class="h4 fw-bold text-white mb-0" id="stkStat3">2 Campuses</div>
              </div>
              <div class="col-6">
                <div class="small text-white-50">Faculty Retention</div>
                <div class="h4 fw-bold text-success mb-0" id="stkStat4">98.2% Active</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     5. HOW IT WORKS (5 STEPS)
     ========================================================================= -->
<section id="how-it-works" class="py-5 bg-white">
  <div class="container py-4">
    <div class="text-center mb-5">
      <div class="section-tag"><i class="bi bi-arrow-repeat"></i> Simple Onboarding</div>
      <h2 class="section-heading">How It Works</h2>
      <p class="section-lead">Get your school up and running in 5 simple, guided steps.</p>
    </div>

    <div class="row g-4 mt-2">
      <!-- Step 1 -->
      <div class="col-md-6 col-lg">
        <div class="step-item-card">
          <div class="step-num-badge">1</div>
          <h4 class="fw-bold mt-2 mb-2 font-heading">Register School</h4>
          <p class="text-muted small mb-0">Fill out our 5-step registration wizard with basic school identity, location, and logo.</p>
        </div>
      </div>

      <!-- Step 2 -->
      <div class="col-md-6 col-lg">
        <div class="step-item-card">
          <div class="step-num-badge">2</div>
          <h4 class="fw-bold mt-2 mb-2 font-heading">Set Structure</h4>
          <p class="text-muted small mb-0">Select your education levels (Montessori to Matric) and examination board.</p>
        </div>
      </div>

      <!-- Step 3 -->
      <div class="col-md-6 col-lg">
        <div class="step-item-card">
          <div class="step-num-badge">3</div>
          <h4 class="fw-bold mt-2 mb-2 font-heading">Start 30-Day Trial</h4>
          <p class="text-muted small mb-0">Instant activation with 30 days of full, unconstrained access. No credit card required.</p>
        </div>
      </div>

      <!-- Step 4 -->
      <div class="col-md-6 col-lg">
        <div class="step-item-card">
          <div class="step-num-badge">4</div>
          <h4 class="fw-bold mt-2 mb-2 font-heading">Invite Faculty</h4>
          <p class="text-muted small mb-0">Add teachers, accountants, and staff with auto-configured role permissions.</p>
        </div>
      </div>

      <!-- Step 5 -->
      <div class="col-md-6 col-lg">
        <div class="step-item-card">
          <div class="step-num-badge">5</div>
          <h4 class="fw-bold mt-2 mb-2 font-heading">Subscribe to Scale</h4>
          <p class="text-muted small mb-0">Seamlessly continue with transparent monthly plans that grow with your student count.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     6. PRICING SECTION (DATABASE-DRIVEN)
     ========================================================================= -->
<section id="pricing" class="py-5 bg-light">
  <div class="container py-4">
    <div class="text-center mb-5">
      <div class="section-tag"><i class="bi bi-tag-fill"></i> Subscription Plans</div>
      <h2 class="section-heading">Predictable, Transparent Pricing</h2>
      <p class="section-lead">
        Every plan includes a <strong>30-day full-feature free trial</strong>. No hidden charges or automatic lock-ins.
      </p>
    </div>

    <div class="row g-4 justify-content-center align-items-stretch">
      <?php if (empty($plansList)): ?>
        <div class="col-12 text-center text-muted py-5">
          <p>Subscription plans are loading or currently being configured.</p>
        </div>
      <?php else: ?>
        <?php foreach ($plansList as $idx => $p): 
          $isPopular = strtolower($p['slug'] ?? '') === 'professional' || strtolower($p['name']) === 'professional';
          $priceVal = number_format((float) ($p['monthly_price'] ?? 0), 2);
        ?>
          <div class="col-md-6 col-lg-4">
            <div class="pricing-card-saas <?= $isPopular ? 'popular' : '' ?>">
              <?php if ($isPopular): ?>
                <div class="popular-tag">MOST POPULAR</div>
              <?php endif; ?>

              <!-- Trial Badge -->
              <div class="trial-banner-pill">
                <i class="bi bi-clock-history"></i> 30-Day Free Trial Included
              </div>

              <h3 class="h4 fw-bold font-heading text-dark"><?= e($p['name']) ?></h3>
              <p class="text-muted small mb-3"><?= e($p['description'] ?? 'Complete school operations management') ?></p>

              <div class="d-flex align-items-baseline gap-1 my-3">
                <span class="fs-2 fw-bold text-dark font-heading"><?= e($currPrefix . $priceVal) ?></span>
                <span class="text-muted fw-semibold">/ month</span>
              </div>

              <hr class="my-4">

              <!-- Included Limits & Features -->
              <div class="fw-bold text-dark small text-uppercase mb-3" style="letter-spacing:0.04em;">Plan Capacity & Features:</div>
              <ul class="list-unstyled d-flex flex-column gap-2 text-dark small mb-4">
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Up to <?= e((string)($p['student_limit'] ?? 'Unlimited')) ?></strong> Enrolled Students</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Up to <?= e((string)($p['teacher_limit'] ?? 'Unlimited')) ?></strong> Faculty Teachers</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Up to <?= e((string)($p['employee_limit'] ?? 'Unlimited')) ?></strong> Staff Members</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> <?= e((string)($p['storage_limit_mb'] ?? 1024)) ?> MB Secure Cloud Storage</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Montessori to Matric Class Management</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Biometric Attendance & Exam Tabulation</li>
                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Double-Entry Fees & Defaulters Tracking</li>
                <?php if ($isPopular || strtolower($p['slug'] ?? '') === 'enterprise'): ?>
                  <li><i class="bi bi-check-circle-fill text-success me-2"></i> Staff HR & Automated Payroll Slip Engine</li>
                  <li><i class="bi bi-check-circle-fill text-success me-2"></i> AI Retention Tensor & Dropout Risk Alerts</li>
                <?php endif; ?>
                <?php if (strtolower($p['slug'] ?? '') === 'enterprise'): ?>
                  <li><i class="bi bi-check-circle-fill text-success me-2"></i> Dedicated Database Architecture & Custom Domain</li>
                  <li><i class="bi bi-check-circle-fill text-success me-2"></i> Priority 24/7 Telephone & SLA Support</li>
                <?php endif; ?>
              </ul>

              <a href="<?= e(url('register?plan=' . $p['id'])) ?>" class="btn <?= $isPopular ? 'btn-saas-primary' : 'btn-saas-outline' ?> w-100 py-2.5 justify-content-center text-center mt-auto">
                <span>Start 30-Day Free Trial</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- =========================================================================
     7. TRUST & ENTERPRISE SECURITY
     ========================================================================= -->
<section id="security" class="py-5 bg-white">
  <div class="container py-4">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <div class="section-tag"><i class="bi bi-shield-lock-fill"></i> Data Integrity</div>
        <h2 class="section-heading">Enterprise-Grade Security & Isolation</h2>
        <p class="text-muted fs-6 mb-4">
          Built with an uncompromising commitment to institutional data security, student privacy, and financial audit integrity.
        </p>

        <div class="d-flex flex-column gap-3">
          <div class="d-flex align-items-start gap-3">
            <div class="feature-icon-box flex-shrink-0" style="width:44px;height:44px;font-size:1.1rem;"><i class="bi bi-database-fill-lock"></i></div>
            <div>
              <h4 class="h6 fw-bold mb-1 text-dark">Strict Tenant Isolation Boundary</h4>
              <p class="text-muted small mb-0">Every database query is bound to the verified <code>school_id</code> session context, preventing IDOR and cross-school data leaks.</p>
            </div>
          </div>
          <div class="d-flex align-items-start gap-3">
            <div class="feature-icon-box flex-shrink-0" style="width:44px;height:44px;font-size:1.1rem;"><i class="bi bi-file-earmark-lock2-fill"></i></div>
            <div>
              <h4 class="h6 fw-bold mb-1 text-dark">Encrypted Automated Backups</h4>
              <p class="text-muted small mb-0">Daily database snapshots with military-grade AES-256 encryption and isolated offsite disaster recovery.</p>
            </div>
          </div>
          <div class="d-flex align-items-start gap-3">
            <div class="feature-icon-box flex-shrink-0" style="width:44px;height:44px;font-size:1.1rem;"><i class="bi bi-journal-text"></i></div>
            <div>
              <h4 class="h6 fw-bold mb-1 text-dark">Row-Level Locks & Immutable Audit Logs</h4>
              <p class="text-muted small mb-0">Financial collections utilize <code>SELECT ... FOR UPDATE</code> concurrency protection with permanent system audit logs.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="p-4 p-md-5 rounded-4 border bg-light text-center">
          <div class="display-3 text-primary mb-3"><i class="bi bi-patch-check-fill"></i></div>
          <h3 class="h4 fw-bold text-dark font-heading mb-2">99.9% Uptime Architecture</h3>
          <p class="text-muted small max-w-75 mx-auto mb-4">
            Engineered on high-performance PHP 8.2+ and optimized MySQL 8 with connection pooling, automated query caching, and asynchronous workers.
          </p>
          <div class="d-inline-flex align-items-center gap-2 px-3 py-1.5 rounded-pill bg-success-subtle text-success fw-bold small">
            <span class="status-dot bg-success" style="width:8px;height:8px;border-radius:50%;display:inline-block;"></span>
            All Platform Clusters Fully Operational
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     8. FREQUENTLY ASKED QUESTIONS (FAQ)
     ========================================================================= -->
<section id="faq" class="py-5 bg-light">
  <div class="container py-4">
    <div class="text-center mb-5">
      <div class="section-tag"><i class="bi bi-question-circle-fill"></i> Common Inquiries</div>
      <h2 class="section-heading">Frequently Asked Questions</h2>
      <p class="section-lead">Got questions? We have clear, straightforward answers.</p>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="accordion saas-faq" id="saasFaqAccordion">
          <!-- FAQ 1 -->
          <div class="accordion-item">
            <h3 class="accordion-header">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                How does the 30-day free trial work?
              </button>
            </h3>
            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#saasFaqAccordion">
              <div class="accordion-body text-muted">
                When you register your school, you immediately receive 30 days of full, unrestricted access to all features in your chosen plan. You do not need to enter a credit card, and you will not be billed automatically.
              </div>
            </div>
          </div>

          <!-- FAQ 2 -->
          <div class="accordion-item">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                What education levels does School Portal support?
              </button>
            </h3>
            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#saasFaqAccordion">
              <div class="accordion-body text-muted">
                School Portal is specifically engineered to handle the full academic spectrum: from Montessori and Early Childhood (Playgroup, Nursery, Prep) to Primary (Class 1-5), Middle (Class 6-8), and Matriculation (Class 9-10). It supports local boards (Federal, Punjab, Sindh, KPK) and Cambridge/O-Levels.
              </div>
            </div>
          </div>

          <!-- FAQ 3 -->
          <div class="accordion-item">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                Is our school's data safe and separate from other schools?
              </button>
            </h3>
            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#saasFaqAccordion">
              <div class="accordion-body text-muted">
                Yes, absolutely. Our multi-tenant architecture implements strict database isolation boundaries. Every single query enforces tenant verification, preventing unauthorized access or data leakage between schools.
              </div>
            </div>
          </div>

          <!-- FAQ 4 -->
          <div class="accordion-item">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                Can we import our existing student and staff records?
              </button>
            </h3>
            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#saasFaqAccordion">
              <div class="accordion-body text-muted">
                Yes. The platform provides structured CSV/Excel import tools to bulk upload student profiles, family mapping, class lists, and employee records in minutes.
              </div>
            </div>
          </div>

          <!-- FAQ 5 -->
          <div class="accordion-item">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                Can we manage multiple branches under one organization?
              </button>
            </h3>
            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#saasFaqAccordion">
              <div class="accordion-body text-muted">
                Yes. Our multi-campus architecture enables school owners to oversee multiple school branches with centralized reporting, separate campus ledgers, and isolated staff permissions.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     9. CONTACT & DEMO REQUEST
     ========================================================================= -->
<section id="contact" class="py-5 bg-white border-top">
  <div class="container py-4">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <div class="section-tag"><i class="bi bi-chat-dots-fill"></i> Get in Touch</div>
        <h2 class="section-heading">Have Questions or Need a Custom Demo?</h2>
        <p class="text-muted fs-6 mb-4">
          Our education technology consultants are ready to assist with institutional setup, data migration, and campus network onboarding.
        </p>

        <div class="d-flex flex-column gap-3 text-dark">
          <div class="d-flex align-items-center gap-3">
            <div class="feature-icon-box mb-0" style="width:42px;height:42px;font-size:1.1rem;"><i class="bi bi-envelope-fill"></i></div>
            <div>
              <div class="text-muted small">Email Inquiries</div>
              <div class="fw-bold"><?= e(platform_setting('support_email', 'support@platform.local')) ?></div>
            </div>
          </div>
          <div class="d-flex align-items-center gap-3">
            <div class="feature-icon-box mb-0" style="width:42px;height:42px;font-size:1.1rem;"><i class="bi bi-telephone-fill"></i></div>
            <div>
              <div class="text-muted small">Institutional Helpline</div>
              <div class="fw-bold">+92 (042) 3587-1234</div>
            </div>
          </div>
          <div class="d-flex align-items-center gap-3">
            <div class="feature-icon-box mb-0" style="width:42px;height:42px;font-size:1.1rem;"><i class="bi bi-geo-alt-fill"></i></div>
            <div>
              <div class="text-muted small">Campus Onboarding Desk</div>
              <div class="fw-bold">Pakistan Cloud Operations Centre</div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="p-4 p-md-5 rounded-4 border bg-light">
          <h4 class="fw-bold font-heading text-dark mb-3">Request Institutional Consultation</h4>
          <form onsubmit="event.preventDefault(); document.getElementById('contactSuccessMsg').classList.remove('d-none'); this.reset();">
            <div class="mb-3">
              <label class="form-label small text-muted mb-1">Your Name</label>
              <input type="text" required class="form-control" placeholder="Principal / Owner Name">
            </div>
            <div class="mb-3">
              <label class="form-label small text-muted mb-1">School Name</label>
              <input type="text" required class="form-control" placeholder="Official School Name">
            </div>
            <div class="row g-2 mb-3">
              <div class="col-md-6">
                <label class="form-label small text-muted mb-1">Email</label>
                <input type="email" required class="form-control" placeholder="contact@school.edu">
              </div>
              <div class="col-md-6">
                <label class="form-label small text-muted mb-1">Phone</label>
                <input type="tel" required class="form-control" placeholder="0300-1234567">
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label small text-muted mb-1">Message / Requirements</label>
              <textarea class="form-control" rows="3" placeholder="Tell us about your campus size, education levels, or demo requirements..."></textarea>
            </div>
            <button type="submit" class="btn btn-saas-primary w-100 py-2.5 justify-content-center">
              <span>Send Consultation Request</span>
              <i class="bi bi-send-fill ms-1"></i>
            </button>
            <div id="contactSuccessMsg" class="d-none alert alert-success mt-3 small mb-0">
              <i class="bi bi-check-circle-fill me-1"></i> Thank you! Our institutional consultant will contact you within 24 hours.
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================================
     10. FOOTER
     ========================================================================= -->
<footer class="saas-footer">
  <div class="container">
    <div class="row g-4 g-lg-5 mb-5">
      <!-- Col 1: Brand & Overview -->
      <div class="col-lg-4 col-md-6">
        <div class="d-flex align-items-center gap-2 mb-3 text-white font-heading fs-4">
          <div style="width:36px;height:36px;border-radius:10px;background:#0284c7;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;">
            <i class="bi bi-mortarboard-fill"></i>
          </div>
          <span><?= e($platformName) ?></span>
        </div>
        <p class="small lh-lg mb-4 text-secondary">
          The next-generation multi-tenant cloud ERP for schools spanning Montessori, Primary, Middle, and Matric levels. Empowering administrators with automated billing, attendance, grading, and portals.
        </p>
        <div class="d-flex align-items-center gap-2">
          <a href="<?= e(url('register')) ?>" class="btn btn-sm btn-saas-primary">Start 30-Day Free Trial</a>
          <a href="<?= e(url('login')) ?>" class="btn btn-sm btn-outline-secondary text-white">Log In</a>
        </div>
      </div>

      <!-- Col 2: Core Platform Modules -->
      <div class="col-lg-3 col-md-3 col-6">
        <div class="footer-heading-col">Core Modules</div>
        <a href="#features" class="footer-link-item">Student Admissions 360°</a>
        <a href="#features" class="footer-link-item">Biometric Attendance</a>
        <a href="#features" class="footer-link-item">Double-Entry Fee Billing</a>
        <a href="#features" class="footer-link-item">Competition Grade Tabulation</a>
        <a href="#features" class="footer-link-item">Staff HR & Payroll Engine</a>
        <a href="#features" class="footer-link-item">Clash-Free Timetables</a>
        <a href="#features" class="footer-link-item">Transport & Library System</a>
      </div>

      <!-- Col 3: Dedicated Portals -->
      <div class="col-lg-3 col-md-3 col-6">
        <div class="footer-heading-col">Stakeholder Portals</div>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">School Admin Console</a>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">Faculty & Teacher Workspace</a>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">Student Academic Desk</a>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">Parent Communications Portal</a>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">Finance & Accounts Office</a>
        <a href="<?= e(url('login')) ?>" class="footer-link-item">Platform Super Admin</a>
      </div>

      <!-- Col 4: Platform Policies -->
      <div class="col-lg-2 col-md-12">
        <div class="footer-heading-col">Platform & Legal</div>
        <a href="#pricing" class="footer-link-item">Subscription Pricing</a>
        <a href="#security" class="footer-link-item">Data Security & Isolation</a>
        <a href="#faq" class="footer-link-item">Free Trial Conditions</a>
        <a href="#contact" class="footer-link-item">Privacy Policy & SLA</a>
        <a href="#contact" class="footer-link-item">Institutional Support</a>
      </div>
    </div>

    <hr style="border-color: rgba(255, 255, 255, 0.1);">

    <div class="d-flex flex-column flex-md-row align-items-center justify-content-between pt-3 gap-2 small text-secondary">
      <div>
        &copy; <?= date('Y') ?> <?= e($platformName) ?> SaaS. All rights reserved. Built with pure PHP 8.2+ MVC & MySQL 8.
      </div>
      <div class="d-flex align-items-center gap-3">
        <span class="text-success"><i class="bi bi-circle-fill me-1" style="font-size:8px;"></i> Security Firewall Active</span>
        <span>&bull;</span>
        <span>AES-256 Cloud Vault Backup</span>
      </div>
    </div>
  </div>
</footer>

<script>
// Stakeholder Switcher Data
const stakeholderData = {
  owners: {
    badge: 'Executive Oversight',
    title: 'School Owners & Trustees',
    desc: 'Gain complete institutional clarity with real-time financial transparency, multi-branch performance metrics, fee collection summaries, and audit logs. Eliminate revenue leakage and monitor student growth trends from any device.',
    list: [
      'Real-time fee collection ledgers and defaulter tracking',
      'Single login to supervise multiple school campuses',
      'Immutable transaction audit trails with row-level locks'
    ],
    cardHeader: 'Owner Executive Dashboard',
    stat1: 'Rs. 2,450,000',
    stat2: '842 Students',
    stat3: '2 Campuses',
    stat4: '98.2% Active'
  },
  principals: {
    badge: 'Academic Leadership',
    title: 'Principals & Headmasters',
    desc: 'Supervise daily teacher attendance, classroom period schedules, curriculum completion milestones, and examination results. Instant access to student behavioral records and academic performance metrics.',
    list: [
      'Daily staff and student attendance monitoring',
      'Clash-free period timetable generator',
      'One-click report card approval and printing'
    ],
    cardHeader: 'Principal Academic Dashboard',
    stat1: '98.4%',
    stat2: '32 Sections',
    stat3: '100% On-Time',
    stat4: '0 Clashes'
  },
  teachers: {
    badge: 'Faculty Workspace',
    title: 'Teachers & Educators',
    desc: 'Eliminate tedious paperwork with an automated gradebook, 60-second digital attendance marking, online homework assignments, and instant exam marks tabulation with automated rank calculations.',
    list: [
      'Quick biometric or tap-to-mark daily attendance',
      'Digital homework assignment desk with file attachments',
      'Automated grade tabulation with standard competition ranking'
    ],
    cardHeader: 'Faculty Class Desk',
    stat1: '38/38 Marks',
    stat2: '100% Graded',
    stat3: '5 Assignments',
    stat4: 'Grade 10-A'
  },
  accountants: {
    badge: 'Finance & Accounts',
    title: 'Accountants & Bursars',
    desc: 'Execute flawless financial operations with automated monthly fee vouchers, double-entry ledger accounts, running student balances, bank payment reconciliations, and itemized receipt printing.',
    list: [
      'One-click monthly fee invoice batch generation',
      'Row-locked receipts preventing double-entry cash conflicts',
      'Defaulter registers with automated late fine computation'
    ],
    cardHeader: 'Finance & Accounts Desk',
    stat1: 'Rs. 1,280,000',
    stat2: '94% Collected',
    stat3: '0 Reconcile Errors',
    stat4: '48 Vouchers'
  },
  hr: {
    badge: 'Human Resources',
    title: 'HR & Administrative Staff',
    desc: 'Effortlessly manage faculty profiles, contract records, multi-tier digital leave approvals, and one-click monthly payroll generation with automatic attendance penalty calculations.',
    list: [
      'Automated monthly salary computation with deduction rules',
      'Staff leave application and substitute assignment workflow',
      'Complete digitized employee documents and tenure history'
    ],
    cardHeader: 'HR Staff & Payroll Desk',
    stat1: '48 Staff',
    stat2: 'Rs. 920,000',
    stat3: '2 Leaves Pending',
    stat4: '100% Processed'
  },
  parents: {
    badge: 'Family Portal',
    title: 'Parents & Guardians',
    desc: 'Stay intimately connected with your child’s educational journey. View monthly fee vouchers, download official receipts, track daily attendance, and review term examination report cards directly from your phone.',
    list: [
      'Instant SMS/WhatsApp alerts when child enters/exits school',
      'Online fee voucher view with instant payment verification',
      'Subject-wise examination marks and progress cards'
    ],
    cardHeader: 'Parent Family Desk',
    stat1: 'Fee Paid ✓',
    stat2: '100% Attendance',
    stat3: 'Term Rank: 2nd',
    stat4: 'Next PTM: Nov 5'
  },
  students: {
    badge: 'Student Workspace',
    title: 'Students & Learners',
    desc: 'A dedicated, distraction-free student portal to access the daily timetable, view homework assignments with submission deadlines, check exam schedules, and track term academic achievements.',
    list: [
      'Daily class timetable with classroom and teacher details',
      'Digital homework desk with submission status tracking',
      'Past report cards, examination schedules, and notices'
    ],
    cardHeader: 'Student Academic Dashboard',
    stat1: 'Class 10-A',
    stat2: '6 Subjects',
    stat3: '1 Pending Task',
    stat4: 'GPA: 3.92'
  }
};

function switchStakeholder(key, btn) {
  document.querySelectorAll('#stakeholderNav .stakeholder-nav-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const data = stakeholderData[key];
  if (!data) return;

  document.getElementById('stkBadge').innerText = data.badge;
  document.getElementById('stkTitle').innerText = data.title;
  document.getElementById('stkDesc').innerText = data.desc;
  
  let listHtml = '';
  data.list.forEach(item => {
    listHtml += `<li><i class="bi bi-check-circle-fill text-success me-2"></i> ${item}</li>`;
  });
  document.getElementById('stkList').innerHTML = listHtml;

  document.getElementById('stkCardHeader').innerText = data.cardHeader;
  document.getElementById('stkStat1').innerText = data.stat1;
  document.getElementById('stkStat2').innerText = data.stat2;
  document.getElementById('stkStat3').innerText = data.stat3;
  document.getElementById('stkStat4').innerText = data.stat4;
}

// Navbar scroll shadow & active link highlight
const nav = document.getElementById('mainSaasNav');
const navSections = document.querySelectorAll('section[id], div[id="home"]');
const desktopNavLinks = document.querySelectorAll('.saas-navbar .nav-link-custom');

window.addEventListener('scroll', function() {
  if (window.scrollY > 30) {
    nav.classList.add('scrolled');
  } else {
    nav.classList.remove('scrolled');
  }

  let currentSection = '';
  navSections.forEach(section => {
    const sectionTop = section.offsetTop - 140;
    if (window.pageYOffset >= sectionTop) {
      currentSection = section.getAttribute('id');
    }
  });

  desktopNavLinks.forEach(link => {
    link.classList.remove('active');
    if (currentSection && link.getAttribute('href') === '#' + currentSection) {
      link.classList.add('active');
    }
  });
});
</script>
