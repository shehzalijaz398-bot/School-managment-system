<?php
/**
 * Advanced Multi-Step School Registration Wizard
 * 5 Guided Steps:
 * 1. School Information
 * 2. Academic Structure
 * 3. School Administrator
 * 4. Plan Selection (with 30-Day Free Trial)
 * 5. Review & Submit
 */
$draft = $draft ?? [];
$selectedPlanId = (int) (old('plan_id') ?: ($draft['plan_id'] ?? ($_GET['plan'] ?? 1)));
$plansList = $plans ?? [];
$trialStart = $trialStartDate ?? date('M d, Y');
$trialEnd = $trialEndDate ?? date('M d, Y', strtotime('+30 days'));

$currSymbol = platform_setting('default_currency', 'PKR') === 'PKR' ? 'Rs. ' : (platform_setting('default_currency', 'USD') === 'USD' ? '$' : platform_setting('default_currency', 'PKR') . ' ');
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/23.0.4/css/intlTelInput.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet">

<style>
:root {
  --wizard-primary: #0284c7;
  --wizard-primary-hover: #0369a1;
  --wizard-dark: #070e1b;
  --wizard-border: #e2e8f0;
  --wizard-bg: #f8fafc;
}

body {
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  background-color: var(--wizard-bg);
  color: #1e293b;
  min-height: 100vh;
}

/* Wizard Container Shell */
.wizard-shell {
  max-width: 960px;
  margin: 3rem auto;
  padding: 0 1rem;
}

.wizard-card {
  background: #ffffff;
  border: 1px solid var(--wizard-border);
  border-radius: 20px;
  box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.05), 0 4px 10px -2px rgba(0, 0, 0, 0.02);
  padding: 2.5rem;
}

@media (max-width: 768px) {
  .wizard-card { padding: 1.5rem; }
  .wizard-shell { margin: 1.5rem auto; }
}

/* Progress Stepper Bar */
.stepper-track {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  margin-bottom: 2.5rem;
}

.stepper-progress-bg {
  position: absolute;
  top: 20px;
  left: 0;
  right: 0;
  height: 4px;
  background: #e2e8f0;
  z-index: 1;
}

.stepper-progress-fill {
  position: absolute;
  top: 20px;
  left: 0;
  height: 4px;
  background: linear-gradient(90deg, #0284c7 0%, #38bdf8 100%);
  z-index: 2;
  transition: width 0.35s ease;
  width: 20%;
}

.step-node {
  position: relative;
  z-index: 3;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  background: transparent;
  border: none;
  padding: 0;
}

.step-circle {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  background: #ffffff;
  border: 2px solid #cbd5e1;
  color: #64748b;
  font-weight: 700;
  font-size: 0.95rem;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.25s ease;
  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
}

.step-node.active .step-circle {
  border-color: #0284c7;
  background: #0284c7;
  color: #ffffff;
  box-shadow: 0 0 0 5px rgba(2, 132, 199, 0.15);
}

.step-node.completed .step-circle {
  border-color: #10b981;
  background: #10b981;
  color: #ffffff;
}

.step-label {
  font-size: 0.8rem;
  font-weight: 700;
  color: #64748b;
  margin-top: 8px;
  text-align: center;
  transition: color 0.2s;
}

.step-node.active .step-label { color: #0284c7; }
.step-node.completed .step-label { color: #10b981; }

@media (max-width: 600px) {
  .step-label { display: none; }
  .step-circle { width: 34px; height: 34px; font-size: 0.85rem; }
  .stepper-progress-bg, .stepper-progress-fill { top: 17px; }
}

/* Form Styles */
.form-label-title {
  font-size: 0.88rem;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 0.4rem;
}

.form-control, .form-select, .ts-control {
  border: 1.5px solid #cbd5e1;
  border-radius: 10px;
  padding: 0.65rem 1rem;
  font-size: 0.95rem;
  transition: all 0.2s ease;
}

.form-control:focus, .form-select:focus, .ts-wrapper.focus .ts-control {
  border-color: #0284c7;
  box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15);
}

/* Multi-select Level Badges / Check Pills */
.level-pill-box {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.level-pill-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  border: 1.5px solid #cbd5e1;
  background: #ffffff;
  padding: 8px 16px;
  border-radius: 50px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  user-select: none;
}

.level-pill-checkbox {
  display: none;
}

.level-pill-checkbox:checked + .level-pill-label {
  background: #0284c7;
  border-color: #0284c7;
  color: #ffffff;
  box-shadow: 0 4px 10px rgba(2, 132, 199, 0.25);
}

/* Plan Selection Cards */
.plan-choice-card {
  border: 2px solid #e2e8f0;
  border-radius: 16px;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.25s ease;
  position: relative;
  background: #ffffff;
  height: 100%;
}

.plan-choice-card:hover {
  border-color: #93c5fd;
  transform: translateY(-2px);
}

.plan-choice-card.selected {
  border-color: #0284c7;
  background: #f0f9ff;
  box-shadow: 0 8px 20px -5px rgba(2, 132, 199, 0.2);
}

.plan-radio-indicator {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid #94a3b8;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
}

.plan-choice-card.selected .plan-radio-indicator {
  border-color: #0284c7;
  background: #0284c7;
}

.plan-choice-card.selected .plan-radio-indicator::after {
  content: '';
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #ffffff;
}

/* 30-Day Trial Callout */
.trial-banner-box {
  background: linear-gradient(135deg, #070e1b 0%, #0f172a 100%);
  color: #ffffff;
  border-radius: 14px;
  padding: 1.25rem 1.5rem;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: gap;
  gap: 15px;
}

/* Review Section Box */
.review-panel {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem;
  margin-bottom: 1.25rem;
}

.review-panel-title {
  font-weight: 700;
  font-size: 1rem;
  color: #0f172a;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #e2e8f0;
  padding-bottom: 0.65rem;
  margin-bottom: 1rem;
}

.review-item-label {
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #64748b;
  margin-bottom: 2px;
}

.review-item-value {
  font-size: 0.95rem;
  font-weight: 600;
  color: #0f172a;
}

/* Logo Upload Drag and Drop */
.logo-dropzone {
  border: 2px dashed #cbd5e1;
  border-radius: 12px;
  padding: 1.5rem;
  text-align: center;
  background: #f8fafc;
  cursor: pointer;
  transition: all 0.2s ease;
}

.logo-dropzone:hover, .logo-dropzone.dragover {
  border-color: #0284c7;
  background: #f0f9ff;
}

/* Password Strength Bar */
.password-meter-bar {
  height: 6px;
  border-radius: 4px;
  background: #e2e8f0;
  overflow: hidden;
  margin-top: 6px;
}

.password-meter-fill {
  height: 100%;
  width: 0%;
  transition: width 0.3s ease, background-color 0.3s ease;
}
</style>

<div class="wizard-shell">
  <!-- Top Brand Navigation -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <a href="<?= e(url('/')) ?>" class="d-flex align-items-center gap-2 text-decoration-none">
      <div style="width:36px;height:36px;border-radius:10px;background:#0284c7;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;">
        <i class="bi bi-mortarboard-fill"></i>
      </div>
      <div>
        <span class="fw-bold fs-5 text-dark font-heading"><?= e(platform_setting('platform_name', 'School Portal')) ?></span>
      </div>
    </a>
    <div class="d-flex align-items-center gap-3">
      <span class="text-muted small d-none d-sm-inline">Already registered?</span>
      <a href="<?= e(url('login')) ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3 fw-semibold">Sign In</a>
    </div>
  </div>

  <!-- Wizard Card -->
  <div class="wizard-card">
    <div class="text-center mb-4">
      <span class="badge text-bg-info text-dark rounded-pill px-3 py-1 fw-bold small mb-2">30-DAY FREE TRIAL ONBOARDING</span>
      <h1 class="h3 fw-bold font-heading text-dark mb-1">Register Your School</h1>
      <p class="text-muted small mb-0">Follow our quick 5-step registration wizard to launch your school portal.</p>
    </div>

    <!-- Flash Messages -->
    <?php require base_path('app/Views/partials/flash.php'); ?>

    <!-- 5-Step Progress Stepper -->
    <div class="stepper-track">
      <div class="stepper-progress-bg"></div>
      <div class="stepper-progress-fill" id="stepperProgressFill"></div>

      <!-- Node 1 -->
      <button type="button" class="step-node active" id="stepNode1" onclick="jumpToStep(1)">
        <div class="step-circle" id="circle1">1</div>
        <div class="step-label">School Info</div>
      </button>

      <!-- Node 2 -->
      <button type="button" class="step-node" id="stepNode2" onclick="jumpToStep(2)">
        <div class="step-circle" id="circle2">2</div>
        <div class="step-label">Academics</div>
      </button>

      <!-- Node 3 -->
      <button type="button" class="step-node" id="stepNode3" onclick="jumpToStep(3)">
        <div class="step-circle" id="circle3">3</div>
        <div class="step-label">Administrator</div>
      </button>

      <!-- Node 4 -->
      <button type="button" class="step-node" id="stepNode4" onclick="jumpToStep(4)">
        <div class="step-circle" id="circle4">4</div>
        <div class="step-label">Plan & Trial</div>
      </button>

      <!-- Node 5 -->
      <button type="button" class="step-node" id="stepNode5" onclick="jumpToStep(5)">
        <div class="step-circle" id="circle5">5</div>
        <div class="step-label">Review & Submit</div>
      </button>
    </div>

    <!-- Main Registration Form -->
    <form method="post" action="<?= e(url('register')) ?>" enctype="multipart/form-data" id="wizardForm">
      <?= csrf_field() ?>

      <!-- =====================================================================
           STEP 1: SCHOOL INFORMATION
           ===================================================================== -->
      <div class="wizard-step-pane" id="wizardStep1">
        <h4 class="h5 fw-bold text-dark font-heading mb-3 border-bottom pb-2">
          <i class="bi bi-building-fill text-primary me-2"></i>Step 1: School Identity & Address
        </h4>

        <div class="row g-3 mb-3">
          <div class="col-md-8">
            <label class="form-label-title">Official School Name <span class="text-danger">*</span></label>
            <input type="text" name="school_name" id="school_name" class="form-control" placeholder="e.g. Bloomfield International Academy" value="<?= e(old('school_name', $draft['school_name'] ?? '')) ?>" required>
          </div>
          <div class="col-md-4">
            <label class="form-label-title">School Type</label>
            <select name="school_type" id="school_type" class="form-select">
              <?php 
                $currType = old('school_type', $draft['school_type'] ?? 'Private School');
                $types = ['Private School', 'Trust / Foundation School', 'Semi-Government School', 'Franchise / Chain School', 'Cadet / Army Public', 'Cambridge International', 'Madrasa / Religious Institute'];
                foreach($types as $t): 
              ?>
                <option value="<?= e($t) ?>" <?= $currType === $t ? 'selected' : '' ?>><?= e($t) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">School Official Email <span class="text-danger">*</span></label>
            <input type="email" name="school_email" id="school_email" class="form-control" placeholder="info@yourschool.edu.pk" value="<?= e(old('school_email', $draft['school_email'] ?? '')) ?>" required>
            <div class="small text-muted mt-1" style="font-size:11.5px;">Public institutional inquiries & verification</div>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">School Phone Number</label>
            <input type="tel" id="school_phone_input" class="form-control" placeholder="Phone Number" value="<?= e(old('school_phone', $draft['school_phone'] ?? '')) ?>">
            <input type="hidden" name="school_phone" id="school_phone_hidden" value="<?= e(old('school_phone', $draft['school_phone'] ?? '')) ?>">
          </div>

          <div class="col-md-12">
            <label class="form-label-title">School Website (Optional)</label>
            <input type="url" name="website" id="website" class="form-control" placeholder="https://www.yourschool.edu.pk" value="<?= e(old('website', $draft['website'] ?? '')) ?>">
          </div>
        </div>

        <h5 class="h6 fw-bold text-dark mt-4 mb-3 border-bottom pb-2">Location & Campus Address</h5>
        <div class="row g-3 mb-3">
          <div class="col-md-4">
            <label class="form-label-title">Country <span class="text-danger">*</span></label>
            <select name="country" id="country_select" class="form-select" required>
              <option value="Pakistan" selected>Pakistan</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label-title">Province / State <span class="text-danger">*</span></label>
            <select name="province" id="province_select" class="form-select" required>
              <option value="">Select Province/State</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label-title">City <span class="text-danger">*</span></label>
            <select name="city" id="city_select" class="form-select" required>
              <option value="">Select City</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label-title">Area / Neighborhood</label>
            <select name="area" id="area_select" class="form-select">
              <option value="">Select or type area</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label-title">Street / Sector</label>
            <input type="text" name="street" id="street" class="form-control" placeholder="e.g. Main Boulevard, Phase 2" value="<?= e(old('street', $draft['street'] ?? '')) ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label-title">Plot / Building Number</label>
            <input type="text" name="house_number" id="house_number" class="form-control" placeholder="e.g. Campus Plot 4-A" value="<?= e(old('house_number', $draft['house_number'] ?? '')) ?>">
          </div>
        </div>

        <div class="mt-4">
          <label class="form-label-title">School Crest / Logo (Optional)</label>
          <label class="logo-dropzone w-100 d-block" id="logo_wrapper">
            <div id="logo_placeholder">
              <i class="bi bi-cloud-arrow-up fs-2 text-primary"></i>
              <div class="fw-bold text-dark mt-1">Click or drag & drop school logo here</div>
              <div class="text-muted small">Supports transparent PNG, JPG (Max 2MB)</div>
            </div>
            <img id="logo_preview" src="" alt="Logo Preview" style="max-height: 80px; display: none; margin: 0 auto; object-fit: contain;">
            <input type="file" name="logo" id="logo_input" class="d-none" accept="image/png, image/jpeg">
          </label>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
          <button type="button" class="btn btn-outline-secondary" onclick="saveDraftAjax()"><i class="bi bi-bookmark-check me-1"></i> Save Draft</button>
          <button type="button" class="btn btn-saas-primary" onclick="validateAndGoStep(1, 2)">Continue to Academics <i class="bi bi-arrow-right-short fs-5"></i></button>
        </div>
      </div>

      <!-- =====================================================================
           STEP 2: ACADEMIC STRUCTURE
           ===================================================================== -->
      <div class="wizard-step-pane d-none" id="wizardStep2">
        <h4 class="h5 fw-bold text-dark font-heading mb-3 border-bottom pb-2">
          <i class="bi bi-book-half text-primary me-2"></i>Step 2: Academic Levels & Curriculum
        </h4>

        <!-- Education Levels Multi-Select -->
        <div class="mb-4">
          <label class="form-label-title d-block mb-2">Education Levels Offered <span class="text-danger">*</span> (Select all that apply)</label>
          <?php
            $currLevels = old('education_levels', $draft['education_levels'] ?? ['Montessori', 'Primary', 'Middle', 'Matric']);
            if (is_string($currLevels)) $currLevels = explode(',', $currLevels);
            $levelsArr = [
              'Montessori' => 'Montessori / Early Years (Playgroup, Nursery, Prep/KG)',
              'Primary' => 'Primary School (Class 1 to 5)',
              'Middle' => 'Middle School (Class 6 to 8)',
              'Matric' => 'Matriculation / SSC (Class 9 & 10)',
              'Intermediate' => 'Higher Secondary / Intermediate (Class 11 & 12)',
              'Cambridge' => 'Cambridge International (O-Levels / A-Levels)',
            ];
          ?>
          <div class="level-pill-box">
            <?php foreach($levelsArr as $lKey => $lLabel): ?>
              <label>
                <input type="checkbox" name="education_levels[]" value="<?= e($lKey) ?>" class="level-pill-checkbox" <?= in_array($lKey, $currLevels, true) ? 'checked' : '' ?>>
                <span class="level-pill-label">
                  <i class="bi bi-check2"></i> <?= e($lLabel) ?>
                </span>
              </label>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="row g-3 mb-3">
          <div class="col-md-6">
            <label class="form-label-title">Curriculum / Examination Board <span class="text-danger">*</span></label>
            <select name="curriculum" id="curriculum" class="form-select" required>
              <?php
                $currCurriculum = old('curriculum', $draft['curriculum'] ?? 'Federal Board');
                $boards = ['Federal Board (FBISE)', 'Punjab Boards (BISE)', 'Sindh Boards', 'KPK Boards', 'Balochistan Boards', 'Cambridge International (CAIE)', 'Oxford / Single National Curriculum (SNC)', 'Aga Khan University Examination Board (AKU-EB)'];
                foreach($boards as $b):
              ?>
                <option value="<?= e($b) ?>" <?= $currCurriculum === $b ? 'selected' : '' ?>><?= e($b) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-3">
            <label class="form-label-title">Session Start Month</label>
            <select name="academic_year_start" id="academic_year_start" class="form-select">
              <?php 
                $startMonth = old('academic_year_start', $draft['academic_year_start'] ?? 'April');
                $months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                foreach($months as $m): 
              ?>
                <option value="<?= e($m) ?>" <?= $startMonth === $m ? 'selected' : '' ?>><?= e($m) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-3">
            <label class="form-label-title">Session End Month</label>
            <select name="academic_year_end" id="academic_year_end" class="form-select">
              <?php 
                $endMonth = old('academic_year_end', $draft['academic_year_end'] ?? 'March');
                foreach($months as $m): 
              ?>
                <option value="<?= e($m) ?>" <?= $endMonth === $m ? 'selected' : '' ?>><?= e($m) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">Expected Enrolled Students <span class="text-danger">*</span></label>
            <input type="number" name="estimated_students" id="estimated_students" class="form-control" placeholder="e.g. 450" value="<?= e(old('estimated_students', $draft['estimated_students'] ?? '350')) ?>" min="10" required>
            <div class="small text-muted mt-1" style="font-size:11.5px;">Helps us suggest the optimal capacity plan for your school</div>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">Expected Faculty & Staff Count</label>
            <input type="number" name="estimated_staff" id="estimated_staff" class="form-control" placeholder="e.g. 35" value="<?= e(old('estimated_staff', $draft['estimated_staff'] ?? '25')) ?>" min="2">
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
          <button type="button" class="btn btn-outline-secondary" onclick="jumpToStep(1)"><i class="bi bi-arrow-left-short fs-5"></i> Back</button>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary" onclick="saveDraftAjax()"><i class="bi bi-bookmark-check me-1"></i> Save Draft</button>
            <button type="button" class="btn btn-saas-primary" onclick="validateAndGoStep(2, 3)">Continue to Administrator <i class="bi bi-arrow-right-short fs-5"></i></button>
          </div>
        </div>
      </div>

      <!-- =====================================================================
           STEP 3: SCHOOL ADMINISTRATOR
           ===================================================================== -->
      <div class="wizard-step-pane d-none" id="wizardStep3">
        <h4 class="h5 fw-bold text-dark font-heading mb-3 border-bottom pb-2">
          <i class="bi bi-person-fill-lock text-primary me-2"></i>Step 3: Primary Administrator & Owner Account
        </h4>
        <div class="alert alert-info py-2 small mb-4">
          <i class="bi bi-info-circle-fill me-1"></i> This account will be created as the <strong>School Owner / Master Administrator</strong>. You can invite additional teachers and staff after registration.
        </div>

        <div class="row g-3 mb-3">
          <div class="col-md-6">
            <label class="form-label-title">Owner / Principal Full Name <span class="text-danger">*</span></label>
            <input type="text" name="contact_person" id="contact_person" class="form-control" placeholder="e.g. Dr. Muhammad Tariq" value="<?= e(old('contact_person', $draft['contact_person'] ?? '')) ?>" required>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">Administrator Login Email <span class="text-danger">*</span></label>
            <input type="email" name="email" id="admin_email" class="form-control" placeholder="tariq@yourschool.edu.pk" value="<?= e(old('email', $draft['email'] ?? '')) ?>" required>
            <div class="small text-muted mt-1" style="font-size:11.5px;">Will be used as your master portal login ID</div>
          </div>

          <div class="col-md-12">
            <label class="form-label-title">Administrator Mobile Phone</label>
            <input type="tel" id="admin_phone_input" class="form-control" placeholder="Mobile Number" value="<?= e(old('phone', $draft['phone'] ?? '')) ?>">
            <input type="hidden" name="phone" id="admin_phone_hidden" value="<?= e(old('phone', $draft['phone'] ?? '')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label-title">Master Password <span class="text-danger">*</span></label>
            <div class="input-group">
              <input type="password" name="password" id="password" class="form-control" placeholder="Create strong password" minlength="8" required autocomplete="new-password">
              <button class="btn btn-outline-secondary" type="button" onclick="togglePass('password', 'eyeIcon1')">
                <i class="bi bi-eye" id="eyeIcon1"></i>
              </button>
            </div>
            <!-- Live Password Strength Meter -->
            <div class="password-meter-bar">
              <div class="password-meter-fill" id="passMeterFill"></div>
            </div>
            <div class="small text-muted mt-1 d-flex justify-content-between" style="font-size:11px;">
              <span>Min 8 chars, uppercase, lowercase, number, symbol</span>
              <span id="passStrengthLabel" class="fw-bold"></span>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label-title">Confirm Master Password <span class="text-danger">*</span></label>
            <div class="input-group">
              <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="Confirm password" minlength="8" required autocomplete="new-password">
              <button class="btn btn-outline-secondary" type="button" onclick="togglePass('password_confirmation', 'eyeIcon2')">
                <i class="bi bi-eye" id="eyeIcon2"></i>
              </button>
            </div>
            <div class="small text-danger mt-1 d-none fw-bold" id="confirmPassError" style="font-size:11px;">
              <i class="bi bi-exclamation-triangle-fill"></i> Passwords do not match!
            </div>
          </div>

          <div class="col-12 mt-4">
            <div class="form-check p-3 rounded-3 border bg-light">
              <input class="form-check-input ms-0 me-2" type="checkbox" name="terms_accepted" id="terms_accepted" value="1" required checked>
              <label class="form-check-label text-dark small fw-semibold" for="terms_accepted">
                I agree to the <a href="#contact" class="text-primary text-decoration-none" target="_blank">Terms of Service</a>, <a href="#contact" class="text-primary text-decoration-none" target="_blank">Privacy Policy</a>, and accept the conditions of the <strong>30-Day Free Trial</strong>.
              </label>
            </div>
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
          <button type="button" class="btn btn-outline-secondary" onclick="jumpToStep(2)"><i class="bi bi-arrow-left-short fs-5"></i> Back</button>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary" onclick="saveDraftAjax()"><i class="bi bi-bookmark-check me-1"></i> Save Draft</button>
            <button type="button" class="btn btn-saas-primary" onclick="validateAndGoStep(3, 4)">Continue to Plan Selection <i class="bi bi-arrow-right-short fs-5"></i></button>
          </div>
        </div>
      </div>

      <!-- =====================================================================
           STEP 4: PLAN SELECTION
           ===================================================================== -->
      <div class="wizard-step-pane d-none" id="wizardStep4">
        <h4 class="h5 fw-bold text-dark font-heading mb-3 border-bottom pb-2">
          <i class="bi bi-credit-card-2-front-fill text-primary me-2"></i>Step 4: Select Your 30-Day Free Trial Plan
        </h4>

        <!-- Free Trial Guarantee Banner -->
        <div class="trial-banner-box">
          <div>
            <div class="fw-bold fs-6"><i class="bi bi-gift-fill text-warning me-2"></i> 30-Day Unrestricted Free Trial Active</div>
            <div class="small text-white-50">
              Starts Today (<?= e($trialStart) ?>) &bull; Full Access Ends on <strong><?= e($trialEnd) ?></strong>. No card required.
            </div>
          </div>
          <span class="badge bg-success-subtle text-success fs-6 fw-bold px-3 py-2 rounded-pill">0.00 DUE TODAY</span>
        </div>

        <input type="hidden" name="plan_id" id="selected_plan_id" value="<?= e((string)$selectedPlanId) ?>">

        <div class="row g-3 mb-4">
          <?php foreach ($plansList as $p): 
            $isSelected = ($selectedPlanId === (int) $p['id']);
            $priceFormatted = $currSymbol . number_format((float) ($p['monthly_price'] ?? 0), 2);
          ?>
            <div class="col-md-4">
              <div class="plan-choice-card <?= $isSelected ? 'selected' : '' ?>" id="planCard<?= (int) $p['id'] ?>" onclick="selectPlan(<?= (int) $p['id'] ?>, '<?= e($p['name']) ?>', '<?= e($priceFormatted) ?>')">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <h5 class="fw-bold text-dark font-heading mb-0"><?= e($p['name']) ?></h5>
                  <div class="plan-radio-indicator"></div>
                </div>
                <div class="small text-muted mb-3"><?= e($p['description'] ?? 'School management') ?></div>
                <div class="h4 fw-bold text-dark font-heading mb-1"><?= e($priceFormatted) ?> <span class="fs-6 fw-normal text-muted">/mo</span></div>
                <div class="badge bg-info-subtle text-info small mb-3">After 30-Day Free Trial</div>

                <ul class="list-unstyled small text-muted d-flex flex-column gap-1.5 border-top pt-3">
                  <li><i class="bi bi-check-lg text-success me-1"></i> Up to <strong><?= e((string)($p['student_limit'] ?? 'Unlimited')) ?></strong> Students</li>
                  <li><i class="bi bi-check-lg text-success me-1"></i> Up to <strong><?= e((string)($p['teacher_limit'] ?? 'Unlimited')) ?></strong> Teachers</li>
                  <li><i class="bi bi-check-lg text-success me-1"></i> <?= e((string)($p['storage_limit_mb'] ?? 1024)) ?> MB Cloud Vault</li>
                  <li><i class="bi bi-check-lg text-success me-1"></i> All Core Academic Features</li>
                </ul>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
          <button type="button" class="btn btn-outline-secondary" onclick="jumpToStep(3)"><i class="bi bi-arrow-left-short fs-5"></i> Back</button>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary" onclick="saveDraftAjax()"><i class="bi bi-bookmark-check me-1"></i> Save Draft</button>
            <button type="button" class="btn btn-saas-primary" onclick="validateAndGoStep(4, 5)">Review & Submit <i class="bi bi-arrow-right-short fs-5"></i></button>
          </div>
        </div>
      </div>

      <!-- =====================================================================
           STEP 5: REVIEW & FINAL SUBMISSION
           ===================================================================== -->
      <div class="wizard-step-pane d-none" id="wizardStep5">
        <h4 class="h5 fw-bold text-dark font-heading mb-3 border-bottom pb-2">
          <i class="bi bi-clipboard-check-fill text-primary me-2"></i>Step 5: Review Details & Launch School Portal
        </h4>
        <p class="text-muted small mb-4">Please review your school details before finalizing. You can click <strong>Edit</strong> on any section to make corrections.</p>

        <!-- Block 1: School Profile Review -->
        <div class="review-panel">
          <div class="review-panel-title">
            <span><i class="bi bi-building me-1.5 text-primary"></i> 1. School Information</span>
            <button type="button" class="btn btn-sm btn-link text-primary p-0 fw-bold" onclick="jumpToStep(1)">Edit</button>
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <div class="review-item-label">School Name</div>
              <div class="review-item-value" id="revSchoolName">-</div>
            </div>
            <div class="col-md-3">
              <div class="review-item-label">School Type</div>
              <div class="review-item-value" id="revSchoolType">-</div>
            </div>
            <div class="col-md-3">
              <div class="review-item-label">Official Email</div>
              <div class="review-item-value" id="revSchoolEmail">-</div>
            </div>
            <div class="col-md-6">
              <div class="review-item-label">Campus Address</div>
              <div class="review-item-value" id="revAddress">-</div>
            </div>
            <div class="col-md-6">
              <div class="review-item-label">Website</div>
              <div class="review-item-value" id="revWebsite">-</div>
            </div>
          </div>
        </div>

        <!-- Block 2: Academic Setup Review -->
        <div class="review-panel">
          <div class="review-panel-title">
            <span><i class="bi bi-book me-1.5 text-primary"></i> 2. Academic Framework</span>
            <button type="button" class="btn btn-sm btn-link text-primary p-0 fw-bold" onclick="jumpToStep(2)">Edit</button>
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <div class="review-item-label">Education Levels</div>
              <div class="review-item-value text-primary" id="revLevels">-</div>
            </div>
            <div class="col-md-6">
              <div class="review-item-label">Curriculum / Examination Board</div>
              <div class="review-item-value" id="revCurriculum">-</div>
            </div>
            <div class="col-md-4">
              <div class="review-item-label">Academic Session</div>
              <div class="review-item-value" id="revSession">-</div>
            </div>
            <div class="col-md-4">
              <div class="review-item-label">Expected Students</div>
              <div class="review-item-value" id="revStudents">-</div>
            </div>
            <div class="col-md-4">
              <div class="review-item-label">Expected Staff</div>
              <div class="review-item-value" id="revStaff">-</div>
            </div>
          </div>
        </div>

        <!-- Block 3: Administrator Account Review -->
        <div class="review-panel">
          <div class="review-panel-title">
            <span><i class="bi bi-person-badge me-1.5 text-primary"></i> 3. Administrator Credentials</span>
            <button type="button" class="btn btn-sm btn-link text-primary p-0 fw-bold" onclick="jumpToStep(3)">Edit</button>
          </div>
          <div class="row g-3">
            <div class="col-md-4">
              <div class="review-item-label">Owner / Contact Person</div>
              <div class="review-item-value" id="revContact">-</div>
            </div>
            <div class="col-md-4">
              <div class="review-item-label">Master Login Email</div>
              <div class="review-item-value fw-bold text-dark" id="revEmail">-</div>
            </div>
            <div class="col-md-4">
              <div class="review-item-label">Admin Phone</div>
              <div class="review-item-value" id="revPhone">-</div>
            </div>
          </div>
        </div>

        <!-- Block 4: Plan & Trial Review -->
        <div class="review-panel">
          <div class="review-panel-title">
            <span><i class="bi bi-shield-check me-1.5 text-primary"></i> 4. Subscription & 30-Day Free Trial</span>
            <button type="button" class="btn btn-sm btn-link text-primary p-0 fw-bold" onclick="jumpToStep(4)">Edit</button>
          </div>
          <div class="row g-3 align-items-center">
            <div class="col-md-6">
              <div class="review-item-label">Selected SaaS Plan</div>
              <div class="review-item-value fs-5 fw-bold text-primary" id="revPlanName">Starter Plan</div>
              <div class="small text-muted" id="revPlanPrice">Rs. 4,999.00 / month (after trial)</div>
            </div>
            <div class="col-md-6">
              <div class="p-2.5 rounded bg-success-subtle text-success small fw-semibold">
                <i class="bi bi-check-circle-fill me-1"></i> 30-Day Free Trial active until <strong><?= e($trialEnd) ?></strong>. No charge today.
              </div>
            </div>
          </div>
        </div>

        <!-- Submission Controls -->
        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
          <button type="button" class="btn btn-outline-secondary" onclick="jumpToStep(4)"><i class="bi bi-arrow-left-short fs-5"></i> Back</button>
          <button type="submit" class="btn btn-saas-primary btn-lg px-4" id="submitWizardBtn">
            <span id="submitBtnText"><i class="bi bi-rocket-takeoff-fill me-1.5"></i> Complete Registration & Launch School</span>
            <span id="submitSpinner" class="spinner-border spinner-border-sm d-none" role="status"></span>
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/23.0.4/js/intlTelInput.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>

<script>
let currentStep = 1;
const totalSteps = 5;

// Error display helper functions
function showFieldError(el, msg) {
  el.classList.add('is-invalid');
  el.focus();
  showStepBanner(msg);
}

function showStepBanner(msg) {
  let box = document.getElementById('stepValidationAlert');
  if (!box) {
    box = document.createElement('div');
    box.id = 'stepValidationAlert';
    box.className = 'alert alert-danger py-2.5 px-3 small mb-3 d-flex align-items-center gap-2 shadow-sm';
    box.style.borderRadius = '10px';
  }
  box.innerHTML = '<i class="bi bi-exclamation-triangle-fill text-danger fs-5 flex-shrink-0"></i> <div><strong>Action Required:</strong> ' + msg + '</div>';

  const pane = document.getElementById('wizardStep' + currentStep);
  if (pane) {
    const header = pane.querySelector('h4') || pane.firstChild;
    header.insertAdjacentElement('afterend', box);
    box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function clearStepErrors() {
  document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
  const box = document.getElementById('stepValidationAlert');
  if (box) box.remove();
  const cErr = document.getElementById('confirmPassError');
  if (cErr) cErr.classList.add('d-none');
}

// Comprehensive Validator for each Step
function validateStep(step) {
  clearStepErrors();

  if (step === 1) {
    const nameEl = document.getElementById('school_name');
    const name = nameEl.value.trim();
    if (!name) {
      showFieldError(nameEl, 'Please enter your official School Name before proceeding.');
      return false;
    }

    const emailEl = document.getElementById('school_email');
    const email = emailEl.value.trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showFieldError(emailEl, 'Please enter a valid School Official Email address (e.g. info@school.edu.pk).');
      return false;
    }

    const provVal = (typeof tsProvince !== 'undefined' && tsProvince) ? tsProvince.getValue() : document.getElementById('province_select').value;
    if (!provVal) {
      showStepBanner('Please select a Province / State for your school campus.');
      if (typeof tsProvince !== 'undefined' && tsProvince) tsProvince.focus();
      return false;
    }

    const cityVal = (typeof tsCity !== 'undefined' && tsCity) ? tsCity.getValue() : document.getElementById('city_select').value;
    if (!cityVal) {
      showStepBanner('Please select a City for your school campus.');
      if (typeof tsCity !== 'undefined' && tsCity) tsCity.focus();
      return false;
    }

    return true;
  }

  if (step === 2) {
    const checkedLevels = document.querySelectorAll('input[name="education_levels[]"]:checked');
    if (checkedLevels.length === 0) {
      showStepBanner('Please select at least one Education Level offered (e.g. Montessori, Primary, Matric).');
      return false;
    }

    const studentsEl = document.getElementById('estimated_students');
    const students = parseInt(studentsEl.value, 10);
    if (!students || isNaN(students) || students < 1) {
      showFieldError(studentsEl, 'Please enter expected student count (minimum 1).');
      return false;
    }

    const curEl = document.getElementById('curriculum');
    if (!curEl.value.trim()) {
      showFieldError(curEl, 'Please select a Curriculum / Examination Board.');
      return false;
    }

    return true;
  }

  if (step === 3) {
    const contactEl = document.getElementById('contact_person');
    const contact = contactEl.value.trim();
    if (!contact) {
      showFieldError(contactEl, 'Please enter Administrator / Owner Full Name.');
      return false;
    }

    const adminEmailEl = document.getElementById('admin_email');
    const adminEmail = adminEmailEl.value.trim();
    if (!adminEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(adminEmail)) {
      showFieldError(adminEmailEl, 'Please enter a valid Administrator Login Email.');
      return false;
    }

    const passEl = document.getElementById('password');
    const pass = passEl.value;
    if (pass.length < 8) {
      showFieldError(passEl, 'Master password must be at least 8 characters long.');
      return false;
    }
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/.test(pass)) {
      showFieldError(passEl, 'Password must include uppercase letter, lowercase letter, number, and special character.');
      return false;
    }

    const passConfEl = document.getElementById('password_confirmation');
    const passConf = passConfEl.value;
    if (pass !== passConf) {
      document.getElementById('confirmPassError').classList.remove('d-none');
      showFieldError(passConfEl, 'Password and Confirm Password do not match.');
      return false;
    }

    const termsEl = document.getElementById('terms_accepted');
    if (!termsEl.checked) {
      showStepBanner('You must accept the Terms of Service and Privacy Policy to continue.');
      termsEl.focus();
      return false;
    }

    return true;
  }

  if (step === 4) {
    const planId = document.getElementById('selected_plan_id').value;
    if (!planId) {
      showStepBanner('Please select a 30-day free trial plan to continue.');
      return false;
    }
    return true;
  }

  return true;
}

// Initialize Stepper with Strict Validation Gate
function jumpToStep(step) {
  if (step < 1 || step > totalSteps) return false;

  // STRICT FORWARD CHECK: Never allow jumping forward if any previous step is invalid
  if (step > currentStep) {
    for (let s = currentStep; s < step; s++) {
      if (!validateStep(s)) {
        return false;
      }
    }
  }

  clearStepErrors();

  // Hide all steps
  for (let i = 1; i <= totalSteps; i++) {
    const pane = document.getElementById('wizardStep' + i);
    const node = document.getElementById('stepNode' + i);
    if (pane) pane.classList.add('d-none');
    if (node) {
      node.classList.remove('active');
      if (i < step) {
        node.classList.add('completed');
        document.getElementById('circle' + i).innerHTML = '<i class="bi bi-check-lg"></i>';
      } else {
        node.classList.remove('completed');
        document.getElementById('circle' + i).innerText = i;
      }
    }
  }

  // Show active step
  const activePane = document.getElementById('wizardStep' + step);
  const activeNode = document.getElementById('stepNode' + step);
  if (activePane) activePane.classList.remove('d-none');
  if (activeNode) activeNode.classList.add('active');

  // Update progress bar
  const fillPct = (step / totalSteps) * 100;
  document.getElementById('stepperProgressFill').style.width = fillPct + '%';

  currentStep = step;
  if (step === 5) populateReview();
  window.scrollTo({ top: 120, behavior: 'smooth' });
  return true;
}

// Client-side Validation per Step Button
function validateAndGoStep(fromStep, toStep) {
  if (!validateStep(fromStep)) {
    return false;
  }
  jumpToStep(toStep);
}

// Plan Selection Logic
function selectPlan(planId, name, price) {
  document.getElementById('selected_plan_id').value = planId;
  document.querySelectorAll('.plan-choice-card').forEach(c => c.classList.remove('selected'));
  const card = document.getElementById('planCard' + planId);
  if (card) card.classList.add('selected');
}

// Auto-select Recommended Plan based on Student count
document.getElementById('estimated_students').addEventListener('input', function() {
  const val = parseInt(this.value.trim(), 10);
  if (isNaN(val)) return;

  if (val <= 300) {
    selectPlan(1, 'Starter', 'Rs. 4,999.00');
  } else if (val <= 1000) {
    selectPlan(2, 'Professional', 'Rs. 9,999.00');
  } else {
    selectPlan(3, 'Enterprise', 'Rs. 24,999.00');
  }
});

// Populate Review Step 5
function populateReview() {
  document.getElementById('revSchoolName').innerText = document.getElementById('school_name').value.trim() || 'N/A';
  document.getElementById('revSchoolType').innerText = document.getElementById('school_type').value || 'N/A';
  document.getElementById('revSchoolEmail').innerText = document.getElementById('school_email').value.trim() || 'N/A';
  
  const city = document.getElementById('city_select').value;
  const prov = document.getElementById('province_select').value;
  const country = document.getElementById('country_select').value;
  const street = document.getElementById('street').value.trim();
  document.getElementById('revAddress').innerText = [street, city, prov, country].filter(Boolean).join(', ') || 'N/A';
  document.getElementById('revWebsite').innerText = document.getElementById('website').value.trim() || 'Not specified';

  // Levels
  const levels = Array.from(document.querySelectorAll('input[name="education_levels[]"]:checked')).map(c => c.value);
  document.getElementById('revLevels').innerText = levels.join(', ') || 'None selected';
  document.getElementById('revCurriculum').innerText = document.getElementById('curriculum').value || 'N/A';
  document.getElementById('revSession').innerText = document.getElementById('academic_year_start').value + ' — ' + document.getElementById('academic_year_end').value;
  document.getElementById('revStudents').innerText = document.getElementById('estimated_students').value + ' Students';
  document.getElementById('revStaff').innerText = document.getElementById('estimated_staff').value + ' Faculty / Staff';

  // Admin
  document.getElementById('revContact').innerText = document.getElementById('contact_person').value.trim() || 'N/A';
  document.getElementById('revEmail').innerText = document.getElementById('admin_email').value.trim() || 'N/A';
  document.getElementById('revPhone').innerText = document.getElementById('admin_phone_input').value.trim() || 'N/A';

  // Plan
  const pId = document.getElementById('selected_plan_id').value;
  const pCard = document.getElementById('planCard' + pId);
  if (pCard) {
    const title = pCard.querySelector('h5').innerText;
    const price = pCard.querySelector('.h4').innerText;
    document.getElementById('revPlanName').innerText = title;
    document.getElementById('revPlanPrice').innerText = price + ' (after 30-day trial)';
  }
}

// Password Strength Meter
const passInput = document.getElementById('password');
const confPassInput = document.getElementById('password_confirmation');
const meterFill = document.getElementById('passMeterFill');
const strengthLabel = document.getElementById('passStrengthLabel');

passInput.addEventListener('input', function() {
  const val = this.value;
  let score = 0;
  if (val.length >= 8) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[a-z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[\W_]/.test(val)) score++;

  if (val.length === 0) {
    meterFill.style.width = '0%';
    strengthLabel.innerText = '';
  } else if (score <= 2) {
    meterFill.style.width = '33%';
    meterFill.style.backgroundColor = '#ef4444';
    strengthLabel.innerText = 'Weak';
    strengthLabel.style.color = '#ef4444';
  } else if (score <= 4) {
    meterFill.style.width = '66%';
    meterFill.style.backgroundColor = '#f59e0b';
    strengthLabel.innerText = 'Medium';
    strengthLabel.style.color = '#f59e0b';
  } else {
    meterFill.style.width = '100%';
    meterFill.style.backgroundColor = '#10b981';
    strengthLabel.innerText = 'Strong ✓';
    strengthLabel.style.color = '#10b981';
  }

  if (confPassInput.value && val !== confPassInput.value) {
    document.getElementById('confirmPassError').classList.remove('d-none');
  } else {
    document.getElementById('confirmPassError').classList.add('d-none');
  }
});

confPassInput.addEventListener('input', function() {
  if (this.value !== passInput.value) {
    document.getElementById('confirmPassError').classList.remove('d-none');
  } else {
    document.getElementById('confirmPassError').classList.add('d-none');
  }
});

function togglePass(inputId, iconId) {
  const inp = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  if (inp.type === 'password') {
    inp.type = 'text';
    icon.className = 'bi bi-eye-slash';
  } else {
    inp.type = 'password';
    icon.className = 'bi bi-eye';
  }
}

// Logo Drag & Drop and Preview
const logoInput = document.getElementById('logo_input');
const logoPreview = document.getElementById('logo_preview');
const logoPlaceholder = document.getElementById('logo_placeholder');
const logoWrapper = document.getElementById('logo_wrapper');

if (logoInput) {
  logoInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('File size exceeds 2MB limit.');
        logoInput.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = function(evt) {
        logoPreview.src = evt.target.result;
        logoPreview.style.display = 'block';
        logoPlaceholder.style.display = 'none';
      };
      reader.readAsDataURL(file);
    }
  });

  ['dragenter', 'dragover'].forEach(n => logoWrapper.addEventListener(n, e => { e.preventDefault(); logoWrapper.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach(n => logoWrapper.addEventListener(n, e => { e.preventDefault(); logoWrapper.classList.remove('dragover'); }));
  logoWrapper.addEventListener('drop', function(e) {
    if (e.dataTransfer.files.length) {
      logoInput.files = e.dataTransfer.files;
      logoInput.dispatchEvent(new Event('change'));
    }
  });
}

// Phone Input Handling
let itiSchool, itiAdmin;
document.addEventListener('DOMContentLoaded', function() {
  const sPhone = document.querySelector('#school_phone_input');
  if (sPhone) {
    itiSchool = window.intlTelInput(sPhone, {
      initialCountry: 'pk',
      separateDialCode: true,
      utilsScript: 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/23.0.4/js/utils.js'
    });
    sPhone.addEventListener('change', () => document.getElementById('school_phone_hidden').value = itiSchool.getNumber());
  }

  const aPhone = document.querySelector('#admin_phone_input');
  if (aPhone) {
    itiAdmin = window.intlTelInput(aPhone, {
      initialCountry: 'pk',
      separateDialCode: true,
      utilsScript: 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/23.0.4/js/utils.js'
    });
    aPhone.addEventListener('change', () => document.getElementById('admin_phone_hidden').value = itiAdmin.getNumber());
  }

  // Cascading Location Dropdowns with TomSelect
  const countrySelect = document.getElementById('country_select');
  const provinceSelect = document.getElementById('province_select');
  const citySelect = document.getElementById('city_select');
  const areaSelect = document.getElementById('area_select');

  const tsProvince = new TomSelect(provinceSelect, { create: true });
  const tsCity = new TomSelect(citySelect, { create: true });
  const tsArea = new TomSelect(areaSelect, { create: true });

  const pkProvinces = {
    'Punjab': ['Lahore', 'Faisalabad', 'Rawalpindi', 'Multan', 'Gujranwala', 'Sialkot', 'Bahawalpur', 'Sargodha'],
    'Sindh': ['Karachi', 'Hyderabad', 'Sukkur', 'Larkana', 'Mirpur Khas', 'Nawabshah'],
    'Khyber Pakhtunkhwa': ['Peshawar', 'Mardan', 'Abbottabad', 'Swat', 'Kohat', 'Dera Ismail Khan'],
    'Balochistan': ['Quetta', 'Gwadar', 'Turbat', 'Khuzdar', 'Chaman'],
    'Islamabad Capital Territory': ['Islamabad']
  };

  tsProvince.addOption(Object.keys(pkProvinces).map(p => ({ value: p, text: p })));
  tsProvince.setValue('Punjab');

  tsProvince.on('change', function(prov) {
    tsCity.clear();
    tsCity.clearOptions();
    if (pkProvinces[prov]) {
      tsCity.addOption(pkProvinces[prov].map(c => ({ value: c, text: c })));
      tsCity.setValue(pkProvinces[prov][0]);
    }
  });

  const cityAreas = {
    'Karachi': ['Clifton', 'DHA Defence', 'Gulshan-e-Iqbal', 'North Nazimabad', 'PECHS', 'Saddar', 'Malir', 'Korangi'],
    'Lahore': ['DHA Defence', 'Gulberg', 'Johar Town', 'Model Town', 'Bahria Town', 'Cantonment', 'Wapda Town'],
    'Islamabad': ['Sector F-6', 'Sector F-7', 'Sector F-8', 'Sector F-10', 'Sector G-9', 'Sector G-11', 'Blue Area', 'DHA']
  };

  tsCity.on('change', function(cName) {
    tsArea.clear();
    tsArea.clearOptions();
    if (cityAreas[cName]) {
      tsArea.addOption(cityAreas[cName].map(a => ({ value: a, text: a })));
    }
  });

  // Prepopulate draft values if present
  <?php if (!empty($draft['province'])): ?>
    tsProvince.setValue('<?= e($draft['province']) ?>');
  <?php endif; ?>
  <?php if (!empty($draft['city'])): ?>
    setTimeout(() => tsCity.setValue('<?= e($draft['city']) ?>'), 150);
  <?php endif; ?>
});

// Save Draft via AJAX
function saveDraftAjax() {
  const form = document.getElementById('wizardForm');
  const formData = new FormData(form);

  fetch('<?= url("register/draft") ?>', {
    method: 'POST',
    body: formData,
    headers: { 'X-Requested-With': 'XMLHttpRequest' }
  })
  .then(r => r.json())
  .then(res => {
    alert(res.message || 'Draft saved successfully! You can resume anytime.');
  })
  .catch(err => {
    alert('Draft saved in local session.');
  });
}

// Form Submission validation & spinner
document.getElementById('wizardForm').addEventListener('submit', function(e) {
  for (let s = 1; s <= 4; s++) {
    if (!validateStep(s)) {
      e.preventDefault();
      jumpToStep(s);
      return false;
    }
  }

  if (itiSchool) document.getElementById('school_phone_hidden').value = itiSchool.getNumber();
  if (itiAdmin) document.getElementById('admin_phone_hidden').value = itiAdmin.getNumber();

  document.getElementById('submitBtnText').classList.add('d-none');
  document.getElementById('submitSpinner').classList.remove('d-none');
  document.getElementById('submitWizardBtn').disabled = true;
});
</script>
