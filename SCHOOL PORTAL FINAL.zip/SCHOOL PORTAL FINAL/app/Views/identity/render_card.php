<?php
$primary = htmlspecialchars($design['primary_color']);
$secondary = htmlspecialchars($design['secondary_color']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Digital Identity Card</title>
    <style>
        body { margin: 0; padding: 20px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background: #e9ecef; display: flex; justify-content: center; }
        .id-card { 
            width: 250px; 
            height: 400px; 
            background: #ffffff; 
            border-radius: 12px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            overflow: hidden;
            position: relative;
            border: 2px solid <?= $secondary ?>;
            display: flex;
            flex-direction: column;
        }
        .header {
            background: <?= $primary ?>;
            color: #ffffff;
            text-align: center;
            padding: 15px 10px;
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 1px;
            border-bottom: 4px solid <?= $secondary ?>;
        }
        .photo-area {
            text-align: center;
            margin-top: 20px;
        }
        .photo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: #f1f3f5;
            border: 3px solid <?= $primary ?>;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: <?= $primary ?>;
            overflow: hidden;
        }
        .info {
            padding: 10px 20px;
            text-align: center;
        }
        .name {
            font-size: 18px;
            font-weight: 800;
            color: <?= $primary ?>;
            margin: 5px 0 2px 0;
            text-transform: uppercase;
        }
        .subtitle {
            font-size: 11px;
            color: #495057;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 5px;
            text-align: left;
            border-top: 1px dashed #dee2e6;
            padding-top: 10px;
            margin-top: 5px;
        }
        .grid-item {
            font-size: 9px;
        }
        .grid-label {
            color: <?= $secondary ?>;
            font-weight: bold;
            display: block;
            font-size: 8px;
        }
        .grid-value {
            color: #212529;
            font-weight: bold;
            display: block;
        }
        .qr-area {
            position: absolute;
            bottom: 10px;
            left: 0;
            right: 0;
            text-align: center;
        }
        .qr-placeholder {
            width: 60px;
            height: 60px;
            background: #e9ecef;
            display: inline-block;
            border: 1px solid #ced4da;
            padding: 2px;
        }
        /* Basic QR visual mock using CSS for display */
        .qr-mock {
            width: 100%; height: 100%;
            background: repeating-linear-gradient(45deg, #000, #000 2px, #fff 2px, #fff 4px);
        }
        .footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: <?= $primary ?>;
        }
        @media print {
            body { background: #fff; padding: 0; align-items: flex-start; justify-content: flex-start; }
            .id-card { box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="id-card">
        <div class="header">
            <?= htmlspecialchars($design['header_text']) ?>
        </div>
        
        <div class="photo-area">
            <div class="photo">
                <?= strtoupper(substr($payload['name'], 0, 1)) ?>
            </div>
        </div>
        
        <div class="info">
            <div class="name"><?= htmlspecialchars($payload['name']) ?></div>
            <div class="subtitle"><?= htmlspecialchars($payload['subtitle']) ?></div>
            
            <div class="grid">
                <div class="grid-item">
                    <span class="grid-label"><?= htmlspecialchars($payload['field1_label']) ?></span>
                    <span class="grid-value"><?= htmlspecialchars($payload['field1_value']) ?></span>
                </div>
                <div class="grid-item">
                    <span class="grid-label"><?= htmlspecialchars($payload['field2_label']) ?></span>
                    <span class="grid-value"><?= htmlspecialchars($payload['field2_value']) ?></span>
                </div>
                <?php if (!empty($payload['field3_label'])): ?>
                <div class="grid-item" style="grid-column: span 2; text-align: center; margin-top: 5px;">
                    <span class="grid-label"><?= htmlspecialchars($payload['field3_label']) ?></span>
                    <span class="grid-value text-danger"><?= htmlspecialchars($payload['field3_value']) ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($design['enable_qr']): ?>
        <div class="qr-area">
            <div class="qr-placeholder" title="<?= htmlspecialchars($qrData) ?>">
                <div class="qr-mock"></div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="footer"></div>
    </div>
    <script>
        // Auto-trigger print window for export
        window.onload = function() {
            setTimeout(() => { window.print(); }, 500);
        }
    </script>
</body>
</html>
