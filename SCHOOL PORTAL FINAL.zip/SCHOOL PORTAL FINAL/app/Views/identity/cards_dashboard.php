<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-person-badge text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
    </div>

    <div class="row">
        <!-- Configuration Cockpit (Admin Only) -->
        <?php if (in_array($role, ['admin', 'superadmin', 'principal'])): ?>
        <div class="col-lg-5 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-header py-3 bg-light">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-palette-fill me-2"></i> Badge Designer Configuration</h6>
                </div>
                <div class="card-body bg-white">
                    <form method="POST" action="<?= url('identity/cards/config') ?>">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Target Template Scope <span class="text-danger">*</span></label>
                            <select class="form-select shadow-sm border-primary border-opacity-50" name="card_type" required id="cardTypeSelect">
                                <option value="student">Student Smart Pass</option>
                                <option value="staff">Corporate Faculty Badge</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Header Typography <span class="text-danger">*</span></label>
                            <input type="text" class="form-control shadow-sm" name="header_text" value="STUDENT IDENTIFICATION" id="headerTextInput" required>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">Primary Hex</label>
                                <div class="input-group shadow-sm">
                                    <input type="color" class="form-control form-control-color w-25 p-1" name="primary_color" value="<?= htmlspecialchars($designStudent['primary_color']) ?>" id="primaryColorInput">
                                    <input type="text" class="form-control w-75 font-monospace text-muted" value="<?= htmlspecialchars($designStudent['primary_color']) ?>" disabled id="primaryHexPreview">
                                </div>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">Secondary Accent</label>
                                <div class="input-group shadow-sm">
                                    <input type="color" class="form-control form-control-color w-25 p-1" name="secondary_color" value="<?= htmlspecialchars($designStudent['secondary_color']) ?>" id="secondaryColorInput">
                                    <input type="text" class="form-control w-75 font-monospace text-muted" value="<?= htmlspecialchars($designStudent['secondary_color']) ?>" disabled id="secondaryHexPreview">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <div class="form-check form-switch fs-5">
                                <input class="form-check-input shadow-sm" type="checkbox" name="enable_qr" value="1" id="enableQrSwitch" <?= $designStudent['enable_qr'] ? 'checked' : '' ?>>
                                <label class="form-check-label fs-6 fw-bold text-dark mt-1" for="enableQrSwitch">Inject Cryptographic Access QR</label>
                            </div>
                        </div>

                        <div class="d-grid mt-2">
                            <button type="submit" class="btn btn-primary fw-bold shadow">
                                <i class="bi bi-gpu-card me-1"></i> Override Global Matrix
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Smart Badge Generation Grid -->
        <div class="<?= in_array($role, ['admin', 'superadmin', 'principal']) ? 'col-lg-7' : 'col-lg-12' ?> mb-4">
            <div class="card shadow h-100 border-left-secondary">
                <div class="card-header py-3 bg-dark d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-people-fill me-2"></i> Unified Credential Directory</h6>
                </div>
                <div class="card-body bg-light p-0">
                    <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                        <table class="table table-hover table-bordered bg-white mb-0 align-middle">
                            <thead class="table-dark sticky-top text-uppercase small">
                                <tr>
                                    <th class="ps-3">Target Identity Token</th>
                                    <th>Active Vector</th>
                                    <th class="text-center pe-3">Cryptographic Engine</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($users as $u): ?>
                                <tr>
                                    <td class="ps-3">
                                        <div class="fw-bold text-primary"><i class="bi bi-fingerprint me-1"></i> <?= htmlspecialchars($u['name']) ?></div>
                                        <div class="small text-muted fw-bold mt-1"><?= htmlspecialchars($u['email']) ?></div>
                                    </td>
                                    <td>
                                        <?php if(in_array($u['role'], ['student', 'parent'])): ?>
                                            <span class="badge bg-info text-dark shadow-sm px-3 py-2"><i class="bi bi-mortarboard-fill me-1"></i> <?= strtoupper($u['role']) ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger shadow-sm px-3 py-2"><i class="bi bi-briefcase-fill me-1"></i> <?= strtoupper($u['role']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center pe-3">
                                        <a href="<?= url('identity/cards/download/' . $u['id']) ?>" target="_blank" class="btn btn-sm btn-success fw-bold shadow-sm rounded-pill px-3">
                                            <i class="bi bi-printer-fill me-1"></i> Render Matrix
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($users)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-5">No identities resolved in current scope.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Just a small helper to update preview text if needed
    document.getElementById('primaryColorInput')?.addEventListener('input', function(e) {
        document.getElementById('primaryHexPreview').value = e.target.value;
    });
    document.getElementById('secondaryColorInput')?.addEventListener('input', function(e) {
        document.getElementById('secondaryHexPreview').value = e.target.value;
    });
</script>
