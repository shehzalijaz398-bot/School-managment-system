<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title ?? 'Document Verification') ?> · CodeClove Enterprise</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/lucide@latest"></script>
  <style>
    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: #f8fafc;
      color: #0f172a;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .verify-card {
      max-width: 580px;
      width: 100%;
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04);
      border: 1px solid #e2e8f0;
      overflow: hidden;
    }
  </style>
</head>
<body>

<div class="verify-card">
  <?php if (!empty($document)): ?>
    <!-- Verified Success Header -->
    <div class="p-4 text-center border-bottom bg-success-subtle">
      <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-success text-white mb-3" style="width: 56px; height: 56px;">
        <i data-lucide="check-circle" style="width: 32px; height: 32px;"></i>
      </div>
      <h3 class="fw-bold text-success mb-1">Official Document Verified</h3>
      <p class="text-muted small mb-0">This credential is authenticated against the official institutional ledger.</p>
    </div>

    <!-- Verification Details Body -->
    <div class="p-4">
      <div class="list-group list-group-flush mb-4">
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Issuing Institution:</span>
          <span class="fw-bold text-dark"><?= e($document['school_name'] ?? 'School') ?> (<?= e($document['school_code'] ?? 'SCH') ?>)</span>
        </div>
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Document Reference:</span>
          <span class="badge bg-primary-subtle text-primary fw-mono px-2.5 py-1.5" style="font-size: 13px; font-family: monospace;"><?= e($document['document_ref']) ?></span>
        </div>
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Document Title:</span>
          <span class="fw-semibold text-dark"><?= e($document['title']) ?></span>
        </div>
        <?php if (!empty($document['recipient_name'])): ?>
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Recipient:</span>
          <span class="fw-bold text-dark"><?= e($document['recipient_name']) ?></span>
        </div>
        <?php endif; ?>
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Issue / Upload Date:</span>
          <span class="text-dark"><?= date('F d, Y', strtotime($document['created_at'])) ?></span>
        </div>
        <div class="list-group-item px-0 py-2.5 d-flex justify-content-between align-items-center">
          <span class="text-muted small">Status:</span>
          <span class="badge bg-success text-white px-2.5 py-1">OFFICIALLY ISSUED &amp; ACTIVE</span>
        </div>
        <div class="list-group-item px-0 py-2.5">
          <span class="text-muted small d-block mb-1">Cryptographic Integrity Hash (SHA-256):</span>
          <code class="text-break small text-muted" style="font-size: 11px;"><?= e($document['file_hash']) ?></code>
        </div>
      </div>

      <div class="alert alert-light border small text-muted text-center mb-0">
        <i data-lucide="shield-check" class="text-success me-1" style="width: 16px; height: 16px; vertical-align: -2px;"></i>
        Guaranteed genuine and unaltered record under CodeClove Multi-Tenant Governance.
      </div>
    </div>
  <?php else: ?>
    <!-- Unverified / Invalid Header -->
    <div class="p-4 text-center border-bottom bg-danger-subtle">
      <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-danger text-white mb-3" style="width: 56px; height: 56px;">
        <i data-lucide="alert-triangle" style="width: 32px; height: 32px;"></i>
      </div>
      <h3 class="fw-bold text-danger mb-1">Document Not Verified</h3>
      <p class="text-muted small mb-0">The verification reference code could not be authenticated.</p>
    </div>

    <div class="p-4 text-center">
      <p class="text-muted small mb-4">
        The code <code><?= e($code) ?></code> does not correspond to any valid, active credential or digital record issued by our institutional network.
      </p>
      <a href="<?= e(url('login')) ?>" class="btn btn-outline-secondary btn-sm px-4">Return to Portal</a>
    </div>
  <?php endif; ?>
</div>

<script>
  if (window.lucide) window.lucide.createIcons();
</script>
</body>
</html>
