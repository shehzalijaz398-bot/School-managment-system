<?php
$layout = 'layouts/app';
?>

<!-- Document Center Cockpit Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <div class="d-flex align-items-center gap-2 mb-1">
            <h1 class="h3 fw-bold text-dark mb-0" style="letter-spacing: -0.02em;">
                <?= e($title ?? 'Digital Document Center') ?>
            </h1>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2.5 py-1 text-xs">
                Enterprise Vault
            </span>
        </div>
        <p class="text-muted small mb-0">
            Secure digital repository for student records, faculty files, admission credentials, compliance documents, and verifiable digital records.
        </p>
    </div>
    <div class="d-flex align-items-center gap-2 flex-wrap">
        <button class="btn btn-outline-primary d-inline-flex align-items-center gap-2 px-3 py-2 rounded-3 shadow-sm"
                data-bs-toggle="modal" data-bs-target="#generateRecordModal"
                style="font-size: 13px; font-weight: 600;">
            <i data-lucide="award" style="width: 16px; height: 16px;"></i>
            <span>Generate Official Record</span>
        </button>
        <button class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 rounded-3 shadow-sm"
                data-bs-toggle="modal" data-bs-target="#uploadDocModal"
                style="font-size: 13px; font-weight: 600;">
            <i data-lucide="upload-cloud" style="width: 16px; height: 16px;"></i>
            <span>Upload Document</span>
        </button>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100 rounded-3" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 36px; height: 36px;">
                        <i data-lucide="files" style="width: 18px; height: 18px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-0.5" style="font-size: 10.5px;">All Categories</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= number_format((int)($stats['total'] ?? 0)) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Stored Documents</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100 rounded-3" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 36px; height: 36px;">
                        <i data-lucide="check-circle" style="width: 18px; height: 18px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-0.5" style="font-size: 10.5px;">Verified</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= number_format((int)($stats['approved'] ?? 0)) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Approved &amp; Active</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100 rounded-3" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 36px; height: 36px;">
                        <i data-lucide="clock" style="width: 18px; height: 18px; stroke: #d97706;"></i>
                    </div>
                    <span class="badge rounded-pill bg-warning-subtle text-warning px-2 py-0.5" style="font-size: 10.5px;">Workflow</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= number_format((int)($stats['pending'] ?? 0)) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Pending Review</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100 rounded-3" style="border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 36px; height: 36px;">
                        <i data-lucide="alert-triangle" style="width: 18px; height: 18px; stroke: #dc2626;"></i>
                    </div>
                    <span class="badge rounded-pill bg-danger-subtle text-danger px-2 py-0.5" style="font-size: 10.5px;">&le; 30 Days</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= number_format((int)($stats['expiring'] ?? 0)) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Expiring Soon</div>
            </div>
        </div>
    </div>
</div>

<!-- Filter Tabs & Search Controls Card -->
<div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <!-- Category Tabs -->
            <ul class="nav nav-pills gap-1">
                <?php
                $catTabs = [
                    'all' => 'All Documents',
                    'student_record' => 'Student Records',
                    'staff_file' => 'Staff Files',
                    'admission' => 'Admissions',
                    'certificate' => 'Certificates',
                    'administrative' => 'Administration',
                    'legal_compliance' => 'Compliance',
                ];
                $activeCat = $filters['category'] ?? 'all';
                ?>
                <?php foreach ($catTabs as $catKey => $catLabel): ?>
                    <li class="nav-item">
                        <a class="nav-link py-1.5 px-3 rounded-pill text-xs fw-semibold <?= $activeCat === $catKey ? 'active bg-primary text-white' : 'text-muted bg-light' ?>" 
                           href="<?= e(url('documents?category=' . $catKey . '&status=' . urlencode($filters['status'] ?? 'all'))) ?>">
                            <?= e($catLabel) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
                <li class="nav-item">
                    <a class="nav-link py-1.5 px-3 rounded-pill text-xs fw-semibold <?= !empty($filters['expiring']) ? 'active bg-danger text-white' : 'text-danger bg-danger-subtle' ?>" 
                       href="<?= e(url('documents?expiring=1')) ?>">
                        <i data-lucide="bell" style="width: 12px; height: 12px; vertical-align: -1px;"></i>
                        Expiring Soon
                    </a>
                </li>
            </ul>

            <!-- Search Bar -->
            <form method="get" action="<?= e(url('documents')) ?>" class="d-flex align-items-center gap-2 m-0">
                <input type="hidden" name="category" value="<?= e($activeCat) ?>">
                <div class="input-group input-group-sm" style="max-width: 260px;">
                    <span class="input-group-text bg-white border-end-0 text-muted"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
                    <input type="text" name="q" class="form-control border-start-0 ps-0" placeholder="Search reference, title..." value="<?= e($filters['q'] ?? '') ?>">
                </div>
                <?php if (!empty($filters['q']) || $activeCat !== 'all' || !empty($filters['expiring'])): ?>
                    <a href="<?= e(url('documents')) ?>" class="btn btn-sm btn-outline-secondary" title="Clear Filters">Clear</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<!-- Documents Repository Table Card -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="border: 1px solid #e2e8f0 !important;">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
            <thead class="table-light text-muted" style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em;">
                <tr>
                    <th class="ps-3 py-3">Document / Ref</th>
                    <th>Category</th>
                    <th>Entity / Recipient</th>
                    <th>Version &amp; Size</th>
                    <th>Status</th>
                    <th>Expiry Date</th>
                    <th class="text-end pe-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($documents)): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <div class="cc-empty-state">
                                <div class="cc-empty-icon">
                                    <i data-lucide="folder-open"></i>
                                </div>
                                <div class="cc-empty-title">No documents found</div>
                                <div class="cc-empty-desc">
                                    No records match the current filter or category. Upload a document or generate an official record to get started.
                                </div>
                                <button class="btn btn-sm btn-primary px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#uploadDocModal">
                                    Upload Document
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($documents as $doc): ?>
                        <?php
                        $statusColors = [
                            'approved' => 'bg-success-subtle text-success border-success-subtle',
                            'under_review' => 'bg-warning-subtle text-warning border-warning-subtle',
                            'pending' => 'bg-info-subtle text-info border-info-subtle',
                            'rejected' => 'bg-danger-subtle text-danger border-danger-subtle',
                        ];
                        $badgeClass = $statusColors[$doc['review_status']] ?? 'bg-light text-muted';
                        
                        $isExpiring = false;
                        $isExpired = false;
                        if (!empty($doc['expiry_date'])) {
                            $isExpired = $doc['expiry_date'] < date('Y-m-d');
                            $isExpiring = !$isExpired && ($doc['expiry_date'] <= date('Y-m-d', strtotime('+30 days')));
                        }
                        ?>
                        <tr>
                            <td class="ps-3 py-3">
                                <div class="d-flex align-items-center gap-2.5">
                                    <div class="rounded-2 p-2 bg-light text-primary flex-shrink-0 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                        <i data-lucide="<?= str_contains($doc['mime_type'], 'pdf') ? 'file-text' : (str_contains($doc['mime_type'], 'image') ? 'image' : 'file') ?>" style="width: 16px; height: 16px;"></i>
                                    </div>
                                    <div class="min-w-0">
                                        <div class="fw-bold text-dark text-truncate d-flex align-items-center gap-1.5" style="max-width: 240px;">
                                            <span><?= e($doc['title']) ?></span>
                                            <?php if (!empty($doc['is_confidential'])): ?>
                                                <i data-lucide="lock" class="text-danger flex-shrink-0" style="width: 12px; height: 12px;" title="Confidential Document"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="d-flex align-items-center gap-2 text-muted text-xs">
                                            <span class="font-monospace text-primary fw-semibold"><?= e($doc['document_ref']) ?></span>
                                            <span>&bull;</span>
                                            <span><?= e($doc['file_name']) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge rounded-pill bg-light text-secondary border px-2 py-1 text-xs">
                                    <?= ucwords(str_replace('_', ' ', e($doc['category']))) ?>
                                </span>
                            </td>
                            <td>
                                <span class="text-dark small fw-medium"><?= ucwords(e($doc['entity_type'])) ?></span>
                                <?php if (!empty($doc['entity_id'])): ?>
                                    <span class="text-muted text-xs">#<?= (int)$doc['entity_id'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="text-dark small fw-medium">v<?= (int)$doc['version'] ?></div>
                                <div class="text-muted text-xs"><?= round($doc['file_size'] / 1024, 1) ?> KB</div>
                            </td>
                            <td>
                                <span class="badge rounded-pill border px-2 py-1 text-xs <?= $badgeClass ?>">
                                    <?= ucwords(str_replace('_', ' ', e($doc['review_status']))) ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($doc['expiry_date'])): ?>
                                    <div class="small <?= $isExpired ? 'text-danger fw-bold' : ($isExpiring ? 'text-warning fw-semibold' : 'text-dark') ?>">
                                        <?= date('M d, Y', strtotime($doc['expiry_date'])) ?>
                                    </div>
                                    <?php if ($isExpired): ?>
                                        <span class="badge bg-danger rounded-pill px-1.5 py-0 text-xs">Expired</span>
                                    <?php elseif ($isExpiring): ?>
                                        <span class="badge bg-warning text-dark rounded-pill px-1.5 py-0 text-xs">Expiring Soon</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted small">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-3">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= e(url('documents/' . $doc['document_ref'] . '/preview')) ?>" 
                                       target="_blank"
                                       class="btn btn-outline-secondary px-2" 
                                       title="Preview Document">
                                        <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                                    </a>
                                    <a href="<?= e(url('documents/' . $doc['document_ref'] . '/download')) ?>" 
                                       class="btn btn-outline-secondary px-2" 
                                       title="Download File">
                                        <i data-lucide="download" style="width: 14px; height: 14px;"></i>
                                    </a>
                                    <?php if ($isPrivileged): ?>
                                        <button type="button" 
                                                class="btn btn-outline-secondary px-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#uploadVersionModal"
                                                onclick="setVersionDocId('<?= (int)$doc['id'] ?>', '<?= e(addslashes($doc['title'])) ?>')"
                                                title="Upload New Version">
                                            <i data-lucide="upload" style="width: 14px; height: 14px;"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-outline-secondary px-2" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#reviewStatusModal"
                                                onclick="setReviewDoc('<?= (int)$doc['id'] ?>', '<?= e(addslashes($doc['title'])) ?>', '<?= e($doc['review_status']) ?>', '<?= e(addslashes($doc['reviewer_notes'] ?? '')) ?>')"
                                                title="Review Status &amp; Notes">
                                            <i data-lucide="check-square" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if (!empty($doc['verification_code'])): ?>
                                        <a href="<?= e(url('verify-document/' . $doc['verification_code'])) ?>" 
                                           target="_blank"
                                           class="btn btn-outline-secondary px-2" 
                                           title="Public Verification">
                                            <i data-lucide="shield-check" style="width: 14px; height: 14px;"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 1: UPLOAD NEW DOCUMENT               -->
<!-- ========================================== -->
<div class="modal fade" id="uploadDocModal" tabindex="-1" aria-labelledby="uploadDocModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="<?= e(url('documents')) ?>" method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <div class="d-flex align-items-center gap-2">
                        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
                            <i data-lucide="upload-cloud" style="width: 18px; height: 18px;"></i>
                        </div>
                        <div>
                            <h5 class="modal-title fw-bold fs-6 mb-0" id="uploadDocModalLabel">Upload Secure Document</h5>
                            <small class="text-muted">Encrypted vault storage with hash integrity verification</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Document Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control" placeholder="e.g. Grade 10 National Certificate" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Category <span class="text-danger">*</span></label>
                            <select name="category" class="form-select" required>
                                <option value="student_record">Student Record</option>
                                <option value="staff_file">Staff File</option>
                                <option value="admission">Admissions Credential</option>
                                <option value="certificate">Certificate</option>
                                <option value="administrative">Administrative Record</option>
                                <option value="legal_compliance">Legal &amp; Compliance</option>
                                <option value="general">General</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Entity Association</label>
                            <select name="entity_type" class="form-select">
                                <option value="general">General Institution</option>
                                <option value="student">Student Record</option>
                                <option value="employee">Staff / Faculty</option>
                                <option value="admission">Admission Applicant</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Expiry Date (Optional)</label>
                            <input type="date" name="expiry_date" class="form-control">
                            <small class="text-muted" style="font-size: 11px;">System automatically sends alerts 30 days prior to expiry</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Review / Workflow Status</label>
                            <select name="review_status" class="form-select">
                                <option value="approved" selected>Approved (Default)</option>
                                <option value="pending">Pending Approval</option>
                                <option value="under_review">Under Review</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Select File <span class="text-danger">*</span></label>
                            <input type="file" name="document_file" class="form-control" required accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.csv,.txt">
                            <small class="text-muted" style="font-size: 11px;">Supported formats: PDF, PNG, JPG, DOCX, XLSX, CSV, TXT (Max size: 10 MB)</small>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Description / Notes</label>
                            <textarea name="description" class="form-control" rows="2" placeholder="Optional background context, purpose, or reference information..."></textarea>
                        </div>
                        <div class="col-12">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_confidential" value="1" id="isConfidentialSwitch">
                                <label class="form-check-label fw-semibold small text-danger" for="isConfidentialSwitch">
                                    <i data-lucide="lock" style="width: 13px; height: 13px; vertical-align: -1px;"></i> Mark as Confidential (Restricted to Administrators &amp; HR)
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top py-2.5 px-4 d-flex justify-content-between">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-primary px-3 shadow-sm">Upload &amp; Encrypt</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 2: GENERATE OFFICIAL DIGITAL RECORD  -->
<!-- ========================================== -->
<div class="modal fade" id="generateRecordModal" tabindex="-1" aria-labelledby="generateRecordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="<?= e(url('documents/generate-record')) ?>" method="post">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <div class="d-flex align-items-center gap-2">
                        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
                            <i data-lucide="award" style="width: 18px; height: 18px;"></i>
                        </div>
                        <div>
                            <h5 class="modal-title fw-bold fs-6 mb-0" id="generateRecordModalLabel">Generate Digital Record</h5>
                            <small class="text-muted">Authenticated academic credentials with QR verification</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Credential Type <span class="text-danger">*</span></label>
                        <select name="record_type" class="form-select" required>
                            <option value="enrollment_confirmation">Enrollment &amp; Admission Confirmation</option>
                            <option value="transcript">Official Cumulative Academic Transcript</option>
                            <option value="fee_receipt">Official Fee Payment Statement</option>
                            <option value="bonafide">Bonafide Student Certificate</option>
                            <option value="transfer">School Leaving / Transfer Certificate (TC)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Select Student <span class="text-danger">*</span></label>
                        <select name="student_id" class="form-select" required>
                            <option value="">-- Choose Student --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (Adm: <?= e($st['admission_no'] ?? 'N/A') ?> &bull; <?= e($st['class_name'] ?? '') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="alert alert-light border small text-muted mb-0">
                        <i data-lucide="shield-check" class="text-primary me-1" style="width: 14px; height: 14px; vertical-align: -2px;"></i>
                        Generates a tamper-proof digital credential with verifiable tracking code and SHA-256 integrity hash.
                    </div>
                </div>
                <div class="modal-footer border-top py-2.5 px-4 d-flex justify-content-between">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-primary px-3 shadow-sm">Generate Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 3: UPLOAD NEW VERSION                -->
<!-- ========================================== -->
<div class="modal fade" id="uploadVersionModal" tabindex="-1" aria-labelledby="uploadVersionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form id="uploadVersionForm" method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <div class="d-flex align-items-center gap-2">
                        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
                            <i data-lucide="layers" style="width: 18px; height: 18px;"></i>
                        </div>
                        <div>
                            <h5 class="modal-title fw-bold fs-6 mb-0" id="uploadVersionModalLabel">Upload New Version</h5>
                            <small class="text-muted" id="versionDocTitle">Document Title</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Updated File <span class="text-danger">*</span></label>
                        <input type="file" name="version_file" class="form-control" required accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.csv,.txt">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Version Changelog / Notes</label>
                        <textarea name="changelog" class="form-control" rows="2" placeholder="Describe revisions, corrections, or updates made in this version..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-2.5 px-4 d-flex justify-content-between">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-primary px-3 shadow-sm">Upload Version</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================== -->
<!-- MODAL 4: REVIEW STATUS & NOTES             -->
<!-- ========================================== -->
<div class="modal fade" id="reviewStatusModal" tabindex="-1" aria-labelledby="reviewStatusModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form id="reviewStatusForm" method="post">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <div class="d-flex align-items-center gap-2">
                        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
                            <i data-lucide="check-square" style="width: 18px; height: 18px;"></i>
                        </div>
                        <div>
                            <h5 class="modal-title fw-bold fs-6 mb-0" id="reviewStatusModalLabel">Review Workflow Status</h5>
                            <small class="text-muted" id="reviewDocTitle">Document Title</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Workflow Approval Status <span class="text-danger">*</span></label>
                        <select name="status" id="reviewStatusSelect" class="form-select" required>
                            <option value="approved">Approved</option>
                            <option value="under_review">Under Review</option>
                            <option value="pending">Pending</option>
                            <option value="rejected">Rejected / Needs Resubmission</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Reviewer Notes</label>
                        <textarea name="reviewer_notes" id="reviewerNotesText" class="form-control" rows="3" placeholder="Provide feedback, approval rationale, or requested modifications..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-2.5 px-4 d-flex justify-content-between">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-primary px-3 shadow-sm">Update Workflow</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function setVersionDocId(id, title) {
    document.getElementById('uploadVersionForm').action = '<?= e(url('documents')) ?>/' + id + '/version';
    document.getElementById('versionDocTitle').textContent = title;
}

function setReviewDoc(id, title, currentStatus, notes) {
    document.getElementById('reviewStatusForm').action = '<?= e(url('documents')) ?>/' + id + '/status';
    document.getElementById('reviewDocTitle').textContent = title;
    document.getElementById('reviewStatusSelect').value = currentStatus;
    document.getElementById('reviewerNotesText').value = notes;
}
</script>
