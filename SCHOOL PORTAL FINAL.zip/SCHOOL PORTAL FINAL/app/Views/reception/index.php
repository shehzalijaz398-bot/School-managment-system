<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-concierge-bell text-primary me-2"></i> Reception & Front Desk</h2>
        <p class="text-muted mb-0">Manage admission inquiries and track campus visitors.</p>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-info d-flex align-items-center gap-2 shadow-sm action-hover text-white fw-bold" data-bs-toggle="modal" data-bs-target="#logVisitorModal">
            <i class="fas fa-user-clock"></i> Log Visitor
        </button>
        <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm action-hover fw-bold" data-bs-toggle="modal" data-bs-target="#addInquiryModal">
            <i class="fas fa-plus-circle"></i> Add Inquiry
        </button>
    </div>
</div>

<div class="row g-4">
    <!-- Inquiries Column -->
    <div class="col-xl-7">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4">
                <h5 class="fw-bold text-gray-800 mb-0"><i class="fas fa-headset text-primary me-2"></i> Recent Admission Inquiries</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">Inquiry Details</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Contact</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Status</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inquiries as $i): ?>
                        <tr class="reception-row">
                            <td class="px-4 py-3">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 40px; height: 40px;">
                                        <i class="fas fa-child"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($i['student_name']) ?></h6>
                                        <span class="text-xs text-muted"><i class="fas fa-user-tie me-1"></i> Parent: <?= e($i['parent_name'] ?: 'N/A') ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="py-3 text-sm">
                                <div class="text-secondary fw-semibold">
                                    <i class="fas fa-phone-alt text-muted me-1"></i> <?= e($i['phone'] ?: 'N/A') ?>
                                </div>
                            </td>
                            <td class="py-3">
                                <?= statusBadge($i['status']) ?>
                            </td>
                            <td class="px-4 py-3 text-end">
                                <form method="post" action="<?= e(url('reception/inquiries/'.$i['id'].'/status')) ?>" class="m-0 d-flex justify-content-end">
                                    <?= csrf_field() ?>
                                    <select name="status" class="form-select form-select-sm border border-light-subtle shadow-sm action-hover rounded-pill" style="width: 130px; cursor: pointer; font-size: 0.8rem;" onchange="this.form.submit()">
                                        <option value="new" <?= $i['status']==='new'?'selected':'' ?>>New</option>
                                        <option value="contacted" <?= $i['status']==='contacted'?'selected':'' ?>>Contacted</option>
                                        <option value="converted" <?= $i['status']==='converted'?'selected':'' ?>>Converted</option>
                                        <option value="closed" <?= $i['status']==='closed'?'selected':'' ?>>Closed</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($inquiries)): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">
                                <i class="fas fa-inbox fa-3x mb-3 text-light"></i>
                                <p class="mb-0">No recent inquiries.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Visitor Log Column -->
    <div class="col-xl-5">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4">
                <h5 class="fw-bold text-gray-800 mb-0"><i class="fas fa-clipboard-list text-info me-2"></i> Today's Visitor Log</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">Visitor</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Timing</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($visitors as $v): ?>
                        <tr class="reception-row">
                            <td class="px-4 py-3">
                                <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($v['visitor_name']) ?></h6>
                                <span class="text-xs text-muted d-block text-truncate" style="max-width: 150px;"><i class="fas fa-tag me-1"></i> <?= e($v['purpose'] ?: 'General Visit') ?></span>
                            </td>
                            <td class="py-3 text-sm">
                                <div class="text-success fw-bold" style="font-size: 0.75rem;"><i class="fas fa-sign-in-alt me-1"></i> <?= e(formatDate($v['check_in'], 'H:i A')) ?></div>
                                <?php if (!empty($v['check_out'])): ?>
                                    <div class="text-secondary fw-semibold mt-1" style="font-size: 0.75rem;"><i class="fas fa-sign-out-alt me-1"></i> <?= e(formatDate($v['check_out'], 'H:i A')) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-end">
                                <?php if (empty($v['check_out'])): ?>
                                    <form method="post" action="<?= e(url('reception/visitors/'.$v['id'].'/checkout')) ?>" class="m-0">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-outline-info rounded-pill px-3 shadow-sm action-hover" title="Check Out">
                                            <i class="fas fa-walking"></i> Check Out
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border rounded-pill px-2 py-1"><i class="fas fa-check"></i> Left</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($visitors)): ?>
                        <tr>
                            <td colspan="3" class="text-center py-5 text-muted">
                                <i class="fas fa-id-badge fa-3x mb-3 text-light"></i>
                                <p class="mb-0">No visitors logged today.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Inquiry Modal -->
<div class="modal fade" id="addInquiryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-primary text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle me-2"></i> Add New Inquiry</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('reception/inquiries')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    
                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-user-friends me-1"></i> Personal Details</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Student Name <span class="text-danger">*</span></label>
                            <input type="text" name="student_name" class="form-control rounded-3 shadow-sm border-0" required placeholder="Full Name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Parent / Guardian Name</label>
                            <input type="text" name="parent_name" class="form-control rounded-3 shadow-sm border-0" placeholder="Full Name">
                        </div>
                    </div>

                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-address-book me-1"></i> Contact & Interest</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Phone Number</label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-phone text-muted"></i></span>
                                <input type="text" name="phone" class="form-control border-0 bg-white" placeholder="Contact Number">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Class of Interest</label>
                            <select name="interested_class_id" class="form-select rounded-3 shadow-sm border-0">
                                <option value="">Select a class...</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-sm fw-semibold">Additional Notes</label>
                            <textarea name="notes" rows="2" class="form-control rounded-3 shadow-sm border-0" placeholder="Any specific requirements or questions..."></textarea>
                        </div>
                    </div>

                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-save me-1"></i> Save Inquiry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Log Visitor Modal -->
<div class="modal fade" id="logVisitorModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-info text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-clock me-2"></i> Log New Visitor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('reception/visitors')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Visitor Name <span class="text-danger">*</span></label>
                        <div class="input-group shadow-sm rounded-3 overflow-hidden">
                            <span class="input-group-text bg-white border-0"><i class="fas fa-id-badge text-muted"></i></span>
                            <input type="text" name="visitor_name" class="form-control border-0 bg-white" required placeholder="Full Name">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Purpose of Visit</label>
                        <input type="text" name="purpose" class="form-control rounded-3 shadow-sm border-0" placeholder="e.g. Meeting Principal, Delivery">
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Person to Meet</label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-user-tie text-muted"></i></span>
                                <input type="text" name="person_to_meet" class="form-control border-0 bg-white" placeholder="Staff Name">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Phone Number</label>
                            <input type="text" name="phone" class="form-control rounded-3 shadow-sm border-0" placeholder="Contact Info">
                        </div>
                    </div>

                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-info text-white rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-sign-in-alt me-1"></i> Check In</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* Premium Hover Effects */
    .reception-row {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        border-radius: 12px;
    }
    .reception-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px -10px rgba(0, 0, 0, 0.1);
        z-index: 10;
        position: relative;
    }
    .reception-row:hover .avatar {
        transform: scale(1.15) rotate(5deg);
        box-shadow: 0 4px 10px rgba(13, 110, 253, 0.2) !important;
    }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15) !important;
    }
    
    .table > :not(caption) > * > * {
        border-bottom-color: #f1f5f9;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
    }
</style>
