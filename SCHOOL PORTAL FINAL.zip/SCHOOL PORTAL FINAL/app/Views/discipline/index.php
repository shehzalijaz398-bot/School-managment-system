<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-shield-exclamation text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
    </div>

    <!-- Active Disciplinary Notices for Students/Parents -->
    <?php if (in_array($role, ['student', 'parent'])): ?>
        <?php foreach($logs as $log): ?>
            <?php if ($log['status'] === 'active'): ?>
            <div class="alert alert-danger shadow-sm border-left-danger rounded-0 mb-4 d-flex align-items-center justify-content-between">
                <div>
                    <i class="bi bi-exclamation-triangle-fill fs-4 me-2"></i>
                    <strong>⚠️ DISCIPLINARY NOTICE:</strong> <?= $log['points_impact'] ?> Points deducted for [<?= htmlspecialchars($log['incident_title']) ?>].
                </div>
                <form method="POST" action="<?= url('discipline/incident/appeal') ?>" class="m-0">
                    <?= csrf_field() ?>
                    <input type="hidden" name="incident_id" value="<?= $log['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger fw-bold">Submit Official Appeal</button>
                </form>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="row">
        <!-- Report Form (Hidden from Students/Parents) -->
        <?php if (in_array($role, ['teacher', 'admin', 'principal', 'superadmin'])): ?>
        <div class="col-lg-4 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-header py-3 bg-light">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-file-earmark-plus-fill me-2"></i> File Incident Log</h6>
                </div>
                <div class="card-body bg-white">
                    <form method="POST" action="<?= url('discipline/incident/report') ?>">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Target Student <span class="text-danger">*</span></label>
                            <select class="form-select shadow-sm" name="student_id" required>
                                <option value="" disabled selected>Select active student...</option>
                                <?php foreach($students as $s): ?>
                                    <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Incident Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control shadow-sm" name="incident_title" placeholder="e.g. Disruption during Lecture" required>
                        </div>

                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">Points Impact</label>
                                <select class="form-select shadow-sm text-danger fw-bold" name="points_impact">
                                    <option value="0">0 (Warning)</option>
                                    <option value="-5">-5 (Minor)</option>
                                    <option value="-10" selected>-10 (Moderate)</option>
                                    <option value="-20">-20 (Severe)</option>
                                    <option value="-30">-30 (Suspension Trigger)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">Action Type</label>
                                <select class="form-select shadow-sm" name="action_type">
                                    <option value="warning">Warning</option>
                                    <option value="detention">Detention</option>
                                    <option value="fine">Financial Penalty</option>
                                    <option value="suspension">Suspension</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark small">Property Damage Fine ($)</label>
                            <input type="number" step="0.01" class="form-control shadow-sm" name="fine_amount" value="0.00">
                            <div class="form-text small text-muted"><i class="bi bi-info-circle"></i> Auto-generates invoice penalty line item.</div>
                        </div>

                        <div class="d-grid mt-2">
                            <button type="submit" class="btn btn-danger fw-bold shadow">
                                <i class="bi bi-hammer me-1"></i> File Incident & Deduct
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Active Disciplinary Trajectories -->
        <div class="<?= in_array($role, ['teacher', 'admin', 'principal', 'superadmin']) ? 'col-lg-8' : 'col-lg-12' ?> mb-4">
            
            <?php if (in_array($role, ['admin', 'principal', 'superadmin']) && !empty($leaderboard)): ?>
            <!-- Leaderboard / Defaulters (Admin Only) -->
            <div class="card shadow mb-4 border-left-danger">
                <div class="card-header py-3 bg-dark d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-graph-down-arrow me-2"></i> Critical Defaulters Trigger List</h6>
                </div>
                <div class="card-body bg-light p-3">
                    <div class="d-flex flex-wrap gap-2">
                        <?php foreach($leaderboard as $def): ?>
                            <div class="badge bg-danger p-2 shadow-sm d-flex align-items-center">
                                <span class="me-2"><?= htmlspecialchars($def['name']) ?></span>
                                <span class="bg-white text-danger fw-bold rounded px-1"><?= $def['total_points'] ?> pt</span>
                                <?php if ($def['total_points'] <= -30): ?>
                                    <form method="POST" action="<?= url('discipline/incident/action') ?>" class="m-0 ms-2">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="clear_suspension">
                                        <input type="hidden" name="student_id" value="<?= $def['id'] ?>">
                                        <button type="submit" class="btn btn-xs btn-outline-light border-0 py-0 px-1" title="Clear Suspension & Reset Points"><i class="bi bi-arrow-counterclockwise"></i></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="card shadow h-100">
                <div class="card-header py-3 bg-secondary d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-clock-history me-2"></i> Behavioural Ledger History</h6>
                </div>
                <div class="card-body bg-white p-0">
                    <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                        <table class="table table-hover table-bordered mb-0 align-middle">
                            <thead class="table-light sticky-top text-uppercase small">
                                <tr>
                                    <th class="ps-3">Target Student</th>
                                    <th>Incident Payload</th>
                                    <th>Impact</th>
                                    <th class="text-center pe-3">Lifecycle State</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($logs as $log): ?>
                                <tr>
                                    <td class="ps-3">
                                        <div class="fw-bold text-primary"><i class="bi bi-person-fill me-1"></i> <?= htmlspecialchars($log['student_name']) ?></div>
                                        <div class="small text-muted fw-bold mt-1">Rep: <?= htmlspecialchars($log['reporter_name']) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($log['incident_title']) ?></div>
                                        <div class="small text-muted fw-bold">
                                            <?= date('M d, Y H:i', strtotime($log['created_at'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger shadow-sm fs-6"><?= $log['points_impact'] ?></span>
                                        <?php if ($log['fine_amount'] > 0): ?>
                                            <span class="badge bg-warning text-dark ms-1 shadow-sm">$<?= $log['fine_amount'] ?> Fine</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center pe-3">
                                        <?php if($log['status'] === 'active'): ?>
                                            <span class="badge bg-primary shadow-sm w-100 mb-1">Active</span>
                                        <?php elseif($log['status'] === 'appealed'): ?>
                                            <span class="badge bg-warning text-dark shadow-sm w-100 mb-1 pulse-btn">Pending Appeal</span>
                                        <?php elseif($log['status'] === 'voided'): ?>
                                            <span class="badge bg-success shadow-sm w-100 mb-1">Voided</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary shadow-sm w-100 mb-1"><?= ucfirst($log['status']) ?></span>
                                        <?php endif; ?>
                                        
                                        <!-- Appeal Resolution Actions (HR/Principal Only) -->
                                        <?php if ($log['status'] === 'appealed' && in_array($role, ['admin', 'principal', 'superadmin'])): ?>
                                            <div class="btn-group w-100 mt-1 shadow-sm">
                                                <form method="POST" action="<?= url('discipline/incident/action') ?>" class="m-0 w-50">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="incident_id" value="<?= $log['id'] ?>">
                                                    <input type="hidden" name="action" value="approve_appeal">
                                                    <button type="submit" class="btn btn-sm btn-success w-100 rounded-start rounded-0" title="Void Points"><i class="bi bi-check-lg"></i></button>
                                                </form>
                                                <form method="POST" action="<?= url('discipline/incident/action') ?>" class="m-0 w-50">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="incident_id" value="<?= $log['id'] ?>">
                                                    <input type="hidden" name="action" value="reject_appeal">
                                                    <button type="submit" class="btn btn-sm btn-danger w-100 rounded-end rounded-0" title="Reject Appeal"><i class="bi bi-x-lg"></i></button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($logs)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-5"><i class="bi bi-shield-check fs-1 d-block mb-3 text-success"></i> No behavioral incidents recorded.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .pulse-btn {
        animation: pulse-warning-anim 2s infinite;
    }
    @keyframes pulse-warning-anim {
        0% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(255, 193, 7, 0); }
        100% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0); }
    }
</style>
