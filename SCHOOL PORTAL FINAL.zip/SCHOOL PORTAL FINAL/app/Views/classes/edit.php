<div class="d-flex align-items-center mb-4">
  <a href="<?= e(url('classes')) ?>" class="btn btn-light btn-sm me-3 d-flex align-items-center justify-content-center" style="width:36px;height:36px;border-radius:50%; transition:all 0.2s;" onmouseover="this.style.background='var(--sp-light)'; this.style.transform='scale(1.1)';" onmouseout="this.style.background=''; this.style.transform='scale(1)';">
    <i data-lucide="arrow-left" style="width:18px;height:18px;"></i>
  </a>
  <div>
    <h2 class="mb-0" style="font-size:1.25rem; color:var(--sp-primary-dark);"><?= e($title) ?></h2>
    <div class="small text-muted mt-1">Manage class name, assigned subjects, and all sections here.</div>
  </div>
</div>

<form method="post" action="<?= e(url('classes/'.$class['id'])) ?>">
  <?= csrf_field() ?>
  
  <div class="row g-4">
    <!-- Left Column: Class & Subjects -->
    <div class="col-lg-4 d-flex flex-column gap-4">
      
      <!-- Class Setup Card -->
      <div class="card border-0 shadow-sm flex-grow-1 hover-card" style="border-radius:1rem;">
        <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4">
          <h3 class="mb-0 d-flex align-items-center gap-2" style="font-size:1.1rem; color:var(--sp-primary);">
            <i data-lucide="settings" style="color:var(--sp-accent);"></i> Class Setup
          </h3>
        </div>
        <div class="card-body p-4 pt-2 d-flex flex-column gap-4">
          
          <!-- Class Name -->
          <div>
            <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1 mb-2"><i data-lucide="pen-tool" style="width:14px;height:14px;color:var(--sp-accent);"></i> Class Name</label>
            <input name="name" class="form-control form-control-lg fs-6" value="<?= e($class['name'] ?? old('name')) ?>" required placeholder="e.g. Class 1" style="border-radius:0.75rem; background:#f8fafc; border:1px solid #e2e8f0; transition:all 0.2s;" onfocus="this.style.background='#fff'; this.style.borderColor='var(--sp-accent)'; this.style.boxShadow='0 0 0 0.25rem rgba(2,169,216,0.15)';">
          </div>

          <hr class="m-0 text-muted" style="opacity:0.15;">

          <!-- Manage Subjects -->
          <div class="d-flex flex-column flex-grow-1">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1 mb-0"><i data-lucide="library" style="width:14px;height:14px;color:var(--sp-accent);"></i> Assigned Subjects</label>
              <span class="badge bg-light text-dark border rounded-pill shadow-sm" id="subject-count-badge">0</span>
            </div>
            
            <!-- Selected Subjects Container -->
            <div id="selected-subjects-container" class="d-flex flex-wrap gap-2 mb-4 p-3" style="min-height: 100px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:0.75rem;">
              <!-- Badges will be injected here via JS -->
            </div>

            <div class="mt-auto">
              <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1 mb-2"><i data-lucide="plus-circle" style="width:14px;height:14px;color:var(--sp-success);"></i> Add Subject from Library</label>
              <div class="input-group mb-4 shadow-sm" style="border-radius:0.75rem;">
                <select id="subject-dropdown" class="form-select border-0" style="border-radius:0.75rem 0 0 0.75rem; cursor:pointer; background:#fff;">
                  <option value="">-- Choose Subject --</option>
                  <?php foreach($allSubjects as $sub): ?>
                    <option value="<?= $sub['id'] ?>"><?= e($sub['name']) ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="button" class="btn btn-primary px-4 fw-medium" id="btn-add-subject" style="border-radius:0 0.75rem 0.75rem 0; background:var(--sp-accent); border-color:var(--sp-accent);">Add</button>
              </div>
              
              <div class="border-top pt-4">
                <label class="form-label text-muted small fw-medium d-flex align-items-center gap-1 mb-2"><i data-lucide="edit-3" style="width:14px;height:14px;"></i> Or Create Custom Subject</label>
                <div class="input-group">
                  <input type="text" id="custom-subject-input" class="form-control form-control-sm" placeholder="Type new subject name..." style="border-radius:0.5rem 0 0 0.5rem; background:#f8fafc; border:1px solid #e2e8f0;">
                  <button type="button" class="btn btn-outline-primary btn-sm bg-white fw-medium" id="btn-create-subject" style="border-radius:0 0.5rem 0.5rem 0; border:1px solid #e2e8f0; border-left:0; color:var(--sp-primary);">Create</button>
                </div>
                <small class="text-success d-none mt-2 fw-medium" id="custom-subject-msg"><i data-lucide="check-circle" style="width:12px;height:12px;"></i> Created & Added to class!</small>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- Right Column: Sections Details -->
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm h-100" style="border-radius:1rem; transition:transform 0.2s;" onmouseover="this.style.transform='translateY(-2px)';" onmouseout="this.style.transform='translateY(0)';">
        <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
          <h3 class="mb-0 d-flex align-items-center gap-2" style="font-size:1.1rem; color:var(--sp-primary);">
            <i data-lucide="layout-grid" style="color:var(--sp-accent);"></i> Manage Sections
          </h3>
          <span class="badge bg-light text-dark border rounded-pill"><?= count($sections) ?> Section(s)</span>
        </div>
        <div class="card-body p-4 pt-2">
          <?php if(empty($sections)): ?>
            <div class="text-center text-muted py-5 rounded bg-light border border-dashed">
              <i data-lucide="info" style="width:32px;height:32px;opacity:0.5;margin-bottom:0.5rem;"></i>
              <p class="mb-0">No sections added yet.<br>Go back to the classes page to add a section.</p>
            </div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table align-middle border" style="border-radius:0.5rem; overflow:hidden;">
                <thead class="bg-light text-muted small">
                  <tr>
                    <th class="ps-3 border-0 rounded-start">Section Name</th>
                    <th class="border-0">Capacity</th>
                    <th class="border-0 rounded-end">Class Teacher (Optional)</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($sections as $sec): ?>
                  <tr style="transition:background 0.2s;" onmouseover="this.style.background='rgba(0,0,0,0.01)';" onmouseout="this.style.background='';">
                    <td class="ps-3">
                      <div class="d-flex align-items-center gap-2">
                        <i data-lucide="users" style="width:16px;height:16px;color:var(--sp-primary);opacity:0.6;"></i>
                        <input type="text" name="sections[<?= $sec['id'] ?>][name]" class="form-control form-control-sm" value="<?= e($sec['name']) ?>" required style="border-radius:0.3rem;">
                      </div>
                    </td>
                    <td style="width:120px;">
                      <input type="number" name="sections[<?= $sec['id'] ?>][capacity]" class="form-control form-control-sm" value="<?= (int)$sec['capacity'] ?>" required min="1" style="border-radius:0.3rem;">
                    </td>
                    <td class="pe-3">
                      <select name="sections[<?= $sec['id'] ?>][class_teacher_id]" class="form-select form-select-sm" style="border-radius:0.3rem;">
                        <option value="">None</option>
                        <?php foreach($teachers as $t): ?>
                          <option value="<?= (int)$t['id'] ?>" <?= $t['id'] == $sec['class_teacher_id'] ? 'selected' : '' ?>><?= e($t['first_name'].' '.$t['last_name']) ?></option>
                        <?php endforeach; ?>
                      </select>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Actions -->
  <div class="mt-4 d-flex justify-content-between align-items-center bg-white p-3 rounded shadow-sm border border-light" style="border-radius:1rem !important;">
    <div class="small text-muted d-flex align-items-center gap-2">
      <i data-lucide="shield-check" style="width:16px;height:16px;color:var(--sp-success);"></i> All changes will be saved securely
    </div>
    <div class="d-flex gap-3">
      <a href="<?= e(url('classes')) ?>" class="btn btn-light d-flex align-items-center gap-2 px-4 py-2" style="border-radius:0.5rem; transition:transform 0.1s;" onmouseover="this.style.transform='scale(1.02)';" onmouseout="this.style.transform='scale(1)';">Cancel</a>
      <button type="submit" class="btn btn-primary d-flex align-items-center gap-2 px-4 py-2" style="border-radius:0.5rem; background:var(--sp-primary-dark); border-color:var(--sp-primary-dark); transition:transform 0.1s;" onmouseover="this.style.transform='scale(1.02)';" onmouseout="this.style.transform='scale(1)';">
        <i data-lucide="save" style="width:18px;height:18px;"></i> Save All Changes
      </button>
    </div>
  </div>
  
  <!-- Hidden inputs container for subject ids -->
  <div id="hidden-subject-inputs"></div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const existingSubjectIds = <?= json_encode($classSubjectIds) ?>;
    const allSubjects = <?= json_encode($allSubjects) ?>;
    
    let selectedSubjects = existingSubjectIds.map(id => parseInt(id));
    
    const container = document.getElementById('selected-subjects-container');
    const dropdown = document.getElementById('subject-dropdown');
    const btnAdd = document.getElementById('btn-add-subject');
    const hiddenInputsContainer = document.getElementById('hidden-subject-inputs');
    const badgeCount = document.getElementById('subject-count-badge');
    
    // Custom subject elements
    const customInput = document.getElementById('custom-subject-input');
    const btnCreate = document.getElementById('btn-create-subject');
    const customMsg = document.getElementById('custom-subject-msg');

    function getSubjectIcon(name) {
        name = name.toLowerCase();
        if (name.includes('math')) return 'calculator';
        if (name.includes('sci')) return 'microscope';
        if (name.includes('eng')) return 'book-open';
        if (name.includes('urd')) return 'book';
        if (name.includes('isl')) return 'moon';
        if (name.includes('art') || name.includes('draw')) return 'palette';
        if (name.includes('comp')) return 'monitor';
        if (name.includes('phy')) return 'atom';
        if (name.includes('chem')) return 'flask-conical';
        if (name.includes('bio')) return 'dna';
        if (name.includes('hist') || name.includes('stud')) return 'globe';
        return 'bookmark';
    }

    function renderSubjects() {
        container.innerHTML = '';
        hiddenInputsContainer.innerHTML = '';
        
        if (selectedSubjects.length === 0) {
            container.innerHTML = '<div class="small text-muted w-100 py-2 d-flex align-items-center gap-2"><i data-lucide="info" style="width:14px;height:14px;opacity:0.5;"></i> No subjects assigned yet. Add one below.</div>';
        }
        
        selectedSubjects.forEach(subId => {
            const sub = allSubjects.find(s => parseInt(s.id) === subId);
            if (!sub) return;
            
            // UI Badge
            const badge = document.createElement('div');
            badge.className = 'badge d-flex align-items-center gap-2 py-2 px-3';
            badge.style.background = 'rgba(2, 169, 216, 0.1)';
            badge.style.color = 'var(--sp-accent)';
            badge.style.border = '1px solid rgba(2, 169, 216, 0.2)';
            badge.style.borderRadius = '2rem';
            badge.style.fontSize = '0.85rem';
            badge.style.transition = 'all 0.2s';
            
            const iconName = getSubjectIcon(sub.name);
            badge.innerHTML = `
                <i data-lucide="${iconName}" style="width:14px;height:14px;"></i>
                ${sub.name}
                <button type="button" class="btn-close btn-close-sm ms-1 remove-subject" data-id="${sub.id}" style="font-size:0.5rem;"></button>
            `;
            container.appendChild(badge);
            
            // Hidden Input
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'subject_ids[]';
            input.value = sub.id;
            hiddenInputsContainer.appendChild(input);
        });
        
        badgeCount.textContent = selectedSubjects.length;
        if(window.lucide) window.lucide.createIcons();
        
        // Attach remove events
        document.querySelectorAll('.remove-subject').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const idToRemove = parseInt(this.getAttribute('data-id'));
                selectedSubjects = selectedSubjects.filter(id => id !== idToRemove);
                renderSubjects();
            });
        });
    }

    btnAdd.addEventListener('click', function() {
        const val = parseInt(dropdown.value);
        if (!val) return;
        if (!selectedSubjects.includes(val)) {
            selectedSubjects.push(val);
            renderSubjects();
        }
        dropdown.value = '';
    });
    
    // Custom subject creation via AJAX
    btnCreate.addEventListener('click', async function() {
        const name = customInput.value.trim();
        if (!name) return;
        
        btnCreate.disabled = true;
        btnCreate.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        
        const formData = new FormData();
        formData.append('name', name);
        formData.append('<?= app_config("csrf_token_name") ?>', '<?= \Core\CSRF::token() ?>');
        
        try {
            const res = await fetch('<?= url("subjects/ajax") ?>', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            
            if (data.success) {
                // Add to global subjects array if not already there
                const id = parseInt(data.id);
                if (!allSubjects.find(s => parseInt(s.id) === id)) {
                    allSubjects.push({id: id, name: data.name});
                    // Also add to dropdown
                    const opt = document.createElement('option');
                    opt.value = id;
                    opt.textContent = data.name;
                    dropdown.appendChild(opt);
                }
                
                if (!selectedSubjects.includes(id)) {
                    selectedSubjects.push(id);
                    renderSubjects();
                }
                
                customInput.value = '';
                customMsg.classList.remove('d-none');
                setTimeout(() => customMsg.classList.add('d-none'), 3000);
            } else {
                alert(data.message || 'Error creating subject');
            }
        } catch (e) {
            console.error(e);
            alert('Network error while saving subject.');
        } finally {
            btnCreate.disabled = false;
            btnCreate.textContent = 'Create';
        }
    });

    // Initial render
    renderSubjects();
});
</script>
