<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex align-items-center gap-2">
    <div class="bg-primary bg-opacity-10 text-primary p-2 rounded-3">
      <i data-lucide="user-plus"></i>
    </div>
    <h2 class="mb-0 h4 fw-bold text-dark">New Admission</h2>
  </div>
  <a href="<?= e(url('admissions')) ?>" class="btn btn-outline-secondary d-flex align-items-center gap-2">
    <i data-lucide="arrow-left" style="width:18px;"></i> Back to Admissions
  </a>
</div>

<div class="row justify-content-center">
  <div class="col-lg-10">
    <div class="panel border-0 shadow-sm p-4">
      <form method="post" action="<?= e(url('admissions')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        
        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="user" class="text-primary me-2"></i> Applicant Details</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Applicant Name <span class="text-danger">*</span></label>
            <input type="text" name="student_name" class="form-control" placeholder="Full Name" required>
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold">Gender</label>
            <select name="gender" class="form-select">
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold">Date of Birth</label>
            <input type="date" name="date_of_birth" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Requested Class <span class="text-danger">*</span></label>
            <select name="class_id" class="form-select" required>
              <option value="">Select Class...</option>
              <?php foreach ($classes as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Requested Section (Optional)</label>
            <!-- Usually dynamically loaded, keeping text/select simple here -->
            <input type="text" name="section_id" class="form-control" placeholder="Section Name / ID">
          </div>
        </div>

        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="users" class="text-info me-2"></i> Parent / Guardian Information</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-4">
            <label class="form-label fw-semibold">Parent/Guardian Name</label>
            <input type="text" name="parent_name" class="form-control" placeholder="Full Name">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">Parent Phone <span class="text-danger">*</span></label>
            <input type="text" name="parent_phone" class="form-control" placeholder="+1..." required>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">Parent Email</label>
            <input type="email" name="parent_email" class="form-control" placeholder="email@example.com">
          </div>
        </div>
        
        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="file-text" class="text-warning me-2"></i> Additional Details</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Initial Status</label>
            <select name="status" class="form-select">
              <option value="application">Application Received (New)</option>
              <option value="documents">Awaiting Documents</option>
              <option value="review">Under Review</option>
              <option value="approved">Approved</option>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold">Notes / Previous School Information</label>
            <textarea name="notes" class="form-control" rows="4" placeholder="Any relevant academic history, medical notes, or comments..."></textarea>
          </div>
        </div>

        <div class="text-end border-top pt-4">
          <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm d-flex align-items-center gap-2 ms-auto">
            <i data-lucide="check-circle" style="width:18px;"></i> Submit Application
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
