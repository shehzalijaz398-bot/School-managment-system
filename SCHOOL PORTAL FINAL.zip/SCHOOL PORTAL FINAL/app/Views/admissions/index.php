<?php
/**
 * Admission Applications Dashboard - CodeClove School Management Pro UI Match
 */
?>

<!-- Breadcrumbs & Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Students</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Admission Applications</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Admission Applications Dashboard</h1>
      <p class="text-muted small mb-0">Review incoming student applications, manage document checks, and convert accepted applicants to registered students.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
      <!-- New Application Trigger -->
      <button type="button" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#newAdmissionModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; height: 38px;">
        <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
        <span>New Application</span>
      </button>
    </div>
  </div>
</div>

<!-- 4-Filter Interactive Control Bar (Matches Screenshot) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3">
    <form method="get" action="<?= e(url('admissions')) ?>" id="admissionsFilterForm" class="row g-2 align-items-center m-0">
      <input type="hidden" name="limit" value="<?= (int)($limit ?? 10) ?>">
      <input type="hidden" name="sort" value="<?= e($sort ?? 'date') ?>">
      <input type="hidden" name="dir" value="<?= e($dir ?? 'desc') ?>">

      <!-- Filter 1: Search Applicants -->
      <div class="col-12 col-md-4">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Search Applicants</label>
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 10px; width: 15px; height: 15px;"></i>
          <input type="text" name="search" id="searchApplicantsInput" value="<?= e($filters['search'] ?? '') ?>" class="form-control form-control-sm ps-5" placeholder="Search by name, reference..." style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;">
          <?php if (!empty($filters['search'])): ?>
            <a href="<?= e(url('admissions')) ?>" class="position-absolute text-muted" style="right: 10px; top: 10px;" title="Clear search">
              <i data-lucide="x" style="width: 14px; height: 14px;"></i>
            </a>
          <?php endif; ?>
        </div>
      </div>

      <!-- Filter 2: Class -->
      <div class="col-12 col-sm-6 col-md-3">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Class</label>
        <select name="class_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="0">All classes</option>
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((int)($filters['class_id'] ?? 0) === (int)$c['id']) ? 'selected' : '' ?>>
              <?= e($c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Filter 3: Status -->
      <div class="col-12 col-sm-6 col-md-2">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Status</label>
        <select name="status" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="">All statuses</option>
          <option value="accepted" <?= (($filters['status'] ?? '') === 'accepted' || ($filters['status'] ?? '') === 'approved') ? 'selected' : '' ?>>Accepted</option>
          <option value="admitted" <?= (($filters['status'] ?? '') === 'admitted' || ($filters['status'] ?? '') === 'enrolled') ? 'selected' : '' ?>>Admitted</option>
          <option value="rejected" <?= (($filters['status'] ?? '') === 'rejected') ? 'selected' : '' ?>>Rejected</option>
          <option value="withdrawn" <?= (($filters['status'] ?? '') === 'withdrawn') ? 'selected' : '' ?>>Withdrawn</option>
          <option value="application" <?= (($filters['status'] ?? '') === 'application') ? 'selected' : '' ?>>Under Review</option>
          <option value="documents" <?= (($filters['status'] ?? '') === 'documents') ? 'selected' : '' ?>>Documents Pending</option>
        </select>
      </div>

      <!-- Filter 4: Submission Date & Export Button -->
      <div class="col-12 col-md-3">
        <label class="form-label small fw-semibold text-secondary mb-1" style="font-size: 11px; letter-spacing: 0.03em;">Submission Date</label>
        <div class="d-flex align-items-center gap-2">
          <select name="date" class="form-select form-select-sm" style="height: 38px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
            <option value="all" <?= (($filters['date'] ?? 'all') === 'all') ? 'selected' : '' ?>>All time</option>
            <option value="today" <?= (($filters['date'] ?? '') === 'today') ? 'selected' : '' ?>>Today</option>
            <option value="week" <?= (($filters['date'] ?? '') === 'week') ? 'selected' : '' ?>>Last 7 days</option>
            <option value="month" <?= (($filters['date'] ?? '') === 'month') ? 'selected' : '' ?>>Last 30 days</option>
          </select>
          <a href="<?= e(url('admissions/export-csv')) ?>" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center justify-content-center flex-shrink-0" style="width: 38px; height: 38px; border-radius: 8px; border-color: #cbd5e1;" title="Export Applications to CSV">
            <i data-lucide="download" style="width: 15px; height: 15px;"></i>
          </a>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Bulk Action Floating Bar -->
<form method="post" action="<?= e(url('admissions/bulk-action')) ?>" id="bulkAdmissionsForm">
  <?= csrf_field() ?>
  <div id="bulkActionBar" class="card border-0 shadow-sm mb-3 d-none" style="border-radius: 10px; background: #f8fafc; border: 1px solid #cbd5e1 !important;">
    <div class="card-body p-2 px-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary rounded-pill px-2 py-1" id="selectedCountBadge" style="background-color: #4f46e5 !important;">0</span>
        <span class="small fw-semibold text-dark">application(s) selected</span>
      </div>
      <div class="d-flex align-items-center gap-2">
        <select name="bulk_status" class="form-select form-select-sm" style="width: 140px; height: 32px; border-radius: 6px; font-size: 12px;">
          <option value="accepted">Set Accepted</option>
          <option value="admitted">Set Admitted</option>
          <option value="rejected">Set Rejected</option>
          <option value="withdrawn">Set Withdrawn</option>
          <option value="review">Set Under Review</option>
        </select>
        <button type="submit" name="action" value="status" class="btn btn-sm btn-outline-secondary fw-medium" style="height: 32px; border-radius: 6px; font-size: 12px;">
          Apply Status
        </button>
        <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger fw-medium d-inline-flex align-items-center gap-1" style="height: 32px; border-radius: 6px; font-size: 12px;" onclick="return confirm('Are you sure you want to delete selected applications?')">
          <i data-lucide="trash-2" style="width: 13px; height: 13px;"></i>
          <span>Delete</span>
        </button>
        <button type="button" class="btn btn-sm btn-link text-muted p-0 ms-2" onclick="clearSelectedRows()" title="Cancel Selection">
          <i data-lucide="x" style="width: 16px; height: 16px;"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- Applications Table Card -->
  <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; overflow: hidden;">
    <?php if (empty($admissions)): ?>
      <div class="text-center py-5 my-3">
        <div class="d-inline-flex align-items-center justify-content-center rounded-circle mb-3" style="width: 56px; height: 56px; background: #f8fafc; border: 1px solid #e2e8f0;">
          <i data-lucide="clipboard-list" style="width: 26px; height: 26px; color: #94a3b8;"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1" style="font-size: 16px;">No Admission Applications Found</h5>
        <p class="text-muted small mb-3">No applications found matching your criteria. Create a manual applicant or adjust filters.</p>
        <button type="button" class="btn btn-sm btn-primary px-3 py-2 fw-semibold" data-bs-toggle="modal" data-bs-target="#newAdmissionModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
          <span>New Application</span>
        </button>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle mb-0" id="admissionsTable">
          <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
            <tr style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
              <!-- Select All Checkbox -->
              <th class="ps-3 py-3" style="width: 40px;">
                <div class="form-check m-0">
                  <input class="form-check-input" type="checkbox" id="selectAllCheckbox" style="border-color: #cbd5e1; cursor: pointer;" onchange="toggleSelectAll(this)">
                </div>
              </th>

              <!-- Column: REFERENCE -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('reference')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>REFERENCE</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: APPLICANT NAME -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('name')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>APPLICANT NAME</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: CLASS -->
              <th class="py-3 fw-bold">CLASS</th>

              <!-- Column: PRIMARY PARENT / GUARDIAN -->
              <th class="py-3 fw-bold">PRIMARY PARENT / GUARDIAN</th>

              <!-- Column: SUBMISSION DATE -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('date')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>SUBMISSION DATE</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: STATUS -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('status')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>STATUS</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: ACTIONS -->
              <th class="pe-3 py-3 fw-bold text-end" style="width: 120px;">ACTIONS</th>
            </tr>
          </thead>
          <tbody style="font-size: 13px;">
            <?php foreach ($admissions as $a): ?>
              <?php
                // Status Mapping & Badge Styling (Matching Screenshot)
                $st = strtolower($a['status']);
                if ($st === 'rejected') {
                    $badgeStyle = 'background: #fef2f2; color: #dc2626; border: 1px solid #fee2e2;';
                    $statusLabel = 'Rejected';
                } elseif ($st === 'accepted' || $st === 'approved') {
                    $badgeStyle = 'background: #f0fdf4; color: #16a34a; border: 1px solid #dcfce7;';
                    $statusLabel = 'Accepted';
                } elseif ($st === 'admitted' || $st === 'enrolled') {
                    $badgeStyle = 'background: #ecfeff; color: #0891b2; border: 1px solid #cffafe;';
                    $statusLabel = 'Admitted';
                } elseif ($st === 'withdrawn' || $st === 'inquiry') {
                    $badgeStyle = 'background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;';
                    $statusLabel = 'Withdrawn';
                } else {
                    $badgeStyle = 'background: #fefce8; color: #ca8a04; border: 1px solid #fef9c3;';
                    $statusLabel = 'Under Review';
                }

                $formattedDate = date('d/m/Y', strtotime($a['created_at']));
              ?>
              <tr class="admission-row" style="border-bottom: 1px solid #f1f5f9;">
                <!-- Checkbox -->
                <td class="ps-3 py-3">
                  <div class="form-check m-0">
                    <input class="form-check-input admission-checkbox" type="checkbox" name="admission_ids[]" value="<?= (int)$a['id'] ?>" style="border-color: #cbd5e1; cursor: pointer;" onchange="updateSelectedCount()">
                  </div>
                </td>

                <!-- Reference -->
                <td class="py-3">
                  <span class="text-secondary fw-medium" style="font-family: monospace; font-size: 12px; letter-spacing: 0.02em;">
                    <?= e($a['application_no']) ?>
                  </span>
                </td>

                <!-- Applicant Name -->
                <td class="py-3">
                  <span class="fw-semibold text-dark" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#viewAppModal<?= (int)$a['id'] ?>">
                    <?= e($a['student_name']) ?>
                  </span>
                  <?php if (!empty($a['gender'])): ?>
                    <span class="text-muted small ms-1" style="font-size: 11px;">(<?= ucfirst(substr($a['gender'], 0, 1)) ?>)</span>
                  <?php endif; ?>
                </td>

                <!-- Class -->
                <td class="py-3">
                  <span class="text-secondary fw-normal">
                    <?= e($a['class_name'] ?? 'Unassigned') ?>
                  </span>
                </td>

                <!-- Primary Parent / Guardian -->
                <td class="py-3">
                  <span class="text-secondary fw-normal">
                    <?= e($a['parent_name'] ?? '—') ?>
                  </span>
                </td>

                <!-- Submission Date -->
                <td class="py-3">
                  <span class="text-secondary font-monospace" style="font-size: 12px;">
                    <?= e($formattedDate) ?>
                  </span>
                </td>

                <!-- Status -->
                <td class="py-3">
                  <span class="badge rounded-pill px-3 py-1 fw-medium" style="<?= $badgeStyle ?> font-size: 11px;">
                    <?= e($statusLabel) ?>
                  </span>
                </td>

                <!-- Actions -->
                <td class="pe-3 py-3 text-end">
                  <div class="d-inline-flex align-items-center gap-1">
                    <!-- View Details Modal Trigger -->
                    <button type="button" class="btn btn-sm btn-icon text-muted hover-icon p-1" data-bs-toggle="modal" data-bs-target="#viewAppModal<?= (int)$a['id'] ?>" title="View Application Details" style="border-radius: 6px;">
                      <i data-lucide="eye" style="width: 15px; height: 15px;"></i>
                    </button>

                    <!-- Edit / Update Status Trigger -->
                    <button type="button" class="btn btn-sm btn-icon text-muted hover-icon p-1" data-bs-toggle="modal" data-bs-target="#editStatusModal<?= (int)$a['id'] ?>" title="Change Status" style="border-radius: 6px;">
                      <i data-lucide="edit-3" style="width: 15px; height: 15px;"></i>
                    </button>

                    <!-- Safe Delete Trigger -->
                    <button type="button" class="btn btn-sm btn-icon text-danger hover-icon p-1" data-bs-toggle="modal" data-bs-target="#deleteAppModal<?= (int)$a['id'] ?>" title="Delete Application" style="border-radius: 6px;">
                      <i data-lucide="trash-2" style="width: 15px; height: 15px;"></i>
                    </button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Table Footer & Pagination -->
      <div class="p-3 border-top d-flex justify-content-between align-items-center flex-wrap gap-3 bg-white" style="border-color: #f1f5f9 !important;">
        <div class="text-muted small">
          Showing <span class="fw-semibold text-dark"><?= $startRecord ?></span> to <span class="fw-semibold text-dark"><?= $endRecord ?></span> of <span class="fw-semibold text-dark"><?= $total ?></span> records
        </div>

        <div class="d-flex align-items-center gap-3">
          <!-- Rows Selector -->
          <div class="d-flex align-items-center gap-1">
            <span class="text-muted small" style="font-size: 12px;">Rows:</span>
            <select class="form-select form-select-sm" style="width: 70px; height: 30px; font-size: 12px; border-radius: 6px; border-color: #cbd5e1;" onchange="changeLimit(this.value)">
              <option value="10" <?= ($limit ?? 10) == 10 ? 'selected' : '' ?>>10</option>
              <option value="25" <?= ($limit ?? 10) == 25 ? 'selected' : '' ?>>25</option>
              <option value="50" <?= ($limit ?? 10) == 50 ? 'selected' : '' ?>>50</option>
              <option value="100" <?= ($limit ?? 10) == 100 ? 'selected' : '' ?>>100</option>
            </select>
          </div>

          <!-- Pagination -->
          <?php if (($totalPages ?? 1) > 1): ?>
            <nav aria-label="Page navigation">
              <ul class="pagination pagination-sm m-0 gap-1">
                <li class="page-item <?= ($page ?? 1) <= 1 ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('admissions?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) - 1])))) ?>">
                    <i data-lucide="chevron-left" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                  <?php if ($p == 1 || $p == $totalPages || ($p >= ($page - 2) && $p <= ($page + 2))): ?>
                    <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                      <a class="page-link rounded px-3" href="<?= e(url('admissions?' . http_build_query(array_merge($filters, ['page' => $p])))) ?>"
                         style="<?= $p == $page ? 'background-color: #4f46e5; border-color: #4f46e5;' : '' ?>">
                        <?= $p ?>
                      </a>
                    </li>
                  <?php elseif ($p == 2 || $p == ($totalPages - 1)): ?>
                    <li class="page-item disabled"><span class="page-link rounded border-0 px-2">...</span></li>
                  <?php endif; ?>
                <?php endfor; ?>
                <li class="page-item <?= ($page ?? 1) >= $totalPages ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('admissions?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) + 1])))) ?>">
                    <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
              </ul>
            </nav>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</form>

<!-- MODALS SECTION -->

<!-- 1. VIEW APPLICATION MODAL (Per applicant) -->
<?php if (!empty($admissions)): ?>
  <?php foreach ($admissions as $a): ?>
    <div class="modal fade" id="viewAppModal<?= (int)$a['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
          <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
            <div>
              <h5 class="modal-title fw-bold text-dark mb-0 fs-6"><?= e($a['student_name']) ?></h5>
              <span class="text-muted small font-monospace"><?= e($a['application_no']) ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body p-4">
            <div class="row g-3">
              <div class="col-6">
                <span class="text-muted small d-block">Applying For:</span>
                <span class="fw-semibold text-dark"><?= e($a['class_name'] ?? 'Unassigned') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Gender:</span>
                <span class="fw-semibold text-dark"><?= ucfirst(e($a['gender'] ?? 'N/A')) ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Parent / Guardian:</span>
                <span class="fw-semibold text-dark"><?= e($a['parent_name'] ?? 'N/A') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Contact Phone:</span>
                <span class="fw-semibold text-dark"><?= e($a['parent_phone'] ?? 'N/A') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Submission Date:</span>
                <span class="fw-semibold text-dark"><?= date('d/m/Y', strtotime($a['created_at'])) ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Current Status:</span>
                <span class="badge bg-light text-dark border fw-medium"><?= ucfirst(e($a['status'])) ?></span>
              </div>
              <?php if (!empty($a['notes'])): ?>
                <div class="col-12">
                  <span class="text-muted small d-block">Notes:</span>
                  <div class="p-2 bg-light rounded text-secondary small"><?= nl2br(e($a['notes'])) ?></div>
                </div>
              <?php endif; ?>
            </div>
          </div>
          <div class="modal-footer border-top px-4 py-3 bg-light d-flex justify-content-between" style="border-radius: 0 0 14px 14px;">
            <?php if (in_array(strtolower($a['status']), ['accepted', 'approved'], true)): ?>
              <form method="post" action="<?= e(url('admissions/' . $a['id'] . '/enroll')) ?>" class="m-0">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-success d-inline-flex align-items-center gap-1 fw-semibold" style="border-radius: 8px;">
                  <i data-lucide="user-check" style="width: 14px; height: 14px;"></i>
                  <span>Enroll as Student</span>
                </button>
              </form>
            <?php else: ?>
              <span></span>
            <?php endif; ?>
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 2. EDIT STATUS MODAL -->
    <div class="modal fade" id="editStatusModal<?= (int)$a['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
          <form method="post" action="<?= e(url('admissions/' . $a['id'] . '/status')) ?>">
            <?= csrf_field() ?>
            <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
              <h6 class="modal-title fw-bold text-dark mb-0">Update Status</h6>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
              <label class="form-label small fw-semibold text-secondary">Application Status</label>
              <select name="status" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                <option value="accepted" <?= in_array(strtolower($a['status']), ['accepted', 'approved']) ? 'selected' : '' ?>>Accepted</option>
                <option value="admitted" <?= in_array(strtolower($a['status']), ['admitted', 'enrolled']) ? 'selected' : '' ?>>Admitted</option>
                <option value="rejected" <?= strtolower($a['status']) === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                <option value="withdrawn" <?= strtolower($a['status']) === 'withdrawn' ? 'selected' : '' ?>>Withdrawn</option>
                <option value="review" <?= in_array(strtolower($a['status']), ['review', 'application']) ? 'selected' : '' ?>>Under Review</option>
                <option value="documents" <?= strtolower($a['status']) === 'documents' ? 'selected' : '' ?>>Documents Pending</option>
              </select>
            </div>
            <div class="modal-footer border-top p-3 bg-light" style="border-radius: 0 0 14px 14px;">
              <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-sm btn-primary fw-semibold" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">Save Status</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- 3. DELETE MODAL -->
    <div class="modal fade" id="deleteAppModal<?= (int)$a['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
          <form method="post" action="<?= e(url('admissions/' . $a['id'] . '/delete')) ?>">
            <?= csrf_field() ?>
            <div class="modal-body p-4 text-center">
              <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger mb-3" style="width: 48px; height: 48px;">
                <i data-lucide="alert-triangle" style="width: 24px; height: 24px;"></i>
              </div>
              <h6 class="fw-bold text-dark mb-1">Delete Application?</h6>
              <p class="text-muted small mb-0">Are you sure you want to remove the application for <strong><?= e($a['student_name']) ?></strong> (<?= e($a['application_no']) ?>)?</p>
            </div>
            <div class="modal-footer border-0 p-3 pt-0 justify-content-center">
              <button type="button" class="btn btn-sm btn-light px-3" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
              <button type="submit" class="btn btn-sm btn-danger px-3 fw-semibold" style="border-radius: 8px;">Delete</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<!-- 4. NEW ADMISSION APPLICATION MODAL -->
<div class="modal fade" id="newAdmissionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
      <form method="post" action="<?= e(url('admissions')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
          <div>
            <h5 class="modal-title fw-bold text-dark mb-0 fs-6">New Admission Application</h5>
            <span class="text-muted small">Submit a manual student registration or walk-in application.</span>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body p-4">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Student Full Name <span class="text-danger">*</span></label>
              <input type="text" name="student_name" class="form-control form-control-sm" required placeholder="e.g. Ali Khan" style="height: 38px; border-radius: 8px;">
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold text-secondary">Gender</label>
              <select name="gender" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold text-secondary">Date of Birth</label>
              <input type="date" name="date_of_birth" class="form-control form-control-sm" style="height: 38px; border-radius: 8px;">
            </div>

            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Target Class <span class="text-danger">*</span></label>
              <select name="class_id" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;">
                <option value="" disabled selected>Select Class...</option>
                <?php foreach ($classes as $c): ?>
                  <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Initial Status</label>
              <select name="status" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                <option value="accepted">Accepted</option>
                <option value="application" selected>Under Review</option>
                <option value="documents">Documents Pending</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Parent / Guardian Name</label>
              <input type="text" name="parent_name" class="form-control form-control-sm" placeholder="e.g. Tariq Khan" style="height: 38px; border-radius: 8px;">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Parent Phone</label>
              <input type="text" name="parent_phone" class="form-control form-control-sm" placeholder="e.g. 03001234567" style="height: 38px; border-radius: 8px;">
            </div>

            <div class="col-12">
              <label class="form-label small fw-semibold text-secondary">Remarks / Notes</label>
              <textarea name="notes" class="form-control form-control-sm" rows="2" placeholder="Previous school records, special requests..." style="border-radius: 8px;"></textarea>
            </div>
          </div>
        </div>

        <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
          <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
            <i data-lucide="check" style="width: 15px; height: 15px;"></i>
            <span>Create Application</span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Javascript & Interaction -->
<script>
// Multi-select Checkboxes
function toggleSelectAll(masterCheckbox) {
  const checkboxes = document.querySelectorAll('.admission-checkbox');
  checkboxes.forEach(cb => {
    cb.checked = masterCheckbox.checked;
  });
  updateSelectedCount();
}

function updateSelectedCount() {
  const checkboxes = document.querySelectorAll('.admission-checkbox:checked');
  const count = checkboxes.length;
  const bar = document.getElementById('bulkActionBar');
  const badge = document.getElementById('selectedCountBadge');
  
  if (badge) badge.textContent = count;
  if (bar) {
    if (count > 0) {
      bar.classList.remove('d-none');
    } else {
      bar.classList.add('d-none');
    }
  }

  const allCheckboxes = document.querySelectorAll('.admission-checkbox');
  const master = document.getElementById('selectAllCheckbox');
  if (master && allCheckboxes.length > 0) {
    master.checked = count === allCheckboxes.length;
  }
}

function clearSelectedRows() {
  document.querySelectorAll('.admission-checkbox').forEach(cb => cb.checked = false);
  const master = document.getElementById('selectAllCheckbox');
  if (master) master.checked = false;
  updateSelectedCount();
}

// Limit Switcher
function changeLimit(newLimit) {
  const form = document.getElementById('admissionsFilterForm');
  form.querySelector('input[name="limit"]').value = newLimit;
  form.submit();
}

// Sort By Column
function sortBy(column) {
  const form = document.getElementById('admissionsFilterForm');
  const sortInput = form.querySelector('input[name="sort"]');
  const dirInput = form.querySelector('input[name="dir"]');

  if (sortInput.value === column) {
    dirInput.value = dirInput.value === 'asc' ? 'desc' : 'asc';
  } else {
    sortInput.value = column;
    dirInput.value = 'asc';
  }
  form.submit();
}

document.addEventListener('DOMContentLoaded', function() {
  if (window.lucide) {
    lucide.createIcons();
  }
});
</script>

<style>
.hover-icon:hover {
  background-color: #f1f5f9 !important;
  color: #1e293b !important;
}
.admission-row:hover {
  background-color: #f8fafc !important;
}
</style>
