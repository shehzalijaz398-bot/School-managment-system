<?php
$totalCount = count($announcements);
?>

<div class="cc-noticeboard-wrapper">
    <!-- Page Header & Action -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Noticeboard</h2>
            <p class="text-muted small mb-0">Publish and manage school-wide announcements, portal updates, and staff circulars.</p>
        </div>

        <!-- Top Right: + New Announcement Button -->
        <button type="button" class="btn btn-sm text-white rounded-3 px-3 py-2 fw-semibold d-flex align-items-center gap-1 shadow-sm" 
                style="background: #4f46e5; font-size: 0.84rem;" data-bs-toggle="modal" data-bs-target="#createAnnouncementModal">
            <i data-lucide="plus" style="width: 15px; height: 15px;"></i> New Announcement
        </button>
    </div>

    <!-- Filter Bar Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('announcements')) ?>" id="noticeFilterForm" class="row g-2 align-items-center">
                <!-- Search Input -->
                <div class="col-12 col-md-6">
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" name="q" id="noticeLiveSearch" value="<?= e($search ?? '') ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search announcements..." style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>

                <!-- Audience Dropdown -->
                <div class="col-6 col-md-3">
                    <select name="audience" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('noticeFilterForm').submit();">
                        <option value="">All Audiences / Everyone [Portal]</option>
                        <option value="all" <?= (($audience ?? '') === 'all') ? 'selected' : '' ?>>Everyone [Portal]</option>
                        <option value="staff" <?= (($audience ?? '') === 'staff') ? 'selected' : '' ?>>Staff Only</option>
                        <option value="students" <?= (($audience ?? '') === 'students') ? 'selected' : '' ?>>Students Only</option>
                        <option value="parents" <?= (($audience ?? '') === 'parents') ? 'selected' : '' ?>>Parents Only</option>
                    </select>
                </div>

                <!-- Category Dropdown -->
                <div class="col-6 col-md-3">
                    <select name="category" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" 
                            style="height: 38px; font-size: 0.86rem;" onchange="document.getElementById('noticeFilterForm').submit();">
                        <option value="">All Categories</option>
                        <option value="Attendance Alert" <?= (($category ?? '') === 'Attendance Alert') ? 'selected' : '' ?>>Attendance Alert</option>
                        <option value="Invoice Issued" <?= (($category ?? '') === 'Invoice Issued') ? 'selected' : '' ?>>Invoice Issued</option>
                        <option value="Announcement" <?= (($category ?? '') === 'Announcement') ? 'selected' : '' ?>>Announcement</option>
                        <option value="Circular" <?= (($category ?? '') === 'Circular') ? 'selected' : '' ?>>Circular</option>
                        <option value="Event" <?= (($category ?? '') === 'Event') ? 'selected' : '' ?>>Event</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Noticeboard Data Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important; background: #fff;">
        <div class="table-responsive mb-0">
            <table class="table table-hover align-middle mb-0" id="noticeboardTable">
                <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                    <tr>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 55%;">
                            NOTICE
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            AUDIENCE
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 15%;">
                            CATEGORY
                        </th>
                        <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 12%;">
                            DATE POSTED
                        </th>
                        <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.74rem; width: 6%;">
                            ACTIONS
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($announcements)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <div class="py-5 d-flex flex-column align-items-center justify-content-center">
                                    <i data-lucide="bell-off" class="text-muted mb-2" style="width: 40px; height: 40px; opacity: 0.35;"></i>
                                    <p class="mb-0 fw-medium">No announcements found matching criteria.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($announcements as $a): 
                            $aId = (int)$a['id'];
                            $title = $a['title'];
                            $body = $a['body'];
                            $cat = $a['category'] ?: ($a['type'] ? ucwords(str_replace('_', ' ', $a['type'])) : 'Announcement');
                            $rawAudience = $a['audience'] ?: 'all';
                            $audienceLabel = ($rawAudience === 'all') ? 'Portal' : ucwords($rawAudience);
                            $datePosted = date('d/m/Y', strtotime($a['published_at'] ?? $a['created_at']));

                            // Determine if title has linked action icon
                            $hasExternalLink = (str_contains($title, 'Attendance Alert') || str_contains($title, 'Invoice Issued'));
                        ?>
                            <tr class="notice-row" data-title="<?= e(strtolower($title)) ?>" data-body="<?= e(strtolower($body)) ?>" data-cat="<?= e(strtolower($cat)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Notice (Title + Body) -->
                                <td class="py-3 px-4">
                                    <div class="d-flex align-items-center gap-1 mb-1">
                                        <span class="fw-bold text-dark" style="font-size: 0.88rem; letter-spacing: -0.01em;">
                                            <?= e($title) ?>
                                        </span>
                                        <?php if ($hasExternalLink): ?>
                                            <i data-lucide="external-link" class="text-muted ms-1 flex-shrink-0" style="width: 13px; height: 13px; opacity: 0.7;"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-muted small" style="font-size: 0.82rem; line-height: 1.4;">
                                        <?= e($body) ?>
                                    </div>
                                </td>

                                <!-- Audience -->
                                <td class="py-3 px-3 text-center">
                                    <span class="badge rounded-pill fw-medium px-2 py-1" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-size: 0.74rem;">
                                        <?= e($audienceLabel) ?>
                                    </span>
                                </td>

                                <!-- Category -->
                                <td class="py-3 px-3 text-center">
                                    <span class="badge rounded-pill fw-medium border px-2 py-1" style="background: #f8fafc; color: #475569; border-color: #e2e8f0 !important; font-size: 0.74rem;">
                                        <?= e($cat) ?>
                                    </span>
                                </td>

                                <!-- Date Posted -->
                                <td class="py-3 px-3 text-center text-secondary small" style="font-size: 0.84rem;">
                                    <?= e($datePosted) ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <!-- Edit Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#editNoticeModal<?= $aId ?>" title="Edit Announcement">
                                            <i data-lucide="edit-2" style="width: 14px; height: 14px;"></i>
                                        </button>

                                        <!-- Delete Button -->
                                        <button type="button" class="btn btn-sm btn-link p-0 text-secondary shadow-none action-icon-btn" 
                                                data-bs-toggle="modal" data-bs-target="#deleteNoticeModal<?= $aId ?>" title="Delete Announcement">
                                            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                                        </button>
                                    </div>

                                    <!-- Edit Announcement Modal -->
                                    <div class="modal fade" id="editNoticeModal<?= $aId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h5 class="modal-title fw-bold text-dark">Edit Announcement</h5>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?= e(url('announcements/' . $aId)) ?>">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-body p-4">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Title</label>
                                                            <input type="text" name="title" value="<?= e($title) ?>" class="form-control rounded-3 shadow-none border-light-subtle" required>
                                                        </div>
                                                        <div class="row g-2 mb-3">
                                                            <div class="col-6">
                                                                <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Category</label>
                                                                <select name="category" class="form-select rounded-3 shadow-none border-light-subtle">
                                                                    <option value="Announcement" <?= ($cat === 'Announcement') ? 'selected' : '' ?>>Announcement</option>
                                                                    <option value="Attendance Alert" <?= ($cat === 'Attendance Alert') ? 'selected' : '' ?>>Attendance Alert</option>
                                                                    <option value="Invoice Issued" <?= ($cat === 'Invoice Issued') ? 'selected' : '' ?>>Invoice Issued</option>
                                                                    <option value="Circular" <?= ($cat === 'Circular') ? 'selected' : '' ?>>Circular</option>
                                                                    <option value="Event" <?= ($cat === 'Event') ? 'selected' : '' ?>>Event</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-6">
                                                                <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Audience</label>
                                                                <select name="audience" class="form-select rounded-3 shadow-none border-light-subtle">
                                                                    <option value="all" <?= ($rawAudience === 'all') ? 'selected' : '' ?>>Everyone [Portal]</option>
                                                                    <option value="staff" <?= ($rawAudience === 'staff') ? 'selected' : '' ?>>Staff Only</option>
                                                                    <option value="students" <?= ($rawAudience === 'students') ? 'selected' : '' ?>>Students Only</option>
                                                                    <option value="parents" <?= ($rawAudience === 'parents') ? 'selected' : '' ?>>Parents Only</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Description / Details</label>
                                                            <textarea name="body" rows="4" class="form-control rounded-3 shadow-none border-light-subtle" required><?= e($body) ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer py-2 px-4 border-top">
                                                        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Delete Modal -->
                                    <div class="modal fade" id="deleteNoticeModal<?= $aId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-sm">
                                            <div class="modal-content border-0 shadow-lg rounded-4 text-start">
                                                <div class="modal-header py-3 px-4 border-bottom">
                                                    <h6 class="modal-title fw-bold text-dark">Confirm Delete</h6>
                                                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?= e(url('announcements/' . $aId . '/delete')) ?>">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-body p-4 text-center">
                                                        <i data-lucide="alert-triangle" class="text-danger mb-2" style="width: 36px; height: 36px;"></i>
                                                        <p class="mb-0 small text-muted">Are you sure you want to remove <strong><?= e($title) ?></strong>?</p>
                                                    </div>
                                                    <div class="modal-footer py-2 px-4 border-top d-flex justify-content-between">
                                                        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-sm btn-danger px-3 fw-medium">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal: + New Announcement -->
<div class="modal fade" id="createAnnouncementModal" tabindex="-1" aria-labelledby="createAnnouncementModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header py-3 px-4 border-bottom">
                <h5 class="modal-title fw-bold text-dark" id="createAnnouncementModalLabel">New Announcement</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('announcements')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Notice Title</label>
                        <input type="text" name="title" class="form-control rounded-3 shadow-none border-light-subtle" placeholder="e.g. Annual Sports Meet & Schedule Published" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Category</label>
                            <select name="category" class="form-select rounded-3 shadow-none border-light-subtle">
                                <option value="Announcement" selected>Announcement</option>
                                <option value="Attendance Alert">Attendance Alert</option>
                                <option value="Invoice Issued">Invoice Issued</option>
                                <option value="Circular">Circular</option>
                                <option value="Event">Event</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Audience</label>
                            <select name="audience" class="form-select rounded-3 shadow-none border-light-subtle">
                                <option value="all" selected>Everyone [Portal]</option>
                                <option value="staff">Staff Only</option>
                                <option value="students">Students Only</option>
                                <option value="parents">Parents Only</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label small fw-bold text-secondary text-uppercase mb-1" style="font-size: 0.74rem;">Description / Details</label>
                        <textarea name="body" rows="4" class="form-control rounded-3 shadow-none border-light-subtle" placeholder="Enter full announcement details here..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer py-2 px-4 border-top">
                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Publish Announcement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.action-icon-btn {
    opacity: 0.65;
    transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
}
.action-icon-btn:hover {
    opacity: 1;
    transform: scale(1.15);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Client-side real-time live search
    const searchInput = document.getElementById('noticeLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.notice-row');

            rows.forEach(row => {
                const title = row.getAttribute('data-title') || '';
                const body = row.getAttribute('data-body') || '';
                const cat = row.getAttribute('data-cat') || '';
                if (!query || title.includes(query) || body.includes(query) || cat.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>
