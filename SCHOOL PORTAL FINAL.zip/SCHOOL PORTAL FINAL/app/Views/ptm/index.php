<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-camera-video-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
    </div>

    <div class="row">
        <!-- Booking Console -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-header py-3 bg-light">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-calendar2-plus-fill me-2"></i> Schedule Virtual Consultation</h6>
                </div>
                <div class="card-body bg-white">
                    <form method="POST" action="<?= url('ptm/schedule/book') ?>">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Educator / Teacher <span class="text-danger">*</span></label>
                            <select class="form-select shadow-sm border-primary border-opacity-50" name="teacher_id" required>
                                <option value="" disabled selected>Select designated educator...</option>
                                <?php foreach($teachers as $t): ?>
                                    <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Student Matrix <span class="text-danger">*</span></label>
                            <select class="form-select shadow-sm" name="student_id" required>
                                <option value="" disabled selected>Select active student ledger...</option>
                                <?php foreach($students as $s): ?>
                                    <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small">Consultation Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control shadow-sm" name="meeting_date" min="<?= date('Y-m-d') ?>" required>
                        </div>

                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">Start Time <span class="text-danger">*</span></label>
                                <input type="time" class="form-control shadow-sm" name="start_time" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-bold text-dark small">End Time <span class="text-danger">*</span></label>
                                <input type="time" class="form-control shadow-sm" name="end_time" required>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark small">Meeting Notes (Optional)</label>
                            <textarea class="form-control shadow-sm" name="notes" rows="2" placeholder="Specific academic concerns to discuss..."></textarea>
                        </div>

                        <div class="alert alert-primary border-0 shadow-sm small py-2">
                            <i class="bi bi-shield-lock-fill me-1"></i> A secure <code>virtual_link</code> string will be automatically generated upon successful slot validation.
                        </div>

                        <div class="d-grid mt-2">
                            <button type="submit" class="btn btn-primary fw-bold shadow">
                                <i class="bi bi-hdd-network me-1"></i> Lock Appointment Slot
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Appointment Grid -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3 bg-dark d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-layout-text-window-reverse me-2"></i> Active PTM Trajectories</h6>
                </div>
                <div class="card-body bg-light p-0">
                    <div class="table-responsive" style="max-height: 600px; overflow-y: auto;">
                        <table class="table table-hover table-bordered bg-white mb-0 align-middle">
                            <thead class="table-dark sticky-top text-uppercase small">
                                <tr>
                                    <th class="ps-3">Target Nodes</th>
                                    <th>Temporal Block</th>
                                    <th>Status</th>
                                    <th class="text-center pe-3">Virtual Room Matrix</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($appointments as $appt): ?>
                                <tr>
                                    <td class="ps-3">
                                        <div class="fw-bold text-primary"><i class="bi bi-person-video3 me-1"></i> <?= htmlspecialchars($appt['teacher_name']) ?></div>
                                        <div class="small fw-bold text-secondary mt-1"><i class="bi bi-mortarboard-fill me-1"></i> <?= htmlspecialchars($appt['student_name']) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= date('M d, Y', strtotime($appt['meeting_date'])) ?></div>
                                        <div class="small text-muted fw-bold">
                                            <?= date('H:i', strtotime($appt['start_time'])) ?> - <?= date('H:i', strtotime($appt['end_time'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($appt['status'] === 'scheduled'): ?>
                                            <span class="badge bg-warning text-dark shadow-sm">Scheduled</span>
                                        <?php elseif($appt['status'] === 'completed'): ?>
                                            <span class="badge bg-success shadow-sm">Completed</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger shadow-sm">Cancelled</span>
                                        <?php endif; ?>
                                        
                                        <!-- Lifecycle Actions Dropdown -->
                                        <div class="dropdown mt-2">
                                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle py-0 border-0 fw-bold" type="button" data-bs-toggle="dropdown">
                                                Update State
                                            </button>
                                            <ul class="dropdown-menu shadow">
                                                <li>
                                                    <form method="POST" action="<?= url("ptm/schedule/{$appt['id']}/status") ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="status" value="scheduled">
                                                        <button class="dropdown-item fw-bold text-warning" type="submit">Re-Schedule</button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <form method="POST" action="<?= url("ptm/schedule/{$appt['id']}/status") ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="status" value="completed">
                                                        <button class="dropdown-item fw-bold text-success" type="submit">Mark Completed</button>
                                                    </form>
                                                </li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li>
                                                    <form method="POST" action="<?= url("ptm/schedule/{$appt['id']}/status") ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="status" value="cancelled">
                                                        <button class="dropdown-item fw-bold text-danger" type="submit">Force Cancel</button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td class="text-center pe-3">
                                        <?php if($appt['status'] === 'scheduled' && $appt['virtual_link']): ?>
                                            <a href="<?= htmlspecialchars($appt['virtual_link']) ?>" target="_blank" class="btn btn-sm btn-success fw-bold shadow-sm pulse-btn">
                                                <i class="bi bi-camera-video me-1"></i> Join Virtual Room
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-secondary fw-bold" disabled>
                                                <i class="bi bi-camera-video-off me-1"></i> Link Locked
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($appointments)): ?>
                                <tr><td colspan="4" class="text-center text-muted py-5"><i class="bi bi-calendar-x fs-1 d-block mb-3 text-gray-300"></i> No consultations scheduled.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .pulse-btn {
        animation: pulse-success-anim 2s infinite;
    }
    @keyframes pulse-success-anim {
        0% { box-shadow: 0 0 0 0 rgba(25, 135, 84, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(25, 135, 84, 0); }
        100% { box-shadow: 0 0 0 0 rgba(25, 135, 84, 0); }
    }
</style>
