<div class="row g-3">
  <div class="col-lg-6 mx-auto">
    <div class="panel">
      <h2>Edit Section: <?= e($section['name']) ?></h2>
      <form method="post" action="<?= e(url('sections/'.$section['id'])) ?>">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Class</label>
          <select name="class_id" class="form-select" required>
            <option value="">Select Class...</option>
            <?php foreach ($classes as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $section['class_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Section Name</label>
          <input type="text" name="name" class="form-control" value="<?= e($section['name']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Capacity</label>
          <input type="number" name="capacity" class="form-control" value="<?= (int)$section['capacity'] ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Class Teacher</label>
          <select name="class_teacher_id" class="form-select">
            <option value="">None (Remove Assignment)</option>
            <?php foreach ($teachers as $t): ?>
              <option value="<?= (int)$t['id'] ?>" <?= $t['id'] == $section['class_teacher_id'] ? 'selected' : '' ?>><?= e($t['first_name'].' '.$t['last_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Section</button>
        <a href="<?= e(url('sections')) ?>" class="btn btn-outline-secondary">Cancel</a>
      </form>
    </div>
  </div>
</div>
