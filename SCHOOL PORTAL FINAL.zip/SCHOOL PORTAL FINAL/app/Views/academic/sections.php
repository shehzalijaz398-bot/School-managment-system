<!-- Academics Breadcrumb & Title Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Academics</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Sections</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Sections</h1>
      <p class="text-muted small mb-0">Manage the classroom sections, homerooms, or streams mapped under each class.</p>
    </div>
    <?php if (hasPermission('classes.manage')): ?>
      <div>
        <button type="button" class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#newSectionModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
          <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
          <span>New Section</span>
        </button>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Academics Subnav Pill Switcher -->
<div class="mb-4">
  <div class="d-inline-flex align-items-center bg-white border rounded-pill p-1 shadow-xs" style="border-color: #e2e8f0 !important;">
    <a href="<?= e(url('academic-sessions')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="calendar" style="width: 14px; height: 14px;"></i>
      <span>Academic Years</span>
    </a>
    <a href="<?= e(url('classes')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="graduation-cap" style="width: 14px; height: 14px;"></i>
      <span>Classes</span>
    </a>
    <a href="<?= e(url('sections')) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2" style="background-color: #ede9fe; color: #4f46e5; border: 1px solid #c7d2fe;">
      <i data-lucide="layout-grid" style="width: 14px; height: 14px;"></i>
      <span>Sections</span>
    </a>
    <a href="<?= e(url('subjects')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="book-open" style="width: 14px; height: 14px;"></i>
      <span>Subjects</span>
    </a>
  </div>
</div>

<!-- Search & Multi-Filter Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <div class="row g-3 align-items-end">
      <!-- Search input -->
      <div class="col-md-6 col-lg-6">
        <label for="sectionSearchInput" class="form-label small fw-semibold text-secondary mb-1">Search Sections</label>
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 14px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; pointer-events: none;"></i>
          <input type="text" id="sectionSearchInput" class="form-control" placeholder="Search by section name, code..." style="padding-left: 40px; height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
        </div>
      </div>

      <!-- Class Filter -->
      <div class="col-md-3 col-lg-3">
        <label for="sectionClassFilter" class="form-label small fw-semibold text-secondary mb-1">Class</label>
        <select id="sectionClassFilter" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
          <option value="all">All Classes</option>
          <?php foreach ($classes as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Status Filter -->
      <div class="col-md-3 col-lg-3">
        <label for="sectionStatusFilter" class="form-label small fw-semibold text-secondary mb-1">Status</label>
        <select id="sectionStatusFilter" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
    </div>
  </div>
</div>

<!-- Sections Table Card -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; overflow: hidden; background: #ffffff;">
  <div class="table-responsive">
    <table class="table align-middle mb-0" id="sectionsTable">
      <thead style="background-color: #ffffff; border-bottom: 1px solid #e2e8f0;">
        <tr>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase sortable-sec-th" data-col="name" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            NAME <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sec-th" data-col="class" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            CLASS <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sec-th" data-col="capacity" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            CAPACITY <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sec-th" data-col="students" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            ACTIVE STUDENTS <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sec-th" data-col="teacher" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            CLASS TEACHER <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sec-th" data-col="status" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            STATUS <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase text-end" style="font-size: 11px; letter-spacing: 0.05em;">
            ACTIONS
          </th>
        </tr>
      </thead>
      <tbody id="sectionTableBody">
        <?php if (empty($sections)): ?>
          <tr id="emptySectionRow">
            <td colspan="7" class="text-center py-5 text-muted">
              <i data-lucide="layout-grid" class="d-block mx-auto mb-2 opacity-50" style="width: 36px; height: 36px;"></i>
              No sections configured yet. Click "+ New Section" to add one.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($sections as $s): ?>
            <?php 
              $isActive = (int)($s['status'] ?? 1) === 1;
              $secName = $s['name'];
              $secCode = !empty($s['code']) ? $s['code'] : 'SEC-' . $s['id'];
              $className = $s['class_name'] ?? 'Unassigned';
              $classId = (int)$s['class_id'];
              $capacity = (int)($s['capacity'] ?? 40);
              $studentCount = (int)($s['student_count'] ?? 0);
              $teacherName = !empty($s['teacher_first']) ? trim($s['teacher_first'] . ' ' . ($s['teacher_last'] ?? '')) : '';
            ?>
            <tr class="section-row" 
                data-name="<?= e(strtolower($secName)) ?>" 
                data-code="<?= e(strtolower($secCode)) ?>"
                data-class-id="<?= $classId ?>"
                data-class="<?= e(strtolower($className)) ?>"
                data-capacity="<?= $capacity ?>"
                data-students="<?= $studentCount ?>"
                data-teacher="<?= e(strtolower($teacherName)) ?>"
                data-status="<?= $isActive ? 'active' : 'inactive' ?>"
                style="border-bottom: 1px solid #f8fafc; transition: background-color 0.15s ease;">
              
              <!-- Name & Code -->
              <td class="py-3 px-4">
                <div class="d-flex align-items-center gap-2">
                  <span class="badge bg-light text-primary border px-2 py-1 fw-bold" style="font-size: 12px; border-radius: 6px;">
                    <?= e($secName) ?>
                  </span>
                  <?php if (!empty($s['code'])): ?>
                    <span class="text-muted small" style="font-size: 12px;">(<?= e($s['code']) ?>)</span>
                  <?php endif; ?>
                </div>
              </td>

              <!-- Class -->
              <td class="py-3 px-3">
                <span class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($className) ?></span>
              </td>

              <!-- Capacity -->
              <td class="py-3 px-3 text-secondary" style="font-size: 13px; font-variant-numeric: tabular-nums;">
                <?= $capacity ?>
              </td>

              <!-- Active Students -->
              <td class="py-3 px-3 text-secondary" style="font-size: 13px; font-variant-numeric: tabular-nums;">
                <span class="fw-semibold text-dark"><?= $studentCount ?></span>
                <span class="text-muted small">/ <?= $capacity ?></span>
              </td>

              <!-- Class Teacher -->
              <td class="py-3 px-3">
                <?php if (!empty($teacherName)): ?>
                  <div class="d-flex align-items-center gap-2">
                    <i data-lucide="user-check" class="text-success" style="width: 14px; height: 14px;"></i>
                    <span class="text-dark small fw-medium"><?= e($teacherName) ?></span>
                  </div>
                <?php else: ?>
                  <span class="badge bg-light text-secondary border px-2 py-1" style="font-size: 11px;">Not Assigned</span>
                <?php endif; ?>
              </td>

              <!-- Status Badge -->
              <td class="py-3 px-3">
                <?php if ($isActive): ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px;">●</span> Active
                  </span>
                <?php else: ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f8fafc; color: #64748b; border: 1px solid #e2e8f0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px; color: #94a3b8;">●</span> Inactive
                  </span>
                <?php endif; ?>
              </td>

              <!-- Actions (Edit, Delete) -->
              <td class="py-3 px-4 text-end">
                <div class="d-inline-flex align-items-center gap-2">
                  <?php if (hasPermission('classes.manage')): ?>
                    <!-- Edit Section Modal Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action" title="Edit Section" data-bs-toggle="modal" data-bs-target="#editSectionModal-<?= $s['id'] ?>">
                      <i data-lucide="edit-3" style="width: 16px; height: 16px;"></i>
                    </button>

                    <!-- Delete Section Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action text-danger" title="Delete Section" onclick="confirmDeleteSection(<?= $s['id'] ?>, '<?= e(addslashes($s['name'])) ?>', '<?= e(addslashes($className)) ?>')">
                      <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                    </button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        <tr id="noSectionResultsRow" style="display: none;">
          <td colspan="7" class="text-center py-5 text-muted">
            <i data-lucide="search-x" class="d-block mx-auto mb-2 opacity-50" style="width: 32px; height: 32px;"></i>
            No sections matching your search filters.
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Table Pagination / Footer -->
  <div class="card-footer bg-white py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2" style="border-top: 1px solid #f1f5f9;">
    <span class="text-muted small" id="sectionRecordCounter">Showing 1 to <?= count($sections) ?> of <?= count($sections) ?> records</span>
    <div class="d-flex align-items-center gap-2">
      <span class="text-muted small">Rows:</span>
      <select class="form-select form-select-sm" id="sectionRowsSelect" style="width: 70px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 13px;">
        <option value="10" selected>10</option>
        <option value="25">25</option>
        <option value="50">50</option>
      </select>
    </div>
  </div>
</div>

<!-- ========================================== -->
<!-- MODALS -->
<!-- ========================================== -->

<!-- 1. Modal: + New Section -->
<?php if (hasPermission('classes.manage')): ?>
<div class="modal fade" id="newSectionModal" tabindex="-1" aria-labelledby="newSectionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
        <h5 class="modal-title fw-bold text-dark fs-6" id="newSectionModalLabel">
          <i data-lucide="plus-circle" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
          New Section
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= e(url('sections')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-secondary">Target Class <span class="text-danger">*</span></label>
            <select name="class_id" class="form-select" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
              <option value="">Select Class...</option>
              <?php foreach ($classes as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Section Name <span class="text-danger">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="e.g. A or Blue" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Section Code</label>
              <input type="text" name="code" class="form-control" placeholder="e.g. SEC-A" style="border-radius: 8px; border: 1px solid #e2e8f0;">
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Capacity (Max Students)</label>
              <input type="number" name="capacity" class="form-control" value="40" min="1" max="200" style="border-radius: 8px; border: 1px solid #e2e8f0;">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Class Teacher</label>
              <select name="class_teacher_id" class="form-select" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                <option value="">None (Unassigned)</option>
                <?php foreach ($teachers as $t): ?>
                  <option value="<?= (int)$t['id'] ?>"><?= e($t['first_name'] . ' ' . $t['last_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-check form-switch p-0 mt-3 pt-3 border-top d-flex justify-content-between align-items-center">
            <div>
              <label class="form-check-label fw-semibold text-dark small" for="newSecStatus">Active Status</label>
              <div class="text-muted" style="font-size: 12px;">Active sections are visible across roll calls and schedules.</div>
            </div>
            <input class="form-check-input ms-0" type="checkbox" role="switch" name="status" value="1" id="newSecStatus" checked style="width: 2.5em; height: 1.25em;">
          </div>
        </div>
        <div class="modal-footer bg-light px-4 py-3 border-top">
          <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Create Section</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 2. Modals: Edit Section for each Section -->
<?php if (!empty($sections)): ?>
  <?php foreach ($sections as $s): ?>
    <?php if (hasPermission('classes.manage')): ?>
    <div class="modal fade" id="editSectionModal-<?= $s['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
          <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
            <h5 class="modal-title fw-bold text-dark fs-6">
              <i data-lucide="edit-3" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
              Edit Section — <?= e($s['name']) ?> (<?= e($s['class_name'] ?? '') ?>)
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form method="post" action="<?= e(url("sections/{$s['id']}/update")) ?>">
            <?= csrf_field() ?>
            <div class="modal-body p-4">
              <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Target Class <span class="text-danger">*</span></label>
                <select name="class_id" class="form-select" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
                  <?php foreach ($classes as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= (int)$c['id'] === (int)$s['class_id'] ? 'selected' : '' ?>>
                      <?= e($c['name']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Section Name <span class="text-danger">*</span></label>
                  <input type="text" name="name" class="form-control" value="<?= e($s['name']) ?>" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Section Code</label>
                  <input type="text" name="code" class="form-control" value="<?= e($s['code'] ?? '') ?>" placeholder="e.g. SEC-A" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                </div>
              </div>

              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Capacity</label>
                  <input type="number" name="capacity" class="form-control" value="<?= (int)($s['capacity'] ?? 40) ?>" min="1" max="200" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Class Teacher</label>
                  <select name="class_teacher_id" class="form-select" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                    <option value="">None (Unassigned)</option>
                    <?php foreach ($teachers as $t): ?>
                      <option value="<?= (int)$t['id'] ?>" <?= (int)$t['id'] === (int)($s['class_teacher_id'] ?? 0) ? 'selected' : '' ?>>
                        <?= e($t['first_name'] . ' ' . $t['last_name']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="form-check form-switch p-0 mt-3 pt-3 border-top d-flex justify-content-between align-items-center">
                <div>
                  <label class="form-check-label fw-semibold text-dark small" for="editSecStatus-<?= $s['id'] ?>">Active Status</label>
                  <div class="text-muted" style="font-size: 12px;">Enable or disable this section across the school system.</div>
                </div>
                <input class="form-check-input ms-0" type="checkbox" role="switch" name="status" value="1" id="editSecStatus-<?= $s['id'] ?>" <?= (int)($s['status'] ?? 1) === 1 ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>
            <div class="modal-footer bg-light px-4 py-3 border-top">
              <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
              <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
  <?php endforeach; ?>
<?php endif; ?>

<!-- Hidden form for deleting a section -->
<form id="deleteSectionForm" method="post" action="" style="display: none;">
  <?= csrf_field() ?>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('sectionSearchInput');
  const classFilter = document.getElementById('sectionClassFilter');
  const statusFilter = document.getElementById('sectionStatusFilter');
  const tableBody = document.getElementById('sectionTableBody');
  const rows = Array.from(document.querySelectorAll('.section-row'));
  const recordCounter = document.getElementById('sectionRecordCounter');
  const noResultsRow = document.getElementById('noSectionResultsRow');
  const totalCount = rows.length;

  // Filter Function
  function filterSections() {
    const query = searchInput.value.trim().toLowerCase();
    const selectedClass = classFilter.value;
    const status = statusFilter.value.toLowerCase();
    let visibleCount = 0;

    rows.forEach(row => {
      const name = row.getAttribute('data-name') || '';
      const code = row.getAttribute('data-code') || '';
      const rowClassId = row.getAttribute('data-class-id') || '';
      const rowStatus = row.getAttribute('data-status') || '';

      const matchesQuery = query === '' || name.includes(query) || code.includes(query);
      const matchesClass = selectedClass === 'all' || rowClassId === selectedClass;
      const matchesStatus = status === 'all' || rowStatus === status;

      if (matchesQuery && matchesClass && matchesStatus) {
        row.style.display = '';
        visibleCount++;
      } else {
        row.style.display = 'none';
      }
    });

    if (recordCounter) {
      recordCounter.textContent = `Showing 1 to ${visibleCount} of ${totalCount} records`;
    }

    if (noResultsRow) {
      noResultsRow.style.display = visibleCount === 0 ? '' : 'none';
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterSections);
  }
  if (classFilter) {
    classFilter.addEventListener('change', filterSections);
  }
  if (statusFilter) {
    statusFilter.addEventListener('change', filterSections);
  }

  // Column Sorting
  let currentSortCol = null;
  let currentSortAsc = true;

  document.querySelectorAll('.sortable-sec-th').forEach(th => {
    th.addEventListener('click', function() {
      const col = this.getAttribute('data-col');
      if (currentSortCol === col) {
        currentSortAsc = !currentSortAsc;
      } else {
        currentSortCol = col;
        currentSortAsc = true;
      }

      // Update sort indicators
      document.querySelectorAll('.sortable-sec-th .sort-icon').forEach(si => si.textContent = '⇅');
      const sortIcon = this.querySelector('.sort-icon');
      if (sortIcon) {
        sortIcon.textContent = currentSortAsc ? '↑' : '↓';
      }

      rows.sort((a, b) => {
        let valA = a.getAttribute(`data-${col}`);
        let valB = b.getAttribute(`data-${col}`);

        if (col === 'capacity' || col === 'students') {
          valA = parseInt(valA, 10) || 0;
          valB = parseInt(valB, 10) || 0;
          return currentSortAsc ? valA - valB : valB - valA;
        } else {
          valA = (valA || '').toLowerCase();
          valB = (valB || '').toLowerCase();
          if (valA < valB) return currentSortAsc ? -1 : 1;
          if (valA > valB) return currentSortAsc ? 1 : -1;
          return 0;
        }
      });

      rows.forEach(r => tableBody.appendChild(r));
    });
  });

  // Row hover effect
  rows.forEach(row => {
    row.addEventListener('mouseenter', () => {
      row.style.backgroundColor = '#f8fafc';
    });
    row.addEventListener('mouseleave', () => {
      row.style.backgroundColor = '';
    });
  });

  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
});

function confirmDeleteSection(id, name, className) {
  showDeleteConfirm({
    title: 'Delete Section',
    message: `Are you sure you want to delete section "${name}" of ${className}?`,
    subtext: 'This action cannot be undone if students are enrolled.',
    confirmText: 'Delete',
    onConfirm: function() {
      const form = document.getElementById('deleteSectionForm');
      form.action = `<?= e(url('sections')) ?>/${id}/delete`;
      form.submit();
    }
  });
}
</script>

<style>
.btn-icon-action {
  color: #64748b;
  background: transparent;
  border: 1px solid transparent;
  padding: 4px 6px;
  border-radius: 6px;
  transition: all 0.15s ease;
}
.btn-icon-action:hover {
  color: #4f46e5;
  background-color: #f1f5f9;
}
.btn-icon-action.text-danger:hover {
  color: #ef4444 !important;
  background-color: #fef2f2;
}
.hover-bg-light:hover {
  background-color: #f8fafc;
  color: #1e293b !important;
}
.sortable-sec-th:hover {
  background-color: #f8fafc;
  color: #1e293b !important;
}
</style>
