<!-- Academics Breadcrumb & Title Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Academics</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Subjects</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Subjects</h1>
      <p class="text-muted small mb-0">Manage the global list of courses, subjects, or modules taught across classes.</p>
    </div>
    <?php if (hasPermission('classes.manage')): ?>
      <div>
        <button type="button" class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#newSubjectModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
          <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
          <span>New Subject</span>
        </button>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Academics Subnav Pill Switcher -->
<div class="mb-4">
  <div class="d-inline-flex align-items-center bg-white border rounded-pill p-1 shadow-xs" style="border-color: #e2e8f0 !important;">
    <a href="<?= e(url('academic-sessions')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="calendar" style="width: 14px; height: 14px;"></i>
      <span>Academic Years</span>
    </a>
    <a href="<?= e(url('classes')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="graduation-cap" style="width: 14px; height: 14px;"></i>
      <span>Classes</span>
    </a>
    <a href="<?= e(url('sections')) ?>" class="btn btn-sm rounded-pill px-3 py-1 text-muted d-inline-flex align-items-center gap-2 hover-bg-light" style="border: 1px solid transparent;">
      <i data-lucide="layout-grid" style="width: 14px; height: 14px;"></i>
      <span>Sections</span>
    </a>
    <a href="<?= e(url('subjects')) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2" style="background-color: #ede9fe; color: #4f46e5; border: 1px solid #c7d2fe;">
      <i data-lucide="book-open" style="width: 14px; height: 14px;"></i>
      <span>Subjects</span>
    </a>
  </div>
</div>

<!-- Search & Status Filter Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <div class="row g-3 align-items-end">
      <div class="col-md-8 col-lg-9">
        <label for="subjectSearchInput" class="form-label small fw-semibold text-secondary mb-1">Search Subjects</label>
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 14px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; pointer-events: none;"></i>
          <input type="text" id="subjectSearchInput" class="form-control" placeholder="Search by name, code..." style="padding-left: 40px; height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
        </div>
      </div>
      <div class="col-md-4 col-lg-3">
        <label for="subjectStatusFilter" class="form-label small fw-semibold text-secondary mb-1">Status</label>
        <select id="subjectStatusFilter" class="form-select" style="height: 42px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 14px;">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
    </div>
  </div>
</div>

<!-- Subjects Table Card -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; overflow: hidden; background: #ffffff;">
  <div class="table-responsive">
    <table class="table align-middle mb-0" id="subjectsTable">
      <thead style="background-color: #ffffff; border-bottom: 1px solid #e2e8f0;">
        <tr>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase sortable-sub-th" data-col="name" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            SUBJECT NAME <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sub-th" data-col="code" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            CODE <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sub-th" data-col="type" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            TYPE <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sub-th" data-col="mapped" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            MAPPED CLASSES <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-3 text-muted fw-bold text-uppercase sortable-sub-th" data-col="status" style="font-size: 11px; letter-spacing: 0.05em; cursor: pointer; user-select: none;">
            STATUS <span class="sort-icon text-muted" style="font-size: 10px;">⇅</span>
          </th>
          <th scope="col" class="py-3 px-4 text-muted fw-bold text-uppercase text-end" style="font-size: 11px; letter-spacing: 0.05em;">
            ACTIONS
          </th>
        </tr>
      </thead>
      <tbody id="subjectTableBody">
        <?php if (empty($subjects)): ?>
          <tr id="emptySubjectRow">
            <td colspan="6" class="text-center py-5 text-muted">
              <i data-lucide="book-open" class="d-block mx-auto mb-2 opacity-50" style="width: 36px; height: 36px;"></i>
              No subjects configured yet. Click "+ New Subject" to add one.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($subjects as $sub): ?>
            <?php 
              $isActive = (int)($sub['status'] ?? 1) === 1;
              $subCode = !empty($sub['code']) ? $sub['code'] : strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $sub['name']), 0, 4));
              $subType = strtolower($sub['type'] ?? 'core');
              $mappedCount = (int)($sub['mapped_classes_count'] ?? 0);
            ?>
            <tr class="subject-row" 
                data-name="<?= e(strtolower($sub['name'])) ?>" 
                data-code="<?= e(strtolower($subCode)) ?>"
                data-type="<?= e($subType) ?>"
                data-mapped="<?= $mappedCount ?>"
                data-status="<?= $isActive ? 'active' : 'inactive' ?>"
                style="border-bottom: 1px solid #f8fafc; transition: background-color 0.15s ease;">
              
              <!-- Subject Name -->
              <td class="py-3 px-4">
                <span class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($sub['name']) ?></span>
              </td>

              <!-- Code -->
              <td class="py-3 px-3">
                <span class="badge bg-light text-secondary border px-2 py-1 fw-medium" style="font-size: 11.5px; border-radius: 6px; letter-spacing: 0.04em;">
                  <?= e($subCode) ?>
                </span>
              </td>

              <!-- Type -->
              <td class="py-3 px-3">
                <?php if ($subType === 'core'): ?>
                  <span class="badge rounded-pill fw-medium" style="background-color: #ede9fe; color: #6366f1; border: 1px solid #ddd6fe; font-size: 11.5px; padding: 2.5px 10px;">
                    Core
                  </span>
                <?php elseif ($subType === 'elective'): ?>
                  <span class="badge rounded-pill fw-medium" style="background-color: #e0f2fe; color: #0284c7; border: 1px solid #bae6fd; font-size: 11.5px; padding: 2.5px 10px;">
                    Elective
                  </span>
                <?php else: ?>
                  <span class="badge rounded-pill fw-medium" style="background-color: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; font-size: 11.5px; padding: 2.5px 10px;">
                    <?= e(ucfirst($subType)) ?>
                  </span>
                <?php endif; ?>
              </td>

              <!-- Mapped Classes -->
              <td class="py-3 px-3 text-secondary" style="font-size: 13px; font-variant-numeric: tabular-nums;">
                <span class="fw-semibold text-dark"><?= $mappedCount ?></span>
              </td>

              <!-- Status Badge -->
              <td class="py-3 px-3">
                <?php if ($isActive): ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px;">●</span> Active
                  </span>
                <?php else: ?>
                  <span class="badge rounded-pill fw-medium d-inline-flex align-items-center gap-1" style="background-color: #f8fafc; color: #64748b; border: 1px solid #e2e8f0; font-size: 11.5px; padding: 3px 10px;">
                    <span style="font-size: 8px; color: #94a3b8;">●</span> Inactive
                  </span>
                <?php endif; ?>
              </td>

              <!-- Actions (Edit, Delete) -->
              <td class="py-3 px-4 text-end">
                <div class="d-inline-flex align-items-center gap-2">
                  <?php if (hasPermission('classes.manage')): ?>
                    <!-- Edit Subject Modal Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action" title="Edit Subject" data-bs-toggle="modal" data-bs-target="#editSubjectModal-<?= $sub['id'] ?>">
                      <i data-lucide="edit-3" style="width: 16px; height: 16px;"></i>
                    </button>

                    <!-- Delete Subject Trigger -->
                    <button type="button" class="btn btn-sm btn-icon-action text-danger" title="Delete Subject" onclick="confirmDeleteSubject(<?= $sub['id'] ?>, '<?= e(addslashes($sub['name'])) ?>')">
                      <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                    </button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        <tr id="noSubjectResultsRow" style="display: none;">
          <td colspan="6" class="text-center py-5 text-muted">
            <i data-lucide="search-x" class="d-block mx-auto mb-2 opacity-50" style="width: 32px; height: 32px;"></i>
            No subjects matching your search filters.
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Table Pagination / Footer -->
  <div class="card-footer bg-white py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2" style="border-top: 1px solid #f1f5f9;">
    <span class="text-muted small" id="subjectRecordCounter">Showing 1 to <?= count($subjects) ?> of <?= count($subjects) ?> records</span>
    <div class="d-flex align-items-center gap-2">
      <span class="text-muted small">Rows:</span>
      <select class="form-select form-select-sm" id="subjectRowsSelect" style="width: 70px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 13px;">
        <option value="10" selected>10</option>
        <option value="25">25</option>
        <option value="50">50</option>
      </select>
    </div>
  </div>
</div>

<!-- ========================================== -->
<!-- MODALS -->
<!-- ========================================== -->

<!-- 1. Modal: + New Subject -->
<?php if (hasPermission('classes.manage')): ?>
<div class="modal fade" id="newSubjectModal" tabindex="-1" aria-labelledby="newSubjectModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
        <h5 class="modal-title fw-bold text-dark fs-6" id="newSubjectModalLabel">
          <i data-lucide="plus-circle" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
          New Subject
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= e(url('subjects')) ?>">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-secondary">Subject Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="e.g. Mathematics or Art & Craft" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Subject Code</label>
              <input type="text" name="code" class="form-control" placeholder="e.g. MATH or ART" style="border-radius: 8px; border: 1px solid #e2e8f0;">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Subject Type</label>
              <select name="type" class="form-select" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                <option value="core">Core</option>
                <option value="elective">Elective</option>
                <option value="other">Other / Lab</option>
              </select>
            </div>
          </div>

          <div class="form-check form-switch p-0 mt-3 pt-3 border-top d-flex justify-content-between align-items-center">
            <div>
              <label class="form-check-label fw-semibold text-dark small" for="newSubjectStatus">Active Status</label>
              <div class="text-muted" style="font-size: 12px;">Active subjects are available for class mapping, timetables, and exams.</div>
            </div>
            <input class="form-check-input ms-0" type="checkbox" role="switch" name="status" value="1" id="newSubjectStatus" checked style="width: 2.5em; height: 1.25em;">
          </div>
        </div>
        <div class="modal-footer bg-light px-4 py-3 border-top">
          <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Create Subject</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 2. Modals: Edit Subject for each Subject -->
<?php if (!empty($subjects)): ?>
  <?php foreach ($subjects as $sub): ?>
    <?php if (hasPermission('classes.manage')): ?>
    <div class="modal fade" id="editSubjectModal-<?= $sub['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
          <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
            <h5 class="modal-title fw-bold text-dark fs-6">
              <i data-lucide="edit-3" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
              Edit Subject — <?= e($sub['name']) ?>
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form method="post" action="<?= e(url("subjects/{$sub['id']}/update")) ?>">
            <?= csrf_field() ?>
            <div class="modal-body p-4">
              <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Subject Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?= e($sub['name']) ?>" required style="border-radius: 8px; border: 1px solid #e2e8f0;">
              </div>

              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Subject Code</label>
                  <input type="text" name="code" class="form-control" value="<?= e($sub['code'] ?? '') ?>" placeholder="e.g. MATH" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Subject Type</label>
                  <select name="type" class="form-select" style="border-radius: 8px; border: 1px solid #e2e8f0;">
                    <option value="core" <?= ($sub['type'] ?? '') === 'core' ? 'selected' : '' ?>>Core</option>
                    <option value="elective" <?= ($sub['type'] ?? '') === 'elective' ? 'selected' : '' ?>>Elective</option>
                    <option value="other" <?= ($sub['type'] ?? '') === 'other' ? 'selected' : '' ?>>Other / Lab</option>
                  </select>
                </div>
              </div>

              <div class="form-check form-switch p-0 mt-3 pt-3 border-top d-flex justify-content-between align-items-center">
                <div>
                  <label class="form-check-label fw-semibold text-dark small" for="editSubStatus-<?= $sub['id'] ?>">Active Status</label>
                  <div class="text-muted" style="font-size: 12px;">Enable or disable this subject across curriculum and exams.</div>
                </div>
                <input class="form-check-input ms-0" type="checkbox" role="switch" name="status" value="1" id="editSubStatus-<?= $sub['id'] ?>" <?= (int)($sub['status'] ?? 1) === 1 ? 'checked' : '' ?> style="width: 2.5em; height: 1.25em;">
              </div>
            </div>
            <div class="modal-footer bg-light px-4 py-3 border-top">
              <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
              <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
  <?php endforeach; ?>
<?php endif; ?>

<!-- Hidden form for deleting a subject -->
<form id="deleteSubjectForm" method="post" action="" style="display: none;">
  <?= csrf_field() ?>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('subjectSearchInput');
  const statusFilter = document.getElementById('subjectStatusFilter');
  const tableBody = document.getElementById('subjectTableBody');
  const rows = Array.from(document.querySelectorAll('.subject-row'));
  const recordCounter = document.getElementById('subjectRecordCounter');
  const noResultsRow = document.getElementById('noSubjectResultsRow');
  const totalCount = rows.length;

  // Filter Function
  function filterSubjects() {
    const query = searchInput.value.trim().toLowerCase();
    const status = statusFilter.value.toLowerCase();
    let visibleCount = 0;

    rows.forEach(row => {
      const name = row.getAttribute('data-name') || '';
      const code = row.getAttribute('data-code') || '';
      const rowStatus = row.getAttribute('data-status') || '';

      const matchesQuery = query === '' || name.includes(query) || code.includes(query);
      const matchesStatus = status === 'all' || rowStatus === status;

      if (matchesQuery && matchesStatus) {
        row.style.display = '';
        visibleCount++;
      } else {
        row.style.display = 'none';
      }
    });

    if (recordCounter) {
      recordCounter.textContent = `Showing 1 to ${visibleCount} of ${totalCount} records`;
    }

    if (noResultsRow) {
      noResultsRow.style.display = visibleCount === 0 ? '' : 'none';
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterSubjects);
  }
  if (statusFilter) {
    statusFilter.addEventListener('change', filterSubjects);
  }

  // Column Sorting
  let currentSortCol = null;
  let currentSortAsc = true;

  document.querySelectorAll('.sortable-sub-th').forEach(th => {
    th.addEventListener('click', function() {
      const col = this.getAttribute('data-col');
      if (currentSortCol === col) {
        currentSortAsc = !currentSortAsc;
      } else {
        currentSortCol = col;
        currentSortAsc = true;
      }

      // Update sort indicators
      document.querySelectorAll('.sortable-sub-th .sort-icon').forEach(si => si.textContent = '⇅');
      const sortIcon = this.querySelector('.sort-icon');
      if (sortIcon) {
        sortIcon.textContent = currentSortAsc ? '↑' : '↓';
      }

      rows.sort((a, b) => {
        let valA = a.getAttribute(`data-${col}`);
        let valB = b.getAttribute(`data-${col}`);

        if (col === 'mapped') {
          valA = parseInt(valA, 10) || 0;
          valB = parseInt(valB, 10) || 0;
          return currentSortAsc ? valA - valB : valB - valA;
        } else {
          valA = (valA || '').toLowerCase();
          valB = (valB || '').toLowerCase();
          if (valA < valB) return currentSortAsc ? -1 : 1;
          if (valA > valB) return currentSortAsc ? 1 : -1;
          return 0;
        }
      });

      rows.forEach(r => tableBody.appendChild(r));
    });
  });

  // Row hover effect
  rows.forEach(row => {
    row.addEventListener('mouseenter', () => {
      row.style.backgroundColor = '#f8fafc';
    });
    row.addEventListener('mouseleave', () => {
      row.style.backgroundColor = '';
    });
  });

  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
});

function confirmDeleteSubject(id, name) {
  showDeleteConfirm({
    title: 'Delete Subject',
    message: `Are you sure you want to delete ${name}?`,
    subtext: 'This action cannot be undone if it is mapped to classes.',
    confirmText: 'Delete',
    onConfirm: function() {
      const form = document.getElementById('deleteSubjectForm');
      form.action = `<?= e(url('subjects')) ?>/${id}/delete`;
      form.submit();
    }
  });
}
</script>

<style>
.btn-icon-action {
  color: #64748b;
  background: transparent;
  border: 1px solid transparent;
  padding: 4px 6px;
  border-radius: 6px;
  transition: all 0.15s ease;
}
.btn-icon-action:hover {
  color: #4f46e5;
  background-color: #f1f5f9;
}
.btn-icon-action.text-danger:hover {
  color: #ef4444 !important;
  background-color: #fef2f2;
}
.hover-bg-light:hover {
  background-color: #f8fafc;
  color: #1e293b !important;
}
.sortable-sub-th:hover {
  background-color: #f8fafc;
  color: #1e293b !important;
}
</style>
