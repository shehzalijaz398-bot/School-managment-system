<?php
$title = $title ?? 'Books Catalog';
$layout = 'layouts/app';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-book-open text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Manage library inventory, add new books, and update details.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('library')) ?>" class="btn btn-light shadow-sm action-hover rounded-pill px-3 fw-bold text-secondary">
            <i class="fas fa-arrow-left me-1"></i> Dashboard
        </a>
        <?php if (canAccessMenu('library.manage')): ?>
        <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm action-hover rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#addBookModal">
            <i class="fas fa-plus"></i> Add Book
        </button>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-3">
        <form action="<?= e(url('library/books')) ?>" method="GET" class="d-flex align-items-center gap-2 m-0">
            <div class="input-group shadow-sm rounded-pill overflow-hidden">
                <span class="input-group-text bg-light border-0"><i class="fas fa-search text-muted"></i></span>
                <input type="text" name="q" class="form-control border-0 bg-light shadow-none" placeholder="Search by title, author, or ISBN..." value="<?= e($query ?? '') ?>">
            </div>
            <button class="btn btn-primary rounded-pill px-4 fw-bold shadow-sm action-hover" type="submit">Search</button>
            <?php if (!empty($query)): ?>
            <a href="<?= e(url('library/books')) ?>" class="btn btn-light rounded-pill px-3 shadow-sm action-hover text-danger fw-bold" title="Clear Search">
                <i class="fas fa-times"></i>
            </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3" style="width: 35%;">Book Details</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">ISBN & Category</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Stock Info</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Status</th>
                    <?php if (canAccessMenu('library.manage')): ?>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($books as $book): ?>
                <tr class="book-row">
                    <td class="px-4 py-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 48px; height: 48px;">
                                <i class="fas fa-book"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-sm fw-bold text-gray-800 text-wrap" style="max-width: 250px;"><?= e($book['title']) ?></h6>
                                <span class="text-xs text-muted"><i class="fas fa-user-edit me-1 text-light"></i> <?= e($book['author']) ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="py-3">
                        <div class="text-sm fw-semibold text-secondary mb-1">
                            <i class="fas fa-barcode text-muted me-1"></i> <?= e($book['isbn'] ?: 'N/A') ?>
                        </div>
                        <span class="badge bg-light text-dark border"><i class="fas fa-folder-open text-muted me-1"></i> <?= e($book['category_name'] ?: 'Uncategorized') ?></span>
                    </td>
                    <td class="py-3 text-sm">
                        <div class="mb-1"><span class="text-muted fw-bold">Total:</span> <?= (int)$book['quantity'] ?></div>
                        <div>
                            <span class="fw-bold">Available:</span> 
                            <span class="<?= $book['available_quantity'] > 0 ? 'text-success' : 'text-danger' ?> fw-bold">
                                <?= (int)$book['available_quantity'] ?>
                            </span>
                        </div>
                    </td>
                    <td class="py-3">
                        <?php if ($book['status'] === 'active'): ?>
                            <span class="badge bg-success rounded-pill px-3 shadow-sm">Active</span>
                        <?php elseif ($book['status'] === 'inactive'): ?>
                            <span class="badge bg-secondary rounded-pill px-3 shadow-sm">Inactive</span>
                        <?php else: ?>
                            <span class="badge bg-danger rounded-pill px-3 shadow-sm">Lost</span>
                        <?php endif; ?>
                    </td>
                    <?php if (canAccessMenu('library.manage')): ?>
                    <td class="px-4 py-3 text-end">
                        <button class="btn btn-sm btn-outline-primary rounded-pill px-3 shadow-sm action-hover edit-book-btn" 
                            data-id="<?= e($book['id']) ?>"
                            data-title="<?= e($book['title']) ?>"
                            data-author="<?= e($book['author']) ?>"
                            data-isbn="<?= e($book['isbn']) ?>"
                            data-publisher="<?= e($book['publisher']) ?>"
                            data-quantity="<?= e($book['quantity']) ?>"
                            data-category="<?= e($book['category_id']) ?>"
                            data-status="<?= e($book['status']) ?>"
                            data-bs-toggle="modal" data-bs-target="#editBookModal" title="Edit Book">
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($books)): ?>
                <tr>
                    <td colspan="<?= canAccessMenu('library.manage') ? '5' : '4' ?>" class="text-center py-5 text-muted">
                        <i class="fas fa-book-dead fa-3x mb-3 text-light"></i>
                        <h5 class="fw-bold text-gray-500">No Books Found</h5>
                        <p class="mb-0 text-sm">Try adjusting your search or add a new book to the library.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (canAccessMenu('library.manage')): ?>
<!-- Add Book Modal -->
<div class="modal fade" id="addBookModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-primary text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle me-2"></i> Add New Book</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= e(url('library/books')) ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    
                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-info-circle me-1"></i> Essential Info</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Book Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control rounded-3 shadow-sm border-0" required placeholder="e.g. Harry Potter">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Author <span class="text-danger">*</span></label>
                            <input type="text" name="author" class="form-control rounded-3 shadow-sm border-0" required placeholder="e.g. J.K. Rowling">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Category <span class="text-danger">*</span></label>
                            <select name="category_id" class="form-select rounded-3 shadow-sm border-0" required>
                                <option value="">Select Category...</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Quantity <span class="text-danger">*</span></label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-boxes text-muted"></i></span>
                                <input type="number" name="quantity" class="form-control border-0 bg-white" min="1" value="1" required>
                            </div>
                        </div>
                    </div>

                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-barcode me-1"></i> Additional Details</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">ISBN (Optional)</label>
                            <input type="text" name="isbn" class="form-control rounded-3 shadow-sm border-0" placeholder="e.g. 978-3-16-148410-0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Publisher (Optional)</label>
                            <input type="text" name="publisher" class="form-control rounded-3 shadow-sm border-0" placeholder="e.g. Bloomsbury">
                        </div>
                        <div class="col-md-6 mt-3">
                            <label class="form-label text-sm fw-semibold">Status</label>
                            <select name="status" class="form-select rounded-3 shadow-sm border-0">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="lost">Lost</option>
                            </select>
                        </div>
                    </div>

                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-save me-1"></i> Add Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Book Modal -->
<div class="modal fade" id="editBookModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-primary text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i> Edit Book Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editBookForm" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    
                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-info-circle me-1"></i> Essential Info</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Book Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="edit_title" class="form-control rounded-3 shadow-sm border-0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Author <span class="text-danger">*</span></label>
                            <input type="text" name="author" id="edit_author" class="form-control rounded-3 shadow-sm border-0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Category <span class="text-danger">*</span></label>
                            <select name="category_id" id="edit_category" class="form-select rounded-3 shadow-sm border-0" required>
                                <option value="">Select Category...</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Total Quantity <span class="text-danger">*</span></label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-boxes text-muted"></i></span>
                                <input type="number" name="quantity" id="edit_quantity" class="form-control border-0 bg-white" min="0" required>
                            </div>
                            <small class="text-muted text-xs">Cannot reduce below issued amount.</small>
                        </div>
                    </div>

                    <h6 class="text-uppercase text-muted text-xs fw-bold mb-3"><i class="fas fa-barcode me-1"></i> Additional Details</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">ISBN</label>
                            <input type="text" name="isbn" id="edit_isbn" class="form-control rounded-3 shadow-sm border-0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Publisher</label>
                            <input type="text" name="publisher" id="edit_publisher" class="form-control rounded-3 shadow-sm border-0">
                        </div>
                        <div class="col-md-6 mt-3">
                            <label class="form-label text-sm fw-semibold">Status</label>
                            <select name="status" id="edit_status" class="form-select rounded-3 shadow-sm border-0">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="lost">Lost</option>
                            </select>
                        </div>
                    </div>

                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-check-circle me-1"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.edit-book-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            document.getElementById('editBookForm').action = '<?= url("library/books/") ?>' + id;
            document.getElementById('edit_title').value = btn.dataset.title;
            document.getElementById('edit_author').value = btn.dataset.author;
            document.getElementById('edit_isbn').value = btn.dataset.isbn;
            document.getElementById('edit_publisher').value = btn.dataset.publisher;
            document.getElementById('edit_quantity').value = btn.dataset.quantity;
            document.getElementById('edit_category').value = btn.dataset.category;
            document.getElementById('edit_status').value = btn.dataset.status;
        });
    });
});
</script>
<?php endif; ?>

<style>
    /* Premium Hover Effects */
    .book-row {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        border-radius: 12px;
    }
    .book-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px -10px rgba(0, 0, 0, 0.1);
        z-index: 10;
        position: relative;
    }
    .book-row:hover .avatar {
        transform: scale(1.15) rotate(5deg);
        box-shadow: 0 4px 10px rgba(13, 110, 253, 0.25) !important;
    }
    
    .bg-primary-subtle {
        background-color: #cfe2ff !important;
    }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15) !important;
    }
    
    .table > :not(caption) > * > * {
        border-bottom-color: #f1f5f9;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
    }
</style>
