<?php
$title = $title ?? 'Library Dashboard';
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-book-reader text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Overview of library resources, issued books, and inventory.</p>
    </div>
</div>

<!-- Stats Row -->
<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden stat-card">
            <div class="card-body p-4 position-relative">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h6 class="text-uppercase text-muted fw-bold text-xs mb-1">Total Books</h6>
                        <h2 class="mb-0 fw-bold text-gray-800"><?= number_format((float)$stats['total_books']) ?></h2>
                    </div>
                    <div class="avatar bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                        <i class="fas fa-book fa-lg"></i>
                    </div>
                </div>
                <div class="progress" style="height: 4px;">
                    <div class="progress-bar bg-primary" role="progressbar" style="width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden stat-card">
            <div class="card-body p-4 position-relative">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h6 class="text-uppercase text-muted fw-bold text-xs mb-1">Available for Issue</h6>
                        <h2 class="mb-0 fw-bold text-success"><?= number_format((float)$stats['available_books']) ?></h2>
                    </div>
                    <div class="avatar bg-success-subtle text-success rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                        <i class="fas fa-check-circle fa-lg"></i>
                    </div>
                </div>
                <div class="progress" style="height: 4px;">
                    <?php 
                        $availPct = $stats['total_books'] > 0 ? ($stats['available_books'] / $stats['total_books'] * 100) : 0;
                    ?>
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= $availPct ?>%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden stat-card">
            <div class="card-body p-4 position-relative">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h6 class="text-uppercase text-muted fw-bold text-xs mb-1">Currently Issued</h6>
                        <h2 class="mb-0 fw-bold text-warning"><?= number_format((float)$stats['issued_books']) ?></h2>
                    </div>
                    <div class="avatar bg-warning-subtle text-warning rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                        <i class="fas fa-hand-holding text-dark fa-lg"></i>
                    </div>
                </div>
                <div class="progress" style="height: 4px;">
                    <?php 
                        $issuedPct = $stats['total_books'] > 0 ? ($stats['issued_books'] / $stats['total_books'] * 100) : 0;
                    ?>
                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?= $issuedPct ?>%;"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Navigation Cards -->
<h5 class="fw-bold text-gray-800 mb-3"><i class="fas fa-compass text-secondary me-2"></i> Library Modules</h5>
<div class="row g-4">
    <div class="col-md-6 col-lg-4">
        <a href="<?= e(url('library/books')) ?>" class="card text-decoration-none h-100 border-0 shadow-sm rounded-4 nav-module-card position-relative overflow-hidden">
            <div class="card-body p-4 d-flex align-items-start gap-3">
                <div class="icon-box bg-primary text-white rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 48px; height: 48px; flex-shrink: 0;">
                    <i class="fas fa-book-open"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-gray-800 mb-1">Manage Books</h5>
                    <p class="text-sm text-muted mb-0">View, add, update, and search library inventory.</p>
                </div>
            </div>
            <div class="card-arrow text-primary"><i class="fas fa-chevron-right"></i></div>
        </a>
    </div>
    
    <div class="col-md-6 col-lg-4">
        <a href="<?= e(url('library/issues')) ?>" class="card text-decoration-none h-100 border-0 shadow-sm rounded-4 nav-module-card position-relative overflow-hidden">
            <div class="card-body p-4 d-flex align-items-start gap-3">
                <div class="icon-box bg-success text-white rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 48px; height: 48px; flex-shrink: 0;">
                    <i class="fas fa-exchange-alt"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-gray-800 mb-1">Issue & Returns</h5>
                    <p class="text-sm text-muted mb-0">Handle book circulations for students and staff.</p>
                </div>
            </div>
            <div class="card-arrow text-success"><i class="fas fa-chevron-right"></i></div>
        </a>
    </div>

    <?php if (canAccessMenu('library.manage')): ?>
    <div class="col-md-6 col-lg-4">
        <a href="<?= e(url('library/categories')) ?>" class="card text-decoration-none h-100 border-0 shadow-sm rounded-4 nav-module-card position-relative overflow-hidden">
            <div class="card-body p-4 d-flex align-items-start gap-3">
                <div class="icon-box bg-dark text-white rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 48px; height: 48px; flex-shrink: 0;">
                    <i class="fas fa-layer-group"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-gray-800 mb-1">Categories</h5>
                    <p class="text-sm text-muted mb-0">Organize and manage book genres and categories.</p>
                </div>
            </div>
            <div class="card-arrow text-dark"><i class="fas fa-chevron-right"></i></div>
        </a>
    </div>
    <?php endif; ?>
</div>

<style>
    /* Premium Hover Effects */
    .stat-card {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px -10px rgba(0,0,0,0.1) !important;
    }
    
    .nav-module-card {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    .nav-module-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px -8px rgba(0,0,0,0.15) !important;
        border-color: #e2e8f0;
        background-color: #f8fafc;
    }
    .nav-module-card .icon-box {
        transition: all 0.3s ease;
    }
    .nav-module-card:hover .icon-box {
        transform: scale(1.1) rotate(5deg);
    }
    .card-arrow {
        position: absolute;
        right: 20px;
        top: 50%;
        transform: translateY(-50%) translateX(-10px);
        opacity: 0;
        transition: all 0.3s ease;
        font-size: 1.2rem;
    }
    .nav-module-card:hover .card-arrow {
        opacity: 1;
        transform: translateY(-50%) translateX(0);
    }
    
    .bg-primary-subtle { background-color: #cfe2ff !important; }
    .bg-success-subtle { background-color: #d1e7dd !important; }
    .bg-warning-subtle { background-color: #fff3cd !important; }
</style>
