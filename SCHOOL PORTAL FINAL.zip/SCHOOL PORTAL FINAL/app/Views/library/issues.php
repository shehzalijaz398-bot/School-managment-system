<?php
$title = $title ?? 'Book Issues & Returns';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?= e($title) ?></h2>
    <div>
        <a href="<?= e(url('library')) ?>" class="btn btn-outline-secondary me-2">Dashboard</a>
        <?php if (canAccessMenu('library.manage')): ?>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#issueBookModal">Issue Book</button>
        <?php endif; ?>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Book</th>
                        <th>Issued To</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <?php if (canAccessMenu('library.manage')): ?>
                        <th class="text-end">Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($issues)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No issue records found.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($issues as $issue): ?>
                    <tr>
                        <td>
                            <strong><?= e($issue['book_title']) ?></strong><br>
                            <small class="text-muted">ISBN: <?= e($issue['isbn'] ?: 'N/A') ?></small>
                        </td>
                        <td>
                            <?= e($issue['member_name']) ?><br>
                            <span class="badge bg-light text-dark border"><?= ucfirst($issue['member_type']) ?></span>
                        </td>
                        <td><?= e(date('M d, Y', strtotime($issue['issue_date']))) ?></td>
                        <td>
                            <?php 
                            $dueDate = strtotime($issue['due_date']);
                            $isOverdue = $issue['status'] === 'issued' && $dueDate < time();
                            ?>
                            <span class="<?= $isOverdue ? 'text-danger fw-bold' : '' ?>">
                                <?= e(date('M d, Y', $dueDate)) ?>
                            </span>
                            <?php if ($isOverdue): ?>
                                <br><small class="text-danger">Overdue</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($issue['status'] === 'issued'): ?>
                                <span class="badge bg-warning text-dark">Issued</span>
                            <?php elseif ($issue['status'] === 'returned'): ?>
                                <span class="badge bg-success">Returned<br><small><?= date('M d, Y', strtotime($issue['return_date'])) ?></small></span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?= ucfirst($issue['status']) ?></span>
                            <?php endif; ?>
                        </td>
                        <?php if (canAccessMenu('library.manage')): ?>
                        <td class="text-end">
                            <?php if ($issue['status'] === 'issued'): ?>
                            <form action="<?= e(url("library/issues/{$issue['id']}/return")) ?>" method="POST" class="d-inline" onsubmit="return confirm('Confirm book return?');">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-success">Return</button>
                            </form>
                            <?php else: ?>
                            <button class="btn btn-sm btn-light" disabled>Returned</button>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if (canAccessMenu('library.manage')): ?>
<!-- Issue Book Modal -->
<div class="modal fade" id="issueBookModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= e(url('library/issues')) ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-header">
                    <h5 class="modal-title">Issue Book</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Select Book <span class="text-danger">*</span></label>
                        <select name="book_id" class="form-select" required>
                            <option value="">Select an available book...</option>
                            <?php foreach ($books as $book): ?>
                                <?php if ($book['available_quantity'] > 0): ?>
                                <option value="<?= $book['id'] ?>">
                                    <?= e($book['title']) ?> by <?= e($book['author']) ?> (<?= $book['available_quantity'] ?> available)
                                </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Member Type <span class="text-danger">*</span></label>
                        <select name="member_type" id="member_type" class="form-select" required>
                            <option value="student">Student</option>
                            <option value="employee">Employee</option>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="student_select_div">
                        <label class="form-label">Select Student <span class="text-danger">*</span></label>
                        <select name="member_id" id="student_id" class="form-select">
                            <option value="">Select Student...</option>
                            <?php foreach ($students as $student): ?>
                            <option value="<?= $student['id'] ?>"><?= e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?> (<?= e($student['admission_no'] ?? ($student['admission_number'] ?? '')) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3 d-none" id="employee_select_div">
                        <label class="form-label">Select Employee <span class="text-danger">*</span></label>
                        <select name="member_id_emp" id="employee_id" class="form-select">
                            <option value="">Select Employee...</option>
                            <?php foreach ($employees as $employee): ?>
                            <option value="<?= $employee['id'] ?>"><?= e($employee['first_name'] . ' ' . $employee['last_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Due Date <span class="text-danger">*</span></label>
                        <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+14 days')) ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Issue Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const typeSelect = document.getElementById('member_type');
    const studentDiv = document.getElementById('student_select_div');
    const employeeDiv = document.getElementById('employee_select_div');
    const studentId = document.getElementById('student_id');
    const employeeId = document.getElementById('employee_id');

    typeSelect.addEventListener('change', (e) => {
        if (e.target.value === 'student') {
            studentDiv.classList.remove('d-none');
            employeeDiv.classList.add('d-none');
            studentId.setAttribute('name', 'member_id');
            studentId.setAttribute('required', 'required');
            employeeId.removeAttribute('name');
            employeeId.removeAttribute('required');
        } else {
            studentDiv.classList.add('d-none');
            employeeDiv.classList.remove('d-none');
            employeeId.setAttribute('name', 'member_id');
            employeeId.setAttribute('required', 'required');
            studentId.removeAttribute('name');
            studentId.removeAttribute('required');
        }
    });
});
</script>
<?php endif; ?>
