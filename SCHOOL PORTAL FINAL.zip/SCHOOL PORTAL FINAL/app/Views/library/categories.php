<?php
$title = $title ?? 'Book Categories';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?= e($title) ?></h2>
    <a href="<?= e(url('library')) ?>" class="btn btn-outline-secondary">Back to Library</a>
</div>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title">Add Category</h5>
                <form action="<?= e(url('library/categories')) ?>" method="POST">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Category Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <button class="btn btn-primary w-100">Add Category</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th class="text-end">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($categories)): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted py-4">No categories found.</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($categories as $cat): ?>
                            <tr>
                                <td><?= e($cat['name']) ?></td>
                                <td class="text-end text-muted small"><?= e(date('M d, Y', strtotime($cat['created_at']))) ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
