<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= e($title ?? 'Print') ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body class="p-4">
  <div class="no-print mb-3">
    <button onclick="window.print()" class="btn btn-primary btn-sm">Print</button>
    <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm">Back</a>
  </div>
  <?= $content ?>
</body>
</html>
