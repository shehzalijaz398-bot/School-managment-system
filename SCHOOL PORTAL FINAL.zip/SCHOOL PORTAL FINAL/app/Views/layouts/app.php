<?php
$user = currentUser();
$school = currentSchool();
$schoolName = $school['name'] ?? ($user['school_name'] ?? 'CodeClove');
$role = $user['role_slug'] ?? 'school_admin';

// Active / Viewing Session query
$viewYearId = !empty($_SESSION['selected_academic_year_id']) ? (int)$_SESSION['selected_academic_year_id'] : 0;
$currentSession = null;
if ($viewYearId && !empty($school['id'])) {
    $currentSession = \Core\Database::fetch(
        "SELECT * FROM academic_years WHERE id = ? AND school_id = ? LIMIT 1",
        [$viewYearId, (int)$school['id']]
    );
}
if (!$currentSession && !empty($school['id'])) {
    $currentSession = \Core\Database::fetch(
        "SELECT * FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1",
        [(int)$school['id']]
    );
}
if (!$currentSession && !empty($school['id'])) {
    $currentSession = \Core\Database::fetch(
        "SELECT * FROM academic_years WHERE school_id = ? ORDER BY start_date DESC LIMIT 1",
        [(int)$school['id']]
    );
}

$sessionDisplayName = $currentSession['name'] ?? '2026-2027';
$sessionTag = 'Current';
if (!empty($currentSession)) {
    if ((int)($currentSession['is_active'] ?? 0) === 1) {
        $sessionTag = 'Current';
    } elseif (($currentSession['status'] ?? '') === 'future' || (!empty($currentSession['start_date']) && $currentSession['start_date'] > date('Y-m-d'))) {
        $sessionTag = 'Future';
    } else {
        $sessionTag = 'Archived';
    }
}

// Available Sessions for the dropdown
$availableSessions = [];
if (!empty($school['id'])) {
    if ($role === 'parent') {
        $pId = (int)($user['parent_id'] ?? 0);
        $pChildren = (new \App\Models\ParentModel())->children($pId);
        $actChildId = (int)($_SESSION['selected_student_id'] ?? ($pChildren[0]['id'] ?? 0));
        if ($actChildId > 0) {
            $availableSessions = \Core\Database::fetchAll(
                "SELECT DISTINCT ay.* 
                 FROM academic_years ay
                 WHERE ay.school_id = :school_id
                   AND (
                       ay.id IN (SELECT academic_year_id FROM students WHERE id = :cid AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_academic_history WHERE student_id = :cid2 AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_attendance WHERE student_id = :cid3 AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_fee_invoices WHERE student_id = :cid4 AND academic_year_id IS NOT NULL)
                       OR ay.is_active = 1
                   )
                 ORDER BY ay.start_date DESC",
                [
                    'school_id' => (int)$school['id'],
                    'cid' => $actChildId,
                    'cid2' => $actChildId,
                    'cid3' => $actChildId,
                    'cid4' => $actChildId,
                ]
            );
        }
    } elseif ($role === 'student') {
        $stId = (int)(\Core\Database::fetch("SELECT id FROM students WHERE user_id = ? AND school_id = ? LIMIT 1", [(int)$user['id'], (int)$school['id']])['id'] ?? 0);
        if ($stId > 0) {
            $availableSessions = \Core\Database::fetchAll(
                "SELECT DISTINCT ay.* 
                 FROM academic_years ay
                 WHERE ay.school_id = :school_id
                   AND (
                       ay.id IN (SELECT academic_year_id FROM students WHERE id = :sid AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_academic_history WHERE student_id = :sid2 AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_attendance WHERE student_id = :sid3 AND academic_year_id IS NOT NULL)
                       OR ay.id IN (SELECT academic_year_id FROM student_fee_invoices WHERE student_id = :sid4 AND academic_year_id IS NOT NULL)
                       OR ay.is_active = 1
                   )
                 ORDER BY ay.start_date DESC",
                [
                    'school_id' => (int)$school['id'],
                    'sid' => $stId,
                    'sid2' => $stId,
                    'sid3' => $stId,
                    'sid4' => $stId,
                ]
            );
        }
    }

    // Fallback if empty or for staff/admin
    if (empty($availableSessions)) {
        if (!in_array($role, ['parent', 'student'], true)) {
            $availableSessions = \Core\Database::fetchAll(
                "SELECT * FROM academic_years WHERE school_id = ? ORDER BY start_date DESC",
                [(int)$school['id']]
            );
        } elseif ($currentSession) {
            $availableSessions = [$currentSession];
        }
    }
}

\Core\Language::init();
$direction = \Core\Language::getDirection();
$activeLanguages = \Core\Language::getActiveLanguages();
$currentLocale = \Core\Language::current();

// Query School Appearance Settings
$appearanceSettings = [];
if (!empty($school['id'])) {
    $appearanceRows = \Core\Database::fetchAll(
        "SELECT setting_key, setting_value FROM settings WHERE school_id = ? AND setting_key IN ('theme_mode', 'dark_mode', 'theme_color', 'accent_color', 'layout_density', 'sidebar_density', 'table_density', 'display_scale')",
        [(int) $school['id']]
    );
    foreach ($appearanceRows as $ar) {
        $appearanceSettings[$ar['setting_key']] = $ar['setting_value'];
    }
}
$savedThemeMode = $appearanceSettings['theme_mode'] ?? 'light';
$savedThemeColor = !empty($appearanceSettings['theme_color']) ? $appearanceSettings['theme_color'] : '#4f46e5';
$savedLayoutDensity = $appearanceSettings['layout_density'] ?? 'Fluid';
$savedSidebarDensity = $appearanceSettings['sidebar_density'] ?? 'Comfortable';
$savedTableDensity = $appearanceSettings['table_density'] ?? 'Comfortable';
$savedDisplayScale = $appearanceSettings['display_scale'] ?? '100%';

$layoutSlug = 'fluid';
$sidebarSlug = str_contains(strtolower($savedSidebarDensity), 'minimal') || str_contains(strtolower($savedSidebarDensity), 'icon') ? 'minimal' : (str_contains(strtolower($savedSidebarDensity), 'compact') ? 'compact' : 'comfortable');
$tableSlug = str_contains(strtolower($savedTableDensity), 'compact') ? 'compact' : (str_contains(strtolower($savedTableDensity), 'spacious') ? 'spacious' : 'comfortable');
$scaleSlug = str_contains($savedDisplayScale, '90') ? '90%' : (str_contains($savedDisplayScale, '110') ? '110%' : (str_contains($savedDisplayScale, '125') ? '125%' : '100%'));

$hexClean = ltrim($savedThemeColor, '#');
if (strlen($hexClean) === 3) {
    $hexClean = $hexClean[0].$hexClean[0].$hexClean[1].$hexClean[1].$hexClean[2].$hexClean[2];
}
$rVal = hexdec(substr($hexClean, 0, 2)) ?: 79;
$gVal = hexdec(substr($hexClean, 2, 2)) ?: 70;
$bVal = hexdec(substr($hexClean, 4, 2)) ?: 229;
$savedRgb = "$rVal, $gVal, $bVal";
$lum = (0.299 * $rVal + 0.587 * $gVal + 0.114 * $bVal) / 255;
$savedContrastColor = $lum > 0.52 ? '#0f1117' : '#ffffff';
?>
<!DOCTYPE html>
<html lang="<?= e($currentLocale) ?>" dir="<?= e($direction) ?>" data-theme="<?= e($savedThemeMode) ?>" data-theme-mode="<?= e($savedThemeMode) ?>" data-layout-density="<?= e($layoutSlug) ?>" data-sidebar-density="<?= e($sidebarSlug) ?>" data-table-density="<?= e($tableSlug) ?>" data-display-scale="<?= e($scaleSlug) ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= e($title ?? 'Dashboard') ?> · <?= e($schoolName) ?> Enterprise Portal</title>
  
  <!-- High-Level SEO Meta Tags -->
  <meta name="description" content="<?= e($schoolName) ?> Portal - High-performance enterprise school ERP system providing real-time academic tracking, student & parent portals, fee & finance management, and faculty administration.">
  <meta name="keywords" content="school portal, student portal, parent portal, school erp, education management, fee finance system, student attendance, gradebook, timetable">
  <meta name="author" content="<?= e($schoolName) ?> Admin & Technology Services">
  <meta name="robots" content="index, follow">
  <meta name="theme-color" content="<?= e($savedThemeColor) ?>">

  <!-- Open Graph / Social Media -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?= e($title ?? 'Dashboard') ?> · <?= e($schoolName) ?>">
  <meta property="og:description" content="All-in-one institutional management portal for parents, students, teachers, and finance teams.">
  <meta property="og:site_name" content="<?= e($schoolName) ?> Portal">
  
  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= e($title ?? 'Dashboard') ?> · <?= e($schoolName) ?>">
  <meta name="twitter:description" content="All-in-one institutional management portal for parents, students, teachers, and finance teams.">
  
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%234f46e5' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22 10v6M2 10l10-5 10 5-10 5z'/><path d='M6 12v5c3 3 9 3 12 0v-5'/></svg>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <?php if ($direction === 'rtl'): ?>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <?php else: ?>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <?php endif; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
  <script src="https://unpkg.com/lucide@latest"></script>
  <style id="cc-dynamic-theme-styles">
    :root {
      --sp-primary: <?= e($savedThemeColor) ?>;
      --sp-primary-dark: <?= e($savedThemeColor) ?>;
      --bs-primary: <?= e($savedThemeColor) ?>;
      --sp-primary-rgb: <?= $savedRgb ?>;
      --sp-primary-light: rgba(<?= $savedRgb ?>, 0.12);
      --sp-primary-contrast: <?= $savedContrastColor ?>;
    }
    .cc-brand-logo:not(.has-custom-logo) {
      background-color: var(--sp-primary) !important;
      border-radius: 50% !important;
    }
    .cc-brand-logo:not(.has-custom-logo) svg {
      stroke: var(--sp-primary-contrast, #ffffff) !important;
    }
    .cc-brand-logo.has-custom-logo {
      background-color: transparent !important;
      border-radius: 8px !important;
      overflow: hidden !important;
      padding: 0 !important;
    }
    .cc-brand-logo.has-custom-logo img {
      width: 100% !important;
      height: 100% !important;
      max-width: 36px !important;
      max-height: 36px !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      display: block !important;
    }
    .cc-btn-new {
      background-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .btn-primary, .btn-primary:focus, .cc-save-btn {
      background-color: var(--sp-primary) !important;
      border-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .btn-outline-primary {
      color: var(--sp-primary) !important;
      border-color: var(--sp-primary) !important;
    }
    .btn-outline-primary:hover {
      background-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .text-primary {
      color: var(--sp-primary) !important;
    }
    .bg-primary {
      background-color: var(--sp-primary) !important;
    }
    .cc-tab-link.active {
      color: var(--sp-primary) !important;
      background-color: var(--sp-primary-light) !important;
    }
    .cc-tab-link.active .cc-tab-icon {
      color: var(--sp-primary) !important;
      stroke: var(--sp-primary) !important;
    }
    .cc-theme-tile.active {
      border-color: var(--sp-primary) !important;
      color: var(--sp-primary) !important;
    }
    .cc-theme-tile.active svg {
      stroke: var(--sp-primary) !important;
    }
    .cc-accent-tile.active {
      border-color: var(--sp-primary) !important;
      box-shadow: 0 0 0 1px var(--sp-primary) !important;
    }
    .cc-card-icon-box {
      background-color: var(--sp-primary-light) !important;
      color: var(--sp-primary) !important;
    }
    .cc-card-icon-box svg {
      stroke: var(--sp-primary) !important;
    }
    .cc-unsaved-dot {
      background-color: var(--sp-primary) !important;
    }

    /* Dark Mode Dynamic Overrides */
    [data-theme="dark"] .cc-tab-link.active {
      color: #ffffff !important;
      background-color: rgba(<?= $savedRgb ?>, 0.12) !important;
      border: 1px solid rgba(<?= $savedRgb ?>, 0.35) !important;
    }
    [data-theme="dark"] .cc-tab-link.active .cc-tab-icon {
      color: var(--sp-primary) !important;
      stroke: var(--sp-primary) !important;
    }
    [data-theme="dark"] .cc-theme-tile.active {
      border: 1.5px solid var(--sp-primary) !important;
      color: #ffffff !important;
      background-color: #11141d !important;
      box-shadow: 0 0 12px rgba(<?= $savedRgb ?>, 0.2) !important;
    }
    [data-theme="dark"] .cc-theme-tile.active svg {
      stroke: var(--sp-primary) !important;
    }
    [data-theme="dark"] .cc-accent-tile.active {
      border: 1.5px solid var(--sp-primary) !important;
      box-shadow: 0 0 12px rgba(<?= $savedRgb ?>, 0.25) !important;
      background-color: #11141d !important;
      color: #ffffff !important;
    }
    [data-theme="dark"] .cc-accent-tile.active .cc-accent-label {
      color: #ffffff !important;
    }
    [data-theme="dark"] .cc-card-icon-box {
      background-color: rgba(<?= $savedRgb ?>, 0.14) !important;
      color: var(--sp-primary) !important;
    }
    [data-theme="dark"] .cc-card-icon-box svg {
      stroke: var(--sp-primary) !important;
    }
    [data-theme="dark"] .cc-nav-item.active,
    [data-theme="dark"] .cc-sub-item.active {
      background-color: rgba(<?= $savedRgb ?>, 0.12) !important;
      color: var(--sp-primary) !important;
    }
  </style>
</head>
<body class="app-body <?= $sidebarSlug === 'minimal' ? 'sidebar-collapsed' : '' ?>" data-app-url="<?= e(rtrim(app_config('url'), '/')) ?>">

<!-- Accessibility: Skip to Main Content Link -->
<a href="#mainWrap" class="cc-skip-to-content">Skip to main content</a>

<!-- Mobile Sidebar Backdrop Overlay -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app-layout-wrapper d-flex">
  <!-- CodeClove Pro Sidebar -->
  <?php require base_path('app/Views/partials/sidebar.php'); ?>

  <!-- Main Application Body -->
  <div class="main-wrap flex-grow-1" id="mainWrap" tabindex="-1">

    <!-- TOP NAVIGATION BAR -->
    <header class="cc-topbar">
      <!-- Left side: Mobile Toggle & Session Pill -->
      <div class="d-flex align-items-center gap-2 gap-sm-3">
        <!-- Mobile Sidebar Hamburger Toggle Button (Accessibility & Responsive Navigation) -->
        <button id="sidebarToggleBtn" class="cc-icon-btn d-lg-none" type="button" aria-label="Toggle navigation menu" aria-controls="appSidebar" aria-expanded="false">
          <i data-lucide="menu" style="width: 20px; height: 20px;"></i>
        </button>
        <?php if ($role !== 'student'): ?>
        <!-- Session Selector Pill Dropdown -->
        <div class="dropdown d-inline-block" id="sessionDropdownWrap">
          <button class="cc-session-pill dropdown-toggle" type="button" id="sessionToggleBtn" data-bs-toggle="dropdown" aria-expanded="false" title="Academic Session">
            <i data-lucide="calendar" class="cc-session-icon"></i>
            <span class="cc-session-label">Session</span>
            <strong class="cc-session-val" id="currentSessionDisplay"><?= e($sessionDisplayName) ?></strong>
            <span class="cc-session-badge cc-tag-<?= strtolower($sessionTag) ?>" id="currentSessionBadge"><?= e($sessionTag) ?></span>
          </button>
          <div class="dropdown-menu cc-session-dropdown-menu" aria-labelledby="sessionToggleBtn">
            <div class="cc-session-header">ACADEMIC SESSIONS</div>
            <?php foreach ($availableSessions as $as): ?>
              <?php
                $isCur = (int)($as['is_active'] ?? 0) === 1;
                $asTag = $isCur ? 'Current' : ((($as['status'] ?? '') === 'future' || (!empty($as['start_date']) && $as['start_date'] > date('Y-m-d'))) ? 'Future' : 'Archived');
                $isSelected = (!empty($currentSession) && (int)$currentSession['id'] === (int)$as['id']);
                $tagClass = $isCur ? 'cc-tag-current' : ($asTag === 'Future' ? 'cc-tag-future' : 'cc-tag-archived');
              ?>
              <a class="cc-session-item <?= $isSelected ? 'active' : '' ?>" href="<?= e(url('academic-sessions/switch-view?year_id=' . $as['id'])) ?>">
                <?php if ($isSelected): ?>
                  <i data-lucide="check" class="cc-session-check-icon"></i>
                <?php else: ?>
                  <span class="cc-session-check-placeholder"></span>
                <?php endif; ?>
                <span class="cc-session-name"><?= e($as['name']) ?></span>
                <span class="cc-session-pill-tag <?= e($tagClass) ?>"><?= e($asTag) ?></span>
              </a>
            <?php endforeach; ?>
            <?php if (!in_array($role, ['parent', 'student'], true) && hasPermission('settings.manage')): ?>
              <hr class="cc-session-divider">
              <a class="cc-session-manage-link" href="<?= e(url('settings?tab=academic-setup')) ?>">
                <i data-lucide="settings"></i>
                <span>Manage Sessions</span>
              </a>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Right side: Search, + New, Notifications, Theme, User -->
      <div class="d-flex align-items-center gap-2 gap-sm-3">
        
        <?php if ($role !== 'student'): ?>
        <!-- Global Search Bar with Shortcut -->
        <div class="cc-search-wrap d-none d-md-flex" id="globalSearchTrigger" title="Quick Search (Ctrl+K)">
          <i data-lucide="search" class="cc-search-icon"></i>
          <span class="cc-search-placeholder">Search...</span>
          <kbd class="cc-search-kbd">Ctrl+K</kbd>
        </div>

        <!-- + New Action Button with Dropdown -->
        <div class="dropdown" id="quickCreateDropdownWrap">
          <button class="cc-btn-new dropdown-toggle" type="button" id="quickCreateToggleBtn" data-bs-toggle="dropdown" aria-expanded="false" title="Quick Create">
            <i data-lucide="plus" style="width:15px;height:15px;"></i> New
          </button>
          <div class="dropdown-menu dropdown-menu-end cc-new-dropdown-menu" aria-labelledby="quickCreateToggleBtn">
            <div class="cc-new-header">QUICK CREATE</div>
            <a class="cc-new-item" href="<?= e(url('finance/invoices/new')) ?>">
              <i data-lucide="receipt"></i>
              <span>Create Invoice</span>
            </a>
            <a class="cc-new-item" href="<?= e(url('admissions/create')) ?>">
              <i data-lucide="user-plus"></i>
              <span>Admit Student</span>
            </a>
            <a class="cc-new-item" href="<?= e(url('staff/create')) ?>">
              <i data-lucide="briefcase"></i>
              <span>New Staff Record</span>
            </a>
            <a class="cc-new-item" href="<?= e(url('announcements')) ?>">
              <i data-lucide="megaphone"></i>
              <span>New Announcement</span>
            </a>
          </div>
        </div>
        <?php endif; ?>

        <?php if ($role === 'parent'): ?>
          <?php
            $parentId = (int)($user['parent_id'] ?? 0);
            $parentChildren = (new \App\Models\ParentModel())->children($parentId);
            if (empty($parentChildren)) {
                $defSt = (new \App\Models\Student())->findDetailed(8);
                if ($defSt) { $parentChildren = [$defSt]; }
            }
            $activeChildId = (int)($_SESSION['selected_student_id'] ?? ($parentChildren[0]['id'] ?? 8));
            $activeChild = null;
            foreach ($parentChildren as $pc) {
                if ((int)$pc['id'] === $activeChildId) {
                    $activeChild = $pc;
                    break;
                }
            }
            if (!$activeChild && !empty($parentChildren)) {
                $activeChild = $parentChildren[0];
            }
            $childName = $activeChild ? ($activeChild['first_name'] . ' ' . $activeChild['last_name']) : 'Alexander Bartholomew';
            $childMeta = $activeChild ? (($activeChild['class_name'] ?? 'Class 1') . ' · Section ' . ($activeChild['section_name'] ?? 'A')) : 'Class 1 · Section A';
            $initial = $activeChild ? strtoupper(substr($activeChild['first_name'], 0, 1)) : 'A';
          ?>
          <!-- Child Switcher Dropdown for Parent Portal (Matches Screenshot) -->
          <div class="dropdown me-2" id="childSwitcherDropdownWrap">
            <button class="btn btn-sm d-inline-flex align-items-center gap-2 border shadow-sm py-1 px-2 rounded-3 bg-white" type="button" id="childSwitcherBtn" data-bs-toggle="dropdown" aria-expanded="false" style="border-color: #e2e8f0 !important;">
              <div style="width: 26px; height: 26px; border-radius: 50%; background: #eef2ff; color: #4f46e5; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px;">
                <?= e($initial) ?>
              </div>
              <div class="text-start d-none d-sm-block" style="line-height: 1.2;">
                <div class="fw-bold text-dark text-truncate" style="font-size: 12px; max-width: 140px;"><?= e($childName) ?></div>
                <div class="text-secondary" style="font-size: 10px;"><?= e($childMeta) ?></div>
              </div>
              <i data-lucide="chevron-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border py-1" style="min-width: 210px; border-radius: 8px;">
              <li class="dropdown-header text-uppercase small fw-bold text-muted py-1" style="font-size: 10px;">Select Child</li>
              <?php foreach ($parentChildren as $pc): ?>
                <?php $isSelected = ((int)$pc['id'] === (int)($activeChild['id'] ?? 0)); ?>
                <li>
                  <form method="post" action="<?= e(url('dashboard/switch-child')) ?>" class="m-0 p-0">
                    <?= csrf_field() ?>
                    <input type="hidden" name="student_id" value="<?= (int)$pc['id'] ?>">
                    <button type="submit" class="dropdown-item d-flex align-items-center justify-content-between py-2 px-3 <?= $isSelected ? 'bg-light text-primary fw-semibold' : '' ?>" style="font-size: 12.5px;">
                      <div>
                        <div class="text-dark fw-medium"><?= e($pc['first_name'] . ' ' . $pc['last_name']) ?></div>
                        <div class="text-muted small" style="font-size: 11px;"><?= e(($pc['class_name'] ?? '') . ' · Sec ' . ($pc['section_name'] ?? '')) ?></div>
                      </div>
                      <?php if ($isSelected): ?>
                        <i data-lucide="check" style="width: 14px; height: 14px; color: #4f46e5;"></i>
                      <?php endif; ?>
                    </button>
                  </form>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <?php
          $navUserId = (int) ($user['id'] ?? \Core\Auth::id());
          $navUnreadCount = 0;
          $navRecentNotifs = [];
          if ($navUserId > 0) {
              $navNotifModel = new \App\Models\Notification();
              $navUnreadCount = $navNotifModel->unreadCount($navUserId);
              $navRecentNotifs = $navNotifModel->recentUnread($navUserId, 5);
          }
        ?>
        <!-- Notifications Dropdown -->
        <div class="dropdown" id="notificationDropdownWrap">
          <button class="cc-icon-btn position-relative no-caret" type="button" id="notificationToggleBtn" data-bs-toggle="dropdown" aria-expanded="false" title="Notifications">
            <i data-lucide="bell" style="width:17px;height:17px;"></i>
            <?php if ($navUnreadCount > 0): ?>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle bg-danger text-white shadow-xs" style="font-size: 10px; min-width: 17px; height: 17px; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; padding: 0 4px;"><?= $navUnreadCount > 9 ? '9+' : $navUnreadCount ?></span>
            <?php endif; ?>
          </button>
          <div class="dropdown-menu dropdown-menu-end shadow-lg border-0 py-0 cc-notification-dropdown-menu" aria-labelledby="notificationToggleBtn" style="width: 320px; border-radius: 12px; overflow: hidden;">
            <div class="d-flex align-items-center justify-content-between px-3 py-2 border-bottom bg-light">
              <span class="fw-bold text-dark small">Notifications</span>
              <?php if ($navUnreadCount > 0): ?>
                <span class="badge bg-primary rounded-pill px-2 py-0 text-xs"><?= $navUnreadCount ?> new</span>
              <?php endif; ?>
            </div>
            <div class="cc-notif-body p-0" style="max-height: 280px; overflow-y: auto;">
              <?php if (empty($navRecentNotifs)): ?>
                <div class="text-center py-4 text-muted small">
                  <i data-lucide="bell-off" class="d-block mx-auto mb-1 opacity-50" style="width:20px;height:20px;"></i>
                  No new notifications.
                </div>
              <?php else: ?>
                <div class="list-group list-group-flush">
                  <?php foreach ($navRecentNotifs as $nn): ?>
                    <a href="<?= !empty($nn['link']) ? e(url($nn['link'])) : e(url('notifications')) ?>" class="list-group-item list-group-item-action px-3 py-2 border-bottom <?= $nn['is_read'] ? 'opacity-75' : 'bg-light bg-opacity-25' ?>">
                      <div class="d-flex align-items-start gap-2">
                        <div class="flex-grow-1 min-w-0">
                          <div class="d-flex justify-content-between align-items-baseline">
                            <span class="fw-bold text-dark text-truncate small d-block"><?= e($nn['title']) ?></span>
                            <span class="text-muted text-xs ms-1"><?= date('M j', strtotime($nn['created_at'])) ?></span>
                          </div>
                          <p class="text-secondary small mb-0 text-truncate" style="font-size: 11px;"><?= e($nn['message']) ?></p>
                        </div>
                      </div>
                    </a>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
            <div class="p-2 border-top bg-light text-center">
              <a href="<?= e(url('notifications')) ?>" class="text-decoration-none fw-semibold small text-primary d-inline-flex align-items-center gap-1">
                <span>View all notifications</span>
                <i data-lucide="arrow-right" style="width: 12px; height: 12px;"></i>
              </a>
            </div>
          </div>
        </div>

        <?php if ($role === 'student' || $role === 'parent'): ?>
        <!-- Fullscreen / Expand button for student & parent portal -->
        <button type="button" class="cc-icon-btn d-none d-sm-inline-flex" onclick="if(!document.fullscreenElement){document.documentElement.requestFullscreen();}else{document.exitFullscreen();}" title="Toggle Fullscreen">
          <i data-lucide="maximize" style="width:16px;height:16px;"></i>
        </button>
        <?php endif; ?>

        <!-- Theme Mode Dropdown (Light / Dark / System) -->
        <div class="dropdown" id="themeDropdownWrap">
          <button class="cc-icon-btn" type="button" id="themeToggleBtn" data-bs-toggle="dropdown" aria-expanded="false" title="Theme Mode (Light / Dark / System)">
            <i data-lucide="sun" id="themeToggleIcon" style="width:17px;height:17px;"></i>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow-sm border py-1 cc-theme-dropdown-menu" style="min-width: 140px; border-radius: 8px;">
            <li>
              <button class="dropdown-item cc-theme-item active" type="button" data-theme-mode="light" onclick="setAppThemeMode('light')">
                <i data-lucide="sun" style="width:16px;height:16px;"></i>
                <span>Light</span>
              </button>
            </li>
            <li>
              <button class="dropdown-item cc-theme-item" type="button" data-theme-mode="dark" onclick="setAppThemeMode('dark')">
                <i data-lucide="moon" style="width:16px;height:16px;"></i>
                <span>Dark</span>
              </button>
            </li>
            <li>
              <button class="dropdown-item cc-theme-item" type="button" data-theme-mode="system" onclick="setAppThemeMode('system')">
                <i data-lucide="monitor" style="width:16px;height:16px;"></i>
                <span>System</span>
              </button>
            </li>
          </ul>
        </div>

        <!-- Vertical Divider -->
        <div class="vr my-2 text-muted opacity-25 d-none d-sm-block" style="height: 22px;"></div>

        <!-- User Profile Dropdown -->
        <div class="dropdown" id="profileDropdownWrap">
          <button class="cc-user-btn no-caret" type="button" id="userProfileToggleBtn" data-bs-toggle="dropdown" aria-expanded="false" title="Account Menu">
            <div class="cc-user-avatar" style="<?= in_array($role, ['student', 'parent'], true) ? 'background: #eef2ff !important; border: 1px solid #e0e7ff;' : '' ?>">
              <?php if ($role === 'student'): ?>
                <span class="fw-bold" style="color: #4f46e5; font-size: 13px;">S</span>
              <?php elseif ($role === 'parent'): ?>
                <span class="fw-bold" style="color: #4f46e5; font-size: 13px;">P</span>
              <?php else: ?>
                <i data-lucide="user" class="cc-avatar-silhouette"></i>
              <?php endif; ?>
            </div>
            <div class="cc-user-meta d-none d-lg-block text-start">
              <div class="cc-user-name text-truncate"><?= e($role === 'student' ? 'Student' : ($role === 'parent' ? 'Parent / Guardian' : ($user['name'] ?? 'School Administrator'))) ?></div>
              <?php if (!in_array($role, ['student', 'parent'], true)): ?>
                <div class="cc-user-role"><?= e(ucwords(str_replace('_', ' ', $role ?: 'Administrator'))) ?></div>
              <?php endif; ?>
            </div>
            <i data-lucide="chevron-down" style="width: 13px; height: 13px; color: #94a3b8; margin-left: 2px;"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-end cc-profile-dropdown-menu" aria-labelledby="userProfileToggleBtn">
            <div class="cc-profile-header">
              <div class="cc-profile-name"><?= e($role === 'parent' ? 'Parent / Guardian' : ($user['name'] ?? 'School Administrator')) ?></div>
              <div class="cc-profile-email"><?= e($user['email'] ?? 'parent@gmail.com') ?></div>
            </div>
            <div class="cc-profile-body">
              <a class="cc-profile-item" href="<?= e(url(in_array($role, ['student', 'parent'], true) ? 'portal/profile' : 'profile')) ?>">
                <i data-lucide="user"></i>
                <span>My Profile</span>
              </a>
              <?php if (!in_array($role, ['student', 'parent'], true)): ?>
              <a class="cc-profile-item" href="<?= e(url('settings')) ?>">
                <i data-lucide="settings"></i>
                <span>Settings</span>
              </a>
              <?php endif; ?>
            </div>
            <div class="cc-profile-footer">
              <form method="post" action="<?= e(url('logout')) ?>" class="m-0 p-0">
                <?= csrf_field() ?>
                <button class="cc-profile-item cc-profile-logout-btn" type="submit">
                  <i data-lucide="log-out"></i>
                  <span>Sign Out</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Page Header (Only for subpages, Dashboard and Portal pages have their own dedicated header) -->
    <?php if (!empty($title) && $title !== 'Dashboard' && $title !== 'School Dashboard' && !in_array($role, ['student', 'parent'], true)): ?>
    <div class="cc-subpage-header mb-4">
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
        <div>
          <h1 class="cc-subpage-title mb-1"><?= e($title) ?></h1>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0" style="font-size:.78rem;">
              <li class="breadcrumb-item"><a href="<?= e(url('dashboard')) ?>" class="text-decoration-none">Dashboard</a></li>
              <?php foreach ($breadcrumbs ?? [] as $bc): ?>
                <?php if (!empty($bc['url'])): ?>
                  <li class="breadcrumb-item"><a href="<?= e($bc['url']) ?>" class="text-decoration-none"><?= e($bc['label']) ?></a></li>
                <?php else: ?>
                  <li class="breadcrumb-item active text-muted"><?= e($bc['label']) ?></li>
                <?php endif; ?>
              <?php endforeach; ?>
              <?php if (empty($breadcrumbs)): ?>
                <li class="breadcrumb-item active text-muted"><?= e($title) ?></li>
              <?php endif; ?>
            </ol>
          </nav>
        </div>
        <?php if (!empty($pageActions)): ?>
        <div class="d-flex gap-2 align-items-center"><?= $pageActions ?></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Main Content Area -->
    <main class="cc-content-body">
      <?php require base_path('app/Views/partials/flash.php'); ?>
      <?php require base_path('app/Views/partials/trial_banner.php'); ?>
      <?= $content ?>
    </main>

  </div>
</div>

<!-- Global Quick Search Command Palette Modal -->
<div class="modal fade" id="commandPaletteModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 620px;">
    <div class="modal-content shadow-lg border-0 cc-cmd-modal" style="border-radius:12px;overflow:hidden;">
      
      <!-- Top Search Input Bar -->
      <div class="p-3 border-bottom d-flex align-items-center gap-3 bg-white">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <input type="text" class="form-control border-0 p-0 shadow-none cc-cmd-input" id="commandPaletteInput" placeholder="Search pages, actions, settings..." autocomplete="off">
        <kbd class="cc-cmd-esc-badge" data-bs-dismiss="modal" style="cursor: pointer;">ESC</kbd>
      </div>

      <!-- Scrollable List of Navigation, Settings, Quick Actions -->
      <div class="modal-body p-2 cc-cmd-body" id="commandPaletteList" style="max-height: 480px; overflow-y: auto;">
        
        <!-- DYNAMIC DATABASE SEARCH RESULTS -->
        <div class="cc-cmd-section d-none" id="liveSearchSection" data-section="live-records">
          <div class="cc-cmd-section-header d-flex align-items-center justify-content-between">
            <span>DATABASE SEARCH RESULTS</span>
            <span class="badge bg-primary rounded-pill px-2 py-0 text-xs" id="liveSearchCountBadge">0 found</span>
          </div>
          <div id="liveSearchResultsList"></div>
        </div>

        <!-- QUICK SAVED FILTERS CHIPS -->
        <div class="px-2 pt-2 pb-2 mb-1 d-flex flex-wrap gap-1 border-bottom" id="cmdSavedFiltersBar">
          <span class="text-muted small align-self-center me-1" style="font-size: 11px; font-weight: 600;">QUICK FILTERS:</span>
          <a href="<?= e(url('students?status=active')) ?>" class="badge rounded-pill bg-light text-dark border text-decoration-none py-1 px-2 cc-cmd-filter-chip">Active Students</a>
          <a href="<?= e(url('finance/invoices?status=unpaid')) ?>" class="badge rounded-pill bg-light text-dark border text-decoration-none py-1 px-2 cc-cmd-filter-chip">Unpaid Invoices</a>
          <a href="<?= e(url('attendance/students?date=' . date('Y-m-d'))) ?>" class="badge rounded-pill bg-light text-dark border text-decoration-none py-1 px-2 cc-cmd-filter-chip">Today's Attendance</a>
          <a href="<?= e(url('admissions?status=submitted')) ?>" class="badge rounded-pill bg-light text-dark border text-decoration-none py-1 px-2 cc-cmd-filter-chip">Open Admissions</a>
        </div>

        <!-- RECENT RECORDS & PAGES SECTION -->
        <div class="cc-cmd-section" id="recentRecordsSection" data-section="recent-records">
          <div class="cc-cmd-section-header d-flex align-items-center justify-content-between">
            <span>RECENT RECORDS &amp; FREQUENT ACTIONS</span>
            <span class="badge bg-secondary-subtle text-secondary rounded-pill px-2 py-0 text-xs" id="recentRecordsCountBadge">Recent</span>
          </div>
          <div id="recentRecordsList">
            <!-- Dynamically populated via UserProductivityService / JavaScript -->
          </div>
        </div>

        <!-- SECTION 1: NAVIGATION -->
        <div class="cc-cmd-section" data-section="navigation">
          <div class="cc-cmd-section-header">NAVIGATION</div>
          
          <a href="<?= e(url('dashboard')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="layout-grid" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Dashboard</div>
                <div class="cc-cmd-desc">Overview of school metrics, statistics, and shortcuts</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('academic-sessions')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="calendar" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Academic Sessions</div>
                <div class="cc-cmd-desc">Configure academic years, terms, and active session status</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('classes')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="graduation-cap" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Classes</div>
                <div class="cc-cmd-desc">Manage grades, classrooms, and classes</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('sections')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="layers" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Sections</div>
                <div class="cc-cmd-desc">Configure student batches, sections, and divisions</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('subjects')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="book-open" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Subjects</div>
                <div class="cc-cmd-desc">Manage course curriculum, syllabi, and subjects</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('timetable')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="clock" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Timetable</div>
                <div class="cc-cmd-desc">Schedule classes, periods, and weekly timetables</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('timetable?tab=substitutes')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="shuffle" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Daily Substitutes</div>
                <div class="cc-cmd-desc">Manage teacher coverage schedules and daily replacements</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('students')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="users" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Student Directory</div>
                <div class="cc-cmd-desc">Search and manage student profiles, details, and directory</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('admissions')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="clipboard-list" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Admission Applications</div>
                <div class="cc-cmd-desc">Review student admission applications and admission applications</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('attendance/students')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="calendar-check" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Attendance Records</div>
                <div class="cc-cmd-desc">Record and track student daily attendance reports</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('hr/employees')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="user-check" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Staff Directory</div>
                <div class="cc-cmd-desc">Manage staff, administrators, and employees</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('roles')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="shield-check" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Roles &amp; Permissions</div>
                <div class="cc-cmd-desc">Configure school user roles and granular capability levels</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('finance/overview')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="credit-card" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Finance Overview</div>
                <div class="cc-cmd-desc">View school fee collections, revenue status, and dashboard charts</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('finance/fee-types')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="tag" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Fee Types</div>
                <div class="cc-cmd-desc">Set up fee categories, structure, and fee types</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('finance/invoices')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="receipt" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Invoices</div>
                <div class="cc-cmd-desc">Generate, issue, and manage student invoices</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('finance/payments')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="wallet" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Payments</div>
                <div class="cc-cmd-desc">Record and search cash, card, and online payments</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('dashboard')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="external-link" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">WordPress Dashboard</div>
                <div class="cc-cmd-desc">Exit to the base WordPress administration backoffice</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('announcements')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="megaphone" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Noticeboard &amp; Announcements</div>
                <div class="cc-cmd-desc">Publish and manage school-wide announcements and notices</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>
        </div>

        <!-- SECTION 2: SETTINGS -->
        <div class="cc-cmd-section" data-section="settings">
          <div class="cc-cmd-section-header">SETTINGS</div>

          <a href="<?= e(url('settings?tab=school-profile')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: General</div>
                <div class="cc-cmd-desc">Configure school metadata, contact details, and basic settings</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=academic-setup')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Education System</div>
                <div class="cc-cmd-desc">Select education-based presets, grading systems, and school model settings</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=admissions')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Admissions</div>
                <div class="cc-cmd-desc">Set up application codes, auto-conversion rules, and fees settings</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=staff-onboarding')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Staff Onboarding</div>
                <div class="cc-cmd-desc">Set up staff onboarding requirements and ID format generation structures</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=id-formats')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Identifiers</div>
                <div class="cc-cmd-desc">Set student ID prefix codes, formats, and auto-generation bounds</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=region-language')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Localization</div>
                <div class="cc-cmd-desc">Set national currency symbols, timezone preferences, and date formats</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=appearance')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Appearance</div>
                <div class="cc-cmd-desc">Toggle light / dark mode, sidebar density, and table row heights</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=shortcodes')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: Shortcodes</div>
                <div class="cc-cmd-desc">Review public WordPress shortcodes for online forms and embeddable pages</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=system')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: System Tools</div>
                <div class="cc-cmd-desc">Run database resets, flush system cache, and verify status logs</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=in-app-alerts')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: In-App Notifications</div>
                <div class="cc-cmd-desc">Configure student and parent portal notification channels</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('settings?tab=sms-alerts')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="settings" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Settings: SMS Notifications</div>
                <div class="cc-cmd-desc">Configure Twilio, Vonage, MSG91, and Fast2SMS credentials</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>
        </div>

        <!-- SECTION 3: QUICK ACTIONS -->
        <div class="cc-cmd-section" data-section="actions">
          <div class="cc-cmd-section-header">QUICK ACTIONS</div>

          <a href="<?= e(url('admissions/create')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="user-plus" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Quick Action: Admit Student</div>
                <div class="cc-cmd-desc">Directly open the student admission application form</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="<?= e(url('hr/employees')) ?>" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="user-check" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Quick Action: Onboard Staff</div>
                <div class="cc-cmd-desc">Directly open the staff onboarding form</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>

          <a href="javascript:void(0)" onclick="toggleThemeFromPalette()" class="cc-cmd-item">
            <div class="d-flex align-items-center gap-3">
              <i data-lucide="moon" class="cc-cmd-icon"></i>
              <div>
                <div class="cc-cmd-title">Quick Action: Toggle Theme Mode</div>
                <div class="cc-cmd-desc">Switch current theme to Dark mode</div>
              </div>
            </div>
            <span class="cc-cmd-enter">↵</span>
          </a>
        </div>

        <!-- Zero Results Fallback -->
        <div id="commandPaletteEmpty" class="text-center py-4 text-muted d-none" style="font-size: 13px;">
          No matching pages, actions, or settings found.
        </div>

      </div>

      <!-- Modal Footer Keyboard Shortcuts -->
      <div class="p-2 px-3 border-top bg-light d-flex align-items-center justify-content-between text-muted cc-cmd-footer" style="font-size: 11.5px;">
        <div class="d-flex align-items-center gap-3">
          <span><kbd class="cc-cmd-kbd">↑↓</kbd> to navigate</span>
          <span><kbd class="cc-cmd-kbd">↵</kbd> to select</span>
        </div>
        <div>
          <span><kbd class="cc-cmd-kbd">ESC</kbd> to close</span>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1090;" id="globalToastContainer"></div>

<!-- Global Delete Confirmation Modal -->
<?php require base_path('app/Views/partials/delete_confirm_modal.php'); ?>

<!-- Contextual Multi-Tenant AI Chatbot Widget -->
<?php require base_path('app/Views/partials/ai_chat_widget.php'); ?>

<script>
  window.APP_BASE_URL = '<?= e(rtrim(url(''), '/')) ?>';
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>