<?php
$layout = 'layouts/app';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Academic Calendar & Events') ?>
        </h1>
        <p class="text-muted small mb-0">
            Schedule institution events, examination periods, sports days, holidays, and academic milestones
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                data-bs-toggle="modal" data-bs-target="#newEventModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
            <span>Schedule Event / Holiday</span>
        </button>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="calendar" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Total Events</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Scheduled Milestone Days</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="sun" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <span class="badge rounded-pill bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">Holidays</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['holidays'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Gazetted / School Holidays</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 34px; height: 34px;">
                        <i data-lucide="file-text" style="width: 16px; height: 16px; stroke: #dc2626;"></i>
                    </div>
                    <span class="badge rounded-pill bg-danger-subtle text-danger px-2 py-1" style="font-size: 10px;">Assessments</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['exams'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Examination Schedules</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="trophy" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 10px;">Athletics</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['sports'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Sports &amp; Tournaments</div>
            </div>
        </div>
    </div>
</div>

<!-- Calendar Filters & Event Grid -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <!-- Filter bar -->
        <form method="GET" action="<?= e(url('calendar')) ?>" class="row g-2 align-items-center mb-4">
            <div class="col-md-4">
                <label class="small text-muted mb-1">Target Month</label>
                <input type="month" name="month" class="form-control form-control-sm" value="<?= e($currentMonth) ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-4">
                <label class="small text-muted mb-1">Event Category</label>
                <select name="category" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <option value="academic" <?= $selectedCategory === 'academic' ? 'selected' : '' ?>>Academic Milestone</option>
                    <option value="holiday" <?= $selectedCategory === 'holiday' ? 'selected' : '' ?>>Official Holiday</option>
                    <option value="exam" <?= $selectedCategory === 'exam' ? 'selected' : '' ?>>Examination</option>
                    <option value="sports" <?= $selectedCategory === 'sports' ? 'selected' : '' ?>>Sports &amp; Athletics</option>
                    <option value="cultural" <?= $selectedCategory === 'cultural' ? 'selected' : '' ?>>Cultural &amp; Science</option>
                    <option value="meeting" <?= $selectedCategory === 'meeting' ? 'selected' : '' ?>>PTM &amp; Meetings</option>
                </select>
            </div>
            <div class="col-md-4 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-sm btn-primary w-100">Apply Filter</button>
                <?php if (!empty($selectedCategory) || $currentMonth !== date('Y-m')): ?>
                    <a href="<?= e(url('calendar')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <!-- Events List Timeline -->
        <div class="row g-3">
            <?php if (empty($events)): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i data-lucide="calendar-x" style="width: 32px; height: 32px; opacity: 0.4;"></i>
                    <div class="mt-2">No events scheduled for the selected month or filter.</div>
                </div>
            <?php else: ?>
                <?php foreach ($events as $ev): 
                    $isMultiDay = ($ev['start_date'] !== $ev['end_date']);
                ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 border rounded-3 p-3 shadow-sm bg-white" style="border-left: 5px solid <?= e($ev['color'] ?: '#4f46e5') ?> !important;">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge rounded-pill text-uppercase px-2 py-1" style="font-size: 10px; background-color: <?= e($ev['color'] ?: '#4f46e5') ?>15; color: <?= e($ev['color'] ?: '#4f46e5') ?>;">
                                    <?= e($ev['category']) ?>
                                </span>
                                <form method="POST" action="<?= e(url('calendar/events/' . $ev['id'] . '/delete')) ?>" onsubmit="return confirm('Remove this event?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="btn btn-link text-muted p-0" title="Delete">
                                        <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                                    </button>
                                </form>
                            </div>

                            <h5 class="fw-bold text-dark mb-1"><?= e($ev['title']) ?></h5>

                            <div class="small text-muted mb-1">
                                <i data-lucide="clock" style="width: 13px; height: 13px; margin-right: 4px;"></i>
                                <?php if ($isMultiDay): ?>
                                    <?= date('M d, Y', strtotime($ev['start_date'])) ?> &rarr; <?= date('M d, Y', strtotime($ev['end_date'])) ?>
                                <?php else: ?>
                                    <?= date('l, M d, Y', strtotime($ev['start_date'])) ?>
                                <?php endif; ?>
                                <?php if (!empty($ev['start_time'])): ?>
                                    <span class="ms-1 fw-medium">(<?= date('h:i A', strtotime($ev['start_time'])) ?>)</span>
                                <?php endif; ?>
                            </div>

                            <?php if (!empty($ev['venue'])): ?>
                                <div class="small text-muted mb-2">
                                    <i data-lucide="map-pin" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($ev['venue']) ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($ev['description'])): ?>
                                <p class="small text-muted mb-3"><?= nl2br(e($ev['description'])) ?></p>
                            <?php endif; ?>

                            <div class="border-top pt-2 mt-auto d-flex justify-content-between align-items-center small text-muted">
                                <span>Audience: <strong class="text-dark text-capitalize"><?= e($ev['audience']) ?></strong></span>
                                <span><?= e($ev['creator_name'] ?? 'Admin') ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal: New Event -->
<div class="modal fade" id="newEventModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('calendar/events')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Schedule Calendar Event / Holiday</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Event Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Annual Athletic Sports Gala 2026" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Category *</label>
                            <select name="category" class="form-select" required>
                                <option value="academic">Academic Milestone</option>
                                <option value="holiday">Official Holiday</option>
                                <option value="exam">Examination Assessment</option>
                                <option value="sports">Sports &amp; Athletics</option>
                                <option value="cultural">Cultural &amp; Science Fair</option>
                                <option value="meeting">PTM &amp; Conference</option>
                                <option value="general">General Institution Event</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Target Audience</label>
                            <select name="audience" class="form-select">
                                <option value="all">Everyone (All Stakeholders)</option>
                                <option value="students">Students Only</option>
                                <option value="parents">Parents Only</option>
                                <option value="teachers">Teaching Staff</option>
                                <option value="staff">All Staff Members</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Start Date *</label>
                            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">End Date (Leave same if single day)</label>
                            <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-bold">Start Time</label>
                            <input type="time" name="start_time" class="form-control">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">End Time</label>
                            <input type="time" name="end_time" class="form-control">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Tag Color</label>
                            <input type="color" name="color" class="form-control form-control-color w-100" value="#4f46e5">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Venue / Location</label>
                        <input type="text" name="venue" class="form-control" placeholder="e.g. Main Auditorium / Ground">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Description / Agenda</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Outline activities, dress code, instructions..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Publish Event</button>
                </div>
            </form>
        </div>
    </div>
</div>
