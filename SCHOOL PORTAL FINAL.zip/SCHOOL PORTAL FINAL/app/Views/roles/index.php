<?php
$isOwnerRole = ($activeRole['slug'] ?? '') === 'owner';
$activeRoleId = (int)($activeRole['id'] ?? 0);
?>

<div class="cc-roles-wrapper">
    <!-- Breadcrumb & Page Header -->
    <div class="mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                <li class="breadcrumb-item"><a href="<?= e(url('hr/employees')) ?>" class="text-decoration-none text-muted">Staff & HR</a></li>
                <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Roles & Permissions</li>
            </ol>
        </nav>
        <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Roles & Permissions</h2>
        <p class="text-muted small mb-0">Configure feature capability grids, manage dynamic system roles, and assign school dashboard access privileges.</p>
    </div>

    <!-- Main Two-Column Layout -->
    <div class="row g-4">
        <!-- Left Column: SYSTEM ROLES List -->
        <div class="col-12 col-lg-4 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="border: 1px solid #eef2f6 !important;">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                        <span class="text-secondary small fw-bold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.78rem;">
                            System Roles
                        </span>
                        <button type="button" class="btn btn-sm rounded-pill text-white px-3 py-1 fw-semibold shadow-none" 
                                style="background: #4f46e5; font-size: 0.78rem;" data-bs-toggle="modal" data-bs-target="#addRoleModal">
                            + Add Role
                        </button>
                    </div>

                    <!-- Roles List -->
                    <div class="d-flex flex-column gap-2" id="rolesListContainer">
                        <?php foreach ($roles as $r): 
                            $rId = (int)$r['id'];
                            $isActive = ($rId === $activeRoleId);
                            $isOwner = ($r['slug'] === 'owner');
                            $capabilityCount = (int)($r['capability_count'] ?? 0);
                            $roleDesc = $r['description'] ?: 'Configure permission scopes.';
                        ?>
                            <a href="<?= e(url('staff/roles?role_id=' . $rId)) ?>" 
                               class="role-card-item text-decoration-none p-3 rounded-3 d-flex justify-content-between align-items-center transition-all <?= $isActive ? 'active-role' : 'inactive-role' ?>">
                                <div class="pe-2 text-truncate">
                                    <div class="fw-bold text-truncate role-title" style="font-size: 0.92rem;">
                                        <?= e($r['name']) ?>
                                    </div>
                                    <div class="small text-truncate role-subtitle" style="font-size: 0.78rem; opacity: <?= $isActive ? '0.85' : '0.6' ?>;">
                                        <?= e($roleDesc) ?>
                                    </div>
                                </div>
                                <div class="flex-shrink-0">
                                    <?php if ($isOwner): ?>
                                        <div class="d-flex align-items-center gap-1 <?= $isActive ? 'text-white' : 'text-secondary' ?>" style="font-size: 0.85rem;">
                                            <i data-lucide="lock" style="width: 14px; height: 14px;"></i>
                                            <i data-lucide="star" style="width: 14px; height: 14px; fill: currentColor;"></i>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge rounded-pill fw-bold <?= $isActive ? 'badge-active-count' : 'bg-light text-secondary border' ?>" 
                                              style="font-size: 0.78rem; padding: 4px 9px;">
                                            <?= $capabilityCount ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Capability Map for Selected Role -->
        <div class="col-12 col-lg-8 col-xl-9">
            <?php if ($activeRole): ?>
                <form method="post" action="<?= e(url('roles/' . $activeRoleId)) ?>" id="rolePermissionsForm">
                    <?= csrf_field() ?>

                    <!-- Role Details Header Card -->
                    <div class="card border-0 shadow-sm rounded-4 mb-3" style="border: 1px solid #eef2f6 !important;">
                        <div class="card-body p-4">
                            <div class="row g-3 align-items-center">
                                <div class="col-12 col-xl-5">
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="rounded-circle" style="width: 10px; height: 10px; background: #4f46e5;"></span>
                                        <h5 class="fw-bold text-dark mb-0" style="letter-spacing: -0.01em;">
                                            <?= e($activeRole['name']) ?> Capabilities
                                        </h5>
                                    </div>
                                    <p class="text-muted small mb-0">Configure administrative permission scopes.</p>
                                </div>

                                <div class="col-12 col-xl-7">
                                    <div class="d-flex flex-wrap flex-sm-nowrap align-items-center gap-2 justify-content-xl-end">
                                        <div class="d-flex align-items-center gap-1 w-100" style="max-width: 200px;">
                                            <label class="text-secondary small fw-bold text-uppercase mb-0" style="font-size: 0.72rem;">ROLE:</label>
                                            <input type="text" name="name" value="<?= e($activeRole['name']) ?>" 
                                                   class="form-control form-control-sm rounded-3 shadow-none border-light-subtle fw-medium" 
                                                   style="font-size: 0.85rem;" <?= $isOwnerRole ? 'readonly' : '' ?> required>
                                        </div>

                                        <div class="d-flex align-items-center gap-1 w-100" style="max-width: 290px;">
                                            <label class="text-secondary small fw-bold text-uppercase mb-0" style="font-size: 0.72rem;">DESC:</label>
                                            <input type="text" name="description" value="<?= e($activeRole['description'] ?? '') ?>" 
                                                   class="form-control form-control-sm rounded-3 shadow-none border-light-subtle" 
                                                   style="font-size: 0.85rem;" placeholder="Role description..." <?= $isOwnerRole ? 'readonly' : '' ?>>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Capability Map Panel -->
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-3" style="border: 1px solid #eef2f6 !important;">
                        <!-- Capability Map Header -->
                        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <span class="fw-bold text-uppercase text-secondary" style="letter-spacing: 0.05em; font-size: 0.82rem;">
                                Capability Map
                            </span>
                            <?php if (!$isOwnerRole): ?>
                                <div class="d-flex align-items-center gap-2">
                                    <button type="button" class="btn btn-sm btn-link text-decoration-none text-primary fw-semibold p-0 shadow-none" 
                                            onclick="selectAllCapabilities(true);" style="font-size: 0.82rem;">
                                        Select All
                                    </button>
                                    <span class="text-muted" style="opacity: 0.5;">•</span>
                                    <button type="button" class="btn btn-sm btn-link text-decoration-none text-muted fw-semibold p-0 shadow-none" 
                                            onclick="selectAllCapabilities(false);" style="font-size: 0.82rem;">
                                        Deselect All
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Accordion Category Groups -->
                        <div class="accordion accordion-flush" id="capabilitiesAccordion">
                            <?php 
                            $catIcons = [
                                'Academics' => 'graduation-cap',
                                'Students & Admissions' => 'users',
                                'Settings & System' => 'settings',
                                'Staff & HR' => 'briefcase',
                                'Finance' => 'receipt',
                                'Attendance' => 'clock',
                            ];

                            $idx = 0;
                            foreach ($groupedPerms as $category => $permList): 
                                $idx++;
                                $collapseId = 'collapseCat_' . $idx;
                                $icon = $catIcons[$category] ?? 'layers';
                                $stats = $categoryStats[$category] ?? ['granted' => 0, 'total' => count($permList)];
                                $isExpanded = ($idx === 1); // Expand first category by default
                            ?>
                                <div class="accordion-item border-bottom">
                                    <h2 class="accordion-header" id="heading_<?= $collapseId ?>">
                                        <button class="accordion-button <?= $isExpanded ? '' : 'collapsed' ?> py-3 px-4 shadow-none bg-white" type="button" 
                                                data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" 
                                                aria-expanded="<?= $isExpanded ? 'true' : 'false' ?>" aria-controls="<?= $collapseId ?>">
                                            <div class="d-flex align-items-center gap-2 me-auto">
                                                <i data-lucide="<?= $icon ?>" class="text-secondary" style="width: 17px; height: 17px;"></i>
                                                <span class="fw-semibold text-dark" style="font-size: 0.92rem;">
                                                    <?= e($category) ?>
                                                </span>
                                                <span class="badge rounded-pill fw-medium ms-1 category-stat-pill" id="catStat_<?= $idx ?>"
                                                      style="background: #eff6ff; color: #3b82f6; font-size: 0.75rem; padding: 3px 8px;">
                                                    <span class="cat-granted-count"><?= $stats['granted'] ?></span>/<span class="cat-total-count"><?= $stats['total'] ?></span>
                                                </span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="<?= $collapseId ?>" class="accordion-collapse collapse <?= $isExpanded ? 'show' : '' ?>" 
                                         aria-labelledby="heading_<?= $collapseId ?>" data-bs-parent="#capabilitiesAccordion">
                                        <div class="accordion-body p-4 bg-light bg-opacity-25">
                                            <div class="row g-3">
                                                <?php foreach ($permList as $p): 
                                                    $pId = (int)$p['id'];
                                                    $isGranted = in_array($pId, $activePermIds, true) || $isOwnerRole;
                                                    $checkboxId = 'perm_' . $pId;
                                                ?>
                                                    <div class="col-12 col-md-6">
                                                        <div class="p-3 bg-white rounded-3 border h-100 d-flex align-items-start gap-3 capability-card transition-all" 
                                                             style="border-color: #f1f5f9 !important;">
                                                            <div class="form-check form-switch pt-1 mb-0 flex-shrink-0">
                                                                <input class="form-check-input capability-checkbox cat-checkbox-<?= $idx ?>" 
                                                                       type="checkbox" name="permissions[]" value="<?= $pId ?>" 
                                                                       id="<?= $checkboxId ?>" 
                                                                       data-cat="<?= $idx ?>"
                                                                       <?= $isGranted ? 'checked' : '' ?> 
                                                                       <?= $isOwnerRole ? 'disabled' : '' ?>
                                                                       onchange="onCapabilityChange(this, <?= $idx ?>)"
                                                                       style="cursor: pointer; width: 36px; height: 20px;">
                                                            </div>
                                                            <label class="form-check-label mb-0" for="<?= $checkboxId ?>" style="cursor: pointer;">
                                                                <div class="fw-semibold text-dark mb-1" style="font-size: 0.86rem;">
                                                                    <?= e($p['name']) ?>
                                                                </div>
                                                                <div class="text-muted small" style="font-size: 0.76rem; line-height: 1.4;">
                                                                    <?= e($p['slug']) ?>
                                                                </div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Card Footer with Save Changes Button -->
                        <div class="card-footer bg-white border-top py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div class="text-muted small d-flex align-items-center gap-2">
                                <?php if ($isOwnerRole): ?>
                                    <i data-lucide="shield" class="text-warning" style="width: 15px; height: 15px;"></i>
                                    <span>The <strong>Owner</strong> role possesses immutable absolute sovereignty across all modules.</span>
                                <?php else: ?>
                                    <i data-lucide="info" class="text-primary" style="width: 15px; height: 15px;"></i>
                                    <span>Changes apply immediately to all users assigned to this role.</span>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-sm text-white rounded-3 px-4 py-2 fw-semibold d-inline-flex align-items-center gap-2 shadow-none" 
                                    style="background: #4f46e5; font-size: 0.86rem;" <?= $isOwnerRole ? 'disabled' : '' ?>>
                                <i data-lucide="save" style="width: 15px; height: 15px;"></i> Save Changes
                            </button>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <div class="card border-0 shadow-sm rounded-4 p-5 text-center text-muted">
                    <i data-lucide="shield-alert" class="mx-auto mb-3" style="width: 48px; height: 48px; opacity: 0.4;"></i>
                    <h5 class="fw-bold">No Role Selected</h5>
                    <p class="mb-0">Please select a system role from the left panel to configure its capability map.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal: Add New Role -->
<div class="modal fade" id="addRoleModal" tabindex="-1" aria-labelledby="addRoleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header py-3 px-4 border-bottom">
                <h5 class="modal-title fw-bold text-dark" id="addRoleModalLabel">Create New System Role</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('staff/roles')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label text-secondary small fw-bold text-uppercase mb-1" style="font-size: 0.75rem;">Role Name</label>
                        <input type="text" name="name" class="form-control rounded-3 shadow-none border-light-subtle" 
                               placeholder="e.g. Lab Coordinator, Deputy Head" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label text-secondary small fw-bold text-uppercase mb-1" style="font-size: 0.75rem;">Description</label>
                        <textarea name="description" rows="3" class="form-control rounded-3 shadow-none border-light-subtle" 
                                  placeholder="Describe the duties and operational scope of this role..."></textarea>
                    </div>
                </div>
                <div class="modal-footer py-2 px-4 border-top">
                    <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm text-white px-4 fw-medium" style="background: #4f46e5;">Create Role</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Left Column Role Item Styling */
.role-card-item {
    cursor: pointer;
    border: 1px solid transparent;
}
.inactive-role {
    background: #ffffff;
    border-color: #f1f5f9;
}
.inactive-role:hover {
    background: #f8fafc;
    border-color: #e2e8f0;
}
.inactive-role .role-title {
    color: #1e293b;
}
.inactive-role .role-subtitle {
    color: #64748b;
}

/* Active Selected Role (Solid Purple #4f46e5 matching CodeClove) */
.active-role {
    background: #4f46e5 !important;
    color: #ffffff !important;
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25);
}
.active-role .role-title {
    color: #ffffff !important;
}
.active-role .role-subtitle {
    color: rgba(255, 255, 255, 0.8) !important;
}
.badge-active-count {
    background: rgba(255, 255, 255, 0.2) !important;
    color: #ffffff !important;
    border: 1px solid rgba(255, 255, 255, 0.3) !important;
}

/* Capability Card Hover */
.capability-card:hover {
    border-color: #cbd5e1 !important;
    background-color: #ffffff !important;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

/* Form switch checked color */
.form-check-input:checked {
    background-color: #4f46e5 !important;
    border-color: #4f46e5 !important;
}

.accordion-button:not(.collapsed) {
    color: #4f46e5;
    background-color: #ffffff;
    box-shadow: none;
}
.accordion-button::after {
    background-size: 14px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }
});

// Select All / Deselect All
function selectAllCapabilities(checked) {
    const checkboxes = document.querySelectorAll('.capability-checkbox');
    checkboxes.forEach(cb => {
        if (!cb.disabled) {
            cb.checked = checked;
        }
    });

    // Update all category pills
    for (let i = 1; i <= 6; i++) {
        updateCategoryStatPill(i);
    }
}

// Capability change trigger
function onCapabilityChange(checkbox, catIndex) {
    updateCategoryStatPill(catIndex);
}

// Update Category badge (e.g. 26/27)
function updateCategoryStatPill(catIndex) {
    const checkboxes = document.querySelectorAll('.cat-checkbox-' + catIndex);
    let total = checkboxes.length;
    let granted = 0;
    checkboxes.forEach(cb => {
        if (cb.checked) granted++;
    });

    const statPill = document.getElementById('catStat_' + catIndex);
    if (statPill) {
        const grantedSpan = statPill.querySelector('.cat-granted-count');
        if (grantedSpan) grantedSpan.textContent = granted;
    }
}
</script>
