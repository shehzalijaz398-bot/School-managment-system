<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= $is_platform_view ? url('superadmin/schools') : url('settings') ?>" class="text-decoration-none text-muted small">
                    &larr; <?= $is_platform_view ? 'Platform Schools' : 'System Administration' ?>
                </a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Cross-Module Intelligence</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-heart-pulse-fill text-danger me-2"></i><?= e($title) ?>
            </h1>
            <p class="text-muted small mb-0">Evidence-based relational consistency scanner across attendance, finance, admissions, exams, timetables, and student records.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <?php if (!$is_platform_view): ?>
                <a href="<?= url('onboarding/wizard') ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                    <i class="bi bi-magic me-1"></i> Quick Setup Wizard
                </a>
                <a href="<?= url('admin/data') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                    <i class="bi bi-file-earmark-spreadsheet me-1"></i> Data Migration &amp; Import
                </a>
            <?php endif; ?>
            <button onclick="window.print()" class="btn btn-light border btn-sm shadow-sm fw-semibold">
                <i class="bi bi-printer me-1"></i> Print Audit
            </button>
        </div>
    </div>

    <!-- Health Scorecard Overview Card -->
    <div class="row g-4 mb-4">
        <!-- Main Score Gauge -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 bg-white h-100">
                <div class="card-body p-4 text-center d-flex flex-column justify-content-center">
                    <div class="text-muted small text-uppercase fw-bold mb-1">Overall Institutional Health</div>
                    
                    <?php 
                    $score = (int)$audit['health_score'];
                    $colorClass = match(true) {
                        $score >= 90 => 'text-success',
                        $score >= 75 => 'text-primary',
                        $score >= 50 => 'text-warning',
                        default => 'text-danger'
                    };
                    $badgeClass = match(true) {
                        $score >= 90 => 'bg-success-subtle text-success border border-success-subtle',
                        $score >= 75 => 'bg-primary-subtle text-primary border border-primary-subtle',
                        $score >= 50 => 'bg-warning-subtle text-warning border border-warning-subtle',
                        default => 'bg-danger-subtle text-danger border border-danger-subtle'
                    };
                    ?>
                    
                    <div class="display-3 fw-bold <?= $colorClass ?> my-2"><?= $score ?>%</div>
                    
                    <div>
                        <span class="badge <?= $badgeClass ?> px-3 py-2 text-uppercase fw-bold rounded-pill">
                            <?= str_replace('_', ' ', $audit['status_tier']) ?>
                        </span>
                    </div>

                    <div class="mt-4 pt-3 border-top small text-muted">
                        Audited on <?= date('d M Y, h:i A', strtotime($audit['summary']['audited_at'])) ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Issue Counter & Summary -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 bg-white h-100">
                <div class="card-header bg-white border-bottom p-3">
                    <h6 class="fw-bold text-dark mb-0">
                        <i class="bi bi-speedometer2 text-primary me-2"></i>Module Integrity Breakdown
                    </h6>
                </div>
                <div class="card-body p-4">
                    <!-- Issue Severity Counters -->
                    <div class="row g-3 mb-4">
                        <div class="col-4">
                            <div class="p-3 rounded-3 bg-danger-subtle text-danger border border-danger-subtle text-center">
                                <div class="h3 fw-bold mb-0"><?= (int)$audit['critical_count'] ?></div>
                                <div class="small fw-semibold">Critical Discrepancies</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-3 rounded-3 bg-warning-subtle text-warning border border-warning-subtle text-center">
                                <div class="h3 fw-bold mb-0"><?= (int)$audit['warning_count'] ?></div>
                                <div class="small fw-semibold">Operational Warnings</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-3 rounded-3 bg-info-subtle text-info border border-info-subtle text-center">
                                <div class="h3 fw-bold mb-0"><?= (int)$audit['info_count'] ?></div>
                                <div class="small fw-semibold">Data Advisory Alerts</div>
                            </div>
                        </div>
                    </div>

                    <!-- Progress bars by module -->
                    <div class="row g-3 small">
                        <?php 
                        $moduleLabels = [
                            'setup' => 'Setup Completeness',
                            'records' => 'Student & Staff Records',
                            'attendance' => 'Attendance Consistency',
                            'finance' => 'Fee & Ledger Balancing',
                            'exams' => 'Exams & Grading Rules',
                            'timetable' => 'Timetable Conflict Freedom',
                        ];
                        foreach ($audit['module_scores'] as $mKey => $mScore): 
                            $barColor = ($mScore >= 90) ? 'bg-success' : (($mScore >= 70) ? 'bg-primary' : (($mScore >= 50) ? 'bg-warning' : 'bg-danger'));
                        ?>
                            <div class="col-md-6">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted fw-semibold"><?= $moduleLabels[$mKey] ?? ucfirst($mKey) ?></span>
                                    <span class="fw-bold"><?= $mScore ?>%</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar <?= $barColor ?>" style="width: <?= $mScore ?>%;"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cross-Module Inconsistency Alerts & Actionable Remediation -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-header bg-white border-bottom p-3 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
            <div>
                <h6 class="fw-bold text-dark mb-0">
                    <i class="bi bi-shield-exclamation text-danger me-2"></i>Actionable Cross-Module Consistency Alerts
                </h6>
                <div class="text-muted small">Evidence-based alerts detected across operational relational tables. System never modifies records automatically.</div>
            </div>
            <div>
                <span class="badge bg-light text-dark border px-3 py-2">
                    Total Issues Detected: <strong><?= (int)$audit['total_alerts'] ?></strong>
                </span>
            </div>
        </div>

        <div class="card-body p-4">
            <?php if (empty($audit['alerts'])): ?>
                <div class="text-center py-5">
                    <div class="display-5 text-success mb-2">
                        <i class="bi bi-check-circle-fill"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Institutional Operations are in Optimal Health!</h5>
                    <p class="text-muted small">No relational inconsistencies, missing registers, or ledger discrepancies were found across your database.</p>
                </div>
            <?php else: ?>
                <div class="d-flex flex-column gap-3">
                    <?php foreach ($audit['alerts'] as $alert): 
                        $borderAlert = match($alert['severity']) {
                            'critical' => 'border-danger border-start border-4',
                            'warning' => 'border-warning border-start border-4',
                            default => 'border-info border-start border-4'
                        };
                        $badgeSeverity = match($alert['severity']) {
                            'critical' => 'bg-danger text-white',
                            'warning' => 'bg-warning text-dark',
                            default => 'bg-info text-white'
                        };
                    ?>
                        <div class="card border-0 shadow-sm rounded-3 <?= $borderAlert ?> p-3">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3">
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="badge <?= $badgeSeverity ?> text-uppercase px-2" style="font-size: 10px;">
                                            <?= htmlspecialchars($alert['severity']) ?>
                                        </span>
                                        <span class="badge bg-light text-muted border text-uppercase" style="font-size: 10px;">
                                            <?= htmlspecialchars($alert['module']) ?>
                                        </span>
                                        <span class="text-muted small">&bull;</span>
                                        <span class="text-muted small">Affected Count: <strong><?= (int)$alert['evidence_count'] ?></strong></span>
                                    </div>
                                    <h6 class="fw-bold text-dark mb-1"><?= htmlspecialchars($alert['title']) ?></h6>
                                    <p class="text-muted small mb-2"><?= htmlspecialchars($alert['description']) ?></p>

                                    <!-- Evidence Samples -->
                                    <?php if (!empty($alert['evidence_samples'])): ?>
                                        <div class="p-2 bg-light rounded-2 small mb-2 border" style="font-size: 11.5px;">
                                            <div class="fw-bold text-dark mb-1">Sample Evidence Records:</div>
                                            <ul class="mb-0 ps-3">
                                                <?php foreach ($alert['evidence_samples'] as $sample): ?>
                                                    <li><?= htmlspecialchars($sample) ?></li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Recommended Action -->
                                    <div class="small text-dark">
                                        <strong><i class="bi bi-arrow-right-circle text-primary me-1"></i>Recommended Action:</strong> 
                                        <?= htmlspecialchars($alert['recommended_action']) ?>
                                    </div>
                                </div>

                                <div class="text-nowrap align-self-start align-self-md-center">
                                    <a href="<?= $alert['action_url'] ?>" class="btn btn-outline-primary btn-sm rounded-3 px-3 fw-semibold">
                                        Resolve Issue &rarr;
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
