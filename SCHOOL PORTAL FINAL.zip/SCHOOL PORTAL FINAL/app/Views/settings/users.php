<?php
$title = $title ?? 'User Management';
$layout = 'layouts/app';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-users-cog text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Manage system users, assign roles, and monitor account access.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('users/create')) ?>" class="btn btn-primary shadow-sm action-hover rounded-pill px-4 fw-bold d-flex align-items-center">
            <i class="fas fa-user-plus me-2"></i> Add User
        </a>
    </div>
</div>

<?php if (hasFlash('success')): ?>
    <div class="alert alert-success border-0 shadow-sm rounded-3 fw-semibold mb-4 bg-success-subtle text-success">
        <i class="fas fa-check-circle me-2"></i> <?= e(getFlash('success')) ?>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3" style="width: 25%;">User Info</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Role</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Linked Employee</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-center">Status</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Last Login</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        <i class="fas fa-users-slash fa-3x mb-3 text-light"></i>
                        <h5 class="fw-bold text-gray-500">No Users Found</h5>
                        <p class="mb-0 text-sm">Create a user account to get started.</p>
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                    <tr class="user-row">
                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center shadow-sm fw-bold" style="width: 40px; height: 40px; flex-shrink: 0;">
                                    <?= strtoupper(substr(trim($u['name']), 0, 1)) ?>
                                </div>
                                <div>
                                    <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($u['name']) ?></h6>
                                    <span class="text-xs text-muted"><i class="fas fa-envelope me-1"></i> <?= e($u['email']) ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="py-3">
                            <span class="badge bg-light text-dark border px-3 rounded-pill shadow-sm">
                                <i class="fas fa-user-shield text-secondary me-1"></i> <?= e($u['role_name']) ?>
                            </span>
                        </td>
                        <td class="py-3">
                            <?php if (!empty($u['emp_first_name'])): ?>
                                <div class="text-sm fw-semibold text-gray-800">
                                    <?= e($u['emp_first_name'] . ' ' . $u['emp_last_name']) ?>
                                </div>
                                <span class="text-xs text-muted"><i class="fas fa-id-badge me-1"></i> <?= e($u['emp_code']) ?></span>
                            <?php else: ?>
                                <span class="badge bg-secondary-subtle text-secondary px-3 rounded-pill fw-semibold border border-secondary border-opacity-25">
                                    Not Linked
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 text-center">
                            <?php if ((int)$u['status'] === 1): ?>
                                <span class="badge bg-success-subtle text-success border border-success border-opacity-25 px-3 rounded-pill"><i class="fas fa-circle text-xs me-1"></i> Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger border-opacity-25 px-3 rounded-pill"><i class="fas fa-ban text-xs me-1"></i> Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 text-sm text-muted">
                            <?php if ($u['last_login_at']): ?>
                                <div><i class="far fa-calendar-alt me-1"></i> <?= e(formatDate($u['last_login_at'], 'd M Y')) ?></div>
                                <div class="text-xs"><i class="far fa-clock me-1"></i> <?= e(formatDate($u['last_login_at'], 'h:i A')) ?></div>
                            <?php else: ?>
                                <span class="fst-italic">Never Logged In</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <?php if (in_array($u['role_slug'], ['hr', 'finance', 'receptionist', 'school_admin'])): ?>
                                <a href="<?= e(url('users/' . $u['id'] . '/edit')) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 action-hover shadow-sm" title="Edit User">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .user-row {
        transition: all 0.2s ease;
    }
    .user-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 10px -4px rgba(0,0,0,0.05);
        position: relative;
        z-index: 10;
    }
    .user-row:hover .avatar {
        transform: scale(1.1);
        box-shadow: 0 4px 8px rgba(13, 110, 253, 0.2) !important;
    }
    
    .bg-primary-subtle { background-color: #cfe2ff !important; }
    .bg-success-subtle { background-color: #d1e7dd !important; }
    .bg-danger-subtle { background-color: #f8d7da !important; }
    .bg-secondary-subtle { background-color: #f8f9fa !important; }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(13, 110, 253, 0.2) !important;
    }
</style>
