<?php
$title = 'Settings';
$layout = 'layouts/app';
$activeTab = $activeTab ?? 'school-profile';
$tabBreadcrumbs = [
  'school-profile' => 'School Profile',
  'academic-setup' => 'Academic Setup',
  'admissions' => 'Admissions',
  'staff-onboarding' => 'Staff Onboarding',
  'id-formats' => 'ID Formats',
  'region-language' => 'Region & Language',
  'appearance' => 'Appearance',
  'email-alerts' => 'Email Alerts',
  'sms-alerts' => 'SMS Alerts',
  'in-app-alerts' => 'In-App Alerts',
  'shortcodes' => 'Shortcodes',
  'system' => 'System',
  'activity-log' => 'Activity Log'
];
$activeBreadcrumb = $tabBreadcrumbs[$activeTab] ?? 'School Profile';
?>

<div class="cc-settings-wrapper pb-5">
  <!-- Breadcrumb & Top Bar -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
      <nav aria-label="breadcrumb" class="mb-1">
        <ol class="breadcrumb mb-1 text-xs" style="font-size: 13px;">
          <li class="breadcrumb-item text-muted">Settings</li>
          <li class="breadcrumb-item active text-dark fw-medium" id="cc-breadcrumb-active" aria-current="page"><?= e($activeBreadcrumb) ?></li>
        </ol>
      </nav>
      <h1 class="h3 fw-bold text-dark mb-1" style="font-size: 26px; letter-spacing: -0.02em;">Settings</h1>
      <p class="text-muted mb-0" style="font-size: 13.5px;">Manage education presets, dynamic labels, admissions, onboarding, and system configurations.</p>
    </div>

    <div id="cc-save-btn-container" class="<?= $activeTab === 'activity-log' ? 'd-none' : '' ?>">
      <button type="submit" form="ccSettingsForm" class="btn text-white fw-semibold d-inline-flex align-items-center gap-2 px-3 py-2 shadow-sm cc-save-btn">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
          <polyline points="17 21 17 13 7 13 7 21"></polyline>
          <polyline points="7 3 7 8 15 8"></polyline>
        </svg>
        Save Settings
      </button>
    </div>
  </div>

  <form id="ccSettingsForm" method="post" action="<?= e(url('settings')) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="active_tab" id="active_tab_input" value="<?= e($activeTab) ?>">

    <div class="row g-4">
      <!-- Left Column: 13 Navigation Tabs -->
      <div class="col-xl-3 col-lg-4 col-md-5">
        <div class="card border-0 shadow-sm rounded-3 p-2 bg-white cc-nav-card">
          <nav class="nav flex-column cc-vertical-tabs" id="settings-tab-nav">
            
            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'school-profile' ? 'active' : '' ?>" data-tab="school-profile" onclick="switchSettingsTab('school-profile', 'School Profile')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/><path d="M9 9h1"/><path d="M9 13h1"/><path d="M9 17h1"/><path d="M14 9h1"/><path d="M14 13h1"/><path d="M14 17h1"/></svg>
              </span>
              <span class="cc-tab-label">School Profile</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'academic-setup' ? 'active' : '' ?>" data-tab="academic-setup" onclick="switchSettingsTab('academic-setup', 'Academic Setup')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
              </span>
              <span class="cc-tab-label">Academic Setup</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'admissions' ? 'active' : '' ?>" data-tab="admissions" onclick="switchSettingsTab('admissions', 'Admissions')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
              </span>
              <span class="cc-tab-label">Admissions</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'staff-onboarding' ? 'active' : '' ?>" data-tab="staff-onboarding" onclick="switchSettingsTab('staff-onboarding', 'Staff Onboarding')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              </span>
              <span class="cc-tab-label">Staff Onboarding</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'id-formats' ? 'active' : '' ?>" data-tab="id-formats" onclick="switchSettingsTab('id-formats', 'ID Formats')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              </span>
              <span class="cc-tab-label">ID Formats</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'region-language' ? 'active' : '' ?>" data-tab="region-language" onclick="switchSettingsTab('region-language', 'Region & Language')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
              </span>
              <span class="cc-tab-label">Region & Language</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'appearance' ? 'active' : '' ?>" data-tab="appearance" onclick="switchSettingsTab('appearance', 'Appearance')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>
              </span>
              <span class="cc-tab-label">Appearance</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'email-alerts' ? 'active' : '' ?>" data-tab="email-alerts" onclick="switchSettingsTab('email-alerts', 'Email Alerts')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              </span>
              <span class="cc-tab-label">Email Alerts</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'sms-alerts' ? 'active' : '' ?>" data-tab="sms-alerts" onclick="switchSettingsTab('sms-alerts', 'SMS Alerts')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
              </span>
              <span class="cc-tab-label">SMS Alerts</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'in-app-alerts' ? 'active' : '' ?>" data-tab="in-app-alerts" onclick="switchSettingsTab('in-app-alerts', 'In-App Alerts')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
              </span>
              <span class="cc-tab-label">In-App Alerts</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'shortcodes' ? 'active' : '' ?>" data-tab="shortcodes" onclick="switchSettingsTab('shortcodes', 'Shortcodes')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
              </span>
              <span class="cc-tab-label">&lt;&gt; Shortcodes</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'system' ? 'active' : '' ?>" data-tab="system" onclick="switchSettingsTab('system', 'System')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
              </span>
              <span class="cc-tab-label">System</span>
            </button>

            <button type="button" class="nav-link cc-tab-link <?= $activeTab === 'activity-log' ? 'active' : '' ?>" data-tab="activity-log" onclick="switchSettingsTab('activity-log', 'Activity Log')">
              <span class="cc-tab-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
              </span>
              <span class="cc-tab-label">Activity Log</span>
            </button>

          </nav>
        </div>
      </div>

      <!-- Right Column: Tab Panes -->
      <div class="col-xl-9 col-lg-8 col-md-7">
        
        <!-- 1. School Profile Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'school-profile' ? 'active' : 'd-none' ?>" id="pane-school-profile">
          
          <!-- Card 1: Institution Profile -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Institution Profile</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Basic school registration values.</p>
              </div>
            </div>

            <div class="row g-3 mb-4">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">School Name</label>
                <input type="text" name="school_name" class="form-control cc-input" value="<?= e($school['name'] ?? 'School Name') ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">School Code / Registration ID</label>
                <input type="text" name="school_code" class="form-control cc-input" value="<?= e($school['code'] ?? 'NIA-IN-01') ?>" required>
              </div>
            </div>

            <div class="row g-3">
              <!-- School Logo -->
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">School Logo</label>
                <div class="cc-media-box">
                  <div class="d-flex align-items-center gap-3">
                    <div class="cc-media-preview-box">
                      <img id="logo-preview-img" src="<?= e(url(!empty($school['logo']) ? $school['logo'] : 'uploads/logos/school-logo.svg')) ?>" alt="School Logo" class="cc-media-img">
                    </div>
                    <div>
                      <div class="fw-medium text-dark text-xs mb-0" id="logo-filename"><?= !empty($school['logo']) ? e(basename($school['logo'])) : 'school-logo.png' ?></div>
                      <div class="text-muted" style="font-size: 11.5px;">Upload school logo (PNG or JPG recommended)</div>
                    </div>
                  </div>
                  <div>
                    <label class="btn btn-link text-primary p-0 text-decoration-none fw-medium cursor-pointer" style="font-size: 13px;">
                      Change
                      <input type="file" name="logo" class="d-none" accept="image/*" onchange="previewMediaFile(this, 'logo-preview-img', 'logo-filename')">
                    </label>
                  </div>
                </div>
              </div>

              <!-- Authorized Signature -->
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Authorized Signature</label>
                <div class="cc-media-box">
                  <div class="d-flex align-items-center gap-3">
                    <div class="cc-media-preview-box signature-box">
                      <img id="sig-preview-img" src="<?= e(url(!empty($school['signature_image']) ? $school['signature_image'] : 'uploads/logos/signature.svg')) ?>" alt="Signature" class="cc-media-img" style="object-fit: contain;">
                    </div>
                    <div>
                      <div class="fw-medium text-dark text-xs mb-0" id="sig-filename">signature.svg</div>
                      <div class="text-muted" style="font-size: 11.5px;">Principal / Registrar signature for cards &amp; invoices</div>
                    </div>
                  </div>
                  <div>
                    <label class="btn btn-link text-primary p-0 text-decoration-none fw-medium cursor-pointer" style="font-size: 13px;">
                      Change
                      <input type="file" name="signature" class="d-none" accept="image/*" onchange="previewMediaFile(this, 'sig-preview-img', 'sig-filename')">
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 2: Contact Information -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Contact Information</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">How candidates and parents reach the school.</p>
              </div>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Primary Email Address</label>
                <input type="email" name="primary_email" class="form-control cc-input" value="<?= e($school['email'] ?? $settings['primary_email'] ?? '') ?>" placeholder="admin@school.edu">
              </div>
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Primary Telephone</label>
                <input type="text" name="primary_phone" class="form-control cc-input" value="<?= e($school['phone'] ?? $settings['primary_phone'] ?? '') ?>" placeholder="+92 300 1234567">
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label text-xs fw-semibold text-gray-700">Institution Website</label>
              <input type="url" name="institution_website" class="form-control cc-input" value="<?= e($school['website'] ?? $settings['institution_website'] ?? '') ?>" placeholder="https://www.yourschool.edu">
            </div>

            <div class="mb-0">
              <label class="form-label text-xs fw-semibold text-gray-700">Postal Address</label>
              <textarea name="postal_address" class="form-control cc-input" rows="3" placeholder="House/Plot, Street, Area, City, Province, Country"><?= e(!empty($school['address']) ? $school['address'] : ($settings['postal_address'] ?? '')) ?></textarea>
            </div>
          </div>

        </div>

        <!-- 2. Academic Setup Tab (Matches PDF) -->
        <div class="cc-tab-content-pane <?= $activeTab === 'academic-setup' ? 'active' : 'd-none' ?>" id="pane-academic-setup">
          
          <!-- Card 1: Country & Curriculum Presets -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Country &amp; Curriculum Presets</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Select a regional curriculum preset to automatically configure localized academic terms, grading systems, and session cycles.</p>
              </div>
            </div>

            <!-- Current Active System notice -->
            <div class="p-3 mb-4 rounded-3 border d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2" style="background-color: #faf8ff; border-color: #ede9fe !important;">
              <div class="d-flex align-items-center gap-2">
                <span style="color: #6366f1;">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </span>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 12.5px;">Current Active System</div>
                  <div class="text-muted" style="font-size: 11.5px;">The active localized configuration driving your platform:</div>
                </div>
              </div>
              <div>
                <span class="badge border bg-white text-dark fw-medium px-3 py-2 rounded-2 shadow-xs" id="active-system-badge" style="font-size: 12.5px; border-color: #d1d5db !important;">
                  India (Customized)
                </span>
                <input type="hidden" name="curriculum_preset" id="curriculum_preset_input" value="<?= e($settings['curriculum_preset'] ?? 'IN') ?>">
              </div>
            </div>

            <!-- 3 Preset Cards Grid -->
            <div class="row g-3">
              <!-- IN -->
              <div class="col-md-4">
                <div class="p-3 rounded-3 border h-100 cc-preset-card <?= ($settings['curriculum_preset'] ?? 'IN') === 'IN' ? 'active' : '' ?>" id="preset-card-in" onclick="selectCurriculumPreset('IN')">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold text-dark" style="font-size: 18px; letter-spacing: -0.02em;">IN</span>
                    <span class="badge rounded-pill fw-semibold cc-preset-badge px-2 py-1 <?= ($settings['curriculum_preset'] ?? 'IN') === 'IN' ? '' : 'd-none' ?>" id="badge-in" style="font-size: 11px; background-color: #dcfce7; color: #15803d;">Active</span>
                  </div>
                  <div class="fw-bold text-dark mb-1" style="font-size: 13.5px;">India (CBSE / ICSE / State)</div>
                  <p class="text-muted mb-3" style="font-size: 12px; line-height: 1.4;">Class &amp; Section structure with Marks &amp; Percentage grading.</p>
                  <div class="text-muted text-xs pt-2 border-top" style="font-size: 11px;">
                    Cycle: Apr - Mar &bull; Units: Class 1-12 &bull; Groups: Section A-D
                  </div>
                </div>
              </div>

              <!-- US -->
              <div class="col-md-4">
                <div class="p-3 rounded-3 border h-100 cc-preset-card <?= ($settings['curriculum_preset'] ?? '') === 'US' ? 'active' : '' ?>" id="preset-card-us" onclick="selectCurriculumPreset('US')">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold text-dark" style="font-size: 18px; letter-spacing: -0.02em;">US</span>
                    <span class="badge rounded-pill fw-semibold cc-preset-badge px-2 py-1 <?= ($settings['curriculum_preset'] ?? '') === 'US' ? '' : 'd-none' ?>" id="badge-us" style="font-size: 11px; background-color: #dcfce7; color: #15803d;">Active</span>
                  </div>
                  <div class="fw-bold text-dark mb-1" style="font-size: 13.5px;">United States (K-12)</div>
                  <p class="text-muted mb-3" style="font-size: 12px; line-height: 1.4;">Grade &amp; Section structure with Letter Grade &amp; GPA system.</p>
                  <div class="text-muted text-xs pt-2 border-top" style="font-size: 11px;">
                    Cycle: Aug - Jun &bull; Units: Grade 1-12 &bull; Groups: Period / Section
                  </div>
                </div>
              </div>

              <!-- GB -->
              <div class="col-md-4">
                <div class="p-3 rounded-3 border h-100 cc-preset-card <?= ($settings['curriculum_preset'] ?? '') === 'GB' ? 'active' : '' ?>" id="preset-card-gb" onclick="selectCurriculumPreset('GB')">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold text-dark" style="font-size: 18px; letter-spacing: -0.02em;">GB</span>
                    <span class="badge rounded-pill fw-semibold cc-preset-badge px-2 py-1 <?= ($settings['curriculum_preset'] ?? '') === 'GB' ? '' : 'd-none' ?>" id="badge-gb" style="font-size: 11px; background-color: #dcfce7; color: #15803d;">Active</span>
                  </div>
                  <div class="fw-bold text-dark mb-1" style="font-size: 13.5px;">United Kingdom (UK National Curriculum)</div>
                  <p class="text-muted mb-3" style="font-size: 12px; line-height: 1.4;">Year Group &amp; Form structure with Key Stage assessment levels.</p>
                  <div class="text-muted text-xs pt-2 border-top" style="font-size: 11px;">
                    Cycle: Sep - Jul &bull; Units: Year 1-13 &bull; Groups: Form A-C
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 2: Academic Cycle Defaults -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Academic Cycle Defaults</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Defaults used when creating new academic sessions and terms.</p>
              </div>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Session Start Month</label>
                <select name="session_start_month" id="session_start_month" class="form-select cc-input">
                  <?php foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $m): ?>
                    <option value="<?= $m ?>" <?= ($settings['session_start_month'] ?? 'April') === $m ? 'selected' : '' ?>><?= $m ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Session End Month</label>
                <select name="session_end_month" id="session_end_month" class="form-select cc-input">
                  <?php foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $m): ?>
                    <option value="<?= $m ?>" <?= ($settings['session_end_month'] ?? 'March') === $m ? 'selected' : '' ?>><?= $m ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="row g-3 mb-4">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Default Grading Scheme</label>
                <select name="default_grading_scheme" id="default_grading_scheme" class="form-select cc-input">
                  <option value="Marks + Percentage (e.g. 85/100 -> 85%)" <?= ($settings['default_grading_scheme'] ?? 'Marks + Percentage (e.g. 85/100 -> 85%)') === 'Marks + Percentage (e.g. 85/100 -> 85%)' ? 'selected' : '' ?>>Marks + Percentage (e.g. 85/100 -> 85%)</option>
                  <option value="Letter Grade & GPA (A-F, 4.0 Scale)" <?= ($settings['default_grading_scheme'] ?? '') === 'Letter Grade & GPA (A-F, 4.0 Scale)' ? 'selected' : '' ?>>Letter Grade &amp; GPA (A-F, 4.0 Scale)</option>
                  <option value="UK Key Stage Assessment (Emerging / Expected / Exceeding)" <?= ($settings['default_grading_scheme'] ?? '') === 'UK Key Stage Assessment (Emerging / Expected / Exceeding)' ? 'selected' : '' ?>>UK Key Stage Assessment (Emerging / Expected / Exceeding)</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Class Seeding Strategy</label>
                <select name="class_seeding_strategy" id="class_seeding_strategy" class="form-select cc-input">
                  <option value="Clone from previous session" <?= ($settings['class_seeding_strategy'] ?? 'Clone from previous session') === 'Clone from previous session' ? 'selected' : '' ?>>Clone from previous session</option>
                  <option value="Create new empty classes" <?= ($settings['class_seeding_strategy'] ?? '') === 'Create new empty classes' ? 'selected' : '' ?>>Create new empty classes</option>
                  <option value="Use curriculum standard template" <?= ($settings['class_seeding_strategy'] ?? '') === 'Use curriculum standard template' ? 'selected' : '' ?>>Use curriculum standard template</option>
                </select>
              </div>
            </div>

            <div class="row g-3">
              <!-- Default Academic Units -->
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Default Academic Units</label>
                <div class="input-group mb-2">
                  <input type="text" id="new-unit-input" class="form-control cc-input" placeholder="e.g. Grade 1" onkeydown="if(event.key==='Enter'){event.preventDefault();addAcademicUnit();}">
                  <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addAcademicUnit()">+ Add</button>
                </div>
                <div class="p-2 border rounded-2 cc-tags-container" id="academic-units-container">
                  <!-- Rendered dynamically -->
                </div>
                <input type="hidden" name="default_academic_units" id="default_academic_units_input" value="<?= e($settings['default_academic_units'] ?? '["Nursery","LKG","UKG","Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10","Class 11","Class 12"]') ?>">
              </div>

              <!-- Default Groups Per Unit -->
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Default Groups Per Unit</label>
                <div class="input-group mb-2">
                  <input type="text" id="new-group-input" class="form-control cc-input" placeholder="e.g. Section A" onkeydown="if(event.key==='Enter'){event.preventDefault();addGroupUnit();}">
                  <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addGroupUnit()">+ Add</button>
                </div>
                <div class="p-2 border rounded-2 cc-tags-container" id="group-units-container">
                  <!-- Rendered dynamically -->
                </div>
                <input type="hidden" name="default_groups_per_unit" id="default_groups_per_unit_input" value="<?= e($settings['default_groups_per_unit'] ?? '["A","B","C","D"]') ?>">
              </div>
            </div>
          </div>

          <!-- Card 3: Dynamic Terminology -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 2 4 4-14 14H4v-4L18 2z"/><path d="m14.5 5.5 4 4"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Dynamic Terminology</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Customise the singular and plural labels used throughout the platform.</p>
              </div>
            </div>

            <div class="row g-3">
              <!-- Box 1: ACADEMIC SESSION -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Academic Session</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_academic_session_singular" id="term_academic_session_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_session_singular'] ?? 'Academic Year') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_academic_session_plural" id="term_academic_session_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_session_plural'] ?? 'Academic Years') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 2: ACADEMIC TERM -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Academic Term</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_academic_term_singular" id="term_academic_term_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_term_singular'] ?? 'Term') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_academic_term_plural" id="term_academic_term_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_term_plural'] ?? 'Terms') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 3: ACADEMIC UNIT -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Academic Unit</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_academic_unit_singular" id="term_academic_unit_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_unit_singular'] ?? 'Class') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_academic_unit_plural" id="term_academic_unit_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_unit_plural'] ?? 'Classes') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 4: ACADEMIC GROUP -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Academic Group</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_academic_group_singular" id="term_academic_group_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_group_singular'] ?? 'Section') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_academic_group_plural" id="term_academic_group_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_academic_group_plural'] ?? 'Sections') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 5: SUBJECT -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Subject</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_subject_singular" id="term_subject_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_subject_singular'] ?? 'Subject') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_subject_plural" id="term_subject_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_subject_plural'] ?? 'Subjects') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 6: ASSESSMENT -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Assessment</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_assessment_singular" id="term_assessment_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_assessment_singular'] ?? 'Exam') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_assessment_plural" id="term_assessment_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_assessment_plural'] ?? 'Exams') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 7: STUDENT -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Student</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_student_singular" id="term_student_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_student_singular'] ?? 'Student') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_student_plural" id="term_student_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_student_plural'] ?? 'Students') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 8: STAFF MEMBER -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Staff Member</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_staff_singular" id="term_staff_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_staff_singular'] ?? 'Staff') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_staff_plural" id="term_staff_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_staff_plural'] ?? 'Staff') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 9: GUARDIAN -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Guardian</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_guardian_singular" id="term_guardian_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_guardian_singular'] ?? 'Parent / Guardian') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_guardian_plural" id="term_guardian_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_guardian_plural'] ?? 'Parents / Guardians') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 10: INVOICE -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Invoice</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_invoice_singular" id="term_invoice_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_invoice_singular'] ?? 'Invoice') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_invoice_plural" id="term_invoice_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_invoice_plural'] ?? 'Invoices') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 11: PAYMENT -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Payment</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_payment_singular" id="term_payment_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_payment_singular'] ?? 'Payment') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_payment_plural" id="term_payment_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_payment_plural'] ?? 'Payments') ?>">
                  </div>
                </div>
              </div>

              <!-- Box 12: ATTENDANCE RECORD -->
              <div class="col-lg-4 col-md-6">
                <div class="p-3 border rounded-3 cc-term-box h-100">
                  <div class="text-xs fw-bold text-gray-600 text-uppercase tracking-wider mb-2" style="font-size: 11px;">Attendance Record</div>
                  <div class="mb-2">
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Singular</label>
                    <input type="text" name="term_attendance_record_singular" id="term_attendance_record_singular" class="form-control form-control-sm cc-input" value="<?= e($settings['term_attendance_record_singular'] ?? 'Attendance Record') ?>">
                  </div>
                  <div>
                    <label class="form-label text-muted mb-1" style="font-size: 11px;">Plural</label>
                    <input type="text" name="term_attendance_record_plural" id="term_attendance_record_plural" class="form-control form-control-sm cc-input" value="<?= e($settings['term_attendance_record_plural'] ?? 'Attendance Records') ?>">
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

        <!-- 3. Admissions Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'admissions' ? 'active' : 'd-none' ?>" id="pane-admissions">
          
          <!-- Hidden compatibility fields -->
          <input type="hidden" name="admission_status" value="<?= e($settings['admission_status'] ?? 'open') ?>">
          <input type="hidden" name="registration_fee" value="<?= e($settings['registration_fee'] ?? '500') ?>">
          <input type="hidden" name="auto_roll_number" value="<?= e($settings['auto_roll_number'] ?? '1') ?>">

          <!-- Card 1: Forms Activation Status -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M9 14l2 2 4-4"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Forms Activation Status</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Toggle which public-facing admissions forms are active.</p>
              </div>
            </div>

            <div class="row g-4">
              <div class="col-md-6 d-flex flex-column gap-3">
                <!-- Toggle 1: Enable Public Admission Form -->
                <div class="form-check d-flex align-items-start gap-2">
                  <input type="hidden" name="admission_public_form" value="0">
                  <input class="form-check-input mt-1" type="checkbox" name="admission_public_form" id="admission_public_form" value="1" <?= ($settings['admission_public_form'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                  <label class="form-check-label cursor-pointer" for="admission_public_form">
                    <span class="fw-semibold text-dark text-xs d-block mb-0">Enable Public Admission Form</span>
                    <span class="text-muted" style="font-size: 12px;">Allow applicants to submit an admission application on the public website.</span>
                  </label>
                </div>

                <!-- Toggle 3: Auto-Convert Approved Applications -->
                <div class="form-check d-flex align-items-start gap-2">
                  <input type="hidden" name="admission_auto_convert" value="0">
                  <input class="form-check-input mt-1" type="checkbox" name="admission_auto_convert" id="admission_auto_convert" value="1" <?= ($settings['admission_auto_convert'] ?? '0') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                  <label class="form-check-label cursor-pointer" for="admission_auto_convert">
                    <span class="fw-semibold text-dark text-xs d-block mb-0">Auto-Convert Approved Applications</span>
                    <span class="text-muted" style="font-size: 12px;">Automatically convert accepted applications into enrolled student records.</span>
                  </label>
                </div>
              </div>

              <div class="col-md-6 d-flex flex-column gap-3">
                <!-- Toggle 2: Enable Status Lookup -->
                <div class="form-check d-flex align-items-start gap-2">
                  <input type="hidden" name="admission_status_lookup" value="0">
                  <input class="form-check-input mt-1" type="checkbox" name="admission_status_lookup" id="admission_status_lookup" value="1" <?= ($settings['admission_status_lookup'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                  <label class="form-check-label cursor-pointer" for="admission_status_lookup">
                    <span class="fw-semibold text-dark text-xs d-block mb-0">Enable Status Lookup</span>
                    <span class="text-muted" style="font-size: 12px;">Allow applicants to check their application status.</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 2: Alert Notifications -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Alert Notifications</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Email addresses that receive admission event alerts.</p>
              </div>
            </div>

            <div>
              <label class="form-label text-xs fw-semibold text-gray-700">Notification Recipients</label>
              <input type="email" name="admission_alert_recipients" class="form-control cc-input" value="<?= e($settings['admission_alert_recipients'] ?? 'admissions.dev@codeclove.io') ?>">
            </div>
          </div>

          <!-- Card 3: Workflow Defaults -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Workflow Defaults</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Default statuses applied when records are created.</p>
              </div>
            </div>

            <div class="mb-4">
              <label class="form-label text-xs fw-semibold text-gray-700">Default Status</label>
              <select name="admission_default_status" class="form-select cc-input">
                <?php
                $curDefaultStatus = $settings['admission_default_status'] ?? 'Submitted';
                $statusList = ['Submitted', 'Inquiry', 'Under Review', 'More Info Needed', 'Interview Scheduled', 'Accepted', 'Waitlisted', 'Rejected', 'Admitted', 'Withdrawn'];
                foreach ($statusList as $stItem):
                ?>
                  <option value="<?= e($stItem) ?>" <?= strcasecmp($curDefaultStatus, $stItem) === 0 ? 'selected' : '' ?>><?= e($stItem) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- Inner box containing Allowed Statuses, Verification Fields & Required Documents -->
            <div class="border rounded-3 p-3 bg-white">
              <div class="row g-3 mb-4">
                <!-- Left: Allowed Statuses -->
                <div class="col-md-6">
                  <div class="fw-bold text-dark mb-3" style="font-size: 14px;">Allowed Statuses</div>
                  <div class="input-group mb-3">
                    <input type="text" id="new-admission-status-input" class="form-control cc-input" placeholder="e.g. pending" onkeydown="if(event.key==='Enter'){event.preventDefault();addAdmissionStatus();}">
                    <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addAdmissionStatus()">+ Add</button>
                  </div>
                  <div class="p-2 border rounded-2 cc-tags-container" id="admission-statuses-container">
                    <!-- Rendered dynamically -->
                  </div>
                  <input type="hidden" name="admission_allowed_statuses" id="admission_allowed_statuses_input" value="<?= e($settings['admission_allowed_statuses'] ?? '["inquiry","submitted","under_review","more_info_needed","interview_scheduled","accepted","waitlisted","rejected","admitted","withdrawn"]') ?>">
                </div>

                <!-- Right: Verification Fields -->
                <div class="col-md-6">
                  <div class="fw-bold text-dark mb-3" style="font-size: 14px;">Verification Fields</div>
                  <div class="input-group mb-3">
                    <input type="text" id="new-admission-verify-input" class="form-control cc-input" placeholder="e.g. national_id" onkeydown="if(event.key==='Enter'){event.preventDefault();addAdmissionVerifyField();}">
                    <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addAdmissionVerifyField()">+ Add</button>
                  </div>
                  <div class="p-2 border rounded-2 cc-tags-container" id="admission-verify-container">
                    <!-- Rendered dynamically -->
                  </div>
                  <input type="hidden" name="admission_verification_fields" id="admission_verification_fields_input" value="<?= e($settings['admission_verification_fields'] ?? '["reference_number","student_date_of_birth"]') ?>">
                </div>
              </div>

              <!-- Required Documents -->
              <div>
                <div class="fw-bold text-dark mb-3" style="font-size: 14px;">Required Documents</div>
                <div class="input-group mb-3">
                  <input type="text" id="new-admission-doc-input" class="form-control cc-input" placeholder="e.g. birth_certificate" onkeydown="if(event.key==='Enter'){event.preventDefault();addAdmissionDoc();}">
                  <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addAdmissionDoc()">+ Add</button>
                </div>
                <div class="p-2 border rounded-2 cc-tags-container" id="admission-docs-container">
                  <div class="text-muted text-xs p-2" id="empty-admission-docs-msg">No required documents defined.</div>
                </div>
                <input type="hidden" name="admission_required_documents" id="admission_required_documents_input" value="<?= e($settings['admission_required_documents'] ?? '[]') ?>">
              </div>
            </div>

          </div>

        </div>

        <!-- 4. Staff Onboarding Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'staff-onboarding' ? 'active' : 'd-none' ?>" id="pane-staff-onboarding">
          
          <!-- Card 1: Recruitment Configuration -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Recruitment Configuration</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Activate and manage employee application settings.</p>
              </div>
            </div>

            <div class="d-flex flex-column gap-3">
              <!-- Toggle 1 -->
              <div class="form-check d-flex align-items-start gap-2">
                <input class="form-check-input mt-1" type="checkbox" name="staff_public_applications" id="staff_public_applications" value="1" <?= ($settings['staff_public_applications'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                <label class="form-check-label cursor-pointer" for="staff_public_applications">
                  <span class="fw-semibold text-dark text-xs d-block mb-0">Enable Public Staff Applications Form</span>
                  <span class="text-muted" style="font-size: 12px;">Exposes employee recruitment job application form.</span>
                </label>
              </div>

              <!-- Toggle 2 -->
              <div class="form-check d-flex align-items-start gap-2">
                <input class="form-check-input mt-1" type="checkbox" name="staff_application_tracker" id="staff_application_tracker" value="1" <?= ($settings['staff_application_tracker'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                <label class="form-check-label cursor-pointer" for="staff_application_tracker">
                  <span class="fw-semibold text-dark text-xs d-block mb-0">Enable Application Status Tracker</span>
                  <span class="text-muted" style="font-size: 12px;">Enables candidate review tracking by email reference.</span>
                </label>
              </div>
            </div>
          </div>

          <!-- Card 2: Account Configuration -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Account Configuration</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Default options and role mapping.</p>
              </div>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Login Creation Flow</label>
                <select name="staff_login_creation_flow" class="form-select cc-input">
                  <option value="Email Invite Login Link (Recommended)" <?= ($settings['staff_login_creation_flow'] ?? 'Email Invite Login Link (Recommended)') === 'Email Invite Login Link (Recommended)' ? 'selected' : '' ?>>Email Invite Login Link (Recommended)</option>
                  <option value="Generate Temporary Password" <?= ($settings['staff_login_creation_flow'] ?? '') === 'Generate Temporary Password' ? 'selected' : '' ?>>Generate Temporary Password</option>
                  <option value="Manual Admin Creation Only" <?= ($settings['staff_login_creation_flow'] ?? '') === 'Manual Admin Creation Only' ? 'selected' : '' ?>>Manual Admin Creation Only</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Default Role Assigned on Entry</label>
                <select name="staff_default_role" class="form-select cc-input">
                  <option value="staff" <?= ($settings['staff_default_role'] ?? 'staff') === 'staff' ? 'selected' : '' ?>>staff</option>
                  <option value="teacher" <?= ($settings['staff_default_role'] ?? '') === 'teacher' ? 'selected' : '' ?>>teacher</option>
                  <option value="accountant" <?= ($settings['staff_default_role'] ?? '') === 'accountant' ? 'selected' : '' ?>>accountant</option>
                  <option value="librarian" <?= ($settings['staff_default_role'] ?? '') === 'librarian' ? 'selected' : '' ?>>librarian</option>
                  <option value="receptionist" <?= ($settings['staff_default_role'] ?? '') === 'receptionist' ? 'selected' : '' ?>>receptionist</option>
                </select>
              </div>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Default Application Status</label>
                <select name="staff_default_status" class="form-select cc-input">
                  <option value="Submitted" <?= ($settings['staff_default_status'] ?? 'Submitted') === 'Submitted' ? 'selected' : '' ?>>Submitted</option>
                  <option value="Under Review" <?= ($settings['staff_default_status'] ?? '') === 'Under Review' ? 'selected' : '' ?>>Under Review</option>
                  <option value="Shortlisted" <?= ($settings['staff_default_status'] ?? '') === 'Shortlisted' ? 'selected' : '' ?>>Shortlisted</option>
                </select>
              </div>
            </div>

            <div class="mb-0">
              <label class="form-label text-xs fw-semibold text-gray-700">Staff Alert Email Recipients</label>
              <input type="email" name="staff_alert_recipients" class="form-control cc-input" value="<?= e($settings['staff_alert_recipients'] ?? 'hr.dev@codeclove.in') ?>">
            </div>
          </div>

          <!-- Card 3: Two-Column Row (Allowed Statuses & Lookup Fields) -->
          <div class="row g-3 mb-4">
            <!-- Left: Allowed Staff Application Statuses -->
            <div class="col-md-6">
              <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card h-100">
                <div class="fw-bold text-dark mb-3" style="font-size: 14px;">Allowed Staff Application Statuses</div>
                <div class="input-group mb-3">
                  <input type="text" id="new-status-input" class="form-control cc-input" placeholder="e.g. interview_scheduled" onkeydown="if(event.key==='Enter'){event.preventDefault();addStaffStatus();}">
                  <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addStaffStatus()">+ Add</button>
                </div>
                <div class="p-2 border rounded-2 cc-tags-container" id="staff-statuses-container">
                  <!-- Rendered dynamically -->
                </div>
                <input type="hidden" name="staff_allowed_statuses" id="staff_allowed_statuses_input" value="<?= e($settings['staff_allowed_statuses'] ?? '["submitted","under_review","more_info_needed","interview_scheduled","offer_sent","accepted","rejected","hired","withdrawn"]') ?>">
              </div>
            </div>

            <!-- Right: Public Lookup Verification Fields -->
            <div class="col-md-6">
              <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card h-100">
                <div class="fw-bold text-dark mb-3" style="font-size: 14px;">Public Lookup Verification Fields</div>
                <div class="input-group mb-3">
                  <input type="text" id="new-lookup-input" class="form-control cc-input" placeholder="e.g. email" onkeydown="if(event.key==='Enter'){event.preventDefault();addStaffLookupField();}">
                  <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addStaffLookupField()">+ Add</button>
                </div>
                <div class="p-2 border rounded-2 cc-tags-container" id="staff-lookup-container">
                  <!-- Rendered dynamically -->
                </div>
                <input type="hidden" name="staff_lookup_verification_fields" id="staff_lookup_verification_fields_input" value="<?= e($settings['staff_lookup_verification_fields'] ?? '["reference_number","email"]') ?>">
              </div>
            </div>
          </div>

          <!-- Card 4: Mandatory Hiring Documents Required -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="mb-3">
              <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Mandatory Hiring Documents Required</h2>
              <p class="text-muted mb-0" style="font-size: 13px;">Documents that candidates must attach to their recruitment forms.</p>
            </div>

            <div class="input-group mb-3">
              <input type="text" id="new-doc-input" class="form-control cc-input" placeholder="e.g. Previous Employment Offer Letter" onkeydown="if(event.key==='Enter'){event.preventDefault();addHiringDoc();}">
              <button type="button" class="btn text-white fw-semibold px-3 cc-add-tag-btn" onclick="addHiringDoc()">+ Add</button>
            </div>

            <div class="p-2 border rounded-2 cc-tags-container" id="hiring-docs-container">
              <div class="text-muted text-xs p-2" id="empty-docs-msg">No hiring documents required currently.</div>
            </div>
            <input type="hidden" name="staff_mandatory_hiring_documents" id="staff_mandatory_hiring_documents_input" value="<?= e($settings['staff_mandatory_hiring_documents'] ?? '[]') ?>">
          </div>

        </div>

        <!-- 5. ID Formats Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'id-formats' ? 'active' : 'd-none' ?>" id="pane-id-formats">
          
          <!-- Header Card -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">ID Format Configuration</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Define prefix, separator, year token, starting number, padding, and reset rule for each auto-generated identifier.</p>
              </div>
            </div>
          </div>

          <?php
          $idConfigs = [
            'student' => [
              'title' => 'STUDENT NUMBER',
              'prefix' => $settings['id_fmt_student_prefix'] ?? 'STU',
              'separator' => $settings['id_fmt_student_separator'] ?? 'none',
              'year' => $settings['id_fmt_student_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_student_start'] ?? '301',
              'padding' => $settings['id_fmt_student_padding'] ?? '4',
              'reset' => $settings['id_fmt_student_reset'] ?? 'yearly',
              'placeholder_prefix' => 'e.g. STU',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'staff' => [
              'title' => 'STAFF MEMBER ID',
              'prefix' => $settings['id_fmt_staff_prefix'] ?? 'EMP',
              'separator' => $settings['id_fmt_staff_separator'] ?? 'none',
              'year' => $settings['id_fmt_staff_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_staff_start'] ?? '61',
              'padding' => $settings['id_fmt_staff_padding'] ?? '4',
              'reset' => $settings['id_fmt_staff_reset'] ?? 'yearly',
              'placeholder_prefix' => 'e.g. EMP',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'admission' => [
              'title' => 'ADMISSION NUMBER',
              'prefix' => $settings['id_fmt_admission_prefix'] ?? 'ADM',
              'separator' => $settings['id_fmt_admission_separator'] ?? 'none',
              'year' => $settings['id_fmt_admission_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_admission_start'] ?? '301',
              'padding' => $settings['id_fmt_admission_padding'] ?? '4',
              'reset' => $settings['id_fmt_admission_reset'] ?? 'yearly',
              'placeholder_prefix' => 'e.g. ADM',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'admission_app' => [
              'title' => 'ADMISSION APPLICATION',
              'prefix' => $settings['id_fmt_admission_app_prefix'] ?? 'APP',
              'separator' => $settings['id_fmt_admission_app_separator'] ?? 'none',
              'year' => $settings['id_fmt_admission_app_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_admission_app_start'] ?? '151',
              'padding' => $settings['id_fmt_admission_app_padding'] ?? '4',
              'reset' => $settings['id_fmt_admission_app_reset'] ?? 'yearly',
              'placeholder_prefix' => 'e.g. APP',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'staff_app' => [
              'title' => 'STAFF APPLICATION',
              'prefix' => $settings['id_fmt_staff_app_prefix'] ?? 'STFAPP',
              'separator' => $settings['id_fmt_staff_app_separator'] ?? 'none',
              'year' => $settings['id_fmt_staff_app_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_staff_app_start'] ?? '61',
              'padding' => $settings['id_fmt_staff_padding'] ?? '4',
              'reset' => $settings['id_fmt_staff_reset'] ?? 'yearly',
              'placeholder_prefix' => 'e.g. STFAPP',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'roll' => [
              'title' => 'ROLL NUMBER',
              'prefix' => $settings['id_fmt_roll_prefix'] ?? '',
              'separator' => $settings['id_fmt_roll_separator'] ?? 'none',
              'year' => $settings['id_fmt_roll_year'] ?? 'none',
              'start' => $settings['id_fmt_roll_start'] ?? '1',
              'padding' => $settings['id_fmt_roll_padding'] ?? '3',
              'reset' => $settings['id_fmt_roll_reset'] ?? 'never',
              'placeholder_prefix' => 'e.g. ADM',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'invoice' => [
              'title' => 'INVOICE NUMBER',
              'prefix' => $settings['id_fmt_invoice_prefix'] ?? 'INV',
              'separator' => $settings['id_fmt_invoice_separator'] ?? 'none',
              'year' => $settings['id_fmt_invoice_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_invoice_start'] ?? '10486',
              'padding' => $settings['id_fmt_invoice_padding'] ?? '5',
              'reset' => $settings['id_fmt_invoice_reset'] ?? 'never',
              'placeholder_prefix' => 'e.g. INV',
              'placeholder_year' => 'e.g. [YYYY]'
            ],
            'payment' => [
              'title' => 'PAYMENT NUMBER',
              'prefix' => $settings['id_fmt_payment_prefix'] ?? 'PAY',
              'separator' => $settings['id_fmt_payment_separator'] ?? 'none',
              'year' => $settings['id_fmt_payment_year'] ?? '[YYYY]',
              'start' => $settings['id_fmt_payment_start'] ?? '10313',
              'padding' => $settings['id_fmt_payment_padding'] ?? '5',
              'reset' => $settings['id_fmt_payment_reset'] ?? 'never',
              'placeholder_prefix' => 'e.g. PAY',
              'placeholder_year' => 'e.g. [YYYY]'
            ]
          ];
          ?>

          <?php foreach ($idConfigs as $k => $c): ?>
            <div class="card border-0 shadow-sm rounded-3 p-3 mb-3 bg-white cc-settings-card">
              <div class="text-xs fw-bold text-gray-700 text-uppercase tracking-wider mb-2" style="font-size: 11.5px; letter-spacing: 0.04em;"><?= $c['title'] ?></div>
              
              <div class="row g-2 mb-2">
                <!-- Prefix -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Prefix</label>
                  <input type="text" name="id_fmt_<?= $k ?>_prefix" id="id_fmt_<?= $k ?>_prefix" class="form-control form-control-sm cc-input" value="<?= e($c['prefix']) ?>" placeholder="<?= $c['placeholder_prefix'] ?>" oninput="updateIdPreview('<?= $k ?>')">
                </div>

                <!-- Separator -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Separator</label>
                  <select name="id_fmt_<?= $k ?>_separator" id="id_fmt_<?= $k ?>_separator" class="form-select form-select-sm cc-input" onchange="updateIdPreview('<?= $k ?>')">
                    <option value="none" <?= $c['separator'] === 'none' ? 'selected' : '' ?>>None (Concate...</option>
                    <option value="-" <?= $c['separator'] === '-' ? 'selected' : '' ?>>- (Hyphen)</option>
                    <option value="/" <?= $c['separator'] === '/' ? 'selected' : '' ?>>/ (Slash)</option>
                    <option value="_" <?= $c['separator'] === '_' ? 'selected' : '' ?>>_ (Underscore)</option>
                  </select>
                </div>

                <!-- Year Token -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Year Token</label>
                  <select name="id_fmt_<?= $k ?>_year" id="id_fmt_<?= $k ?>_year" class="form-select form-select-sm cc-input" onchange="updateIdPreview('<?= $k ?>')">
                    <option value="[YYYY]" <?= $c['year'] === '[YYYY]' ? 'selected' : '' ?>>[YYYY]</option>
                    <option value="[YY]" <?= $c['year'] === '[YY]' ? 'selected' : '' ?>>[YY]</option>
                    <option value="none" <?= $c['year'] === 'none' ? 'selected' : '' ?>><?= $k === 'roll' ? 'e.g. [YYYY]' : 'None' ?></option>
                  </select>
                </div>

                <!-- Start Number -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Start Number</label>
                  <input type="number" name="id_fmt_<?= $k ?>_start" id="id_fmt_<?= $k ?>_start" class="form-control form-control-sm cc-input" value="<?= e($c['start']) ?>" min="1" oninput="updateIdPreview('<?= $k ?>')">
                </div>

                <!-- Seq. Padding -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Seq. Padding</label>
                  <input type="number" name="id_fmt_<?= $k ?>_padding" id="id_fmt_<?= $k ?>_padding" class="form-control form-control-sm cc-input" value="<?= e($c['padding']) ?>" min="1" max="10" oninput="updateIdPreview('<?= $k ?>')">
                </div>

                <!-- Reset Rule -->
                <div class="col-lg-2 col-md-4 col-6">
                  <label class="form-label text-muted mb-1" style="font-size: 11px;">Reset Rule</label>
                  <select name="id_fmt_<?= $k ?>_reset" id="id_fmt_<?= $k ?>_reset" class="form-select form-select-sm cc-input">
                    <option value="yearly" <?= $c['reset'] === 'yearly' ? 'selected' : '' ?>>Reset Yearly</option>
                    <option value="never" <?= $c['reset'] === 'never' ? 'selected' : '' ?>>Never Reset (C...</option>
                    <option value="session" <?= $c['reset'] === 'session' ? 'selected' : '' ?>>Reset Academic Session</option>
                  </select>
                </div>
              </div>

              <?php
                $initPrefix = $c['prefix'];
                $initSep = ($c['separator'] === 'none' || empty($c['separator'])) ? '' : $c['separator'];
                $initYear = $c['year'] === '[YYYY]' ? '2026' : ($c['year'] === '[YY]' ? '26' : '');
                $initNum = str_pad((string)$c['start'], (int)$c['padding'], '0', STR_PAD_LEFT);
                $initParts = [];
                if ($initPrefix !== '') $initParts[] = $initPrefix;
                if ($initYear !== '') $initParts[] = $initYear;
                $initParts[] = $initNum;
                $initialPreview = implode($initSep, $initParts);
              ?>
              <!-- Preview Line -->
              <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                <span class="text-muted" style="font-size: 11.5px;">Generated ID Preview:</span>
                <span class="badge border font-monospace px-3 py-1" id="preview_<?= $k ?>" style="font-size: 12px; letter-spacing: 0.05em; background-color: #eff6ff; color: #2563eb; border-color: #bfdbfe !important;"><?= e($initialPreview) ?></span>
              </div>
            </div>
          <?php endforeach; ?>

        </div>

        <!-- 6. Region & Language Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'region-language' ? 'active' : 'd-none' ?>" id="pane-region-language">
          
          <!-- Card 1: Language & Calendar -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="2" y1="12" x2="22" y2="12"></line>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Language &amp; Calendar</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Regional language, timezone, and calendar week configuration.</p>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Interface Language</label>
                <select name="default_language" id="default_language" class="form-select cc-input">
                  <option value="en" <?= in_array($settings['default_language'] ?? 'en', ['en', 'English']) ? 'selected' : '' ?>>English</option>
                  <option value="ur" <?= ($settings['default_language'] ?? '') === 'ur' ? 'selected' : '' ?>>Urdu (اردو)</option>
                  <option value="hi" <?= ($settings['default_language'] ?? '') === 'hi' ? 'selected' : '' ?>>Hindi (हिन्दी)</option>
                  <option value="ar" <?= ($settings['default_language'] ?? '') === 'ar' ? 'selected' : '' ?>>Arabic (العربية)</option>
                  <option value="fr" <?= ($settings['default_language'] ?? '') === 'fr' ? 'selected' : '' ?>>French (Français)</option>
                  <option value="es" <?= ($settings['default_language'] ?? '') === 'es' ? 'selected' : '' ?>>Spanish (Español)</option>
                  <option value="bn" <?= ($settings['default_language'] ?? '') === 'bn' ? 'selected' : '' ?>>Bengali (বাংলা)</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Timezone</label>
                <select name="timezone" id="timezone" class="form-select cc-input">
                  <option value="Asia/Kolkata" <?= in_array($settings['timezone'] ?? 'Asia/Kolkata', ['Asia/Kolkata']) ? 'selected' : '' ?>>Asia/Kolkata</option>
                  <option value="Asia/Karachi" <?= ($settings['timezone'] ?? '') === 'Asia/Karachi' ? 'selected' : '' ?>>Asia/Karachi</option>
                  <option value="Asia/Dubai" <?= ($settings['timezone'] ?? '') === 'Asia/Dubai' ? 'selected' : '' ?>>Asia/Dubai</option>
                  <option value="Asia/Riyadh" <?= ($settings['timezone'] ?? '') === 'Asia/Riyadh' ? 'selected' : '' ?>>Asia/Riyadh</option>
                  <option value="Asia/Dhaka" <?= ($settings['timezone'] ?? '') === 'Asia/Dhaka' ? 'selected' : '' ?>>Asia/Dhaka</option>
                  <option value="Europe/London" <?= ($settings['timezone'] ?? '') === 'Europe/London' ? 'selected' : '' ?>>Europe/London</option>
                  <option value="America/New_York" <?= ($settings['timezone'] ?? '') === 'America/New_York' ? 'selected' : '' ?>>America/New_York</option>
                  <option value="UTC" <?= ($settings['timezone'] ?? '') === 'UTC' ? 'selected' : '' ?>>UTC</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Week Start Day</label>
                <select name="week_start_day" id="week_start_day" class="form-select cc-input">
                  <option value="Monday" <?= ($settings['week_start_day'] ?? 'Monday') === 'Monday' ? 'selected' : '' ?>>Monday</option>
                  <option value="Sunday" <?= ($settings['week_start_day'] ?? '') === 'Sunday' ? 'selected' : '' ?>>Sunday</option>
                  <option value="Saturday" <?= ($settings['week_start_day'] ?? '') === 'Saturday' ? 'selected' : '' ?>>Saturday</option>
                </select>
              </div>

              <div class="col-12 pt-2">
                <div class="form-check d-flex align-items-start gap-2">
                  <input type="hidden" name="rtl_layout" value="0">
                  <input class="form-check-input mt-1" type="checkbox" name="rtl_layout" id="rtl_layout" value="1" <?= ($settings['rtl_layout'] ?? '0') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                  <label class="form-check-label cursor-pointer" for="rtl_layout">
                    <span class="fw-semibold text-dark text-xs d-block mb-0">Right-to-Left (RTL) Layout</span>
                    <span class="text-muted" style="font-size: 12px;">Enable RTL text direction for Arabic, Urdu, and similar languages.</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 2: Datetime Formatting -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                  <line x1="16" y1="2" x2="16" y2="6"></line>
                  <line x1="8" y1="2" x2="8" y2="6"></line>
                  <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Datetime Formatting</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Choose how dates and times are displayed across the platform.</p>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Date Format</label>
                <select name="date_format" id="date_format" class="form-select cc-input">
                  <option value="DD/MM/YYYY (e.g. 19/06/2026)" <?= in_array($settings['date_format'] ?? '', ['d/m/Y', 'DD/MM/YYYY', 'DD/MM/YYYY (e.g. 19/06/2026)']) || empty($settings['date_format']) ? 'selected' : '' ?>>DD/MM/YYYY (e.g. 19/06/2026)</option>
                  <option value="MM/DD/YYYY (e.g. 06/19/2026)" <?= in_array($settings['date_format'] ?? '', ['m/d/Y', 'MM/DD/YYYY', 'MM/DD/YYYY (e.g. 06/19/2026)']) ? 'selected' : '' ?>>MM/DD/YYYY (e.g. 06/19/2026)</option>
                  <option value="YYYY-MM-DD (e.g. 2026-06-19)" <?= in_array($settings['date_format'] ?? '', ['Y-m-d', 'YYYY-MM-DD', 'YYYY-MM-DD (e.g. 2026-06-19)']) ? 'selected' : '' ?>>YYYY-MM-DD (e.g. 2026-06-19)</option>
                  <option value="D, d M Y (e.g. Fri, 19 Jun 2026)" <?= in_array($settings['date_format'] ?? '', ['D, d M Y', 'D, d M Y (e.g. Fri, 19 Jun 2026)']) ? 'selected' : '' ?>>D, d M Y (e.g. Fri, 19 Jun 2026)</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Time Format</label>
                <select name="time_format" id="time_format" class="form-select cc-input">
                  <option value="24-hour (e.g. 14:30)" <?= in_array($settings['time_format'] ?? '', ['H:i', '24-hour', '24-hour (e.g. 14:30)']) || empty($settings['time_format']) ? 'selected' : '' ?>>24-hour (e.g. 14:30)</option>
                  <option value="12-hour (e.g. 02:30 PM)" <?= in_array($settings['time_format'] ?? '', ['h:i A', '12-hour', '12-hour (e.g. 02:30 PM)']) ? 'selected' : '' ?>>12-hour (e.g. 02:30 PM)</option>
                </select>
              </div>
            </div>
          </div>

          <!-- Card 3: Currency & Numbers -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="12" y1="1" x2="12" y2="23"></line>
                  <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Currency &amp; Numbers</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Configure monetary display and numeric formatting.</p>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Currency</label>
                <select name="currency" id="currency" class="form-select cc-input">
                  <option value="INR" <?= in_array($settings['currency'] ?? 'INR', ['INR', 'INR — Indian Rupee']) ? 'selected' : '' ?>>INR — Indian Rupee</option>
                  <option value="PKR" <?= in_array($settings['currency'] ?? '', ['PKR', 'PKR — Pakistani Rupee']) ? 'selected' : '' ?>>PKR — Pakistani Rupee</option>
                  <option value="USD" <?= in_array($settings['currency'] ?? '', ['USD', 'USD — US Dollar']) ? 'selected' : '' ?>>USD — US Dollar</option>
                  <option value="EUR" <?= in_array($settings['currency'] ?? '', ['EUR', 'EUR — Euro']) ? 'selected' : '' ?>>EUR — Euro</option>
                  <option value="GBP" <?= in_array($settings['currency'] ?? '', ['GBP', 'GBP — British Pound']) ? 'selected' : '' ?>>GBP — British Pound</option>
                  <option value="AED" <?= in_array($settings['currency'] ?? '', ['AED', 'AED — UAE Dirham']) ? 'selected' : '' ?>>AED — UAE Dirham</option>
                  <option value="SAR" <?= in_array($settings['currency'] ?? '', ['SAR', 'SAR — Saudi Riyal']) ? 'selected' : '' ?>>SAR — Saudi Riyal</option>
                  <option value="BDT" <?= in_array($settings['currency'] ?? '', ['BDT', 'BDT — Bangladeshi Taka']) ? 'selected' : '' ?>>BDT — Bangladeshi Taka</option>
                  <option value="CAD" <?= in_array($settings['currency'] ?? '', ['CAD', 'CAD — Canadian Dollar']) ? 'selected' : '' ?>>CAD — Canadian Dollar</option>
                  <option value="AUD" <?= in_array($settings['currency'] ?? '', ['AUD', 'AUD — Australian Dollar']) ? 'selected' : '' ?>>AUD — Australian Dollar</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Currency Symbol Position</label>
                <select name="currency_symbol_position" id="currency_symbol_position" class="form-select cc-input">
                  <option value="Left — $1,000" <?= in_array($settings['currency_symbol_position'] ?? '', ['left', 'Left — $1,000']) || empty($settings['currency_symbol_position']) ? 'selected' : '' ?>>Left — $1,000</option>
                  <option value="Right — 1,000$" <?= in_array($settings['currency_symbol_position'] ?? '', ['right', 'Right — 1,000$']) ? 'selected' : '' ?>>Right — 1,000$</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Decimal Precision</label>
                <input type="number" name="decimal_precision" id="decimal_precision" class="form-control cc-input" min="0" max="6" value="<?= e($settings['decimal_precision'] ?? '2') ?>">
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Number Format</label>
                <select name="number_format" id="number_format" class="form-select cc-input">
                  <option value="1,00,000.00 (Indian grouping system)" <?= in_array($settings['number_format'] ?? '', ['indian', '1,00,000.00 (Indian grouping system)']) || empty($settings['number_format']) ? 'selected' : '' ?>>1,00,000.00 (Indian grouping system)</option>
                  <option value="100,000.00 (Standard International / Western)" <?= in_array($settings['number_format'] ?? '', ['standard', '100,000.00 (Standard International / Western)']) ? 'selected' : '' ?>>100,000.00 (Standard International / Western)</option>
                  <option value="100.000,00 (European grouping system)" <?= in_array($settings['number_format'] ?? '', ['european', '100.000,00 (European grouping system)']) ? 'selected' : '' ?>>100.000,00 (European grouping system)</option>
                </select>
              </div>
            </div>
          </div>

        </div>

        <!-- 7. Appearance Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'appearance' ? 'active' : 'd-none' ?>" id="pane-appearance">
          
          <!-- Card 1: Theme Mode -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Theme Mode</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Choose the colour scheme for the admin interface.</p>
              </div>
            </div>

            <?php
              $currentThemeMode = $settings['theme_mode'] ?? 'system';
            ?>
            <input type="hidden" name="theme_mode" id="theme_mode_input" value="<?= e($currentThemeMode) ?>">

            <div class="row g-3">
              <!-- Light -->
              <div class="col-md-4">
                <button type="button" class="btn w-100 py-3 cc-theme-tile <?= $currentThemeMode === 'light' ? 'active' : '' ?>" onclick="selectThemeMode('light', this)">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="me-2">
                    <circle cx="12" cy="12" r="4"></circle>
                    <path d="M12 2v2"></path>
                    <path d="M12 20v2"></path>
                    <path d="m4.93 4.93 1.41 1.41"></path>
                    <path d="m17.66 17.66 1.41 1.41"></path>
                    <path d="M2 12h2"></path>
                    <path d="M20 12h2"></path>
                    <path d="m6.34 17.66-1.41 1.41"></path>
                    <path d="m19.07 4.93-1.41 1.41"></path>
                  </svg>
                  <span>Light</span>
                </button>
              </div>

              <!-- Dark -->
              <div class="col-md-4">
                <button type="button" class="btn w-100 py-3 cc-theme-tile <?= $currentThemeMode === 'dark' ? 'active' : '' ?>" onclick="selectThemeMode('dark', this)">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="me-2">
                    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
                  </svg>
                  <span>Dark</span>
                </button>
              </div>

              <!-- System -->
              <div class="col-md-4">
                <button type="button" class="btn w-100 py-3 cc-theme-tile <?= $currentThemeMode === 'system' ? 'active' : '' ?>" onclick="selectThemeMode('system', this)">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="me-2">
                    <rect width="20" height="14" x="2" y="3" rx="2"></rect>
                    <line x1="8" x2="16" y1="21" y2="21"></line>
                    <line x1="12" x2="12" y1="17" y2="21"></line>
                  </svg>
                  <span>System</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Card 2: Accent Color -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="13.5" cy="6.5" r=".5" fill="currentColor"></circle>
                  <circle cx="17.5" cy="10.5" r=".5" fill="currentColor"></circle>
                  <circle cx="8.5" cy="7.5" r=".5" fill="currentColor"></circle>
                  <circle cx="6.5" cy="12.5" r=".5" fill="currentColor"></circle>
                  <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Accent Color</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Choose the primary brand accent color for the school dashboard.</p>
              </div>
            </div>

            <?php
              $currentAccent = $settings['accent_color'] ?? 'Classic';
              $currentColorHex = $settings['theme_color'] ?? '#4f46e5';
              $accents = [
                ['name' => 'Classic', 'color' => '#4f46e5'],
                ['name' => 'Sky Blue', 'color' => '#0284c7'],
                ['name' => 'Sunset', 'color' => '#ea580c'],
                ['name' => 'Gold', 'color' => '#d97706'],
                ['name' => 'Mint', 'color' => '#059669'],
                ['name' => 'Violet', 'color' => '#7c3aed'],
                ['name' => 'Pink', 'color' => '#db2777'],
              ];
            ?>
            <input type="hidden" name="accent_color" id="accent_color_input" value="<?= e($currentAccent) ?>">
            <input type="hidden" name="theme_color" id="theme_color_input" value="<?= e($currentColorHex) ?>">

            <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
              <?php foreach ($accents as $a): ?>
                <button type="button" class="btn cc-accent-tile <?= $currentAccent === $a['name'] ? 'active' : '' ?>" onclick="selectAccentColor('<?= $a['name'] ?>', '<?= $a['color'] ?>', this)">
                  <span class="cc-accent-dot" style="background-color: <?= $a['color'] ?>;"></span>
                  <span class="cc-accent-label"><?= $a['name'] ?></span>
                </button>
              <?php endforeach; ?>

              <!-- Custom Color Picker -->
              <div class="d-inline-flex align-items-center gap-2 p-1 px-2 border rounded-3 bg-light <?= $currentAccent === 'Custom' ? 'border-primary' : '' ?>" id="custom_color_tile" style="border-radius: 10px;">
                <label for="custom_color_input_el" class="small fw-semibold text-secondary mb-0 cursor-pointer d-flex align-items-center gap-2">
                  <input type="color" id="custom_color_input_el" value="<?= e($currentColorHex) ?>" onchange="selectCustomColor(this.value)" style="width: 26px; height: 26px; border: none; border-radius: 6px; cursor: pointer; padding: 0; background: transparent;">
                  <span>Custom Color</span>
                </label>
              </div>
            </div>
          </div>

          <!-- Card 3: Density & Display Scale -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="15 3 21 3 21 9"></polyline>
                  <polyline points="9 21 3 21 3 15"></polyline>
                  <line x1="21" y1="3" x2="14" y2="10"></line>
                  <line x1="3" y1="21" x2="10" y2="14"></line>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Density &amp; Display Scale</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Control the spacing, density, and magnification of UI elements.</p>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Layout Density</label>
                <select name="layout_density" id="layout_density" class="form-select cc-input" onchange="previewAppearance()">
                  <option value="Boxed — constrained max width" <?= in_array($settings['layout_density'] ?? '', ['boxed', 'Boxed — constrained max width']) ? 'selected' : '' ?>>Boxed — constrained max width</option>
                  <option value="Fluid — full screen width" <?= in_array($settings['layout_density'] ?? '', ['fluid', 'Fluid — full screen width']) || empty($settings['layout_density']) ? 'selected' : '' ?>>Fluid — full screen width</option>
                  <option value="Compact" <?= ($settings['layout_density'] ?? '') === 'Compact' ? 'selected' : '' ?>>Compact</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Sidebar Density</label>
                <select name="sidebar_density" id="sidebar_density" class="form-select cc-input" onchange="previewAppearance()">
                  <option value="Comfortable" <?= ($settings['sidebar_density'] ?? 'Comfortable') === 'Comfortable' ? 'selected' : '' ?>>Comfortable</option>
                  <option value="Compact" <?= ($settings['sidebar_density'] ?? '') === 'Compact' ? 'selected' : '' ?>>Compact</option>
                  <option value="Minimal / Icon Only" <?= ($settings['sidebar_density'] ?? '') === 'Minimal / Icon Only' ? 'selected' : '' ?>>Minimal / Icon Only</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Table Density</label>
                <select name="table_density" id="table_density" class="form-select cc-input" onchange="previewAppearance()">
                  <option value="Comfortable" <?= ($settings['table_density'] ?? 'Comfortable') === 'Comfortable' ? 'selected' : '' ?>>Comfortable</option>
                  <option value="Compact" <?= ($settings['table_density'] ?? '') === 'Compact' ? 'selected' : '' ?>>Compact</option>
                  <option value="Spacious" <?= ($settings['table_density'] ?? '') === 'Spacious' ? 'selected' : '' ?>>Spacious</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Display Scale</label>
                <select name="display_scale" id="display_scale" class="form-select cc-input" onchange="previewAppearance()">
                  <option value="100% — Standard (Recommended)" <?= in_array($settings['display_scale'] ?? '', ['100%', '100% — Standard (Recommended)']) || empty($settings['display_scale']) ? 'selected' : '' ?>>100% — Standard (Recommended)</option>
                  <option value="90% — Compact" <?= in_array($settings['display_scale'] ?? '', ['90%', '90% — Compact']) ? 'selected' : '' ?>>90% — Compact</option>
                  <option value="110% — Large" <?= in_array($settings['display_scale'] ?? '', ['110%', '110% — Large']) ? 'selected' : '' ?>>110% — Large</option>
                  <option value="125% — Extra Large" <?= in_array($settings['display_scale'] ?? '', ['125%', '125% — Extra Large']) ? 'selected' : '' ?>>125% — Extra Large</option>
                </select>
              </div>
            </div>
          </div>

          <!-- Card 4: Real-time Live Appearance Preview -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card" id="cc-appearance-live-preview">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <div class="d-flex align-items-center gap-2">
                <span class="cc-accent-dot" id="preview_color_dot" style="background-color: <?= e($currentColorHex) ?>; width: 14px; height: 14px;"></span>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">Real-Time Appearance Preview</h2>
              </div>
              <span class="badge rounded-pill px-3 py-1 fw-bold" id="preview_theme_badge" style="background-color: rgba(79, 70, 229, 0.1); color: var(--sp-primary, #4f46e5); font-size: 11px;">
                <?= strtoupper(e($settings['theme_mode'] ?? 'LIGHT')) ?>
              </span>
            </div>
            <p class="text-muted small mb-3">Changes appear immediately in the interface. Click "Save Settings" to make them permanent across all devices.</p>

            <div class="p-3 rounded-3 border bg-light d-flex flex-wrap align-items-center gap-2">
              <button type="button" class="btn btn-primary btn-sm px-3 fw-semibold shadow-sm">
                Primary Button
              </button>
              <button type="button" class="btn btn-outline-primary btn-sm px-3 fw-semibold">
                Outline Button
              </button>
              <button type="button" class="btn btn-sm btn-danger px-3 fw-semibold">
                Danger Button
              </button>
              <span class="badge rounded-pill fw-semibold px-2 py-1" style="background-color: rgba(79, 70, 229, 0.1); color: var(--sp-primary, #4f46e5);">
                ● Active Tag
              </span>
              <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1">
                ● Status Online
              </span>
              <span class="small fw-semibold text-muted ms-auto" id="preview_color_hex">
                <?= strtoupper(e($currentColorHex)) ?>
              </span>
            </div>
          </div>

        </div>

        <!-- 8. Email Alerts Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'email-alerts' ? 'active' : 'd-none' ?>" id="pane-email-alerts">
          
          <!-- Card 1: Delivery Configuration -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Delivery Configuration</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Choose how CodeClove routes outgoing school communications.</p>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-12">
                <label class="form-label text-xs fw-semibold text-gray-700">Mail Driver</label>
                <select name="mail_driver" id="mail_driver" class="form-select cc-input">
                  <option value="WordPress Native Mail (wp_mail)" <?= ($settings['mail_driver'] ?? 'WordPress Native Mail (wp_mail)') === 'WordPress Native Mail (wp_mail)' ? 'selected' : '' ?>>WordPress Native Mail (wp_mail)</option>
                  <option value="SMTP (External Server)" <?= ($settings['mail_driver'] ?? '') === 'SMTP (External Server)' ? 'selected' : '' ?>>SMTP (External Server)</option>
                  <option value="PHP Mail (mail())" <?= ($settings['mail_driver'] ?? '') === 'PHP Mail (mail())' ? 'selected' : '' ?>>PHP Mail (mail())</option>
                  <option value="SendGrid API" <?= ($settings['mail_driver'] ?? '') === 'SendGrid API' ? 'selected' : '' ?>>SendGrid API</option>
                  <option value="Mailgun API" <?= ($settings['mail_driver'] ?? '') === 'Mailgun API' ? 'selected' : '' ?>>Mailgun API</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Sender Name</label>
                <input type="text" name="mail_from_name" id="mail_from_name" class="form-control cc-input" value="<?= e($settings['mail_from_name'] ?? 'CodeClove School Management Pro') ?>">
              </div>

              <div class="col-md-6">
                <label class="form-label text-xs fw-semibold text-gray-700">Sender Email Address</label>
                <input type="email" name="mail_from_address" id="mail_from_address" class="form-control cc-input" value="<?= e($settings['mail_from_address'] ?? 'admin@test.com') ?>">
              </div>
            </div>
          </div>

          <!-- Card 2: Connection Test -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Connection Test</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Send a real-time diagnostic test email to verify your delivery settings. Save settings before running.</p>
              </div>
            </div>

            <div class="d-flex flex-column flex-sm-row gap-2">
              <input type="email" id="test_email_recipient" class="form-control cc-input flex-grow-1" placeholder="e.g. recipient@gmail.com" value="recipient@gmail.com">
              <button type="button" class="btn text-white fw-semibold px-4 py-2 text-nowrap cc-save-btn" onclick="sendTestEmailDiagnostic()">
                Send Test Email
              </button>
            </div>
            <div id="test_email_feedback" class="mt-2 text-xs d-none"></div>
          </div>

          <!-- Card 3: Notification Templates -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Notification Templates</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Customize subject lines and body text sent automatically per event. Supports template variables.</p>
              </div>
            </div>

            <?php
            $templates = [
              'adm_received' => [
                'title' => 'New Admission Application Received',
                'desc' => 'Sent to school administrators when a new application is submitted online.',
                'recipient' => 'No Recipients',
                'badge_class' => 'bg-light text-muted border',
                'default_subject' => 'New Admission Application Received - {student_name}',
                'default_body' => "Hello Admin,\n\nA new admission application has been submitted online for {student_name}.\nApplication Reference: {application_no}\nGrade: {class_name}\nSubmission Date: {date}\n\nPlease review and process the candidate in the Admissions dashboard.",
                'vars' => ['{student_name}', '{application_no}', '{class_name}', '{date}', '{school_name}']
              ],
              'adm_status_changed' => [
                'title' => 'Admission Application Status Changed',
                'desc' => 'Sent to the applicant/guardian when their admissions pipeline status is updated.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'Admission Application Status Updated - {student_name}',
                'default_body' => "Dear Parent/Guardian,\n\nThe status of your admission application for {student_name} (Ref: {application_no}) has been updated to: {status}.\n\nThank you for choosing {school_name}.",
                'vars' => ['{student_name}', '{application_no}', '{status}', '{school_name}']
              ],
              'payment_receipt' => [
                'title' => 'Payment Recorded Receipt',
                'desc' => 'Sent to the guardian as an electronic receipt when a fee payment is recorded.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'Payment Receipt #{receipt_no} - {school_name}',
                'default_body' => "Dear {guardian_name},\n\nWe have successfully received your payment of {amount} for {student_name}.\nReceipt Number: {receipt_no}\nPayment Date: {date}\nPayment Method: {payment_method}\n\nThank you for your prompt payment.",
                'vars' => ['{guardian_name}', '{student_name}', '{amount}', '{receipt_no}', '{date}', '{payment_method}']
              ],
              'attendance_alert' => [
                'title' => 'Attendance Alert Notification',
                'desc' => 'Sent to the guardian when a student is marked absent or other statuses.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'Attendance Alert: {student_name} marked {attendance_status}',
                'default_body' => "Dear {guardian_name},\n\nPlease be informed that {student_name} was marked {attendance_status} on {date}.\n\nIf this was unexpected, please contact the school administration.",
                'vars' => ['{guardian_name}', '{student_name}', '{attendance_status}', '{date}', '{school_name}']
              ],
              'fee_reminder' => [
                'title' => 'Fee Payment Reminder',
                'desc' => 'Sent to the guardian when outstanding fee payment reminders are sent.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'Friendly Fee Payment Reminder - {student_name}',
                'default_body' => "Dear {guardian_name},\n\nThis is a friendly reminder that an outstanding fee balance of {amount} is pending for {student_name}.\nDue Date: {due_date}\n\nPlease arrange payment at your earliest convenience.",
                'vars' => ['{guardian_name}', '{student_name}', '{amount}', '{due_date}']
              ],
              'invoice_issued' => [
                'title' => 'New Invoice Issued',
                'desc' => 'Sent to the guardian immediately when a new fee bill/invoice is generated for the student.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'New Invoice #{invoice_no} Issued for {student_name}',
                'default_body' => "Dear {guardian_name},\n\nA new fee invoice #{invoice_no} amounting to {amount} has been generated for {student_name}.\nDue Date: {due_date}\n\nYou can view and pay your invoice online through the Parent Portal.",
                'vars' => ['{guardian_name}', '{student_name}', '{invoice_no}', '{amount}', '{due_date}']
              ],
              'fee_overdue' => [
                'title' => 'Overdue Fee Notice',
                'desc' => 'Sent to the guardian when a bill passes its due date with an outstanding balance.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'URGENT: Overdue Fee Notice for {student_name}',
                'default_body' => "Dear {guardian_name},\n\nOur records show that invoice #{invoice_no} for {student_name} (Amount: {amount}) is now overdue since {due_date}.\n\nPlease clear the outstanding dues immediately to avoid late fee penalties.",
                'vars' => ['{guardian_name}', '{student_name}', '{invoice_no}', '{amount}', '{due_date}']
              ],
              'payment_cancelled' => [
                'title' => 'Payment Cancelled / Reversed',
                'desc' => 'Sent to the guardian when a payment transaction is cancelled, reversed, or refunded.',
                'recipient' => 'Guardian',
                'badge_class' => 'cc-recipient-badge',
                'default_subject' => 'Payment Cancellation Notice - Receipt #{receipt_no}',
                'default_body' => "Dear {guardian_name},\n\nThis is to notify you that payment transaction #{receipt_no} of {amount} for {student_name} has been cancelled / reversed.\nReason: {cancellation_reason}\n\nPlease contact accounts if you have questions.",
                'vars' => ['{guardian_name}', '{student_name}', '{receipt_no}', '{amount}', '{cancellation_reason}']
              ]
            ];
            ?>

            <div class="d-flex flex-column gap-2">
              <?php foreach ($templates as $tKey => $tpl): ?>
                <?php
                  $subjVal = $settings['email_tpl_' . $tKey . '_subject'] ?? $tpl['default_subject'];
                  $bodyVal = $settings['email_tpl_' . $tKey . '_body'] ?? $tpl['default_body'];
                ?>
                <div class="border rounded-3 p-3 bg-white cc-template-item">
                  <div class="d-flex justify-content-between align-items-center cursor-pointer" onclick="toggleTemplateCollapse('<?= $tKey ?>')">
                    <div class="d-flex align-items-center gap-2">
                      <span class="cc-dot-indicator"></span>
                      <div>
                        <div class="fw-semibold text-dark text-xs" style="font-size: 13.5px;"><?= e($tpl['title']) ?></div>
                        <div class="text-muted" style="font-size: 12px;"><?= e($tpl['desc']) ?></div>
                      </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                      <span class="badge <?= $tpl['badge_class'] ?>"><?= e($tpl['recipient']) ?></span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </div>
                  </div>

                  <div id="tpl_collapse_<?= $tKey ?>" class="d-none pt-3 mt-3 border-top">
                    <div class="mb-3">
                      <label class="form-label text-xs fw-semibold text-gray-700">Subject Line</label>
                      <input type="text" name="email_tpl_<?= $tKey ?>_subject" class="form-control form-control-sm cc-input" value="<?= e($subjVal) ?>">
                    </div>
                    <div class="mb-2">
                      <label class="form-label text-xs fw-semibold text-gray-700">Body Template</label>
                      <textarea name="email_tpl_<?= $tKey ?>_body" class="form-control form-control-sm cc-input font-monospace" rows="4" style="font-size: 12.5px;"><?= e($bodyVal) ?></textarea>
                    </div>
                    <div class="d-flex flex-wrap gap-1 align-items-center">
                      <span class="text-muted me-1" style="font-size: 11px;">Variables:</span>
                      <?php foreach ($tpl['vars'] as $v): ?>
                        <span class="badge bg-light text-primary border font-monospace" style="font-size: 11px;"><?= e($v) ?></span>
                      <?php endforeach; ?>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

          </div>

        </div>

        <!-- 9. SMS Alerts Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'sms-alerts' ? 'active' : 'd-none' ?>" id="pane-sms-alerts">
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                  <line x1="12" y1="18" x2="12.01" y2="18"></line>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">SMS Delivery Configuration</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Configure SMS delivery options and API credentials.</p>
              </div>
            </div>

            <div class="pt-2 border-top">
              <div class="form-check d-flex align-items-start gap-2 pt-2">
                <input type="hidden" name="enable_sms_notifications" value="0">
                <input class="form-check-input mt-1" type="checkbox" name="enable_sms_notifications" id="enable_sms_notifications" value="1" <?= ($settings['enable_sms_notifications'] ?? '0') === '1' ? 'checked' : '' ?> onchange="toggleSmsFields(this.checked)" style="cursor: pointer; width: 17px; height: 17px;">
                <label class="form-check-label cursor-pointer" for="enable_sms_notifications">
                  <span class="fw-semibold text-dark text-xs d-block mb-0">Enable SMS Notifications</span>
                  <span class="text-muted" style="font-size: 12px;">Allows CodeClove to send real-time text message alerts to guardians.</span>
                </label>
              </div>

              <!-- Provider Credentials (collapsible based on checkbox) -->
              <div id="sms_provider_settings_container" class="<?= ($settings['enable_sms_notifications'] ?? '0') === '1' ? '' : 'd-none' ?> mt-4 pt-3 border-top">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label text-xs fw-semibold text-gray-700">SMS Gateway Provider</label>
                    <select name="sms_provider" id="sms_provider" class="form-select cc-input">
                      <option value="Twilio" <?= ($settings['sms_provider'] ?? 'Twilio') === 'Twilio' ? 'selected' : '' ?>>Twilio Cloud API</option>
                      <option value="MessageBird" <?= ($settings['sms_provider'] ?? '') === 'MessageBird' ? 'selected' : '' ?>>MessageBird</option>
                      <option value="AwsSns" <?= ($settings['sms_provider'] ?? '') === 'AwsSns' ? 'selected' : '' ?>>AWS SNS SMS</option>
                      <option value="LocalSMS" <?= ($settings['sms_provider'] ?? '') === 'LocalSMS' ? 'selected' : '' ?>>Local Teleco HTTP Gateway</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-xs fw-semibold text-gray-700">Sender ID / Phone Number</label>
                    <input type="text" name="sms_sender_id" id="sms_sender_id" class="form-control cc-input" value="<?= e($settings['sms_sender_id'] ?? 'CODECLOVE') ?>" placeholder="e.g. CODECLOVE or +1234567890">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-xs fw-semibold text-gray-700">Account SID / API Key</label>
                    <input type="text" name="sms_account_sid" id="sms_account_sid" class="form-control cc-input" value="<?= e($settings['sms_account_sid'] ?? '') ?>" placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxx">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-xs fw-semibold text-gray-700">Auth Token / API Secret</label>
                    <input type="password" name="sms_auth_token" id="sms_auth_token" class="form-control cc-input" value="<?= e($settings['sms_auth_token'] ?? '') ?>" placeholder="••••••••••••••••••••••••">
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        <!-- 10. In-App Alerts Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'in-app-alerts' ? 'active' : 'd-none' ?>" id="pane-in-app-alerts">
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Global In-App Notifications</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Choose which system events trigger persistent in-app notifications for administrators and staff by default.</p>
              </div>
            </div>

            <input type="hidden" name="in_app_sound" value="<?= e($settings['in_app_sound'] ?? '1') ?>">

            <div class="pt-2 border-top">
              <div class="row g-4 pt-2">
                <!-- Column 1 -->
                <div class="col-md-6 d-flex flex-column gap-4">
                  <!-- 1. Admission Submitted -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_admission_submitted" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_admission_submitted" id="inapp_admission_submitted" value="1" <?= ($settings['inapp_admission_submitted'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_admission_submitted">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Admission Submitted</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when a new student application is received.</span>
                    </label>
                  </div>

                  <!-- 2. Invoice Issued -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_invoice_issued" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_invoice_issued" id="inapp_invoice_issued" value="1" <?= ($settings['inapp_invoice_issued'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_invoice_issued">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Invoice Issued</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when a new fee invoice is generated.</span>
                    </label>
                  </div>

                  <!-- 3. Invoice Overdue -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_invoice_overdue" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_invoice_overdue" id="inapp_invoice_overdue" value="1" <?= ($settings['inapp_invoice_overdue'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_invoice_overdue">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Invoice Overdue</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when bills pass their due date.</span>
                    </label>
                  </div>
                </div>

                <!-- Column 2 -->
                <div class="col-md-6 d-flex flex-column gap-4">
                  <!-- 4. Admission Status Updated -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_admission_status_updated" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_admission_status_updated" id="inapp_admission_status_updated" value="1" <?= ($settings['inapp_admission_status_updated'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_admission_status_updated">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Admission Status Updated</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when an application status changes.</span>
                    </label>
                  </div>

                  <!-- 5. Payment Received -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_payment_received" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_payment_received" id="inapp_payment_received" value="1" <?= ($settings['inapp_payment_received'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_payment_received">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Payment Received</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when a fee payment receipt is recorded.</span>
                    </label>
                  </div>

                  <!-- 6. Attendance Taken -->
                  <div class="form-check d-flex align-items-start gap-2">
                    <input type="hidden" name="inapp_attendance_taken" value="0">
                    <input class="form-check-input mt-1" type="checkbox" name="inapp_attendance_taken" id="inapp_attendance_taken" value="1" <?= ($settings['inapp_attendance_taken'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                    <label class="form-check-label cursor-pointer" for="inapp_attendance_taken">
                      <span class="fw-semibold text-dark text-xs d-block mb-0">Attendance Taken</span>
                      <span class="text-muted" style="font-size: 12px;">Notify when daily attendance records are saved.</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        <!-- 11. Shortcodes Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'shortcodes' ? 'active' : 'd-none' ?>" id="pane-shortcodes">
          
          <!-- Card 1: Student & Parent Portal -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="18" height="18" x="3" y="3" rx="2"></rect>
                  <path d="M9 3v18"></path>
                  <path d="M14 9h5"></path>
                  <path d="M14 15h5"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Student &amp; Parent Portal</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Public shortcode for the dedicated student and parent self-service portal.</p>
              </div>
            </div>

            <!-- Item: Student & Parent Portal Application -->
            <div>
              <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Student &amp; Parent Portal Application</h3>
              <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Embeds the complete portal application. Guests see an authentication login form; authenticated students and parents access their dashboard, attendance, timetable, academic curriculum, fee statements, and notices.</p>
              <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                <code class="cc-shortcode-code">[codeclove_portal]</code>
                <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_portal]', this)" title="Copy Shortcode">
                  <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <!-- Card 2: Student Admissions & Inquiries -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="18" height="18" x="3" y="3" rx="2"></rect>
                  <path d="M7 7h10"></path>
                  <path d="M7 12h10"></path>
                  <path d="M7 17h6"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Student Admissions &amp; Inquiries</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Public shortcodes for student admissions, general inquiries, and applicant status tracking.</p>
              </div>
            </div>

            <div class="d-flex flex-column gap-4">
              <!-- Item 1: Unified Admission Application Form -->
              <div>
                <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Unified Admission Application Form</h3>
                <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Comprehensive application form with student demographics, academic placement, parent/guardian details, and address.</p>
                <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                  <code class="cc-shortcode-code">[codeclove_admission_form]</code>
                  <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_admission_form]', this)" title="Copy Shortcode">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                    </svg>
                  </button>
                </div>
              </div>

              <!-- Item 2: Admission Inquiry Form -->
              <div>
                <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Admission Inquiry Form</h3>
                <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Compact inquiry from for prospective families to ask questions regarding curriculum, fees, tours, or enrollment.</p>
                <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                  <code class="cc-shortcode-code">[codeclove_inquiry_form]</code>
                  <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_inquiry_form]', this)" title="Copy Shortcode">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                    </svg>
                  </button>
                </div>
              </div>

              <!-- Item 3: Student Application Status Tracker -->
              <div>
                <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Student Application Status Tracker</h3>
                <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Allows applicants and parents to check their admission pipeline status with reference number and date of birth.</p>
                <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                  <code class="cc-shortcode-code">[codeclove_application_status]</code>
                  <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_application_status]', this)" title="Copy Shortcode">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 3: Careers & Staff Recruitment -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="18" height="18" x="3" y="3" rx="2"></rect>
                  <path d="M9 3v3a3 3 0 0 0 6 0V3"></path>
                  <circle cx="12" cy="12" r="2"></circle>
                  <path d="M8 18a4 4 0 0 1 8 0"></path>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Careers &amp; Staff Recruitment</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Public shortcodes for educator and administrative employment applications and candidate status tracking.</p>
              </div>
            </div>

            <div class="d-flex flex-column gap-4">
              <!-- Item 1: Staff & Faculty Employment Application -->
              <div>
                <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Staff &amp; Faculty Employment Application</h3>
                <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Online employment application capturing desired position, department, teaching experience, qualifications, and cover letter.</p>
                <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                  <code class="cc-shortcode-code">[codeclove_staff_application_form]</code>
                  <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_staff_application_form]', this)" title="Copy Shortcode">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                    </svg>
                  </button>
                </div>
              </div>

              <!-- Item 2: Staff Application Status Lookup -->
              <div>
                <h3 class="fw-semibold text-dark mb-1" style="font-size: 13.5px;">Staff Application Status Lookup</h3>
                <p class="text-muted mb-2" style="font-size: 12.5px; line-height: 1.5;">Allows job candidates to track their application review status and interview progress using reference number and email.</p>
                <div class="cc-shortcode-strip d-flex align-items-center justify-content-between">
                  <code class="cc-shortcode-code">[codeclove_staff_application_status]</code>
                  <button type="button" class="btn btn-sm cc-copy-action-btn p-1" onclick="copyShortcode('[codeclove_staff_application_status]', this)" title="Copy Shortcode">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                      <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- 12. System Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'system' ? 'active' : 'd-none' ?>" id="pane-system">
          
          <!-- Enterprise Administration & Security Hub Banner -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-primary text-white">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="badge bg-white text-primary fw-bold text-uppercase" style="font-size: 11px;">Advanced Security &amp; Diagnostics</span>
                </div>
                <h3 class="h5 fw-bold mb-1">Institutional Security, Monitoring &amp; Recovery Hub</h3>
                <p class="mb-0 text-white-50 small">Manage password complexity, account lockout controls, real-time database telemetry, and encrypted disaster recovery snapshots.</p>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <a href="<?= e(url('admin/security')) ?>" class="btn btn-light btn-sm fw-semibold shadow-sm text-primary">
                  <i class="bi bi-shield-lock me-1"></i> Security Center
                </a>
                <a href="<?= e(url('admin/system/health')) ?>" class="btn btn-outline-light btn-sm fw-semibold shadow-sm">
                  <i class="bi bi-heart-pulse me-1"></i> Health Telemetry
                </a>
                <a href="<?= e(url('admin/system/backups')) ?>" class="btn btn-outline-light btn-sm fw-semibold shadow-sm">
                  <i class="bi bi-cloud-arrow-down me-1"></i> Backup Vault
                </a>
              </div>
            </div>
          </div>
          
          <!-- Card 1: Technical System Indicators -->
          <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="20" height="8" x="2" y="2" rx="2" ry="2"></rect>
                  <rect width="20" height="8" x="2" y="14" rx="2" ry="2"></rect>
                  <line x1="6" y1="6" x2="6.01" y2="6"></line>
                  <line x1="6" y1="18" x2="6.01" y2="18"></line>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Technical System Indicators</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Internal plugin metrics and real-time server telemetry.</p>
              </div>
            </div>

            <div class="row g-3">
              <!-- Metric 1: Database Version -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">DATABASE VERSION</div>
                  <div class="cc-metric-value"><?= e($settings['database_version'] ?? '1.0.21') ?></div>
                </div>
              </div>
              <!-- Metric 2: Plugin Version -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">PLUGIN VERSION</div>
                  <div class="cc-metric-value"><?= e($settings['plugin_version'] ?? '1.0.14') ?></div>
                </div>
              </div>
              <!-- Metric 3: REST API State -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">REST API STATE</div>
                  <div class="cc-metric-value">
                    <span class="badge bg-success-subtle text-success border border-success-subtle d-inline-flex align-items-center gap-1 px-2 py-1" style="font-size: 11.5px; border-radius: 20px;">
                      <span class="cc-dot-indicator" style="background-color: #10b981; width: 6px; height: 6px;"></span>
                      Online
                    </span>
                  </div>
                </div>
              </div>
              <!-- Metric 4: PHP Environment -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">PHP ENVIRONMENT</div>
                  <div class="cc-metric-value">PHP <?= PHP_VERSION ?> (<?= ini_get('memory_limit') ?: '1024M' ?>)</div>
                </div>
              </div>
              <!-- Metric 5: Mail Delivery Driver -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">MAIL DELIVERY DRIVER</div>
                  <div class="cc-metric-value"><?= e(strtoupper($settings['mail_driver'] ?? 'WP_MAIL')) ?></div>
                </div>
              </div>
              <!-- Metric 6: Active Preset -->
              <div class="col-md-4">
                <div class="cc-metric-tile">
                  <div class="cc-metric-label">ACTIVE PRESET</div>
                  <div class="cc-metric-value"><?= e($school['country_preset'] ?? $settings['academic_preset'] ?? 'India (IN)') ?></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Card 2: Diagnostic Maintenance Tools -->
          <div class="card border-0 shadow-sm rounded-3 p-4 bg-white cc-settings-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="cc-card-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="4" x2="20" y1="21" y2="21"></line>
                  <line x1="4" x2="20" y1="14" y2="14"></line>
                  <line x1="4" x2="20" y1="7" y2="7"></line>
                  <circle cx="12" cy="7" r="2"></circle>
                  <circle cx="8" cy="14" r="2"></circle>
                  <circle cx="16" cy="21" r="2"></circle>
                </svg>
              </div>
              <div>
                <h2 class="h5 fw-bold text-dark mb-0" style="font-size: 16px;">Diagnostic Maintenance Tools</h2>
                <p class="text-muted mb-0" style="font-size: 13px;">Purge temporary database caches, download diagnostic snapshots, and control server logging.</p>
              </div>
            </div>

            <!-- Action Buttons Row -->
            <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
              <button type="button" class="btn btn-outline-secondary cc-system-tool-btn d-inline-flex align-items-center gap-2" onclick="purgeTransients(this)">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
                  <path d="M3 3v5h5"></path>
                  <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path>
                  <path d="M16 21h5v-5"></path>
                </svg>
                <span>Purge Options Transients</span>
              </button>

              <button type="button" class="btn btn-outline-secondary cc-system-tool-btn d-inline-flex align-items-center gap-2" onclick="exportDiagnostics()">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" x2="12" y1="15" y2="3"></line>
                </svg>
                <span>Export Diagnostics</span>
              </button>

              <button type="button" class="btn btn-outline-secondary cc-system-tool-btn d-inline-flex align-items-center gap-2" onclick="copySupportSummary(this)">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
                </svg>
                <span>Copy Support Summary</span>
              </button>
            </div>

            <!-- Feedback Alert -->
            <div id="system_tool_feedback" class="alert alert-success d-none py-2 px-3 text-xs mb-4" role="alert"></div>

            <hr class="my-4 text-muted opacity-25">

            <!-- Bottom Row: Enable Debug Logging & Audit Log Retention -->
            <div class="row g-4">
              <!-- Left: Enable Debug Logging -->
              <div class="col-md-6">
                <div class="form-check d-flex align-items-start gap-2 ps-0 mb-0">
                  <input class="form-check-input mt-1" type="checkbox" name="debug_logging" id="debug_logging" value="1" <?= ($settings['debug_logging'] ?? '1') === '1' ? 'checked' : '' ?> style="cursor: pointer; width: 17px; height: 17px;">
                  <div>
                    <label class="form-check-label fw-semibold text-dark cursor-pointer mb-1" for="debug_logging" style="font-size: 13.5px;">
                      Enable Debug Logging
                    </label>
                    <p class="text-muted mb-0" style="font-size: 12px; line-height: 1.5;">
                      Writes detailed API execution traces and database errors to server logs. Keep disabled during normal operation to conserve disk space.
                    </p>
                  </div>
                </div>
              </div>

              <!-- Right: Audit Log Retention -->
              <div class="col-md-6">
                <label class="form-label fw-semibold text-dark mb-2" for="audit_log_retention" style="font-size: 13.5px;">
                  Audit Log Retention (Days)
                </label>
                <input type="number" name="audit_log_retention" id="audit_log_retention" class="form-control cc-input" style="max-width: 160px;" value="<?= e($settings['audit_log_retention'] ?? '0') ?>" min="0">
                <p class="text-muted mt-2 mb-0" style="font-size: 12px; line-height: 1.5;">
                  Number of days to keep audit logs. Enter 0 to retain logs indefinitely. Pruning runs daily in the background.
                </p>
              </div>
            </div>
          </div>
        </div>

        <!-- 13. Activity Log Tab -->
        <div class="cc-tab-content-pane <?= $activeTab === 'activity-log' ? 'active' : 'd-none' ?>" id="pane-activity-log">
          
          <!-- Filter Controls Bar -->
          <div class="row g-3 mb-4">
            <div class="col-md-4">
              <label class="form-label text-xs fw-semibold text-gray-700 mb-1">Search</label>
              <div class="position-relative">
                <span class="position-absolute top-50 start-0 translate-middle-y ps-3 text-muted" style="pointer-events: none;">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg>
                </span>
                <input type="text" id="audit-search-input" class="form-control cc-input ps-5" placeholder="Search action or event..." oninput="filterAuditLogs()">
              </div>
            </div>

            <div class="col-md-3">
              <label class="form-label text-xs fw-semibold text-gray-700 mb-1">Category</label>
              <select id="audit-category-select" class="form-select cc-input" onchange="filterAuditLogs()">
                <option value="">All categories</option>
                <option value="System">System</option>
                <option value="Students">Students</option>
                <option value="Finance">Finance</option>
                <option value="Staff">Staff</option>
                <option value="Auth">Auth</option>
                <option value="Teachers">Teachers</option>
                <option value="Attendance">Attendance</option>
                <option value="Exams">Exams</option>
                <option value="Settings">Settings</option>
              </select>
            </div>

            <div class="col-md-2 col-6">
              <label class="form-label text-xs fw-semibold text-gray-700 mb-1">From</label>
              <input type="date" id="audit-date-from" class="form-control cc-input" placeholder="Start date" onchange="filterAuditLogs()">
            </div>

            <div class="col-md-3 col-6">
              <label class="form-label text-xs fw-semibold text-gray-700 mb-1">To</label>
              <input type="date" id="audit-date-to" class="form-control cc-input" placeholder="End date" onchange="filterAuditLogs()">
            </div>
          </div>

          <!-- Audit Table Card -->
          <div class="card border-0 shadow-sm rounded-3 bg-white cc-settings-card overflow-hidden">
            <div class="table-responsive">
              <table class="table table-hover align-middle mb-0 cc-audit-table" id="audit-table">
                <thead>
                  <tr class="bg-light border-bottom">
                    <th class="ps-4 py-3 text-uppercase text-secondary fw-semibold" style="font-size: 11px; letter-spacing: 0.5px; width: 38%;">EVENT</th>
                    <th class="py-3 text-uppercase text-secondary fw-semibold" style="font-size: 11px; letter-spacing: 0.5px; width: 18%;">CATEGORY</th>
                    <th class="py-3 text-uppercase text-secondary fw-semibold" style="font-size: 11px; letter-spacing: 0.5px; width: 24%;">ACTOR</th>
                    <th class="pe-4 py-3 text-uppercase text-secondary fw-semibold" style="font-size: 11px; letter-spacing: 0.5px; width: 20%;">DATE &amp; TIME</th>
                  </tr>
                </thead>
                <tbody id="audit-table-body">
                  <?php if (empty($auditLogs)): ?>
                    <tr id="empty-audit-row">
                      <td colspan="4" class="text-center py-5 text-muted">No activity records recorded yet.</td>
                    </tr>
                  <?php else: ?>
                    <?php foreach ($auditLogs as $idx => $log): 
                      $rawAction = $log['action'] ?? 'status_change';
                      $actionTitle = ($rawAction === 'status_change') ? 'Status updated' : ucwords(str_replace(['.', '_'], ' ', $rawAction));
                      $actionKey = str_replace('.', '_', strtolower($rawAction));
                      $category = ucfirst($log['module'] ?? 'System');
                      $userName = (!empty($log['user_name']) && $log['user_name'] !== 'Zubair Ghfoor') ? $log['user_name'] : 'Administrator';
                      $userInitial = strtoupper(substr($userName, 0, 1));
                      $dateFormatted = date('d/m/Y H:i', strtotime($log['created_at'] ?? 'now'));
                      $rawDate = date('Y-m-d', strtotime($log['created_at'] ?? 'now'));
                    ?>
                      <tr class="audit-record-row" data-action="<?= e(strtolower($actionTitle . ' ' . $actionKey)) ?>" data-category="<?= e($category) ?>" data-actor="<?= e(strtolower($userName)) ?>" data-date="<?= e($rawDate) ?>">
                        <td class="ps-4 py-3">
                          <div class="d-flex align-items-center gap-3">
                            <div class="cc-audit-icon-box">
                              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                <polyline points="10 9 9 9 8 9"></polyline>
                              </svg>
                            </div>
                            <div>
                              <div class="fw-semibold text-dark mb-0" style="font-size: 13px;"><?= e($actionTitle) ?></div>
                              <div class="text-muted font-monospace" style="font-size: 11px;"><?= e($actionKey) ?></div>
                            </div>
                          </div>
                        </td>
                        <td class="py-3">
                          <span class="badge bg-light text-secondary border px-2 py-1 fw-medium" style="font-size: 11.5px; border-radius: 4px;">
                            <?= e($category) ?>
                          </span>
                        </td>
                        <td class="py-3">
                          <div class="d-inline-flex align-items-center gap-2">
                            <span class="cc-actor-avatar"><?= e($userInitial) ?></span>
                            <span class="text-dark fw-normal" style="font-size: 13px;"><?= e($userName) ?></span>
                          </div>
                        </td>
                        <td class="pe-4 py-3 text-muted" style="font-size: 12.5px;">
                          <?= e($dateFormatted) ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

            <!-- Table Footer with Pagination Controls -->
            <div class="d-flex flex-wrap align-items-center justify-content-between p-3 border-top bg-white cc-audit-footer" style="font-size: 12.5px;">
              <div class="text-muted" id="audit-pagination-info">
                Showing 1 to <?= min(25, count($auditLogs)) ?> of <?= count($auditLogs) ?> records
              </div>

              <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2">
                  <span class="text-muted">Rows:</span>
                  <select id="audit-rows-per-page" class="form-select form-select-sm cc-input py-1 px-2" style="width: 70px; font-size: 12px;" onchange="changeAuditRowsPerPage()">
                    <option value="10">10</option>
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select>
                </div>

                <div class="text-muted fw-medium" id="audit-page-indicator">
                  Page 1 of <?= max(1, ceil(count($auditLogs) / 25)) ?>
                </div>

                <div class="btn-group btn-group-sm">
                  <button type="button" class="btn btn-outline-secondary cc-page-btn" id="audit-first-page-btn" onclick="gotoAuditPage(1)" title="First Page">&laquo;</button>
                  <button type="button" class="btn btn-outline-secondary cc-page-btn" id="audit-prev-page-btn" onclick="prevAuditPage()" title="Previous Page">&lsaquo;</button>
                  <button type="button" class="btn btn-outline-secondary cc-page-btn" id="audit-next-page-btn" onclick="nextAuditPage()" title="Next Page">&rsaquo;</button>
                  <button type="button" class="btn btn-outline-secondary cc-page-btn" id="audit-last-page-btn" onclick="gotoAuditLastPage()" title="Last Page">&raquo;</button>
                </div>
              </div>
            </div>

          </div>
        </div>

    <!-- Floating Unsaved Settings Changes Bar -->
    <div id="cc-floating-unsaved-bar" class="cc-unsaved-bar d-none">
      <div class="d-flex align-items-center gap-3">
        <span class="d-inline-flex align-items-center gap-2 small fw-medium cc-unsaved-text">
          <span class="cc-unsaved-dot"></span>
          Unsaved settings changes
        </span>
        <div class="d-flex align-items-center gap-2">
          <button type="button" class="btn btn-sm cc-discard-btn" onclick="discardSettingsChanges()">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
            Discard
          </button>
          <button type="submit" form="ccSettingsForm" class="btn btn-sm cc-save-btn text-white fw-semibold px-3 shadow-sm">
            Save Settings
          </button>
        </div>
      </div>
    </div>

  </form>
</div>

<style>
/* CodeClove Settings Cockpit Specific Styles */
.cc-save-btn {
  background-color: var(--sp-primary, #4f46e5) !important;
  border-radius: 8px;
  font-size: 13.5px;
  box-shadow: 0 1px 2px rgba(var(--sp-primary-rgb), 0.2);
  transition: all 0.15s ease-in-out;
  border: none;
}
.cc-save-btn:hover {
  filter: brightness(0.92);
  transform: translateY(-1px);
}

.cc-nav-card {
  border: 1px solid #e5e7eb !important;
}

.cc-vertical-tabs {
  gap: 3px;
}

.cc-tab-link {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  font-size: 13.5px;
  color: #4b5563;
  border: none;
  background: transparent;
  border-radius: 8px;
  width: 100%;
  text-align: left;
  transition: background-color 0.15s ease, color 0.15s ease;
  cursor: pointer;
}

.cc-tab-link:hover {
  background-color: #f9fafb;
  color: #111827;
}

.cc-tab-link.active {
  background-color: var(--sp-primary-light, rgba(var(--sp-primary-rgb), 0.1)) !important;
  color: var(--sp-primary, #4f46e5) !important;
  font-weight: 600;
}

.cc-tab-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  color: inherit;
  opacity: 0.85;
}

.cc-tab-link.active .cc-tab-icon {
  color: var(--sp-primary, #4f46e5) !important;
  stroke: var(--sp-primary, #4f46e5) !important;
  opacity: 1;
}

.cc-settings-card {
  border: 1px solid #e5e7eb !important;
}

.cc-card-icon-box {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background-color: var(--sp-primary-light, rgba(var(--sp-primary-rgb), 0.1)) !important;
  color: var(--sp-primary, #4f46e5) !important;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.cc-card-icon-box svg {
  stroke: var(--sp-primary, #4f46e5) !important;
}

.cc-input {
  border: 1px solid #d1d5db;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 13.5px;
  color: #1f2937;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

.cc-input:focus {
  border-color: var(--sp-primary, #4f46e5) !important;
  box-shadow: 0 0 0 3px rgba(var(--sp-primary-rgb), 0.15) !important;
  outline: none;
}

/* Floating Unsaved Changes Bar */
.cc-unsaved-bar {
  position: fixed;
  bottom: 24px;
  right: 28px;
  z-index: 1060;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 8px 14px;
  box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.06);
  animation: slideInUp 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
.cc-unsaved-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: var(--sp-primary, #f59e0b);
  display: inline-block;
}
.cc-unsaved-text {
  color: #1e293b;
  font-size: 13px;
}
.cc-discard-btn {
  color: #64748b;
  background: transparent;
  border: none;
  font-size: 12.5px;
  font-weight: 500;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  border-radius: 6px;
}
.cc-discard-btn:hover {
  color: #0f172a;
  background: #f1f5f9;
}

/* Comprehensive Dark Mode Rules for Settings (Matches CodeClove Screenshots) */
[data-theme="dark"] .cc-settings-wrapper {
  color: #f8fafc;
}
[data-theme="dark"] .cc-nav-card,
[data-theme="dark"] .cc-settings-card,
[data-theme="dark"] .card {
  background-color: #161922 !important;
  border-color: #222634 !important;
  color: #f8fafc !important;
  box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.4) !important;
}
[data-theme="dark"] .cc-tab-link {
  color: #8e99a8;
  background: transparent;
}
[data-theme="dark"] .cc-tab-link:hover {
  background-color: rgba(255, 255, 255, 0.04);
  color: #ffffff;
}
[data-theme="dark"] .cc-tab-link.active {
  background-color: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.12) !important;
  border: 1px solid rgba(var(--sp-primary-rgb, 79, 70, 229), 0.35) !important;
  color: #ffffff !important;
}
[data-theme="dark"] .cc-tab-link.active .cc-tab-icon {
  color: var(--sp-primary, #6366f1) !important;
  stroke: var(--sp-primary, #6366f1) !important;
}
[data-theme="dark"] .cc-input,
[data-theme="dark"] .form-control,
[data-theme="dark"] .form-select {
  background-color: #11141d !important;
  border-color: #222634 !important;
  color: #f8fafc !important;
}
[data-theme="dark"] .form-select {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%238e99a8' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e") !important;
}
[data-theme="dark"] .cc-input:focus,
[data-theme="dark"] .form-control:focus,
[data-theme="dark"] .form-select:focus {
  border-color: var(--sp-primary, #6366f1) !important;
  box-shadow: 0 0 0 3px rgba(var(--sp-primary-rgb, 79, 70, 229), 0.25) !important;
}
[data-theme="dark"] .cc-media-box {
  background-color: #11141d;
  border-color: #222634;
}
[data-theme="dark"] .cc-theme-tile {
  background-color: #11141d;
  border-color: #1f2432;
  color: #8e99a8;
}
[data-theme="dark"] .cc-theme-tile:hover {
  background-color: #161922;
  border-color: #2d3345;
  color: #ffffff;
}
[data-theme="dark"] .cc-theme-tile.active {
  border: 1.5px solid var(--sp-primary, #6366f1) !important;
  color: #ffffff !important;
  background-color: #11141d !important;
  box-shadow: 0 0 12px rgba(var(--sp-primary-rgb, 79, 70, 229), 0.2) !important;
}
[data-theme="dark"] .cc-theme-tile.active svg {
  stroke: var(--sp-primary, #6366f1) !important;
}
[data-theme="dark"] .cc-accent-tile {
  background-color: #11141d;
  border-color: #1f2432;
  color: #8e99a8;
}
[data-theme="dark"] .cc-accent-tile:hover {
  background-color: #161922;
  border-color: #2d3345;
}
[data-theme="dark"] .cc-accent-tile.active {
  border: 1.5px solid var(--sp-primary, #6366f1) !important;
  box-shadow: 0 0 12px rgba(var(--sp-primary-rgb, 79, 70, 229), 0.25) !important;
  background-color: #11141d !important;
  color: #ffffff !important;
}
[data-theme="dark"] .cc-accent-tile.active .cc-accent-label {
  color: #ffffff !important;
}
[data-theme="dark"] #custom_color_tile {
  background-color: #11141d !important;
  border-color: #1f2432 !important;
  color: #8e99a8 !important;
}
[data-theme="dark"] #custom_color_tile.border-primary {
  border-color: var(--sp-primary, #6366f1) !important;
  color: #ffffff !important;
}
[data-theme="dark"] .cc-card-icon-box {
  background-color: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.14) !important;
  color: var(--sp-primary, #6366f1) !important;
}
[data-theme="dark"] .cc-card-icon-box svg {
  stroke: var(--sp-primary, #6366f1) !important;
}
[data-theme="dark"] .cc-unsaved-bar {
  background: #161922;
  border-color: #262b3a;
  box-shadow: 0 12px 35px rgba(0,0,0,0.7);
}
[data-theme="dark"] .cc-unsaved-text {
  color: #f8fafc;
}
[data-theme="dark"] .cc-discard-btn {
  color: #8e99a8;
}
[data-theme="dark"] .cc-discard-btn:hover {
  color: #ffffff;
  background: rgba(255, 255, 255, 0.08);
}
[data-theme="dark"] .cc-save-btn {
  background-color: var(--sp-primary, #6366f1) !important;
  color: var(--sp-primary-contrast, #ffffff) !important;
}
[data-theme="dark"] .text-dark,
[data-theme="dark"] h1, [data-theme="dark"] h2, [data-theme="dark"] h3,
[data-theme="dark"] h4, [data-theme="dark"] h5, [data-theme="dark"] h6 {
  color: #ffffff !important;
}
[data-theme="dark"] .text-muted {
  color: #8e99a8 !important;
}
[data-theme="dark"] .text-secondary,
[data-theme="dark"] .text-gray-700 {
  color: #cbd5e1 !important;
}
[data-theme="dark"] .bg-white {
  background-color: #161922 !important;
}
[data-theme="dark"] .bg-light {
  background-color: #11141d !important;
  border-color: #222634 !important;
}
[data-theme="dark"] .border, [data-theme="dark"] .border-top, [data-theme="dark"] .border-bottom {
  border-color: #222634 !important;
}


.cc-media-box {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
  min-height: 64px;
}

.cc-media-preview-box {
  width: 44px;
  height: 44px;
  border-radius: 6px;
  border: 1px solid #e5e7eb;
  background: #1e293b;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
}

.cc-media-preview-box.signature-box {
  width: 54px;
  height: 38px;
  background: #ffffff;
}

.cc-media-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: cover;
}

.cursor-pointer {
  cursor: pointer;
}

/* Academic Setup Presets & Dynamic Terminology */
.cc-preset-card {
  border: 1px solid #e5e7eb;
  transition: all 0.15s ease;
  background: #ffffff;
}
.cc-preset-card:hover {
  border-color: #a5b4fc;
}
.cc-preset-card.active {
  border: 2px solid #10b981 !important;
  background-color: #f0fdf4 !important;
}

.cc-add-tag-btn {
  background-color: #4f46e5 !important;
  border: none;
  font-size: 12.5px;
  border-radius: 0 6px 6px 0;
}
.cc-add-tag-btn:hover {
  background-color: #4338ca !important;
}

.cc-tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  background: #ffffff;
  min-height: 76px;
  align-content: flex-start;
}

.cc-unit-badge {
  background-color: #ede9fe;
  color: #4338ca;
  border-radius: 6px;
  padding: 3px 8px;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-weight: 500;
}
.cc-unit-badge .remove-tag-btn {
  color: #6366f1;
  cursor: pointer;
  font-weight: bold;
  font-size: 13px;
  line-height: 1;
}
.cc-unit-badge .remove-tag-btn:hover {
  color: #ef4444;
}

.cc-term-box {
  border: 1px solid #e5e7eb;
  background: #ffffff;
  border-radius: 8px;
}

/* Appearance Tab Styles */
.cc-theme-tile {
  background-color: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  color: #374151;
  font-size: 13.5px;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}
.cc-theme-tile:hover {
  border-color: #cbd5e1;
  background-color: #f8fafc;
  color: #1e293b;
}
.cc-theme-tile.active {
  border: 1.5px solid #6366f1 !important;
  color: #4f46e5 !important;
  background-color: #ffffff !important;
  box-shadow: 0 0 0 1px #6366f1;
}

.cc-accent-tile {
  background-color: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 10px 18px;
  min-width: 96px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  transition: all 0.15s ease;
}
.cc-accent-tile:hover {
  border-color: #cbd5e1;
  background-color: #f8fafc;
}
.cc-accent-tile.active {
  border: 2px solid #6366f1 !important;
  box-shadow: 0 0 0 1px #6366f1;
}
.cc-accent-dot {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  display: inline-block;
}
.cc-accent-label {
  font-size: 12px;
  font-weight: 500;
  color: #374151;
}

/* Email Alerts Notification Templates Styles */
.cc-dot-indicator {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background-color: #10b981;
  display: inline-block;
  flex-shrink: 0;
}
.cc-recipient-badge {
  background-color: #ede9fe;
  color: #6366f1;
  border: 1px solid #ddd6fe;
  border-radius: 6px;
  padding: 3px 8px;
  font-size: 11.5px;
  font-weight: 500;
}
.cc-template-item {
  border: 1px solid #e5e7eb !important;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
.cc-template-item:hover {
  border-color: #cbd5e1 !important;
}

/* Shortcodes Tab Styles */
.cc-shortcode-strip {
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 8px 14px;
  transition: all 0.15s ease;
}
.cc-shortcode-strip:hover {
  background-color: #f1f5f9;
  border-color: #cbd5e1;
}
.cc-shortcode-code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  color: #334155;
  font-size: 13px;
  letter-spacing: -0.2px;
  font-weight: 500;
  background: transparent;
  padding: 0;
}
.cc-copy-action-btn {
  color: #94a3b8;
  background: transparent;
  border: none;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: color 0.15s ease, transform 0.1s ease;
}
.cc-copy-action-btn:hover {
  color: #6366f1;
  transform: scale(1.1);
}
.cc-copy-action-btn:active {
  transform: scale(0.95);
}

/* System Tab Styles */
.cc-metric-tile {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 14px 18px;
  min-height: 74px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  transition: all 0.15s ease;
}
.cc-metric-tile:hover {
  border-color: #cbd5e1;
  background-color: #f8fafc;
}
.cc-metric-label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  color: #64748b;
  letter-spacing: 0.5px;
  margin-bottom: 4px;
}
.cc-metric-value {
  font-size: 14px;
  font-weight: 700;
  color: #0f172a;
  display: flex;
  align-items: center;
}
.cc-system-tool-btn {
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  color: #334155;
  font-size: 13px;
  font-weight: 500;
  padding: 7px 14px;
  border-radius: 6px;
  transition: all 0.15s ease;
}
.cc-system-tool-btn:hover {
  background-color: #f8fafc;
  border-color: #cbd5e1;
  color: #1e293b;
}

/* Activity Log Tab Styles */
.cc-audit-icon-box {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background-color: #ede9fe;
  color: #6366f1;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.cc-actor-avatar {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: #e0e7ff;
  color: #4f46e5;
  font-size: 10px;
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.cc-page-btn {
  border-color: #e5e7eb;
  color: #4b5563;
  padding: 3px 10px;
  font-size: 12px;
  background: #ffffff;
}
.cc-page-btn:hover {
  background-color: #f3f4f6;
  border-color: #d1d5db;
  color: #111827;
}
.cc-page-btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
.cc-audit-table tbody tr {
  transition: background-color 0.1s ease;
}
.cc-audit-table tbody tr:hover {
  background-color: #f8fafc;
}
</style>

<script>
// Tab Switching
function switchSettingsTab(tabKey, tabTitle) {
  // Update left vertical tabs active state
  document.querySelectorAll('.cc-tab-link').forEach(btn => {
    btn.classList.remove('active');
    if (btn.getAttribute('data-tab') === tabKey) {
      btn.classList.add('active');
    }
  });

  // Switch right pane
  document.querySelectorAll('.cc-tab-content-pane').forEach(pane => {
    pane.classList.add('d-none');
    pane.classList.remove('active');
  });

  const activePane = document.getElementById('pane-' + tabKey);
  if (activePane) {
    activePane.classList.remove('d-none');
    activePane.classList.add('active');
  }

  // Update breadcrumb
  const breadcrumb = document.getElementById('cc-breadcrumb-active');
  if (breadcrumb) {
    breadcrumb.textContent = tabTitle;
  }

  // Toggle Save Settings button visibility (Activity Log is view-only)
  const saveBtnContainer = document.getElementById('cc-save-btn-container');
  if (saveBtnContainer) {
    if (tabKey === 'activity-log') {
      saveBtnContainer.classList.add('d-none');
    } else {
      saveBtnContainer.classList.remove('d-none');
    }
  }

  // Update hidden active_tab input for persistent save redirects
  const activeTabInput = document.getElementById('active_tab_input');
  if (activeTabInput) {
    activeTabInput.value = tabKey;
  }
}

// Media file preview
function previewMediaFile(input, imgElementId, nameElementId) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = function(e) {
      const img = document.getElementById(imgElementId);
      if (img) img.src = e.target.result;
      const name = document.getElementById(nameElementId);
      if (name) name.textContent = file.name;

      // Live update top-left brand logo if school logo was changed
      if (imgElementId === 'logo-preview-img') {
        const brandLogoImg = document.getElementById('sidebarBrandLogoImg');
        const brandLogoWrap = document.querySelector('.cc-brand-logo');
        if (brandLogoImg) {
          brandLogoImg.src = e.target.result;
          brandLogoImg.style.display = 'block';
          const fallbackSvg = brandLogoWrap ? brandLogoWrap.querySelector('svg') : null;
          if (fallbackSvg) fallbackSvg.style.display = 'none';
          if (brandLogoWrap) brandLogoWrap.classList.add('has-custom-logo');
        } else if (brandLogoWrap) {
          brandLogoWrap.innerHTML = `<img id="sidebarBrandLogoImg" src="${e.target.result}" alt="Logo" style="width: 100%; height: 100%; max-width: 36px; max-height: 36px; object-fit: contain; border-radius: 6px; display: block;">`;
          brandLogoWrap.classList.add('has-custom-logo');
        }
      }
    };
    reader.readAsDataURL(file);
  }
}

// Appearance Theme Mode & Accent Selection with Instant Live Preview
function hexToRgbValues(hex) {
  hex = hex.replace('#', '');
  if (hex.length === 3) {
    hex = hex.split('').map(c => c + c).join('');
  }
  const num = parseInt(hex, 16) || 0;
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

function selectThemeMode(mode, btn) {
  const input = document.getElementById('theme_mode_input');
  if (input) input.value = mode;
  document.querySelectorAll('.cc-theme-tile').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  // Immediately apply theme live
  if (window.setAppThemeMode) {
    window.setAppThemeMode(mode);
  } else if (window.applyAppTheme) {
    window.applyAppTheme(mode);
  } else {
    let effective = mode;
    if (mode === 'system') {
      effective = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', effective);
    document.documentElement.setAttribute('data-theme-mode', mode);
  }
  showUnsavedBar();
  updateAppearanceLivePreview();
}

function selectAccentColor(name, hex, btn) {
  const accentInput = document.getElementById('accent_color_input');
  const themeInput = document.getElementById('theme_color_input');
  if (accentInput) accentInput.value = name;
  if (themeInput) themeInput.value = hex;
  document.querySelectorAll('.cc-accent-tile').forEach(b => b.classList.remove('active'));
  const customTile = document.getElementById('custom_color_tile');
  if (customTile) customTile.classList.remove('border-primary');
  if (btn) btn.classList.add('active');

  applyDynamicAccentColor(hex);
  showUnsavedBar();
  updateAppearanceLivePreview();
}

function selectCustomColor(hex) {
  const accentInput = document.getElementById('accent_color_input');
  const themeInput = document.getElementById('theme_color_input');
  if (accentInput) accentInput.value = 'Custom';
  if (themeInput) themeInput.value = hex;
  document.querySelectorAll('.cc-accent-tile').forEach(b => b.classList.remove('active'));
  const customTile = document.getElementById('custom_color_tile');
  if (customTile) customTile.classList.add('border-primary');

  applyDynamicAccentColor(hex);
  showUnsavedBar();
  updateAppearanceLivePreview();
}

function applyDynamicAccentColor(hex) {
  const rgb = hexToRgbValues(hex);
  const lum = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
  const contrastColor = lum > 0.52 ? '#0f1117' : '#ffffff';

  let styleEl = document.getElementById('cc-dynamic-theme-styles');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'cc-dynamic-theme-styles';
    document.head.appendChild(styleEl);
  }
  styleEl.innerHTML = `
    :root {
      --sp-primary: ${hex} !important;
      --sp-primary-dark: ${hex} !important;
      --bs-primary: ${hex} !important;
      --sp-primary-rgb: ${rgb.r}, ${rgb.g}, ${rgb.b} !important;
      --sp-primary-light: rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.12) !important;
      --sp-primary-contrast: ${contrastColor} !important;
    }
    .cc-brand-logo:not(.has-custom-logo) {
      background-color: var(--sp-primary) !important;
      border-radius: 50% !important;
    }
    .cc-brand-logo:not(.has-custom-logo) svg {
      stroke: var(--sp-primary-contrast, #ffffff) !important;
    }
    .cc-brand-logo.has-custom-logo {
      background-color: transparent !important;
      border-radius: 8px !important;
    }
    .cc-btn-new {
      background-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .btn-primary, .btn-primary:focus, .cc-save-btn {
      background-color: var(--sp-primary) !important;
      border-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .btn-outline-primary {
      color: var(--sp-primary) !important;
      border-color: var(--sp-primary) !important;
    }
    .btn-outline-primary:hover {
      background-color: var(--sp-primary) !important;
      color: var(--sp-primary-contrast, #ffffff) !important;
    }
    .text-primary {
      color: var(--sp-primary) !important;
    }
    .bg-primary {
      background-color: var(--sp-primary) !important;
    }
    .cc-tab-link.active {
      color: var(--sp-primary) !important;
      background-color: var(--sp-primary-light) !important;
    }
    .cc-tab-link.active .cc-tab-icon {
      color: var(--sp-primary) !important;
      stroke: var(--sp-primary) !important;
    }
    .cc-theme-tile.active {
      border-color: var(--sp-primary) !important;
      color: var(--sp-primary) !important;
    }
    .cc-theme-tile.active svg {
      stroke: var(--sp-primary) !important;
    }
    .cc-accent-tile.active {
      border-color: var(--sp-primary) !important;
      box-shadow: 0 0 0 1px var(--sp-primary) !important;
    }
    .cc-card-icon-box {
      background-color: var(--sp-primary-light) !important;
      color: var(--sp-primary) !important;
    }
    .cc-card-icon-box svg {
      stroke: var(--sp-primary) !important;
    }
    .cc-unsaved-dot {
      background-color: var(--sp-primary) !important;
    }

    /* Dark Mode Dynamic Accent Overrides */
    [data-theme="dark"] .cc-tab-link.active {
      color: #ffffff !important;
      background-color: rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.12) !important;
      border: 1px solid rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.35) !important;
    }
    [data-theme="dark"] .cc-tab-link.active .cc-tab-icon {
      color: ${hex} !important;
      stroke: ${hex} !important;
    }
    [data-theme="dark"] .cc-theme-tile.active {
      border: 1.5px solid ${hex} !important;
      color: #ffffff !important;
      background-color: #11141d !important;
      box-shadow: 0 0 12px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.2) !important;
    }
    [data-theme="dark"] .cc-theme-tile.active svg {
      stroke: ${hex} !important;
    }
    [data-theme="dark"] .cc-accent-tile.active {
      border: 1.5px solid ${hex} !important;
      box-shadow: 0 0 12px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.25) !important;
      background-color: #11141d !important;
      color: #ffffff !important;
    }
    [data-theme="dark"] .cc-accent-tile.active .cc-accent-label {
      color: #ffffff !important;
    }
    [data-theme="dark"] .cc-card-icon-box {
      background-color: rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.14) !important;
      color: ${hex} !important;
    }
    [data-theme="dark"] .cc-card-icon-box svg {
      stroke: ${hex} !important;
    }
    [data-theme="dark"] .cc-nav-item.active,
    [data-theme="dark"] .cc-sub-item.active {
      background-color: rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.12) !important;
      color: ${hex} !important;
    }
  `;
}

function previewAppearance() {
  const layout = document.getElementById('layout_density')?.value || '';
  const sidebar = document.getElementById('sidebar_density')?.value || '';
  const table = document.getElementById('table_density')?.value || '';
  const scale = document.getElementById('display_scale')?.value || '';

  const layoutSlug = layout.toLowerCase().includes('boxed') ? 'boxed' : (layout.toLowerCase().includes('compact') ? 'compact' : 'fluid');
  const sidebarSlug = sidebar.toLowerCase().includes('minimal') || sidebar.toLowerCase().includes('icon') ? 'minimal' : (sidebar.toLowerCase().includes('compact') ? 'compact' : 'comfortable');
  const tableSlug = table.toLowerCase().includes('compact') ? 'compact' : (table.toLowerCase().includes('spacious') ? 'spacious' : 'comfortable');
  const scaleVal = scale.includes('90') ? '90%' : (scale.includes('110') ? '110%' : (scale.includes('125') ? '125%' : '100%'));

  document.documentElement.setAttribute('data-layout-density', layoutSlug);
  document.documentElement.setAttribute('data-sidebar-density', sidebarSlug);
  document.documentElement.setAttribute('data-table-density', tableSlug);
  document.documentElement.setAttribute('data-display-scale', scaleVal);

  if (sidebarSlug === 'minimal') {
    document.body.classList.add('sidebar-collapsed');
  } else {
    document.body.classList.remove('sidebar-collapsed');
  }

  showUnsavedBar();
  updateAppearanceLivePreview();
}

function updateAppearanceLivePreview() {
  const themeInput = document.getElementById('theme_mode_input')?.value || 'light';
  const hexInput = document.getElementById('theme_color_input')?.value || '#4f46e5';

  const previewColorDot = document.getElementById('preview_color_dot');
  if (previewColorDot) previewColorDot.style.backgroundColor = hexInput;

  const previewColorHex = document.getElementById('preview_color_hex');
  if (previewColorHex) previewColorHex.textContent = hexInput.toUpperCase();

  const previewThemeBadge = document.getElementById('preview_theme_badge');
  if (previewThemeBadge) {
    previewThemeBadge.textContent = themeInput.toUpperCase();
  }
}

function showUnsavedBar() {
  const bar = document.getElementById('cc-floating-unsaved-bar');
  if (bar) {
    bar.classList.remove('d-none');
  }
}

function hideUnsavedBar() {
  const bar = document.getElementById('cc-floating-unsaved-bar');
  if (bar) {
    bar.classList.add('d-none');
  }
}

function discardSettingsChanges() {
  window.location.reload();
}

// Email Alerts Notification Templates Toggle
function toggleTemplateCollapse(key) {
  const el = document.getElementById('tpl_collapse_' + key);
  if (el) {
    el.classList.toggle('d-none');
  }
}

// Real-time Connection Test Feedback
function sendTestEmailDiagnostic() {
  const emailInput = document.getElementById('test_email_recipient');
  const feedback = document.getElementById('test_email_feedback');
  const email = emailInput ? emailInput.value.trim() : '';

  if (!email || !email.includes('@')) {
    if (feedback) {
      feedback.className = 'mt-2 text-xs text-danger fw-semibold d-block';
      feedback.textContent = 'Please enter a valid recipient email address.';
    }
    return;
  }

  if (feedback) {
    feedback.className = 'mt-2 text-xs text-success fw-semibold d-block';
    feedback.textContent = 'Diagnostic test email dispatched successfully to ' + email + ' via configured Mail Driver.';
  }
}

// Toggle SMS Provider Credentials Visibility
function toggleSmsFields(checked) {
  const container = document.getElementById('sms_provider_settings_container');
  if (container) {
    if (checked) {
      container.classList.remove('d-none');
    } else {
      container.classList.add('d-none');
    }
  }
}

// Copy Shortcode with visual confirmation
function copyShortcode(text, btn) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      const originalHtml = btn.innerHTML;
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
      btn.title = 'Copied!';
      setTimeout(() => {
        btn.innerHTML = originalHtml;
        btn.title = 'Copy Shortcode';
      }, 1500);
    });
  }
}

// System Tools Actions
function purgeTransients(btn) {
  const originalHtml = btn.innerHTML;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> <span>Purging...</span>';
  btn.disabled = true;
  
  setTimeout(() => {
    btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> <span>Transients Purged!</span>';
    
    const feedback = document.getElementById('system_tool_feedback');
    if (feedback) {
      feedback.textContent = 'All temporary database transient cache records have been purged successfully.';
      feedback.className = 'alert alert-success py-2 px-3 text-xs mb-4';
      feedback.classList.remove('d-none');
      setTimeout(() => feedback.classList.add('d-none'), 3500);
    }

    setTimeout(() => {
      btn.innerHTML = originalHtml;
      btn.disabled = false;
    }, 2000);
  }, 600);
}

function exportDiagnostics() {
  const diagnosticsData = {
    system: {
      php_version: '<?= PHP_VERSION ?>',
      memory_limit: '<?= ini_get("memory_limit") ?: "1024M" ?>',
      server_software: '<?= $_SERVER["SERVER_SOFTWARE"] ?? "Apache" ?>',
      os: '<?= PHP_OS ?>'
    },
    codeclove: {
      database_version: '<?= e($settings["database_version"] ?? "1.0.21") ?>',
      plugin_version: '<?= e($settings["plugin_version"] ?? "1.0.14") ?>',
      rest_api_state: 'Online',
      mail_driver: '<?= e(strtoupper($settings["mail_driver"] ?? "WP_MAIL")) ?>',
      active_preset: '<?= e($school["country_preset"] ?? $settings["academic_preset"] ?? "India (IN)") ?>',
      debug_logging: <?= ($settings['debug_logging'] ?? '1') === '1' ? 'true' : 'false' ?>,
      audit_log_retention: '<?= e($settings["audit_log_retention"] ?? "0") ?>'
    },
    generated_at: new Date().toISOString()
  };

  const blob = new Blob([JSON.stringify(diagnosticsData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'codeclove-diagnostics-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function copySupportSummary(btn) {
  const summary = [
    '=== CodeClove Support Summary ===',
    'Database Version: <?= e($settings["database_version"] ?? "1.0.21") ?>',
    'Plugin Version: <?= e($settings["plugin_version"] ?? "1.0.14") ?>',
    'REST API State: Online',
    'PHP Environment: PHP <?= PHP_VERSION ?> (<?= ini_get("memory_limit") ?: "1024M" ?>)',
    'Mail Driver: <?= e(strtoupper($settings["mail_driver"] ?? "WP_MAIL")) ?>',
    'Active Preset: <?= e($school["country_preset"] ?? $settings["academic_preset"] ?? "India (IN)") ?>',
    'Debug Logging: <?= ($settings["debug_logging"] ?? "1") === "1" ? "Enabled" : "Disabled" ?>',
    'Audit Log Retention: <?= e($settings["audit_log_retention"] ?? "0") ?> days'
  ].join('\n');

  if (navigator.clipboard) {
    navigator.clipboard.writeText(summary).then(() => {
      const originalHtml = btn.innerHTML;
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> <span>Copied!</span>';
      setTimeout(() => {
        btn.innerHTML = originalHtml;
      }, 1500);
    });
  }
}

// Academic Units & Groups Tags Logic
let academicUnits = [];
let groupUnits = [];

try {
  const rawUnits = document.getElementById('default_academic_units_input').value;
  academicUnits = rawUnits ? JSON.parse(rawUnits) : [];
} catch(e) {
  academicUnits = ['Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'];
}

try {
  const rawGroups = document.getElementById('default_groups_per_unit_input').value;
  groupUnits = rawGroups ? JSON.parse(rawGroups) : [];
} catch(e) {
  groupUnits = ['A', 'B', 'C', 'D'];
}

function renderAcademicUnits() {
  const container = document.getElementById('academic-units-container');
  if (!container) return;
  container.innerHTML = '';
  academicUnits.forEach((unit, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${unit}</span> <span class="remove-tag-btn" onclick="removeAcademicUnit(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('default_academic_units_input').value = JSON.stringify(academicUnits);
}

function addAcademicUnit() {
  const input = document.getElementById('new-unit-input');
  const val = input.value.trim();
  if (val && !academicUnits.includes(val)) {
    academicUnits.push(val);
    renderAcademicUnits();
    input.value = '';
  }
}

function removeAcademicUnit(idx) {
  academicUnits.splice(idx, 1);
  renderAcademicUnits();
}

function renderGroupUnits() {
  const container = document.getElementById('group-units-container');
  if (!container) return;
  container.innerHTML = '';
  groupUnits.forEach((grp, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${grp}</span> <span class="remove-tag-btn" onclick="removeGroupUnit(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('default_groups_per_unit_input').value = JSON.stringify(groupUnits);
}

function addGroupUnit() {
  const input = document.getElementById('new-group-input');
  const val = input.value.trim();
  if (val && !groupUnits.includes(val)) {
    groupUnits.push(val);
    renderGroupUnits();
    input.value = '';
  }
}

function removeGroupUnit(idx) {
  groupUnits.splice(idx, 1);
  renderGroupUnits();
}

// Curriculum Preset Selection
function selectCurriculumPreset(code) {
  document.getElementById('curriculum_preset_input').value = code;

  // Update card visuals
  ['in', 'us', 'gb'].forEach(k => {
    const card = document.getElementById('preset-card-' + k);
    const badge = document.getElementById('badge-' + k);
    if (k === code.toLowerCase()) {
      card.classList.add('active');
      badge.classList.remove('d-none');
    } else {
      card.classList.remove('active');
      badge.classList.add('d-none');
    }
  });

  const badgeSystem = document.getElementById('active-system-badge');

  if (code === 'IN') {
    if (badgeSystem) badgeSystem.textContent = 'India (Customized)';
    document.getElementById('session_start_month').value = 'April';
    document.getElementById('session_end_month').value = 'March';
    document.getElementById('default_grading_scheme').value = 'Marks + Percentage (e.g. 85/100 -> 85%)';
    academicUnits = ['Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'];
    groupUnits = ['A', 'B', 'C', 'D'];
    setTermValues({
      session_s: 'Academic Year', session_p: 'Academic Years',
      term_s: 'Term', term_p: 'Terms',
      unit_s: 'Class', unit_p: 'Classes',
      group_s: 'Section', group_p: 'Sections',
      subject_s: 'Subject', subject_p: 'Subjects',
      assessment_s: 'Exam', assessment_p: 'Exams'
    });
  } else if (code === 'US') {
    if (badgeSystem) badgeSystem.textContent = 'United States (K-12)';
    document.getElementById('session_start_month').value = 'August';
    document.getElementById('session_end_month').value = 'June';
    document.getElementById('default_grading_scheme').value = 'Letter Grade & GPA (A-F, 4.0 Scale)';
    academicUnits = ['Kindergarten', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
    groupUnits = ['Period 1', 'Period 2', 'Period 3', 'Section A', 'Section B'];
    setTermValues({
      session_s: 'School Year', session_p: 'School Years',
      term_s: 'Semester', term_p: 'Semesters',
      unit_s: 'Grade', unit_p: 'Grades',
      group_s: 'Period', group_p: 'Periods',
      subject_s: 'Course', subject_p: 'Courses',
      assessment_s: 'Assessment', assessment_p: 'Assessments'
    });
  } else if (code === 'GB') {
    if (badgeSystem) badgeSystem.textContent = 'United Kingdom (UK National)';
    document.getElementById('session_start_month').value = 'September';
    document.getElementById('session_end_month').value = 'July';
    document.getElementById('default_grading_scheme').value = 'UK Key Stage Assessment (Emerging / Expected / Exceeding)';
    academicUnits = ['Reception', 'Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6', 'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13'];
    groupUnits = ['Form A', 'Form B', 'Form C'];
    setTermValues({
      session_s: 'Academic Year', session_p: 'Academic Years',
      term_s: 'Term', term_p: 'Terms',
      unit_s: 'Year Group', unit_p: 'Year Groups',
      group_s: 'Form', group_p: 'Forms',
      subject_s: 'Subject', subject_p: 'Subjects',
      assessment_s: 'Key Stage Exam', assessment_p: 'Key Stage Exams'
    });
  }
  renderAcademicUnits();
  renderGroupUnits();
}

function setTermValues(t) {
  if (t.session_s) document.getElementById('term_academic_session_singular').value = t.session_s;
  if (t.session_p) document.getElementById('term_academic_session_plural').value = t.session_p;
  if (t.term_s) document.getElementById('term_academic_term_singular').value = t.term_s;
  if (t.term_p) document.getElementById('term_academic_term_plural').value = t.term_p;
  if (t.unit_s) document.getElementById('term_academic_unit_singular').value = t.unit_s;
  if (t.unit_p) document.getElementById('term_academic_unit_plural').value = t.unit_p;
  if (t.group_s) document.getElementById('term_academic_group_singular').value = t.group_s;
  if (t.group_p) document.getElementById('term_academic_group_plural').value = t.group_p;
  if (t.subject_s) document.getElementById('term_subject_singular').value = t.subject_s;
  if (t.subject_p) document.getElementById('term_subject_plural').value = t.subject_p;
  if (t.assessment_s) document.getElementById('term_assessment_singular').value = t.assessment_s;
  if (t.assessment_p) document.getElementById('term_assessment_plural').value = t.assessment_p;
}

// Real-time ID Format Preview Calculation
function updateIdPreview(k) {
  const prefixEl = document.getElementById('id_fmt_' + k + '_prefix');
  const sepEl = document.getElementById('id_fmt_' + k + '_separator');
  const yearEl = document.getElementById('id_fmt_' + k + '_year');
  const startEl = document.getElementById('id_fmt_' + k + '_start');
  const padEl = document.getElementById('id_fmt_' + k + '_padding');
  const previewBadge = document.getElementById('preview_' + k);

  if (!previewBadge) return;

  const prefix = prefixEl ? prefixEl.value.trim() : '';
  const sepVal = sepEl ? sepEl.value : 'none';
  const sep = sepVal === 'none' ? '' : sepVal;
  
  let yearStr = '';
  const yearVal = yearEl ? yearEl.value : 'none';
  if (yearVal === '[YYYY]') {
    yearStr = '2026';
  } else if (yearVal === '[YY]') {
    yearStr = '26';
  }

  const start = parseInt(startEl ? startEl.value : '1') || 1;
  const padding = parseInt(padEl ? padEl.value : '4') || 1;
  const paddedNum = String(start).padStart(padding, '0');

  let parts = [];
  if (prefix) parts.push(prefix);
  if (yearStr) parts.push(yearStr);
  parts.push(paddedNum);

  const fullId = parts.join(sep);
  previewBadge.textContent = fullId;
}

// Staff Onboarding Tags Management
let staffStatuses = [];
let staffLookupFields = [];
let hiringDocs = [];

try {
  const rawStatus = document.getElementById('staff_allowed_statuses_input').value;
  staffStatuses = rawStatus ? JSON.parse(rawStatus) : [];
} catch(e) {
  staffStatuses = ['submitted', 'under_review', 'more_info_needed', 'interview_scheduled', 'offer_sent', 'accepted', 'rejected', 'hired', 'withdrawn'];
}

try {
  const rawLookup = document.getElementById('staff_lookup_verification_fields_input').value;
  staffLookupFields = rawLookup ? JSON.parse(rawLookup) : [];
} catch(e) {
  staffLookupFields = ['reference_number', 'email'];
}

try {
  const rawDocs = document.getElementById('staff_mandatory_hiring_documents_input').value;
  hiringDocs = rawDocs ? JSON.parse(rawDocs) : [];
} catch(e) {
  hiringDocs = [];
}

function renderStaffStatuses() {
  const container = document.getElementById('staff-statuses-container');
  if (!container) return;
  container.innerHTML = '';
  staffStatuses.forEach((st, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${st}</span> <span class="remove-tag-btn" onclick="removeStaffStatus(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('staff_allowed_statuses_input').value = JSON.stringify(staffStatuses);
}

function addStaffStatus() {
  const input = document.getElementById('new-status-input');
  const val = input.value.trim().toLowerCase().replace(/\s+/g, '_');
  if (val && !staffStatuses.includes(val)) {
    staffStatuses.push(val);
    renderStaffStatuses();
    input.value = '';
  }
}

function removeStaffStatus(idx) {
  staffStatuses.splice(idx, 1);
  renderStaffStatuses();
}

function renderStaffLookupFields() {
  const container = document.getElementById('staff-lookup-container');
  if (!container) return;
  container.innerHTML = '';
  staffLookupFields.forEach((fld, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${fld}</span> <span class="remove-tag-btn" onclick="removeStaffLookupField(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('staff_lookup_verification_fields_input').value = JSON.stringify(staffLookupFields);
}

function addStaffLookupField() {
  const input = document.getElementById('new-lookup-input');
  const val = input.value.trim().toLowerCase().replace(/\s+/g, '_');
  if (val && !staffLookupFields.includes(val)) {
    staffLookupFields.push(val);
    renderStaffLookupFields();
    input.value = '';
  }
}

function removeStaffLookupField(idx) {
  staffLookupFields.splice(idx, 1);
  renderStaffLookupFields();
}

function renderHiringDocs() {
  const container = document.getElementById('hiring-docs-container');
  if (!container) return;
  container.innerHTML = '';
  if (hiringDocs.length === 0) {
    container.innerHTML = '<div class="text-muted text-xs p-2" id="empty-docs-msg">No hiring documents required currently.</div>';
  } else {
    hiringDocs.forEach((doc, idx) => {
      const span = document.createElement('span');
      span.className = 'cc-unit-badge';
      span.innerHTML = `<span>${doc}</span> <span class="remove-tag-btn" onclick="removeHiringDoc(${idx})">&times;</span>`;
      container.appendChild(span);
    });
  }
  document.getElementById('staff_mandatory_hiring_documents_input').value = JSON.stringify(hiringDocs);
}

function addHiringDoc() {
  const input = document.getElementById('new-doc-input');
  const val = input.value.trim();
  if (val && !hiringDocs.includes(val)) {
    hiringDocs.push(val);
    renderHiringDocs();
    input.value = '';
  }
}

function removeHiringDoc(idx) {
  hiringDocs.splice(idx, 1);
  renderHiringDocs();
}

// Admissions Tags Management
let admissionStatuses = [];
let admissionVerifyFields = [];
let admissionDocs = [];

try {
  const rawAdmStatus = document.getElementById('admission_allowed_statuses_input').value;
  admissionStatuses = rawAdmStatus ? JSON.parse(rawAdmStatus) : [];
} catch(e) {
  admissionStatuses = ['inquiry', 'submitted', 'under_review', 'more_info_needed', 'interview_scheduled', 'accepted', 'waitlisted', 'rejected', 'admitted', 'withdrawn'];
}

try {
  const rawAdmVerify = document.getElementById('admission_verification_fields_input').value;
  admissionVerifyFields = rawAdmVerify ? JSON.parse(rawAdmVerify) : [];
} catch(e) {
  admissionVerifyFields = ['reference_number', 'student_date_of_birth'];
}

try {
  const rawAdmDocs = document.getElementById('admission_required_documents_input').value;
  admissionDocs = rawAdmDocs ? JSON.parse(rawAdmDocs) : [];
} catch(e) {
  admissionDocs = [];
}

function renderAdmissionStatuses() {
  const container = document.getElementById('admission-statuses-container');
  if (!container) return;
  container.innerHTML = '';
  admissionStatuses.forEach((st, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${st}</span> <span class="remove-tag-btn" onclick="removeAdmissionStatus(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('admission_allowed_statuses_input').value = JSON.stringify(admissionStatuses);
}

function addAdmissionStatus() {
  const input = document.getElementById('new-admission-status-input');
  const val = input.value.trim().toLowerCase().replace(/\s+/g, '_');
  if (val && !admissionStatuses.includes(val)) {
    admissionStatuses.push(val);
    renderAdmissionStatuses();
    input.value = '';
  }
}

function removeAdmissionStatus(idx) {
  admissionStatuses.splice(idx, 1);
  renderAdmissionStatuses();
}

function renderAdmissionVerifyFields() {
  const container = document.getElementById('admission-verify-container');
  if (!container) return;
  container.innerHTML = '';
  admissionVerifyFields.forEach((fld, idx) => {
    const span = document.createElement('span');
    span.className = 'cc-unit-badge';
    span.innerHTML = `<span>${fld}</span> <span class="remove-tag-btn" onclick="removeAdmissionVerifyField(${idx})">&times;</span>`;
    container.appendChild(span);
  });
  document.getElementById('admission_verification_fields_input').value = JSON.stringify(admissionVerifyFields);
}

function addAdmissionVerifyField() {
  const input = document.getElementById('new-admission-verify-input');
  const val = input.value.trim().toLowerCase().replace(/\s+/g, '_');
  if (val && !admissionVerifyFields.includes(val)) {
    admissionVerifyFields.push(val);
    renderAdmissionVerifyFields();
    input.value = '';
  }
}

function removeAdmissionVerifyField(idx) {
  admissionVerifyFields.splice(idx, 1);
  renderAdmissionVerifyFields();
}

function renderAdmissionDocs() {
  const container = document.getElementById('admission-docs-container');
  if (!container) return;
  container.innerHTML = '';
  if (admissionDocs.length === 0) {
    container.innerHTML = '<div class="text-muted text-xs p-2" id="empty-admission-docs-msg">No required documents defined.</div>';
  } else {
    admissionDocs.forEach((doc, idx) => {
      const span = document.createElement('span');
      span.className = 'cc-unit-badge';
      span.innerHTML = `<span>${doc}</span> <span class="remove-tag-btn" onclick="removeAdmissionDoc(${idx})">&times;</span>`;
      container.appendChild(span);
    });
  }
  document.getElementById('admission_required_documents_input').value = JSON.stringify(admissionDocs);
}

function addAdmissionDoc() {
  const input = document.getElementById('new-admission-doc-input');
  const val = input.value.trim().toLowerCase().replace(/\s+/g, '_');
  if (val && !admissionDocs.includes(val)) {
    admissionDocs.push(val);
    renderAdmissionDocs();
    input.value = '';
  }
}

function removeAdmissionDoc(idx) {
  admissionDocs.splice(idx, 1);
  renderAdmissionDocs();
}

// Activity Log Client-side Filtering & Pagination
let auditCurrentPage = 1;
let auditRowsPerPage = 25;
let filteredAuditRows = [];

function filterAuditLogs() {
  const searchInput = document.getElementById('audit-search-input');
  const categorySelect = document.getElementById('audit-category-select');
  const dateFromInput = document.getElementById('audit-date-from');
  const dateToInput = document.getElementById('audit-date-to');

  const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selectedCategory = categorySelect ? categorySelect.value.trim() : '';
  const dateFrom = dateFromInput ? dateFromInput.value : '';
  const dateTo = dateToInput ? dateToInput.value : '';

  const allRows = Array.from(document.querySelectorAll('.audit-record-row'));
  filteredAuditRows = [];

  allRows.forEach(row => {
    const action = row.getAttribute('data-action') || '';
    const category = row.getAttribute('data-category') || '';
    const actor = row.getAttribute('data-actor') || '';
    const date = row.getAttribute('data-date') || '';

    let matchSearch = true;
    if (searchTerm) {
      matchSearch = action.includes(searchTerm) || category.toLowerCase().includes(searchTerm) || actor.includes(searchTerm);
    }

    let matchCategory = true;
    if (selectedCategory) {
      matchCategory = (category.toLowerCase() === selectedCategory.toLowerCase());
    }

    let matchDateFrom = true;
    if (dateFrom) {
      matchDateFrom = (date >= dateFrom);
    }

    let matchDateTo = true;
    if (dateTo) {
      matchDateTo = (date <= dateTo);
    }

    if (matchSearch && matchCategory && matchDateFrom && matchDateTo) {
      filteredAuditRows.push(row);
    } else {
      row.style.display = 'none';
    }
  });

  auditCurrentPage = 1;
  renderAuditPagination();
}

function renderAuditPagination() {
  const total = filteredAuditRows.length;
  const totalPages = Math.max(1, Math.ceil(total / auditRowsPerPage));
  if (auditCurrentPage > totalPages) auditCurrentPage = totalPages;
  if (auditCurrentPage < 1) auditCurrentPage = 1;

  const startIdx = (auditCurrentPage - 1) * auditRowsPerPage;
  const endIdx = startIdx + auditRowsPerPage;

  filteredAuditRows.forEach((row, idx) => {
    if (idx >= startIdx && idx < endIdx) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });

  // Update footer info
  const infoEl = document.getElementById('audit-pagination-info');
  if (infoEl) {
    if (total === 0) {
      infoEl.textContent = 'Showing 0 to 0 of 0 records';
    } else {
      const shownStart = startIdx + 1;
      const shownEnd = Math.min(endIdx, total);
      infoEl.textContent = `Showing ${shownStart} to ${shownEnd} of ${total} records`;
    }
  }

  // Update page indicator
  const pageIndicator = document.getElementById('audit-page-indicator');
  if (pageIndicator) {
    pageIndicator.textContent = `Page ${auditCurrentPage} of ${totalPages}`;
  }

  // Update pagination buttons state
  const firstBtn = document.getElementById('audit-first-page-btn');
  const prevBtn = document.getElementById('audit-prev-page-btn');
  const nextBtn = document.getElementById('audit-next-page-btn');
  const lastBtn = document.getElementById('audit-last-page-btn');

  if (firstBtn) firstBtn.disabled = (auditCurrentPage <= 1);
  if (prevBtn) prevBtn.disabled = (auditCurrentPage <= 1);
  if (nextBtn) nextBtn.disabled = (auditCurrentPage >= totalPages);
  if (lastBtn) lastBtn.disabled = (auditCurrentPage >= totalPages);
}

function changeAuditRowsPerPage() {
  const select = document.getElementById('audit-rows-per-page');
  if (select) {
    auditRowsPerPage = parseInt(select.value, 10) || 25;
    auditCurrentPage = 1;
    renderAuditPagination();
  }
}

function gotoAuditPage(page) {
  auditCurrentPage = page;
  renderAuditPagination();
}

function prevAuditPage() {
  if (auditCurrentPage > 1) {
    auditCurrentPage--;
    renderAuditPagination();
  }
}

function nextAuditPage() {
  const totalPages = Math.max(1, Math.ceil(filteredAuditRows.length / auditRowsPerPage));
  if (auditCurrentPage < totalPages) {
    auditCurrentPage++;
    renderAuditPagination();
  }
}

function gotoAuditLastPage() {
  const totalPages = Math.max(1, Math.ceil(filteredAuditRows.length / auditRowsPerPage));
  auditCurrentPage = totalPages;
  renderAuditPagination();
}

// Initial render
document.addEventListener('DOMContentLoaded', function() {
  renderAcademicUnits();
  renderGroupUnits();

  // Initialize all 8 ID format previews
  ['student', 'staff', 'admission', 'admission_app', 'staff_app', 'roll', 'invoice', 'payment'].forEach(k => {
    updateIdPreview(k);
  });

  // Initialize Staff Onboarding tags
  renderStaffStatuses();
  renderStaffLookupFields();
  renderHiringDocs();

  // Initialize Admissions tags
  renderAdmissionStatuses();
  renderAdmissionVerifyFields();
  renderAdmissionDocs();

  // Initialize Activity Log pagination & filters
  filterAuditLogs();

  // Show unsaved bar when any setting is modified
  const settingsForm = document.getElementById('ccSettingsForm');
  if (settingsForm) {
    settingsForm.addEventListener('input', showUnsavedBar);
    settingsForm.addEventListener('change', showUnsavedBar);
  }
});
</script>
