<div class="panel">
    <h2><?= e($title) ?></h2>
    
    <?php if (hasFlash('error')): ?>
        <div class="alert alert-danger"><?= e(getFlash('error')) ?></div>
    <?php endif; ?>

    <form method="POST" action="<?= $user ? e(url('users/' . $user['id'])) : e(url('users')) ?>">
        <?= csrf_field() ?>
        
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control" value="<?= e($user['name'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?= e($user['email'] ?? '') ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Role</label>
            <select name="role_id" class="form-control" required>
                <option value="">Select Role</option>
                <?php foreach ($roles as $role): ?>
                    <option value="<?= $role['id'] ?>" <?= ($user['role_id'] ?? '') == $role['id'] ? 'selected' : '' ?>>
                        <?= e($role['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Linked Employee Profile (Optional)</label>
            <select name="employee_id" class="form-control">
                <option value="">-- None --</option>
                <?php foreach ($employees ?? [] as $emp): ?>
                    <option value="<?= $emp['id'] ?>" <?= ($user['employee_id'] ?? '') == $emp['id'] ? 'selected' : '' ?>>
                        <?= e($emp['first_name'] . ' ' . $emp['last_name'] . ' (' . $emp['employee_code'] . ')') ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Password <?= $user ? '(leave blank to keep current)' : '' ?></label>
            <input type="password" name="password" class="form-control" <?= $user ? '' : 'required' ?>>
        </div>

        <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="password_confirm" class="form-control" <?= $user ? '' : 'required' ?>>
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
                <option value="1" <?= ($user['status'] ?? 1) == 1 ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= ($user['status'] ?? 1) == 0 ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Save User</button>
        <a href="<?= e(url('users')) ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
