<?php 
$isEdit = isset($teacher); 
// Parse existing specializations into an array of names
$existingSpecializations = [];
if ($isEdit && !empty($teacher['specialization'])) {
    $existingSpecializations = array_map('trim', explode(',', (string)$teacher['specialization']));
}
?>
<style>
.form-control, .form-select {
    border-radius: 0.5rem;
    transition: all 0.2s ease-in-out;
    border: 1px solid #e2e8f0;
    padding: 0.6rem 1rem;
    box-shadow: none;
}
.form-control:focus, .form-select:focus {
    box-shadow: 0 0 0 0.25rem rgba(2,169,216,0.15) !important;
    border-color: var(--sp-accent) !important;
}
.hover-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.hover-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.05) !important;
}
.btn-hover {
    transition: all 0.2s ease;
}
.btn-hover:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(2,169,216,0.3);
}
/* Style for custom subject badge removal */
.btn-close-sm {
    width: 0.5em;
    height: 0.5em;
}
</style>

<div class="d-flex align-items-center mb-4">
  <a href="<?= e(url('teachers')) ?>" class="btn btn-light btn-sm me-3 d-flex align-items-center justify-content-center" style="width:36px;height:36px;border-radius:50%;"><i data-lucide="arrow-left" style="width:18px;height:18px;"></i></a>
  <div>
    <h2 class="mb-0" style="font-size:1.5rem; color:var(--sp-primary-dark); font-weight:700;"><?= $isEdit ? 'Edit Teacher' : 'Add Teacher' ?></h2>
    <div class="text-muted small">Fill out the teacher's professional and personal details.</div>
  </div>
</div>

<form method="post" enctype="multipart/form-data" action="<?= $isEdit ? e(url('teachers/'.$teacher['id'])) : e(url('teachers')) ?>">
  <?= csrf_field() ?>
  
  <div class="row g-4">
    <!-- Teacher Details Card (Personal + Professional) -->
    <div class="col-xl-8">
      <div class="card h-100 border-0 shadow-sm hover-card" style="border-radius:1rem;">
        <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
          <h4 class="mb-0 d-flex align-items-center gap-2" style="color:var(--sp-primary);">
            <i data-lucide="user" style="color:var(--sp-accent);"></i> Teacher Details
          </h4>
        </div>
        <div class="card-body p-4 pt-2">
          <div class="row g-4">
            <?php if ($isEdit): ?>
                <div class="col-md-12">
                    <div class="alert alert-info py-2 small d-flex align-items-center gap-2 mb-0 border-0 rounded-3">
                        <i data-lucide="info" style="width:16px;height:16px;"></i> Editing profile for <?= e($teacher['employee_code']) ?>
                    </div>
                    <input type="hidden" name="employee_id" value="<?= (int)$teacher['employee_id'] ?>">
                </div>
            <?php endif; ?>

            <!-- Basic Info -->
            <div class="col-md-6">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="user" style="width:14px;height:14px;"></i> First Name *</label>
              <input type="text" name="first_name" class="form-control" required value="<?= $isEdit ? e($teacher['first_name']) : '' ?>" placeholder="Jane">
            </div>
            <div class="col-md-6">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="user" style="width:14px;height:14px;"></i> Last Name *</label>
              <input type="text" name="last_name" class="form-control" required value="<?= $isEdit ? e($teacher['last_name']) : '' ?>" placeholder="Smith">
            </div>
            
            <div class="col-md-4">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="calendar" style="width:14px;height:14px;"></i> Date of Birth</label>
              <input type="date" name="date_of_birth" class="form-control" value="<?= $isEdit ? e($teacher['date_of_birth'] ?? '') : '' ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="users" style="width:14px;height:14px;"></i> Gender</label>
              <select name="gender" class="form-select">
                  <option value="">Select Gender</option>
                  <option value="male" <?= ($isEdit && ($teacher['gender'] ?? '') === 'male') ? 'selected' : '' ?>>Male</option>
                  <option value="female" <?= ($isEdit && ($teacher['gender'] ?? '') === 'female') ? 'selected' : '' ?>>Female</option>
                  <option value="other" <?= ($isEdit && ($teacher['gender'] ?? '') === 'other') ? 'selected' : '' ?>>Other</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="phone" style="width:14px;height:14px;"></i> Phone Number</label>
              <input type="tel" name="phone" class="form-control" value="<?= $isEdit ? e($teacher['phone']) : '' ?>" placeholder="+1 234 567 8900">
            </div>

            <div class="col-md-6">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="image" style="width:14px;height:14px;"></i> Profile Image</label>
              <input type="file" name="profile_image" class="form-control" accept="image/*">
            </div>
            <div class="col-md-6">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="file-text" style="width:14px;height:14px;"></i> Upload CV / Resume</label>
              <input type="file" name="resume_path" class="form-control" accept=".pdf,.doc,.docx">
            </div>

            <!-- Professional Info Block -->
            <div class="col-12 mt-4 pt-4 border-top">
                <h5 class="d-flex align-items-center gap-2 mb-3" style="color:var(--sp-primary-dark); font-size:1.1rem;"><i data-lucide="briefcase" style="color:var(--sp-accent); width:18px;height:18px;"></i> Professional Background</h5>
            </div>
            
            <div class="col-md-4">
                <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="award" style="width:14px;height:14px;"></i> Qualification</label>
                <input name="qualification" class="form-control" placeholder="e.g. M.Sc. Mathematics" value="<?= $isEdit ? e($teacher['qualification']) : '' ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="clock" style="width:14px;height:14px;"></i> Experience (Years)</label>
                <input type="number" name="experience_years" class="form-control" placeholder="0" value="<?= $isEdit ? (int)$teacher['experience_years'] : 0 ?>" min="0">
            </div>
            <div class="col-md-4">
              <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="calendar-check" style="width:14px;height:14px;"></i> Date of Joining</label>
              <input type="date" name="joining_date" class="form-control" value="<?= $isEdit ? e($teacher['joining_date'] ?? date('Y-m-d')) : date('Y-m-d') ?>">
            </div>

            <!-- Interactive Specialization Section -->
            <div class="col-md-12">
                <div class="p-3 border rounded-3 bg-light">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label d-flex align-items-center gap-1 text-muted fw-bold mb-0"><i data-lucide="book-open" style="width:14px;height:14px;"></i> Specializations (Subjects)</label>
                        <span class="badge bg-white text-dark border rounded-pill shadow-sm" id="subject-count-badge">0</span>
                    </div>
                    
                    <div id="selected-subjects-container" class="d-flex flex-wrap gap-2 mb-3 mt-2 min-vh-25">
                        <!-- Badges injected here via JS -->
                    </div>

                    <div class="row g-2">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <select id="subject-dropdown" class="form-select" style="border-radius:0.5rem 0 0 0.5rem; cursor:pointer;">
                                    <option value="">-- Choose Subject --</option>
                                    <?php foreach($subjects as $sub): ?>
                                    <option value="<?= e($sub['name']) ?>" data-id="<?= $sub['id'] ?>"><?= e($sub['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="button" class="btn btn-primary" id="btn-add-subject" style="border-radius:0 0.5rem 0.5rem 0; background:var(--sp-accent); border-color:var(--sp-accent);">Add</button>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <input type="text" id="custom-subject-input" class="form-control" placeholder="Custom subject..." style="border-radius:0.5rem 0 0 0.5rem;">
                                <button type="button" class="btn btn-outline-primary" id="btn-create-subject" style="border-radius:0 0.5rem 0.5rem 0;">Create</button>
                            </div>
                        </div>
                    </div>
                    <small class="text-success d-none mt-2" id="custom-subject-msg"><i data-lucide="check-circle" style="width:12px;height:12px;"></i> Created & Added!</small>
                </div>
            </div>
            <!-- Hidden inputs container for specialization array -->
            <div id="hidden-subject-inputs"></div>

          </div>
        </div>
      </div>
    </div>

    <!-- Right Col: Portal Details -->
    <div class="col-xl-4 d-flex flex-column gap-4">
        
        <?php if (!$isEdit): ?>
        <!-- Login Portal Details -->
        <div class="card border-0 shadow-sm hover-card flex-grow-1" style="border-radius:1rem; background:linear-gradient(to bottom, #ffffff, #fcfdfd);">
            <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2 px-4">
                <h4 class="mb-0 d-flex align-items-center gap-2" style="color:var(--sp-primary);"><i data-lucide="shield-check" style="color:var(--sp-accent);"></i> Portal Details</h4>
                <div class="small text-muted mt-2">Set up the login credentials for the Teacher Portal.</div>
            </div>
            <div class="card-body p-4 pt-2">
                <div class="row g-4">
                    <div class="col-md-12">
                        <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="mail" style="width:14px;height:14px;"></i> Email Address *</label>
                        <input type="email" name="email" class="form-control" required placeholder="teacher@school.com">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="key" style="width:14px;height:14px;"></i> Portal Password *</label>
                        <div class="input-group">
                            <input name="login_password" type="password" class="form-control" required placeholder="Choose a strong password" minlength="8" style="border-top-right-radius:0; border-bottom-right-radius:0;">
                            <span class="input-group-text bg-white" style="cursor:pointer; border-top-right-radius:0.5rem; border-bottom-right-radius:0.5rem;" onclick="const el=this.previousElementSibling; el.type=el.type==='password'?'text':'password';"><i data-lucide="eye" style="width:18px;height:18px;"></i></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="key" style="width:14px;height:14px;"></i> Confirm Password *</label>
                        <input type="password" name="login_password_confirm" class="form-control" required placeholder="Repeat password" minlength="8">
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="card border-0 shadow-sm hover-card" style="border-radius:1rem;">
            <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2 px-4">
                <h4 class="mb-0 d-flex align-items-center gap-2" style="color:var(--sp-primary);"><i data-lucide="settings" style="color:var(--sp-accent);"></i> Account Settings</h4>
            </div>
            <div class="card-body p-4 pt-2">
                <div class="col-md-12">
                    <label class="form-label d-flex align-items-center gap-1 text-muted"><i data-lucide="activity" style="width:14px;height:14px;"></i> Account Status</label>
                    <select name="status" class="form-select">
                        <option value="1" <?= $teacher['status'] == 1 ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= $teacher['status'] == 0 ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
  </div>

  <!-- Submit Buttons -->
  <div class="mt-4 d-flex align-items-center justify-content-between bg-white p-3 rounded shadow-sm border border-light">
    <div class="small text-muted d-flex align-items-center gap-2 px-2">
        <i data-lucide="shield-check" style="width:16px;height:16px;color:var(--sp-success);"></i> All changes will be saved securely
    </div>
    <div class="d-flex gap-3">
        <a href="<?= e(url('teachers')) ?>" class="btn btn-light btn-hover d-flex align-items-center gap-2 px-4 py-2" style="border-radius:8px;">Cancel</a>
        <button type="submit" class="btn btn-primary btn-hover d-flex align-items-center gap-2 px-4 py-2" style="border-radius:8px; background:var(--sp-primary-dark); border-color:var(--sp-primary-dark);">
        <i data-lucide="save" style="width:18px;height:18px;"></i> <?= $isEdit ? 'Update Teacher' : 'Save Teacher Profile' ?>
        </button>
    </div>
  </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Array of subject names
    const initialSpecs = <?= json_encode($existingSpecializations) ?>;
    let selectedSubjects = [...initialSpecs];
    
    // We also need access to all subjects to check against creation
    const allSubjects = <?= json_encode($subjects) ?>;

    const container = document.getElementById('selected-subjects-container');
    const dropdown = document.getElementById('subject-dropdown');
    const btnAdd = document.getElementById('btn-add-subject');
    const hiddenInputsContainer = document.getElementById('hidden-subject-inputs');
    const badgeCount = document.getElementById('subject-count-badge');
    
    const customInput = document.getElementById('custom-subject-input');
    const btnCreate = document.getElementById('btn-create-subject');
    const customMsg = document.getElementById('custom-subject-msg');

    function getSubjectIcon(name) {
        name = name.toLowerCase();
        if (name.includes('math')) return 'calculator';
        if (name.includes('sci')) return 'microscope';
        if (name.includes('eng')) return 'book-open';
        if (name.includes('urd')) return 'book';
        if (name.includes('isl')) return 'moon';
        if (name.includes('art') || name.includes('draw')) return 'palette';
        if (name.includes('comp')) return 'monitor';
        if (name.includes('phy')) return 'atom';
        if (name.includes('chem')) return 'flask-conical';
        if (name.includes('bio')) return 'dna';
        if (name.includes('hist') || name.includes('stud')) return 'globe';
        return 'bookmark';
    }

    function renderSubjects() {
        container.innerHTML = '';
        hiddenInputsContainer.innerHTML = '';
        
        if (selectedSubjects.length === 0) {
            container.innerHTML = '<div class="small text-muted w-100 py-2 d-flex align-items-center gap-2"><i data-lucide="info" style="width:14px;height:14px;opacity:0.5;"></i> No subjects added to specialization yet.</div>';
        }
        
        selectedSubjects.forEach(subName => {
            if (!subName) return;
            
            // UI Badge
            const badge = document.createElement('div');
            badge.className = 'badge d-flex align-items-center gap-2 py-2 px-3 shadow-sm';
            badge.style.background = '#ffffff';
            badge.style.color = 'var(--sp-primary-dark)';
            badge.style.border = '1px solid rgba(0,0,0,0.1)';
            badge.style.borderRadius = '2rem';
            badge.style.fontSize = '0.85rem';
            badge.style.transition = 'all 0.2s';
            
            const iconName = getSubjectIcon(subName);
            badge.innerHTML = `
                <i data-lucide="${iconName}" style="width:14px;height:14px;color:var(--sp-accent);"></i>
                ${subName}
                <button type="button" class="btn-close btn-close-sm ms-2 remove-subject" data-name="${subName}" style="font-size:0.55rem;"></button>
            `;
            container.appendChild(badge);
            
            // Hidden Input for Form Submission (Stores Name)
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'specialization[]';
            input.value = subName;
            hiddenInputsContainer.appendChild(input);
        });
        
        badgeCount.textContent = selectedSubjects.length;
        if(window.lucide) window.lucide.createIcons();
        
        document.querySelectorAll('.remove-subject').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const nameToRemove = this.getAttribute('data-name');
                selectedSubjects = selectedSubjects.filter(name => name !== nameToRemove);
                renderSubjects();
            });
        });
    }

    btnAdd.addEventListener('click', function() {
        const val = dropdown.value;
        if (!val) return;
        if (!selectedSubjects.includes(val)) {
            selectedSubjects.push(val);
            renderSubjects();
        }
        dropdown.value = '';
    });
    
    // AJAX Custom subject creation
    btnCreate.addEventListener('click', async function() {
        const name = customInput.value.trim();
        if (!name) return;
        
        btnCreate.disabled = true;
        btnCreate.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        
        const formData = new FormData();
        formData.append('name', name);
        formData.append('<?= app_config("csrf_token_name") ?>', '<?= \Core\CSRF::token() ?>');
        
        try {
            const res = await fetch('<?= url("subjects/ajax") ?>', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            
            if (data.success) {
                const subName = data.name;
                
                // Add to dropdown if not exists
                if (!allSubjects.find(s => s.name.toLowerCase() === subName.toLowerCase())) {
                    allSubjects.push({id: data.id, name: subName});
                    const opt = document.createElement('option');
                    opt.value = subName;
                    opt.textContent = subName;
                    dropdown.appendChild(opt);
                }
                
                // Add to selection
                if (!selectedSubjects.includes(subName)) {
                    selectedSubjects.push(subName);
                    renderSubjects();
                }
                
                customInput.value = '';
                customMsg.classList.remove('d-none');
                setTimeout(() => customMsg.classList.add('d-none'), 3000);
            } else {
                alert(data.message || 'Error creating subject');
            }
        } catch (e) {
            console.error(e);
            alert('Network error while saving subject.');
        } finally {
            btnCreate.disabled = false;
            btnCreate.textContent = 'Create';
        }
    });

    // Initial render
    renderSubjects();
});
</script>
