<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex align-items-center gap-2">
    <div class="bg-primary bg-opacity-10 text-primary p-2 rounded-3">
      <i data-lucide="book-open"></i>
    </div>
    <h2 class="mb-0 h4 fw-bold text-dark">Teachers Directory</h2>
  </div>
  <?php if (hasPermission('teachers.create')): ?>
    <a href="<?= e(url('teachers/create')) ?>" class="btn btn-primary d-flex align-items-center gap-2 rounded-pill shadow-sm">
      <i data-lucide="user-plus" style="width:18px;"></i> Add Teacher
    </a>
  <?php endif; ?>
</div>

<div class="panel border-0 shadow-sm p-4 mb-4 rounded-4">
  <form method="get" action="<?= e(url('teachers')) ?>" class="row g-3 align-items-end">
    <div class="col-md-5">
      <label class="form-label small fw-semibold text-muted">Search Teacher</label>
      <div class="input-group">
        <span class="input-group-text bg-white border-end-0 text-muted"><i data-lucide="search" style="width:16px;"></i></span>
        <input type="text" name="q" class="form-control border-start-0 ps-0" placeholder="Name, ID, Email, or Subject..." value="<?= e($filters['q'] ?? '') ?>">
      </div>
    </div>
    <div class="col-md-3">
      <label class="form-label small fw-semibold text-muted">Status</label>
      <select name="status" class="form-select">
        <option value="">All Statuses</option>
        <option value="active" <?= ($filters['status'] === 'active') ? 'selected' : '' ?>>Active</option>
        <option value="inactive" <?= ($filters['status'] === 'inactive') ? 'selected' : '' ?>>Inactive</option>
      </select>
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-primary w-100 fw-semibold d-flex align-items-center justify-content-center gap-2 rounded-3">
        <i data-lucide="filter" style="width:16px;"></i> Filter
      </button>
    </div>
  </form>
</div>

<div class="panel border-0 shadow-sm p-0 overflow-hidden rounded-4">
  <div class="table-responsive">
    <table class="table table-hover table-borderless align-middle mb-0">
      <thead class="bg-light text-muted small text-uppercase" style="border-bottom: 2px solid #edf2f7;">
        <tr>
          <th class="ps-4 py-3 fw-semibold border-0">Teacher Profile</th>
          <th class="py-3 fw-semibold border-0">Emp ID & Contact</th>
          <th class="py-3 fw-semibold border-0">Assigned Classes</th>
          <th class="py-3 fw-semibold border-0">Status</th>
          <th class="pe-4 py-3 fw-semibold border-0 text-end">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($teachers)): ?>
          <tr><td colspan="5" class="text-center py-5 text-muted">No teachers found.</td></tr>
        <?php else: ?>
          <?php foreach($teachers as $t): ?>
            <tr class="border-bottom border-light" style="transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='rgba(2, 169, 216, 0.04)';" onmouseout="this.style.backgroundColor='transparent';">
              <td class="ps-4 py-3">
                <div class="d-flex align-items-center gap-3">
                  <?php if (!empty($t['profile_image'])): ?>
                    <img src="<?= e(asset($t['profile_image'])) ?>" class="rounded-circle shadow-sm" style="width:40px;height:40px;object-fit:cover;">
                  <?php else: ?>
                    <div class="d-flex align-items-center justify-content-center rounded-circle text-white fw-bold shadow-sm" style="width:40px;height:40px;background:var(--sp-accent);">
                      <?= strtoupper(substr($t['first_name'], 0, 1)) ?>
                    </div>
                  <?php endif; ?>
                  <div>
                    <div class="fw-bold text-dark" style="font-size:0.95rem;"><?= e($t['first_name'] . ' ' . $t['last_name']) ?></div>
                    <div class="small text-muted text-truncate" style="max-width:200px;"><?= e($t['specialization'] ?? 'General') ?></div>
                  </div>
                </div>
              </td>
              <td class="py-3">
                <div class="fw-semibold text-dark small"><i data-lucide="hash" style="width:12px;"></i> <?= e($t['employee_code']) ?></div>
                <div class="small text-muted"><i data-lucide="mail" style="width:12px;"></i> <?= e($t['email']) ?></div>
              </td>
              <td class="py-3">
                <?php if(!empty($t['assignments'])): ?>
                  <div class="d-flex flex-wrap gap-1" style="max-width:220px;">
                    <?php 
                      $limit = 2;
                      $count = 0;
                      foreach($t['assignments'] as $a):
                        if($count < $limit):
                    ?>
                      <span class="badge bg-secondary bg-opacity-10 text-secondary border fw-normal" title="<?= e($a['subject_name']) ?>">
                        <?= e($a['class_name']) ?>
                      </span>
                    <?php 
                        $count++;
                        endif;
                      endforeach; 
                    ?>
                    <?php if(count($t['assignments']) > $limit): ?>
                      <span class="badge bg-light text-muted border fw-normal">+<?= count($t['assignments']) - $limit ?> more</span>
                    <?php endif; ?>
                  </div>
                <?php else: ?>
                  <span class="text-muted small">No assignments</span>
                <?php endif; ?>
              </td>
              <td class="py-3">
                <?php if ($t['emp_status'] === 'active'): ?>
                  <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1"><i data-lucide="check-circle" style="width:12px;"></i> Active</span>
                <?php else: ?>
                  <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2 py-1"><i data-lucide="x-circle" style="width:12px;"></i> Inactive</span>
                <?php endif; ?>
              </td>
              <td class="text-end pe-4 py-3">
                <a href="<?= e(url("teachers/{$t['id']}")) ?>" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center text-primary shadow-sm" style="width:32px;height:32px; border-radius:0.5rem; transition:all 0.2s;" onmouseover="this.classList.add('bg-primary', 'bg-opacity-10');" onmouseout="this.classList.remove('bg-primary', 'bg-opacity-10');" title="View Profile">
                  <i data-lucide="eye" style="width:16px;"></i>
                </a>
                <?php if(hasPermission('teachers.edit')): ?>
                  <a href="<?= e(url("teachers/{$t['id']}/edit")) ?>" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center text-secondary shadow-sm ms-1" style="width:32px;height:32px; border-radius:0.5rem; transition:all 0.2s;" onmouseover="this.classList.add('bg-secondary', 'bg-opacity-10');" onmouseout="this.classList.remove('bg-secondary', 'bg-opacity-10');" title="Edit Teacher">
                    <i data-lucide="edit-2" style="width:16px;"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  
  <?php if(isset($totalPages) && $totalPages > 1): ?>
    <div class="p-3 border-top d-flex justify-content-between align-items-center bg-light">
      <div class="small text-muted">Page <?= $page ?> of <?= $totalPages ?></div>
      <div class="d-flex gap-2">
        <a href="?page=<?= $page - 1 ?>&q=<?= urlencode($filters['q'] ?? '') ?>&status=<?= urlencode($filters['status'] ?? '') ?>" class="btn btn-sm btn-outline-secondary <?= $page <= 1 ? 'disabled' : '' ?>">Previous</a>
        <a href="?page=<?= $page + 1 ?>&q=<?= urlencode($filters['q'] ?? '') ?>&status=<?= urlencode($filters['status'] ?? '') ?>" class="btn btn-sm btn-outline-secondary <?= $page >= $totalPages ? 'disabled' : '' ?>">Next</a>
      </div>
    </div>
  <?php endif; ?>
</div>
