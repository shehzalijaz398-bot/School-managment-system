<?php 
$profileImg = !empty($teacher['profile_image']) ? e(url($teacher['profile_image'])) : null;
$initial = strtoupper(substr($teacher['first_name'], 0, 1));
?>
<style>
.profile-header {
    background: linear-gradient(135deg, var(--sp-primary-dark) 0%, var(--sp-primary) 100%);
    color: white;
    border-radius: 1rem;
    position: relative;
    overflow: hidden;
}
.profile-avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid white;
    background: var(--sp-light);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--sp-primary);
}
.hover-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.hover-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.05) !important;
}
.badge-soft {
    background: rgba(2, 169, 216, 0.1);
    color: var(--sp-accent);
    border: 1px solid rgba(2, 169, 216, 0.2);
}
.assignment-table tr {
    transition: background 0.2s;
}
.assignment-table tr:hover {
    background: rgba(0,0,0,0.02);
}
</style>

<div class="d-flex align-items-center justify-content-between mb-4">
  <div class="d-flex align-items-center gap-3">
    <a href="<?= e(url('teachers')) ?>" class="btn btn-light btn-sm d-flex align-items-center justify-content-center" style="width:36px;height:36px;border-radius:50%;"><i data-lucide="arrow-left" style="width:18px;height:18px;"></i></a>
    <h2 class="mb-0" style="font-size:1.5rem; color:var(--sp-primary-dark); font-weight:700;">Teacher Profile</h2>
  </div>
  <?php if (hasPermission('teachers.edit')): ?>
    <a href="<?= e(url('teachers/'.$teacher['id'].'/edit')) ?>" class="btn btn-primary d-flex align-items-center gap-2" style="border-radius:0.5rem;">
      <i data-lucide="edit-3" style="width:16px;height:16px;"></i> Edit Profile
    </a>
  <?php endif; ?>
</div>

<div class="row g-4">
    <!-- Left Column: Profile Card & Portal Details -->
    <div class="col-lg-4 d-flex flex-column gap-4">
        
        <!-- Main Profile Card -->
        <div class="card border-0 shadow-sm profile-header p-4 text-center">
            <div class="d-flex justify-content-center mb-3">
                <?php if ($profileImg): ?>
                    <img src="<?= $profileImg ?>" alt="Profile" class="profile-avatar shadow">
                <?php else: ?>
                    <div class="profile-avatar shadow"><?= $initial ?></div>
                <?php endif; ?>
            </div>
            <h3 class="mb-1 fw-bold"><?= e($teacher['first_name'].' '.$teacher['last_name']) ?></h3>
            <p class="mb-2 text-white-50 small"><?= e($teacher['employee_code']) ?> &middot; <?= e($teacher['qualification']) ?></p>
            
            <div class="d-flex justify-content-center flex-wrap gap-2 mt-2">
                <?php if (!empty($teacher['specialization'])): ?>
                    <?php foreach(explode(',', $teacher['specialization']) as $spec): ?>
                        <span class="badge bg-white text-dark rounded-pill px-3 py-2 shadow-sm d-flex align-items-center gap-1" style="font-size:0.75rem;">
                            <i data-lucide="book-open" style="width:12px;height:12px;color:var(--sp-accent);"></i> <?= e(trim($spec)) ?>
                        </span>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span class="badge bg-white text-muted rounded-pill px-3 py-2 shadow-sm">No Specializations</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Contact & Portal Info -->
        <div class="card border-0 shadow-sm hover-card" style="border-radius:1rem;">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4">
                <h5 class="mb-0 d-flex align-items-center gap-2" style="color:var(--sp-primary);"><i data-lucide="info" style="color:var(--sp-accent);"></i> Contact & Portal</h5>
            </div>
            <div class="card-body p-4 pt-2">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0 py-3 d-flex align-items-center gap-3">
                        <div class="bg-light rounded p-2 text-primary d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                            <i data-lucide="mail" style="width:20px;height:20px;"></i>
                        </div>
                        <div>
                            <div class="small text-muted mb-1">Email Address</div>
                            <div class="fw-medium"><?= e($teacher['email'] ?: 'N/A') ?></div>
                        </div>
                    </li>
                    <li class="list-group-item px-0 py-3 d-flex align-items-center gap-3">
                        <div class="bg-light rounded p-2 text-primary d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                            <i data-lucide="phone" style="width:20px;height:20px;"></i>
                        </div>
                        <div>
                            <div class="small text-muted mb-1">Phone Number</div>
                            <div class="fw-medium"><?= e($teacher['phone'] ?: 'N/A') ?></div>
                        </div>
                    </li>
                    <li class="list-group-item px-0 py-3 d-flex align-items-center gap-3">
                        <div class="bg-light rounded p-2 text-primary d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                            <i data-lucide="shield-check" style="width:20px;height:20px;"></i>
                        </div>
                        <div>
                            <div class="small text-muted mb-1">Portal Account</div>
                            <?php if (!empty($teacher['login_email'])): ?>
                                <div class="badge bg-success rounded-pill px-3 py-2"><i data-lucide="check-circle" style="width:12px;height:12px;" class="me-1"></i> Active</div>
                            <?php else: ?>
                                <div class="badge bg-warning text-dark rounded-pill px-3 py-2">No Account</div>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php if (!empty($teacher['resume_path'])): ?>
                    <li class="list-group-item px-0 py-3 d-flex align-items-center gap-3 border-0">
                        <div class="bg-light rounded p-2 text-primary d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
                            <i data-lucide="file-text" style="width:20px;height:20px;"></i>
                        </div>
                        <div>
                            <div class="small text-muted mb-1">Resume / CV</div>
                            <a href="<?= e(url($teacher['resume_path'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">View Document</a>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Right Column: Assignments -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm h-100" style="border-radius:1rem;">
            
            <div class="card-header bg-white border-bottom-0 pt-4 pb-3 px-4 d-flex justify-content-between align-items-center">
                <h4 class="mb-0 d-flex align-items-center gap-2" style="color:var(--sp-primary);">
                    <i data-lucide="book" style="color:var(--sp-accent);"></i> Class & Subject Assignments
                </h4>
                <span class="badge badge-soft rounded-pill px-3 py-2"><?= count($assignments) ?> Assignments</span>
            </div>
            
            <div class="card-body p-0 d-flex flex-column h-100">
                <div class="table-responsive flex-grow-1 px-4">
                    <?php if(empty($assignments)): ?>
                        <div class="text-center text-muted py-5 rounded bg-light border border-dashed my-3">
                            <i data-lucide="inbox" style="width:32px;height:32px;opacity:0.5;margin-bottom:0.5rem;"></i>
                            <p class="mb-0">No assignments yet. Add one below.</p>
                        </div>
                    <?php else: ?>
                        <table class="table align-middle assignment-table" style="border-radius:0.5rem; overflow:hidden;">
                            <thead class="bg-light text-muted small">
                                <tr>
                                    <th class="ps-3 border-0 rounded-start">Class</th>
                                    <th class="border-0">Section</th>
                                    <th class="border-0">Subject</th>
                                    <th class="border-0 rounded-end text-end pe-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($assignments as $a): ?>
                                <tr>
                                    <td class="ps-3 fw-medium text-dark">
                                        <div class="d-flex align-items-center gap-2">
                                            <i data-lucide="layout" style="width:16px;height:16px;color:var(--sp-accent);opacity:0.7;"></i> <?= e($a['class_name']) ?>
                                        </div>
                                    </td>
                                    <td><span class="badge bg-light text-dark border rounded-pill"><?= e($a['section_name']) ?></span></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <i data-lucide="book-open" style="width:16px;height:16px;color:var(--sp-primary);opacity:0.7;"></i> <?= e($a['subject_name']) ?>
                                        </div>
                                    </td>
                                    <td class="text-end pe-3">
                                        <?php if (hasPermission('teachers.edit')): ?>
                                        <form method="post" action="<?= e(url('teachers/assignments/'.$a['id'].'/delete')) ?>" class="d-inline" onsubmit="return confirm('Remove assignment?');">
                                            <?= csrf_field() ?>
                                            <button class="btn btn-sm btn-outline-danger d-inline-flex align-items-center justify-content-center rounded-circle" style="width:32px;height:32px;" title="Remove Assignment">
                                                <i data-lucide="trash-2" style="width:14px;height:14px;"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <?php if (hasPermission('teachers.edit')): ?>
                <div class="bg-light mt-auto p-4 border-top" style="border-radius: 0 0 1rem 1rem;">
                    <h5 class="mb-3 d-flex align-items-center gap-2" style="font-size:1rem; color:var(--sp-primary-dark);"><i data-lucide="plus-circle" style="width:18px;height:18px;color:var(--sp-accent);"></i> Add New Assignment</h5>
                    <form method="post" action="<?= e(url('teachers/'.$teacher['id'].'/assignments')) ?>" class="row g-3 align-items-end">
                        <?= csrf_field() ?>
                        
                        <div class="col-md-3">
                            <label class="form-label text-muted small mb-1">Class</label>
                            <select name="class_id" id="classSelect" class="form-select border-0 shadow-sm" required>
                                <option value="">Select Class</option>
                                <?php foreach($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label text-muted small mb-1">Section</label>
                            <select name="section_id" id="sectionSelect" class="form-select border-0 shadow-sm" required disabled>
                                <option value="">Select Section</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label text-muted small mb-1">Subject (Specialization)</label>
                            <select name="subject_id" class="form-select border-0 shadow-sm" required>
                                <option value="">Select Subject</option>
                                <?php if(empty($specializationSubjects)): ?>
                                    <option value="" disabled>No subjects match specialization.</option>
                                <?php else: ?>
                                    <?php foreach($specializationSubjects as $s): ?>
                                        <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100 shadow-sm d-flex justify-content-center align-items-center gap-2" style="border-radius:0.5rem;">
                                <i data-lucide="plus" style="width:16px;height:16px;"></i> Add
                            </button>
                        </div>
                    </form>
                    <?php if(empty($specializationSubjects)): ?>
                        <div class="form-text mt-2 text-danger small"><i data-lucide="alert-circle" style="width:12px;height:12px;"></i> You must add Specializations (subjects) to this teacher's profile before you can assign them to a class.</div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const classSelect = document.getElementById('classSelect');
    const sectionSelect = document.getElementById('sectionSelect');
    
    // Pass PHP classes array (with nested sections) to JS
    const classes = <?= json_encode($classes) ?>;
    
    if(classSelect && sectionSelect) {
        classSelect.addEventListener('change', function() {
            const classId = this.value;
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            
            if (classId) {
                const selectedClass = classes.find(c => c.id == classId);
                if (selectedClass && selectedClass.sections && selectedClass.sections.length > 0) {
                    sectionSelect.disabled = false;
                    selectedClass.sections.forEach(sec => {
                        const opt = document.createElement('option');
                        opt.value = sec.id;
                        opt.textContent = sec.name;
                        sectionSelect.appendChild(opt);
                    });
                } else {
                    sectionSelect.disabled = true;
                    sectionSelect.innerHTML = '<option value="">No sections found</option>';
                }
            } else {
                sectionSelect.disabled = true;
            }
        });
    }
});
</script>
