<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($title) ?></title>
    <style>
        body { margin: 0; padding: 40px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background: #fff; color: #333; }
        .header { text-align: center; border-bottom: 3px solid #0b4f6c; padding-bottom: 20px; margin-bottom: 30px; }
        .title { font-size: 24px; font-weight: bold; color: #0b4f6c; text-transform: uppercase; letter-spacing: 2px; }
        .subtitle { font-size: 14px; color: #666; margin-top: 5px; }
        
        .section { margin-bottom: 40px; }
        .section-title { font-size: 16px; font-weight: bold; background: #f8f9fa; padding: 10px; border-left: 4px solid #01baef; margin-bottom: 15px; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f1f3f5; color: #333; font-weight: bold; font-size: 13px; text-transform: uppercase; }
        td { font-size: 14px; }
        
        .footer { position: fixed; bottom: 20px; left: 40px; right: 40px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }
        
        @media print {
            body { padding: 0; }
            .footer { position: fixed; bottom: 0; }
            button { display: none; }
        }
    </style>
</head>
<body>
    <div style="text-align: right; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #0b4f6c; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">
            Print Matrix
        </button>
    </div>

    <div class="header">
        <div class="title">Enterprise Performance Analytics</div>
        <div class="subtitle">Multi-Dimensional KPI Export Matrix • Generated: <?= date('M d, Y H:i:s') ?></div>
    </div>

    <div class="section">
        <div class="section-title">Institutional KPIs (Confidential)</div>
        <table>
            <thead>
                <tr>
                    <th>Metric Classification</th>
                    <th>Current Value</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Gross Operational Revenue</td>
                    <td style="color: #198754; font-weight: bold;">System Masked</td>
                    <td><span style="color: green; font-weight: bold;">Verified</span></td>
                </tr>
                <tr>
                    <td>Syllabus Completion Index</td>
                    <td>75.4% Average</td>
                    <td><span style="color: #f6c23e; font-weight: bold;">On Track</span></td>
                </tr>
                <tr>
                    <td>Global Staff Attendance</td>
                    <td>94% Present / 6% Absent</td>
                    <td><span style="color: green; font-weight: bold;">Optimal</span></td>
                </tr>
                <tr>
                    <td>Security Incidents (Last 30 Days)</td>
                    <td>0 Infractions</td>
                    <td><span style="color: green; font-weight: bold;">Secure</span></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="footer">
        Generated securely via Enterprise Smart Analytics Engine • Document ID: <?= bin2hex(random_bytes(8)) ?>
    </div>
    
    <script>
        // Auto-trigger print window for export
        window.onload = function() {
            setTimeout(() => { window.print(); }, 500);
        }
    </script>
</body>
</html>
