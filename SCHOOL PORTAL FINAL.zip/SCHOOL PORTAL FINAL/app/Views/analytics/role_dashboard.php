<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-bar-chart-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
        <a href="<?= url('analytics/report-card/export') ?>" class="btn btn-sm btn-outline-primary shadow-sm fw-bold" target="_blank">
            <i class="bi bi-printer-fill me-1"></i> Export Metrics Matrix
        </a>
    </div>

    <!-- Data container -->
    <script>
        const metricsData = <?= $metricsJson ?>;
    </script>

    <div class="row">

        <!-- STUDENT / PARENT VIEW -->
        <?php if (in_array($role, ['student', 'parent'])): ?>
            <div class="col-xl-8 col-lg-7 mb-4">
                <div class="card shadow mb-4 h-100">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Academic Progress Trajectory</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="gradeCurveChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-5 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Attendance Distribution</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-pie" style="position: relative; height: 200px; width: 100%;">
                            <canvas id="attendanceChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <div class="card shadow border-left-danger mb-4">
                    <div class="card-body py-3 d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Behaviour Disciplinary Score</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="behaviorPtsVal">100 / 100</div>
                        </div>
                        <i class="bi bi-shield-exclamation fs-1 text-gray-300"></i>
                    </div>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    document.getElementById('behaviorPtsVal').innerText = metricsData.behavior_points + ' / 100';
                    
                    new Chart(document.getElementById("gradeCurveChart"), {
                        type: 'line',
                        data: {
                            labels: metricsData.grade_curves.labels,
                            datasets: [{
                                label: "Percentage Score",
                                data: metricsData.grade_curves.data,
                                borderColor: "#0b4f6c",
                                backgroundColor: "rgba(11, 79, 108, 0.1)",
                                tension: 0.3,
                                fill: true
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                    
                    new Chart(document.getElementById("attendanceChart"), {
                        type: 'doughnut',
                        data: {
                            labels: metricsData.attendance_ratio.labels,
                            datasets: [{
                                data: metricsData.attendance_ratio.data,
                                backgroundColor: ['#198754', '#dc3545']
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                });
            </script>
        <?php endif; ?>

        <!-- PRINCIPAL / ADMIN VIEW -->
        <?php if (in_array($role, ['principal', 'admin', 'superadmin'])): ?>
            <div class="col-xl-8 col-lg-7 mb-4">
                <div class="card shadow mb-4 h-100">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Institutional Registration Growth (MoM)</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="regGrowthChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-5 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Staff Attendance (Today)</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-pie" style="position: relative; height: 200px; width: 100%;">
                            <canvas id="staffAttChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <div class="card shadow border-left-success mb-4">
                    <div class="card-body py-3 d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Gross Fee Defalcation Ledger</div>
                            <div class="small fw-bold text-dark mt-2">Collected: <span class="text-success">$<span id="collectedFees"></span></span></div>
                            <div class="small fw-bold text-dark">Outstanding: <span class="text-danger">$<span id="outstandingFees"></span></span></div>
                        </div>
                        <i class="bi bi-cash-stack fs-1 text-gray-300"></i>
                    </div>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    document.getElementById('collectedFees').innerText = metricsData.fee_collection.collected.toLocaleString();
                    document.getElementById('outstandingFees').innerText = metricsData.fee_collection.outstanding.toLocaleString();
                    
                    new Chart(document.getElementById("regGrowthChart"), {
                        type: 'bar',
                        data: {
                            labels: metricsData.registration_growth.labels,
                            datasets: [{
                                label: "New Enrollments",
                                data: metricsData.registration_growth.data,
                                backgroundColor: "#0b4f6c",
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                    
                    new Chart(document.getElementById("staffAttChart"), {
                        type: 'pie',
                        data: {
                            labels: metricsData.staff_attendance.labels,
                            datasets: [{
                                data: metricsData.staff_attendance.data,
                                backgroundColor: ['#01baef', '#dc3545']
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                });
            </script>
        <?php endif; ?>
        
        <!-- TEACHER VIEW -->
        <?php if ($role === 'teacher'): ?>
            <div class="col-xl-8 col-lg-7 mb-4">
                <div class="card shadow mb-4 h-100">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Class Average Performance Curve</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="classAvgChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-5 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Subject Pass Rates</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-pie" style="position: relative; height: 200px; width: 100%;">
                            <canvas id="subjectPassChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <div class="card shadow border-left-info mb-4">
                    <div class="card-body py-3 d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Syllabus Completion Matrix</div>
                            <div class="row align-items-center mt-2">
                                <div class="col-auto">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800" id="syllabusCompVal"></div>
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 0%" id="syllabusCompBar"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <i class="bi bi-book fs-1 text-gray-300"></i>
                    </div>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    document.getElementById('syllabusCompVal').innerText = metricsData.syllabus_completion + '%';
                    document.getElementById('syllabusCompBar').style.width = metricsData.syllabus_completion + '%';
                    
                    new Chart(document.getElementById("classAvgChart"), {
                        type: 'line',
                        data: {
                            labels: metricsData.class_avg_performance.labels,
                            datasets: [{
                                label: "Average Aggregate (%)",
                                data: metricsData.class_avg_performance.data,
                                borderColor: "#17a2b8",
                                backgroundColor: "rgba(23, 162, 184, 0.1)",
                                tension: 0.4,
                                fill: true
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                    
                    new Chart(document.getElementById("subjectPassChart"), {
                        type: 'doughnut',
                        data: {
                            labels: metricsData.subject_pass_rate.labels,
                            datasets: [{
                                data: metricsData.subject_pass_rate.data,
                                backgroundColor: ['#0b4f6c', '#198754', '#f6c23e']
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                });
            </script>
        <?php endif; ?>
        
        <!-- FINANCE VIEW -->
        <?php if ($role === 'finance'): ?>
            <div class="col-xl-8 col-lg-7 mb-4">
                <div class="card shadow mb-4 h-100">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Predictive Cashflow Modeling</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="cashflowChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-5 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Net Profit / Loss Ledger</h6>
                    </div>
                    <div class="card-body p-4 text-center">
                        <div class="mb-3">
                            <span class="small text-muted fw-bold text-uppercase d-block mb-1">Gross Revenue</span>
                            <h4 class="text-success fw-bold">$<span id="finRev"></span></h4>
                        </div>
                        <div class="mb-3">
                            <span class="small text-muted fw-bold text-uppercase d-block mb-1">Operational Expenses</span>
                            <h5 class="text-danger fw-bold">-$<span id="finExp"></span></h5>
                        </div>
                        <div class="mb-3">
                            <span class="small text-muted fw-bold text-uppercase d-block mb-1">Payroll Defalcation</span>
                            <h5 class="text-warning text-dark fw-bold">-$<span id="finPay"></span></h5>
                        </div>
                        <hr>
                        <div>
                            <span class="small text-dark fw-bold text-uppercase d-block mb-1">Net Operating Margins</span>
                            <h3 class="text-primary fw-bold">$<span id="finNet"></span></h3>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    const rev = metricsData.net_profit.revenue;
                    const exp = metricsData.net_profit.expenses;
                    const pay = metricsData.net_profit.payroll;
                    const net = rev - exp - pay;
                    
                    document.getElementById('finRev').innerText = rev.toLocaleString();
                    document.getElementById('finExp').innerText = exp.toLocaleString();
                    document.getElementById('finPay').innerText = pay.toLocaleString();
                    document.getElementById('finNet').innerText = net.toLocaleString();
                    
                    new Chart(document.getElementById("cashflowChart"), {
                        type: 'line',
                        data: {
                            labels: metricsData.cashflow.labels,
                            datasets: [{
                                label: "Inflow Buffer ($)",
                                data: metricsData.cashflow.data,
                                borderColor: "#198754",
                                backgroundColor: "rgba(25, 135, 84, 0.1)",
                                tension: 0.1,
                                fill: true,
                                borderDash: [5, 5]
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                });
            </script>
        <?php endif; ?>
        
        <!-- HR VIEW -->
        <?php if ($role === 'hr'): ?>
            <div class="col-xl-8 col-lg-7 mb-4">
                <div class="card shadow mb-4 h-100">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Quarterly Staff Attrition Trajectory</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-area" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="attritionChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-5 mb-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-white">
                        <h6 class="m-0 font-weight-bold text-primary">Department Performance KPIs</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-pie" style="position: relative; height: 200px; width: 100%;">
                            <canvas id="deptPerfChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    new Chart(document.getElementById("attritionChart"), {
                        type: 'bar',
                        data: {
                            labels: metricsData.staff_attrition.labels,
                            datasets: [{
                                label: "Departures",
                                data: metricsData.staff_attrition.data,
                                backgroundColor: "#dc3545",
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                    
                    new Chart(document.getElementById("deptPerfChart"), {
                        type: 'polarArea',
                        data: {
                            labels: metricsData.dept_performance.labels,
                            datasets: [{
                                data: metricsData.dept_performance.data,
                                backgroundColor: ['#0b4f6c', '#01baef', '#f6c23e']
                            }]
                        },
                        options: { maintainAspectRatio: false }
                    });
                });
            </script>
        <?php endif; ?>

    </div>
</div>
