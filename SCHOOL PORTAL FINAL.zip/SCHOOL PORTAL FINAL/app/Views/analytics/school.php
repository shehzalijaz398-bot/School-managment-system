<?php
/**
 * CodeClove School Analytics & AI Insights View
 * Role-aware educational intelligence with verified statistics, cohort breakdowns,
 * predictive indicators, student-level drill-downs, and multi-format report exports.
 */
$a = $analytics ?? [];
$stats = $a['verified_statistics'] ?? [];
$att = $stats['attendance'] ?? [];
$fin = $stats['finance'] ?? [];
$acad = $stats['academics'] ?? [];
$enr = $stats['enrollment'] ?? [];
$staff = $stats['staff'] ?? [];
$staffAtt = $stats['staff_attendance'] ?? [];
$cohorts = $stats['cohorts'] ?? [];
$monthlyFinance = $stats['monthly_finance'] ?? [];
$predictions = $a['predictive_insights'] ?? [];
$anomalies = $a['anomalies'] ?? [];
$ai = $a['ai_interpretation'] ?? [];
$drilldowns = $a['drilldowns'] ?? [];
$periodInfo = $a['reporting_period'] ?? [];
$periodKey = $periodInfo['key'] ?? 'last_30_days';
$isFinanceRestricted = !empty($fin['access_restricted']);
$roleName = $role ?? 'school_admin';
$classesList = $a['classes_list'] ?? [];
$selectedClassId = $a['selected_class_id'] ?? null;

$exportQuery = 'period=' . urlencode($periodKey);
if (!empty($customStart) && !empty($customEnd)) {
    $exportQuery .= '&start_date=' . urlencode($customStart) . '&end_date=' . urlencode($customEnd);
}
if (!empty($selectedClassId)) {
    $exportQuery .= '&class_id=' . (int)$selectedClassId;
}
?>

<div class="codeclove-analytics">

  <!-- 1. Header & Navigation Controls -->
  <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
      <div class="d-flex align-items-center gap-2 mb-1">
        <h1 class="h3 fw-bold mb-0 text-dark">School Analytics &amp; Business Intelligence</h1>
        <span class="badge" style="background:#eef2ff; color:#4f46e5; font-size:12px; font-weight:700; border-radius:9999px; padding:4px 10px; border:1px solid #e0e7ff;">
          <i data-lucide="sparkles" style="width:13px;height:13px;margin-right:3px;"></i> AI-Powered
        </span>
      </div>
      <div class="text-muted small">
        <span>Data Source: <strong><?= e($a['data_source'] ?? 'Institutional Production Database') ?></strong></span> · 
        <span>Reporting Period: <strong><?= e($periodInfo['label'] ?? 'Last 30 Days') ?></strong></span> ·
        <span>Purview: <span class="badge bg-secondary-subtle text-secondary"><?= e(strtoupper(str_replace('_', ' ', $roleName))) ?></span></span>
        <?php if (!empty($selectedClassId)): ?>
          · <span class="badge bg-primary-subtle text-primary border border-primary-subtle">Filtered Class ID: #<?= (int)$selectedClassId ?></span>
        <?php endif; ?>
      </div>
    </div>

    <!-- Controls: Class Filter, Date Filters, Export, AI Assistant -->
    <div class="d-flex flex-wrap align-items-center gap-2">
      <!-- Class Filter Form -->
      <form method="GET" action="<?= e(url('analytics/school')) ?>" class="d-inline-flex align-items-center me-1">
        <input type="hidden" name="period" value="<?= e($periodKey) ?>">
        <?php if (!empty($customStart)): ?><input type="hidden" name="start_date" value="<?= e($customStart) ?>"><?php endif; ?>
        <?php if (!empty($customEnd)): ?><input type="hidden" name="end_date" value="<?= e($customEnd) ?>"><?php endif; ?>
        <select name="class_id" class="form-select form-select-sm shadow-sm" style="min-width: 140px;" onchange="this.form.submit()" aria-label="Filter by Class">
          <option value="">All Classes / Cohorts</option>
          <?php foreach ($classesList as $cls): ?>
            <option value="<?= (int)$cls['id'] ?>" <?= $selectedClassId === (int)$cls['id'] ? 'selected' : '' ?>><?= e($cls['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </form>

      <!-- Period Presets -->
      <div class="btn-group shadow-sm" role="group">
        <?php
          $classParam = !empty($selectedClassId) ? '&class_id=' . (int)$selectedClassId : '';
        ?>
        <a href="<?= e(url('analytics/school?period=last_30_days' . $classParam)) ?>" class="btn btn-sm <?= $periodKey === 'last_30_days' ? 'btn-primary' : 'btn-outline-secondary' ?>">Last 30 Days</a>
        <a href="<?= e(url('analytics/school?period=this_term' . $classParam)) ?>" class="btn btn-sm <?= $periodKey === 'this_term' ? 'btn-primary' : 'btn-outline-secondary' ?>">This Term</a>
        <a href="<?= e(url('analytics/school?period=this_year' . $classParam)) ?>" class="btn btn-sm <?= $periodKey === 'this_year' ? 'btn-primary' : 'btn-outline-secondary' ?>">Academic Year</a>
      </div>

      <button type="button" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 shadow-sm" data-bs-toggle="collapse" data-bs-target="#customDateFilter">
        <i data-lucide="calendar" style="width:14px;height:14px;"></i> Custom Range
      </button>

      <!-- Export Dropdown -->
      <div class="dropdown">
        <button class="btn btn-sm btn-outline-secondary dropdown-toggle d-inline-flex align-items-center gap-1 shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i data-lucide="download" style="width:14px;height:14px;"></i> Export
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
          <li>
            <a class="dropdown-item d-flex align-items-center gap-2 py-2" href="<?= e(url('analytics/export?format=csv&' . $exportQuery)) ?>">
              <i data-lucide="file-spreadsheet" style="width:15px;height:15px;" class="text-success"></i> Export CSV (.csv)
            </a>
          </li>
          <li>
            <a class="dropdown-item d-flex align-items-center gap-2 py-2" href="<?= e(url('analytics/export?format=json&' . $exportQuery)) ?>">
              <i data-lucide="file-code" style="width:15px;height:15px;" class="text-primary"></i> Export JSON (.json)
            </a>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li>
            <a class="dropdown-item d-flex align-items-center gap-2 py-2" href="<?= e(url('analytics/export?format=print&' . $exportQuery)) ?>" target="_blank">
              <i data-lucide="printer" style="width:15px;height:15px;" class="text-indigo"></i> Print / Executive PDF
            </a>
          </li>
        </ul>
      </div>

      <button type="button" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-1 shadow-sm" onclick="window.triggerChatbotPrompt('Provide an executive business intelligence summary of our school attendance, academic performance, and areas needing support.')">
        <i data-lucide="message-square" style="width:14px;height:14px;"></i> Ask Copilot
      </button>
    </div>
  </div>

  <!-- Custom Date Filter Dropdown Collapse -->
  <div class="collapse mb-4 <?= $periodKey === 'custom' ? 'show' : '' ?>" id="customDateFilter">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-light">
      <form method="GET" action="<?= e(url('analytics/school')) ?>" class="row g-2 align-items-end">
        <input type="hidden" name="period" value="custom">
        <?php if (!empty($selectedClassId)): ?>
          <input type="hidden" name="class_id" value="<?= (int)$selectedClassId ?>">
        <?php endif; ?>
        <div class="col-12 col-sm-4">
          <label class="form-label small fw-semibold text-muted mb-1">Start Date</label>
          <input type="date" name="start_date" class="form-control form-control-sm" value="<?= e($periodInfo['current_start'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-sm-4">
          <label class="form-label small fw-semibold text-muted mb-1">End Date</label>
          <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($periodInfo['current_end'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-sm-4 d-flex gap-2">
          <button type="submit" class="btn btn-sm btn-primary w-100">Apply Filter</button>
          <a href="<?= e(url('analytics/school?period=last_30_days')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
        </div>
      </form>
    </div>
  </div>

  <!-- Role Privacy Notice for Teachers / Academic Staff -->
  <?php if ($isFinanceRestricted): ?>
  <div class="alert alert-info border-0 shadow-sm rounded-3 py-2 px-3 mb-4 d-flex align-items-center gap-2">
    <i data-lucide="shield-check" style="width: 18px; height: 18px;" class="text-primary"></i>
    <span class="small"><strong>Teacher Curriculum &amp; Pedagogical View:</strong> Attendance records, examinations, and cohort trends for your assigned curriculum are unlocked. Institutional tuition billing and school cashflows are confidential to administrative and finance officers.</span>
  </div>
  <?php endif; ?>

  <!-- Data Sparsity / Uncertainty Warning Banner -->
  <?php if (empty($att['has_sufficient_data']) || empty($acad['has_sufficient_data'])): ?>
  <div class="alert alert-warning border-0 shadow-sm rounded-3 py-2 px-3 mb-4 d-flex align-items-center gap-2">
    <i data-lucide="alert-triangle" style="width: 18px; height: 18px;" class="text-warning"></i>
    <span class="small"><strong>[DATA_SPARSE_WARNING] Provisional Trend Warning:</strong> Incomplete historical evaluation data on file (&lt; 3 attendance days or &lt; 5 examination marks). Statistical projections are provisional until mid-term grade submissions are completed.</span>
  </div>
  <?php endif; ?>

  <!-- 2. AI Executive Brief & Verified Data Distinction Banner -->
  <div class="card border-0 shadow-sm rounded-4 mb-4" style="background: linear-gradient(135deg, #ffffff 0%, #fbfbfe 100%); border-left: 5px solid #4f46e5 !important;">
    <div class="card-body p-4">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3 pb-2 border-bottom">
        <div class="d-flex align-items-center gap-2">
          <div class="avatar bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
            <i data-lucide="sparkles" style="width: 20px; height: 20px;"></i>
          </div>
          <div>
            <h5 class="fw-bold mb-0 text-dark">Executive Intelligence Brief</h5>
            <small class="text-muted">Role Purview: <?= e(strtoupper(str_replace('_', ' ', $roleName))) ?> · Engine: <?= e($ai['provider'] ?? 'deterministic_heuristic_engine') ?></small>
          </div>
        </div>

        <div class="d-flex align-items-center gap-2">
          <span class="badge" style="background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; font-size: 11px; padding: 4px 8px;">
            <i data-lucide="shield-check" style="width: 12px; height: 12px; margin-right: 2px;"></i> [VERIFIED_STATISTICS] Grounded
          </span>
          <span class="badge" style="background: #f5f3ff; color: #6d28d9; border: 1px solid #ddd6fe; font-size: 11px; padding: 4px 8px;">
            <i data-lucide="bot" style="width: 12px; height: 12px; margin-right: 2px;"></i> [AI_INTERPRETATION] Model
          </span>
        </div>
      </div>

      <!-- Formatted AI Text Output -->
      <div class="cc-ai-brief-content text-dark" style="font-size: 13.5px; line-height: 1.6;">
        <?= nl2br(e($ai['executive_summary'] ?? 'Compiling executive insights...')) ?>
      </div>
    </div>
  </div>

  <!-- 3. Predictive Early Warnings & Pedagogical Interventions -->
  <?php if (!empty($predictions)): ?>
  <div class="mb-4">
    <div class="d-flex align-items-center justify-content-between mb-2">
      <h6 class="fw-bold text-muted small text-uppercase mb-0" style="letter-spacing: 0.5px;">Predictive Insights &amp; Targeted Interventions</h6>
      <span class="badge bg-light text-muted border">Proactive Early Warnings</span>
    </div>
    <div class="row g-2">
      <?php foreach ($predictions as $pred): 
        $sev = $pred['severity'] ?? 'medium';
        $pBorder = match($sev) {
            'high' => 'border-danger-subtle bg-danger-subtle text-danger-emphasis',
            'medium' => 'border-warning-subtle bg-warning-subtle text-warning-emphasis',
            default => 'border-primary-subtle bg-primary-subtle text-primary-emphasis',
        };
        $pBadge = match($sev) {
            'high' => 'bg-danger text-white',
            'medium' => 'bg-warning text-dark',
            default => 'bg-primary text-white',
        };
      ?>
      <div class="col-12 col-md-6">
        <div class="card border rounded-3 p-3 h-100 shadow-sm <?= $pBorder ?>">
          <div class="d-flex align-items-center justify-content-between mb-1">
            <span class="badge <?= $pBadge ?> text-uppercase" style="font-size: 10px;"><?= e($sev) ?> Priority</span>
            <small class="fw-semibold opacity-75">Certainty: <?= e($pred['certainty'] ?? 'high') ?></small>
          </div>
          <div class="fw-bold text-dark mt-1"><?= e($pred['headline'] ?? '') ?></div>
          <div class="small text-muted mt-1" style="font-size: 12px;"><?= e($pred['evidence'] ?? '') ?></div>
          <div class="small fw-semibold mt-2 text-dark" style="font-size: 12px; border-top: 1px dashed rgba(0,0,0,0.1); padding-top: 6px;">
            <?= e($pred['recommendation'] ?? '') ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- 4. Key Performance Indicator Cards with Comparison Deltas -->
  <div class="row g-3 mb-4">
    <!-- Attendance KPI -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="calendar" style="width: 18px; height: 18px;"></i>
          </div>
          <?php $delta = (float)($att['percentage_delta'] ?? 0.0); ?>
          <span class="badge <?= $delta >= 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>" style="font-size: 11px;">
            <?= $delta >= 0 ? '+' : '' ?><?= $delta ?>% vs prior
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-dark"><?= (float)($att['overall_attendance_rate'] ?? 0.0) ?>%</h3>
        <small class="text-muted">Student Attendance Rate</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          <?= (int)($att['present_count'] ?? 0) ?> Present · <?= (int)($att['absent_count'] ?? 0) ?> Absent (<?= (int)($att['recorded_school_days'] ?? 0) ?> Days)
        </div>
      </div>
    </div>

    <!-- Staff Attendance KPI -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-info-subtle text-info rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="user-check" style="width: 18px; height: 18px;"></i>
          </div>
          <span class="badge bg-info-subtle text-info" style="font-size: 11px;">
            <?= (int)($staff['total_staff'] ?? 0) ?> Total Faculty
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-dark"><?= (float)($staffAtt['staff_attendance_rate'] ?? 100.0) ?>%</h3>
        <small class="text-muted">Staff Operational Presence</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          <?= (int)($staffAtt['present_count'] ?? 0) ?> Present · <?= (int)($staffAtt['recorded_days'] ?? 0) ?> Recorded Days
        </div>
      </div>
    </div>

    <?php if (!$isFinanceRestricted): ?>
    <!-- Fee Collection Efficiency KPI -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-success-subtle text-success rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="credit-card" style="width: 18px; height: 18px;"></i>
          </div>
          <span class="badge bg-success-subtle text-success" style="font-size: 11px;">
            <?= (float)($fin['collection_efficiency_rate'] ?? 0.0) ?>% Collected
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-dark">$<?= number_format((float)($fin['total_collected'] ?? 0.0), 2) ?></h3>
        <small class="text-muted">Tuition Fees Collected</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          $<?= number_format((float)($fin['total_invoiced'] ?? 0.0), 2) ?> Billed in Period
        </div>
      </div>
    </div>

    <!-- Overdue Debt KPI -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-danger-subtle text-danger rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="alert-circle" style="width: 18px; height: 18px;"></i>
          </div>
          <span class="badge bg-danger-subtle text-danger" style="font-size: 11px;">
            <?= (int)($fin['overdue_invoices_count'] ?? 0) ?> Invoices
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-danger">$<?= number_format((float)($fin['overdue_arrears'] ?? 0.0), 2) ?></h3>
        <small class="text-muted">Overdue Fee Arrears</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          <?= !empty($monthlyFinance['projected_collection_30d']) ? '30d Velocity: $' . number_format($monthlyFinance['projected_collection_30d'], 2) : 'Action required by cashier' ?>
        </div>
      </div>
    </div>
    <?php else: ?>
    <!-- Active Students & Classes (Replaces Finance for Teachers) -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-success-subtle text-success rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="users" style="width: 18px; height: 18px;"></i>
          </div>
          <span class="badge bg-success-subtle text-success" style="font-size: 11px;">
            <?= (int)($enr['active_students'] ?? 0) ?> Active
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-dark"><?= count($cohorts) ?></h3>
        <small class="text-muted">Instructional Classes</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          <?= (int)($enr['total_students'] ?? 0) ?> Total Enrolled Pupils
        </div>
      </div>
    </div>

    <!-- Academic Evaluations Evaluated -->
    <div class="col-12 col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="avatar bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
            <i data-lucide="check-square" style="width: 18px; height: 18px;"></i>
          </div>
          <span class="badge bg-primary-subtle text-primary" style="font-size: 11px;">
            <?= (int)($acad['published_exams_count'] ?? 0) ?> Exams
          </span>
        </div>
        <h3 class="fw-bold mb-0 text-dark"><?= (int)($acad['total_marks_evaluated'] ?? 0) ?></h3>
        <small class="text-muted">Total Marks Evaluated</small>
        <div class="text-muted mt-2" style="font-size: 11px;">
          Overall Average: <?= (float)($acad['average_score_percentage'] ?? 0.0) ?>%
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- 5. Interactive Multi-Dimensional Drilldown Consoles -->
  <div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-header bg-white border-bottom p-0">
      <ul class="nav nav-tabs border-0 px-3 pt-2" id="analyticsDrilldownTabs" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active fw-bold text-dark d-inline-flex align-items-center gap-2" id="cohorts-tab" data-bs-toggle="tab" data-bs-target="#tab-cohorts" type="button" role="tab">
            <i data-lucide="users" style="width:15px;height:15px;"></i> Cohort Performance &amp; Risk
          </button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link fw-bold text-dark d-inline-flex align-items-center gap-2" id="subjects-tab" data-bs-toggle="tab" data-bs-target="#tab-subjects" type="button" role="tab">
            <i data-lucide="book-open" style="width:15px;height:15px;"></i> Subject Academic Standing
          </button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link fw-bold text-dark d-inline-flex align-items-center gap-2" id="defaulters-tab" data-bs-toggle="tab" data-bs-target="#tab-defaulters" type="button" role="tab">
            <i data-lucide="user-x" style="width:15px;height:15px;"></i> Chronic Attendance Defaulters
          </button>
        </li>
        <?php if (!$isFinanceRestricted): ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link fw-bold text-dark d-inline-flex align-items-center gap-2" id="feecats-tab" data-bs-toggle="tab" data-bs-target="#tab-feecats" type="button" role="tab">
            <i data-lucide="credit-card" style="width:15px;height:15px;"></i> Fee Category Patterns
          </button>
        </li>
        <?php endif; ?>
      </ul>
    </div>

    <div class="tab-content" id="analyticsDrilldownTabContent">
      <!-- Tab 1: Cohorts & Student Roster -->
      <div class="tab-pane fade show active p-3" id="tab-cohorts" role="tabpanel">
        <?php if (!empty($cohorts)): ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
            <thead class="table-light text-muted text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">
              <tr>
                <th class="ps-3">Class / Cohort</th>
                <th>Enrolled Pupils</th>
                <th>Attendance Rate</th>
                <th>Evaluations</th>
                <th>Average Score</th>
                <th>Pass Rate</th>
                <th>Risk Status</th>
                <th class="pe-3 text-end">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($cohorts as $coh): 
                $risk = $coh['risk_category'] ?? 'normal';
                $rBadge = match($risk) {
                    'attendance_risk' => '<span class="badge bg-warning-subtle text-warning border border-warning-subtle"><i data-lucide="alert-circle" style="width:11px;height:11px;"></i> Attendance Risk</span>',
                    'academic_risk' => '<span class="badge bg-danger-subtle text-danger border border-danger-subtle"><i data-lucide="alert-triangle" style="width:11px;height:11px;"></i> Academic Risk</span>',
                    default => '<span class="badge bg-success-subtle text-success border border-success-subtle"><i data-lucide="check" style="width:11px;height:11px;"></i> Normal</span>',
                };
              ?>
              <tr>
                <td class="ps-3 fw-semibold text-dark"><?= e($coh['class_name']) ?></td>
                <td><?= (int)$coh['student_count'] ?> pupils</td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <span class="fw-semibold <?= $coh['attendance_rate'] < 80 ? 'text-danger' : 'text-dark' ?>"><?= $coh['attendance_rate'] ?>%</span>
                    <div class="progress flex-grow-1" style="height: 6px; width: 60px;">
                      <div class="progress-bar <?= $coh['attendance_rate'] < 80 ? 'bg-danger' : 'bg-primary' ?>" style="width: <?= min(100, $coh['attendance_rate']) ?>%"></div>
                    </div>
                  </div>
                </td>
                <td><?= (int)$coh['evaluations_count'] ?></td>
                <td class="fw-semibold"><?= $coh['average_score'] ?>%</td>
                <td>
                  <span class="fw-semibold <?= $coh['pass_rate'] < 60 ? 'text-danger' : 'text-success' ?>"><?= $coh['pass_rate'] ?>%</span>
                </td>
                <td><?= $rBadge ?></td>
                <td class="pe-3 text-end">
                  <button type="button" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1" onclick="window.openCohortDrilldown(<?= (int)$coh['class_id'] ?>, '<?= e(addslashes($coh['class_name'])) ?>')">
                    <i data-lucide="eye" style="width:12px;height:12px;"></i> Drill Down
                  </button>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="text-center py-4 text-muted">No cohort records enrolled in current school academic term.</div>
        <?php endif; ?>
      </div>

      <!-- Tab 2: Subject Academic Standing -->
      <div class="tab-pane fade p-3" id="tab-subjects" role="tabpanel">
        <?php if (!empty($drilldowns['subject_details'])): ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
            <thead class="table-light text-muted text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">
              <tr>
                <th class="ps-3">Curriculum Subject</th>
                <th>Class / Cohort</th>
                <th>Candidates</th>
                <th>Average Score</th>
                <th>Min / Max Score</th>
                <th>Pass Rate</th>
                <th>Passing / Failing</th>
                <th class="pe-3 text-end">Support Recommendation</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($drilldowns['subject_details'] as $sd): 
                $needsSupport = !empty($sd['needs_support']) || $sd['pass_rate'] < 65.0;
              ?>
              <tr>
                <td class="ps-3 fw-bold text-dark"><?= e($sd['subject_name']) ?></td>
                <td><?= e($sd['class_name']) ?></td>
                <td><?= (int)$sd['candidate_count'] ?> candidates</td>
                <td class="fw-semibold"><?= $sd['average_score'] ?>%</td>
                <td class="text-muted"><?= $sd['lowest_score'] ?>% / <?= $sd['highest_score'] ?>%</td>
                <td>
                  <span class="fw-bold <?= $needsSupport ? 'text-danger' : 'text-success' ?>"><?= $sd['pass_rate'] ?>%</span>
                </td>
                <td><?= (int)$sd['passing_candidates'] ?> Pass · <?= (int)$sd['failing_candidates'] ?> Fail</td>
                <td class="pe-3 text-end">
                  <?php if ($needsSupport): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                      <i data-lucide="alert-triangle" style="width:11px;height:11px;"></i> Support Needed
                    </span>
                  <?php else: ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle">
                      <i data-lucide="check" style="width:11px;height:11px;"></i> Standard Met
                    </span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="text-center py-4 text-muted">No published examination evaluations available for subject breakdown in this period.</div>
        <?php endif; ?>
      </div>

      <!-- Tab 3: Chronic Attendance Defaulters -->
      <div class="tab-pane fade p-3" id="tab-defaulters" role="tabpanel">
        <?php if (!empty($drilldowns['attendance_defaulters'])): ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
            <thead class="table-light text-muted text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">
              <tr>
                <th class="ps-3">Admission ID</th>
                <th>Student Name</th>
                <th>Class</th>
                <th>Recorded Days</th>
                <th>Present Days</th>
                <th>Absent Days</th>
                <th>Attendance Rate</th>
                <th class="pe-3 text-end">Contact Phone</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($drilldowns['attendance_defaulters'] as $def): ?>
              <tr>
                <td class="ps-3 fw-mono text-muted"><?= e($def['admission_no']) ?></td>
                <td class="fw-semibold text-dark"><?= e($def['name']) ?></td>
                <td><?= e($def['class_name']) ?></td>
                <td><?= (int)$def['recorded_days'] ?> days</td>
                <td class="text-success"><?= (int)$def['present_days'] ?> present</td>
                <td class="text-danger fw-semibold"><?= (int)$def['absent_days'] ?> absent</td>
                <td>
                  <span class="badge bg-danger-subtle text-danger border border-danger-subtle fw-bold"><?= $def['attendance_rate'] ?>%</span>
                </td>
                <td class="pe-3 text-end text-muted"><?= e($def['phone'] ?? 'Unlisted') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="text-center py-4 text-success">
            <i data-lucide="check-circle" style="width:20px;height:20px;margin-bottom:4px;"></i>
            <div>Zero chronic attendance defaulters detected (&lt;75% attendance) in active reporting cycle!</div>
          </div>
        <?php endif; ?>
      </div>

      <?php if (!$isFinanceRestricted): ?>
      <!-- Tab 4: Fee Categories & Collection Patterns -->
      <div class="tab-pane fade p-3" id="tab-feecats" role="tabpanel">
        <?php if (!empty($drilldowns['fee_categories']['categories'])): ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
            <thead class="table-light text-muted text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">
              <tr>
                <th class="ps-3">Fee Category</th>
                <th>Billing Frequency</th>
                <th>Invoiced Amount</th>
                <th>Collected Amount</th>
                <th>Collection Efficiency</th>
                <th class="pe-3 text-end">Overdue Arrears</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($drilldowns['fee_categories']['categories'] as $fc): ?>
              <tr>
                <td class="ps-3 fw-bold text-dark"><?= e($fc['name']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= e($fc['frequency']) ?></span></td>
                <td>$<?= number_format((float)$fc['total_invoiced'], 2) ?></td>
                <td class="text-success fw-semibold">$<?= number_format((float)$fc['total_collected'], 2) ?></td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <span class="fw-semibold"><?= $fc['collection_efficiency'] ?>%</span>
                    <div class="progress flex-grow-1" style="height: 6px; width: 60px;">
                      <div class="progress-bar bg-success" style="width: <?= min(100, $fc['collection_efficiency']) ?>%"></div>
                    </div>
                  </div>
                </td>
                <td class="pe-3 text-end fw-bold <?= $fc['overdue_arrears'] > 0 ? 'text-danger' : 'text-muted' ?>">
                  $<?= number_format((float)$fc['overdue_arrears'], 2) ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="text-center py-4 text-muted">No fee categories configured for active school tenant.</div>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- 6. Analytical Visualizations Section -->
  <div class="row g-3 mb-4">
    <!-- Attendance Trend Chart -->
    <div class="col-12 col-lg-7">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom">
          <div>
            <h6 class="fw-bold mb-0 text-dark">Daily Attendance Trajectory</h6>
            <small class="text-muted">Attendance percentage per recorded school day</small>
          </div>
          <span class="badge bg-light text-dark border">Recorded: <?= count($att['daily_trend'] ?? []) ?> days</span>
        </div>
        <div style="position: relative; height: 260px;">
          <canvas id="attendanceTrendCanvas"></canvas>
        </div>
      </div>
    </div>

    <!-- Subject Pass Rate Breakdown Chart -->
    <div class="col-12 col-lg-5">
      <div class="card border-0 shadow-sm rounded-4 p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom">
          <div>
            <h6 class="fw-bold mb-0 text-dark">Subject Academic Standing</h6>
            <small class="text-muted">Class pass rate by curriculum subject</small>
          </div>
        </div>
        <div style="position: relative; height: 260px;">
          <canvas id="subjectPassCanvas"></canvas>
        </div>
      </div>
    </div>
  </div>

  <?php if (!$isFinanceRestricted && !empty($monthlyFinance['history'])): ?>
  <!-- 7. Monthly Cashflow & Fee Collection Trajectory Chart (Admin/Finance only) -->
  <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between mb-3 pb-2 border-bottom gap-2">
      <div>
        <h6 class="fw-bold mb-0 text-dark">Past 6 Months Financial Collection Velocity</h6>
        <small class="text-muted">Tuition fees invoiced vs collected with 30-day projected velocity</small>
      </div>
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary-subtle text-primary border">Projected Next 30d: $<?= number_format((float)($monthlyFinance['projected_collection_30d'] ?? 0.0), 2) ?></span>
      </div>
    </div>
    <div style="position: relative; height: 240px;">
      <canvas id="monthlyFinanceCanvas"></canvas>
    </div>
  </div>
  <?php endif; ?>

</div>

<!-- Student-Level Cohort Drilldown Interactive Modal -->
<div class="modal fade" id="cohortDrilldownModal" tabindex="-1" aria-labelledby="cohortDrilldownModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg rounded-4">
      <div class="modal-header border-bottom py-3 px-4">
        <div>
          <h5 class="modal-title fw-bold text-dark" id="cohortDrilldownModalLabel">Cohort Student Roster Drilldown</h5>
          <small class="text-muted" id="cohortDrilldownSub">Detailed student attendance, academic scores, and risk classifications</small>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <!-- Quick Summary Bar & Live Filter -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3 pb-3 border-bottom">
          <div class="d-flex align-items-center gap-3">
            <div>
              <small class="text-muted d-block">Pupils Enrolled</small>
              <strong class="fs-6" id="drilldownPupilCount">-</strong>
            </div>
            <div class="border-start ps-3">
              <small class="text-muted d-block">Avg Attendance</small>
              <strong class="fs-6 text-primary" id="drilldownAvgAtt">-</strong>
            </div>
            <div class="border-start ps-3">
              <small class="text-muted d-block">Class Average Score</small>
              <strong class="fs-6 text-success" id="drilldownAvgScore">-</strong>
            </div>
          </div>
          <div style="min-width: 240px;">
            <input type="text" id="drilldownSearchInput" class="form-control form-control-sm" placeholder="Search student name or admission no...">
          </div>
        </div>

        <!-- Student Roster Table -->
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0" id="drilldownStudentTable" style="font-size: 13px;">
            <thead class="table-light text-muted text-uppercase" style="font-size: 11px;">
              <tr>
                <th>Admission No</th>
                <th>Roll</th>
                <th>Student Name</th>
                <th>Section</th>
                <th>Attendance Rate</th>
                <th>Evaluations</th>
                <th>Average Score</th>
                <th>Pass Rate</th>
                <th id="drilldownFeeHeader">Fee Balance</th>
                <th class="text-end">Risk Status</th>
              </tr>
            </thead>
            <tbody id="drilldownTableBody">
              <tr>
                <td colspan="10" class="text-center py-4 text-muted">
                  <div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading cohort roster...
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer border-top py-2 px-4">
        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Chart.js Engine -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Attendance Trend Chart
    const attCanvas = document.getElementById('attendanceTrendCanvas');
    if (attCanvas) {
        const trendData = <?= json_encode($att['daily_trend'] ?? []) ?>;
        const labels = trendData.map(d => d.date);
        const rates = trendData.map(d => d.rate);

        new Chart(attCanvas, {
            type: 'line',
            data: {
                labels: labels.length ? labels : ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Attendance %',
                    data: rates.length ? rates : [92, 94, 91, 95, 93],
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79, 70, 229, 0.1)',
                    borderWidth: 2.5,
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#4f46e5',
                    pointRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        min: 50,
                        max: 100,
                        ticks: {
                            callback: v => v + '%'
                        }
                    }
                }
            }
        });
    }

    // 2. Subject Pass Rate Chart
    const subCanvas = document.getElementById('subjectPassCanvas');
    if (subCanvas) {
        const subs = <?= json_encode($acad['subject_breakdown'] ?? []) ?>;
        const subNames = subs.map(s => s.subject);
        const passRates = subs.map(s => s.pass_rate);

        new Chart(subCanvas, {
            type: 'bar',
            data: {
                labels: subNames.length ? subNames : ['Mathematics', 'Science', 'English', 'History'],
                datasets: [{
                    label: 'Pass Rate %',
                    data: passRates.length ? passRates : [85, 78, 92, 88],
                    backgroundColor: '#10b981',
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        min: 0,
                        max: 100,
                        ticks: {
                            callback: v => v + '%'
                        }
                    }
                }
            }
        });
    }

    // 3. Monthly Financial Velocity Chart (if available)
    const finCanvas = document.getElementById('monthlyFinanceCanvas');
    if (finCanvas) {
        const finHistory = <?= json_encode($monthlyFinance['history'] ?? []) ?>;
        const mLabels = finHistory.map(m => m.label);
        const mInvoiced = finHistory.map(m => m.invoiced);
        const mCollected = finHistory.map(m => m.collected);

        new Chart(finCanvas, {
            type: 'bar',
            data: {
                labels: mLabels,
                datasets: [
                    {
                        label: 'Invoiced ($)',
                        data: mInvoiced,
                        backgroundColor: 'rgba(99, 102, 241, 0.4)',
                        borderColor: '#6366f1',
                        borderWidth: 1,
                        borderRadius: 4
                    },
                    {
                        label: 'Collected ($)',
                        data: mCollected,
                        backgroundColor: '#10b981',
                        borderRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: v => '$' + v
                        }
                    }
                }
            }
        });
    }

    // 4. Modal Student Search Filter
    const searchInput = document.getElementById('drilldownSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            const rows = document.querySelectorAll('#drilldownTableBody tr');
            rows.forEach(r => {
                const text = r.textContent.toLowerCase();
                r.style.display = text.includes(query) ? '' : 'none';
            });
        });
    }
});

// Interactive Cohort Student Drilldown Handler
window.openCohortDrilldown = function(classId, className) {
    const modalEl = document.getElementById('cohortDrilldownModal');
    if (!modalEl) return;
    const modal = new bootstrap.Modal(modalEl);
    modal.show();

    document.getElementById('cohortDrilldownModalLabel').textContent = 'Cohort Roster: ' + className;
    document.getElementById('cohortDrilldownSub').textContent = 'Loading student metrics for ' + className + '...';
    const tbody = document.getElementById('drilldownTableBody');
    tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Querying student records...</td></tr>';

    const period = '<?= e($periodKey) ?>';
    const start = '<?= e($customStart ?? '') ?>';
    const end = '<?= e($customEnd ?? '') ?>';
    let url = '<?= e(url('analytics/cohort-drilldown')) ?>?class_id=' + classId + '&period=' + period;
    if (start && end) {
        url += '&start_date=' + encodeURIComponent(start) + '&end_date=' + encodeURIComponent(end);
    }

    fetch(url)
        .then(res => res.json())
        .then(res => {
            if (res.status !== 'success') {
                tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-danger">' + (res.message || 'Unable to retrieve cohort records.') + '</td></tr>';
                return;
            }

            document.getElementById('drilldownPupilCount').textContent = res.student_count + ' pupils';
            document.getElementById('drilldownAvgAtt').textContent = res.class_average_attendance + '%';
            document.getElementById('drilldownAvgScore').textContent = res.class_average_score + '%';
            document.getElementById('cohortDrilldownSub').textContent = 'Reporting Period: ' + res.period + (res.finance_gated ? ' · [Teacher Confidentiality Active]' : '');

            const feeTh = document.getElementById('drilldownFeeHeader');
            if (feeTh) {
                feeTh.style.display = res.finance_gated ? 'none' : '';
            }

            if (!res.students || !res.students.length) {
                tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-muted">No active students enrolled in this cohort.</td></tr>';
                return;
            }

            let html = '';
            res.students.forEach(s => {
                let rBadge = '<span class="badge bg-success-subtle text-success">Normal</span>';
                if (s.risk_status === 'attendance_risk') {
                    rBadge = '<span class="badge bg-warning-subtle text-warning">Attendance Risk</span>';
                } else if (s.risk_status === 'academic_risk') {
                    rBadge = '<span class="badge bg-danger-subtle text-danger">Academic Risk</span>';
                } else if (s.risk_status === 'fee_defaulter') {
                    rBadge = '<span class="badge bg-danger-subtle text-danger">Fee Defaulter</span>';
                }

                const feeTd = res.finance_gated ? '' : ('<td class="' + (s.is_overdue ? 'text-danger fw-bold' : 'text-muted') + '">$' + (s.fee_balance !== null ? s.fee_balance.toFixed(2) : '0.00') + '</td>');

                html += '<tr>' +
                    '<td class="font-monospace text-muted">' + escapeHtml(s.admission_no) + '</td>' +
                    '<td>' + escapeHtml(s.roll_no) + '</td>' +
                    '<td class="fw-semibold text-dark">' + escapeHtml(s.name) + '</td>' +
                    '<td>Section ' + escapeHtml(s.section) + '</td>' +
                    '<td><span class="fw-semibold ' + (s.attendance_rate < 80 ? 'text-danger' : 'text-dark') + '">' + s.attendance_rate + '%</span> (' + s.present_days + '/' + s.recorded_days + ')</td>' +
                    '<td>' + s.evaluations_count + ' evaluated</td>' +
                    '<td class="fw-semibold">' + (s.average_score !== null ? s.average_score + '%' : '-') + '</td>' +
                    '<td>' + (s.pass_rate !== null ? s.pass_rate + '%' : '-') + '</td>' +
                    feeTd +
                    '<td class="text-end">' + rBadge + '</td>' +
                    '</tr>';
            });
            tbody.innerHTML = html;
        })
        .catch(err => {
            tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-danger">Communication failure: ' + escapeHtml(err.message) + '</td></tr>';
        });
};

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Helper to open chatbot with analytical inquiry
window.triggerChatbotPrompt = function(promptText) {
    const bubbleBtn = document.getElementById('cc-ai-bubble-btn');
    const input = document.getElementById('cc-ai-input');
    const sendBtn = document.getElementById('cc-ai-btn-send');
    if (bubbleBtn && input) {
        const panel = document.getElementById('cc-ai-chat-panel');
        if (panel && panel.classList.contains('d-none')) {
            bubbleBtn.click();
        }
        input.value = promptText;
        if (sendBtn) {
            sendBtn.click();
        }
    }
};
</script>
