<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Interoperability</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-diagram-3-fill text-primary me-2"></i><?= e($title) ?>
            </h1>
            <p class="text-muted small mb-0">Secure RESTful API keys, rate-limiting policies, HMAC-SHA256 signed webhooks, and real-time delivery telemetry.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('admin/data') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-file-earmark-spreadsheet me-1"></i> Data Import &amp; Export
            </a>
            <button type="button" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#newApiKeyModal">
                <i class="bi bi-key-fill me-1"></i> Generate API Key
            </button>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#newWebhookModal">
                <i class="bi bi-broadcast me-1"></i> Add Webhook Endpoint
            </button>
        </div>
    </div>

    <!-- Security & Interoperability Architecture Banner -->
    <div class="alert alert-primary border-0 shadow-sm rounded-4 p-4 mb-4">
        <div class="d-flex align-items-start gap-3">
            <div class="fs-2 text-primary"><i class="bi bi-shield-check"></i></div>
            <div class="flex-grow-1">
                <h6 class="fw-bold text-dark mb-1">Secure Enterprise Interoperability Standard</h6>
                <p class="mb-2 small text-secondary">
                    All outbound webhooks are stamped with cryptographic <strong>HMAC-SHA256</strong> signatures (using a unique endpoint secret) in the <code>X-Signature-SHA256</code> header. 
                    Inbound API requests are throttled with sliding 60-second rate-limiting per API key, requiring strict tenant-scoped permission authorization.
                </p>
                <div class="d-flex flex-wrap gap-3 small text-muted">
                    <span><i class="bi bi-lock-fill text-success me-1"></i> HMAC-SHA256 Signatures</span>
                    <span><i class="bi bi-speedometer2 text-primary me-1"></i> Rate Limited (60 req/min default)</span>
                    <span><i class="bi bi-arrow-repeat text-warning me-1"></i> Duplicate Event Prevention</span>
                </div>
            </div>
        </div>
    </div>

    <!-- KPI Metric Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Active API Keys</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= count(array_filter($api_keys, fn($k) => $k['status'] === 'active')) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;"><?= count($api_keys) ?> total provisioned</div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Active Webhooks</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= count(array_filter($webhooks, fn($w) => $w['status'] === 'active')) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Subscribed to institutional events</div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Webhook Deliveries</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= count($deliveries) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Logged event dispatches</div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Default Rate Limit</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">60 <span class="fs-6 text-muted fw-normal">req/min</span></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Sliding window throttling</div>
            </div>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-header bg-white border-bottom p-3">
            <ul class="nav nav-pills card-header-pills" id="integrationTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-semibold" id="api-keys-tab" data-bs-toggle="tab" data-bs-target="#api-keys-pane" type="button" role="tab">
                        <i class="bi bi-key me-1"></i> API Keys &amp; Credentials (<?= count($api_keys) ?>)
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="webhooks-tab" data-bs-toggle="tab" data-bs-target="#webhooks-pane" type="button" role="tab">
                        <i class="bi bi-broadcast me-1"></i> Webhooks &amp; Subscriptions (<?= count($webhooks) ?>)
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="deliveries-tab" data-bs-toggle="tab" data-bs-target="#deliveries-pane" type="button" role="tab">
                        <i class="bi bi-clock-history me-1"></i> Delivery Logs &amp; Retries
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="docs-tab" data-bs-toggle="tab" data-bs-target="#docs-pane" type="button" role="tab">
                        <i class="bi bi-book me-1"></i> REST API Documentation
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body p-4">
            <div class="tab-content" id="integrationTabsContent">

                <!-- Tab 1: API Keys -->
                <div class="tab-pane fade show active" id="api-keys-pane" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-bold text-dark mb-0">Authorized School API Keys</h6>
                        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newApiKeyModal">
                            <i class="bi bi-plus-circle me-1"></i> Generate New Key
                        </button>
                    </div>

                    <?php if (empty($api_keys)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-key text-muted fs-1"></i>
                            <h6 class="fw-bold text-dark mt-2">No API Keys Generated</h6>
                            <p class="text-muted small mb-3">Generate API keys to integrate your mobile app, RFID scanners, or custom school portals.</p>
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newApiKeyModal">
                                Generate First API Key
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                                <thead class="table-light">
                                    <tr>
                                        <th>Key Name</th>
                                        <th>Prefix</th>
                                        <th>Authorized Scopes</th>
                                        <th>Rate Limit</th>
                                        <th>Status</th>
                                        <th>Last Used</th>
                                        <th class="text-end pe-3">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($api_keys as $k): ?>
                                        <tr>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($k['name']) ?></td>
                                            <td><code class="text-muted"><?= htmlspecialchars($k['key_prefix']) ?>••••••••</code></td>
                                            <td>
                                                <?php foreach ($k['scopes_list'] as $scope): ?>
                                                    <span class="badge bg-light text-dark border me-1"><?= htmlspecialchars($scope) ?></span>
                                                <?php endforeach; ?>
                                            </td>
                                            <td><span class="badge bg-secondary-subtle text-secondary"><?= $k['rate_limit_per_minute'] ?> req/min</span></td>
                                            <td>
                                                <?php if ($k['status'] === 'active'): ?>
                                                    <span class="badge bg-success-subtle text-success"><i class="bi bi-check-circle me-1"></i> Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger-subtle text-danger"><i class="bi bi-x-circle me-1"></i> Revoked</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-muted small">
                                                <?= $k['last_used_at'] ? date('M d, H:i', strtotime($k['last_used_at'])) : 'Never used' ?>
                                            </td>
                                            <td class="text-end pe-3">
                                                <?php if ($k['status'] === 'active'): ?>
                                                    <form action="<?= url("admin/integrations/api-keys/{$k['id']}/revoke") ?>" method="POST" class="d-inline" onsubmit="return confirm('Revoke this API Key immediately? Any apps using it will lose access.');">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="btn btn-outline-danger btn-sm">
                                                            <i class="bi bi-trash"></i> Revoke
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <span class="text-muted small">Revoked</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tab 2: Webhooks -->
                <div class="tab-pane fade" id="webhooks-pane" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-bold text-dark mb-0">Registered Webhook Endpoints</h6>
                        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newWebhookModal">
                            <i class="bi bi-plus-circle me-1"></i> Add Webhook Endpoint
                        </button>
                    </div>

                    <?php if (empty($webhooks)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-broadcast text-muted fs-1"></i>
                            <h6 class="fw-bold text-dark mt-2">No Webhooks Registered</h6>
                            <p class="text-muted small mb-3">Subscribe external services to real-time events such as admissions, attendance punches, and fee payments.</p>
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newWebhookModal">
                                Register First Webhook
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                                <thead class="table-light">
                                    <tr>
                                        <th>Endpoint Name</th>
                                        <th>Target URL</th>
                                        <th>Subscribed Events</th>
                                        <th>Status</th>
                                        <th>Deliveries</th>
                                        <th>Last Triggered</th>
                                        <th class="text-end pe-3">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($webhooks as $w): ?>
                                        <tr>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($w['name']) ?></td>
                                            <td><code class="text-muted" style="max-width: 250px; display: inline-block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?= htmlspecialchars($w['target_url']) ?></code></td>
                                            <td>
                                                <?php foreach ($w['events_list'] as $evt): ?>
                                                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle me-1"><?= htmlspecialchars($evt) ?></span>
                                                <?php endforeach; ?>
                                            </td>
                                            <td>
                                                <?php if ($w['status'] === 'active'): ?>
                                                    <span class="badge bg-success-subtle text-success"><i class="bi bi-check-circle me-1"></i> Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary-subtle text-secondary"><i class="bi bi-pause-circle me-1"></i> Disabled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="text-dark fw-semibold"><?= (int)$w['total_deliveries'] ?></span>
                                                <?php if ((int)$w['total_failed'] > 0): ?>
                                                    <span class="text-danger small ms-1">(<?= (int)$w['total_failed'] ?> failed)</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-muted small">
                                                <?= $w['last_triggered_at'] ? date('M d, H:i', strtotime($w['last_triggered_at'])) : 'Never' ?>
                                            </td>
                                            <td class="text-end pe-3">
                                                <div class="btn-group btn-group-sm">
                                                    <!-- Test Ping Form -->
                                                    <form action="<?= url("admin/integrations/webhooks/{$w['id']}/test") ?>" method="POST" class="d-inline">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="btn btn-outline-success btn-sm" title="Dispatch simulated test event">
                                                            <i class="bi bi-play-circle"></i> Test Ping
                                                        </button>
                                                    </form>
                                                    <!-- Delete Form -->
                                                    <form action="<?= url("admin/integrations/webhooks/{$w['id']}/delete") ?>" method="POST" class="d-inline ms-1" onsubmit="return confirm('Delete this webhook endpoint and its delivery logs?');">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete endpoint">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tab 3: Delivery Logs -->
                <div class="tab-pane fade" id="deliveries-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">Recent Webhook Deliveries &amp; Retry Console</h6>

                    <?php if (empty($deliveries)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-clock-history text-muted fs-1"></i>
                            <h6 class="fw-bold text-dark mt-2">No Delivery Logs Recorded</h6>
                            <p class="text-muted small mb-0">Delivery logs will appear here when events are triggered or test pings are sent.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                                <thead class="table-light">
                                    <tr>
                                        <th>Timestamp</th>
                                        <th>Event Type</th>
                                        <th>Target Webhook</th>
                                        <th>HTTP Response</th>
                                        <th>HMAC-SHA256 Signature</th>
                                        <th>Status</th>
                                        <th class="text-end pe-3">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($deliveries as $d): ?>
                                        <tr>
                                            <td class="text-muted small"><?= date('M d, H:i:s', strtotime($d['created_at'])) ?></td>
                                            <td><span class="badge bg-primary text-white font-monospace"><?= htmlspecialchars($d['event_type']) ?></span></td>
                                            <td class="fw-semibold text-dark"><?= htmlspecialchars($d['webhook_name'] ?? 'Webhook') ?></td>
                                            <td>
                                                <?php if ((int)$d['response_code'] >= 200 && (int)$d['response_code'] < 300): ?>
                                                    <span class="badge bg-success-subtle text-success">HTTP <?= $d['response_code'] ?> OK</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger-subtle text-danger">HTTP <?= $d['response_code'] ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><code class="text-muted small" title="<?= htmlspecialchars($d['signature_sha256']) ?>"><?= substr($d['signature_sha256'], 0, 16) ?>...</code></td>
                                            <td>
                                                <?php if ($d['status'] === 'delivered'): ?>
                                                    <span class="text-success small fw-semibold"><i class="bi bi-check-circle-fill"></i> Delivered</span>
                                                <?php else: ?>
                                                    <span class="text-danger small fw-semibold"><i class="bi bi-exclamation-triangle-fill"></i> Failed</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end pe-3">
                                                <form action="<?= url("admin/integrations/deliveries/{$d['id']}/retry") ?>" method="POST" class="d-inline">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="btn btn-outline-secondary btn-sm" title="Re-dispatch this delivery">
                                                        <i class="bi bi-arrow-clockwise"></i> Retry
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tab 4: REST API Documentation -->
                <div class="tab-pane fade" id="docs-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">Enterprise REST API v1 Reference</h6>
                    <p class="text-muted small mb-4">Integrate your hardware terminals, mobile applications, and third-party systems using secure token authentication.</p>

                    <div class="accordion" id="apiAccordion">
                        <!-- Endpoint 1 -->
                        <div class="accordion-item border rounded-3 mb-2">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 px-3 fw-bold small" type="button" data-bs-toggle="collapse" data-bs-target="#ep1">
                                    <span class="badge bg-success me-2">GET</span> <code>/api/v1/students</code> — List &amp; Filter Students
                                </button>
                            </h2>
                            <div id="ep1" class="accordion-collapse collapse" data-bs-parent="#apiAccordion">
                                <div class="accordion-body small bg-light">
                                    <p class="mb-1 text-muted">Headers required: <code>X-API-Key: sk_live_...</code> or <code>Authorization: Bearer &lt;token&gt;</code></p>
                                    <p class="mb-0 text-muted">Query parameters: <code>page</code>, <code>limit</code>, <code>class_id</code>, <code>search</code>.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Endpoint 2 -->
                        <div class="accordion-item border rounded-3 mb-2">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 px-3 fw-bold small" type="button" data-bs-toggle="collapse" data-bs-target="#ep2">
                                    <span class="badge bg-primary me-2">POST</span> <code>/api/v1/students</code> — Create Student Record
                                </button>
                            </h2>
                            <div id="ep2" class="accordion-collapse collapse" data-bs-parent="#apiAccordion">
                                <div class="accordion-body small bg-light">
                                    <p class="mb-1 text-muted">JSON Body: <code>{"first_name": "John", "last_name": "Doe", "gender": "male", "class_id": 1}</code></p>
                                    <p class="mb-0 text-muted">Dispatches <code>student.admitted</code> webhook event automatically upon success.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Endpoint 3 -->
                        <div class="accordion-item border rounded-3 mb-2">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 px-3 fw-bold small" type="button" data-bs-toggle="collapse" data-bs-target="#ep3">
                                    <span class="badge bg-success me-2">GET</span> <code>/api/v1/attendance</code> — Query Student Attendance
                                </button>
                            </h2>
                            <div id="ep3" class="accordion-collapse collapse" data-bs-parent="#apiAccordion">
                                <div class="accordion-body small bg-light">
                                    <p class="mb-0 text-muted">Query parameter: <code>date=YYYY-MM-DD</code>. Returns attendance matrix for the school tenant.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Endpoint 4 -->
                        <div class="accordion-item border rounded-3 mb-2">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 px-3 fw-bold small" type="button" data-bs-toggle="collapse" data-bs-target="#ep4">
                                    <span class="badge bg-primary me-2">POST</span> <code>/api/v1/attendance</code> — Log Student Attendance Punch
                                </button>
                            </h2>
                            <div id="ep4" class="accordion-collapse collapse" data-bs-parent="#apiAccordion">
                                <div class="accordion-body small bg-light">
                                    <p class="mb-1 text-muted">JSON Body: <code>{"student_id": 6, "status": "present", "date": "2026-10-21"}</code></p>
                                    <p class="mb-0 text-muted">Dispatches <code>attendance.marked</code> webhook event automatically.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal: Generate API Key -->
<div class="modal fade" id="newApiKeyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form action="<?= url('admin/integrations/api-keys') ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0 pt-4 px-4">
                    <h5 class="modal-title fw-bold">
                        <i class="bi bi-key-fill text-primary me-2"></i>Generate School API Key
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Key Label / Integration Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., Mobile App Gateway, Gate RFID Scanner" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">Authorized Scopes</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="students.read" id="sc1" checked>
                                    <label class="form-check-label small" for="sc1">students.read</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="students.write" id="sc2" checked>
                                    <label class="form-check-label small" for="sc2">students.write</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="attendance.read" id="sc3" checked>
                                    <label class="form-check-label small" for="sc3">attendance.read</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="attendance.write" id="sc4" checked>
                                    <label class="form-check-label small" for="sc4">attendance.write</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="finance.read" id="sc5">
                                    <label class="form-check-label small" for="sc5">finance.read</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="scopes[]" value="exams.read" id="sc6">
                                    <label class="form-check-label small" for="sc6">exams.read</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">Rate Limit (Requests per minute)</label>
                        <input type="number" name="rate_limit_per_minute" class="form-control" value="60" min="10" max="1000">
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 px-4 pb-4">
                    <button type="button" class="btn btn-light rounded-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-3 fw-semibold">Generate Key</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Add Webhook Endpoint -->
<div class="modal fade" id="newWebhookModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form action="<?= url('admin/integrations/webhooks') ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0 pt-4 px-4">
                    <h5 class="modal-title fw-bold">
                        <i class="bi bi-broadcast text-primary me-2"></i>Register Webhook Endpoint
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Endpoint Identifier Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. ERP Accounting Sync, SMS Dispatch Relay" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">Target URL (HTTPS Recommended)</label>
                        <input type="url" name="target_url" class="form-control" placeholder="https://api.thirdparty.com/webhooks/school" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">Subscribed Events</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="student.admitted" id="ev1" checked>
                                    <label class="form-check-label small" for="ev1">student.admitted</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="attendance.marked" id="ev2" checked>
                                    <label class="form-check-label small" for="ev2">attendance.marked</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="fee.paid" id="ev3" checked>
                                    <label class="form-check-label small" for="ev3">fee.paid</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="exam.published" id="ev4">
                                    <label class="form-check-label small" for="ev4">exam.published</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 px-4 pb-4">
                    <button type="button" class="btn btn-light rounded-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-3 fw-semibold">Save Webhook</button>
                </div>
            </form>
        </div>
    </div>
</div>
