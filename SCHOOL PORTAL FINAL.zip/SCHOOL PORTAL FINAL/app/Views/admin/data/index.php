<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Data Operations</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-file-earmark-spreadsheet-fill text-success me-2"></i><?= e($title) ?>
            </h1>
            <p class="text-muted small mb-0">Transactional bulk data imports, automated duplicate checks, row-level error validation, and isolated tenant CSV exports.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('admin/integrations') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-diagram-3 me-1"></i> API &amp; Webhooks Center
            </a>
            <a href="<?= url("admin/data/template/{$active_entity}") ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-download me-1"></i> Download <?= htmlspecialchars($definition['label']) ?> CSV Template
            </a>
            <a href="<?= url("admin/data/export/{$active_entity}") ?>" class="btn btn-success btn-sm shadow-sm fw-semibold">
                <i class="bi bi-cloud-arrow-down-fill me-1"></i> Export <?= htmlspecialchars($definition['label']) ?> (CSV)
            </a>
        </div>
    </div>

    <!-- Entity Navigation Pills -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">
            <div class="d-flex flex-wrap gap-2">
                <?php 
                $entities = [
                    'students' => ['icon' => 'mortarboard', 'label' => 'Students Directory'],
                    'staff' => ['icon' => 'person-workspace', 'label' => 'Staff & Faculty'],
                    'classes' => ['icon' => 'diagram-2', 'label' => 'Academic Classes'],
                    'subjects' => ['icon' => 'book', 'label' => 'Curriculum Subjects'],
                    'fees' => ['icon' => 'cash-stack', 'label' => 'Fee Invoices & Billing']
                ];
                foreach ($entities as $key => $info): ?>
                    <a href="<?= url("admin/data?entity={$key}") ?>" class="btn btn-sm <?= ($active_entity === $key) ? 'btn-primary shadow-sm fw-bold' : 'btn-light border' ?> d-inline-flex align-items-center gap-1 rounded-3 px-3 py-2">
                        <i class="bi bi-<?= $info['icon'] ?>"></i>
                        <span><?= e($info['label']) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Step 1: Upload & Scan Section -->
    <div class="row g-4 mb-4">
        <!-- Upload Form Card -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4 bg-white h-100">
                <div class="card-header bg-white border-bottom p-3">
                    <h6 class="fw-bold text-dark mb-0">
                        <i class="bi bi-cloud-arrow-up text-primary me-2"></i>Upload <?= htmlspecialchars($definition['label']) ?> CSV File
                    </h6>
                </div>
                <div class="card-body p-4">
                    <form action="<?= url('admin/data/preview') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <input type="hidden" name="entity" value="<?= htmlspecialchars($active_entity) ?>">

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Choose CSV Spreadsheet</label>
                            <input type="file" name="csv_file" class="form-control form-control-lg" accept=".csv,text/csv" required>
                            <div class="form-text small">
                                Supported format: UTF-8 encoded CSV. Headers must match the template exactly.
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pt-2">
                            <a href="<?= url("admin/data/template/{$active_entity}") ?>" class="text-decoration-none small text-muted">
                                <i class="bi bi-question-circle me-1"></i>Need the format? Download sample template
                            </a>
                            <button type="submit" class="btn btn-primary rounded-3 px-4 fw-semibold shadow-sm">
                                <i class="bi bi-search me-1"></i> Scan &amp; Preview File
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Specifications & Guardrails Card -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4 bg-light h-100">
                <div class="card-body p-4">
                    <h6 class="fw-bold text-dark mb-2">
                        <i class="bi bi-shield-check text-success me-1"></i>Data Integrity &amp; Safety Guardrails
                    </h6>
                    <ul class="text-muted small ps-3 mb-3" style="line-height: 1.8;">
                        <li><strong>Mandatory Columns:</strong> <?= implode(', ', array_map('htmlspecialchars', $definition['required'])) ?></li>
                        <li><strong>Duplicate Protection:</strong> Rows matching existing admission numbers, employee IDs, or class names are flagged automatically.</li>
                        <li><strong>Transactional Atomicity:</strong> All valid rows are imported inside an isolated MySQL database transaction.</li>
                        <li><strong>Never Overwrite:</strong> Existing records are never silently modified.</li>
                    </ul>

                    <div class="p-3 bg-white border rounded-3 small">
                        <div class="fw-bold text-dark mb-1">Allowed Headers:</div>
                        <code><?= implode(', ', $definition['headers']) ?></code>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Step 2: Preview & Validation Results (If scan was just performed) -->
    <?php if (!empty($preview) && !empty($preview['valid'])): ?>
        <div id="preview" class="card border-0 shadow-sm rounded-4 bg-white mb-4 border-start border-4 <?= ($preview['error_count'] > 0) ? 'border-warning' : 'border-success' ?>">
            <div class="card-header bg-white border-bottom p-3 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
                <div>
                    <h6 class="fw-bold text-dark mb-0">
                        <i class="bi bi-clipboard-check text-primary me-2"></i>Scan Validation Preview: <?= htmlspecialchars($definition['label']) ?>
                    </h6>
                    <div class="text-muted small">Scanned <?= (int)$preview['total_rows_scanned'] ?> rows from uploaded file.</div>
                </div>
                <div>
                    <?php if ($preview['can_commit']): ?>
                        <form action="<?= url('admin/data/commit') ?>" method="POST" class="d-inline" onsubmit="return confirm('Commit <?= $preview['valid_count'] ?> valid records to database inside an atomic transaction?');">
                            <?= csrf_field() ?>
                            <input type="hidden" name="entity" value="<?= htmlspecialchars($active_entity) ?>">
                            <input type="hidden" name="valid_rows_json" value="<?= htmlspecialchars(json_encode($preview['valid_rows'])) ?>">
                            <button type="submit" class="btn btn-success fw-bold shadow-sm rounded-3">
                                <i class="bi bi-check-all me-1"></i> Commit <?= $preview['valid_count'] ?> Valid Record(s)
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-body p-4">
                <!-- Summary Metrics -->
                <div class="row g-3 mb-4">
                    <div class="col-4">
                        <div class="p-3 rounded-3 bg-success-subtle text-success border border-success-subtle text-center">
                            <div class="h3 fw-bold mb-0"><?= $preview['valid_count'] ?></div>
                            <div class="small fw-semibold">Ready to Import</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-3 rounded-3 bg-warning-subtle text-warning border border-warning-subtle text-center">
                            <div class="h3 fw-bold mb-0"><?= $preview['duplicate_count'] ?></div>
                            <div class="small fw-semibold">Duplicates Detected</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-3 rounded-3 bg-danger-subtle text-danger border border-danger-subtle text-center">
                            <div class="h3 fw-bold mb-0"><?= $preview['error_count'] ?></div>
                            <div class="small fw-semibold">Syntax / Field Errors</div>
                        </div>
                    </div>
                </div>

                <!-- Duplicate Rows Warning Box -->
                <?php if (!empty($preview['duplicate_rows'])): ?>
                    <div class="alert alert-warning border-0 p-3 mb-3 small">
                        <h6 class="fw-bold mb-2"><i class="bi bi-exclamation-triangle-fill me-1"></i>Duplicates Flagged (Will Be Skipped Safely):</h6>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($preview['duplicate_rows'] as $dup): ?>
                                <li><strong>Row <?= $dup['row_number'] ?>:</strong> <?= htmlspecialchars($dup['reason']) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Error Rows Box -->
                <?php if (!empty($preview['error_rows'])): ?>
                    <div class="alert alert-danger border-0 p-3 mb-3 small">
                        <h6 class="fw-bold mb-2"><i class="bi bi-x-circle-fill me-1"></i>Row Errors (Cannot be imported):</h6>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($preview['error_rows'] as $err): ?>
                                <li><strong>Row <?= $err['row_number'] ?>:</strong> <?= implode(', ', array_map('htmlspecialchars', $err['errors'])) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Column Mapping Summary -->
                <?php if (!empty($preview['column_mapping_applied'])): ?>
                    <div class="p-3 bg-light border rounded-3 mb-3 small">
                        <div class="fw-bold text-dark mb-1"><i class="bi bi-shuffle text-primary me-1"></i>Column Mapping Applied:</div>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($preview['column_mapping_applied'] as $rawCol => $targetCol): ?>
                                <span class="badge bg-white text-dark border p-2">
                                    <code><?= htmlspecialchars($rawCol) ?></code> &rarr; <span class="text-primary fw-bold"><?= htmlspecialchars($targetCol) ?></span>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Preview Table of Valid Rows -->
                <?php if (!empty($preview['valid_rows'])): ?>
                    <h6 class="fw-bold text-dark mb-2">Valid Rows Ready for Ingestion (First 15 sample):</h6>
                    <div class="table-responsive border rounded-3">
                        <table class="table table-hover align-middle mb-0" style="font-size: 12px;">
                            <thead class="table-light">
                                <tr>
                                    <th># Row</th>
                                    <?php foreach ($definition['headers'] as $h): ?>
                                        <th><?= htmlspecialchars(ucwords(str_replace('_', ' ', $h))) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($preview['valid_rows'], 0, 15) as $vRow): ?>
                                    <tr>
                                        <td class="text-muted fw-bold"><?= $vRow['row_number'] ?></td>
                                        <?php foreach ($definition['headers'] as $h): ?>
                                            <td><?= htmlspecialchars($vRow['record'][$h] ?? '') ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Step 3: Historical Import Batches & Safe Rollback Console -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mt-4">
        <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
            <div>
                <h6 class="fw-bold text-dark mb-0">
                    <i class="bi bi-clock-history text-secondary me-2"></i>Institutional Import History &amp; Safe Rollback
                </h6>
                <div class="text-muted small">Audit trail of bulk data ingestions with transaction-safe reversal for unreferenced records.</div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">Batch ID</th>
                            <th>Entity</th>
                            <th>Records Ingested</th>
                            <th>Status</th>
                            <th>Initiated By</th>
                            <th>Timestamp</th>
                            <th class="text-end pe-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($history)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="bi bi-inbox fs-4 d-block mb-1"></i>
                                    No bulk import batches recorded yet.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($history as $job): ?>
                                <tr>
                                    <td class="ps-3 fw-bold text-dark">#<?= (int)$job['id'] ?></td>
                                    <td>
                                        <span class="badge bg-secondary-subtle text-secondary text-uppercase px-2 py-1">
                                            <?= htmlspecialchars($job['entity']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?= (int)$job['success_count'] ?></strong> / <?= (int)$job['total_rows'] ?> rows
                                    </td>
                                    <td>
                                        <?php if ((int)$job['is_rolled_back'] === 1): ?>
                                            <span class="badge bg-warning-subtle text-warning border border-warning-subtle">
                                                <i class="bi bi-arrow-counterclockwise me-1"></i>Rolled Back
                                            </span>
                                        <?php elseif ($job['status'] === 'completed'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle">
                                                <i class="bi bi-check-circle me-1"></i>Completed
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                                <?= htmlspecialchars($job['status']) ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-muted small">
                                        <?= htmlspecialchars($job['user_name'] ?? 'Administrator') ?>
                                    </td>
                                    <td class="text-muted small">
                                        <?= date('d M Y, h:i A', strtotime($job['created_at'])) ?>
                                    </td>
                                    <td class="text-end pe-3">
                                        <?php if ((int)$job['is_rolled_back'] === 0 && (int)$job['success_count'] > 0): ?>
                                            <form action="<?= url("admin/data/rollback/{$job['id']}") ?>" method="POST" class="d-inline" onsubmit="return confirm('Safe Rollback: Are you sure you want to reverse Batch #<?= $job['id'] ?>? Any records with dependent operations will be safeguarded.');">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-outline-danger btn-sm rounded-3 py-1 px-2 fw-semibold">
                                                    <i class="bi bi-arrow-counterclockwise me-1"></i>Rollback Batch
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted small fst-italic">No action</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
