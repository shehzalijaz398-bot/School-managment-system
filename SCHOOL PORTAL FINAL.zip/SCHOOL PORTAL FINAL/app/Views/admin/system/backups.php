<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Disaster Recovery</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-cloud-arrow-down-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">AES-256 encrypted database snapshots, SHA-256 checksum verification, and non-destructive dry-run sandbox testing.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('admin/security') ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-shield-lock me-1"></i> Security Center
            </a>
            <a href="<?= url('admin/system/health') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-heart-pulse me-1"></i> System Health
            </a>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createBackupModal">
                <i class="bi bi-plus-circle me-1"></i> Create Encrypted Backup
            </button>
        </div>
    </div>

    <!-- Disaster Recovery Architecture & Safety Banner -->
    <div class="alert alert-info border-0 shadow-sm rounded-4 p-4 mb-4">
        <div class="d-flex align-items-start gap-3">
            <div class="fs-2 text-primary"><i class="bi bi-shield-shaded"></i></div>
            <div class="flex-grow-1">
                <h6 class="fw-bold text-dark mb-1">Zero Production Data Risk Guarantee</h6>
                <p class="mb-2 small text-secondary">
                    All snapshots are compressed with GZIP, encrypted with <strong>AES-256-CBC</strong>, and stamped with a cryptographic <strong>SHA-256</strong> checksum. 
                    Restoration simulations run in an isolated memory sandbox that tests decryption, decompression, and SQL syntax without writing to or altering production tables.
                </p>
                <div class="d-flex flex-wrap gap-3 small text-muted">
                    <span><i class="bi bi-lock-fill text-success me-1"></i> Encrypted at Rest</span>
                    <span><i class="bi bi-fingerprint text-primary me-1"></i> SHA-256 Tamper Evident</span>
                    <span><i class="bi bi-safe2-fill text-warning me-1"></i> Sandbox Test Verified</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Vault Metric Cards -->
    <div class="row g-3 mb-4">
        <!-- 1. Total Snapshots -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Snapshots in Vault</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= count($backups) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Active tenant snapshots</div>
            </div>
        </div>

        <!-- 2. Vault Storage Footprint -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Vault Storage Size</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= round($total_size_bytes / (1024 * 1024), 2) ?> <span class="fs-6 text-muted fw-normal">MB</span>
                </div>
                <div class="text-muted small mt-1" style="font-size: 11px;">GZIP compressed &amp; encrypted</div>
            </div>
        </div>

        <!-- 3. Verified Snapshots -->
        <?php 
        $verifiedCount = count(array_filter($backups, fn($b) => $b['status'] === 'verified' || !empty($b['verified_at'])));
        ?>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Integrity Verified</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $verifiedCount ?> / <?= count($backups) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Pass SHA-256 &amp; decryption checks</div>
            </div>
        </div>

        <!-- 4. Retention Policy -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Snapshot Retention</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">30 <span class="fs-6 text-muted fw-normal">Days</span></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Automated rotation policy</div>
            </div>
        </div>
    </div>

    <!-- Snapshots Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold text-dark mb-0">
                <i class="bi bi-archive me-2 text-primary"></i>Encrypted Snapshot Vault
            </h6>
            <span class="badge bg-light text-muted border"><?= count($backups) ?> Available</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($backups)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-cloud-slash text-muted fs-1"></i>
                    <h6 class="fw-bold text-dark mt-2">No Backups in Vault</h6>
                    <p class="text-muted small mb-3">Create your first encrypted snapshot to safeguard institutional records.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#createBackupModal">
                        <i class="bi bi-plus-circle me-1"></i> Create First Snapshot
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Snapshot Identifier</th>
                                <th>Scope</th>
                                <th>Size &amp; Encryption</th>
                                <th>SHA-256 Checksum</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th class="pe-4 text-end">Disaster Recovery Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backups as $b): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($b['backup_name']) ?></div>
                                        <div class="text-muted small" style="font-size: 11px;">
                                            Created by: <?= htmlspecialchars($b['creator_name'] ?? 'System') ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($b['backup_type'] === 'tenant_data'): ?>
                                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                                <i class="bi bi-building me-1"></i> Tenant Data
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-dark-subtle text-dark border border-dark-subtle">
                                                <i class="bi bi-database me-1"></i> Full Database
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= round(((int)$b['file_size']) / 1024, 1) ?> KB</div>
                                        <span class="badge bg-light text-muted border" style="font-size: 10px;">
                                            <i class="bi bi-key-fill text-warning me-1"></i><?= htmlspecialchars($b['encryption_cipher'] ?? 'AES-256-CBC') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <code class="text-muted small" title="<?= htmlspecialchars($b['checksum_sha256']) ?>">
                                            <?= substr($b['checksum_sha256'], 0, 14) ?>...
                                        </code>
                                    </td>
                                    <td>
                                        <?php if ($b['status'] === 'verified'): ?>
                                            <span class="badge bg-success-subtle text-success">
                                                <i class="bi bi-patch-check-fill me-1"></i> Verified
                                            </span>
                                        <?php elseif ($b['status'] === 'completed'): ?>
                                            <span class="badge bg-primary-subtle text-primary">
                                                <i class="bi bi-check-circle me-1"></i> Ready
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger">
                                                <i class="bi bi-x-circle me-1"></i> <?= htmlspecialchars($b['status']) ?>
                                            </span>
                                        <?php endif; ?>

                                        <?php if (!empty($b['verified_at'])): ?>
                                            <div class="text-muted small" style="font-size: 10px;">
                                                Checked: <?= date('M d, H:i', strtotime($b['verified_at'])) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-muted small">
                                        <?= date('M d, Y H:i', strtotime($b['created_at'])) ?>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <div class="btn-group btn-group-sm">
                                            <!-- Verify Integrity Button -->
                                            <form action="<?= url("admin/system/backups/{$b['id']}/verify") ?>" method="POST" class="d-inline">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-outline-success btn-sm" title="Verify SHA-256 Checksum &amp; AES Decryption">
                                                    <i class="bi bi-shield-check"></i> Verify
                                                </button>
                                            </form>

                                            <!-- Sandbox Dry-Run Simulation Button -->
                                            <form action="<?= url("admin/system/backups/{$b['id']}/sandbox-restore") ?>" method="POST" class="d-inline ms-1">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-outline-warning btn-sm text-dark" title="Simulate Dry-Run Restoration in isolated memory (Zero data altered)">
                                                    <i class="bi bi-play-circle"></i> Dry-Run
                                                </button>
                                            </form>

                                            <!-- Download Archive Button -->
                                            <a href="<?= url("admin/system/backups/{$b['id']}/download") ?>" class="btn btn-outline-primary btn-sm ms-1" title="Download Encrypted GZIP Archive">
                                                <i class="bi bi-download"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal: Create Encrypted Backup -->
<div class="modal fade" id="createBackupModal" tabindex="-1" aria-labelledby="createBackupModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form action="<?= url('admin/system/backups/create') ?>" method="POST">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0 pt-4 px-4">
                    <h5 class="modal-title fw-bold" id="createBackupModalLabel">
                        <i class="bi bi-shield-lock text-primary me-2"></i>Create Encrypted Snapshot
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <p class="text-muted small mb-3">
                        Select the snapshot scope. All snapshots are encrypted with AES-256-CBC and protected with SHA-256 checksums.
                    </p>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">Backup Scope</label>
                        <div class="form-check p-3 border rounded-3 mb-2 bg-light">
                            <input class="form-check-input ms-0 me-2" type="radio" name="backup_type" id="typeTenant" value="tenant_data" checked>
                            <label class="form-check-label fw-semibold text-dark" for="typeTenant">
                                Isolated School Tenant Data (Recommended)
                                <div class="text-muted small fw-normal">Exports all students, academics, finance, HR, and settings for this school tenant only.</div>
                            </label>
                        </div>
                        <div class="form-check p-3 border rounded-3 bg-light">
                            <input class="form-check-input ms-0 me-2" type="radio" name="backup_type" id="typeFull" value="full_database">
                            <label class="form-check-label fw-semibold text-dark" for="typeFull">
                                Complete Institution Database
                                <div class="text-muted small fw-normal">Exports the full database catalog including tenant tables and master schemas.</div>
                            </label>
                        </div>
                    </div>

                    <div class="alert alert-warning border-0 p-3 small mb-0">
                        <i class="bi bi-info-circle-fill me-1"></i>
                        The snapshot file will be stored in <code>storage/backups/</code> with an AES-256 cryptographic envelope. Keep encryption keys secure.
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 px-4 pb-4">
                    <button type="button" class="btn btn-light rounded-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-3 fw-semibold">
                        <i class="bi bi-lock-fill me-1"></i> Generate Encrypted Snapshot
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
