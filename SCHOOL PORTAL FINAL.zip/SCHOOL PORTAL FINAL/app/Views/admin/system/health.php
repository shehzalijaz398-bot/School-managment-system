<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Operational Monitoring</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-heart-pulse-fill text-danger me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Real-time health telemetry, database performance, storage permissions, and safe diagnostic monitoring.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('admin/security') ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-shield-lock me-1"></i> Security Center
            </a>
            <a href="<?= url('admin/system/backups') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-cloud-arrow-down me-1"></i> Disaster Recovery Vault
            </a>
            <button onclick="window.location.reload();" class="btn btn-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-arrow-clockwise me-1"></i> Refresh Telemetry
            </button>
        </div>
    </div>

    <!-- Health Score & Primary Status Banners -->
    <div class="row g-3 mb-4">
        <!-- 1. Overall System Health Score -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ($overview['health_score'] >= 85) ? 'border-success' : (($overview['health_score'] >= 60) ? 'border-warning' : 'border-danger') ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">System Health Score</div>
                <div class="d-flex align-items-baseline gap-2 mt-1">
                    <span class="h3 fw-bold mb-0 <?= ($overview['health_score'] >= 85) ? 'text-success' : (($overview['health_score'] >= 60) ? 'text-warning' : 'text-danger') ?>">
                        <?= $overview['health_score'] ?>%
                    </span>
                    <span class="badge rounded-pill <?= ($overview['overall_status'] === 'healthy') ? 'bg-success-subtle text-success' : (($overview['overall_status'] === 'degraded') ? 'bg-warning-subtle text-warning' : 'bg-danger-subtle text-danger') ?> fw-bold text-uppercase" style="font-size: 10px;">
                        <?= htmlspecialchars($overview['overall_status']) ?>
                    </span>
                </div>
                <div class="text-muted small mt-2" style="font-size: 11px;">
                    Checked: <?= date('M d, H:i:s', strtotime($overview['checked_at'])) ?>
                </div>
            </div>
        </div>

        <!-- 2. Database Connectivity & Ping Latency -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ($overview['database']['status'] === 'operational' && $overview['database']['latency_ms'] < 50) ? 'border-success' : 'border-warning' ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Database Latency</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= $overview['database']['latency_ms'] ?> <span class="fs-6 text-muted fw-normal">ms</span>
                </div>
                <div class="text-muted small mt-2" style="font-size: 11px;">
                    <i class="bi bi-database me-1"></i> <?= (int)$overview['database']['total_tables'] ?> tables &middot; <?= $overview['database']['db_size_mb'] ?> MB data
                </div>
            </div>
        </div>

        <!-- 3. Storage Health & Disk Capacity -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ($overview['storage']['writable_failures'] === 0) ? 'border-success' : 'border-danger' ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Disk &amp; Storage Permissions</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= $overview['storage']['disk_free_gb'] ?> <span class="fs-6 text-muted fw-normal">GB free</span>
                </div>
                <div class="text-muted small mt-2" style="font-size: 11px;">
                    <?php if ($overview['storage']['writable_failures'] === 0): ?>
                        <span class="text-success"><i class="bi bi-check-circle-fill"></i> All storage paths writable</span>
                    <?php else: ?>
                        <span class="text-danger"><i class="bi bi-exclamation-triangle-fill"></i> <?= $overview['storage']['writable_failures'] ?> path(s) permission denied</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- 4. Background Automations & Integration Status -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ($overview['automations']['failed_automations_24h'] === 0) ? 'border-info' : 'border-warning' ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Automations (24h)</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= (int)$overview['automations']['executions_24h'] ?> <span class="fs-6 text-muted fw-normal">runs</span>
                </div>
                <div class="small mt-2" style="font-size: 11px;">
                    <span class="text-muted"><?= (int)$overview['automations']['active_rules_count'] ?> active rules</span>
                    &middot;
                    <span class="<?= ($overview['automations']['failed_automations_24h'] > 0) ? 'text-danger fw-bold' : 'text-success' ?>">
                        <?= (int)$overview['automations']['failed_automations_24h'] ?> failed
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Diagnostic Tabs -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-header bg-white border-bottom p-3">
            <ul class="nav nav-pills card-header-pills" id="healthTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-semibold" id="db-tab" data-bs-toggle="tab" data-bs-target="#db-pane" type="button" role="tab">
                        <i class="bi bi-database me-1"></i> Database Health
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="storage-tab" data-bs-toggle="tab" data-bs-target="#storage-pane" type="button" role="tab">
                        <i class="bi bi-folder-check me-1"></i> Storage &amp; Paths
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="php-tab" data-bs-toggle="tab" data-bs-target="#php-pane" type="button" role="tab">
                        <i class="bi bi-cpu me-1"></i> PHP Runtime Environment
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="integrations-tab" data-bs-toggle="tab" data-bs-target="#integrations-pane" type="button" role="tab">
                        <i class="bi bi-diagram-3 me-1"></i> Integrations &amp; Channels
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-semibold" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs-pane" type="button" role="tab">
                        <i class="bi bi-shield-check me-1"></i> Error Diagnostics &amp; Telemetry
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body p-4">
            <div class="tab-content" id="healthTabsContent">
                
                <!-- Tab 1: Database Health -->
                <div class="tab-pane fade show active" id="db-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">Database Engine &amp; Connectivity Metrics</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Server Version</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['database']['version']) ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Active Database</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['database']['db_name']) ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Character Encoding</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['database']['character_set']) ?> / <?= htmlspecialchars($overview['database']['collation']) ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Ping Latency</div>
                                <div class="fw-bold <?= ($overview['database']['latency_ms'] < 50) ? 'text-success' : 'text-warning' ?> mt-1">
                                    <?= $overview['database']['latency_ms'] ?> ms (Real-time probe)
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Index Integrity & Optimization Status -->
                    <div class="border rounded-3 p-3 bg-white">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold mb-0 text-dark">
                                <i class="bi bi-lightning-charge text-warning me-1"></i> Query Optimization &amp; Index Status
                            </h6>
                            <span class="badge bg-success-subtle text-success fw-bold">
                                <?= $overview['slow_queries']['tables_with_primary_keys'] ?> / <?= $overview['slow_queries']['total_tables'] ?> Tables Indexed
                            </span>
                        </div>
                        <p class="text-muted small mb-3">All production database tables are verified for primary keys and tenant-isolation indexes (`school_id`).</p>
                        
                        <?php if (empty($overview['slow_queries']['missing_pk_tables'])): ?>
                            <div class="alert alert-success d-flex align-items-center mb-0 py-2 px-3 small">
                                <i class="bi bi-check-circle-fill me-2 fs-6"></i>
                                <div><strong>Optimal Indexing:</strong> All inspected database tables have primary keys configured. Fast tenant-filtered query paths are available.</div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning mb-0 py-2 px-3 small">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                <strong>Tables lacking primary keys:</strong> <?= implode(', ', array_map('htmlspecialchars', $overview['slow_queries']['missing_pk_tables'])) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Tab 2: Storage & Directory Security -->
                <div class="tab-pane fade" id="storage-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">Application Storage &amp; Filesystem Permissions</h6>
                    <p class="text-muted small mb-3">The application requires strict write permissions to encrypted backup storage, session logs, and isolated tenant uploads.</p>
                    
                    <!-- Disk Space Meter -->
                    <div class="mb-4 p-3 bg-light rounded-3">
                        <div class="d-flex justify-content-between text-muted small mb-1">
                            <span>Disk Usage: <strong><?= $overview['storage']['disk_percent_used'] ?>%</strong></span>
                            <span><?= $overview['storage']['disk_free_gb'] ?> GB Available of <?= $overview['storage']['disk_total_gb'] ?> GB</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar <?= ($overview['storage']['disk_percent_used'] > 90) ? 'bg-danger' : (($overview['storage']['disk_percent_used'] > 75) ? 'bg-warning' : 'bg-primary') ?>" 
                                 role="progressbar" 
                                 style="width: <?= min(100, $overview['storage']['disk_percent_used']) ?>%;">
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                            <thead class="table-light">
                                <tr>
                                    <th>Target Directory</th>
                                    <th>Relative Path</th>
                                    <th>Read Permission</th>
                                    <th>Write Permission</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($overview['storage']['paths'] as $pathName => $item): ?>
                                    <tr>
                                        <td class="fw-bold text-dark"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $pathName))) ?></td>
                                        <td><code class="text-muted"><?= htmlspecialchars($item['path']) ?></code></td>
                                        <td>
                                            <?php if ($item['readable']): ?>
                                                <span class="badge bg-success-subtle text-success"><i class="bi bi-check"></i> Readable</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger"><i class="bi bi-x"></i> Denied</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($item['writable']): ?>
                                                <span class="badge bg-success-subtle text-success"><i class="bi bi-check"></i> Writable</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger"><i class="bi bi-x"></i> Read Only</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($item['status'] === 'writable'): ?>
                                                <span class="text-success small fw-semibold"><i class="bi bi-shield-check"></i> Healthy</span>
                                            <?php else: ?>
                                                <span class="text-danger small fw-semibold"><i class="bi bi-shield-x"></i> <?= htmlspecialchars($item['message']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tab 3: PHP Runtime Environment -->
                <div class="tab-pane fade" id="php-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">PHP Server Configuration &amp; Hardening Posture</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">PHP Version</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['php_runtime']['php_version']) ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Memory Limit</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['php_runtime']['memory_limit']) ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Max Execution Time</div>
                                <div class="fw-bold text-dark mt-1"><?= htmlspecialchars($overview['php_runtime']['max_execution_time']) ?>s</div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Display Errors Posture</div>
                                <div class="fw-bold <?= (str_contains($overview['php_runtime']['display_errors'], 'Secure')) ? 'text-success' : 'text-danger' ?> mt-1">
                                    <?= htmlspecialchars($overview['php_runtime']['display_errors']) ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <h6 class="fw-bold text-dark mb-3">Required PHP Extensions Verification</h6>
                    <div class="row g-2">
                        <?php foreach ($overview['php_runtime']['extensions'] as $ext => $loaded): ?>
                            <div class="col-6 col-sm-4 col-md-3">
                                <div class="p-2 border rounded-3 d-flex align-items-center justify-content-between small">
                                    <span class="font-monospace fw-semibold"><?= htmlspecialchars($ext) ?></span>
                                    <?php if ($loaded): ?>
                                        <i class="bi bi-check-circle-fill text-success"></i>
                                    <?php else: ?>
                                        <i class="bi bi-x-circle-fill text-danger"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Tab 4: Integrations & Delivery Channels -->
                <div class="tab-pane fade" id="integrations-pane" role="tabpanel">
                    <h6 class="fw-bold text-dark mb-3">External Integrations &amp; Delivery Services</h6>
                    <div class="row g-3">
                        <!-- Mail / SMTP -->
                        <div class="col-md-4">
                            <div class="card h-100 border rounded-4 p-3 shadow-none">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="fw-bold text-dark"><i class="bi bi-envelope-at me-2 text-primary"></i>Email Delivery (SMTP)</span>
                                    <span class="badge <?= ($overview['integrations']['mail']['status'] === 'configured') ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?>">
                                        <?= htmlspecialchars(ucwords(str_replace('_', ' ', $overview['integrations']['mail']['status']))) ?>
                                    </span>
                                </div>
                                <p class="text-muted small mb-0"><?= htmlspecialchars($overview['integrations']['mail']['details']) ?></p>
                            </div>
                        </div>

                        <!-- SMS & WhatsApp -->
                        <div class="col-md-4">
                            <div class="card h-100 border rounded-4 p-3 shadow-none">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="fw-bold text-dark"><i class="bi bi-chat-dots me-2 text-success"></i>SMS &amp; WhatsApp Gateways</span>
                                    <span class="badge <?= ($overview['integrations']['sms']['status'] === 'live') ? 'bg-success-subtle text-success' : 'bg-info-subtle text-info' ?>">
                                        <?= htmlspecialchars(ucwords(str_replace('_', ' ', $overview['integrations']['sms']['status']))) ?>
                                    </span>
                                </div>
                                <p class="text-muted small mb-0"><?= htmlspecialchars($overview['integrations']['sms']['details']) ?></p>
                            </div>
                        </div>

                        <!-- Google Gemini AI -->
                        <div class="col-md-4">
                            <div class="card h-100 border rounded-4 p-3 shadow-none">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="fw-bold text-dark"><i class="bi bi-stars me-2 text-warning"></i>Gemini AI Assistant</span>
                                    <span class="badge <?= ($overview['integrations']['ai_gemini']['status'] === 'configured') ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?>">
                                        <?= htmlspecialchars(ucwords(str_replace('_', ' ', $overview['integrations']['ai_gemini']['status']))) ?>
                                    </span>
                                </div>
                                <p class="text-muted small mb-0"><?= htmlspecialchars($overview['integrations']['ai_gemini']['details']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 5: Error Diagnostics & Telemetry Analyzer -->
                <div class="tab-pane fade" id="logs-pane" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="fw-bold text-dark mb-0">Sanitized Operational Diagnostics (Zero Secret Leakage)</h6>
                            <p class="text-muted small mb-0">System events and application warnings are scrubbed to prevent exposing sensitive student data or API credentials.</p>
                        </div>
                        <div class="d-flex gap-2">
                            <span class="badge bg-danger-subtle text-danger fw-bold"><?= $overview['error_diagnostics']['critical_count'] ?> Critical</span>
                            <span class="badge bg-warning-subtle text-warning fw-bold"><?= $overview['error_diagnostics']['warning_count'] ?> Warnings</span>
                        </div>
                    </div>

                    <?php if (empty($overview['error_diagnostics']['recent_entries'])): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-check2-circle text-success fs-1"></i>
                            <h6 class="fw-bold text-dark mt-2">Clean Operational Log</h6>
                            <p class="text-muted small mb-0">No active system errors or unhandled exceptions logged in the telemetry store.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 160px;">Timestamp</th>
                                        <th style="width: 100px;">Level</th>
                                        <th>Sanitized Message</th>
                                        <th>Actionable Guidance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($overview['error_diagnostics']['recent_entries'] as $entry): ?>
                                        <tr>
                                            <td class="text-muted small"><?= htmlspecialchars($entry['timestamp']) ?></td>
                                            <td>
                                                <?php if ($entry['level'] === 'CRITICAL'): ?>
                                                    <span class="badge bg-danger"><?= htmlspecialchars($entry['level']) ?></span>
                                                <?php elseif ($entry['level'] === 'WARNING'): ?>
                                                    <span class="badge bg-warning text-dark"><?= htmlspecialchars($entry['level']) ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-info text-dark"><?= htmlspecialchars($entry['level']) ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="font-monospace text-dark"><?= htmlspecialchars($entry['message']) ?></td>
                                            <td class="text-muted small">
                                                <i class="bi bi-lightbulb text-warning me-1"></i><?= htmlspecialchars($entry['hint']) ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>
