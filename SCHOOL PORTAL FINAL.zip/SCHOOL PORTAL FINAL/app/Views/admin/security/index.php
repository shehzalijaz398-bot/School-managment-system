<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Security Center</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-shield-lock-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Enforce enterprise password policies, account lockouts, login history audits, and strict multi-tenant isolation.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('admin/system/health') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-heart-pulse me-1"></i> System Health
            </a>
            <a href="<?= url('admin/system/backups') ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-cloud-arrow-down me-1"></i> Disaster Recovery Vault
            </a>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#editSecurityPolicyModal">
                <i class="bi bi-sliders me-1"></i> Configure Security Policies
            </button>
        </div>
    </div>

    <!-- Security KPI Cards -->
    <div class="row g-3 mb-4">
        <!-- 1. Tenant Security Score -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ($audit['score'] >= 90) ? 'border-success' : 'border-warning' ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Tenant Isolation Score</div>
                <div class="h3 fw-bold <?= ($audit['score'] >= 90) ? 'text-success' : 'text-warning' ?> mt-1 mb-0">
                    <?= $audit['score'] ?>%
                </div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    <?= $audit['secure_tables_count'] ?> / <?= $audit['total_tables_checked'] ?> isolated schema tables verified
                </div>
            </div>
        </div>

        <!-- 2. Today's Successful Logins -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Logins Today</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= (int)($metrics['logins_today']['total_today'] ?? 0) ?></div>
                <div class="text-success small mt-1" style="font-size: 11px;">
                    <i class="bi bi-check-circle-fill"></i> <?= (int)($metrics['logins_today']['successful_today'] ?? 0) ?> Success
                    &middot; <span class="text-danger"><?= (int)($metrics['logins_today']['failed_today'] ?? 0) ?> Failed</span>
                </div>
            </div>
        </div>

        <!-- 3. Open Incidents / Alerts -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 <?= ((int)($metrics['incidents']['open_incidents'] ?? 0) > 0) ? 'border-danger' : 'border-success' ?> h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Security Incidents</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= (int)($metrics['incidents']['open_incidents'] ?? 0) ?> Open</div>
                <div class="small mt-1 <?= ((int)($metrics['incidents']['critical_incidents'] ?? 0) > 0) ? 'text-danger fw-bold' : 'text-muted' ?>" style="font-size: 11px;">
                    <?= (int)($metrics['incidents']['critical_incidents'] ?? 0) ?> Critical Priority
                </div>
            </div>
        </div>

        <!-- 4. Administrative Accounts -->
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Admin Privileged Accounts</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= (int)$metrics['admin_accounts_count'] ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Full RBAC administrative authority</div>
            </div>
        </div>
    </div>

    <!-- Security Incidents Alert Box (If any open incidents exist) -->
    <?php 
    $openIncidents = array_filter($incidents, fn($i) => $i['status'] === 'open');
    if (!empty($openIncidents)): ?>
        <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white border-start border-4 border-danger">
            <div class="card-header bg-danger text-white rounded-top-4 py-3 px-4 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0">
                    <i class="bi bi-shield-fill-exclamation me-2"></i>Active Security Alerts &amp; Suspicious Activity
                </h6>
                <span class="badge bg-white text-danger fw-bold"><?= count($openIncidents) ?> Action Required</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Incident Event</th>
                                <th>Severity</th>
                                <th>Origin IP Address</th>
                                <th>Event Details</th>
                                <th>Detected At</th>
                                <th class="pe-4 text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($openIncidents as $inc): ?>
                                <?php 
                                $details = json_decode((string)$inc['details'], true) ?: [];
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark text-capitalize"><?= str_replace('_', ' ', $inc['event_type']) ?></div>
                                        <div class="text-muted small">Target: <?= htmlspecialchars($details['target_email'] ?? ($inc['target_name'] ?? 'System')) ?></div>
                                    </td>
                                    <td>
                                        <span class="badge <?= ($inc['severity'] === 'critical' || $inc['severity'] === 'high') ? 'bg-danger text-white' : 'bg-warning text-dark' ?> text-uppercase" style="font-size: 10px;">
                                            <?= htmlspecialchars($inc['severity']) ?>
                                        </span>
                                    </td>
                                    <td class="font-monospace text-dark"><?= htmlspecialchars($inc['ip_address']) ?></td>
                                    <td style="max-width: 250px;" class="text-truncate text-muted small">
                                        <?= htmlspecialchars($details['reason'] ?? (!empty($details['consecutive_failures']) ? "{$details['consecutive_failures']} consecutive failed attempts" : 'Anomalous pattern')) ?>
                                    </td>
                                    <td class="text-muted small"><?= date('M d, H:i', strtotime($inc['created_at'])) ?></td>
                                    <td class="pe-4 text-end">
                                        <button type="button" class="btn btn-sm btn-outline-success rounded-pill px-3 py-1 fw-semibold resolve-btn"
                                                data-id="<?= $inc['id'] ?>"
                                                data-bs-toggle="modal" data-bs-target="#resolveIncidentModal">
                                            Resolve
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Nav Tabs: Login History, Tenant Isolation Audit, Active Policies -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white mb-4">
        <div class="card-header bg-white border-bottom p-2">
            <ul class="nav nav-tabs border-0" id="securityTabs" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active fw-semibold small" id="history-tab" data-bs-toggle="tab" data-bs-target="#history-pane" type="button" role="tab">
                        <i class="bi bi-journal-text me-1"></i> Login History &amp; Access Logs (<?= $history['total'] ?>)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold small" id="audit-tab" data-bs-toggle="tab" data-bs-target="#audit-pane" type="button" role="tab">
                        <i class="bi bi-shield-check me-1"></i> Multi-Tenant Isolation Audit (<?= $audit['score'] ?>%)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold small" id="policy-tab" data-bs-toggle="tab" data-bs-target="#policy-pane" type="button" role="tab">
                        <i class="bi bi-lock me-1"></i> Password Policy &amp; Lockout Rules
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body p-4">
            <div class="tab-content" id="securityTabContent">
                <!-- Tab 1: Login History -->
                <div class="tab-pane fade show active" id="history-pane" role="tabpanel">
                    <!-- Filters -->
                    <form method="GET" action="<?= url('admin/security') ?>" class="row g-2 align-items-center mb-3">
                        <div class="col-md-5">
                            <input type="text" name="q" class="form-control form-control-sm" placeholder="Search email, name, IP address..." value="<?= htmlspecialchars($filters['q']) ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="all" <?= ($filters['status'] === 'all') ? 'selected' : '' ?>>All Login Outcomes</option>
                                <option value="success" <?= ($filters['status'] === 'success') ? 'selected' : '' ?>>Success Only</option>
                                <option value="failed_password" <?= ($filters['status'] === 'failed_password') ? 'selected' : '' ?>>Failed Password</option>
                                <option value="locked_out" <?= ($filters['status'] === 'locked_out') ? 'selected' : '' ?>>Account Locked Out</option>
                                <option value="user_not_found" <?= ($filters['status'] === 'user_not_found') ? 'selected' : '' ?>>User Not Found</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
                        </div>
                        <div class="col-md-2">
                            <a href="<?= url('admin/security') ?>" class="btn btn-outline-secondary btn-sm w-100">Reset</a>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">User / Identity</th>
                                    <th>Status</th>
                                    <th>IP Address</th>
                                    <th>User Agent / Browser</th>
                                    <th>Timestamp</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($history['items'])): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">
                                            No login attempts recorded matching your filter criteria.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($history['items'] as $h): ?>
                                        <tr>
                                            <td class="ps-3">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($h['email']) ?></div>
                                                <div class="text-muted small">
                                                    <?= htmlspecialchars($h['user_name'] ?? 'External / Anonymous') ?>
                                                    <?php if (!empty($h['role_name'])): ?>
                                                        &middot; <span class="badge bg-light text-dark border"><?= htmlspecialchars($h['role_name']) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <?php 
                                                $badge = match($h['status']) {
                                                    'success' => 'bg-success-subtle text-success border-success-subtle',
                                                    'failed_password' => 'bg-danger-subtle text-danger border-danger-subtle',
                                                    'locked_out' => 'bg-warning-subtle text-warning-emphasis border-warning-subtle',
                                                    default => 'bg-secondary-subtle text-secondary border-secondary-subtle',
                                                };
                                                ?>
                                                <span class="badge border <?= $badge ?> text-uppercase px-2 py-1" style="font-size: 10px;">
                                                    <?= str_replace('_', ' ', $h['status']) ?>
                                                </span>
                                            </td>
                                            <td class="font-monospace text-dark"><?= htmlspecialchars($h['ip_address']) ?></td>
                                            <td style="max-width: 250px;" class="text-truncate text-muted small" title="<?= htmlspecialchars($h['user_agent'] ?? '') ?>">
                                                <?= htmlspecialchars($h['user_agent'] ?: 'Direct / API Client') ?>
                                            </td>
                                            <td class="text-muted small"><?= date('M d, Y H:i:s', strtotime($h['attempted_at'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($history['totalPages'] > 1): ?>
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                            <span class="small text-muted">Page <?= $history['page'] ?> of <?= $history['totalPages'] ?> (<?= $history['total'] ?> total records)</span>
                            <div class="d-flex gap-1">
                                <?php if ($history['page'] > 1): ?>
                                    <a href="<?= url('admin/security?page=' . ($history['page'] - 1) . '&status=' . $filters['status'] . '&q=' . urlencode($filters['q'])) ?>" class="btn btn-sm btn-outline-secondary">&laquo; Prev</a>
                                <?php endif; ?>
                                <?php if ($history['page'] < $history['totalPages']): ?>
                                    <a href="<?= url('admin/security?page=' . ($history['page'] + 1) . '&status=' . $filters['status'] . '&q=' . urlencode($filters['q'])) ?>" class="btn btn-sm btn-outline-secondary">Next &raquo;</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tab 2: Tenant Isolation Audit -->
                <div class="tab-pane fade" id="audit-pane" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="fw-bold text-dark mb-0">Multi-Tenant Database Perimeter Audit</h6>
                            <p class="text-muted small mb-0">Verifies that all entity tables enforce strict tenant filtering with zero cross-tenant contamination.</p>
                        </div>
                        <form method="POST" action="<?= url('admin/security/audit') ?>">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-semibold">
                                <i class="bi bi-arrow-repeat me-1"></i> Re-Run Audit
                            </button>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">Table Entity</th>
                                    <th>Isolation Status</th>
                                    <th>Tenant Records Scoped</th>
                                    <th>Orphan / NULL Records</th>
                                    <th>Integrity Verdict</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($audit['table_details'] as $det): ?>
                                    <tr>
                                        <td class="ps-3 fw-bold text-dark font-monospace"><?= htmlspecialchars($det['table']) ?></td>
                                        <td>
                                            <?php if ($det['status'] === 'secure'): ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1">
                                                    <i class="bi bi-check-circle me-1"></i> Secure Perimeter
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1">
                                                    <i class="bi bi-exclamation-triangle me-1"></i> Orphan Detected
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="fw-semibold text-dark"><?= (int)$det['tenant_records'] ?> records</td>
                                        <td>
                                            <span class="<?= ($det['orphan_records'] > 0) ? 'text-danger fw-bold' : 'text-muted' ?>">
                                                <?= (int)$det['orphan_records'] ?>
                                            </span>
                                        </td>
                                        <td class="text-muted small"><?= htmlspecialchars($det['message']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tab 3: Security Policies -->
                <div class="tab-pane fade" id="policy-pane" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="p-4 bg-light rounded-4 border h-100">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-key-fill text-primary me-2"></i>Active Password Policy</h6>
                                <ul class="list-unstyled mb-0" style="font-size: 13px;">
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Minimum Character Length:</span>
                                        <strong class="text-dark"><?= (int)$settings['min_password_length'] ?> characters</strong>
                                    </li>
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Require Uppercase Letter (A-Z):</span>
                                        <span class="badge <?= !empty($settings['require_uppercase']) ? 'bg-success' : 'bg-secondary' ?>"><?= !empty($settings['require_uppercase']) ? 'Enforced' : 'Optional' ?></span>
                                    </li>
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Require Lowercase Letter (a-z):</span>
                                        <span class="badge <?= !empty($settings['require_lowercase']) ? 'bg-success' : 'bg-secondary' ?>"><?= !empty($settings['require_lowercase']) ? 'Enforced' : 'Optional' ?></span>
                                    </li>
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Require Numeric Digits (0-9):</span>
                                        <span class="badge <?= !empty($settings['require_numbers']) ? 'bg-success' : 'bg-secondary' ?>"><?= !empty($settings['require_numbers']) ? 'Enforced' : 'Optional' ?></span>
                                    </li>
                                    <li class="mb-0 d-flex justify-content-between">
                                        <span>Require Special Characters:</span>
                                        <span class="badge <?= !empty($settings['require_special_chars']) ? 'bg-success' : 'bg-secondary' ?>"><?= !empty($settings['require_special_chars']) ? 'Enforced' : 'Optional' ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="p-4 bg-light rounded-4 border h-100">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-shield-x text-danger me-2"></i>Account Lockout &amp; Session Controls</h6>
                                <ul class="list-unstyled mb-0" style="font-size: 13px;">
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Max Consecutive Failed Logins:</span>
                                        <strong class="text-danger"><?= (int)$settings['max_failed_logins'] ?> attempts</strong>
                                    </li>
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Lockout Duration:</span>
                                        <strong class="text-dark"><?= (int)$settings['lockout_duration_minutes'] ?> minutes</strong>
                                    </li>
                                    <li class="mb-2 d-flex justify-content-between">
                                        <span>Inactivity Session Timeout:</span>
                                        <strong class="text-dark"><?= (int)$settings['session_timeout_minutes'] ?> minutes</strong>
                                    </li>
                                    <li class="mb-0 d-flex justify-content-between">
                                        <span>Notify Admins on Lockout:</span>
                                        <span class="badge <?= !empty($settings['notify_admin_on_lockout']) ? 'bg-success' : 'bg-secondary' ?>"><?= !empty($settings['notify_admin_on_lockout']) ? 'Enabled' : 'Disabled' ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Configure Security Policies -->
<div class="modal fade" id="editSecurityPolicyModal" tabindex="-1" aria-labelledby="editSecurityPolicyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('admin/security/policy') ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="editSecurityPolicyModalLabel">Configure Security Policies</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Minimum Password Length</label>
                        <input type="number" name="min_password_length" class="form-control" value="<?= (int)$settings['min_password_length'] ?>" min="6" max="32" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Password Complexity Requirements</label>
                        <div class="form-check form-switch mb-1">
                            <input class="form-check-input" type="checkbox" name="require_uppercase" value="1" id="req_upper" <?= !empty($settings['require_uppercase']) ? 'checked' : '' ?>>
                            <label class="form-check-label small" for="req_upper">Require Uppercase Letter (A-Z)</label>
                        </div>
                        <div class="form-check form-switch mb-1">
                            <input class="form-check-input" type="checkbox" name="require_lowercase" value="1" id="req_lower" <?= !empty($settings['require_lowercase']) ? 'checked' : '' ?>>
                            <label class="form-check-label small" for="req_lower">Require Lowercase Letter (a-z)</label>
                        </div>
                        <div class="form-check form-switch mb-1">
                            <input class="form-check-input" type="checkbox" name="require_numbers" value="1" id="req_num" <?= !empty($settings['require_numbers']) ? 'checked' : '' ?>>
                            <label class="form-check-label small" for="req_num">Require Numeric Digits (0-9)</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="require_special_chars" value="1" id="req_spec" <?= !empty($settings['require_special_chars']) ? 'checked' : '' ?>>
                            <label class="form-check-label small" for="req_spec">Require Special Characters (!@#$%^&*)</label>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Max Failed Logins</label>
                            <input type="number" name="max_failed_logins" class="form-control" value="<?= (int)$settings['max_failed_logins'] ?>" min="3" max="20" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Lockout Duration (Mins)</label>
                            <input type="number" name="lockout_duration_minutes" class="form-control" value="<?= (int)$settings['lockout_duration_minutes'] ?>" min="5" max="1440" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Inactivity Session Timeout (Minutes)</label>
                        <input type="number" name="session_timeout_minutes" class="form-control" value="<?= (int)$settings['session_timeout_minutes'] ?>" min="15" max="1440" required>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="notify_admin_on_lockout" value="1" id="notify_lock" <?= !empty($settings['notify_admin_on_lockout']) ? 'checked' : '' ?>>
                        <label class="form-check-label small" for="notify_lock">Notify School Administrators upon Account Lockout</label>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Security Policies</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Resolve Incident -->
<div class="modal fade" id="resolveIncidentModal" tabindex="-1" aria-labelledby="resolveIncidentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" id="resolveIncidentForm" action="">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="resolveIncidentModalLabel">Resolve Security Alert</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Resolution Audit Notes <span class="text-danger">*</span></label>
                        <textarea name="resolution_notes" rows="3" class="form-control" placeholder="Describe investigation outcome (e.g. Verified genuine user password typo; IP unblocked)." required></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">Mark Incident Resolved</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const resolveBtns = document.querySelectorAll('.resolve-btn');
    resolveBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            const incId = this.dataset.id;
            document.getElementById('resolveIncidentForm').action = '<?= url("admin/security/incidents") ?>/' + incId + '/resolve';
        });
    });
});
</script>
