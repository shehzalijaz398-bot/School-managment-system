<?php
$title = 'Help & Support';
$layout = 'layouts/app';
/** @var array $tickets */
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-headset text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Contact the SaaS platform team for billing, account, or technical help.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Ticket Form -->
    <div class="col-lg-5 col-xl-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-primary text-white border-0 pt-4 pb-3 px-4 rounded-top-4">
                <h5 class="fw-bold mb-0"><i class="fas fa-ticket-alt me-2"></i> Open a Ticket</h5>
            </div>
            <div class="card-body p-4 bg-light rounded-bottom-4">
                <form method="post" action="<?= e(url('support')) ?>">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Category <span class="text-danger">*</span></label>
                        <select name="category" class="form-select rounded-3 shadow-sm border-0" required>
                            <option value="technical">Technical Issue</option>
                            <option value="billing">Billing & Subscriptions</option>
                            <option value="account">Account Management</option>
                            <option value="feature">Feature Request</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Priority <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select rounded-3 shadow-sm border-0" required>
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-sm fw-semibold">Subject <span class="text-danger">*</span></label>
                        <input type="text" name="subject" class="form-control rounded-3 shadow-sm border-0" required maxlength="255" placeholder="Brief summary of issue">
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-sm fw-semibold">Message <span class="text-danger">*</span></label>
                        <textarea name="message" class="form-control rounded-3 shadow-sm border-0" rows="5" required minlength="10" placeholder="Please provide detailed information..."></textarea>
                    </div>
                    <button class="btn btn-primary w-100 rounded-pill fw-bold shadow-sm action-hover py-2">
                        <i class="fas fa-paper-plane me-1"></i> Submit Ticket
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Ticket History -->
    <div class="col-lg-7 col-xl-8">
        <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden">
            <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                <h5 class="fw-bold text-gray-800 mb-0"><i class="fas fa-history text-secondary me-2"></i> Your Tickets</h5>
            </div>
            <div class="card-body p-0 mt-3">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">Ticket Info</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Status</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($tickets)): ?>
                            <tr>
                                <td colspan="3" class="text-center py-5 text-muted">
                                    <i class="fas fa-inbox fa-3x mb-3 text-light"></i>
                                    <h5 class="fw-bold text-gray-500">No Support Tickets</h5>
                                    <p class="mb-0 text-sm">You haven't opened any support tickets yet.</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($tickets as $t): ?>
                            <tr class="ticket-row" onclick="window.location='<?= e(url('support/'.$t['id'])) ?>';" style="cursor: pointer;">
                                <td class="px-4 py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 40px; height: 40px; flex-shrink: 0;">
                                            <i class="fas fa-hashtag text-xs"></i>
                                        </div>
                                        <div>
                                            <a href="<?= e(url('support/'.$t['id'])) ?>" class="text-primary fw-bold text-decoration-none d-block mb-1 text-sm"><?= e($t['ticket_number']) ?></a>
                                            <span class="text-sm fw-semibold text-gray-800 d-block text-truncate" style="max-width: 250px;"><?= e($t['subject']) ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3">
                                    <?php
                                        $statusClass = 'bg-secondary';
                                        if ($t['status'] === 'open') $statusClass = 'bg-primary';
                                        if ($t['status'] === 'in_progress') $statusClass = 'bg-warning text-dark';
                                        if ($t['status'] === 'resolved') $statusClass = 'bg-success';
                                        if ($t['status'] === 'closed') $statusClass = 'bg-dark';
                                    ?>
                                    <span class="badge <?= $statusClass ?> rounded-pill px-3 shadow-sm text-xs">
                                        <?= ucfirst(e(str_replace('_', ' ', $t['status']))) ?>
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-end text-sm text-muted">
                                    <i class="far fa-clock me-1"></i> <?= e(formatDate($t['updated_at'], 'd M Y, h:i A')) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .ticket-row {
        transition: all 0.2s ease;
    }
    .ticket-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 10px -4px rgba(0,0,0,0.05);
        position: relative;
        z-index: 10;
    }
    .ticket-row:hover .avatar {
        transform: scale(1.1);
        box-shadow: 0 4px 8px rgba(13, 110, 253, 0.2) !important;
    }
    
    .bg-primary-subtle { background-color: #cfe2ff !important; }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(13, 110, 253, 0.2) !important;
    }
    .form-control:focus, .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
    }
</style>
