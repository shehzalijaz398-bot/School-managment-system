<?php /** @var array $ticket */ /** @var array $messages */ ?>
<p><a href="<?= e(url('support')) ?>">&larr; Back to tickets</a></p>
<div class="card border-0 shadow-sm mb-3">
  <div class="card-body">
    <h5><?= e($ticket['ticket_number']) ?> — <?= e($ticket['subject']) ?></h5>
    <div class="small text-muted">
      <?= e($ticket['category']) ?> · <?= e($ticket['priority']) ?> ·
      <span class="badge text-bg-secondary"><?= e($ticket['status']) ?></span>
    </div>
  </div>
</div>

<?php foreach ($messages as $m): ?>
  <div class="card border-0 shadow-sm mb-2">
    <div class="card-body">
      <div class="small text-muted mb-1">
        <?= e($m['sender_type'] === 'platform' ? 'Platform Support' : 'Your school') ?>
        · <?= e($m['created_at']) ?>
      </div>
      <div><?= nl2br(e($m['message'])) ?></div>
    </div>
  </div>
<?php endforeach; ?>

<?php if (!in_array($ticket['status'], ['closed'], true)): ?>
<form method="post" action="<?= e(url('support/'.$ticket['id'].'/reply')) ?>" class="card border-0 shadow-sm mt-3">
  <div class="card-body">
    <?= csrf_field() ?>
    <label class="form-label">Reply</label>
    <textarea name="message" class="form-control mb-2" rows="4" required></textarea>
    <button class="btn btn-primary">Send reply</button>
  </div>
</form>
<?php endif; ?>
