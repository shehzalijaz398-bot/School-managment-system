<div class="container-fluid py-4">
    <!-- Header with Gateway Test -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h1 class="h3 mb-1 text-gray-800 fw-bold">
                <i class="bi bi-broadcast text-primary me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Unified multi-channel announcement and broadcast dispatch engine with live delivery tracking.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <form method="POST" action="<?= url('communication/test-payload') ?>" class="d-inline">
                <?= csrf_field() ?>
                <input type="hidden" name="test_channel" value="SMS">
                <button type="submit" class="btn btn-outline-secondary shadow-sm fw-bold btn-sm">
                    <i class="bi bi-phone me-1"></i> Test SMS Sandbox
                </button>
            </form>
            <form method="POST" action="<?= url('communication/test-payload') ?>" class="d-inline">
                <?= csrf_field() ?>
                <input type="hidden" name="test_channel" value="WhatsApp">
                <button type="submit" class="btn btn-outline-success shadow-sm fw-bold btn-sm">
                    <i class="bi bi-whatsapp me-1"></i> Test WhatsApp Sandbox
                </button>
            </form>
        </div>
    </div>

    <!-- Live Transmission Metrics -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-primary">
                <div class="text-muted small fw-semibold text-uppercase">Total Dispatches</div>
                <div class="h3 fw-bold text-dark mb-0 mt-1"><?= number_format((float)($stats['total_dispatches'] ?? 0)) ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase">Delivered / Synced</div>
                <div class="h3 fw-bold text-success mb-0 mt-1"><?= number_format((float)($stats['delivered_count'] ?? 0)) ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-info">
                <div class="text-muted small fw-semibold text-uppercase">In-App / Simulation</div>
                <div class="h3 fw-bold text-info mb-0 mt-1"><?= number_format((float)($stats['simulated_count'] ?? 0)) ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-warning">
                <div class="text-muted small fw-semibold text-uppercase">SMS / WA / Email</div>
                <div class="h3 fw-bold text-dark mb-0 mt-1">
                    <span class="fs-6 text-muted"><?= (int)($stats['sms_count'] ?? 0) ?> / <?= (int)($stats['whatsapp_count'] ?? 0) ?> / <?= (int)($stats['email_count'] ?? 0) ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Communication Matrix Console -->
        <div class="col-lg-8">
            <div class="card shadow mb-4 border-0 rounded-4">
                <div class="card-header py-3 bg-light border-0 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-send-fill me-2"></i>Multi-Channel Broadcast Composer</h6>
                    <span class="badge bg-primary-subtle text-primary fw-semibold px-3 py-1">Audience Targeting Active</span>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="<?= url('communication/dispatch-broadcast') ?>" id="broadcastForm">
                        <?= csrf_field() ?>
                        
                        <div class="row mb-4">
                            <!-- Channel Toggles -->
                            <div class="col-md-6 border-end pe-md-4">
                                <label class="form-label fw-bold text-dark text-uppercase fs-6 mb-3">Transmission Vectors</label>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="chanSms" name="channels[]" value="SMS" checked style="transform: scale(1.2); margin-right: 10px;">
                                    <label class="form-check-label fw-bold" for="chanSms"><i class="bi bi-phone text-secondary me-1"></i> Direct SMS (Provider Gateway)</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="chanWa" name="channels[]" value="WhatsApp" checked style="transform: scale(1.2); margin-right: 10px;">
                                    <label class="form-check-label fw-bold text-success" for="chanWa"><i class="bi bi-whatsapp me-1"></i> WhatsApp Cloud API</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="chanEmail" name="channels[]" value="Email" checked style="transform: scale(1.2); margin-right: 10px;">
                                    <label class="form-check-label fw-bold text-primary" for="chanEmail"><i class="bi bi-envelope me-1"></i> Email (SMTP / Mail Dispatch)</label>
                                </div>
                                <div class="text-muted small bg-light p-2 rounded-2 mt-2">
                                    <i class="bi bi-info-circle me-1"></i> In-app portal notifications are automatically synced for all targeted recipient accounts.
                                </div>
                            </div>

                            <!-- Target Audience -->
                            <div class="col-md-6 ps-md-4 mt-3 mt-md-0">
                                <label class="form-label fw-bold text-dark text-uppercase fs-6 mb-2">Target Audience Scope</label>
                                <select class="form-select form-select-lg shadow-sm mb-3" name="target" id="targetSelect" required style="font-size: 14px;">
                                    <option value="" disabled selected>Select Audience Target...</option>
                                    <optgroup label="Global Scopes">
                                        <option value="all" class="fw-bold text-primary">All School Members (Parents & Staff)</option>
                                        <option value="all_parents" class="fw-bold text-primary">All Registered Parents</option>
                                        <option value="staff" class="fw-bold text-success">All Internal Staff & Faculty</option>
                                    </optgroup>
                                    
                                    <?php if (!empty($roles)): ?>
                                    <optgroup label="Filter by Role">
                                        <?php foreach ($roles as $r): ?>
                                            <option value="role_<?= htmlspecialchars($r['slug']) ?>">Role: <?= htmlspecialchars($r['name']) ?></option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <?php endif; ?>

                                    <?php if (!empty($classes)): ?>
                                    <optgroup label="Filter by Class">
                                        <?php foreach ($classes as $c): ?>
                                            <option value="class_<?= $c['id'] ?>">Class: <?= htmlspecialchars($c['name']) ?> (<?= (int)$c['student_count'] ?> students)</option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <?php endif; ?>

                                    <?php if (!empty($sections)): ?>
                                    <optgroup label="Filter by Section">
                                        <?php foreach ($sections as $sec): ?>
                                            <option value="section_<?= $sec['id'] ?>"><?= htmlspecialchars($sec['class_name']) ?> • Section <?= htmlspecialchars($sec['name']) ?></option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <?php endif; ?>
                                </select>

                                <label class="form-label fw-bold text-dark text-uppercase fs-6 mb-2">Broadcast Subject / Title</label>
                                <input type="text" name="title" class="form-control shadow-sm" placeholder="e.g. Important Academic Update or Fee Notice" value="School Announcement" required>
                            </div>
                        </div>

                        <!-- Dynamic Message Box -->
                        <div class="mb-3 position-relative">
                            <label class="form-label fw-bold text-dark text-uppercase fs-6">Payload Content</label>
                            <textarea class="form-control font-monospace shadow-sm" name="message" id="messageBox" rows="5" placeholder="Enter message payload here..." required></textarea>
                            <div class="mt-2 d-flex justify-content-between align-items-center text-muted small flex-wrap gap-2">
                                <div>
                                    <span class="fw-bold text-dark">Dynamic Tags: </span>
                                    <span class="badge bg-light border text-dark cursor-pointer me-1" onclick="injectHook('{student_name}')">{student_name}</span>
                                    <span class="badge bg-light border text-dark cursor-pointer me-1" onclick="injectHook('{due_amount}')">{due_amount}</span>
                                    <span class="badge bg-light border text-dark cursor-pointer" onclick="injectHook('{exam_grade}')">{exam_grade}</span>
                                </div>
                                <div><span id="charCount" class="fw-bold">0</span> characters</div>
                            </div>
                        </div>

                        <hr class="my-4">
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg shadow fw-bold pulse-primary" onclick="return confirmBroadcast(this)">
                                🚀 Dispatch Multi-Channel Alerts
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Documentation & Gateway Controls -->
        <div class="col-lg-4">
            <div class="card shadow mb-4 border-0 rounded-4">
                <div class="card-header py-3 bg-dark text-white rounded-top-4">
                    <h6 class="m-0 font-weight-bold"><i class="bi bi-shield-check me-2"></i> Safety & Gateway Guards</h6>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-info border-start border-4 border-info p-3 mb-3">
                        <strong class="d-block mb-1"><i class="bi bi-shield-lock-fill me-1"></i> Sandbox Isolation Guard</strong>
                        <p class="mb-0 small">External network transmissions are strictly gated. If API credentials (Twilio/Meta/SMTP) are unconfigured or in development environments, broadcasts are safely recorded as <code>Simulation / In-App Only</code> without network failures.</p>
                    </div>

                    <div class="alert alert-warning border-start border-4 border-warning p-3 mb-3">
                        <strong class="d-block mb-1"><i class="bi bi-slash-circle me-1"></i> 15-Minute Deduplication</strong>
                        <p class="mb-0 small">Duplicate dispatches to identical audience scopes are automatically throttled within a 15-minute sliding window to prevent accidental message flooding.</p>
                    </div>

                    <h6 class="fw-bold text-muted border-bottom pb-2 mt-4 mb-3">Recipient Personalization</h6>
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> <code>{student_name}</code> resolves to the pupil's official name.</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> <code>{due_amount}</code> pulls live unpaid invoice balances.</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> <code>{exam_grade}</code> links to the latest recorded report card.</li>
                        <li><i class="bi bi-bell-fill text-primary me-2"></i> Synced to in-app notification desk for each student and parent.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Delivery Tracking Log -->
    <div class="card shadow border-0 rounded-4 mt-2">
        <div class="card-header py-3 bg-white d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-dark"><i class="bi bi-clock-history text-primary me-2"></i> Recent Transmission Logs (Last 25 Dispatches)</h6>
            <span class="badge bg-secondary-subtle text-secondary small">Auto-Audited</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>Recipient</th>
                            <th>Type</th>
                            <th>Channel</th>
                            <th>Title / Payload</th>
                            <th>Status</th>
                            <th>Provider Ref</th>
                            <th class="pe-4 text-end">Dispatched At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentLogs)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    <i class="bi bi-inbox fs-3 d-block mb-1"></i>
                                    No broadcast logs recorded yet. Create and dispatch your first announcement above.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recentLogs as $log): ?>
                                <tr>
                                    <td class="ps-4 fw-bold text-muted">#<?= (int)$log['id'] ?></td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($log['recipient_name'] ?: 'All Audience') ?></div>
                                        <div class="text-muted small"><?= htmlspecialchars($log['recipient_contact'] ?: '—') ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= htmlspecialchars(ucfirst($log['recipient_type'] ?? 'all')) ?></span>
                                    </td>
                                    <td>
                                        <?php if ($log['channel'] === 'SMS'): ?>
                                            <span class="badge bg-secondary text-white"><i class="bi bi-phone me-1"></i> SMS</span>
                                        <?php elseif ($log['channel'] === 'WhatsApp'): ?>
                                            <span class="badge bg-success text-white"><i class="bi bi-whatsapp me-1"></i> WhatsApp</span>
                                        <?php else: ?>
                                            <span class="badge bg-primary text-white"><i class="bi bi-envelope me-1"></i> Email</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="max-width: 320px;">
                                        <div class="fw-semibold text-dark text-truncate"><?= htmlspecialchars($log['title'] ?: 'Broadcast') ?></div>
                                        <div class="text-muted small text-truncate"><?= htmlspecialchars($log['payload']) ?></div>
                                    </td>
                                    <td>
                                        <?php if (str_starts_with($log['status'], 'Delivered')): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle">
                                                <i class="bi bi-check-circle-fill me-1"></i> Delivered
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-info-subtle text-info border border-info-subtle">
                                                <i class="bi bi-shield-check me-1"></i> <?= htmlspecialchars($log['status']) ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <code class="small text-muted"><?= htmlspecialchars($log['provider_ref'] ?: 'N/A') ?></code>
                                    </td>
                                    <td class="pe-4 text-end text-muted small">
                                        <?= date('M j, Y • h:i A', strtotime($log['created_at'])) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .cursor-pointer { cursor: pointer; }
    .cursor-pointer:hover { background-color: #e2e8f0 !important; }
    
    .pulse-primary {
        animation: pulse-primary-anim 2s infinite;
    }
    @keyframes pulse-primary-anim {
        0% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(78, 115, 223, 0); }
        100% { box-shadow: 0 0 0 0 rgba(78, 115, 223, 0); }
    }
</style>

<script>
    const messageBox = document.getElementById('messageBox');
    const charCount = document.getElementById('charCount');

    if (messageBox && charCount) {
        messageBox.addEventListener('input', function() {
            charCount.textContent = this.value.length;
            if(this.value.length > 160) {
                charCount.classList.add('text-danger');
                charCount.classList.remove('text-success');
            } else {
                charCount.classList.add('text-success');
                charCount.classList.remove('text-danger');
            }
        });
    }

    function injectHook(hook) {
        if (!messageBox) return;
        const startPos = messageBox.selectionStart;
        const endPos = messageBox.selectionEnd;
        messageBox.value = messageBox.value.substring(0, startPos) + hook + messageBox.value.substring(endPos, messageBox.value.length);
        messageBox.focus();
        messageBox.selectionStart = startPos + hook.length;
        messageBox.selectionEnd = startPos + hook.length;
        messageBox.dispatchEvent(new Event('input'));
    }

    function confirmBroadcast(btn) {
        const checks = document.querySelectorAll('input[name="channels[]"]:checked');
        if (checks.length === 0) {
            alert('CRITICAL: You must select at least one transmission vector (SMS, WhatsApp, or Email).');
            return false;
        }
        const target = document.getElementById('targetSelect').value;
        if (!target) {
            alert('CRITICAL: Target audience scope is not defined.');
            return false;
        }

        if (confirm("You are about to dispatch this broadcast to the selected audience. Proceed?")) {
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Transmitting Payloads...';
            btn.classList.add('disabled');
            btn.setAttribute('disabled', 'disabled');
            setTimeout(() => {
                document.getElementById('broadcastForm').submit();
            }, 100);
            return true;
        }
        return false;
    }
</script>
