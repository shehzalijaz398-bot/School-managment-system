<?php
$layout = 'layouts/app';
$activeTab = $tab ?? 'hostels';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Hostel & Dormitory Management') ?>
        </h1>
        <p class="text-muted small mb-0">
            Manage residential halls, dormitory rooms, bed capacity, and student room allocations
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-outline-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
                data-bs-toggle="modal" data-bs-target="#newRoomModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="door-open" style="width: 15px; height: 15px;"></i>
            <span>Add Room</span>
        </button>
        <button class="btn btn-outline-success d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
                data-bs-toggle="modal" data-bs-target="#newAllocationModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="user-plus" style="width: 15px; height: 15px;"></i>
            <span>Allocate Student</span>
        </button>
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                data-bs-toggle="modal" data-bs-target="#newHostelModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
            <span>Add Hostel Building</span>
        </button>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="building" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Buildings</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_hostels'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Hostel Facilities</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="door-closed" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Rooms</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_rooms'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Dormitory Rooms</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fdf2f8; width: 34px; height: 34px;">
                        <i data-lucide="bed-double" style="width: 16px; height: 16px; stroke: #db2777;"></i>
                    </div>
                    <span class="badge rounded-pill bg-primary-subtle text-primary px-2 py-1" style="font-size: 10px;">Capacity</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_beds'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Bed Capacity</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="users" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 10px;">Occupancy</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['occupied_beds'] ?? 0) ?> <span class="text-muted fs-6 font-normal">/ <?= (int)($stats['total_beds'] ?? 0) ?></span></div>
                <div class="text-muted small mt-1" style="font-size: 12px;"><?= (int)($stats['available_beds'] ?? 0) ?> Beds Available</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs Navigation -->
<ul class="nav nav-pills gap-2 mb-4 p-1 bg-white rounded-3 shadow-sm border" style="width: fit-content;">
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'hostels' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('hostels?tab=hostels')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="building" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Hostels (<?= count($hostels) ?>)
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'rooms' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('hostels?tab=rooms')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="door-open" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Rooms &amp; Beds (<?= count($rooms) ?>)
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'allocations' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('hostels?tab=allocations')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="users" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Resident Allocations (<?= count($allocations) ?>)
        </a>
    </li>
</ul>

<!-- Tab 1: Hostels -->
<?php if ($activeTab === 'hostels'): ?>
<div class="row g-3">
    <?php if (empty($hostels)): ?>
        <div class="col-12 text-center py-4 text-muted bg-white border rounded-3 p-4">
            <i data-lucide="building" style="width: 32px; height: 32px; opacity: 0.4;"></i>
            <div class="mt-2">No hostel buildings configured yet. Click "Add Hostel Building" above.</div>
        </div>
    <?php else: ?>
        <?php foreach ($hostels as $h): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 border rounded-3 p-3 shadow-sm bg-white">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <span class="badge rounded-pill <?= $h['type'] === 'boys' ? 'bg-primary' : ($h['type'] === 'girls' ? 'bg-danger-subtle text-danger' : 'bg-secondary') ?> text-uppercase px-2 py-1" style="font-size: 10px;">
                                <?= e($h['type']) ?> Hostel
                            </span>
                            <h5 class="fw-bold text-dark mt-2 mb-0"><?= e($h['name']) ?></h5>
                        </div>
                        <span class="badge bg-success-subtle text-success">Active</span>
                    </div>
                    <div class="small text-muted mb-2">
                        <i data-lucide="map-pin" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($h['address'] ?: 'Campus Grounds') ?>
                    </div>
                    <div class="small text-muted mb-3">
                        <i data-lucide="user-check" style="width: 13px; height: 13px; margin-right: 4px;"></i> Warden: <span class="fw-medium text-dark"><?= e($h['warden_name'] ?: 'Not Assigned') ?></span> (<?= e($h['warden_phone'] ?: 'N/A') ?>)
                    </div>

                    <div class="d-flex justify-content-between border-top pt-2 mt-auto small">
                        <div>
                            <span class="text-muted">Rooms:</span>
                            <span class="fw-bold text-dark"><?= (int)$h['room_count'] ?></span>
                        </div>
                        <div>
                            <span class="text-muted">Residents:</span>
                            <span class="fw-bold text-primary"><?= (int)$h['resident_count'] ?> / <?= (int)$h['total_beds'] ?> beds</span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Tab 2: Rooms -->
<?php if ($activeTab === 'rooms'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Room #</th>
                        <th>Hostel Building</th>
                        <th>Floor</th>
                        <th>Room Type</th>
                        <th>Bed Capacity</th>
                        <th>Occupancy</th>
                        <th>Monthly Fee</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rooms)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No rooms created yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rooms as $r): 
                            $isFull = ((int)$r['occupied_beds'] >= (int)$r['capacity']);
                        ?>
                            <tr>
                                <td class="ps-3 fw-bold text-dark font-monospace"><?= e($r['room_number']) ?></td>
                                <td><?= e($r['hostel_name']) ?></td>
                                <td><?= e($r['floor'] ?: 'Ground') ?></td>
                                <td><span class="badge bg-light text-dark text-uppercase"><?= e($r['room_type']) ?></span></td>
                                <td><?= (int)$r['capacity'] ?> Beds</td>
                                <td>
                                    <span class="badge rounded-pill <?= $isFull ? 'bg-danger text-white' : 'bg-success-subtle text-success' ?>">
                                        <?= (int)$r['occupied_beds'] ?> / <?= (int)$r['capacity'] ?> <?= $isFull ? '(FULL)' : '' ?>
                                    </span>
                                </td>
                                <td class="fw-medium">Rs. <?= number_format((float)$r['cost_per_bed'], 2) ?></td>
                                <td>
                                    <?php if ($isFull): ?>
                                        <span class="badge bg-danger">Full</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Available</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tab 3: Allocations -->
<?php if ($activeTab === 'allocations'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Student Name</th>
                        <th>Class / Sec</th>
                        <th>Hostel &amp; Room</th>
                        <th>Bed #</th>
                        <th>Check-in Date</th>
                        <th>Monthly Fee</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($allocations)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No hostel room allocations found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($allocations as $a): ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark"><?= e($a['first_name'] . ' ' . $a['last_name']) ?></div>
                                    <div class="text-muted font-monospace" style="font-size: 11px;"><?= e($a['admission_no']) ?></div>
                                </td>
                                <td><?= e($a['class_name'] ?? '—') ?> - <?= e($a['section_name'] ?? '—') ?></td>
                                <td>
                                    <div class="fw-medium text-dark"><?= e($a['hostel_name']) ?></div>
                                    <div class="text-muted" style="font-size: 11px;">Room: <?= e($a['room_number']) ?></div>
                                </td>
                                <td class="fw-bold text-primary"><?= e($a['bed_number'] ?: 'Bed-A') ?></td>
                                <td><?= date('M d, Y', strtotime($a['allocated_date'])) ?></td>
                                <td class="fw-medium">Rs. <?= number_format((float)$a['cost_per_bed'], 2) ?></td>
                                <td>
                                    <?php if ($a['status'] === 'active'): ?>
                                        <span class="badge bg-success-subtle text-success">Residing</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Vacated</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-3">
                                    <?php if ($a['status'] === 'active'): ?>
                                        <form method="POST" action="<?= e(url('hostels/allocations/' . $a['id'] . '/vacate')) ?>" class="d-inline" onsubmit="return confirm('Vacate this bed for student?');">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger py-1 px-2" style="font-size: 12px;">
                                                <i data-lucide="log-out" style="width: 12px; height: 12px; margin-right: 4px;"></i> Vacate
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small">Vacated: <?= date('M d, Y', strtotime($a['vacated_date'])) ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modal: New Hostel -->
<div class="modal fade" id="newHostelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('hostels')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Add Hostel Building</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Hostel Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Allama Iqbal Boys Hall" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Hostel Type</label>
                            <select name="type" class="form-select">
                                <option value="boys">Boys Hostel</option>
                                <option value="girls">Girls Hostel</option>
                                <option value="mixed">Co-ed / Mixed</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Total Capacity</label>
                            <input type="number" name="capacity" class="form-control" placeholder="Total beds" value="50">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Warden Name</label>
                            <input type="text" name="warden_name" class="form-control" placeholder="Resident warden">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Warden Phone</label>
                            <input type="text" name="warden_phone" class="form-control" placeholder="+92 300 0000000">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Address / Campus Location</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="e.g. Sector B, North Campus"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Create Hostel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Room -->
<div class="modal fade" id="newRoomModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('hostels/rooms')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Add Dormitory Room</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Hostel Building *</label>
                        <select name="hostel_id" class="form-select" required>
                            <option value="">Select Hostel</option>
                            <?php foreach ($hostels as $h): ?>
                                <option value="<?= (int)$h['id'] ?>"><?= e($h['name']) ?> (<?= ucfirst($h['type']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Room Number *</label>
                            <input type="text" name="room_number" class="form-control" placeholder="e.g. 101, A-12" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Floor</label>
                            <input type="text" name="floor" class="form-control" placeholder="Ground, 1st, 2nd">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-bold">Room Type</label>
                            <select name="room_type" class="form-select">
                                <option value="standard">Standard</option>
                                <option value="ac">Air Conditioned</option>
                                <option value="deluxe">Deluxe</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Bed Capacity *</label>
                            <input type="number" name="capacity" class="form-control" value="4" min="1" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Fee / Bed (Rs.)</label>
                            <input type="number" step="0.01" name="cost_per_bed" class="form-control" value="0.00">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Create Room</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Allocation -->
<div class="modal fade" id="newAllocationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('hostels/allocations')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Allocate Student to Bed</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Select Student *</label>
                        <select name="student_id" class="form-select" required>
                            <option value="">-- Choose Student --</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?> - <?= e($st['class_name'] ?? '') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Select Room *</label>
                        <select name="room_id" class="form-select" required>
                            <option value="">-- Choose Available Room --</option>
                            <?php foreach ($rooms as $rm): ?>
                                <option value="<?= (int)$rm['id'] ?>">
                                    <?= e($rm['hostel_name']) ?> - Room <?= e($rm['room_number']) ?> (<?= (int)$rm['occupied_beds'] ?>/<?= (int)$rm['capacity'] ?> beds)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Bed Label / Number</label>
                            <input type="text" name="bed_number" class="form-control" placeholder="e.g. Bed-1, Upper Bunk">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Check-in Date *</label>
                            <input type="date" name="allocated_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Emergency contact or special dietary note"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Allocate Bed</button>
                </div>
            </form>
        </div>
    </div>
</div>
