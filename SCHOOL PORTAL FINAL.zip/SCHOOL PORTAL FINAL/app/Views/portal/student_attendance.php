<?php
/**
 * Student Attendance Records - CodeClove School Management Pro UI Match
 */

$year = (int)date('Y', $monthTime);
$month = (int)date('n', $monthTime);
$daysInMonth = (int)date('t', $monthTime);
$firstDayOfWeek = (int)date('N', strtotime("{$year}-{$month}-01")); // 1 (Mon) to 7 (Sun)
$totalWeeks = ceil(($firstDayOfWeek - 1 + $daysInMonth) / 7);
?>

<!-- Header & Month Picker -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
  <div>
    <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Attendance Records</h1>
    <p class="text-muted small mb-0">Monthly attendance calendar and daily records</p>
  </div>
  <div class="d-flex align-items-center bg-white rounded-pill px-3 py-1 shadow-sm border" style="border-color: #e2e8f0 !important;">
    <a href="?month=<?= e($prevMonth) ?>" class="btn btn-sm btn-icon text-secondary p-1 border-0" title="Previous Month">
      <i data-lucide="chevron-left" style="width: 16px; height: 16px;"></i>
    </a>
    <span class="fw-semibold text-dark small px-3" style="font-size: 13px;"><?= e($monthTitle) ?></span>
    <a href="?month=<?= e($nextMonth) ?>" class="btn btn-sm btn-icon text-secondary p-1 border-0" title="Next Month">
      <i data-lucide="chevron-right" style="width: 16px; height: 16px;"></i>
    </a>
  </div>
</div>

<!-- 4 Stat Metric Cards -->
<div class="row g-3 mb-4">
  <!-- Card 1: Attendance Rate -->
  <div class="col-12 col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
            <i data-lucide="calendar" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
          <?= number_format($attendanceRate, 1) ?>%
        </div>
        <div class="fw-semibold text-dark small mb-1" style="font-size: 13px;">Attendance Rate</div>
        <div class="text-muted small" style="font-size: 11px;">
          <?= (int)$presentDays ?> of <?= (int)$totalSchoolDays ?> school days
        </div>
      </div>
    </div>
  </div>

  <!-- Card 2: Present Days -->
  <div class="col-12 col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
            <i data-lucide="check-circle" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
          <?= (int)$presentDays ?>
        </div>
        <div class="fw-semibold text-dark small mb-1" style="font-size: 13px;">Present Days</div>
        <div class="text-muted small" style="font-size: 11px;">Attended sessions</div>
      </div>
    </div>
  </div>

  <!-- Card 3: Absent Days -->
  <div class="col-12 col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fef2f2; width: 34px; height: 34px;">
            <i data-lucide="x-circle" style="width: 16px; height: 16px; stroke: #dc2626;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
          <?= (int)$absentDays ?>
        </div>
        <div class="fw-semibold text-dark small mb-1" style="font-size: 13px;">Absent Days</div>
        <div class="text-muted small" style="font-size: 11px;">Recorded absences</div>
      </div>
    </div>
  </div>

  <!-- Card 4: Late Arrivals -->
  <div class="col-12 col-sm-6 col-xl-3">
    <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
            <i data-lucide="alert-triangle" style="width: 16px; height: 16px; stroke: #d97706;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
          <?= (int)$lateArrivals ?>
        </div>
        <div class="fw-semibold text-dark small mb-1" style="font-size: 13px;">Late Arrivals</div>
        <div class="text-muted small" style="font-size: 11px;">Tardy arrivals</div>
      </div>
    </div>
  </div>
</div>

<!-- Monthly Attendance Calendar Grid (Calendar Overview) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
    <div class="d-flex align-items-center gap-2">
      <i data-lucide="calendar" class="text-secondary" style="width: 16px; height: 16px;"></i>
      <span class="fw-bold text-dark small" style="font-size: 13px;">Calendar Overview</span>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-bordered mb-0" style="border-color: #f1f5f9; table-layout: fixed;">
        <thead>
          <tr class="bg-light text-center text-secondary small" style="font-size: 11px; letter-spacing: 0.05em;">
            <th class="py-2 fw-semibold">MON</th>
            <th class="py-2 fw-semibold">TUE</th>
            <th class="py-2 fw-semibold">WED</th>
            <th class="py-2 fw-semibold">THU</th>
            <th class="py-2 fw-semibold">FRI</th>
            <th class="py-2 fw-semibold">SAT</th>
            <th class="py-2 fw-semibold">SUN</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $dayCounter = 1;
            $cellsWritten = 0;

            for ($w = 0; $w < $totalWeeks; $w++):
          ?>
            <tr>
              <?php for ($d = 1; $d <= 7; $d++): ?>
                <?php
                  $cellsWritten++;
                  $hasDay = ($cellsWritten >= $firstDayOfWeek && $dayCounter <= $daysInMonth);
                  $dayNum = $hasDay ? $dayCounter : null;
                  $dateKey = $hasDay ? sprintf('%04d-%02d-%02d', $year, $month, $dayNum) : null;
                  $dayStatus = ($hasDay && isset($attendanceMap[$dateKey])) ? $attendanceMap[$dateKey]['status'] : null;
                ?>
                <td class="p-2 align-top" style="height: 68px; background: <?= ($d >= 6) ? '#fbfcfe' : '#ffffff' ?>;">
                  <?php if ($hasDay): ?>
                    <div class="d-flex justify-content-end mb-1">
                      <span class="text-secondary small fw-medium" style="font-size: 11px;"><?= $dayNum ?></span>
                    </div>
                    <?php if ($dayStatus === 'present'): ?>
                      <div class="d-flex align-items-center gap-1">
                        <span style="width: 5px; height: 5px; border-radius: 50%; background-color: #16a34a; display: inline-block;"></span>
                        <span class="text-secondary fw-normal" style="font-size: 10px;">Present</span>
                      </div>
                    <?php elseif ($dayStatus === 'absent'): ?>
                      <div class="d-flex align-items-center gap-1">
                        <span style="width: 5px; height: 5px; border-radius: 50%; background-color: #dc2626; display: inline-block;"></span>
                        <span class="text-danger fw-normal" style="font-size: 10px;">Absent</span>
                      </div>
                    <?php elseif ($dayStatus === 'late'): ?>
                      <div class="d-flex align-items-center gap-1">
                        <span style="width: 5px; height: 5px; border-radius: 50%; background-color: #d97706; display: inline-block;"></span>
                        <span class="text-warning fw-normal" style="font-size: 10px;">Late</span>
                      </div>
                    <?php endif; ?>
                    <?php $dayCounter++; ?>
                  <?php endif; ?>
                </td>
              <?php endfor; ?>
            </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Daily Attendance Log -->
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-2" style="border-color: #f1f5f9 !important;">
    <div class="d-flex align-items-center gap-2">
      <i data-lucide="file-text" class="text-secondary" style="width: 16px; height: 16px;"></i>
      <span class="fw-bold text-dark small" style="font-size: 13px;">Daily Attendance Log</span>
    </div>
    <!-- Status Filter Buttons -->
    <div class="btn-group btn-group-sm" role="group" id="attendanceFilterGroup">
      <button type="button" class="btn btn-outline-secondary active text-dark fw-medium px-3" style="font-size: 11px;" onclick="filterAttendanceLog('all', this)">All</button>
      <button type="button" class="btn btn-outline-secondary text-secondary fw-medium px-3" style="font-size: 11px;" onclick="filterAttendanceLog('present', this)">Present</button>
      <button type="button" class="btn btn-outline-secondary text-secondary fw-medium px-3" style="font-size: 11px;" onclick="filterAttendanceLog('absent', this)">Absent</button>
      <button type="button" class="btn btn-outline-secondary text-secondary fw-medium px-3" style="font-size: 11px;" onclick="filterAttendanceLog('late', this)">Late</button>
    </div>
  </div>

  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0" id="attendanceLogTable">
        <thead class="bg-light text-secondary small" style="font-size: 11px; letter-spacing: 0.04em;">
          <tr>
            <th class="ps-4 py-3 border-0">DATE</th>
            <th class="py-3 border-0">STATUS</th>
            <th class="pe-4 py-3 border-0">TEACHER / CLASS NOTE</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($records)): ?>
            <tr>
              <td colspan="3" class="text-center py-4 text-muted small">No attendance records found for this period.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($records as $rec): ?>
              <?php
                $st = strtolower($rec['status'] ?? 'present');
                $dFormatted = date('d/m/Y', strtotime($rec['attendance_date']));
                $badgeStyle = match ($st) {
                    'present' => 'background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;',
                    'absent' => 'background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;',
                    'late' => 'background: #fffbeb; color: #d97706; border: 1px solid #fde68a;',
                    default => 'background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;'
                };
                $statusText = ucfirst($st);
              ?>
              <tr class="attendance-log-row" data-status="<?= e($st) ?>" style="border-bottom: 1px solid #f8fafc;">
                <td class="ps-4 py-3 text-secondary font-monospace" style="font-size: 12px;">
                  <?= e($dFormatted) ?>
                </td>
                <td class="py-3">
                  <span class="badge rounded-pill px-3 py-1 fw-medium" style="<?= $badgeStyle ?> font-size: 11px;">
                    <?= e($statusText) ?>
                  </span>
                </td>
                <td class="pe-4 py-3 text-muted small" style="font-size: 12px;">
                  <?= e(!empty($rec['remarks']) ? $rec['remarks'] : '—') ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function filterAttendanceLog(status, btn) {
  const group = document.getElementById('attendanceFilterGroup');
  group.querySelectorAll('button').forEach(b => {
    b.classList.remove('active', 'text-dark');
    b.classList.add('text-secondary');
  });
  btn.classList.add('active', 'text-dark');
  btn.classList.remove('text-secondary');

  const rows = document.querySelectorAll('#attendanceLogTable .attendance-log-row');
  rows.forEach(r => {
    if (status === 'all' || r.getAttribute('data-status') === status) {
      r.style.display = '';
    } else {
      r.style.display = 'none';
    }
  });
}
</script>
