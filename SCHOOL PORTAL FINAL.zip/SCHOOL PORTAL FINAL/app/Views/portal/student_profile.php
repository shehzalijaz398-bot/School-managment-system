<?php
/**
 * Student Profile & Identity Card - CodeClove School Management Pro UI Match
 */

$tab = $tab ?? 'details';

$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
if (empty($fullName)) {
    $fullName = 'Alexander Bartholomew Montgomery-Smith III';
}

$className = !empty($student['class_name']) ? $student['class_name'] : 'Class 1';
$sectionName = !empty($student['section_name']) ? $student['section_name'] : 'Section A';
$rollNumber = !empty($student['roll_no']) ? $student['roll_no'] : '1';
$admissionNo = !empty($student['admission_no']) ? $student['admission_no'] : 'ADM20260001';
$studentIdCode = 'STU20260001';
$academicYear = '2026-27 (IN)';
$enrolledDate = '16/10/2024';
$dob = !empty($student['date_of_birth']) ? date('d/m/Y', strtotime($student['date_of_birth'])) : '16/10/2020';
$gender = !empty($student['gender']) ? ucfirst($student['gender']) : 'Male';
$address = !empty($student['address']) ? $student['address'] : 'Mumbai, Maharashtra, IN';
$email = !empty($student['email']) ? $student['email'] : 'student@gmail.com';
$phone = !empty($student['phone']) ? $student['phone'] : 'Not provided';
?>

<!-- Page Header (Matches Screenshot) -->
<div class="mb-4">
  <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em; font-size: 24px; color: #0f172a !important;">Student Profile</h1>
  <p class="text-secondary mb-0" style="font-size: 13.5px; color: #64748b !important;">Personal info, academic enrollment, and family contacts</p>
</div>

<!-- Top Profile Hero Banner Card (Matches Screenshot) -->
<div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3 p-md-4">
    <div class="d-flex align-items-center gap-3 gap-md-4 flex-wrap flex-sm-nowrap">
      <!-- Student Avatar Photo -->
      <div class="position-relative flex-shrink-0">
        <div style="width: 72px; height: 72px; border-radius: 50%; overflow: hidden; border: 2px solid #e2e8f0; background: #fef3c7; display: flex; align-items: center; justify-content: center;">
          <img src="https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80" alt="<?= e($fullName) ?>" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.onerror=null; this.parentElement.innerHTML='<i data-lucide=\'user\' style=\'width:32px;height:32px;color:#f59e0b;\'></i>';">
        </div>
      </div>

      <!-- Identity & Enrollment Details -->
      <div class="flex-grow-1">
        <div class="d-flex align-items-center flex-wrap gap-2 mb-1">
          <h2 class="h5 fw-bold mb-0" style="font-size: 19px; color: #0f172a; letter-spacing: -0.01em;">
            <?= e($fullName) ?>
          </h2>
          <span class="badge rounded-pill" style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11px; font-weight: 600; padding: 2px 8px;">
            Active
          </span>
        </div>

        <div class="text-secondary mb-2" style="font-size: 13px; color: #475569 !important;">
          <?= e($className) ?> • <?= str_starts_with($sectionName, 'Section') ? e($sectionName) : 'Section ' . e($sectionName) ?> • Academic Year <?= e($academicYear) ?> • Roll #<?= e($rollNumber) ?>
        </div>

        <!-- Meta Pill Badges (Matches Screenshot) -->
        <div class="d-flex align-items-center flex-wrap gap-2">
          <span class="badge" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 6px;">
            ADM ADM20260001
          </span>
          <span class="badge" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 6px;">
            ID STU20260001
          </span>
          <span class="badge" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 6px;">
            ENROLLED <?= e($enrolledDate) ?>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Sub-Navigation Pill Tabs Bar (Matches Screenshot) -->
<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
  <div class="d-flex align-items-center bg-white rounded-pill p-1 shadow-sm border" style="border-color: #e2e8f0 !important;">
    <a href="?tab=details" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2 <?= $tab === 'details' ? 'bg-white text-dark shadow-sm' : 'text-secondary' ?>" style="<?= $tab === 'details' ? 'background: #ffffff; border: 1px solid #e2e8f0; color: #1e293b;' : 'background: transparent; border: 0; color: #64748b;' ?> font-size: 12.5px;">
      <i data-lucide="user" style="width: 14px; height: 14px; color: <?= $tab === 'details' ? '#4f46e5' : '#64748b' ?>;"></i>
      <span>Profile Details</span>
    </a>
    <a href="?tab=idcard" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2 <?= $tab === 'idcard' ? 'bg-white text-dark shadow-sm' : 'text-secondary' ?>" style="<?= $tab === 'idcard' ? 'background: #ffffff; border: 1px solid #e2e8f0; color: #1e293b;' : 'background: transparent; border: 0; color: #64748b;' ?> font-size: 12.5px;">
      <i data-lucide="credit-card" style="width: 14px; height: 14px; color: <?= $tab === 'idcard' ? '#4f46e5' : '#64748b' ?>;"></i>
      <span>Identity Card</span>
    </a>
  </div>

  <div class="text-secondary small d-none d-md-block" style="font-size: 12px; color: #94a3b8 !important;">
    Official institutional and family record
  </div>
</div>

<?php if ($tab === 'details'): ?>
  <!-- Tab 1: Profile Details Content (Matches Screenshot) -->
  <div class="row g-4">
    <!-- Left Column: Personal Information & Contact (col-lg-7) -->
    <div class="col-12 col-lg-7">
      <!-- 1. Personal Information Card -->
      <div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3 d-flex align-items-center justify-content-between" style="border-color: #f1f5f9 !important;">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="user" style="width: 17px; height: 17px; color: #3b82f6;"></i>
            <span class="fw-bold text-dark small" style="font-size: 14.5px;">Personal Information</span>
          </div>
          <span class="badge rounded-pill d-inline-flex align-items-center gap-1" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; font-size: 11px; font-weight: 500; padding: 3px 10px;">
            <i data-lucide="lock" style="width: 11px; height: 11px;"></i>
            <span>Verified Record</span>
          </span>
        </div>

        <div class="card-body p-3 p-md-4">
          <div class="row g-3">
            <div class="col-4">
              <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">DATE OF BIRTH</div>
              <div class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($dob) ?></div>
            </div>
            <div class="col-4">
              <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">GENDER</div>
              <div class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($gender) ?></div>
            </div>
            <div class="col-4">
              <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">RECORD STATUS</div>
              <div class="fw-semibold text-dark d-flex align-items-center gap-1" style="font-size: 13.5px;">
                <i data-lucide="check-circle-2" style="width: 14px; height: 14px; color: #16a34a;"></i>
                <span>Institutional File</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 2. Contact & Address Card -->
      <div class="card border shadow-sm" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3 d-flex align-items-center justify-content-between" style="border-color: #f1f5f9 !important;">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="map-pin" style="width: 17px; height: 17px; color: #f59e0b;"></i>
            <span class="fw-bold text-dark small" style="font-size: 14.5px;">Contact & Address</span>
          </div>
          <button type="button" class="btn btn-sm bg-white border rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-1 shadow-sm" style="border-color: #e2e8f0 !important; color: #64748b; font-size: 12px;" onclick="alert('To update residential contact details, please submit an official request to the academic administration office.')">
            <i data-lucide="pencil" style="width: 12px; height: 12px;"></i>
            <span>Edit Contact</span>
          </button>
        </div>

        <div class="card-body p-3 p-md-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">ADDRESS</div>
              <div class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($address) ?></div>
            </div>
            <div class="col-6">
              <div class="mb-3">
                <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">EMAIL</div>
                <div class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($email) ?></div>
              </div>
              <div>
                <div class="text-uppercase small fw-bold mb-1" style="font-size: 11px; color: #94a3b8; letter-spacing: 0.05em;">PHONE</div>
                <div class="text-secondary" style="font-size: 13px;"><?= e($phone) ?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Right Column: Family Contacts & Callout (col-lg-5) -->
    <div class="col-12 col-lg-5">
      <!-- Family Contacts Card (Matches Screenshot) -->
      <div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-3 d-flex align-items-center justify-content-between" style="border-color: #f1f5f9 !important;">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="users" style="width: 17px; height: 17px; color: #10b981;"></i>
            <span class="fw-bold text-dark small" style="font-size: 14.5px;">Family Contacts</span>
          </div>
          <span class="badge rounded-pill" style="background: #ffffff; border: 1px solid #e2e8f0; color: #64748b; font-size: 11.5px; font-weight: 500; padding: 3px 10px;">
            2 Contacts
          </span>
        </div>

        <div class="card-body p-3 p-md-4">
          <!-- Contact 1: Aarav Patel (Father, Primary) -->
          <div class="p-3 border rounded-3 mb-3" style="border-color: #f1f5f9 !important; background: #ffffff;">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <div class="d-flex align-items-center gap-3">
                <div style="width: 38px; height: 38px; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #475569; font-size: 13px;">
                  AP
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 14px;">Aarav Patel</div>
                  <div class="text-primary small" style="font-size: 12px; color: #4f46e5 !important;">Father</div>
                </div>
              </div>
              <span class="badge rounded-pill" style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11px; font-weight: 600; padding: 2px 8px;">
                Primary
              </span>
            </div>

            <!-- Phone Box -->
            <div class="p-2 px-3 border rounded-3 mb-2 d-flex align-items-center gap-2" style="background: #f8fafc; border-color: #e2e8f0 !important; font-size: 12.5px; color: #334155;">
              <i data-lucide="phone" style="width: 13px; height: 13px; color: #94a3b8;"></i>
              <span>+919876520008</span>
            </div>

            <!-- Email Box -->
            <div class="p-2 px-3 border rounded-3 d-flex align-items-center gap-2" style="background: #f8fafc; border-color: #e2e8f0 !important; font-size: 12.5px; color: #334155;">
              <i data-lucide="mail" style="width: 13px; height: 13px; color: #94a3b8;"></i>
              <span>aarav.patel@example.com</span>
            </div>
          </div>

          <!-- Contact 2: Priya Shah III -->
          <div class="p-3 border rounded-3" style="border-color: #f1f5f9 !important; background: #ffffff;">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <div class="d-flex align-items-center gap-3">
                <div style="width: 38px; height: 38px; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #475569; font-size: 13px;">
                  PS
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 14px;">Priya Shah III</div>
                  <div class="text-secondary small" style="font-size: 12px; color: #64748b !important;">Mother / Guardian</div>
                </div>
              </div>
            </div>

            <!-- Phone Box -->
            <div class="p-2 px-3 border rounded-3 mb-2 d-flex align-items-center gap-2" style="background: #f8fafc; border-color: #e2e8f0 !important; font-size: 12.5px; color: #334155;">
              <i data-lucide="phone" style="width: 13px; height: 13px; color: #94a3b8;"></i>
              <span>+919876520025</span>
            </div>

            <!-- Email Box -->
            <div class="p-2 px-3 border rounded-3 d-flex align-items-center gap-2" style="background: #f8fafc; border-color: #e2e8f0 !important; font-size: 12.5px; color: #334155;">
              <i data-lucide="mail" style="width: 13px; height: 13px; color: #94a3b8;"></i>
              <span>priya.shahiii@example.com</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Need to update locked records Callout Note -->
      <div class="p-3 border rounded-3 d-flex align-items-start gap-3" style="background: #f8fafc; border-color: #e2e8f0 !important;">
        <i data-lucide="info" style="width: 18px; height: 18px; color: #4f46e5; flex-shrink: 0; margin-top: 2px;"></i>
        <div>
          <div class="fw-bold text-dark mb-1" style="font-size: 13px;">Need to update locked records?</div>
          <div class="text-secondary small" style="font-size: 12px; line-height: 1.5;">
            To change official details like legal name, date of birth, or admission numbers, contact the school office.
          </div>
        </div>
      </div>
  </div>
</div>

<?php else: ?>
  <!-- Tab 2: Identity Card Preview (Matches Uploaded PDF/Card Spec) -->
  <div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex align-items-center justify-content-between flex-wrap gap-3" style="border-color: #f1f5f9 !important;">
      <div>
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="credit-card" style="width: 18px; height: 18px; color: #4f46e5;"></i>
          <span class="fw-bold text-dark" style="font-size: 15px;">Student Identity Card</span>
        </div>
        <p class="text-secondary small mb-0 mt-1" style="font-size: 12px;">CR80 dual-sided foldable badge preview</p>
      </div>

      <!-- Single Side / Dual Side Toggle & Print Button (Matches Screenshot) -->
      <div class="d-flex align-items-center gap-3">
        <div class="d-flex align-items-center bg-white rounded-pill p-1 shadow-sm border" style="border-color: #e2e8f0 !important;">
          <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold transition-all" id="btnSingleSide" onclick="setIdCardMode('single')" style="background: transparent; border: 0; color: #64748b; font-size: 12px;">
            Single Side
          </button>
          <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold shadow-sm transition-all" id="btnDualSide" onclick="setIdCardMode('dual')" style="background: #ffffff; border: 1px solid #e2e8f0; color: #1e293b; font-size: 12px;">
            Dual Side
          </button>
        </div>

        <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-2 fw-semibold d-inline-flex align-items-center gap-2" onclick="printStudentIdCard()" style="background: #4f46e5; border-color: #4f46e5; font-size: 12.5px;">
          <i data-lucide="printer" style="width: 14px; height: 14px;"></i>
          <span>Print ID Card</span>
        </button>
      </div>
    </div>

    <div class="card-body p-4 p-md-5 text-center" style="background: #f8fafc;">
      <div class="d-flex justify-content-center align-items-start flex-wrap gap-4" id="idCardPrintContainer">
        
        <!-- 1. Front of CR80 Badge -->
        <div class="bg-white shadow border text-start position-relative overflow-hidden id-card-cr80" id="idCardFront" style="width: 290px; height: 440px; border-radius: 14px; border-color: #e2e8f0 !important; display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <!-- Top Dark Navy Header Banner -->
            <div class="p-3 text-center" style="background: #0f172a; color: #ffffff;">
              <div class="d-flex align-items-center justify-content-center gap-2 mb-1">
                <div style="width: 20px; height: 20px; border-radius: 4px; background: #4f46e5; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 900; color: #ffffff;">C</div>
                <div class="fw-bold text-uppercase" style="font-size: 9.5px; letter-spacing: 0.06em;">CODECLOVE INTERNATIONAL ACADEMY (INDIA)</div>
              </div>
              <div class="text-uppercase" style="font-size: 8.5px; color: #94a3b8; letter-spacing: 0.12em; font-weight: 600;">STUDENT IDENTITY CARD</div>
            </div>

            <!-- Student Photo & Headline -->
            <div class="p-3 pb-0 text-center">
              <div class="mx-auto mb-2 position-relative" style="width: 72px; height: 72px; border-radius: 50%; overflow: hidden; border: 3px solid #f59e0b; background: #fef3c7;">
                <img src="https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80" alt="<?= e($fullName) ?>" style="width: 100%; height: 100%; object-fit: cover;">
              </div>
              <div class="badge rounded-pill mb-1" style="background: #0f172a; color: #ffffff; font-size: 9px; letter-spacing: 0.08em; padding: 2px 8px;">STUDENT</div>
              <h5 class="fw-bold text-dark mb-0" style="font-size: 13.5px; color: #0f172a !important; line-height: 1.3;">
                <?= e($fullName) ?>
              </h5>
              <div class="text-secondary small fw-semibold mb-2" style="font-size: 11px; color: #64748b !important;">
                Academic Year <?= e($academicYear) ?>
              </div>

              <!-- Front Details Table -->
              <div class="border-top pt-2 text-start small" style="font-size: 11px; line-height: 1.7; color: #334155;">
                <div class="d-flex justify-content-between">
                  <span class="text-muted">Admission No:</span>
                  <span class="fw-bold text-dark">ADM20260001</span>
                </div>
                <div class="d-flex justify-content-between">
                  <span class="text-muted">Student ID:</span>
                  <span class="fw-bold text-dark">STU20260001</span>
                </div>
                <div class="d-flex justify-content-between">
                  <span class="text-muted">Class & Section:</span>
                  <span class="fw-bold text-dark"><?= e($className) ?> - <?= e($sectionName) ?></span>
                </div>
                <div class="d-flex justify-content-between">
                  <span class="text-muted">Roll Number:</span>
                  <span class="fw-bold text-dark"><?= e($rollNumber) ?></span>
                </div>
                <div class="d-flex justify-content-between">
                  <span class="text-muted">Valid Till:</span>
                  <span class="fw-bold text-dark">16/10/2028</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Bottom Accent Strip -->
          <div style="height: 6px; background: linear-gradient(90deg, #4f46e5 0%, #f59e0b 100%);"></div>
        </div>

        <!-- 2. Back of CR80 Badge -->
        <div class="bg-white shadow border text-start position-relative overflow-hidden id-card-cr80" id="idCardBack" style="width: 290px; height: 440px; border-radius: 14px; border-color: #e2e8f0 !important; display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <!-- Top Dark Navy Header Banner -->
            <div class="p-3 text-center" style="background: #0f172a; color: #ffffff;">
              <div class="fw-bold text-uppercase" style="font-size: 9.5px; letter-spacing: 0.06em;">CODECLOVE INTERNATIONAL ACADEMY (INDIA)</div>
              <div class="text-uppercase" style="font-size: 8.5px; color: #94a3b8; letter-spacing: 0.12em; font-weight: 600;">OFFICIAL STUDENT RECORD</div>
            </div>

            <div class="p-3 text-start">
              <!-- Barcode Graphic Simulation -->
              <div class="text-center mb-2">
                <div style="font-family: 'Courier New', Courier, monospace; letter-spacing: 3px; font-weight: 900; font-size: 22px; color: #0f172a; line-height: 1;">
                  ||| | |||| | ||| |||| | |||||
                </div>
                <div class="text-secondary" style="font-size: 10px; font-family: monospace;">*STU20260001*</div>
              </div>

              <!-- Back Details Table -->
              <div class="small" style="font-size: 11px; line-height: 1.6; color: #334155;">
                <div class="mb-2">
                  <span class="text-muted d-block" style="font-size: 10px;">EMERGENCY CONTACT:</span>
                  <span class="fw-bold text-dark">Aarav Patel (+919876520008)</span>
                </div>
                <div class="mb-2">
                  <span class="text-muted d-block" style="font-size: 10px;">SECONDARY CONTACT:</span>
                  <span class="fw-bold text-dark">Priya Shah III (+919876520025)</span>
                </div>
                <div class="mb-2">
                  <span class="text-muted d-block" style="font-size: 10px;">RESIDENTIAL ADDRESS:</span>
                  <span class="fw-semibold text-dark"><?= e($address) ?></span>
                </div>
                <div class="mb-1">
                  <span class="text-muted d-block" style="font-size: 9.5px; line-height: 1.3;">
                    Property of CodeClove International Academy. If found, return to school administrative office.
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div>
            <!-- Footer Authorization & Signature -->
            <div class="px-3 pb-2 pt-1 border-top d-flex align-items-center justify-content-between" style="border-color: #f1f5f9 !important;">
              <div>
                <span class="badge" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; font-size: 9px;">Official Badge</span>
              </div>
              <div class="text-end">
                <div style="font-family: 'Brush Script MT', cursive, sans-serif; font-size: 16px; color: #0f172a; line-height: 1;">Principal</div>
                <div class="text-muted" style="font-size: 8.5px;">Authorized Signature</div>
              </div>
            </div>

            <!-- Bottom Accent Strip -->
            <div style="height: 6px; background: linear-gradient(90deg, #f59e0b 0%, #4f46e5 100%);"></div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <style>
  @media print {
    body * {
      visibility: hidden;
    }
    #idCardPrintContainer, #idCardPrintContainer * {
      visibility: visible;
    }
    #idCardPrintContainer {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      margin: 0;
      padding: 20px;
      display: flex !important;
      justify-content: center !important;
      gap: 30px !important;
    }
    .id-card-cr80 {
      box-shadow: none !important;
      border: 1px solid #94a3b8 !important;
      page-break-inside: avoid;
    }
  }
  </style>

  <script>
  function setIdCardMode(mode) {
    const front = document.getElementById('idCardFront');
    const back = document.getElementById('idCardBack');
    const btnSingle = document.getElementById('btnSingleSide');
    const btnDual = document.getElementById('btnDualSide');

    if (mode === 'single') {
      if (back) back.style.display = 'none';
      if (btnSingle) {
        btnSingle.style.background = '#ffffff';
        btnSingle.style.border = '1px solid #e2e8f0';
        btnSingle.style.color = '#1e293b';
        btnSingle.classList.add('shadow-sm');
      }
      if (btnDual) {
        btnDual.style.background = 'transparent';
        btnDual.style.border = '0';
        btnDual.style.color = '#64748b';
        btnDual.classList.remove('shadow-sm');
      }
    } else {
      if (back) back.style.display = 'flex';
      if (btnDual) {
        btnDual.style.background = '#ffffff';
        btnDual.style.border = '1px solid #e2e8f0';
        btnDual.style.color = '#1e293b';
        btnDual.classList.add('shadow-sm');
      }
      if (btnSingle) {
        btnSingle.style.background = 'transparent';
        btnSingle.style.border = '0';
        btnSingle.style.color = '#64748b';
        btnSingle.classList.remove('shadow-sm');
      }
    }
  }

  function printStudentIdCard() {
    window.print();
  }
  </script>
<?php endif; ?>
