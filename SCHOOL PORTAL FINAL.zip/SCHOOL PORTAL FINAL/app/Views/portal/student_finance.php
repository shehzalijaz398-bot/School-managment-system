<?php
/**
 * Student Fee & Payment Records - CodeClove School Management Pro UI Match
 */
?>

<!-- Header -->
<div class="mb-4">
  <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Fee &amp; Payment Records</h1>
  <p class="text-muted small mb-0">Invoices, payment history, and fee balances</p>
</div>

<!-- 4 Unified Stat Metric Columns inside 1 Container Card (Matches Screenshot) -->
<div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff; overflow: hidden;">
  <div class="row g-0">
    <!-- Metric 1: Total Invoiced -->
    <div class="col-12 col-sm-6 col-lg-3 p-4 border-end" style="border-color: #e2e8f0 !important;">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-secondary small fw-medium" style="font-size: 13px; color: #64748b !important;">Total Invoiced</span>
        <div style="background: #eef2ff; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
          <i data-lucide="receipt" style="width: 15px; height: 15px; color: #4f46e5;"></i>
        </div>
      </div>
      <div class="h3 fw-bold text-dark mb-1" style="font-size: 26px; letter-spacing: -0.02em; color: #0f172a !important;">
        ₹<?= number_format($totalInvoiced, 2) ?>
      </div>
      <div class="text-secondary small" style="font-size: 12px; color: #94a3b8 !important;">All term fees billed</div>
    </div>

    <!-- Metric 2: Total Paid -->
    <div class="col-12 col-sm-6 col-lg-3 p-4 border-end" style="border-color: #e2e8f0 !important;">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-secondary small fw-medium" style="font-size: 13px; color: #64748b !important;">Total Paid</span>
        <div style="background: #f0fdf4; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
          <i data-lucide="check-circle" style="width: 15px; height: 15px; color: #16a34a;"></i>
        </div>
      </div>
      <div class="h3 fw-bold mb-1" style="font-size: 26px; letter-spacing: -0.02em; color: #16a34a !important;">
        ₹<?= number_format($totalPaid, 2) ?>
      </div>
      <div class="text-secondary small" style="font-size: 12px; color: #94a3b8 !important;">Cleared payments</div>
    </div>

    <!-- Metric 3: Balance Due -->
    <div class="col-12 col-sm-6 col-lg-3 p-4 border-end" style="border-color: #e2e8f0 !important;">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-secondary small fw-medium" style="font-size: 13px; color: #64748b !important;">Balance Due</span>
        <div style="background: #eef2ff; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
          <i data-lucide="credit-card" style="width: 15px; height: 15px; color: #4f46e5;"></i>
        </div>
      </div>
      <div class="h3 fw-bold text-dark mb-1" style="font-size: 26px; letter-spacing: -0.02em; color: #0f172a !important;">
        ₹<?= number_format($balanceDue, 2) ?>
      </div>
      <div class="text-secondary small" style="font-size: 12px; color: #94a3b8 !important;">Outstanding dues</div>
    </div>

    <!-- Metric 4: Overdue -->
    <div class="col-12 col-sm-6 col-lg-3 p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-secondary small fw-medium" style="font-size: 13px; color: #64748b !important;">Overdue</span>
        <div style="background: #eef2ff; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
          <i data-lucide="info" style="width: 15px; height: 15px; color: #4f46e5;"></i>
        </div>
      </div>
      <div class="h3 fw-bold text-dark mb-1" style="font-size: 26px; letter-spacing: -0.02em; color: #0f172a !important;">
        ₹<?= number_format($overdue, 2) ?>
      </div>
      <div class="text-secondary small" style="font-size: 12px; color: #94a3b8 !important;">Past payment date</div>
    </div>
  </div>
</div>

<!-- Tab Switcher Bar & Hint (Matches Screenshot) -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3">
  <!-- Nav Tabs Pills inside single rounded background pill -->
  <div class="d-flex align-items-center bg-white rounded-pill p-1 shadow-sm border" style="border-color: #e2e8f0 !important;">
    <button class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2 shadow-sm active" id="invoices-tab" data-bs-toggle="pill" data-bs-target="#invoices-content" type="button" role="tab" style="font-size: 12.5px; background-color: #ffffff; color: #1e293b; border: 1px solid #e2e8f0;">
      <i data-lucide="receipt" style="width: 14px; height: 14px; color: #4f46e5;"></i>
      <span>Invoices</span>
      <span class="badge rounded-pill text-secondary border ms-1" style="font-size: 10px; background: #f8fafc; border-color: #e2e8f0 !important;"><?= count($invoices) ?></span>
    </button>
    <button class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2" id="receipts-tab" data-bs-toggle="pill" data-bs-target="#receipts-content" type="button" role="tab" style="font-size: 12.5px; background-color: transparent; color: #64748b; border: 0;">
      <i data-lucide="file-check" style="width: 14px; height: 14px; color: #64748b;"></i>
      <span>Payment Receipts</span>
      <span class="badge rounded-pill text-secondary border ms-1" style="font-size: 10px; background: #f8fafc; border-color: #e2e8f0 !important;"><?= count(array_filter($invoices, fn($i) => (float)$i['paid_amount'] > 0)) ?></span>
    </button>
  </div>
  <span class="text-secondary small" style="font-size: 12px; color: #94a3b8 !important;">Click any invoice to view breakdown &amp; receipts</span>
</div>

<!-- Tab Content -->
<div class="tab-content" id="financeTabContent">
  
  <!-- 1. Invoices Tab Pane -->
  <div class="tab-pane fade show active" id="invoices-content" role="tabpanel">
    <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="bg-light text-secondary small" style="font-size: 11px; letter-spacing: 0.04em;">
              <tr>
                <th class="ps-4 py-3 border-0">INVOICE #</th>
                <th class="py-3 border-0">ISSUED DATE</th>
                <th class="py-3 border-0">DUE DATE</th>
                <th class="py-3 border-0">TOTAL</th>
                <th class="py-3 border-0">PAID</th>
                <th class="py-3 border-0">BALANCE</th>
                <th class="py-3 border-0">STATUS</th>
                <th class="pe-4 py-3 border-0 text-end">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($invoices)): ?>
                <tr>
                  <td colspan="8" class="text-center py-4 text-muted small">No invoices found.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($invoices as $inv): ?>
                  <?php
                    $tot = (float)$inv['total_amount'];
                    $paid = (float)$inv['paid_amount'];
                    $bal = max(0, $tot - $paid);
                    $st = strtolower($inv['status'] ?? 'paid');
                    $badgeStyle = match ($st) {
                        'paid' => 'background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;',
                        'partially_paid' => 'background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;',
                        'unpaid' => 'background: #fffbeb; color: #d97706; border: 1px solid #fde68a;',
                        default => 'background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;'
                    };
                    $issuedFormatted = !empty($inv['invoice_date']) ? date('d/m/Y', strtotime($inv['invoice_date'])) : '16/10/2026';
                    $dueFormatted = !empty($inv['due_date']) ? date('d/m/Y', strtotime($inv['due_date'])) : '31/10/2026';
                    $invNumber = $inv['invoice_no'] ?? '#INV202610001';
                    if (!str_starts_with($invNumber, '#')) {
                        $invNumber = '#' . $invNumber;
                    }
                  ?>
                  <tr style="border-bottom: 1px solid #f8fafc;">
                    <!-- Invoice # -->
                    <td class="ps-4 py-3">
                      <span class="fw-semibold text-dark font-monospace" style="font-size: 12px; letter-spacing: 0.02em;">
                        <?= e($invNumber) ?>
                      </span>
                    </td>
                    <!-- Issued Date -->
                    <td class="py-3 text-secondary font-monospace" style="font-size: 12px;">
                      <?= e($issuedFormatted) ?>
                    </td>
                    <!-- Due Date -->
                    <td class="py-3 text-secondary font-monospace" style="font-size: 12px;">
                      <?= e($dueFormatted) ?>
                    </td>
                    <!-- Total -->
                    <td class="py-3 fw-semibold text-dark" style="font-size: 13px;">
                      ₹<?= number_format($tot, 2) ?>
                    </td>
                    <!-- Paid -->
                    <td class="py-3 fw-semibold" style="font-size: 13px; color: #16a34a;">
                      ₹<?= number_format($paid, 2) ?>
                    </td>
                    <!-- Balance -->
                    <td class="py-3 fw-normal text-secondary" style="font-size: 13px;">
                      ₹<?= number_format($bal, 2) ?>
                    </td>
                    <!-- Status -->
                    <td class="py-3">
                      <span class="badge rounded-pill px-3 py-1 fw-medium" style="<?= $badgeStyle ?> font-size: 11px;">
                        <?= ucfirst(str_replace('_', ' ', $st)) ?>
                      </span>
                    </td>
                    <!-- Actions -->
                    <td class="pe-4 py-3 text-end">
                      <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium d-inline-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#invoiceModal<?= (int)$inv['id'] ?>" style="background: #ffffff; border: 1px solid #e2e8f0; color: #475569; font-size: 11.5px;">
                        <i data-lucide="eye" style="width: 13px; height: 13px;"></i>
                        <span>View</span>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- 2. Payment Receipts Tab Pane -->
  <div class="tab-pane fade" id="receipts-content" role="tabpanel">
    <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="bg-light text-secondary small" style="font-size: 11px; letter-spacing: 0.04em;">
              <tr>
                <th class="ps-4 py-3 border-0">RECEIPT #</th>
                <th class="py-3 border-0">DATE</th>
                <th class="py-3 border-0">INVOICE #</th>
                <th class="py-3 border-0">METHOD</th>
                <th class="py-3 border-0">AMOUNT</th>
                <th class="py-3 border-0">STATUS</th>
                <th class="pe-4 py-3 border-0 text-end">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $receiptsFound = false;
                foreach ($invoices as $inv): 
                  if ((float)$inv['paid_amount'] > 0): 
                    $receiptsFound = true;
                    $invNumber = $inv['invoice_no'] ?? '#INV202610001';
                    if (!str_starts_with($invNumber, '#')) {
                        $invNumber = '#' . $invNumber;
                    }
              ?>
                <tr style="border-bottom: 1px solid #f8fafc;">
                  <td class="ps-4 py-3 font-monospace fw-semibold text-dark" style="font-size: 12px;">
                    #REC-<?= date('Ym', strtotime($inv['invoice_date'] ?? 'now')) ?>-<?= (int)$inv['id'] ?>
                  </td>
                  <td class="py-3 text-secondary font-monospace" style="font-size: 12px;">
                    <?= date('d/m/Y', strtotime($inv['invoice_date'] ?? 'now')) ?>
                  </td>
                  <td class="py-3 font-monospace text-secondary" style="font-size: 12px;">
                    <?= e($invNumber) ?>
                  </td>
                  <td class="py-3 text-secondary small" style="font-size: 12px;">
                    Online Transfer
                  </td>
                  <td class="py-3 fw-bold text-success" style="font-size: 13px;">
                    ₹<?= number_format((float)$inv['paid_amount'], 2) ?>
                  </td>
                  <td class="py-3">
                    <span class="badge rounded-pill px-3 py-1 fw-medium" style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 11px;">
                      Cleared
                    </span>
                  </td>
                  <td class="pe-4 py-3 text-end">
                    <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-1 border-0 fw-medium px-2 py-1 text-secondary" data-bs-toggle="modal" data-bs-target="#invoiceModal<?= (int)$inv['id'] ?>" style="font-size: 12px;">
                      <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                      <span>Receipt</span>
                    </button>
                  </td>
                </tr>
              <?php 
                  endif;
                endforeach; 
                if (!$receiptsFound):
              ?>
                <tr>
                  <td colspan="7" class="text-center py-4 text-muted small">No payment receipts found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Modals Placed Safely OUTSIDE Table and Outside Container to Prevent DOM Corruption -->
<?php foreach ($invoices as $inv): ?>
  <?php
    $tot = (float)$inv['total_amount'];
    $paid = (float)$inv['paid_amount'];
    $bal = max(0, $tot - $paid);
    $st = strtolower($inv['status'] ?? 'paid');
    $badgeStyle = match ($st) {
        'paid' => 'background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;',
        'partially_paid' => 'background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;',
        'unpaid' => 'background: #fffbeb; color: #d97706; border: 1px solid #fde68a;',
        default => 'background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;'
    };
    $issuedFormatted = !empty($inv['invoice_date']) ? date('d/m/Y', strtotime($inv['invoice_date'])) : '16/10/2026';
    $dueFormatted = !empty($inv['due_date']) ? date('d/m/Y', strtotime($inv['due_date'])) : '31/10/2026';
    $invNumber = $inv['invoice_no'] ?? '#INV202610001';
    if (!str_starts_with($invNumber, '#')) {
        $invNumber = '#' . $invNumber;
    }
  ?>
  <div class="modal fade" id="invoiceModal<?= (int)$inv['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg" style="border-radius: 14px; overflow: hidden;">
        <div class="modal-header border-bottom p-4 bg-light">
          <div>
            <h5 class="modal-title fw-bold text-dark mb-0">Invoice <?= e($invNumber) ?></h5>
            <span class="text-muted small"><?= e($inv['title'] ?? 'Tuition & Term Fee') ?></span>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="d-flex justify-content-between mb-3 pb-3 border-bottom">
            <div>
              <span class="text-muted small d-block">Student</span>
              <strong class="text-dark"><?= e($student['first_name'] . ' ' . $student['last_name']) ?></strong>
              <div class="small text-muted"><?= e($student['class_name'] ?? 'Class 1') ?> - Sec <?= e($student['section_name'] ?? 'A') ?></div>
            </div>
            <div class="text-end">
              <span class="text-muted small d-block">Status</span>
              <span class="badge rounded-pill px-3 py-1 fw-medium mt-1" style="<?= $badgeStyle ?> font-size: 11px;">
                <?= ucfirst(str_replace('_', ' ', $st)) ?>
              </span>
            </div>
          </div>

          <div class="row g-2 mb-3">
            <div class="col-6">
              <div class="p-2 bg-light rounded-2">
                <span class="text-muted small d-block" style="font-size: 11px;">Issued Date</span>
                <span class="fw-semibold text-dark small"><?= e($issuedFormatted) ?></span>
              </div>
            </div>
            <div class="col-6">
              <div class="p-2 bg-light rounded-2">
                <span class="text-muted small d-block" style="font-size: 11px;">Due Date</span>
                <span class="fw-semibold text-dark small"><?= e($dueFormatted) ?></span>
              </div>
            </div>
          </div>

          <div class="table-responsive mb-3">
            <table class="table table-sm border mb-0">
              <thead class="bg-light">
                <tr class="text-secondary small" style="font-size: 11px;">
                  <th class="ps-3 py-2">Item Description</th>
                  <th class="pe-3 py-2 text-end">Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="ps-3 py-2 small text-dark"><?= e($inv['title'] ?? 'Session Fee - Term 1') ?></td>
                  <td class="pe-3 py-2 small text-end fw-semibold">₹<?= number_format($tot, 2) ?></td>
                </tr>
              </tbody>
              <tfoot class="bg-light">
                <tr>
                  <td class="ps-3 py-2 fw-bold small text-dark">Total Paid</td>
                  <td class="pe-3 py-2 text-end fw-bold small text-success">₹<?= number_format($paid, 2) ?></td>
                </tr>
                <tr>
                  <td class="ps-3 py-2 fw-bold small text-dark">Balance Due</td>
                  <td class="pe-3 py-2 text-end fw-bold small text-secondary">₹<?= number_format($bal, 2) ?></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        <div class="modal-footer border-top p-3 bg-light d-flex justify-content-between">
          <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print()">
            <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Receipt
          </button>
          <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const invTab = document.getElementById('invoices-tab');
  const recTab = document.getElementById('receipts-tab');

  if (invTab && recTab) {
    invTab.addEventListener('shown.bs.tab', function() {
      invTab.style.backgroundColor = '#ffffff';
      invTab.style.color = '#1e293b';
      invTab.style.border = '1px solid #e2e8f0';
      invTab.classList.add('shadow-sm');

      recTab.style.backgroundColor = 'transparent';
      recTab.style.color = '#64748b';
      recTab.style.border = '0';
      recTab.classList.remove('shadow-sm');
      if (typeof lucide !== 'undefined') { lucide.createIcons(); }
    });

    recTab.addEventListener('shown.bs.tab', function() {
      recTab.style.backgroundColor = '#ffffff';
      recTab.style.color = '#1e293b';
      recTab.style.border = '1px solid #e2e8f0';
      recTab.classList.add('shadow-sm');

      invTab.style.backgroundColor = 'transparent';
      invTab.style.color = '#64748b';
      invTab.style.border = '0';
      invTab.classList.remove('shadow-sm');
      if (typeof lucide !== 'undefined') { lucide.createIcons(); }
    });
  }
  if (typeof lucide !== 'undefined') { lucide.createIcons(); }
});
</script>
