<?php
/**
 * Student Academic Overview - CodeClove School Management Pro UI Match
 */

$className = !empty($student['class_name']) ? $student['class_name'] : 'Class 1';
$sectionName = !empty($student['section_name']) ? $student['section_name'] : 'Section A';
$rollNumber = !empty($student['roll_number']) ? $student['roll_number'] : '1';
$academicYear = !empty($student['academic_year']) ? $student['academic_year'] : '2026-27 (IN)';
$startDate = !empty($student['enrollment_date']) ? date('d/m/Y', strtotime($student['enrollment_date'])) : '16/07/2026';

$subjectsCount = !empty($enrolledSubjects) ? count($enrolledSubjects) : 5;
?>

<!-- Page Header (Matches Screenshot) -->
<div class="mb-4">
  <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em; font-size: 24px; color: #0f172a !important;">Academic Overview</h1>
  <p class="text-secondary mb-0" style="font-size: 13.5px; color: #64748b !important;">Subjects, schedule, and academic year details</p>
</div>

<!-- Top Enrollment Info Card (Matches Screenshot) -->
<div class="card border shadow-sm mb-4" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3 p-md-4 d-flex align-items-center justify-content-between flex-wrap gap-3">
    <div class="d-flex align-items-center gap-3">
      <!-- Graduation Cap Icon Box -->
      <div style="width: 44px; height: 44px; border-radius: 10px; background: #eef2ff; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
        <i data-lucide="graduation-cap" style="width: 22px; height: 22px; color: #6366f1;"></i>
      </div>
      <div>
        <div class="d-flex align-items-center flex-wrap gap-2 mb-1">
          <span class="fw-bold" style="font-size: 15px; color: #0f172a;">
            <?= e($className) ?> • <?= str_starts_with($sectionName, 'Section') ? e($sectionName) : 'Section ' . e($sectionName) ?>
          </span>
          <span class="text-muted">•</span>
          <span class="badge rounded-pill" style="background: #eff6ff; color: #4f46e5; border: 1px solid #dbeafe; font-size: 11.5px; font-weight: 600; padding: 2px 9px;">
            Roll #<?= e($rollNumber) ?>
          </span>
        </div>
        <div style="font-size: 13px; color: #64748b;">
          Academic Year <?= e($academicYear) ?> • Started <?= e($startDate) ?>
        </div>
      </div>
    </div>
    
    <!-- Right Badge: 5 Subjects Enrolled -->
    <div>
      <span class="badge rounded-pill" style="background: #ffffff; border: 1px solid #e2e8f0; color: #4f46e5; font-size: 12.5px; font-weight: 600; padding: 6px 16px;">
        <?= (int)$subjectsCount ?> Subjects Enrolled
      </span>
    </div>
  </div>
</div>

<!-- Enrolled Subjects Container Card (Matches Screenshot) -->
<div class="card border shadow-sm" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3 p-md-4">
    <!-- Header of Enrolled Subjects Section -->
    <div class="d-flex align-items-center justify-content-between mb-4">
      <div class="d-flex align-items-center gap-2">
        <i data-lucide="book-open" style="width: 18px; height: 18px; color: #4f46e5;"></i>
        <span class="fw-bold" style="font-size: 15px; color: #0f172a;">Enrolled Subjects</span>
      </div>
      <span class="badge rounded-pill" style="background: #ffffff; border: 1px solid #e2e8f0; color: #64748b; font-size: 12px; font-weight: 500; padding: 4px 12px;">
        <?= (int)$subjectsCount ?> Subjects
      </span>
    </div>

    <!-- Responsive Subject Cards Grid -->
    <div class="row g-3">
      <?php foreach ($enrolledSubjects as $sub): ?>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="p-3 border rounded-3 d-flex align-items-center justify-content-between h-100 subject-card-hover" style="border-color: #e2e8f0 !important; background: #ffffff; border-radius: 12px; transition: all 0.2s ease;">
            <div class="d-flex align-items-center gap-3">
              <!-- Book Icon Box -->
              <div style="width: 38px; height: 38px; border-radius: 8px; background: #eff6ff; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <i data-lucide="book" style="width: 18px; height: 18px; color: #4f46e5;"></i>
              </div>
              <div>
                <div class="fw-bold" style="font-size: 14px; color: #0f172a; margin-bottom: 2px;">
                  <?= e($sub['name']) ?>
                </div>
                <div style="font-size: 12px; color: #64748b;">
                  Code: <?= e($sub['code']) ?>
                </div>
              </div>
            </div>
            
            <!-- Core / Elective Badge -->
            <div>
              <span class="badge rounded-pill" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; font-size: 11px; font-weight: 500; padding: 3px 12px;">
                <?= e($sub['type'] ?? 'Core') ?>
              </span>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<style>
.subject-card-hover:hover {
  border-color: #cbd5e1 !important;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
}
</style>
