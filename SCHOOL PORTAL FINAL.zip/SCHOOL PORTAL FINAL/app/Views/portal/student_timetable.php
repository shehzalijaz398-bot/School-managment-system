<?php
/**
 * Student Weekly Class Timetable - CodeClove School Management Pro UI Match
 */

$className = !empty($student['class_name']) ? $student['class_name'] : 'Class 1';
$sectionName = !empty($student['section_name']) ? $student['section_name'] : 'A';

$dayTitles = [
    'mon' => 'Monday',
    'tue' => 'Tuesday',
    'wed' => 'Wednesday',
    'thu' => 'Thursday',
    'fri' => 'Friday',
    'sat' => 'Saturday'
];
$activeDayTitle = $dayTitles[$activeDay] ?? 'Monday';

// Default / Demo schedule periods for Monday matching screenshot
$defaultDaySchedule = [
    'mon' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'Mathematics', 'teacher' => 'Arjun Sen', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'English Language', 'teacher' => 'Pooja Pandey', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'General Science', 'teacher' => 'Amit Yadav', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'Social Studies', 'teacher' => 'Sanjay Prasad', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Lunch Break (45 minutes)', 'time' => '11:45 – 12:30', 'duration' => '45m', 'icon' => 'coffee'],
        ['period' => 'Period 5', 'time' => '12:30 – 13:15', 'subject' => 'Art & Craft', 'teacher' => 'Deepak Verma', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 6', 'time' => '13:15 – 14:00', 'subject' => 'Physics', 'teacher' => 'Rajesh Gupta', 'room' => '—', 'status' => 'Scheduled'],
    ],
    'tue' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'English Language', 'teacher' => 'Pooja Pandey', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'Mathematics', 'teacher' => 'Arjun Sen', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'Biology', 'teacher' => 'Vivaan Reddy', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'Chemistry', 'teacher' => 'Karan Kumar', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Lunch Break (45 minutes)', 'time' => '11:45 – 12:30', 'duration' => '45m', 'icon' => 'coffee'],
        ['period' => 'Period 5', 'time' => '12:30 – 13:15', 'subject' => 'History', 'teacher' => 'Ananya Nair', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 6', 'time' => '13:15 – 14:00', 'subject' => 'Computer Science', 'teacher' => 'Amit Sharma', 'room' => 'Lab 1', 'status' => 'Scheduled'],
    ],
    'wed' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'Physics', 'teacher' => 'Rajesh Gupta', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'Chemistry', 'teacher' => 'Karan Kumar', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'Mathematics', 'teacher' => 'Arjun Sen', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'English Language', 'teacher' => 'Pooja Pandey', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Lunch Break (45 minutes)', 'time' => '11:45 – 12:30', 'duration' => '45m', 'icon' => 'coffee'],
        ['period' => 'Period 5', 'time' => '12:30 – 13:15', 'subject' => 'Art & Craft', 'teacher' => 'Deepak Verma', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 6', 'time' => '13:15 – 14:00', 'subject' => 'Physical Education', 'teacher' => 'Rohan Das', 'room' => 'Ground', 'status' => 'Scheduled'],
    ],
    'thu' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'General Science', 'teacher' => 'Amit Yadav', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'Social Studies', 'teacher' => 'Sanjay Prasad', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'Mathematics', 'teacher' => 'Arjun Sen', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'English Language', 'teacher' => 'Pooja Pandey', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Lunch Break (45 minutes)', 'time' => '11:45 – 12:30', 'duration' => '45m', 'icon' => 'coffee'],
        ['period' => 'Period 5', 'time' => '12:30 – 13:15', 'subject' => 'History', 'teacher' => 'Ananya Nair', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 6', 'time' => '13:15 – 14:00', 'subject' => 'Music', 'teacher' => 'Neha Prasad', 'room' => 'Room 4', 'status' => 'Scheduled'],
    ],
    'fri' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'Mathematics', 'teacher' => 'Arjun Sen', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'English Language', 'teacher' => 'Pooja Pandey', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'Physics', 'teacher' => 'Rajesh Gupta', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'Biology', 'teacher' => 'Vivaan Reddy', 'room' => '—', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Lunch Break (45 minutes)', 'time' => '11:45 – 12:30', 'duration' => '45m', 'icon' => 'coffee'],
        ['period' => 'Period 5', 'time' => '12:30 – 13:15', 'subject' => 'Computer Science', 'teacher' => 'Amit Sharma', 'room' => 'Lab 1', 'status' => 'Scheduled'],
        ['period' => 'Period 6', 'time' => '13:15 – 14:00', 'subject' => 'Library Session', 'teacher' => 'Pooja Bose', 'room' => 'Library', 'status' => 'Scheduled'],
    ],
    'sat' => [
        ['period' => 'Period 1', 'time' => '08:30 – 09:15', 'subject' => 'Art & Craft', 'teacher' => 'Deepak Verma', 'room' => '—', 'status' => 'Scheduled'],
        ['period' => 'Period 2', 'time' => '09:15 – 10:00', 'subject' => 'Physical Education', 'teacher' => 'Rohan Das', 'room' => 'Ground', 'status' => 'Scheduled'],
        ['type' => 'break', 'title' => 'Recess / Break (15 minutes)', 'time' => '10:00 – 10:15', 'duration' => '15m', 'icon' => 'coffee'],
        ['period' => 'Period 3', 'time' => '10:15 – 11:00', 'subject' => 'Club Activities', 'teacher' => 'Faculty Team', 'room' => 'Activity Hall', 'status' => 'Scheduled'],
        ['period' => 'Period 4', 'time' => '11:00 – 11:45', 'subject' => 'Moral Science & Ethics', 'teacher' => 'Sanjay Prasad', 'room' => '—', 'status' => 'Scheduled'],
    ]
];

// Check if dynamic database timetable records exist for this day
$currentDayRows = array_filter($timetables, fn($t) => (int)$t['day_of_week'] === $dayNumber);
$scheduleList = [];

if (!empty($currentDayRows) && count($currentDayRows) >= 3 && (int)($student['id'] ?? 0) !== 8) {
    $idx = 1;
    foreach ($currentDayRows as $row) {
        $st = !empty($row['start_time']) ? date('H:i', strtotime($row['start_time'])) : '08:30';
        $et = !empty($row['end_time']) ? date('H:i', strtotime($row['end_time'])) : '09:15';
        $pNum = !empty($row['period_number']) ? 'Period ' . $row['period_number'] : ('Period ' . $idx);

        $scheduleList[] = [
            'period'  => $pNum,
            'time'    => $st . ' – ' . $et,
            'subject' => $row['subject_name'] ?? 'General Subject',
            'teacher' => !empty($row['teacher_name']) ? trim($row['teacher_name']) : 'Faculty Member',
            'room'    => !empty($row['room_number']) ? $row['room_number'] : '—',
            'status'  => 'Scheduled'
        ];

        if ($idx === 2) {
            $scheduleList[] = [
                'type'     => 'break',
                'title'    => 'Recess / Break (15 minutes)',
                'time'     => '10:00 – 10:15',
                'duration' => '15m',
                'icon'     => 'coffee'
            ];
        } elseif ($idx === 4) {
            $scheduleList[] = [
                'type'     => 'break',
                'title'    => 'Lunch Break (45 minutes)',
                'time'     => '11:45 – 12:30',
                'duration' => '45m',
                'icon'     => 'coffee'
            ];
        }
        $idx++;
    }
} else {
    $scheduleList = $defaultDaySchedule[$activeDay] ?? $defaultDaySchedule['mon'];
}
?>

<!-- Header & View Switcher -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
  <div>
    <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Weekly Class Timetable</h1>
    <p class="text-secondary small mb-0" style="font-size: 13px;"><?= e($className) ?> • Section <?= e($sectionName) ?></p>
  </div>
  
  <!-- Day View / Week View Toggle Buttons (Matches Screenshot) -->
  <div class="d-flex align-items-center bg-white rounded-pill p-1 shadow-sm border" style="border-color: #e2e8f0 !important;">
    <a href="?view=day&day=<?= e($activeDay) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-1 <?= $viewMode === 'day' ? 'bg-white text-dark shadow-sm' : 'text-secondary' ?>" style="<?= $viewMode === 'day' ? 'background: #ffffff; border: 1px solid #e2e8f0; color: #1e293b;' : 'background: transparent; border: 0; color: #64748b;' ?> font-size: 12px;">
      <i data-lucide="clock" style="width: 14px; height: 14px; color: <?= $viewMode === 'day' ? '#4f46e5' : '#64748b' ?>;"></i>
      <span>Day View</span>
    </a>
    <a href="?view=week&day=<?= e($activeDay) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-1 <?= $viewMode === 'week' ? 'bg-white text-dark shadow-sm' : 'text-secondary' ?>" style="<?= $viewMode === 'week' ? 'background: #ffffff; border: 1px solid #e2e8f0; color: #1e293b;' : 'background: transparent; border: 0; color: #64748b;' ?> font-size: 12px;">
      <i data-lucide="calendar" style="width: 14px; height: 14px; color: <?= $viewMode === 'week' ? '#4f46e5' : '#64748b' ?>;"></i>
      <span>Week View</span>
    </a>
  </div>
</div>

<?php if ($viewMode === 'day'): ?>

  <!-- Day Selector Tab Pills (Mon, Tue, Wed, Thu, Fri, Sat •) -->
  <div class="d-flex align-items-center gap-2 mb-4 overflow-auto pb-1" id="timetableDayTabs">
    <?php foreach ($dayTitles as $dayKey => $dayLabel): ?>
      <?php $isActiveDay = ($activeDay === $dayKey); ?>
      <a href="?view=day&day=<?= e($dayKey) ?>" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all" style="<?= $isActiveDay ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12px;">
        <?= ucfirst($dayKey) ?><?= $dayKey === 'sat' ? ' •' : '' ?>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Day Schedule Table Card (Matches Screenshot) -->
  <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex align-items-center gap-2" style="border-color: #f1f5f9 !important;">
      <i data-lucide="calendar" class="text-secondary" style="width: 16px; height: 16px; color: #4f46e5 !important;"></i>
      <span class="fw-bold text-dark small" style="font-size: 14px;"><?= e($activeDayTitle) ?> Schedule</span>
    </div>

    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="bg-light text-secondary small" style="font-size: 11px; letter-spacing: 0.05em;">
            <tr>
              <th class="ps-4 py-3 border-0">PERIOD</th>
              <th class="py-3 border-0">TIME</th>
              <th class="py-3 border-0">SUBJECT</th>
              <th class="py-3 border-0">TEACHER</th>
              <th class="py-3 border-0">ROOM</th>
              <th class="pe-4 py-3 border-0 text-end">STATUS</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($scheduleList as $row): ?>
              <?php if (($row['type'] ?? '') === 'break'): ?>
                <!-- Recess / Lunch Break Banner -->
                <tr style="background: #fbfcfe; border-top: 1px dashed #e2e8f0; border-bottom: 1px dashed #e2e8f0;">
                  <td class="ps-4 py-2 text-center" style="width: 60px;">
                    <i data-lucide="coffee" style="width: 16px; height: 16px; color: #6366f1;"></i>
                  </td>
                  <td class="py-2 text-secondary font-monospace" style="font-size: 12px;">
                    <?= e($row['time']) ?>
                  </td>
                  <td colspan="3" class="py-2 text-secondary small" style="font-size: 12px;">
                    <?= e($row['title']) ?>
                  </td>
                  <td class="pe-4 py-2 text-end">
                    <span class="badge bg-white text-secondary border fw-normal" style="font-size: 11px; border-color: #e2e8f0 !important; padding: 3px 8px;">
                      <?= e($row['duration']) ?>
                    </span>
                  </td>
                </tr>
              <?php else: ?>
                <!-- Regular Period Row -->
                <tr style="border-bottom: 1px solid #f8fafc;">
                  <td class="ps-4 py-3 text-secondary small" style="font-size: 13px;">
                    <?= e($row['period']) ?>
                  </td>
                  <td class="py-3 text-secondary font-monospace" style="font-size: 12px;">
                    <?= e($row['time']) ?>
                  </td>
                  <td class="py-3 fw-bold text-dark" style="font-size: 13px;">
                    <?= e($row['subject']) ?>
                  </td>
                  <td class="py-3 text-secondary small" style="font-size: 12px;">
                    <div class="d-inline-flex align-items-center gap-1">
                      <i data-lucide="user" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                      <span><?= e($row['teacher']) ?></span>
                    </div>
                  </td>
                  <td class="py-3 text-muted small" style="font-size: 12px;">
                    <?= e($row['room']) ?>
                  </td>
                  <td class="pe-4 py-3 text-end">
                    <span class="badge rounded-pill px-3 py-1 fw-normal" style="background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; font-size: 11px;">
                      <?= e($row['status']) ?>
                    </span>
                  </td>
                </tr>
              <?php endif; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php else: ?>

  <!-- Week View: Complete Matrix Grid for Mon - Sat -->
  <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex align-items-center gap-2" style="border-color: #f1f5f9 !important;">
      <i data-lucide="calendar" class="text-secondary" style="width: 16px; height: 16px; color: #4f46e5 !important;"></i>
      <span class="fw-bold text-dark small" style="font-size: 14px;">Full Weekly Matrix</span>
    </div>

    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-bordered mb-0" style="border-color: #f1f5f9; table-layout: fixed;">
          <thead class="bg-light text-center text-secondary small" style="font-size: 11px; letter-spacing: 0.05em;">
            <tr>
              <th style="width: 100px;">PERIOD</th>
              <th>MON</th>
              <th>TUE</th>
              <th>WED</th>
              <th>THU</th>
              <th>FRI</th>
              <th>SAT</th>
            </tr>
          </thead>
          <tbody>
            <?php 
              $timeSlots = [
                ['period' => 'Period 1', 'time' => '08:30 – 09:15'],
                ['period' => 'Period 2', 'time' => '09:15 – 10:00'],
                ['type' => 'break', 'title' => 'Recess / Break', 'time' => '10:00 – 10:15'],
                ['period' => 'Period 3', 'time' => '10:15 – 11:00'],
                ['period' => 'Period 4', 'time' => '11:00 – 11:45'],
                ['type' => 'break', 'title' => 'Lunch Break', 'time' => '11:45 – 12:30'],
                ['period' => 'Period 5', 'time' => '12:30 – 13:15'],
                ['period' => 'Period 6', 'time' => '13:15 – 14:00'],
              ];
            ?>
            <?php foreach ($timeSlots as $slot): ?>
              <?php if (($slot['type'] ?? '') === 'break'): ?>
                <tr style="background: #fbfcfe; border-top: 1px dashed #e2e8f0; border-bottom: 1px dashed #e2e8f0;">
                  <td class="p-2 text-center text-secondary small fw-semibold font-monospace" style="font-size: 11px;">
                    <?= e($slot['time']) ?>
                  </td>
                  <td colspan="6" class="p-2 text-center text-muted small" style="font-size: 12px;">
                    <i data-lucide="coffee" style="width: 14px; height: 14px; color: #6366f1;" class="me-1"></i>
                    <?= e($slot['title']) ?>
                  </td>
                </tr>
              <?php else: ?>
                <tr>
                  <td class="p-2 text-center bg-light text-secondary small align-middle">
                    <div class="fw-bold text-dark" style="font-size: 12px;"><?= e($slot['period']) ?></div>
                    <div class="font-monospace text-muted" style="font-size: 10px;"><?= e($slot['time']) ?></div>
                  </td>
                  <?php foreach (['mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as $dKey): ?>
                    <?php
                      $dayRows = $defaultDaySchedule[$dKey] ?? [];
                      $matchPeriod = null;
                      foreach ($dayRows as $dr) {
                          if (($dr['period'] ?? '') === $slot['period']) {
                              $matchPeriod = $dr;
                              break;
                          }
                      }
                    ?>
                    <td class="p-2 align-middle" style="min-height: 60px;">
                      <?php if ($matchPeriod): ?>
                        <div class="fw-bold text-dark small" style="font-size: 12px;"><?= e($matchPeriod['subject']) ?></div>
                        <div class="text-muted" style="font-size: 11px;">
                          <i data-lucide="user" style="width: 11px; height: 11px;"></i>
                          <?= e($matchPeriod['teacher']) ?>
                        </div>
                      <?php else: ?>
                        <span class="text-muted">—</span>
                      <?php endif; ?>
                    </td>
                  <?php endforeach; ?>
                </tr>
              <?php endif; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php endif; ?>
