<?php
/**
 * Student Notifications & Alerts - CodeClove School Management Pro UI Match
 */

$filter = $filter ?? 'all';
?>

<!-- Page Header & Action (Matches CodeClove Style) -->
<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
  <div>
    <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em; font-size: 24px; color: #0f172a !important;">Notifications</h1>
    <p class="text-secondary mb-0" style="font-size: 13.5px; color: #64748b !important;">Recent updates, announcements, and alerts</p>
  </div>
  
  <div>
    <button type="button" class="btn btn-sm bg-white border rounded-pill px-3 py-2 fw-semibold d-inline-flex align-items-center gap-2 shadow-sm" id="btnMarkAllRead" onclick="markAllStudentNotificationsRead()" style="border-color: #e2e8f0 !important; color: #4f46e5; font-size: 13px;">
      <i data-lucide="check-check" style="width: 16px; height: 16px; color: #4f46e5;"></i>
      <span>Mark all as read</span>
    </button>
  </div>
</div>

<!-- Filter Tabs Navigation Pills (Matches CodeClove Style) -->
<div class="d-flex align-items-center gap-2 mb-4 overflow-auto pb-1" id="notifFilterTabs">
  <a href="?filter=all" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all" style="<?= $filter === 'all' ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12.5px;">
    All (<?= (int)$totalCount ?>)
  </a>
  <a href="?filter=unread" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all d-inline-flex align-items-center gap-1" style="<?= $filter === 'unread' ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12.5px;">
    <span>Unread</span>
    <?php if ($unreadCount > 0): ?>
      <span class="badge rounded-circle bg-danger text-white" style="font-size: 10px; width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center;"><?= (int)$unreadCount ?></span>
    <?php endif; ?>
  </a>
  <a href="?filter=academic" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all" style="<?= $filter === 'academic' ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12.5px;">
    Academic
  </a>
  <a href="?filter=finance" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all" style="<?= $filter === 'finance' ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12.5px;">
    Finance
  </a>
  <a href="?filter=announcements" class="text-decoration-none px-3 py-1 rounded-pill fw-semibold small transition-all" style="<?= $filter === 'announcements' ? 'background: #ffffff; border: 1.5px solid #6366f1; color: #4f46e5; box-shadow: 0 1px 3px rgba(99,102,241,0.12);' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b;' ?> font-size: 12.5px;">
    Announcements
  </a>
</div>

<!-- Notification Feed Container Card (Matches CodeClove Style) -->
<div class="card border shadow-sm" style="border-radius: 12px; border-color: #e2e8f0 !important; background: #ffffff;">
  <div class="card-header bg-white border-bottom p-3 d-flex align-items-center justify-content-between" style="border-color: #f1f5f9 !important;">
    <div class="d-flex align-items-center gap-2">
      <i data-lucide="bell" style="width: 18px; height: 18px; color: #4f46e5;"></i>
      <span class="fw-bold text-dark small" style="font-size: 14.5px;">Activity & Notices</span>
    </div>
    <span class="badge rounded-pill" style="background: #ffffff; border: 1px solid #e2e8f0; color: #64748b; font-size: 11.5px; font-weight: 500; padding: 4px 12px;">
      <?= count($notifications) ?> <?= count($notifications) === 1 ? 'Notice' : 'Notices' ?>
    </span>
  </div>

  <div class="card-body p-0">
    <?php if (empty($notifications)): ?>
      <div class="p-5 text-center text-muted">
        <div class="mb-3 d-inline-flex align-items-center justify-content-center" style="width: 56px; height: 56px; border-radius: 50%; background: #f8fafc;">
          <i data-lucide="bell-off" style="width: 24px; height: 24px; color: #94a3b8;"></i>
        </div>
        <h6 class="fw-bold text-dark mb-1">No notifications found</h6>
        <p class="small text-secondary mb-0">You're all caught up with your updates and notices.</p>
      </div>
    <?php else: ?>
      <div class="list-group list-group-flush" id="studentNotifList">
        <?php foreach ($notifications as $n): ?>
          <div class="list-group-item p-3 p-md-4 notif-card-item transition-all <?= empty($n['is_read']) ? 'bg-notif-unread' : 'bg-white' ?>" id="notifItem_<?= $n['id'] ?>" style="border-bottom: 1px solid #f1f5f9 !important;">
            <div class="d-flex align-items-start gap-3">
              <!-- Unread Blue/Purple Indicator Dot -->
              <div class="mt-2" style="width: 8px; flex-shrink: 0;">
                <?php if (empty($n['is_read'])): ?>
                  <span class="d-block rounded-circle notif-unread-dot" style="width: 8px; height: 8px; background: #4f46e5;"></span>
                <?php else: ?>
                  <span class="d-block" style="width: 8px; height: 8px;"></span>
                <?php endif; ?>
              </div>

              <!-- Icon Container -->
              <div style="width: 42px; height: 42px; border-radius: 10px; background: <?= e($n['icon_bg']) ?>; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <i data-lucide="<?= e($n['icon']) ?>" style="width: 20px; height: 20px; color: <?= e($n['icon_col']) ?>;"></i>
              </div>

              <!-- Main Content -->
              <div class="flex-grow-1">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-1">
                  <h6 class="fw-bold text-dark mb-0" style="font-size: 14.5px; color: #0f172a !important;">
                    <?= e($n['title']) ?>
                  </h6>
                  <span class="badge rounded-pill" style="background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; font-size: 11px; font-weight: 500; padding: 2px 10px;">
                    <?= e($n['type']) ?>
                  </span>
                </div>

                <p class="text-secondary small mb-2" style="font-size: 13px; line-height: 1.5; color: #475569 !important;">
                  <?= e($n['message']) ?>
                </p>

                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                  <div class="d-flex align-items-center gap-2" style="font-size: 12px; color: #94a3b8;">
                    <i data-lucide="clock" style="width: 13px; height: 13px;"></i>
                    <span><?= e($n['time']) ?></span>
                  </div>

                  <?php if (!empty($n['action_url'])): ?>
                    <div>
                      <a href="<?= e($n['action_url']) ?>" class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-1 shadow-sm" style="background: #ffffff; border: 1px solid #e2e8f0; color: #4f46e5; font-size: 12px;">
                        <span><?= e($n['action_label'] ?? 'View Details') ?></span>
                        <i data-lucide="arrow-right" style="width: 12px; height: 12px;"></i>
                      </a>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<style>
.bg-notif-unread {
  background-color: #fbfcfe !important;
}
.notif-card-item:hover {
  background-color: #f8fafc !important;
}
</style>

<script>
function markAllStudentNotificationsRead() {
  const btn = document.getElementById('btnMarkAllRead');
  if (btn) {
    btn.innerHTML = '<span class="spinner-border spinner-border-sm text-primary" role="status"></span> Updating...';
    btn.disabled = true;
  }

  fetch('<?= e(url('portal/notifications/mark-all-read')) ?>', {
    method: 'POST',
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Content-Type': 'application/json'
    }
  })
  .then(res => res.json())
  .then(data => {
    // Remove all unread dots and reset styles
    document.querySelectorAll('.notif-unread-dot').forEach(dot => dot.remove());
    document.querySelectorAll('.bg-notif-unread').forEach(card => {
      card.classList.remove('bg-notif-unread');
      card.classList.add('bg-white');
    });
    // Remove red badge from sidebar & header
    document.querySelectorAll('.badge.bg-danger').forEach(b => {
      b.style.display = 'none';
    });
    if (btn) {
      btn.innerHTML = '<i data-lucide="check" style="width: 16px; height: 16px; color: #10b981;"></i> <span>All read</span>';
      btn.style.color = '#10b981';
      if (window.lucide) lucide.createIcons();
    }
  })
  .catch(() => {
    window.location.reload();
  });
}
</script>
