<?php
$title = $title ?? 'Class Learning Resources & Study Materials';
$student = $student ?? [];
$children = $children ?? [];
$role = $role ?? 'student';
$resources = $resources ?? [];
$subjects = $subjects ?? [];
$selectedSubjectId = $selectedSubjectId ?? null;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <h2 class="h4 mb-0 fw-bold text-dark d-flex align-items-center gap-2">
      <i data-lucide="book-marked" class="text-primary" style="width: 24px; height: 24px;"></i>
      <?= e($title) ?>
    </h2>
    <p class="text-muted small mb-0 mt-1">
      Official course materials, syllabus guides, lecture summaries, and reference documents shared by your teachers.
    </p>
  </div>
  <?php if ($role === 'parent' && count($children) > 1): ?>
    <div>
      <form method="GET" action="<?= e(url('portal/resources')) ?>" class="d-flex align-items-center gap-2">
        <label class="small text-muted fw-semibold text-nowrap">Viewing Student:</label>
        <select name="student_id" class="form-select form-select-sm" onchange="this.form.submit()">
          <?php foreach ($children as $ch): ?>
            <option value="<?= e($ch['id']) ?>" <?= ((int)$ch['id'] === (int)($student['id'] ?? 0)) ? 'selected' : '' ?>>
              <?= e($ch['first_name'] . ' ' . $ch['last_name']) ?> (<?= e($ch['class_name'] ?? 'Class') ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  <?php endif; ?>
</div>

<!-- Subject Filter Pills -->
<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="<?= e(url('portal/resources' . ($role === 'parent' ? '?student_id=' . ($student['id'] ?? 0) : ''))) ?>" 
     class="btn btn-sm <?= empty($selectedSubjectId) ? 'btn-primary' : 'btn-light border text-muted' ?> rounded-pill px-3">
    All Subjects (<?= count($resources) ?>)
  </a>
  <?php foreach ($subjects as $s): ?>
    <a href="<?= e(url('portal/resources?subject_id=' . $s['id'] . ($role === 'parent' ? '&student_id=' . ($student['id'] ?? 0) : ''))) ?>" 
       class="btn btn-sm <?= ((int)$s['id'] === $selectedSubjectId) ? 'btn-primary' : 'btn-light border text-muted' ?> rounded-pill px-3">
      <?= e($s['name']) ?>
    </a>
  <?php endforeach; ?>
</div>

<!-- Resources Grid -->
<div class="row g-3">
  <?php if (empty($resources)): ?>
    <div class="col-12">
      <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
        <i data-lucide="folder-open" style="width: 48px; height: 48px; opacity: 0.3;" class="mb-2 mx-auto text-muted"></i>
        <h5 class="fw-bold text-dark">No Learning Materials Found</h5>
        <p class="text-muted small mb-0">Your teachers have not uploaded files for this class or subject yet.</p>
      </div>
    </div>
  <?php else: ?>
    <?php foreach ($resources as $res): ?>
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 h-100 bg-white p-4 d-flex flex-column justify-content-between">
          <div>
            <div class="d-flex justify-content-between align-items-start mb-2">
              <span class="badge bg-primary-subtle text-primary rounded-pill px-2.5 py-1" style="font-size: 11px;">
                <?= e($res['subject_name'] ?? 'General') ?>
              </span>
              <span class="badge bg-light text-muted border font-monospace" style="font-size: 10.5px;">
                <?= round(($res['file_size'] ?? 0) / 1024, 1) ?> KB
              </span>
            </div>
            <h5 class="fw-bold text-dark mb-1" style="font-size: 15px;"><?= e($res['title']) ?></h5>
            <?php if (!empty($res['description'])): ?>
              <p class="text-secondary small mb-3" style="font-size: 12px; line-height: 1.4;">
                <?= e($res['description']) ?>
              </p>
            <?php endif; ?>
          </div>

          <div class="pt-3 border-top border-light d-flex justify-content-between align-items-center">
            <div class="text-muted small" style="font-size: 11px;">
              By <?= e($res['uploader_name'] ?? 'Teacher') ?>
              <div><?= date('M j, Y', strtotime($res['created_at'])) ?></div>
            </div>
            <a href="<?= e(url('resources/' . $res['id'] . '/download')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 shadow-sm">
              <i data-lucide="download" style="width: 14px; height: 14px;"></i> Download
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
