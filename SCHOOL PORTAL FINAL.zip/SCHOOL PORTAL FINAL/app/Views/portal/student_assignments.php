<?php
$layout = 'layouts/app';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Home Tasks &amp; Daily Diary</h1>
        <p class="text-muted small mb-0">Daily classroom homework, assignments, and digital project submissions</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <span class="badge rounded-pill bg-white border px-3 py-2 text-dark shadow-sm d-flex align-items-center gap-2" style="font-size: 13px;">
            <i data-lucide="calendar" style="width: 15px; height: 15px; stroke: #4f46e5;"></i>
            <span><?= e(date('l, d F Y')) ?></span>
        </span>
    </div>
</div>

<?php if ($isParent && !empty($children) && count($children) > 1): ?>
<!-- Child Switcher for Parents -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-3 d-flex align-items-center flex-wrap gap-2">
        <span class="text-muted small fw-semibold me-2 d-flex align-items-center gap-1">
            <i data-lucide="users" style="width: 14px; height: 14px;"></i> Select Child:
        </span>
        <?php foreach ($children as $c): ?>
            <a href="<?= e(url('portal/assignments?student_id=' . $c['id'])) ?>" 
               class="btn btn-sm rounded-pill px-3 py-1 d-flex align-items-center gap-2 <?= ((int)$selectedStudentId === (int)$c['id']) ? 'btn-primary' : 'btn-outline-secondary' ?>"
               style="font-size: 12px; font-weight: 500;">
                <i data-lucide="user" style="width: 13px; height: 13px;"></i>
                <span><?= e(trim($c['first_name'] . ' ' . $c['last_name'])) ?></span>
                <?php if (!empty($c['class_name'])): ?>
                    <span class="badge bg-white bg-opacity-25 ms-1"><?= e($c['class_name']) ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Student Info Pill -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-3 d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
            <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 44px; height: 44px; background: #e0e7ff; color: #4338ca; font-size: 16px;">
                <?= e(strtoupper(substr($student['first_name'] ?? 'S', 0, 1))) ?>
            </div>
            <div>
                <h6 class="mb-0 fw-bold text-dark" style="font-size: 14px;"><?= e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></h6>
                <div class="text-muted small d-flex align-items-center gap-2" style="font-size: 12px;">
                    <span><i data-lucide="book-open" style="width: 12px; height: 12px;" class="me-1"></i> Class: <?= e($student['class_name'] ?? 'N/A') ?><?= !empty($student['section_name']) ? ' (' . e($student['section_name']) . ')' : '' ?></span>
                    <span>•</span>
                    <span>Admission: <?= e($student['admission_no'] ?? 'N/A') ?></span>
                    <?php if (!empty($student['roll_no'])): ?>
                        <span>•</span>
                        <span>Roll No: <?= e($student['roll_no']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge rounded-pill bg-light text-dark border px-3 py-2 small" style="font-size: 12px;">
                <i data-lucide="check-circle" style="width: 13px; height: 13px; stroke: #16a34a;" class="me-1"></i> Academic Year Active
            </span>
        </div>
    </div>
</div>

<!-- 4 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eff6ff; width: 34px; height: 34px;">
                        <i data-lucide="book-marked" style="width: 16px; height: 16px; stroke: #2563eb;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Total Assignments</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <?php if (($stats['pending'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark px-2 py-1" style="font-size: 10px;">To Do</span>
                    <?php endif; ?>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['pending'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Pending Submission</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="send" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['submitted'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Submitted Work</div>
            </div>
        </div>
    </div>

    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fdf2f8; width: 34px; height: 34px;">
                        <i data-lucide="award" style="width: 16px; height: 16px; stroke: #db2777;"></i>
                    </div>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['graded'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Graded &amp; Evaluated</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs & Main Content Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-3" style="border-color: #f1f5f9 !important;">
        <ul class="nav nav-pills gap-2" id="taskTabs">
            <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'diary') ? 'active' : '' ?>" 
                   href="<?= e(url('portal/assignments?tab=diary&student_id=' . $selectedStudentId)) ?>" style="font-size: 13px; font-weight: 500;">
                    <i data-lucide="calendar-days" style="width: 15px; height: 15px;"></i>
                    <span>Daily School Diary</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 d-flex align-items-center gap-2 <?= ($activeTab === 'projects') ? 'active' : '' ?>" 
                   href="<?= e(url('portal/assignments?tab=projects&student_id=' . $selectedStudentId)) ?>" style="font-size: 13px; font-weight: 500;">
                    <i data-lucide="file-check" style="width: 15px; height: 15px;"></i>
                    <span>Graded Assignments &amp; Projects</span>
                    <?php if (($stats['pending'] ?? 0) > 0): ?>
                        <span class="badge rounded-pill bg-danger text-white ms-1" style="font-size: 10px;"><?= (int)$stats['pending'] ?></span>
                    <?php endif; ?>
                </a>
            </li>
        </ul>

        <?php if ($activeTab === 'diary'): ?>
            <!-- Date Filter for Diary -->
            <form method="get" action="<?= e(url('portal/assignments')) ?>" class="d-flex align-items-center gap-2 m-0">
                <input type="hidden" name="tab" value="diary">
                <input type="hidden" name="student_id" value="<?= (int)$selectedStudentId ?>">
                <span class="text-muted small fw-semibold">Diary Date:</span>
                <input type="date" name="date" class="form-control form-control-sm rounded-pill shadow-none" value="<?= e($selectedDate) ?>" onchange="this.form.submit()" style="font-size: 12px; width: 140px;">
            </form>
        <?php endif; ?>
    </div>

    <!-- TAB 1: DAILY DIARY VIEW -->
    <?php if ($activeTab === 'diary'): ?>
        <?php
            // Filter diary tasks for the selected date
            $todayDiary = array_filter($diaryTasks, fn($t) => $t['assigned_date'] === $selectedDate);
        ?>
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                    <i data-lucide="book-open" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    <span>Homework Diary for: <?= e(date('l, d F Y', strtotime($selectedDate))) ?></span>
                </h6>
                <span class="badge bg-light text-secondary border px-3 py-1"><?= count($todayDiary) ?> Subjects Assigned</span>
            </div>

            <?php if (!empty($todayDiary)): ?>
                <div class="row g-3">
                    <?php foreach ($todayDiary as $task): ?>
                        <div class="col-12 col-md-6">
                            <div class="p-3 rounded-3 h-100 border shadow-sm transition-hover" style="background: #ffffff; border-color: #e2e8f0 !important;">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="rounded-circle p-2 d-flex align-items-center justify-content-center" style="background: #e0e7ff; color: #4338ca; width: 32px; height: 32px;">
                                            <i data-lucide="book" style="width: 15px; height: 15px;"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fw-bold text-dark" style="font-size: 14px;"><?= e($task['subject_name']) ?></h6>
                                            <span class="text-muted" style="font-size: 11px;">By <?= e($task['teacher_name'] ?? 'Class Teacher') ?></span>
                                        </div>
                                    </div>
                                    <span class="badge rounded-pill bg-light text-dark border px-2 py-1" style="font-size: 10px;">
                                        Due: <?= e(date('d M', strtotime($task['due_date']))) ?>
                                    </span>
                                </div>
                                <div class="p-3 rounded-3 mt-2" style="background: #f8fafc; border: 1px dashed #cbd5e1; font-size: 13px; color: #334155; line-height: 1.5;">
                                    <?= nl2br(e($task['description'] ?? 'No description entered.')) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                        <i data-lucide="smile" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                    </div>
                    <h6 class="fw-bold text-dark mb-1">No Diary Tasks for this Date</h6>
                    <p class="text-muted small mb-0">No home tasks were recorded for <?= e(date('d M Y', strtotime($selectedDate))) ?>. Choose another date above.</p>
                </div>
            <?php endif; ?>
        </div>

    <!-- TAB 2: GRADED ASSIGNMENTS & PROJECTS -->
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
                    <tr>
                        <th class="px-3 py-3">Assignment &amp; Subject</th>
                        <th class="py-3">Due Date</th>
                        <th class="py-3">Max Marks</th>
                        <th class="py-3">Worksheet / Attachment</th>
                        <th class="py-3">My Submission</th>
                        <th class="py-3">Result &amp; Feedback</th>
                        <th class="text-end px-3 py-3">Action</th>
                    </tr>
                </thead>
                <tbody style="font-size: 13px;">
                    <?php if (!empty($projectAssignments)): ?>
                        <?php foreach ($projectAssignments as $a): ?>
                            <tr>
                                <td class="px-3 py-3">
                                    <div class="fw-bold text-dark" style="font-size: 13px;"><?= e($a['title']) ?></div>
                                    <div class="d-flex align-items-center gap-1 text-muted" style="font-size: 11px;">
                                        <span class="badge rounded-pill bg-light text-dark border px-2 py-0"><?= e($a['subject_name']) ?></span>
                                        <span>•</span>
                                        <span><?= e($a['teacher_name'] ?? 'Teacher') ?></span>
                                    </div>
                                </td>
                                <td class="py-3">
                                    <div class="fw-semibold text-dark" style="font-size: 12px;">
                                        <?= e(date('d M Y', strtotime($a['due_date']))) ?>
                                    </div>
                                    <?php
                                        $today = date('Y-m-d');
                                        if ($a['submission_status'] === 'pending' && $today > $a['due_date']):
                                    ?>
                                        <span class="badge rounded-pill bg-danger text-white px-2 py-0" style="font-size: 9px;">Overdue</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 fw-semibold text-dark">
                                    <?= (float)$a['max_marks'] ?> Marks
                                </td>
                                <td class="py-3">
                                    <?php if (!empty($a['attachment'])): ?>
                                        <a href="<?= e(url($a['attachment'])) ?>" target="_blank" class="btn btn-sm btn-light rounded-pill px-2 py-1 border d-inline-flex align-items-center gap-1" style="font-size: 11px;" title="Download Teacher Attachment">
                                            <i data-lucide="file-down" style="width: 12px; height: 12px; stroke: #2563eb;"></i> Worksheet
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted small">&mdash;</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3">
                                    <?php
                                        $subSt = strtolower($a['submission_status'] ?? 'pending');
                                        $badgeBg = match($subSt) {
                                            'graded' => 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;',
                                            'submitted' => 'background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe;',
                                            'late' => 'background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca;',
                                            default => 'background: #fffbeb; color: #b45309; border: 1px solid #fde68a;',
                                        };
                                        $badgeText = match($subSt) {
                                            'graded' => 'Graded',
                                            'submitted' => 'Submitted',
                                            'late' => 'Submitted Late',
                                            default => 'Pending Submission',
                                        };
                                    ?>
                                    <span class="badge rounded-pill px-2 py-1" style="<?= $badgeBg ?> font-size: 11px; font-weight: 600;">
                                        <?= $badgeText ?>
                                    </span>
                                    <?php if (!empty($a['submitted_at'])): ?>
                                        <div class="text-muted" style="font-size: 10px;"><?= e(date('d M, h:i A', strtotime($a['submitted_at']))) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3" style="max-width: 180px;">
                                    <?php if ($subSt === 'graded'): ?>
                                        <div class="fw-bold text-success" style="font-size: 13px;">
                                            <?= (float)$a['marks'] ?> / <?= (float)$a['max_marks'] ?>
                                            <span class="text-muted fw-normal" style="font-size: 11px;">(<?= round(((float)$a['marks'] / max(1, (float)$a['max_marks'])) * 100) ?>%)</span>
                                        </div>
                                        <?php if (!empty($a['teacher_comment'])): ?>
                                            <div class="text-muted small text-truncate" title="<?= e($a['teacher_comment']) ?>" style="font-size: 11px;">
                                                <i data-lucide="message-square" style="width: 10px; height: 10px;" class="me-1"></i>
                                                <?= e($a['teacher_comment']) ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted small">&mdash;</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end px-3 py-3">
                                    <?php if (!$isParent): ?>
                                        <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1 btn-submit-work"
                                                data-id="<?= (int)$a['id'] ?>"
                                                data-title="<?= e($a['title']) ?>"
                                                data-subject="<?= e($a['subject_name']) ?>"
                                                data-due="<?= e(date('d M Y', strtotime($a['due_date']))) ?>"
                                                data-marks="<?= (float)$a['max_marks'] ?>"
                                                data-status="<?= e($a['submission_status'] ?? 'pending') ?>"
                                                data-submitted-content="<?= e($a['student_content'] ?? '') ?>"
                                                data-submitted-file="<?= !empty($a['student_attachment']) ? e(url($a['student_attachment'])) : '' ?>"
                                                data-teacher-comment="<?= e($a['teacher_comment'] ?? '') ?>"
                                                data-obtained-marks="<?= e((string)($a['marks'] ?? '')) ?>">
                                            <i data-lucide="upload" style="width: 12px; height: 12px;" class="me-1"></i>
                                            <?= ($subSt === 'pending') ? 'Submit Work' : 'Edit / View Work' ?>
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 py-1 btn-submit-work"
                                                data-id="<?= (int)$a['id'] ?>"
                                                data-title="<?= e($a['title']) ?>"
                                                data-subject="<?= e($a['subject_name']) ?>"
                                                data-due="<?= e(date('d M Y', strtotime($a['due_date']))) ?>"
                                                data-marks="<?= (float)$a['max_marks'] ?>"
                                                data-status="<?= e($a['submission_status'] ?? 'pending') ?>"
                                                data-submitted-content="<?= e($a['student_content'] ?? '') ?>"
                                                data-submitted-file="<?= !empty($a['student_attachment']) ? e(url($a['student_attachment'])) : '' ?>"
                                                data-teacher-comment="<?= e($a['teacher_comment'] ?? '') ?>"
                                                data-obtained-marks="<?= e((string)($a['marks'] ?? '')) ?>">
                                            <i data-lucide="eye" style="width: 12px; height: 12px;" class="me-1"></i>
                                            View Work
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="p-4 text-center">
                                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3" style="background: #f1f5f9; width: 64px; height: 64px;">
                                        <i data-lucide="clipboard-check" style="width: 32px; height: 32px; stroke: #94a3b8;"></i>
                                    </div>
                                    <h6 class="fw-bold text-dark mb-1">No Graded Assignments</h6>
                                    <p class="text-muted small mb-0">No project assignments have been published for your class yet.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Modal: Submit / View Student Work -->
<div class="modal fade" id="submitHomeworkModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header px-4 py-3 border-0 text-white" style="background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%);">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-white bg-opacity-25 p-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                        <i data-lucide="upload-cloud" style="width: 16px; height: 16px; stroke: #ffffff;"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold text-white mb-0" style="font-size: 16px;">Homework Submission</h5>
                        <div class="text-white text-opacity-75 small" style="font-size: 11px;" id="modalSubMeta">Assignment</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form method="post" id="submitHomeworkForm" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="student_id" value="<?= (int)$selectedStudentId ?>">

                <div class="modal-body px-4 py-4 bg-light">
                    <!-- Assignment Info Card -->
                    <div class="p-3 rounded-3 bg-white border mb-3 shadow-sm" style="border-color: #e2e8f0 !important;">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold text-dark" id="modalAssignTitle">-</span>
                            <span class="badge rounded-pill bg-primary px-2 py-1" id="modalAssignMarks">- Marks</span>
                        </div>
                        <div class="text-muted small" id="modalAssignSubject">-</div>
                        <div class="text-muted small" id="modalAssignDue">Due: -</div>
                    </div>

                    <!-- Graded Result Box (If already graded) -->
                    <div id="modalGradedBox" class="p-3 rounded-3 mb-3" style="background: #f0fdf4; border: 1px solid #bbf7d0; display: none;">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold text-success" style="font-size: 13px;">Graded by Teacher</span>
                            <span class="badge rounded-pill bg-success text-white px-3 py-1" id="modalObtainedMarks" style="font-size: 13px;">-</span>
                        </div>
                        <p class="text-secondary small mb-0 mt-2" id="modalTeacherFeedback">No comments.</p>
                    </div>

                    <?php if (!$isParent): ?>
                        <div class="mb-3">
                            <label class="form-label text-sm fw-semibold text-dark">Your Answers / Solution Notes</label>
                            <textarea name="content" id="modalStudentContent" rows="4" class="form-control rounded-3 shadow-sm border-0" placeholder="Type your answers, solution, or notes for the teacher here..."></textarea>
                        </div>

                        <div class="mb-2">
                            <label class="form-label text-sm fw-semibold text-dark d-flex justify-content-between align-items-center">
                                <span>Upload Completed Homework File</span>
                                <span class="text-muted small" style="font-size: 11px;">PDF, PNG, JPG, DOCX (Max 10MB)</span>
                            </label>
                            <input type="file" name="attachment" class="form-control rounded-3 shadow-sm border-0" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.zip">
                        </div>

                        <div id="modalExistingFileContainer" class="mt-2" style="display: none;">
                            <span class="text-muted small me-2">Previously Uploaded:</span>
                            <a href="#" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-2 py-0" id="modalExistingFileLink" style="font-size: 11px;">
                                <i data-lucide="file-check" style="width: 11px; height: 11px;"></i> View Attached File
                            </a>
                        </div>
                    <?php else: ?>
                        <!-- Parent Readonly View -->
                        <div class="mb-3">
                            <div class="text-muted small mb-1" style="font-size: 11px;">STUDENT ANSWERS / NOTES</div>
                            <p class="text-dark small p-3 rounded-3 bg-white border mb-0" id="modalParentContent">-</p>
                        </div>
                        <div id="modalParentFileContainer" style="display: none;">
                            <div class="text-muted small mb-1" style="font-size: 11px;">ATTACHED HOMEWORK DOCUMENT</div>
                            <a href="#" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1" id="modalParentFileLink">
                                <i data-lucide="file-text" style="width: 14px; height: 14px;"></i> Download Submitted Homework
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="modal-footer px-4 py-3 bg-white border-top-0 d-flex justify-content-between">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-semibold" data-bs-dismiss="modal">Close</button>
                    <?php if (!$isParent): ?>
                        <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold d-flex align-items-center gap-1 shadow-sm">
                            <i data-lucide="send" style="width: 14px; height: 14px;"></i>
                            <span>Submit Homework</span>
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    const form = document.getElementById('submitHomeworkForm');

    document.querySelectorAll('.btn-submit-work').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const title = this.dataset.title;
            const subject = this.dataset.subject;
            const due = this.dataset.due;
            const marks = this.dataset.marks;
            const status = (this.dataset.status || 'pending').toLowerCase();
            const content = this.dataset.submittedContent || '';
            const file = this.dataset.submittedFile || '';
            const comment = this.dataset.teacherComment || '';
            const obtained = this.dataset.obtainedMarks || '';

            form.action = '<?= e(url('portal/assignments/')) ?>' + id + '/submit';
            document.getElementById('modalSubMeta').textContent = subject + ' • Due: ' + due;
            document.getElementById('modalAssignTitle').textContent = title;
            document.getElementById('modalAssignSubject').textContent = 'Subject: ' + subject;
            document.getElementById('modalAssignDue').textContent = 'Due: ' + due;
            document.getElementById('modalAssignMarks').textContent = marks + ' Marks';

            // Student content inputs
            const contentInput = document.getElementById('modalStudentContent');
            if (contentInput) {
                contentInput.value = content;
            }
            const parentContent = document.getElementById('modalParentContent');
            if (parentContent) {
                parentContent.textContent = content ? content : 'No written text provided.';
            }

            // Existing file
            const fileContainer = document.getElementById('modalExistingFileContainer');
            const fileLink = document.getElementById('modalExistingFileLink');
            if (fileContainer && fileLink) {
                if (file) {
                    fileLink.href = file;
                    fileContainer.style.display = 'block';
                } else {
                    fileContainer.style.display = 'none';
                }
            }

            // Parent file
            const pFileContainer = document.getElementById('modalParentFileContainer');
            const pFileLink = document.getElementById('modalParentFileLink');
            if (pFileContainer && pFileLink) {
                if (file) {
                    pFileLink.href = file;
                    pFileContainer.style.display = 'block';
                } else {
                    pFileContainer.style.display = 'none';
                }
            }

            // Graded feedback box
            const gradedBox = document.getElementById('modalGradedBox');
            if (status === 'graded') {
                document.getElementById('modalObtainedMarks').textContent = obtained + ' / ' + marks + ' Marks';
                document.getElementById('modalTeacherFeedback').textContent = comment ? 'Teacher Remarks: ' + comment : 'No remarks provided.';
                gradedBox.style.display = 'block';
            } else {
                gradedBox.style.display = 'none';
            }

            const modal = new bootstrap.Modal(document.getElementById('submitHomeworkModal'));
            modal.show();
        });
    });
});
</script>
