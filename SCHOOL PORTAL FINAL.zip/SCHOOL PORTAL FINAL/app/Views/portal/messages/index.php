<?php
$title = $title ?? 'Parent-Teacher Messages';
$conversations = $conversations ?? [];
$role = $role ?? 'parent';
$children = $children ?? [];
$teachers = $teachers ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <h2 class="h4 mb-0 fw-bold text-dark d-flex align-items-center gap-2">
      <i data-lucide="messages-square" class="text-primary" style="width: 24px; height: 24px;"></i>
      <?= e($title) ?>
    </h2>
    <p class="text-muted small mb-0 mt-1">
      Direct, confidential communication channel between parents, educators, and school administration.
    </p>
  </div>
  <?php if ($role === 'parent' && !empty($children)): ?>
    <div>
      <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newConversationModal">
        <i data-lucide="plus" style="width: 14px; height: 14px;"></i> New Message
      </button>
    </div>
  <?php endif; ?>
</div>

<!-- Conversations List -->
<div class="card border-0 shadow-sm rounded-4 bg-white">
  <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
    <h5 class="fw-bold text-dark mb-0" style="font-size: 15px;">Conversation Threads</h5>
    <span class="badge bg-light text-muted border"><?= count($conversations) ?> Active Threads</span>
  </div>
  <div class="card-body p-0">
    <?php if (empty($conversations)): ?>
      <div class="text-center py-5 text-muted">
        <i data-lucide="message-square-off" style="width: 42px; height: 42px; opacity: 0.3;" class="mb-2"></i>
        <h5 class="fw-bold text-dark">No Conversations Yet</h5>
        <p class="small mb-3 text-muted">
          <?= ($role === 'parent') ? 'Initiate a message with your child\'s teacher to ask questions or discuss progress.' : 'When parents send messages regarding their students, they will appear here.' ?>
        </p>
        <?php if ($role === 'parent' && !empty($children)): ?>
          <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newConversationModal">
            <i data-lucide="send" style="width: 14px; height: 14px;" class="me-1"></i> Send First Message
          </button>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <div class="list-group list-group-flush">
        <?php foreach ($conversations as $c): ?>
          <a href="<?= e(url('parent/messages/' . $c['id'])) ?>" class="list-group-item list-group-item-action p-4 border-bottom d-flex justify-content-between align-items-center gap-3">
            <div class="d-flex align-items-start gap-3 flex-grow-1">
              <div class="avatar bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 44px; height: 44px;">
                <i data-lucide="user" style="width: 20px; height: 20px;"></i>
              </div>
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <h6 class="fw-bold text-dark mb-0" style="font-size: 14px;"><?= e($c['subject']) ?></h6>
                  <?php if ((int)$c['unread_count'] > 0): ?>
                    <span class="badge bg-danger rounded-pill px-2 py-0.5" style="font-size: 10px;"><?= $c['unread_count'] ?> new</span>
                  <?php endif; ?>
                </div>
                <div class="text-secondary small mb-1" style="font-size: 12px;">
                  <span class="fw-medium text-dark"><?= e($c['student_name']) ?></span>
                  (<?= e($c['class_name'] ?? 'Class') ?> • <?= e($c['section_name'] ?? '') ?>)
                  <span class="text-muted mx-1">•</span>
                  <span>With: <?= e($role === 'parent' ? $c['teacher_name'] : $c['parent_name']) ?></span>
                </div>
                <p class="text-muted small mb-0 text-truncate" style="max-width: 600px; font-size: 12px;">
                  <?= e($c['latest_message'] ?? 'No messages') ?>
                </p>
              </div>
            </div>
            <div class="text-end flex-shrink-0">
              <span class="text-muted small" style="font-size: 11px;">
                <?= date('M j, g:i A', strtotime($c['last_message_at'])) ?>
              </span>
              <div class="mt-1">
                <i data-lucide="chevron-right" class="text-muted" style="width: 16px; height: 16px;"></i>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Modal: New Conversation -->
<?php if ($role === 'parent' && !empty($children)): ?>
<div class="modal fade" id="newConversationModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <div class="modal-header border-0 pb-0 pt-4 px-4">
        <h5 class="modal-title fw-bold text-dark">
          <i data-lucide="mail" class="text-primary me-2" style="width: 18px; height: 18px;"></i>
          New Parent-Teacher Message
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="<?= e(url('parent/messages')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Select Child</label>
            <select name="student_id" class="form-select form-select-sm" required>
              <?php foreach ($children as $ch): ?>
                <option value="<?= e($ch['id']) ?>">
                  <?= e($ch['first_name'] . ' ' . $ch['last_name']) ?> (<?= e($ch['class_name'] ?? 'Class') ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Recipient Teacher</label>
            <select name="teacher_id" class="form-select form-select-sm" required>
              <option value="">-- Choose Educator --</option>
              <?php foreach ($teachers as $t): ?>
                <option value="<?= e($t['id']) ?>">
                  <?= e($t['name']) ?> (<?= e($t['designation'] ?? 'Teacher') ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Subject / Topic</label>
            <input type="text" name="subject" class="form-control form-control-sm" placeholder="e.g. Inquiry regarding science project / attendance" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Message</label>
            <textarea name="message" class="form-control form-control-sm" rows="4" placeholder="Write your message here..." required></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Attachment (Optional: PDF, DOC, Image)</label>
            <input type="file" name="attachment" class="form-control form-control-sm">
          </div>
        </div>
        <div class="modal-footer border-0 pt-0 px-4 pb-4">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
            <i data-lucide="send" style="width: 14px; height: 14px;"></i> Send Message
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
