<?php
$thread = $thread ?? [];
$conv = $thread['conversation'] ?? [];
$messages = $thread['messages'] ?? [];
$isParent = $thread['is_parent'] ?? false;
$isTeacher = $thread['is_teacher'] ?? false;
$isAdmin = $thread['is_admin'] ?? false;
$title = $title ?? 'Conversation Thread';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <a href="<?= e(url('parent/messages')) ?>" class="btn btn-outline-secondary btn-sm p-1 rounded-circle" style="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
        <i data-lucide="arrow-left" style="width: 16px; height: 16px;"></i>
      </a>
      <h2 class="h4 mb-0 fw-bold text-dark">
        <?= e($conv['subject'] ?? 'Conversation') ?>
      </h2>
    </div>
    <div class="text-muted small mt-1 ps-4 ms-2">
      Student: <span class="fw-semibold text-dark"><?= e($conv['student_name'] ?? 'Student') ?></span>
      (<?= e($conv['class_name'] ?? '') ?> • <?= e($conv['section_name'] ?? '') ?>)
      <span class="mx-2">•</span>
      Parent: <span class="text-dark"><?= e($conv['parent_name'] ?? 'Parent') ?></span>
      <span class="mx-2">•</span>
      Teacher: <span class="text-dark"><?= e($conv['teacher_name'] ?? 'Teacher') ?></span>
    </div>
  </div>
</div>

<!-- Thread Message History -->
<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
  <div class="card-body p-4" style="max-height: 550px; overflow-y: auto;">
    <div class="d-flex flex-column gap-3">
      <?php foreach ($messages as $m): 
        $isMe = ((int) $m['sender_id'] === (int) \Core\Auth::id());
      ?>
        <div class="d-flex flex-column <?= $isMe ? 'align-items-end' : 'align-items-start' ?>">
          <div class="d-flex align-items-center gap-2 mb-1">
            <span class="small fw-semibold <?= $isMe ? 'text-primary' : 'text-dark' ?>" style="font-size: 12px;">
              <?= e($m['sender_name'] ?? 'User') ?> (<?= ucfirst(e($m['sender_role'])) ?>)
            </span>
            <span class="text-muted small" style="font-size: 11px;">
              <?= date('M j, g:i A', strtotime($m['created_at'])) ?>
            </span>
          </div>

          <div class="p-3 rounded-4 shadow-sm" style="max-width: 75%; <?= $isMe ? 'background: #eff6ff; border: 1px solid #bfdbfe; color: #1e3a8a;' : 'background: #f8fafc; border: 1px solid #e2e8f0; color: #1e293b;' ?>">
            <p class="mb-0 text-break" style="white-space: pre-wrap; font-size: 13.5px; line-height: 1.5;"><?= e($m['message']) ?></p>
            
            <?php if (!empty($m['attachment'])): ?>
              <div class="mt-2 pt-2 border-top border-light-subtle">
                <a href="<?= e(asset($m['attachment'])) ?>" target="_blank" class="small fw-medium text-decoration-none d-inline-flex align-items-center gap-1">
                  <i data-lucide="paperclip" style="width: 14px; height: 14px;"></i> View Attached Document
                </a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Reply Input Bar -->
  <div class="card-footer bg-white border-0 pt-0 p-4">
    <form method="POST" action="<?= e(url('parent/messages/' . $conv['id'] . '/reply')) ?>" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <div class="mb-2">
        <textarea name="message" class="form-control rounded-3" rows="3" placeholder="Type your reply here..." required></textarea>
      </div>
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <label class="btn btn-sm btn-light border text-muted d-inline-flex align-items-center gap-1 cursor-pointer">
            <i data-lucide="paperclip" style="width: 14px; height: 14px;"></i> Attach File
            <input type="file" name="attachment" style="display: none;" onchange="this.parentElement.classList.add('btn-primary-subtle');">
          </label>
        </div>
        <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm px-3 py-2">
          <i data-lucide="send" style="width: 14px; height: 14px;"></i> Send Reply
        </button>
      </div>
    </form>
  </div>
</div>
