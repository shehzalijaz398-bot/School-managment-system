<?php
$title = 'Activity Center';
$layout = 'layouts/app';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-wave-square text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Audit logs and system-wide activity tracking.</p>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-3">
        <form class="d-flex align-items-center gap-2 m-0" method="get">
            <div class="input-group shadow-sm rounded-pill overflow-hidden" style="max-width: 300px;">
                <span class="input-group-text bg-light border-0"><i class="fas fa-filter text-muted"></i></span>
                <select name="module" class="form-select border-0 bg-light shadow-none fw-semibold text-secondary" onchange="this.form.submit()">
                    <option value="">All Modules</option>
                    <?php foreach (['auth','students','attendance','finance','hr','exams','admissions','leave'] as $m): ?>
                        <option value="<?= $m ?>" <?= ($module ?? '') === $m ? 'selected' : '' ?>><?= ucfirst($m) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if (!empty($module)): ?>
            <a href="<?= e(url('audit')) ?>" class="btn btn-light rounded-pill px-3 shadow-sm action-hover text-danger fw-bold" title="Clear Filter">
                <i class="fas fa-times"></i>
            </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3" style="width: 20%;">Date & Time</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">User</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Module</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Action</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="5" class="text-center py-5 text-muted">
                        <i class="fas fa-history fa-3x mb-3 text-light"></i>
                        <h5 class="fw-bold text-gray-500">No Activity Found</h5>
                        <p class="mb-0 text-sm">There are no audit logs matching your criteria.</p>
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($logs as $l): ?>
                    <tr class="log-row">
                        <td class="px-4 py-3">
                            <span class="text-sm fw-bold text-secondary"><i class="far fa-clock me-1"></i> <?= e(formatDate($l['created_at'], 'd M Y')) ?></span>
                            <div class="text-xs text-muted"><?= e(formatDate($l['created_at'], 'H:i A')) ?></div>
                        </td>
                        <td class="py-3">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm bg-light text-primary rounded-circle me-2 d-flex align-items-center justify-content-center shadow-sm" style="width: 32px; height: 32px;">
                                    <i class="fas fa-user text-xs"></i>
                                </div>
                                <span class="fw-bold text-gray-800 text-sm"><?= e($l['user_name'] ?? 'System') ?></span>
                            </div>
                        </td>
                        <td class="py-3">
                            <span class="badge bg-secondary-subtle text-secondary border border-secondary border-opacity-25 rounded-pill px-3">
                                <?= e(ucfirst($l['module'])) ?>
                            </span>
                        </td>
                        <td class="py-3 text-sm text-gray-700">
                            <?= e($l['action']) ?>
                        </td>
                        <td class="px-4 py-3 text-sm font-monospace text-muted">
                            <i class="fas fa-network-wired me-1"></i> <?= e($l['ip_address']) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .log-row {
        transition: all 0.2s ease;
    }
    .log-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 10px -4px rgba(0,0,0,0.05);
        position: relative;
        z-index: 10;
    }
    
    .bg-secondary-subtle { background-color: #f8f9fa !important; }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1) !important;
    }
</style>
