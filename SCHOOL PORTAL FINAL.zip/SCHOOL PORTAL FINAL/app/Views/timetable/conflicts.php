<div class="container-fluid px-3 px-md-4 py-4">
  <!-- Header -->
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
      <div class="d-flex align-items-center gap-2">
        <h1 class="h3 fw-bold text-dark mb-0">Timetable Conflict & Collision Scanner</h1>
        <?php if ($report['is_conflict_free']): ?>
          <span class="badge bg-success rounded-pill px-3 py-1 fs-xs">✓ Conflict-Free</span>
        <?php else: ?>
          <span class="badge bg-danger rounded-pill px-3 py-1 fs-xs">⚠ <?= $report['conflict_count'] ?> Conflict(s) Detected</span>
        <?php endif; ?>
      </div>
      <p class="text-muted small mb-0 mt-1">Automated validation engine detecting teacher double-bookings, class period overlaps, and room allocation collisions.</p>
    </div>

    <div class="d-flex align-items-center gap-2">
      <a href="<?= e(url('timetable')) ?>" class="btn btn-sm btn-light border d-inline-flex align-items-center gap-2 px-3 py-2 rounded-3 shadow-xs">
        <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
        <span>Back to Timetable</span>
      </a>
      <a href="<?= e(url('timetable/conflicts')) ?>" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 rounded-3 shadow-sm">
        <i data-lucide="refresh-cw" style="width: 15px; height: 15px;"></i>
        <span>Re-scan Matrix</span>
      </a>
    </div>
  </div>

  <!-- Summary Metric Tiles -->
  <div class="row g-3 mb-4">
    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="text-muted fs-xs fw-semibold text-uppercase">Total Scheduled Slots</span>
          <div class="rounded-circle p-2 bg-primary bg-opacity-10 text-primary">
            <i data-lucide="calendar" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <h3 class="fw-bold text-dark mb-0"><?= (int) $report['total_entries'] ?></h3>
        <span class="text-muted fs-xs">Active academic session slots</span>
      </div>
    </div>

    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="text-muted fs-xs fw-semibold text-uppercase">Collisions Detected</span>
          <div class="rounded-circle p-2 <?= $report['is_conflict_free'] ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' ?>">
            <i data-lucide="<?= $report['is_conflict_free'] ? 'shield-check' : 'alert-triangle' ?>" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <h3 class="fw-bold <?= $report['is_conflict_free'] ? 'text-success' : 'text-danger' ?> mb-0"><?= (int) $report['conflict_count'] ?></h3>
        <span class="text-muted fs-xs"><?= $report['is_conflict_free'] ? 'Zero scheduling collisions' : 'Requires administrative resolution' ?></span>
      </div>
    </div>

    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="text-muted fs-xs fw-semibold text-uppercase">Teacher Availability</span>
          <div class="rounded-circle p-2 bg-info bg-opacity-10 text-info">
            <i data-lucide="user-check" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <h3 class="fw-bold text-dark mb-0">100%</h3>
        <span class="text-muted fs-xs">Automated check enabled</span>
      </div>
    </div>

    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="text-muted fs-xs fw-semibold text-uppercase">Room Allocation</span>
          <div class="rounded-circle p-2 bg-warning bg-opacity-10 text-warning">
            <i data-lucide="door-open" style="width: 18px; height: 18px;"></i>
          </div>
        </div>
        <h3 class="fw-bold text-dark mb-0">Verified</h3>
        <span class="text-muted fs-xs">Multi-room collision guard active</span>
      </div>
    </div>
  </div>

  <!-- Detailed Results -->
  <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="card-header bg-white border-bottom border-light px-4 py-3">
      <h5 class="fw-bold text-dark mb-0">Conflict Scan Log</h5>
    </div>
    <div class="card-body p-0">
      <?php if ($report['is_conflict_free']): ?>
        <div class="text-center py-5 px-3">
          <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-success bg-opacity-10 text-success mb-3" style="width: 64px; height: 64px;">
            <i data-lucide="check-circle-2" style="width: 36px; height: 36px;"></i>
          </div>
          <h4 class="fw-bold text-dark mb-1">Excellent! No Conflicts Found</h4>
          <p class="text-muted small mb-0" style="max-width: 480px; margin: 0 auto;">
            The timetable engine scanned all periods, classes, rooms, and teachers. All scheduled slots are fully conflict-free and compliant with institutional constraints.
          </p>
        </div>
      <?php else: ?>
        <div class="list-group list-group-flush">
          <?php foreach ($report['conflicts'] as $c): ?>
            <div class="list-group-item p-3 p-md-4 border-bottom">
              <div class="d-flex align-items-start gap-3">
                <div class="flex-shrink-0 rounded-circle p-2 bg-danger bg-opacity-10 text-danger mt-1">
                  <i data-lucide="alert-octagon" style="width: 22px; height: 22px;"></i>
                </div>
                <div class="flex-grow-1 min-w-0">
                  <div class="d-flex flex-wrap justify-content-between align-items-baseline gap-2 mb-1">
                    <h6 class="mb-0 fw-bold text-danger d-flex align-items-center gap-2">
                      <span><?= e($c['title']) ?></span>
                      <span class="badge bg-danger rounded-pill px-2 py-0 text-xs">Collision</span>
                    </h6>
                    <span class="badge bg-light text-dark border text-xs"><?= e($c['day_name']) ?> · <?= e($c['period_name']) ?></span>
                  </div>
                  <p class="text-secondary small mb-2"><?= e($c['description']) ?></p>
                  <a href="<?= e(url('timetable')) ?>" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 text-xs px-2 py-1 rounded-2">
                    <span>Resolve in Timetable Grid</span>
                    <i data-lucide="arrow-right" style="width: 12px; height: 12px;"></i>
                  </a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
