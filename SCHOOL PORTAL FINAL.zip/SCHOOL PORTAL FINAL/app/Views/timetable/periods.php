<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="mb-0 fw-bold text-dark">Manage Periods</h3>
    <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addPeriodModal">
        <i class="fas fa-plus"></i> Add Period
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary">
                    <tr>
                        <th class="ps-4">Period Order</th>
                        <th>Name</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Type</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($periods)): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No periods defined.</td></tr>
                    <?php else: ?>
                        <?php foreach($periods as $p): ?>
                        <tr>
                            <td class="ps-4"><strong><?= $p['period_number'] ?></strong></td>
                            <td><?= e($p['name']) ?></td>
                            <td><?= substr($p['start_time'], 0, 5) ?></td>
                            <td><?= substr($p['end_time'], 0, 5) ?></td>
                            <td>
                                <?php if($p['type'] === 'Break'): ?>
                                    <span class="badge bg-warning text-dark"><i class="fas fa-coffee"></i> Break</span>
                                <?php elseif($p['type'] === 'Assembly'): ?>
                                    <span class="badge bg-info"><i class="fas fa-users"></i> Assembly</span>
                                <?php elseif($p['type'] === 'Free Period'): ?>
                                    <span class="badge bg-secondary"><i class="fas fa-bed"></i> Free</span>
                                <?php else: ?>
                                    <span class="badge bg-success"><i class="fas fa-book"></i> Lesson</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <button class="btn btn-sm btn-light text-secondary me-1" onclick="editPeriod(<?= htmlspecialchars(json_encode($p)) ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="post" action="<?= e(url('timetable/periods/'.$p['id'].'/delete')) ?>" style="display:inline;" onsubmit="return confirm('Delete this period?');">
                                    <?= csrf_field() ?>
                                    <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Period Modal -->
<div class="modal fade" id="addPeriodModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-4">
      <div class="modal-header bg-white border-bottom-0 pt-4 pb-0 px-4">
        <h5 class="modal-title fw-bold text-dark" id="modalTitle">Add Period</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button>
      </div>
      <form method="post" action="<?= e(url('timetable/periods')) ?>" id="periodForm">
          <?= csrf_field() ?>
          <div class="modal-body p-4">
              <div class="row g-3">
                  <div class="col-md-6">
                      <label class="form-label fw-bold text-secondary small">Period Order</label>
                      <input type="number" name="period_number" id="modalOrder" class="form-control bg-light border-0 shadow-none" required min="1">
                  </div>
                  <div class="col-md-6">
                      <label class="form-label fw-bold text-secondary small">Type</label>
                      <select name="type" id="modalType" class="form-select bg-light border-0 shadow-none" required>
                          <option value="Regular">Lesson</option>
                          <option value="Break">Break</option>
                          <option value="Assembly">Assembly</option>
                          <option value="Free Period">Free Period</option>
                      </select>
                  </div>
                  <div class="col-md-12">
                      <label class="form-label fw-bold text-secondary small">Name (e.g. Period 1, Lunch Break)</label>
                      <input type="text" name="name" id="modalName" class="form-control bg-light border-0 shadow-none" required>
                  </div>
                  <div class="col-md-6">
                      <label class="form-label fw-bold text-secondary small">Start Time</label>
                      <input type="time" name="start_time" id="modalStart" class="form-control bg-light border-0 shadow-none" required>
                  </div>
                  <div class="col-md-6">
                      <label class="form-label fw-bold text-secondary small">End Time</label>
                      <input type="time" name="end_time" id="modalEnd" class="form-control bg-light border-0 shadow-none" required>
                  </div>
              </div>
          </div>
          <div class="modal-footer border-0 px-4 pb-4">
              <button type="button" class="btn btn-light shadow-sm" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Period</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script>
function editPeriod(p) {
    document.getElementById('modalTitle').innerText = 'Edit Period';
    document.getElementById('periodForm').action = '<?= e(url('timetable/periods/')) ?>' + p.id;
    document.getElementById('modalOrder').value = p.period_number;
    document.getElementById('modalType').value = p.type;
    document.getElementById('modalName').value = p.name;
    document.getElementById('modalStart').value = p.start_time;
    document.getElementById('modalEnd').value = p.end_time;
    
    new bootstrap.Modal(document.getElementById('addPeriodModal')).show();
}

document.getElementById('addPeriodModal').addEventListener('hidden.bs.modal', function () {
    document.getElementById('modalTitle').innerText = 'Add Period';
    document.getElementById('periodForm').action = '<?= e(url('timetable/periods')) ?>';
    document.getElementById('periodForm').reset();
});
</script>
