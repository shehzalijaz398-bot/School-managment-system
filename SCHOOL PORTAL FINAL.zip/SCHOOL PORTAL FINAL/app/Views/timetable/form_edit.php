<?php $days = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun']; ?>
<div class="panel">
  <h2>Edit Timetable Entry</h2>
  <form method="post" action="<?= e(url('timetable/'.$timetable['id'])) ?>" class="row g-3">
    <?= csrf_field() ?>
    <div class="col-md-3">
        <label class="form-label">Class</label>
        <select name="class_id" class="form-select" required>
            <?php foreach ($classes as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= (int)$timetable['class_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Section ID</label>
        <input name="section_id" class="form-control" value="<?= e($timetable['section_id']) ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Subject</label>
        <select name="subject_id" class="form-select" required>
            <?php foreach ($subjects as $s): ?>
                <option value="<?= (int)$s['id'] ?>" <?= (int)$timetable['subject_id'] === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Teacher</label>
        <select name="teacher_id" class="form-select" required>
            <?php foreach ($teachers as $t): ?>
                <option value="<?= (int)$t['id'] ?>" <?= (int)$timetable['teacher_id'] === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['first_name'].' '.$t['last_name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">Day</label>
        <select name="day_of_week" class="form-select" required>
            <?php for ($d=1;$d<=6;$d++): ?>
                <option value="<?= $d ?>" <?= (int)$timetable['day_of_week'] === $d ? 'selected' : '' ?>><?= $days[$d] ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">Start Time</label>
        <input type="time" name="start_time" class="form-control" value="<?= e(substr($timetable['start_time'], 0, 5)) ?>" required>
    </div>
    <div class="col-md-2">
        <label class="form-label">End Time</label>
        <input type="time" name="end_time" class="form-control" value="<?= e(substr($timetable['end_time'], 0, 5)) ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Room</label>
        <input name="room" class="form-control" value="<?= e($timetable['room'] ?? '') ?>">
    </div>
    <div class="col-12 mt-3">
        <button class="btn btn-primary">Update Entry</button>
        <a href="<?= e(url('timetable')) ?>" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>
