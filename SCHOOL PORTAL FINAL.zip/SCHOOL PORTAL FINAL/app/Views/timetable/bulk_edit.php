<?php
$days = [1=>'Monday', 2=>'Tuesday', 3=>'Wednesday', 4=>'Thursday', 5=>'Friday', 6=>'Saturday'];

function getCell($map, $day, $periodId) {
    return $map[$day][$periodId] ?? null;
}

$className = '';
$sectionName = '';
foreach ($classes as $c) {
    if ((int)$c['id'] === (int)$classId) {
        $className = $c['name'];
        if (!empty($c['sections'])) {
            foreach ($c['sections'] as $sec) {
                if ((int)$sec['id'] === (int)$sectionId) {
                    $sectionName = $sec['name'];
                    break;
                }
            }
        }
        break;
    }
}

// Map teachers by subject
$subjectTeachers = [];
foreach ($subjects as $s) {
    $subjectTeachers[$s['id']] = [];
    foreach ($teachers as $t) {
        $specs = array_map('trim', explode(',', (string)($t['specialization'] ?? '')));
        if (in_array(trim($s['name']), $specs, true)) {
            $subjectTeachers[$s['id']][] = ['id' => $t['id'], 'name' => $t['first_name'] . ' ' . $t['last_name']];
        }
    }
    // If no specialized teacher found, fallback to all teachers just in case
    if (empty($subjectTeachers[$s['id']])) {
        foreach ($teachers as $t) {
            $subjectTeachers[$s['id']][] = ['id' => $t['id'], 'name' => $t['first_name'] . ' ' . $t['last_name']];
        }
    }
}
?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center p-4">
        <h5 class="mb-0 fw-bold text-primary"><i class="fas fa-users text-primary me-2"></i> <?= e($className) ?> - Section <?= e($sectionName) ?> <span class="badge bg-primary bg-opacity-10 text-primary ms-2 fs-6">Class Timetable</span></h5>
        <a href="<?= e(url("timetable?class_id={$classId}&section_id={$sectionId}")) ?>" class="btn btn-light shadow-sm">
            <i class="fas fa-arrow-left"></i> Back to Grid
        </a>
    </div>
    <div class="card-body p-4">
        <form method="post" action="<?= e(url('timetable/bulk')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="class_id" value="<?= $classId ?>">
            <input type="hidden" name="section_id" value="<?= $sectionId ?>">

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="bg-light">
                        <tr>
                            <th style="width: 130px;" class="text-center text-secondary py-3">Time / Period</th>
                            <?php foreach ($days as $dayName): ?>
                                <th class="text-center text-primary py-3"><strong><?= $dayName ?></strong></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $lessonCount = 1;
                        foreach ($periods as $p): 
                            $isBreak = $p['type'] === 'Break';
                            if ($isBreak) {
                                $displayName = 'Break';
                            } else {
                                $displayName = 'Period ' . $lessonCount;
                                $lessonCount++;
                            }
                        ?>
                            <tr>
                                <td class="text-center bg-light">
                                    <strong style="color: #0f172a;"><?= e($p['name'] && $p['name'] !== 'Break' ? $p['name'] : $displayName) ?></strong><br>
                                    <small class="text-muted"><?= substr($p['start_time'], 0, 5) ?> - <?= substr($p['end_time'], 0, 5) ?></small>
                                </td>
                                <?php if ($isBreak): ?>
                                    <td colspan="6" class="text-center bg-light text-muted py-4 fw-bold rounded">
                                        <i class="fas fa-coffee me-2"></i> BREAK
                                    </td>
                                <?php else: ?>
                                    <?php foreach ($days as $day => $dayName): ?>
                                        <?php 
                                            $cell = getCell($timetableMap, $day, $p['id']); 
                                            $cellSubjectId = $cell ? $cell['subject_id'] : '';
                                            $cellTeacherId = $cell ? $cell['teacher_id'] : '';
                                        ?>
                                        <td class="tt-cell-container" data-day="<?= $day ?>">
                                            <div class="mb-2">
                                                <select name="timetable[<?= $day ?>][<?= $p['id'] ?>][subject_id]" class="form-select form-select-sm shadow-none subject-select" style="font-size: 0.8rem;" onchange="handleSubjectChange(this, <?= $day ?>)">
                                                    <option value="">-- Subject --</option>
                                                    <?php foreach ($subjects as $s): ?>
                                                        <option value="<?= $s['id'] ?>" <?= (string)$cellSubjectId === (string)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div>
                                                <select name="timetable[<?= $day ?>][<?= $p['id'] ?>][teacher_id]" class="form-select form-select-sm shadow-none teacher-select" style="font-size: 0.8rem;">
                                                    <option value="">-- Teacher --</option>
                                                    <?php if ($cellSubjectId): ?>
                                                        <?php foreach ($subjectTeachers[$cellSubjectId] ?? [] as $t): ?>
                                                            <option value="<?= $t['id'] ?>" <?= (string)$cellTeacherId === (string)$t['id'] ? 'selected' : '' ?>><?= e($t['name']) ?></option>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </td>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-end mt-4">
                <button type="submit" class="btn btn-primary px-5 py-2 shadow-sm fw-bold rounded-pill">
                    <i class="fas fa-save me-2"></i> Save Timetable
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const subjectTeachersMap = <?= json_encode($subjectTeachers) ?>;

function handleSubjectChange(selectElem, dayId) {
    const td = selectElem.closest('.tt-cell-container');
    const teacherSelect = td.querySelector('.teacher-select');
    const subjectId = selectElem.value;

    teacherSelect.style.display = 'block';
    teacherSelect.innerHTML = '<option value="">-- Teacher --</option>';
    
    if (subjectId && subjectTeachersMap[subjectId]) {
        const teachers = subjectTeachersMap[subjectId];
        teachers.forEach(t => {
            const opt = document.createElement('option');
            opt.value = t.id;
            opt.textContent = t.name;
            teacherSelect.appendChild(opt);
        });
        
        // Auto-select if only one teacher
        if (teachers.length === 1) {
            teacherSelect.value = teachers[0].id;
        }
    }

    updateDaySubjects(dayId);
}

function updateDaySubjects(dayId) {
    const cells = document.querySelectorAll(`.tt-cell-container[data-day="${dayId}"]`);
    const selects = Array.from(cells).map(c => c.querySelector('.subject-select'));
    
    // Get all currently selected subject IDs (ignore empty)
    const selectedIds = selects.map(s => s.value).filter(v => v !== '');

    // Update each select
    selects.forEach(select => {
        const currentValue = select.value;
        Array.from(select.options).forEach(opt => {
            if (opt.value !== '') {
                // Disable option if it's selected in another period on the SAME day
                if (selectedIds.includes(opt.value) && opt.value !== currentValue) {
                    opt.disabled = true;
                } else {
                    opt.disabled = false;
                }
            }
        });
    });
}

// Run on initial load to set up disabled states correctly
document.addEventListener('DOMContentLoaded', () => {
    const days = [1, 2, 3, 4, 5, 6];
    days.forEach(day => updateDaySubjects(day));
});
</script>
