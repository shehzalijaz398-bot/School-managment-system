<?php
$days = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'];

// Group timetable entries by day_of_week and period_id
$timetableMap = [];
if (!empty($rows)) {
    foreach ($rows as $tt) {
        $timetableMap[$tt['day_of_week']][$tt['period_id']] = $tt;
    }
}

// Subject color mapping helper
function getSubjectBadgeClass(string $subjectName): array {
    $colors = [
        ['bg' => '#eff6ff', 'text' => '#1d4ed8', 'border' => '#bfdbfe'],
        ['bg' => '#f0fdf4', 'text' => '#15803d', 'border' => '#bbf7d0'],
        ['bg' => '#faf5ff', 'text' => '#7e22ce', 'border' => '#e9d5ff'],
        ['bg' => '#fff7ed', 'text' => '#c2410c', 'border' => '#fed7aa'],
        ['bg' => '#ecfeff', 'text' => '#0e7490', 'border' => '#a5f3fc'],
        ['bg' => '#fdf2f8', 'text' => '#be185d', 'border' => '#fbcfe8'],
    ];
    $idx = abs(crc32($subjectName)) % count($colors);
    return $colors[$idx];
}

$printSchool = currentSchool();
?>

<!-- Breadcrumbs & Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Academics</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Timetable</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Timetable & Schedules</h1>
      <p class="text-muted small mb-0">Manage academic period slots, schedule weekly lectures, resolve teacher double booking conflicts, and assign daily substitution covers.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
      <!-- Conflict Scanner Trigger -->
      <a href="<?= e(url('timetable/conflicts')) ?>" class="btn btn-sm btn-outline-danger d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" style="border-radius: 8px; height: 38px;">
        <i data-lucide="alert-triangle" style="width: 15px; height: 15px;"></i>
        <span>Conflict Scanner</span>
      </a>

      <!-- Daily Substitutes Trigger -->
      <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" data-bs-toggle="modal" data-bs-target="#dailySubstitutesModal" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;">
        <i data-lucide="users" style="width: 15px; height: 15px;"></i>
        <span>Daily Substitutes</span>
      </button>

      <!-- Print Timetable Trigger -->
      <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" data-bs-toggle="modal" data-bs-target="#printTimetableModal" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;">
        <i data-lucide="printer" style="width: 15px; height: 15px;"></i>
        <span>Print Timetable</span>
      </button>

      <?php if (hasPermission('timetable.manage') && $viewMode === 'class' && $classId && $sectionId): ?>
        <!-- Bulk Matrix Edit -->
        <a href="<?= e(url("timetable/bulk?class_id={$classId}&section_id={$sectionId}")) ?>" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold shadow-sm" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; height: 38px;">
          <i data-lucide="zap" style="width: 15px; height: 15px;"></i>
          <span>Bulk Matrix</span>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Controls & Filter Card (Segmented View + Dropdowns) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
      
      <!-- Left: Segmented View Pill Switcher -->
      <div class="d-inline-flex align-items-center bg-light border rounded-pill p-1">
        <a href="<?= e(url('timetable?view=class' . ($classId ? "&class_id={$classId}&section_id={$sectionId}" : ''))) ?>" 
           class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2 <?= $viewMode !== 'teacher' ? 'bg-white text-primary shadow-xs' : 'text-muted' ?>" 
           style="<?= $viewMode !== 'teacher' ? 'color: #4f46e5 !important;' : '' ?>">
          <i data-lucide="graduation-cap" style="width: 14px; height: 14px;"></i>
          <span>Class View</span>
        </a>
        <a href="<?= e(url('timetable?view=teacher' . ($teacherId ? "&teacher_id={$teacherId}" : ''))) ?>" 
           class="btn btn-sm rounded-pill px-3 py-1 fw-semibold d-inline-flex align-items-center gap-2 <?= $viewMode === 'teacher' ? 'bg-white text-primary shadow-xs' : 'text-muted' ?>"
           style="<?= $viewMode === 'teacher' ? 'color: #4f46e5 !important;' : '' ?>">
          <i data-lucide="user-check" style="width: 14px; height: 14px;"></i>
          <span>Teacher View</span>
        </a>
      </div>

      <!-- Right: Dropdown Selectors -->
      <form method="get" action="<?= e(url('timetable')) ?>" id="timetableFilterForm" class="d-flex align-items-center flex-wrap gap-2 m-0">
        <input type="hidden" name="view" value="<?= e($viewMode) ?>">

        <!-- Term Selector -->
        <?php if (!empty($terms)): ?>
          <div class="d-flex align-items-center gap-2">
            <label class="form-label small fw-semibold text-secondary mb-0 text-uppercase" style="font-size: 11px; letter-spacing: 0.04em;">TERM:</label>
            <select name="term_id" class="form-select form-select-sm" style="height: 36px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
              <?php foreach ($terms as $t): ?>
                <option value="<?= (int)$t['id'] ?>" <?= (int)$t['id'] === $selectedTermId ? 'selected' : '' ?>>
                  <?= e($t['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        <?php endif; ?>

        <?php if ($viewMode !== 'teacher'): ?>
          <!-- Class Selector -->
          <div class="d-flex align-items-center gap-2">
            <label class="form-label small fw-semibold text-secondary mb-0 text-uppercase" style="font-size: 11px; letter-spacing: 0.04em;">CLASS:</label>
            <select name="class_id" id="ttClassSelect" class="form-select form-select-sm" style="height: 36px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 13px;" onchange="updateSectionDropdownAndSubmit()">
              <?php foreach ($classes as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= (int)$c['id'] === $classId ? 'selected' : '' ?>>
                  <?= e($c['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Section Selector -->
          <div class="d-flex align-items-center gap-2">
            <label class="form-label small fw-semibold text-secondary mb-0 text-uppercase" style="font-size: 11px; letter-spacing: 0.04em;">SECTION:</label>
            <select name="section_id" id="ttSectionSelect" class="form-select form-select-sm" style="height: 36px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
              <?php 
                $activeSections = [];
                foreach ($classes as $c) {
                    if ((int)$c['id'] === $classId) {
                        $activeSections = $c['sections'] ?? [];
                        break;
                    }
                }
              ?>
              <?php if (empty($activeSections)): ?>
                <option value="0">No Sections</option>
              <?php else: ?>
                <?php foreach ($activeSections as $sec): ?>
                  <option value="<?= (int)$sec['id'] ?>" <?= (int)$sec['id'] === $sectionId ? 'selected' : '' ?>>
                    <?= e($sec['name']) ?>
                  </option>
                <?php endforeach; ?>
              <?php endif; ?>
            </select>
          </div>
        <?php else: ?>
          <!-- Teacher Selector -->
          <div class="d-flex align-items-center gap-2">
            <label class="form-label small fw-semibold text-secondary mb-0 text-uppercase" style="font-size: 11px; letter-spacing: 0.04em;">TEACHER:</label>
            <select name="teacher_id" class="form-select form-select-sm" style="height: 36px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
              <?php foreach ($teachers as $t): ?>
                <option value="<?= (int)$t['id'] ?>" <?= (int)$t['id'] === $teacherId ? 'selected' : '' ?>>
                  <?= e($t['first_name'] . ' ' . $t['last_name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        <?php endif; ?>
      </form>

    </div>
  </div>
</div>

<!-- Main Timetable Matrix Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; overflow: hidden; background: #ffffff;">
  <!-- Card Header -->
  <div class="card-header bg-white py-3 px-4 d-flex justify-content-between align-items-center flex-wrap gap-2" style="border-bottom: 1px solid #e2e8f0;">
    <div class="fw-bold text-dark d-flex align-items-center gap-2" style="font-size: 15px;">
      <i data-lucide="calendar" class="text-primary" style="width: 18px; height: 18px;"></i>
      <?php if ($viewMode === 'teacher'): ?>
        <span>Teacher <?= e($selectedTeacherName ?: 'Teacher') ?> Schedule</span>
      <?php else: ?>
        <span>Class <?= e($selectedClassName ?: 'Class') ?> - Section <?= e($selectedSectionName ?: 'A') ?> Timetable</span>
      <?php endif; ?>
    </div>

    <?php if (hasPermission('timetable.manage')): ?>
      <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#configurePeriodsModal" style="border-radius: 6px; font-size: 12.5px;">
        <i data-lucide="clock" style="width: 14px; height: 14px;"></i>
        <span>Configure Periods</span>
      </button>
    <?php endif; ?>
  </div>

  <!-- Card Body -->
  <div class="card-body p-0">
    <?php if (empty($periods)): ?>
      <!-- Empty State matching CodeClove screenshot exactly -->
      <div class="text-center py-5 px-3">
        <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-light mb-3" style="width: 72px; height: 72px; border: 1px dashed #cbd5e1;">
          <i data-lucide="clock" class="text-secondary" style="width: 36px; height: 36px; opacity: 0.6;"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1">No Periods Set Up</h5>
        <p class="text-muted small mb-3">Configure period timings for Class to begin adding scheduling slots.</p>
        <?php if (hasPermission('timetable.manage')): ?>
          <button type="button" class="btn btn-primary btn-sm px-4 fw-semibold" data-bs-toggle="modal" data-bs-target="#configurePeriodsModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
            + Configure Periods
          </button>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <!-- Weekly Timetable Schedule Matrix Grid -->
      <div class="table-responsive">
        <table class="table table-bordered align-middle mb-0" style="border-color: #f1f5f9;">
          <thead style="background-color: #f8fafc;">
            <tr>
              <th scope="col" class="py-3 px-3 text-center text-muted fw-bold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em; width: 110px;">
                DAY / TIME
              </th>
              <?php foreach ($periods as $p): ?>
                <th scope="col" class="py-3 px-2 text-center text-dark fw-bold" style="font-size: 12px; min-width: 140px; <?= strtolower($p['type'] ?? '') === 'break' ? 'background-color: #f8fafc;' : '' ?>">
                  <div class="text-uppercase" style="font-size: 11px; color: <?= strtolower($p['type'] ?? '') === 'break' ? '#d97706' : '#4f46e5' ?>;">
                    <?= !empty($p['name']) ? e($p['name']) : 'Period ' . $p['period_number'] ?>
                  </div>
                  <div class="text-muted fw-normal" style="font-size: 11px; font-variant-numeric: tabular-nums;">
                    <?= date('h:i A', strtotime($p['start_time'])) ?> - <?= date('h:i A', strtotime($p['end_time'])) ?>
                  </div>
                </th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($days as $dayNum => $dayName): ?>
              <tr>
                <!-- Day Label Column -->
                <td class="text-center py-3 px-2 fw-bold text-dark bg-light" style="font-size: 12.5px; border-right: 2px solid #e2e8f0;">
                  <?= e($dayName) ?>
                </td>

                <!-- Period Slot Cells -->
                <?php foreach ($periods as $p): ?>
                  <?php 
                    $isBreak = strtolower($p['type'] ?? '') === 'break';
                    $slot = $timetableMap[$dayNum][$p['id']] ?? null;
                  ?>

                  <?php if ($isBreak): ?>
                    <!-- Break Column -->
                    <td class="text-center py-2 px-1 bg-light text-muted" style="background-color: #f8fafc !important;">
                      <div class="d-inline-flex align-items-center gap-1 text-secondary" style="font-size: 11px; opacity: 0.7;">
                        <span>☕</span> <span>Break</span>
                      </div>
                    </td>
                  <?php elseif (!empty($slot)): ?>
                    <!-- Booked Lecture Slot -->
                    <?php $badgeStyle = getSubjectBadgeClass($slot['subject_name']); ?>
                    <td class="p-2 align-top position-relative" style="background-color: #ffffff;">
                      <div class="p-2 rounded-3 h-100 position-relative slot-box" style="background-color: <?= $badgeStyle['bg'] ?>; border: 1px solid <?= $badgeStyle['border'] ?>; transition: all 0.15s ease;">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                          <strong class="d-block" style="font-size: 12.5px; color: <?= $badgeStyle['text'] ?>;">
                            <?= e($slot['subject_name']) ?>
                          </strong>
                          <?php if (hasPermission('timetable.manage')): ?>
                            <div class="slot-actions d-none gap-1">
                              <button type="button" class="btn btn-xs p-0 text-muted hover-primary" title="Edit Slot" data-bs-toggle="modal" data-bs-target="#editSlotModal-<?= $slot['id'] ?>">
                                <i data-lucide="edit-2" style="width: 12px; height: 12px;"></i>
                              </button>
                              <form method="post" action="<?= e(url("timetable/{$slot['id']}/delete")) ?>" class="m-0 d-inline" onsubmit="return confirm('Delete this scheduled slot?');">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-xs p-0 text-danger" title="Delete Slot">
                                  <i data-lucide="trash" style="width: 12px; height: 12px;"></i>
                                </button>
                              </form>
                            </div>
                          <?php endif; ?>
                        </div>

                        <!-- Teacher / Class subtext -->
                        <div class="small d-flex align-items-center gap-1 text-secondary" style="font-size: 11px;">
                          <i data-lucide="user" style="width: 11px; height: 11px;"></i>
                          <span><?= e($slot['teacher_name'] ?? '') ?></span>
                        </div>

                        <?php if (!empty($slot['room'])): ?>
                          <div class="small text-muted mt-1" style="font-size: 10.5px;">
                            <span class="badge bg-white text-secondary border px-1" style="font-size: 9.5px;">Rm: <?= e($slot['room']) ?></span>
                          </div>
                        <?php endif; ?>
                      </div>
                    </td>
                  <?php else: ?>
                    <!-- Empty Slot -->
                    <td class="p-2 align-middle text-center" style="background-color: #ffffff;">
                      <?php if (hasPermission('timetable.manage') && $viewMode === 'class' && $classId && $sectionId): ?>
                        <button type="button" class="btn btn-sm btn-empty-slot w-100 py-3" onclick="openAddSlotModal(<?= $dayNum ?>, <?= $p['id'] ?>, '<?= e(addslashes($dayName)) ?>', '<?= e(addslashes($p['name'] ?: 'Period ' . $p['period_number'])) ?>')" title="Add Slot">
                          <i data-lucide="plus" style="width: 13px; height: 13px;"></i>
                          <span style="font-size: 11px;">Add</span>
                        </button>
                      <?php else: ?>
                        <span class="text-muted opacity-25" style="font-size: 11px;">—</span>
                      <?php endif; ?>
                    </td>
                  <?php endif; ?>

                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ========================================== -->
<!-- MODALS -->
<!-- ========================================== -->

<!-- 1. Modal: Add Timetable Slot -->
<?php if (hasPermission('timetable.manage')): ?>
<div class="modal fade" id="addSlotModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
        <div>
          <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
            <i data-lucide="plus-circle" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
            Schedule Lecture Slot
          </h5>
          <div class="text-muted small mt-1" id="addSlotModalSubtitle">Assign a subject and teacher to the selected period.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= e(url('timetable')) ?>" id="addSlotForm">
        <?= csrf_field() ?>
        <input type="hidden" name="class_id" value="<?= $classId ?>">
        <input type="hidden" name="section_id" value="<?= $sectionId ?>">

        <div class="modal-body p-4">
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Day of Week <span class="text-danger">*</span></label>
              <select name="day_of_week" id="addSlotDaySelect" class="form-select" required style="border-radius: 8px;">
                <?php foreach ($days as $dn => $dnm): ?>
                  <option value="<?= $dn ?>"><?= e($dnm) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Period Slot <span class="text-danger">*</span></label>
              <select name="period_id" id="addSlotPeriodSelect" class="form-select" required style="border-radius: 8px;">
                <?php foreach ($periods as $p): ?>
                  <?php if (strtolower($p['type'] ?? '') !== 'break'): ?>
                    <option value="<?= (int)$p['id'] ?>">
                      <?= !empty($p['name']) ? e($p['name']) : 'Period ' . $p['period_number'] ?> (<?= date('h:i A', strtotime($p['start_time'])) ?>)
                    </option>
                  <?php endif; ?>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Subject <span class="text-danger">*</span></label>
              <select name="subject_id" class="form-select" required style="border-radius: 8px;">
                <option value="">Select Subject...</option>
                <?php foreach ($subjects as $sub): ?>
                  <option value="<?= (int)$sub['id'] ?>"><?= e($sub['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Teacher <span class="text-danger">*</span></label>
              <select name="teacher_id" class="form-select" required style="border-radius: 8px;">
                <option value="">Select Teacher...</option>
                <?php foreach ($teachers as $t): ?>
                  <option value="<?= (int)$t['id'] ?>"><?= e($t['first_name'] . ' ' . $t['last_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Room / Hall</label>
              <input type="text" name="room" class="form-control" placeholder="e.g. Lab 2 or Room 101" style="border-radius: 8px;">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-secondary">Notes</label>
              <input type="text" name="notes" class="form-control" placeholder="Optional notes" style="border-radius: 8px;">
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light px-4 py-3 border-top">
          <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Save Lecture Slot</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 2. Modals: Edit Slot for each existing slot -->
<?php if (!empty($rows)): ?>
  <?php foreach ($rows as $slot): ?>
    <?php if (hasPermission('timetable.manage')): ?>
    <div class="modal fade" id="editSlotModal-<?= $slot['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
          <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
            <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
              <i data-lucide="edit-3" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
              Edit Lecture Slot — <?= e($slot['subject_name']) ?>
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form method="post" action="<?= e(url("timetable/{$slot['id']}")) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="class_id" value="<?= $slot['class_id'] ?>">
            <input type="hidden" name="section_id" value="<?= $slot['section_id'] ?>">
            <div class="modal-body p-4">
              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Day of Week</label>
                  <select name="day_of_week" class="form-select" required style="border-radius: 8px;">
                    <?php foreach ($days as $dn => $dnm): ?>
                      <option value="<?= $dn ?>" <?= (int)$slot['day_of_week'] === $dn ? 'selected' : '' ?>><?= e($dnm) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Period Slot</label>
                  <select name="period_id" class="form-select" required style="border-radius: 8px;">
                    <?php foreach ($periods as $p): ?>
                      <?php if (strtolower($p['type'] ?? '') !== 'break'): ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (int)$slot['period_id'] === (int)$p['id'] ? 'selected' : '' ?>>
                          <?= !empty($p['name']) ? e($p['name']) : 'Period ' . $p['period_number'] ?>
                        </option>
                      <?php endif; ?>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Subject</label>
                  <select name="subject_id" class="form-select" required style="border-radius: 8px;">
                    <?php foreach ($subjects as $sub): ?>
                      <option value="<?= (int)$sub['id'] ?>" <?= (int)$slot['subject_id'] === (int)$sub['id'] ? 'selected' : '' ?>><?= e($sub['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Teacher</label>
                  <select name="teacher_id" class="form-select" required style="border-radius: 8px;">
                    <?php foreach ($teachers as $t): ?>
                      <option value="<?= (int)$t['id'] ?>" <?= (int)$slot['teacher_id'] === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['first_name'] . ' ' . $t['last_name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Room / Hall</label>
                  <input type="text" name="room" class="form-control" value="<?= e($slot['room'] ?? '') ?>" placeholder="e.g. Lab 2" style="border-radius: 8px;">
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Notes</label>
                  <input type="text" name="notes" class="form-control" value="<?= e($slot['notes'] ?? '') ?>" placeholder="Optional notes" style="border-radius: 8px;">
                </div>
              </div>
            </div>
            <div class="modal-footer bg-light px-4 py-3 border-top">
              <button type="button" class="btn btn-outline-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Cancel</button>
              <button type="submit" class="btn btn-primary btn-sm px-4 fw-semibold" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
  <?php endforeach; ?>
<?php endif; ?>

<!-- 3. Modal: Configure Periods -->
<?php if (hasPermission('timetable.manage')): ?>
<div class="modal fade" id="configurePeriodsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
        <div>
          <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
            <i data-lucide="clock" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
            Configure Period Timings
          </h5>
          <div class="text-muted small mt-1">Manage bell schedule, lecture slot lengths, and break periods.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <!-- Existing Periods Table -->
        <div class="table-responsive border rounded-3 mb-4 overflow-hidden">
          <table class="table align-middle mb-0 table-sm" style="font-size: 13px;">
            <thead class="bg-light fw-bold text-muted">
              <tr>
                <th class="py-2 px-3">PERIOD #</th>
                <th class="py-2 px-3">LABEL</th>
                <th class="py-2 px-3">START TIME</th>
                <th class="py-2 px-3">END TIME</th>
                <th class="py-2 px-3">TYPE</th>
                <th class="py-2 px-3 text-end">ACTION</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($periods)): ?>
                <tr><td colspan="6" class="text-center py-4 text-muted">No periods defined. Add one below.</td></tr>
              <?php else: ?>
                <?php foreach ($periods as $p): ?>
                  <tr>
                    <td class="py-2 px-3 fw-bold"><?= $p['period_number'] ?></td>
                    <td class="py-2 px-3 text-dark"><?= e($p['name'] ?: 'Period ' . $p['period_number']) ?></td>
                    <td class="py-2 px-3 text-muted"><?= date('h:i A', strtotime($p['start_time'])) ?></td>
                    <td class="py-2 px-3 text-muted"><?= date('h:i A', strtotime($p['end_time'])) ?></td>
                    <td class="py-2 px-3">
                      <span class="badge <?= strtolower($p['type'] ?? '') === 'break' ? 'bg-warning text-dark' : 'bg-light text-primary border' ?>" style="font-size: 11px;">
                        <?= e($p['type'] ?? 'Regular') ?>
                      </span>
                    </td>
                    <td class="py-2 px-3 text-end">
                      <form method="post" action="<?= e(url("timetable/periods/{$p['id']}/delete")) ?>" class="m-0 d-inline" onsubmit="return confirm('Delete this period?');">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-xs text-danger p-1 border-0 bg-transparent" title="Delete Period">
                          <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- Add Period Form -->
        <div class="card bg-light border p-3 rounded-3">
          <h6 class="fw-bold text-dark small mb-3">
            <i data-lucide="plus-circle" class="text-primary me-1" style="width: 15px; height: 15px; vertical-align: middle;"></i>
            Add New Period
          </h6>
          <form method="post" action="<?= e(url('timetable/periods')) ?>">
            <?= csrf_field() ?>
            <div class="row g-2 align-items-end">
              <div class="col-md-2">
                <label class="form-label small text-secondary mb-1"># Number</label>
                <input type="number" name="period_number" class="form-control form-control-sm" value="<?= count($periods) + 1 ?>" required>
              </div>
              <div class="col-md-3">
                <label class="form-label small text-secondary mb-1">Period Label</label>
                <input type="text" name="name" class="form-control form-control-sm" placeholder="e.g. Period 1 or Lunch">
              </div>
              <div class="col-md-2">
                <label class="form-label small text-secondary mb-1">Start Time</label>
                <input type="time" name="start_time" class="form-control form-control-sm" required>
              </div>
              <div class="col-md-2">
                <label class="form-label small text-secondary mb-1">End Time</label>
                <input type="time" name="end_time" class="form-control form-control-sm" required>
              </div>
              <div class="col-md-2">
                <label class="form-label small text-secondary mb-1">Type</label>
                <select name="type" class="form-select form-select-sm">
                  <option value="Regular">Regular</option>
                  <option value="Break">Break</option>
                  <option value="Assembly">Assembly</option>
                </select>
              </div>
              <div class="col-md-1">
                <button type="submit" class="btn btn-primary btn-sm w-100 fw-semibold" style="background-color: #4f46e5; border-color: #4f46e5;">Add</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer bg-light px-4 py-2 border-top">
        <button type="button" class="btn btn-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Close</button>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 4. Modal: Daily Substitutes -->
<div class="modal fade" id="dailySubstitutesModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3" style="background-color: #f8fafc;">
        <div>
          <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
            <i data-lucide="user-plus" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
            Daily Teacher Substitutions
          </h5>
          <div class="text-muted small mt-1">Assign substitute coverage for absent teachers today.</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <div class="alert alert-info bg-info bg-opacity-10 border-0 text-info small p-3 rounded-3 mb-4 d-flex align-items-center gap-2">
          <i data-lucide="info" style="width: 16px; height: 16px; flex-shrink: 0;"></i>
          <span>Substitutes will be reflected on daily teacher roll calls and attendance without modifying permanent schedules.</span>
        </div>

        <div class="row g-3">
          <div class="col-md-5">
            <label class="form-label small fw-semibold text-secondary">Absent Teacher</label>
            <select class="form-select" id="subAbsentTeacher" style="border-radius: 8px;">
              <option value="">Select Absent Teacher...</option>
              <?php foreach ($teachers as $t): ?>
                <option value="<?= (int)$t['id'] ?>"><?= e($t['first_name'] . ' ' . $t['last_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-5">
            <label class="form-label small fw-semibold text-secondary">Assign Substitute Teacher</label>
            <select class="form-select" id="subReplacementTeacher" style="border-radius: 8px;">
              <option value="">Select Substitute Teacher...</option>
              <?php foreach ($teachers as $t): ?>
                <option value="<?= (int)$t['id'] ?>"><?= e($t['first_name'] . ' ' . $t['last_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-2 d-flex align-items-end">
            <button type="button" class="btn btn-primary w-100 fw-semibold" style="height: 40px; border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;" onclick="alert('Substitution record logged successfully.')">
              Assign
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer bg-light px-4 py-2 border-top">
        <button type="button" class="btn btn-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- 5. Modal: Print Timetable -->
<div class="modal fade" id="printTimetableModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
      <div class="modal-header border-bottom px-4 py-3 bg-white">
        <h5 class="modal-title fw-bold text-dark fs-6 mb-0">
          <i data-lucide="printer" class="text-primary me-2" style="width: 18px; height: 18px; vertical-align: middle;"></i>
          Print Preview — Timetable
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4 bg-light" id="printableTimetableArea">
        <div class="bg-white p-4 rounded-3 border shadow-xs" style="max-width: 1000px; margin: 0 auto;">
          <!-- School Printable Header -->
          <div class="text-center mb-4 pb-3 border-bottom">
            <h3 class="fw-bold mb-1" style="color: #1e293b; letter-spacing: 0.05em;"><?= e(!empty($printSchool['name']) ? $printSchool['name'] : 'INTERNATIONAL SCHOOL') ?></h3>
            <div class="text-muted small">Academic Weekly Timetable Schedule</div>
            <div class="badge bg-light text-primary border mt-2 px-3 py-1 fw-semibold">
              <?= $viewMode === 'teacher' ? 'Teacher: ' . e($selectedTeacherName) : 'Class: ' . e($selectedClassName) . ' - ' . e($selectedSectionName) ?>
            </div>
          </div>

          <!-- Printable Matrix Table -->
          <table class="table table-bordered align-middle mb-0" style="font-size: 11px;">
            <thead class="bg-light text-uppercase">
              <tr>
                <th class="py-2 text-center" style="width: 90px;">Day</th>
                <?php foreach ($periods as $p): ?>
                  <th class="py-2 text-center">
                    <?= !empty($p['name']) ? e($p['name']) : 'P' . $p['period_number'] ?><br>
                    <small class="fw-normal text-muted"><?= date('h:i', strtotime($p['start_time'])) ?>-<?= date('h:i', strtotime($p['end_time'])) ?></small>
                  </th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($days as $dayNum => $dayName): ?>
                <tr>
                  <td class="fw-bold text-center bg-light"><?= e($dayName) ?></td>
                  <?php foreach ($periods as $p): ?>
                    <?php 
                      $isBreak = strtolower($p['type'] ?? '') === 'break';
                      $slot = $timetableMap[$dayNum][$p['id']] ?? null;
                    ?>
                    <?php if ($isBreak): ?>
                      <td class="text-center text-muted bg-light">Break</td>
                    <?php elseif (!empty($slot)): ?>
                      <td class="text-center p-1">
                        <strong><?= e($slot['subject_name']) ?></strong><br>
                        <small class="text-muted"><?= e($slot['teacher_name'] ?? '') ?></small>
                      </td>
                    <?php else: ?>
                      <td class="text-center text-muted">—</td>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer bg-white px-4 py-3 border-top">
        <button type="button" class="btn btn-secondary btn-sm px-3 fw-medium" data-bs-dismiss="modal" style="border-radius: 6px;">Close</button>
        <button type="button" class="btn btn-primary btn-sm px-4 fw-semibold" onclick="window.print()" style="border-radius: 6px; background-color: #4f46e5; border-color: #4f46e5;">
          <i data-lucide="printer" style="width: 14px; height: 14px; vertical-align: middle;"></i> Print Now
        </button>
      </div>
    </div>
  </div>
</div>

<script>
// Classes and their sections mapping for dynamic dropdown
const classesData = <?= json_encode($classes) ?>;

function updateSectionDropdownAndSubmit() {
  const classSelect = document.getElementById('ttClassSelect');
  const sectionSelect = document.getElementById('ttSectionSelect');
  const selectedClassId = parseInt(classSelect.value, 10);

  sectionSelect.innerHTML = '';
  const selectedClass = classesData.find(c => parseInt(c.id, 10) === selectedClassId);

  if (selectedClass && selectedClass.sections && selectedClass.sections.length > 0) {
    selectedClass.sections.forEach(sec => {
      const opt = document.createElement('option');
      opt.value = sec.id;
      opt.textContent = sec.name;
      sectionSelect.appendChild(opt);
    });
    sectionSelect.value = selectedClass.sections[0].id;
  } else {
    const opt = document.createElement('option');
    opt.value = '0';
    opt.textContent = 'No Sections';
    sectionSelect.appendChild(opt);
  }

  document.getElementById('timetableFilterForm').submit();
}

function openAddSlotModal(dayNum, periodId, dayName, periodName) {
  document.getElementById('addSlotDaySelect').value = dayNum;
  document.getElementById('addSlotPeriodSelect').value = periodId;
  document.getElementById('addSlotModalSubtitle').textContent = `Adding lecture on ${dayName} during ${periodName}.`;
  
  const modal = new bootstrap.Modal(document.getElementById('addSlotModal'));
  modal.show();
}

// Hover effect on slot boxes to show actions
document.querySelectorAll('.slot-box').forEach(box => {
  box.addEventListener('mouseenter', function() {
    const actions = this.querySelector('.slot-actions');
    if (actions) {
      actions.classList.remove('d-none');
      actions.classList.add('d-flex');
    }
  });
  box.addEventListener('mouseleave', function() {
    const actions = this.querySelector('.slot-actions');
    if (actions) {
      actions.classList.remove('d-flex');
      actions.classList.add('d-none');
    }
  });
});
</script>

<style>
.btn-empty-slot {
  background: transparent;
  border: 1px dashed #cbd5e1;
  color: #94a3b8;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  transition: all 0.15s ease;
}
.btn-empty-slot:hover {
  background-color: #eff6ff;
  border-color: #3b82f6;
  color: #2563eb;
}
.hover-primary:hover {
  color: #4f46e5 !important;
}
@media print {
  body * {
    visibility: hidden;
  }
  #printableTimetableArea, #printableTimetableArea * {
    visibility: visible;
  }
  #printableTimetableArea {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    background: #ffffff !important;
    padding: 0 !important;
  }
  .modal-backdrop, .modal-header, .modal-footer {
    display: none !important;
  }
}
</style>
