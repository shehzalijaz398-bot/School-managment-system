<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('settings') ?>" class="text-decoration-none text-muted small">&larr; System Administration</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Self-Service Onboarding</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-magic text-primary me-2"></i><?= e($title) ?>
            </h1>
            <p class="text-muted small mb-0">Guided self-service institutional configuration for branding, academic sessions, grade scales, fee structures, and staff roles.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?= url('school/health') ?>" class="btn btn-outline-info btn-sm shadow-sm fw-semibold">
                <i class="bi bi-heart-pulse me-1"></i> School Health Center
            </a>
            <a href="<?= url('dashboard') ?>" class="btn btn-outline-secondary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-house me-1"></i> Return to Dashboard
            </a>
        </div>
    </div>

    <!-- Onboarding Progress Bar & Overview -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="fw-bold text-dark">
                    Institutional Setup Progress
                    <?php if ($status['is_completed']): ?>
                        <span class="badge bg-success-subtle text-success border border-success-subtle ms-2">
                            <i class="bi bi-check-circle-fill me-1"></i>Fully Operational
                        </span>
                    <?php else: ?>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle ms-2">
                            In Progress
                        </span>
                    <?php endif; ?>
                </div>
                <div class="fw-bold text-primary fs-5"><?= (int)$status['progress_percentage'] ?>%</div>
            </div>
            <div class="progress" style="height: 10px;">
                <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" 
                     style="width: <?= (int)$status['progress_percentage'] ?>%;" 
                     aria-valuenow="<?= (int)$status['progress_percentage'] ?>" aria-valuemin="0" aria-valuemax="100">
                </div>
            </div>

            <!-- Step Pills / Navigation -->
            <div class="row g-2 mt-3 pt-2 border-top">
                <?php foreach ($status['steps'] as $sKey => $stepDef): 
                    $isDone = in_array($sKey, $status['completed_steps'], true);
                    $isActive = ($active_step === $sKey);
                ?>
                    <div class="col-md col-6">
                        <a href="<?= url("onboarding/wizard?step={$sKey}") ?>" 
                           class="card h-100 border text-decoration-none p-2 rounded-3 transition-all <?= $isActive ? 'border-primary bg-primary-subtle shadow-sm' : ($isDone ? 'border-success-subtle bg-light' : 'border-light bg-white') ?>">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge <?= $isActive ? 'bg-primary text-white' : ($isDone ? 'bg-success text-white' : 'bg-secondary text-white') ?> rounded-circle p-2" style="width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 11px;">
                                    <?php if ($isDone): ?>
                                        <i class="bi bi-check"></i>
                                    <?php else: ?>
                                        <?= $stepDef['order'] ?>
                                    <?php endif; ?>
                                </span>
                                <div class="overflow-hidden">
                                    <div class="small fw-bold text-truncate <?= $isActive ? 'text-primary' : ($isDone ? 'text-dark' : 'text-muted') ?>">
                                        <?= htmlspecialchars($stepDef['title']) ?>
                                    </div>
                                    <div class="text-muted" style="font-size: 10px;">Step <?= $stepDef['order'] ?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Active Step Content Area -->
    <div class="row g-4">
        <!-- Main Form Column -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 bg-white">
                <div class="card-header bg-white border-bottom p-4">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <span class="badge bg-primary text-uppercase px-2 py-1 mb-2">Step <?= $status['steps'][$active_step]['order'] ?? 1 ?> of 7</span>
                            <h5 class="fw-bold text-dark mb-1"><?= htmlspecialchars($status['steps'][$active_step]['title'] ?? 'Setup Step') ?></h5>
                            <p class="text-muted small mb-0"><?= htmlspecialchars($status['steps'][$active_step]['subtitle'] ?? '') ?></p>
                        </div>
                    </div>
                </div>

                <div class="card-body p-4">
                    <!-- Step 1: Profile & Region -->
                    <?php if ($active_step === 'profile'): ?>
                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="profile">

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Institution Legal Name <span class="text-danger">*</span></label>
                                    <input type="text" name="school_name" class="form-control" required 
                                           value="<?= htmlspecialchars($status['institutional_summary']['school_name'] ?? '') ?>" placeholder="e.g. Oxford International Academy">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">School Identifier Code</label>
                                    <input type="text" name="school_code" class="form-control" 
                                           value="<?= htmlspecialchars($status['institutional_summary']['school_code'] ?? '') ?>" placeholder="e.g. OIA-2026">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Time Zone <span class="text-danger">*</span></label>
                                    <select name="timezone" class="form-select" required>
                                        <?php 
                                        $tzList = ['UTC', 'Asia/Karachi', 'Asia/Kolkata', 'Asia/Dubai', 'Europe/London', 'America/New_York', 'America/Los_Angeles', 'Asia/Singapore'];
                                        foreach ($tzList as $tz): ?>
                                            <option value="<?= $tz ?>" <?= ($status['institutional_summary']['timezone'] === $tz) ? 'selected' : '' ?>><?= $tz ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Base Currency Code <span class="text-danger">*</span></label>
                                    <select name="currency" class="form-select" required>
                                        <?php 
                                        $curList = ['PKR', 'INR', 'USD', 'GBP', 'EUR', 'AED', 'SAR', 'CAD'];
                                        foreach ($curList as $cur): ?>
                                            <option value="<?= $cur ?>" <?= ($status['institutional_summary']['currency'] === $cur) ? 'selected' : '' ?>><?= $cur ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Primary Brand Color</label>
                                    <div class="input-group">
                                        <input type="color" name="primary_color" class="form-control form-control-color" 
                                               value="<?= htmlspecialchars($status['institutional_summary']['primary_color'] ?? '#0b4f6c') ?>">
                                        <input type="text" class="form-control" value="<?= htmlspecialchars($status['institutional_summary']['primary_color'] ?? '#0b4f6c') ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Secondary Accent Color</label>
                                    <div class="input-group">
                                        <input type="color" name="secondary_color" class="form-control form-control-color" 
                                               value="<?= htmlspecialchars($status['institutional_summary']['secondary_color'] ?? '#01baef') ?>">
                                        <input type="text" class="form-control" value="<?= htmlspecialchars($status['institutional_summary']['secondary_color'] ?? '#01baef') ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Official Contact Email</label>
                                    <input type="email" name="email" class="form-control" placeholder="admin@school.edu">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Official Contact Phone</label>
                                    <input type="text" name="phone" class="form-control" placeholder="+1 (555) 019-2834">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">Physical Campus Address</label>
                                    <textarea name="address" class="form-control" rows="2" placeholder="Street, City, Postal Code, Country"></textarea>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 2: Academic Calendar & Sessions -->
                    <?php elseif ($active_step === 'academic_sessions'): ?>
                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="academic_sessions">

                            <div class="alert alert-info border-0 p-3 mb-4 small">
                                <i class="bi bi-info-circle-fill me-1"></i>
                                An active academic year anchors student enrollments, exam report cards, and tuition billing cycles. Standard Fall, Spring, and Summer terms will be auto-generated.
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Academic Session Title <span class="text-danger">*</span></label>
                                    <input type="text" name="session_name" class="form-control" required 
                                           value="<?= htmlspecialchars($status['institutional_summary']['active_academic_year'] ?? (date('Y') . '-' . (date('Y') + 1))) ?>" 
                                           placeholder="e.g. <?= date('Y') . '-' . (date('Y') + 1) ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold">Session Start Date <span class="text-danger">*</span></label>
                                    <input type="date" name="start_date" class="form-control" required value="<?= date('Y') ?>-08-15">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold">Session End Date <span class="text-danger">*</span></label>
                                    <input type="date" name="end_date" class="form-control" required value="<?= (date('Y') + 1) ?>-06-30">
                                </div>
                            </div>

                            <?php if (!empty($academic_years)): ?>
                                <div class="mt-4 pt-3 border-top">
                                    <h6 class="fw-bold small text-dark mb-2">Existing Sessions on File:</h6>
                                    <ul class="list-group list-group-flush small">
                                        <?php foreach ($academic_years as $ay): ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                                <span><?= htmlspecialchars($ay['name']) ?> (<?= $ay['start_date'] ?> to <?= $ay['end_date'] ?>)</span>
                                                <?php if ((int)$ay['is_active'] === 1): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-light text-muted">Inactive</span>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=profile') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 3: Classes & Sections -->
                    <?php elseif ($active_step === 'classes_sections'): ?>
                        <!-- Quick 1-Click Preset Options -->
                        <div class="p-3 bg-light rounded-3 border mb-4">
                            <h6 class="fw-bold text-dark mb-1">
                                <i class="bi bi-lightning-charge-fill text-warning me-1"></i>Quick 1-Click Curriculum Presets
                            </h6>
                            <p class="text-muted small mb-3">Load pre-configured grade hierarchies, evaluation scales, and standard fee categories in one click:</p>
                            
                            <div class="d-flex flex-wrap gap-2">
                                <form action="<?= url('onboarding/wizard/apply-preset') ?>" method="POST" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="preset_key" value="k12_standard">
                                    <button type="submit" class="btn btn-sm btn-outline-primary fw-semibold rounded-3">
                                        <i class="bi bi-mortarboard me-1"></i> Apply Standard K-12
                                    </button>
                                </form>
                                <form action="<?= url('onboarding/wizard/apply-preset') ?>" method="POST" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="preset_key" value="primary_middle">
                                    <button type="submit" class="btn btn-sm btn-outline-primary fw-semibold rounded-3">
                                        <i class="bi bi-backpack me-1"></i> Apply Primary &amp; Middle (Nursery to 8th)
                                    </button>
                                </form>
                                <form action="<?= url('onboarding/wizard/apply-preset') ?>" method="POST" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="preset_key" value="higher_secondary">
                                    <button type="submit" class="btn btn-sm btn-outline-primary fw-semibold rounded-3">
                                        <i class="bi bi-building me-1"></i> Apply Senior Secondary (9-12 Prep)
                                    </button>
                                </form>
                            </div>
                        </div>

                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="classes_sections">

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Academic Classes / Grade Levels (One per line or comma-separated) <span class="text-danger">*</span></label>
                                <textarea name="classes" class="form-control" rows="5" required placeholder="Grade 1&#10;Grade 2&#10;Grade 3&#10;Grade 4&#10;Grade 5"><?php 
                                    if (!empty($classes)) {
                                        echo htmlspecialchars(implode("\n", array_column($classes, 'name')));
                                    } else {
                                        echo "Grade 1\nGrade 2\nGrade 3\nGrade 4\nGrade 5\nGrade 6\nGrade 7\nGrade 8\nGrade 9\nGrade 10";
                                    }
                                ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Default Section Divisions</label>
                                <input type="text" name="default_sections" class="form-control" value="A, B" placeholder="e.g. A, B or Red, Blue">
                                <div class="form-text small">Each class entered above will automatically receive these section divisions.</div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=academic_sessions') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 4: Grading Scales -->
                    <?php elseif ($active_step === 'grading_rules'): ?>
                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="grading_rules">

                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Grading System Framework</label>
                                    <select name="grading_system" class="form-select">
                                        <option value="letter_grade" selected>Letter Grades (A+, A, B, C, D, F)</option>
                                        <option value="gpa_4">GPA Scale (4.0 Maximum)</option>
                                        <option value="percentage">Pure Percentage (0 - 100%)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Passing Percentage Threshold (%)</label>
                                    <input type="number" name="passing_percentage" class="form-control" min="1" max="100" value="40">
                                </div>
                            </div>

                            <h6 class="fw-bold small text-dark mb-2">Grade Boundary Scale:</h6>
                            <div class="table-responsive border rounded-3 mb-3">
                                <table class="table table-sm align-middle mb-0" style="font-size: 13px;">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Grade Symbol</th>
                                            <th>Min Percentage (%)</th>
                                            <th>Max Percentage (%)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $defaultScales = !empty($grade_scales) ? $grade_scales : [
                                            ['grade' => 'A+', 'min_percentage' => 90, 'max_percentage' => 100],
                                            ['grade' => 'A',  'min_percentage' => 80, 'max_percentage' => 89.99],
                                            ['grade' => 'B',  'min_percentage' => 70, 'max_percentage' => 79.99],
                                            ['grade' => 'C',  'min_percentage' => 60, 'max_percentage' => 69.99],
                                            ['grade' => 'D',  'min_percentage' => 50, 'max_percentage' => 59.99],
                                            ['grade' => 'F',  'min_percentage' => 0,  'max_percentage' => 49.99],
                                        ];
                                        foreach ($defaultScales as $i => $gs): ?>
                                            <tr>
                                                <td>
                                                    <input type="text" name="grade_scales[<?= $i ?>][grade]" class="form-control form-control-sm fw-bold" value="<?= htmlspecialchars($gs['grade']) ?>">
                                                </td>
                                                <td>
                                                    <input type="number" step="0.01" name="grade_scales[<?= $i ?>][min_percentage]" class="form-control form-control-sm" value="<?= $gs['min_percentage'] ?>">
                                                </td>
                                                <td>
                                                    <input type="number" step="0.01" name="grade_scales[<?= $i ?>][max_percentage]" class="form-control form-control-sm" value="<?= $gs['max_percentage'] ?>">
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=classes_sections') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 5: Fee Structures -->
                    <?php elseif ($active_step === 'fee_structures'): ?>
                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="fee_structures">

                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Monthly Fee Due Day</label>
                                    <input type="number" name="fee_due_day" class="form-control" min="1" max="28" value="7">
                                    <div class="form-text small">Day of each month when student recurring invoices are generated and due.</div>
                                </div>
                            </div>

                            <h6 class="fw-bold small text-dark mb-2">Core Fee Categories:</h6>
                            <div class="table-responsive border rounded-3 mb-3">
                                <table class="table table-sm align-middle mb-0" style="font-size: 13px;">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Category Name</th>
                                            <th>Default Amount (<?= htmlspecialchars($status['institutional_summary']['currency'] ?? 'PKR') ?>)</th>
                                            <th>Billing Frequency</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $defaultFees = !empty($fee_categories) ? $fee_categories : [
                                            ['name' => 'Monthly Tuition Fee', 'amount' => 250.00, 'frequency' => 'monthly'],
                                            ['name' => 'Annual Admission Fee', 'amount' => 500.00, 'frequency' => 'one_time'],
                                            ['name' => 'Examination Fee', 'amount' => 75.00, 'frequency' => 'termly'],
                                            ['name' => 'Computer Lab Fee', 'amount' => 50.00, 'frequency' => 'monthly'],
                                        ];
                                        foreach ($defaultFees as $i => $df): ?>
                                            <tr>
                                                <td>
                                                    <input type="text" name="categories[<?= $i ?>][name]" class="form-control form-control-sm" value="<?= htmlspecialchars($df['name']) ?>">
                                                </td>
                                                <td>
                                                    <input type="number" step="0.01" name="categories[<?= $i ?>][amount]" class="form-control form-control-sm" value="<?= $df['amount'] ?>">
                                                </td>
                                                <td>
                                                    <select name="categories[<?= $i ?>][frequency]" class="form-select form-select-sm">
                                                        <option value="monthly" <?= ($df['frequency'] === 'monthly') ? 'selected' : '' ?>>Monthly</option>
                                                        <option value="termly" <?= ($df['frequency'] === 'termly') ? 'selected' : '' ?>>Termly</option>
                                                        <option value="annually" <?= ($df['frequency'] === 'annually') ? 'selected' : '' ?>>Annually</option>
                                                        <option value="one_time" <?= ($df['frequency'] === 'one_time') ? 'selected' : '' ?>>One Time</option>
                                                    </select>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=grading_rules') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 6: Staff Roles & Departments -->
                    <?php elseif ($active_step === 'staff_roles'): ?>
                        <form action="<?= url('onboarding/wizard/save-step') ?>" method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="step_key" value="staff_roles">

                            <div class="mb-4">
                                <label class="form-label small fw-bold">Institutional Departments (Comma-separated)</label>
                                <input type="text" name="departments" class="form-control" 
                                       value="<?php 
                                           if (!empty($departments)) {
                                               echo htmlspecialchars(implode(', ', array_column($departments, 'name')));
                                           } else {
                                               echo 'Academics, Administration, Finance, Human Resources, Student Services';
                                           }
                                       ?>">
                            </div>

                            <h6 class="fw-bold small text-dark mb-2">Available Role Profiles:</h6>
                            <div class="row g-2 mb-3">
                                <?php foreach ($roles as $r): ?>
                                    <div class="col-md-4 col-6">
                                        <div class="p-2 border rounded-3 bg-light small">
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($r['name']) ?></div>
                                            <div class="text-muted" style="font-size: 11px;"><?= htmlspecialchars($r['description'] ?? 'System role') ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=fee_structures') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-primary px-4 fw-semibold shadow-sm">
                                    Save &amp; Continue &rarr;
                                </button>
                            </div>
                        </form>

                    <!-- Step 7: Final Review & Launch -->
                    <?php elseif ($active_step === 'review'): ?>
                        <div class="text-center py-3">
                            <div class="display-6 text-success mb-2">
                                <i class="bi bi-shield-check"></i>
                            </div>
                            <h4 class="fw-bold text-dark">Institutional Readiness Verification</h4>
                            <p class="text-muted small">Verify your core configurations before launching live operational features.</p>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-light">
                                    <div class="text-muted small">Institution Name</div>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($status['institutional_summary']['school_name']) ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-light">
                                    <div class="text-muted small">Active Academic Session</div>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($status['institutional_summary']['active_academic_year'] ?? 'Not set') ?></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 border rounded-3 bg-light text-center">
                                    <div class="h4 fw-bold text-primary mb-0"><?= (int)$status['institutional_summary']['total_classes'] ?></div>
                                    <div class="text-muted small">Classes Configured</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 border rounded-3 bg-light text-center">
                                    <div class="h4 fw-bold text-primary mb-0"><?= (int)$status['institutional_summary']['total_grade_scales'] ?></div>
                                    <div class="text-muted small">Grade Tiers</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 border rounded-3 bg-light text-center">
                                    <div class="h4 fw-bold text-primary mb-0"><?= (int)$status['institutional_summary']['total_fee_categories'] ?></div>
                                    <div class="text-muted small">Fee Schedules</div>
                                </div>
                            </div>
                        </div>

                        <form action="<?= url('onboarding/wizard/complete') ?>" method="POST">
                            <?= csrf_field() ?>
                            <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                <a href="<?= url('onboarding/wizard?step=staff_roles') ?>" class="btn btn-outline-secondary px-3">
                                    &larr; Back
                                </a>
                                <button type="submit" class="btn btn-success px-4 py-2 fw-bold shadow-sm rounded-3">
                                    <i class="bi bi-rocket-takeoff me-1"></i> Finalize Onboarding &amp; Go Live
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <!-- Sidebar / Context Column -->
        <div class="col-lg-4">
            <!-- Next Action Recommendations -->
            <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
                <div class="card-header bg-white border-bottom p-3">
                    <h6 class="fw-bold text-dark mb-0">
                        <i class="bi bi-lightbulb text-warning me-1"></i>Setup Guidance &amp; Tips
                    </h6>
                </div>
                <div class="card-body p-3 small text-muted">
                    <p class="mb-2"><strong>Save Anytime:</strong> You can save your progress at any stage. Settings take effect immediately without requiring developer support.</p>
                    <p class="mb-2"><strong>Data Migration:</strong> Once classes and fee categories are saved, you can import existing students and faculty via <a href="<?= url('admin/data') ?>">Bulk Data Import</a>.</p>
                    <p class="mb-0"><strong>Health Diagnostic:</strong> Check your <a href="<?= url('school/health') ?>">School Health Center</a> at any time to inspect missing setup records or cross-module warnings.</p>
                </div>
            </div>

            <!-- Health Snapshot Card -->
            <div class="card border-0 shadow-sm rounded-4 bg-primary text-white p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="fs-1"><i class="bi bi-shield-check"></i></div>
                    <div>
                        <div class="fw-bold">Enterprise Isolation</div>
                        <div class="small opacity-75">Your school data, grading formulas, and fee registers are fully isolated within Tenant ID #<?= (int)$status['school_id'] ?>.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
