<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('hr/dashboard') ?>" class="text-decoration-none text-muted small">&larr; HR Operations</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Holidays</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-calendar-event text-success me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Manage institutional closures, national holidays, religious observances, and semester recess dates.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <!-- Year Selector -->
            <form method="GET" action="<?= url('hr/holidays') ?>" class="d-flex align-items-center">
                <select name="year" class="form-select form-select-sm shadow-sm" onchange="this.form.submit()">
                    <?php 
                    $currY = (int)date('Y');
                    for ($y = $currY - 2; $y <= $currY + 2; $y++): ?>
                        <option value="<?= $y ?>" <?= ($year == $y) ? 'selected' : '' ?>><?= $y ?> Calendar</option>
                    <?php endfor; ?>
                </select>
            </form>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createHolidayModal">
                <i class="bi bi-plus-lg me-1"></i> Add Holiday / Break
            </button>
        </div>
    </div>

    <!-- Calendar Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Holidays (<?= htmlspecialchars($year) ?>)</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= count($holidays) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Scheduled across the academic calendar</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Off-Days</div>
                <?php 
                $totalDays = 0;
                foreach ($holidays as $h) {
                    $start = strtotime($h['start_date']);
                    $end = strtotime($h['end_date']);
                    $diff = max(1, round(($end - $start) / 86400) + 1);
                    $totalDays += $diff;
                }
                ?>
                <div class="h3 fw-bold text-primary mt-1 mb-0"><?= $totalDays ?> Days</div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Non-instructional &amp; closure duration</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Upcoming Closures</div>
                <?php 
                $upcomingCount = 0;
                $today = date('Y-m-d');
                foreach ($holidays as $h) {
                    if ($h['end_date'] >= $today) $upcomingCount++;
                }
                ?>
                <div class="h3 fw-bold text-warning mt-1 mb-0"><?= $upcomingCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Remaining closures for this calendar year</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Annual Recurring</div>
                <?php 
                $recurringCount = 0;
                foreach ($holidays as $h) {
                    if (!empty($h['is_recurring'])) $recurringCount++;
                }
                ?>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= $recurringCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Auto-applied across future school sessions</div>
            </div>
        </div>
    </div>

    <!-- Holidays List Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">Institutional Holidays &amp; Breaks - <?= htmlspecialchars($year) ?></h6>
            <span class="badge bg-light border text-dark fw-semibold"><?= count($holidays) ?> Records</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($holidays)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-calendar2-x text-muted fs-1 d-block mb-2"></i>
                    <h6 class="fw-bold text-dark">No Holidays Configured for <?= htmlspecialchars($year) ?></h6>
                    <p class="text-muted small mb-3">Add official institutional holidays, winter/summer vacations, and public holidays.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#createHolidayModal">
                        <i class="bi bi-plus-lg me-1"></i> Add Holiday
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Holiday / Observance</th>
                                <th>Category Type</th>
                                <th>Calendar Dates</th>
                                <th>Duration</th>
                                <th>Recurring</th>
                                <th>Notes / Description</th>
                                <th class="pe-4 text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($holidays as $h): ?>
                                <?php 
                                $startTs = strtotime($h['start_date']);
                                $endTs = strtotime($h['end_date']);
                                $daysCount = max(1, round(($endTs - $startTs) / 86400) + 1);
                                $isPast = ($h['end_date'] < date('Y-m-d'));
                                ?>
                                <tr class="<?= $isPast ? 'opacity-75' : '' ?>">
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($h['name']) ?></div>
                                        <?php if ($isPast): ?>
                                            <span class="badge bg-light text-muted border" style="font-size: 10px;">Concluded</span>
                                        <?php else: ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle" style="font-size: 10px;">Upcoming</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $typeBadge = match($h['type']) {
                                            'national' => 'bg-danger-subtle text-danger border-danger-subtle',
                                            'religious' => 'bg-success-subtle text-success border-success-subtle',
                                            'academic' => 'bg-info-subtle text-info border-info-subtle',
                                            default => 'bg-primary-subtle text-primary border-primary-subtle',
                                        };
                                        ?>
                                        <span class="badge border <?= $typeBadge ?> text-capitalize px-2 py-1">
                                            <?= htmlspecialchars($h['type']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark">
                                            <?= date('D, M d, Y', $startTs) ?>
                                            <?php if ($h['start_date'] !== $h['end_date']): ?>
                                                &rarr; <?= date('D, M d, Y', $endTs) ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border fw-semibold">
                                            <?= $daysCount ?> <?= ($daysCount === 1) ? 'Day' : 'Days' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($h['is_recurring'])): ?>
                                            <span class="text-success small fw-semibold"><i class="bi bi-arrow-repeat me-1"></i>Yes</span>
                                        <?php else: ?>
                                            <span class="text-muted small">One-time</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="max-width: 250px;" class="text-truncate text-muted small">
                                        <?= htmlspecialchars($h['description'] ?: 'Official campus closure.') ?>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <div class="d-inline-flex gap-1">
                                            <button type="button" class="btn btn-sm btn-light border text-dark edit-holiday-btn"
                                                    data-id="<?= $h['id'] ?>"
                                                    data-name="<?= htmlspecialchars($h['name']) ?>"
                                                    data-start="<?= $h['start_date'] ?>"
                                                    data-end="<?= $h['end_date'] ?>"
                                                    data-type="<?= $h['type'] ?>"
                                                    data-recurring="<?= !empty($h['is_recurring']) ? 1 : 0 ?>"
                                                    data-desc="<?= htmlspecialchars($h['description'] ?? '') ?>"
                                                    data-bs-toggle="modal" data-bs-target="#createHolidayModal">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                            <form method="POST" action="<?= url('hr/holidays/' . $h['id'] . '/delete') ?>" onsubmit="return confirm('Remove this holiday record?');" class="d-inline">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Create / Edit Holiday Modal -->
<div class="modal fade" id="createHolidayModal" tabindex="-1" aria-labelledby="createHolidayModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/holidays') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="holiday_id" value="">
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="createHolidayModalLabel">Add Holiday / Break</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Holiday / Event Title <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="holiday_name" class="form-control" placeholder="e.g. Independence Day, Winter Break" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Start Date <span class="text-danger">*</span></label>
                            <input type="date" name="start_date" id="holiday_start" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">End Date <span class="text-danger">*</span></label>
                            <input type="date" name="end_date" id="holiday_end" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Holiday Category <span class="text-danger">*</span></label>
                        <select name="type" id="holiday_type" class="form-select" required>
                            <option value="institutional">Institutional / School Closure</option>
                            <option value="national">National Holiday</option>
                            <option value="religious">Religious Observance</option>
                            <option value="academic">Academic Vacation / Term Break</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Description / Administrative Remarks</label>
                        <textarea name="description" id="holiday_desc" rows="2" class="form-control" placeholder="e.g. Campus closed for all teaching and administrative staff."></textarea>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_recurring" value="1" id="holiday_recurring">
                        <label class="form-check-label small fw-semibold text-dark" for="holiday_recurring">
                            Annual Recurring Holiday (Occurs every year)
                        </label>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Holiday</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editBtns = document.querySelectorAll('.edit-holiday-btn');
    editBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            document.getElementById('holiday_id').value = this.dataset.id;
            document.getElementById('holiday_name').value = this.dataset.name;
            document.getElementById('holiday_start').value = this.dataset.start;
            document.getElementById('holiday_end').value = this.dataset.end;
            document.getElementById('holiday_type').value = this.dataset.type;
            document.getElementById('holiday_recurring').checked = (this.dataset.recurring === '1');
            document.getElementById('holiday_desc').value = this.dataset.desc;
            document.getElementById('createHolidayModalLabel').textContent = 'Edit Holiday Record';
        });
    });

    const createModal = document.getElementById('createHolidayModal');
    createModal.addEventListener('hidden.bs.modal', function () {
        document.getElementById('holiday_id').value = '';
        document.getElementById('holiday_name').value = '';
        document.getElementById('holiday_start').value = '<?= date('Y-m-d') ?>';
        document.getElementById('holiday_end').value = '<?= date('Y-m-d') ?>';
        document.getElementById('holiday_type').value = 'institutional';
        document.getElementById('holiday_recurring').checked = false;
        document.getElementById('holiday_desc').value = '';
        document.getElementById('createHolidayModalLabel').textContent = 'Add Holiday / Break';
    });
});
</script>
