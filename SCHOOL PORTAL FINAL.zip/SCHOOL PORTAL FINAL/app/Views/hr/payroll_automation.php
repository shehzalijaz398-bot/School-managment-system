<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= htmlspecialchars($title) ?></h1>
    </div>

    <div class="row">
        <!-- Configuration form -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4 border-bottom-primary">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Automation Settings</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?= url('hr/payroll/calculate-mass') ?>" id="autoPayrollForm">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Payroll Month</label>
                            <select class="form-select" name="payroll_month" required>
                                <?php foreach($months as $m): ?>
                                    <option value="<?= $m ?>"><?= date('F Y', strtotime($m . '-01')) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Target billing cycle for calculations.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Deduction Per Unapproved Absent Day ($)</label>
                            <input type="number" step="0.01" min="0" class="form-control" name="deduction_per_day" value="50.00" required>
                            <small class="text-muted">Cross-references <code>staff_attendance</code> array.</small>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Performance Bonus Multiplier</label>
                            <input type="number" step="0.01" min="1.0" class="form-control" name="bonus_multiplier" value="1.00" required>
                            <small class="text-muted">1.0 = Base. 1.10 = 10% structural bonus.</small>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="button" class="btn btn-primary btn-lg fw-bold shadow-sm" id="runEngineBtn" onclick="confirmRun(this)">
                                💰 Run Automated Monthly Payroll
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Metric panels -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between bg-light">
                    <h6 class="m-0 font-weight-bold text-primary">System Readiness & Architecture Info</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center mb-4">
                        <div class="col-md-6 mb-3">
                            <div class="p-3 bg-light rounded border border-success border-opacity-25 h-100">
                                <h2 class="text-success fw-bold mb-1"><?= $active_employees ?></h2>
                                <div class="text-muted small text-uppercase fw-bold">Active Staff Records Linked</div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="p-3 bg-light rounded border border-primary border-opacity-25 h-100">
                                <h2 class="text-primary fw-bold mb-1"><i class="bi bi-shield-check"></i></h2>
                                <div class="text-muted small text-uppercase fw-bold">Attendance Sync Ready</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info border-start border-info border-4 bg-opacity-10 py-3">
                        <h6 class="fw-bold"><i class="bi bi-info-circle-fill me-2"></i>Automated HR Financial Engine</h6>
                        <p class="mb-0 small">
                            The Mass Payroll Engine will automatically scan the <code>staff_attendance</code> table and cross-reference records with approved <code>leave_requests</code>. Unapproved absences will incur exact financial penalties while approved leave is strictly treated as paid time off. Deductions, basic salaries, and bonuses map directly into the final generated ledgers securely utilizing a bulk database transaction boundary.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function confirmRun(btn) {
    if (confirm("Execute the mass payroll automated generator? This will deploy calculations for all active staff and securely insert the data into the payroll ledgers.")) {
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Calculating Ledger Array...';
        btn.classList.add('disabled');
        btn.setAttribute('disabled', 'disabled');
        
        setTimeout(() => {
            document.getElementById('autoPayrollForm').submit();
        }, 100);
        return true;
    }
    return false;
}
</script>
