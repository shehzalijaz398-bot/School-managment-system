<div class="print-container container mt-4 bg-white p-5 shadow-sm">
    <div class="row border-bottom pb-4 mb-4">
        <div class="col-sm-6">
            <h2 class="text-primary fw-bold mb-1"><?= htmlspecialchars($school['name'] ?? 'School Portal') ?></h2>
            <address class="text-muted mb-0">
                <?= htmlspecialchars($school['address'] ?? '') ?><br>
                Phone: <?= htmlspecialchars($school['phone'] ?? '') ?>
            </address>
        </div>
        <div class="col-sm-6 text-end">
            <h2 class="text-uppercase text-secondary fw-bold mb-1">Payslip</h2>
            <p class="mb-0 fs-5 fw-bold text-dark">Month: <?= date('F Y', strtotime($payroll['payroll_month'].'-01')) ?></p>
            <p class="mb-0 text-muted">Generated: <?= date('d M, Y', strtotime($payroll['created_at'])) ?></p>
            <div class="mt-2">
                <span class="badge <?= $payroll['status'] === 'paid' ? 'bg-success' : 'bg-warning text-dark' ?> fs-6 text-uppercase px-3 py-2">
                    STATUS: <?= htmlspecialchars($payroll['status']) ?>
                </span>
            </div>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-md-6">
            <div class="p-3 bg-light rounded h-100 border border-secondary border-opacity-25">
                <h6 class="text-uppercase text-muted border-bottom border-secondary border-opacity-25 pb-2 mb-3 fw-bold">Employee Details</h6>
                <div class="row mb-2"><div class="col-4 fw-bold">Name:</div><div class="col-8 fw-bold text-dark"><?= htmlspecialchars($payroll['first_name'] . ' ' . $payroll['last_name']) ?></div></div>
                <div class="row mb-2"><div class="col-4 fw-bold">Emp ID:</div><div class="col-8"><?= htmlspecialchars($payroll['employee_code']) ?></div></div>
                <div class="row mb-2"><div class="col-4 fw-bold">Dept:</div><div class="col-8"><?= htmlspecialchars($payroll['department_name'] ?? 'N/A') ?></div></div>
                <div class="row mb-0"><div class="col-4 fw-bold">Role:</div><div class="col-8"><?= htmlspecialchars($payroll['designation_name'] ?? 'N/A') ?></div></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="p-3 bg-light rounded h-100 border border-secondary border-opacity-25">
                <h6 class="text-uppercase text-muted border-bottom border-secondary border-opacity-25 pb-2 mb-3 fw-bold">Payment Summary</h6>
                <div class="row mb-2"><div class="col-5 fw-bold">Basic Pay:</div><div class="col-7 text-end"><?= number_format((float)$payroll['basic_salary'], 2) ?></div></div>
                <div class="row mb-2"><div class="col-5 fw-bold">Allowances:</div><div class="col-7 text-end"><?= number_format((float)$payroll['allowances'] + (float)$payroll['bonuses'], 2) ?></div></div>
                <div class="row mb-2"><div class="col-5 fw-bold">Deductions:</div><div class="col-7 text-end text-danger">-<?= number_format((float)$payroll['deductions'] + (float)$payroll['leave_deduction'] + (float)$payroll['attendance_deduction'], 2) ?></div></div>
                <div class="row mb-0 pt-2 border-top border-secondary border-opacity-25">
                    <div class="col-5 fw-bold fs-5 text-dark">Net Pay:</div>
                    <div class="col-7 text-end fw-bold fs-4 text-success"><?= number_format((float)$payroll['net_salary'], 2) ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <h6 class="text-uppercase text-muted mb-3 fw-bold">Earnings Breakdown</h6>
            <table class="table table-bordered table-sm border-secondary border-opacity-25">
                <thead class="table-light">
                    <tr><th>Description</th><th class="text-end" style="width: 120px;">Amount</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $totalEarn = 0;
                    foreach ($items as $item): 
                        if ($item['type'] === 'earning'): 
                            $totalEarn += (float)$item['amount'];
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($item['description']) ?></td>
                        <td class="text-end"><?= number_format((float)$item['amount'], 2) ?></td>
                    </tr>
                    <?php 
                        endif; 
                    endforeach; 
                    
                    if ($totalEarn == 0): 
                    ?>
                    <tr>
                        <td>Basic Salary</td>
                        <td class="text-end"><?= number_format((float)$payroll['basic_salary'], 2) ?></td>
                    </tr>
                    <?php if ((float)$payroll['allowances'] > 0): ?>
                    <tr>
                        <td>Allowances</td>
                        <td class="text-end"><?= number_format((float)$payroll['allowances'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ((float)$payroll['bonuses'] > 0): ?>
                    <tr>
                        <td>Bonuses</td>
                        <td class="text-end"><?= number_format((float)$payroll['bonuses'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php 
                        $totalEarn = (float)$payroll['basic_salary'] + (float)$payroll['allowances'] + (float)$payroll['bonuses'];
                    endif; 
                    ?>
                </tbody>
                <tfoot class="table-light fw-bold text-dark fs-6">
                    <tr><td class="text-end">Total Earnings</td><td class="text-end"><?= number_format($totalEarn, 2) ?></td></tr>
                </tfoot>
            </table>
        </div>

        <div class="col-md-6">
            <h6 class="text-uppercase text-muted mb-3 fw-bold">Deductions Breakdown</h6>
            <table class="table table-bordered table-sm border-secondary border-opacity-25">
                <thead class="table-light">
                    <tr><th>Description</th><th class="text-end" style="width: 120px;">Amount</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $totalDed = 0;
                    foreach ($items as $item): 
                        if ($item['type'] === 'deduction'): 
                            $totalDed += (float)$item['amount'];
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($item['description']) ?></td>
                        <td class="text-end text-danger"><?= number_format((float)$item['amount'], 2) ?></td>
                    </tr>
                    <?php 
                        endif; 
                    endforeach; 
                    
                    if ($totalDed == 0 && ((float)$payroll['deductions'] > 0 || (float)$payroll['attendance_deduction'] > 0)):
                    ?>
                    <?php if ((float)$payroll['deductions'] > 0): ?>
                    <tr>
                        <td>Fixed Deductions</td>
                        <td class="text-end text-danger"><?= number_format((float)$payroll['deductions'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ((float)$payroll['attendance_deduction'] > 0): ?>
                    <tr>
                        <td>Absences Penalty</td>
                        <td class="text-end text-danger"><?= number_format((float)$payroll['attendance_deduction'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php 
                        $totalDed = (float)$payroll['deductions'] + (float)$payroll['attendance_deduction'];
                    endif; 
                    ?>
                    
                    <?php if($totalDed == 0): ?>
                    <tr><td colspan="2" class="text-center text-muted fst-italic">No deductions incurred</td></tr>
                    <?php endif; ?>
                </tbody>
                <tfoot class="table-light fw-bold text-dark fs-6">
                    <tr><td class="text-end">Total Deductions</td><td class="text-end text-danger">-<?= number_format($totalDed, 2) ?></td></tr>
                </tfoot>
            </table>
        </div>
    </div>
    
    <div class="row mt-5 pt-4 border-top text-center text-muted">
        <div class="col-12">
            <p class="small mb-1"><i class="bi bi-shield-check me-1"></i> System generated confidential payroll document.</p>
            <p class="small mb-0">Financial deductions map automatically to approved HR and synchronized attendance ledgers.</p>
        </div>
    </div>

    <div class="mt-4 text-center position-relative" style="z-index: 1;">
        <button onclick="window.print()" class="btn btn-primary d-print-none btn-lg px-5 shadow">
            <i class="bi bi-printer me-2"></i> Print Payslip Document
        </button>
    </div>
</div>

<style>
@media print {
    body * {
        visibility: hidden;
    }
    .print-container, .print-container * {
        visibility: visible;
    }
    .print-container {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        box-shadow: none !important;
        background: transparent !important;
    }
    .d-print-none { 
        display: none !important; 
    }
}
</style>
