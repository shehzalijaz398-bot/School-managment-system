<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex align-items-center gap-2">
    <div class="bg-primary bg-opacity-10 text-primary p-2 rounded-3">
      <i data-lucide="user-cog"></i>
    </div>
    <h2 class="mb-0 h4 fw-bold text-dark">Edit Staff Profile</h2>
  </div>
  <a href="<?= e(url('hr/employees')) ?>" class="btn btn-outline-secondary d-flex align-items-center gap-2 rounded-pill shadow-sm">
    <i data-lucide="arrow-left" style="width:18px;"></i> Back to Directory
  </a>
</div>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="panel border-0 shadow-sm p-4 rounded-4">
      <form method="post" action="<?= e(url('hr/employees/'.$employee['id'])) ?>">
        <?= csrf_field() ?>
        
        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3 d-flex align-items-center gap-2"><i data-lucide="user" class="text-primary" style="width:18px;"></i> Personal Information</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">First Name <span class="text-danger">*</span></label>
            <input type="text" name="first_name" class="form-control" required value="<?= e($employee['first_name'] ?? old('first_name')) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Last Name <span class="text-danger">*</span></label>
            <input type="text" name="last_name" class="form-control" required value="<?= e($employee['last_name'] ?? old('last_name')) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Email Address</label>
            <input type="email" name="email" class="form-control" value="<?= e($employee['email'] ?? old('email')) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Phone Number</label>
            <input type="text" name="phone" class="form-control" value="<?= e($employee['phone'] ?? old('phone')) ?>">
          </div>
          <div class="col-md-12">
            <label class="form-label fw-semibold">Gender</label>
            <select name="gender" class="form-select">
              <option value="">Select Gender...</option>
              <option value="male" <?= $employee['gender'] === 'male' ? 'selected' : '' ?>>Male</option>
              <option value="female" <?= $employee['gender'] === 'female' ? 'selected' : '' ?>>Female</option>
              <option value="other" <?= $employee['gender'] === 'other' ? 'selected' : '' ?>>Other</option>
            </select>
          </div>
        </div>

        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3 d-flex align-items-center gap-2"><i data-lucide="briefcase" class="text-info" style="width:18px;"></i> Employment Details</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Department</label>
            <select name="department_id" class="form-select">
              <option value="">Select Department...</option>
              <?php foreach ($departments as $d): ?>
                <option value="<?= (int)$d['id'] ?>" <?= $employee['department_id'] == $d['id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Designation</label>
            <select name="designation_id" class="form-select">
              <option value="">Select Designation...</option>
              <?php foreach ($designations as $d): ?>
                <option value="<?= (int)$d['id'] ?>" <?= $employee['designation_id'] == $d['id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Joining Date</label>
            <input type="date" name="joining_date" class="form-control" value="<?= e($employee['joining_date']) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Employment Status</label>
            <select name="status" class="form-select">
              <option value="active" <?= $employee['status'] === 'active' ? 'selected' : '' ?>>Active</option>
              <option value="inactive" <?= $employee['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
              <option value="resigned" <?= $employee['status'] === 'resigned' ? 'selected' : '' ?>>Resigned</option>
              <option value="terminated" <?= $employee['status'] === 'terminated' ? 'selected' : '' ?>>Terminated</option>
              <option value="on_leave" <?= $employee['status'] === 'on_leave' ? 'selected' : '' ?>>On Leave</option>
            </select>
          </div>
        </div>

        <div class="text-end border-top pt-4">
          <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm d-flex align-items-center gap-2 ms-auto rounded-pill">
            <i data-lucide="save" style="width:18px;"></i> Save Changes
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
