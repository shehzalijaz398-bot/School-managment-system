<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('hr/dashboard') ?>" class="text-decoration-none text-muted small">&larr; HR Operations</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Performance</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-award text-warning me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Evaluate faculty pedagogical effectiveness, punctuality, compliance, teamwork, and developmental goals.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <!-- Filter by Staff -->
            <form method="GET" action="<?= url('hr/performance') ?>" class="d-flex align-items-center">
                <select name="employee_id" class="form-select form-select-sm shadow-sm" onchange="this.form.submit()">
                    <option value="">All Staff Reviews</option>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= $emp['id'] ?>" <?= ($selectedEmployee == $emp['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createReviewModal">
                <i class="bi bi-plus-lg me-1"></i> Conduct Staff Appraisal
            </button>
        </div>
    </div>

    <!-- Rating Summary Tiles -->
    <div class="row g-3 mb-4">
        <?php 
        $totalReviews = count($reviews);
        $avgScore = 0.0;
        $masteryCount = 0; // >= 4.5
        $growthCount = 0; // < 3.5
        if ($totalReviews > 0) {
            $sum = 0;
            foreach ($reviews as $r) {
                $rating = (float)$r['overall_rating'];
                $sum += $rating;
                if ($rating >= 4.5) $masteryCount++;
                if ($rating < 3.5) $growthCount++;
            }
            $avgScore = round($sum / $totalReviews, 2);
        }
        ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Average Rating</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= number_format($avgScore, 2) ?> <span class="fs-6 text-warning"><i class="bi bi-star-fill"></i></span>
                </div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Across <?= $totalReviews ?> evaluations</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">High Performers (&ge; 4.5★)</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $masteryCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Exemplary pedagogical &amp; operational standing</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-danger">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Target Intervention (&lt; 3.5★)</div>
                <div class="h3 fw-bold text-danger mt-1 mb-0"><?= $growthCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Requires professional coaching &amp; mentoring</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Appraisals</div>
                <div class="h3 fw-bold text-info mt-1 mb-0"><?= $totalReviews ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Documented faculty assessments</div>
            </div>
        </div>
    </div>

    <!-- Reviews Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">Staff Performance Evaluation Ledger</h6>
            <span class="badge bg-light border text-dark fw-semibold"><?= $totalReviews ?> Recorded</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($reviews)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-star text-muted fs-1 d-block mb-2"></i>
                    <h6 class="fw-bold text-dark">No Performance Appraisals Found</h6>
                    <p class="text-muted small mb-3">Begin faculty evaluations with structured pedagogical criteria and quantifiable star ratings.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#createReviewModal">
                        <i class="bi bi-plus-lg me-1"></i> Conduct First Appraisal
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Staff Member</th>
                                <th>Period &amp; Date</th>
                                <th>Overall Rating</th>
                                <th>Criteria Scores</th>
                                <th>Appraisal Highlights</th>
                                <th>Evaluator</th>
                                <th class="pe-4 text-end">Profile</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reviews as $r): ?>
                                <?php $overall = (float)$r['overall_rating']; ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($r['employee_name']) ?></div>
                                        <div class="text-muted small">
                                            <?= htmlspecialchars($r['employee_code']) ?> &middot; <?= htmlspecialchars($r['designation_name'] ?? 'Staff') ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($r['review_period']) ?></div>
                                        <div class="text-muted small"><?= date('M d, Y', strtotime($r['review_date'])) ?></div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-1">
                                            <span class="badge <?= ($overall >= 4.0) ? 'bg-success' : (($overall >= 3.0) ? 'bg-warning text-dark' : 'bg-danger') ?> fw-bold px-2 py-1">
                                                <?= number_format($overall, 2) ?> ★
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small" style="font-size: 11px;">
                                            <div>Pedagogy: <strong><?= number_format((float)$r['pedagogy_rating'], 1) ?></strong></div>
                                            <div>Punctuality: <strong><?= number_format((float)$r['punctuality_rating'], 1) ?></strong></div>
                                            <div>Compliance: <strong><?= number_format((float)$r['compliance_rating'], 1) ?></strong></div>
                                            <div>Teamwork: <strong><?= number_format((float)$r['teamwork_rating'], 1) ?></strong></div>
                                        </div>
                                    </td>
                                    <td style="max-width: 250px;">
                                        <?php if (!empty($r['strengths'])): ?>
                                            <div class="text-truncate text-success small">
                                                <strong>Strengths:</strong> <?= htmlspecialchars($r['strengths']) ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($r['growth_areas'])): ?>
                                            <div class="text-truncate text-muted small">
                                                <strong>Focus:</strong> <?= htmlspecialchars($r['growth_areas']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="text-muted small"><?= htmlspecialchars($r['reviewer_name'] ?? 'Administrator') ?></span>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <a href="<?= url('hr/employees/' . $r['employee_id'] . '?tab=reviews') ?>" class="btn btn-sm btn-light border text-dark">
                                            View &rarr;
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Conduct Performance Review Modal -->
<div class="modal fade" id="createReviewModal" tabindex="-1" aria-labelledby="createReviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/performance') ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="createReviewModalLabel">Conduct Faculty Performance Appraisal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-dark">Staff Member <span class="text-danger">*</span></label>
                            <select name="employee_id" class="form-select" required>
                                <option value="">-- Select Staff Member --</option>
                                <?php foreach ($employees as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" <?= ($selectedEmployee == $emp['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold text-dark">Evaluation Period <span class="text-danger">*</span></label>
                            <input type="text" name="review_period" class="form-control" value="Annual Review <?= date('Y') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold text-dark">Appraisal Date <span class="text-danger">*</span></label>
                            <input type="date" name="review_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <!-- 4 Scoring Sliders / Inputs (1.0 - 5.0) -->
                    <div class="p-3 bg-light rounded-4 mb-3 border">
                        <h6 class="fw-bold text-dark mb-3">Core Performance Dimensions (Scale: 1.0 to 5.0 ★)</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-dark d-flex justify-content-between">
                                    <span>Pedagogical Effectiveness &amp; Teaching</span>
                                    <span class="text-primary fw-bold" id="pedagogy_val">5.0</span>
                                </label>
                                <input type="range" name="pedagogy_rating" class="form-range" min="1.0" max="5.0" step="0.5" value="5.0" oninput="document.getElementById('pedagogy_val').textContent = this.value">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-dark d-flex justify-content-between">
                                    <span>Punctuality &amp; Attendance Adherence</span>
                                    <span class="text-primary fw-bold" id="punctuality_val">5.0</span>
                                </label>
                                <input type="range" name="punctuality_rating" class="form-range" min="1.0" max="5.0" step="0.5" value="5.0" oninput="document.getElementById('punctuality_val').textContent = this.value">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-dark d-flex justify-content-between">
                                    <span>Institutional Compliance &amp; Record-Keeping</span>
                                    <span class="text-primary fw-bold" id="compliance_val">5.0</span>
                                </label>
                                <input type="range" name="compliance_rating" class="form-range" min="1.0" max="5.0" step="0.5" value="5.0" oninput="document.getElementById('compliance_val').textContent = this.value">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-dark d-flex justify-content-between">
                                    <span>Teamwork, Collaboration &amp; Conduct</span>
                                    <span class="text-primary fw-bold" id="teamwork_val">5.0</span>
                                </label>
                                <input type="range" name="teamwork_rating" class="form-range" min="1.0" max="5.0" step="0.5" value="5.0" oninput="document.getElementById('teamwork_val').textContent = this.value">
                            </div>
                        </div>
                    </div>

                    <!-- Qualitative Notes -->
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-dark">Demonstrated Strengths</label>
                            <textarea name="strengths" rows="3" class="form-control" placeholder="Key strengths, classroom mastery, leadership contributions..."></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-dark">Target Growth Areas</label>
                            <textarea name="growth_areas" rows="3" class="form-control" placeholder="Areas recommended for professional development..."></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold text-dark">Target Developmental Goals (Upcoming Academic Year)</label>
                            <input type="text" name="goals" class="form-control" placeholder="e.g. Complete advanced educational pedagogy certification; integrate digital quizzes.">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save &amp; Finalize Appraisal</button>
                </div>
            </form>
        </div>
    </div>
</div>
