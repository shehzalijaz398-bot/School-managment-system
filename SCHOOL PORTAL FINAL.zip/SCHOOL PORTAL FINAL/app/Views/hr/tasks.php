<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('hr/dashboard') ?>" class="text-decoration-none text-muted small">&larr; HR Operations</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Tasks</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-check2-square text-danger me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Role-based delegation, operational deadlines, institutional task boards, and reminders.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createTaskModal">
                <i class="bi bi-plus-lg me-1"></i> Assign New Task
            </button>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card border-0 shadow-sm rounded-4 bg-white p-3 mb-4">
        <form method="GET" action="<?= url('hr/tasks') ?>" class="row g-2 align-items-center">
            <div class="col-md-4">
                <select name="employee_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Staff Assignees</option>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= $emp['id'] ?>" <?= (($filters['employee_id'] ?? '') == $emp['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Task Statuses</option>
                    <option value="pending" <?= (($filters['status'] ?? '') === 'pending') ? 'selected' : '' ?>>Pending Review</option>
                    <option value="in_progress" <?= (($filters['status'] ?? '') === 'in_progress') ? 'selected' : '' ?>>In Progress</option>
                    <option value="completed" <?= (($filters['status'] ?? '') === 'completed') ? 'selected' : '' ?>>Completed</option>
                    <option value="cancelled" <?= (($filters['status'] ?? '') === 'cancelled') ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="priority" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Priorities</option>
                    <option value="urgent" <?= (($filters['priority'] ?? '') === 'urgent') ? 'selected' : '' ?>>Urgent</option>
                    <option value="high" <?= (($filters['priority'] ?? '') === 'high') ? 'selected' : '' ?>>High Priority</option>
                    <option value="medium" <?= (($filters['priority'] ?? '') === 'medium') ? 'selected' : '' ?>>Medium Priority</option>
                    <option value="low" <?= (($filters['priority'] ?? '') === 'low') ? 'selected' : '' ?>>Low Priority</option>
                </select>
            </div>
            <div class="col-md-2">
                <a href="<?= url('hr/tasks') ?>" class="btn btn-outline-secondary btn-sm w-100">Reset Filters</a>
            </div>
        </form>
    </div>

    <!-- Task KPI Tiles -->
    <div class="row g-3 mb-4">
        <?php 
        $totalCount = count($tasks);
        $pendingCount = 0;
        $inProgressCount = 0;
        $completedCount = 0;
        $overdueCount = 0;
        $today = date('Y-m-d');
        foreach ($tasks as $t) {
            if ($t['status'] === 'pending') $pendingCount++;
            if ($t['status'] === 'in_progress') $inProgressCount++;
            if ($t['status'] === 'completed') $completedCount++;
            if ($t['status'] !== 'completed' && $t['due_date'] < $today) $overdueCount++;
        }
        ?>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Pending Work</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= $pendingCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Awaiting staff commencement</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">In Progress</div>
                <div class="h3 fw-bold text-primary mt-1 mb-0"><?= $inProgressCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Currently under execution</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-danger">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Overdue Deadlines</div>
                <div class="h3 fw-bold text-danger mt-1 mb-0"><?= $overdueCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Past target completion date</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Resolved &amp; Done</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $completedCount ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Completed assignments</div>
            </div>
        </div>
    </div>

    <!-- Task List Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">Staff Delegated Tasks Board</h6>
            <span class="badge bg-light border text-dark fw-semibold"><?= $totalCount ?> Tasks Found</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($tasks)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-clipboard-check text-muted fs-1 d-block mb-2"></i>
                    <h6 class="fw-bold text-dark">No Tasks Matching Filters</h6>
                    <p class="text-muted small mb-3">Delegate administrative responsibilities, syllabus reviews, or event preparations.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#createTaskModal">
                        <i class="bi bi-plus-lg me-1"></i> Assign New Task
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Task Title &amp; Description</th>
                                <th>Assigned Staff Member</th>
                                <th>Priority</th>
                                <th>Due Date &amp; Timeline</th>
                                <th>Status</th>
                                <th class="pe-4 text-end">Update Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tasks as $t): ?>
                                <?php 
                                $isTaskOverdue = ($t['status'] !== 'completed' && $t['due_date'] < $today);
                                ?>
                                <tr class="<?= ($t['status'] === 'completed') ? 'opacity-75 bg-light-subtle' : '' ?>">
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($t['title']) ?></div>
                                        <?php if (!empty($t['description'])): ?>
                                            <div class="text-muted small text-truncate" style="max-width: 280px;"><?= htmlspecialchars($t['description']) ?></div>
                                        <?php endif; ?>
                                        <div class="text-muted" style="font-size: 11px;">
                                            Assigned by: <?= htmlspecialchars($t['assigner_name'] ?? 'Admin') ?> &middot; <?= date('M d, Y', strtotime($t['created_at'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($t['assignee_name']) ?></div>
                                        <div class="text-muted small"><?= htmlspecialchars($t['employee_code']) ?> &middot; <?= htmlspecialchars($t['department_name'] ?? 'General') ?></div>
                                    </td>
                                    <td>
                                        <?php 
                                        $prioBadge = match($t['priority']) {
                                            'urgent' => 'bg-danger text-white',
                                            'high' => 'bg-danger-subtle text-danger border-danger-subtle',
                                            'medium' => 'bg-warning-subtle text-warning-emphasis border-warning-subtle',
                                            default => 'bg-secondary-subtle text-secondary border-secondary-subtle',
                                        };
                                        ?>
                                        <span class="badge border <?= $prioBadge ?> text-uppercase px-2 py-1" style="font-size: 10px;">
                                            <?= htmlspecialchars($t['priority']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-semibold <?= $isTaskOverdue ? 'text-danger' : 'text-dark' ?>">
                                            <i class="bi bi-calendar me-1"></i><?= date('M d, Y', strtotime($t['due_date'])) ?>
                                        </div>
                                        <?php if ($isTaskOverdue): ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle" style="font-size: 10px;">Overdue</span>
                                        <?php elseif ($t['status'] === 'completed' && !empty($t['completed_at'])): ?>
                                            <span class="text-success small" style="font-size: 11px;">Completed <?= date('M d', strtotime($t['completed_at'])) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $statusBadge = match($t['status']) {
                                            'completed' => 'bg-success-subtle text-success border-success-subtle',
                                            'in_progress' => 'bg-primary-subtle text-primary border-primary-subtle',
                                            'cancelled' => 'bg-secondary-subtle text-secondary border-secondary-subtle',
                                            default => 'bg-warning-subtle text-warning border-warning-subtle',
                                        };
                                        ?>
                                        <span class="badge border <?= $statusBadge ?> text-capitalize px-2 py-1">
                                            <?= str_replace('_', ' ', $t['status']) ?>
                                        </span>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <?php if ($t['status'] !== 'completed'): ?>
                                            <form method="POST" action="<?= url('hr/tasks/' . $t['id'] . '/status') ?>" class="d-inline">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="status" value="completed">
                                                <button type="submit" class="btn btn-sm btn-outline-success rounded-pill px-3 py-1 fw-semibold">
                                                    <i class="bi bi-check2 me-1"></i> Complete
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-success small fw-semibold"><i class="bi bi-check-circle-fill me-1"></i>Done</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Assign Task Modal -->
<div class="modal fade" id="createTaskModal" tabindex="-1" aria-labelledby="createTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/tasks') ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="createTaskModalLabel">Assign Task to Staff</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Staff Assignee <span class="text-danger">*</span></label>
                        <select name="assigned_to" class="form-select" required>
                            <option value="">-- Select Staff Assignee --</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= $emp['id'] ?>" <?= (($filters['employee_id'] ?? '') == $emp['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Task Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Prepare Term 2 Mathematics Exam Paper" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Target Deadline <span class="text-danger">*</span></label>
                            <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+3 days')) ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Priority Level <span class="text-danger">*</span></label>
                            <select name="priority" class="form-select" required>
                                <option value="low">Low Priority</option>
                                <option value="medium" selected>Medium Priority</option>
                                <option value="high">High Priority</option>
                                <option value="urgent">Urgent</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-0">
                        <label class="form-label small fw-semibold text-dark">Task Description &amp; Instructions</label>
                        <textarea name="description" rows="3" class="form-control" placeholder="Specific requirements, deliverables, or guidelines..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Dispatch Task</button>
                </div>
            </form>
        </div>
    </div>
</div>
