<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-calendar-alt text-primary me-2"></i> HR Leave Requests</h2>
        <p class="text-muted mb-0">Manage and review all staff leave applications.</p>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">Employee</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Leave Type</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Duration & Reason</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Status</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($leaves as $l): ?>
                <tr class="leave-row">
                    <td class="px-4 py-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 42px; height: 42px;">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-sm fw-bold"><?= e($l['employee_name']) ?></h6>
                            </div>
                        </div>
                    </td>
                    <td class="py-3 text-sm fw-medium">
                        <span class="badge bg-light text-dark border"><i class="fas fa-tag text-muted me-1"></i> <?= e($l['leave_type']) ?></span>
                    </td>
                    <td class="py-3">
                        <div class="text-sm fw-semibold text-gray-800 mb-1">
                            <i class="far fa-calendar-check text-success me-1"></i> <?= e(formatDate($l['start_date'])) ?> 
                            <i class="fas fa-arrow-right text-muted mx-1" style="font-size:0.75rem;"></i> 
                            <i class="far fa-calendar-times text-danger me-1"></i> <?= e(formatDate($l['end_date'])) ?>
                        </div>
                        <?php if(!empty($l['reason'])): ?>
                            <div class="text-xs text-muted fst-italic"><i class="fas fa-quote-left text-light me-1"></i> <?= e(substr($l['reason'], 0, 50)) ?><?= strlen($l['reason'])>50?'...':'' ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="py-3">
                        <?= statusBadge($l['status']) ?>
                    </td>
                    <td class="px-4 py-3 text-end">
                        <?php if ($l['status'] === 'pending'): ?>
                        <div class="d-flex gap-2 justify-content-end">
                            <form method="post" action="<?= e(url('leave/'.$l['id'].'/review')) ?>" class="m-0 p-0 d-flex gap-2">
                                <?= csrf_field() ?>
                                <!-- Important: We redirect back to hr/leaves because we are in HR view -->
                                <input type="hidden" name="redirect_to" value="hr/leaves">
                                <button type="submit" name="status" value="approved" class="btn btn-sm btn-success rounded-pill px-3 shadow-sm action-hover" title="Approve">
                                    <i class="fas fa-check me-1"></i> Approve
                                </button>
                                <button type="submit" name="status" value="rejected" class="btn btn-sm btn-danger rounded-pill px-3 shadow-sm action-hover" title="Reject">
                                    <i class="fas fa-times me-1"></i> Reject
                                </button>
                            </form>
                        </div>
                        <?php else: ?>
                            <span class="text-muted text-sm fst-italic"><i class="fas fa-info-circle"></i> Processed</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($leaves)): ?>
                <tr>
                    <td colspan="5" class="text-center py-5 text-muted">
                        <i class="far fa-calendar-check fa-3x mb-3 text-light"></i>
                        <p class="mb-0">No leave requests found.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    /* Premium Hover Effects */
    .leave-row {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        border-radius: 12px;
    }
    .leave-row:hover {
        background-color: #f8fafc !important;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px -10px rgba(0, 0, 0, 0.1);
        z-index: 10;
        position: relative;
    }
    .leave-row:hover .avatar {
        transform: scale(1.1) rotate(5deg);
        box-shadow: 0 4px 10px rgba(13, 110, 253, 0.3) !important;
    }
    
    .action-hover {
        transition: all 0.2s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        filter: brightness(1.1);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15) !important;
    }
    
    .table > :not(caption) > * > * {
        border-bottom-color: #f1f5f9;
    }
</style>
