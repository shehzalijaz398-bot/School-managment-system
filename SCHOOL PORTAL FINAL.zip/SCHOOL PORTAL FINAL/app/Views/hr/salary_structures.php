<?php
$layout = 'layouts/app';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-file-invoice-dollar text-primary me-2"></i> Employee Salary Structures</h2>
        <p class="text-muted mb-0">Configure base salaries, house and transport allowances, and monthly payroll deductions.</p>
    </div>
    <?php if (hasPermission('payroll.manage')): ?>
    <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm action-hover" data-bs-toggle="modal" data-bs-target="#addSalaryModal">
        <i class="fas fa-plus-circle"></i> Assign Salary Structure
    </button>
    <?php endif; ?>
</div>

<!-- Salary Structures Table -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 px-4 py-3">Employee</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3">Department / Role</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end">Basic Salary</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end">Allowances</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end">Deductions</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-end">Net Salary</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 py-3 text-center px-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (($structures ?? []) as $s): 
                    $totalAllowances = (float)$s['house_allowance'] + (float)$s['transport_allowance'] + (float)$s['other_allowance'];
                    $net = ((float)$s['basic_salary'] + $totalAllowances) - (float)$s['deductions'];
                ?>
                <tr>
                    <td class="px-4 py-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm bg-primary-subtle text-primary rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 38px; height: 38px;">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-sm fw-bold text-gray-800"><?= e($s['first_name'] . ' ' . $s['last_name']) ?></h6>
                                <span class="text-xs text-muted"><?= e($s['employee_code']) ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="py-3 text-sm">
                        <span class="badge bg-light text-dark border px-2 py-1 me-1"><?= e($s['department'] ?: 'General') ?></span>
                        <span class="text-xs text-muted"><?= e($s['designation'] ?: 'Staff') ?></span>
                    </td>
                    <td class="py-3 text-sm fw-semibold text-end">
                        <?= e(formatMoney($s['basic_salary'])) ?>
                    </td>
                    <td class="py-3 text-sm text-success text-end">
                        +<?= e(formatMoney($totalAllowances)) ?>
                    </td>
                    <td class="py-3 text-sm text-danger text-end">
                        -<?= e(formatMoney($s['deductions'])) ?>
                    </td>
                    <td class="py-3 text-sm fw-bold text-primary text-end">
                        <?= e(formatMoney($net)) ?>
                    </td>
                    <td class="py-3 text-center px-4">
                        <?php if (hasPermission('payroll.manage')): ?>
                        <div class="d-flex justify-content-center gap-1">
                            <button class="btn btn-sm btn-outline-secondary border-0 p-1 edit-salary-btn"
                                    data-employee-id="<?= e($s['employee_id']) ?>"
                                    data-basic="<?= e($s['basic_salary']) ?>"
                                    data-house="<?= e($s['house_allowance']) ?>"
                                    data-transport="<?= e($s['transport_allowance']) ?>"
                                    data-other="<?= e($s['other_allowance']) ?>"
                                    data-deductions="<?= e($s['deductions']) ?>"
                                    data-effective="<?= e($s['effective_from']) ?>"
                                    title="Edit Structure">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= url('hr/salary-structures/' . $s['id'] . '/delete') ?>" onsubmit="return confirm('Delete this salary structure?');" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger border-0 p-1" title="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                        <?php else: ?>
                        <span class="text-muted text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($structures)): ?>
                <tr>
                    <td colspan="7" class="text-center py-5 text-muted">
                        <i class="fas fa-file-invoice-dollar fa-3x mb-3 text-light"></i>
                        <p class="mb-0">No custom salary structures assigned yet. (Default standard structure active)</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Assign / Edit Salary Structure -->
<div class="modal fade" id="addSalaryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header border-bottom py-3 px-4 bg-light">
                <h5 class="modal-title fw-bold text-gray-800"><i class="fas fa-cog text-primary me-2"></i> Configure Salary Structure</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= url('hr/salary-structures') ?>" method="POST" id="salaryStructureForm">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-xs text-uppercase text-muted">Employee <span class="text-danger">*</span></label>
                        <select name="employee_id" id="modal_employee_id" class="form-select" required>
                            <option value="">Select Employee...</option>
                            <?php foreach (($employees ?? []) as $emp): ?>
                            <option value="<?= e($emp['id']) ?>"><?= e($emp['first_name'] . ' ' . $emp['last_name'] . ' (' . $emp['employee_code'] . ')') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Basic Salary <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="1" name="basic_salary" id="modal_basic" class="form-control" placeholder="30000.00" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">House Allowance</label>
                            <input type="number" step="0.01" min="0" name="house_allowance" id="modal_house" class="form-control" placeholder="0.00" value="0.00">
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Transport Allowance</label>
                            <input type="number" step="0.01" min="0" name="transport_allowance" id="modal_transport" class="form-control" placeholder="0.00" value="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Other Allowance</label>
                            <input type="number" step="0.01" min="0" name="other_allowance" id="modal_other" class="form-control" placeholder="0.00" value="0.00">
                        </div>
                    </div>
                    <div class="row g-3 mb-0">
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Standard Deductions</label>
                            <input type="number" step="0.01" min="0" name="deductions" id="modal_deductions" class="form-control" placeholder="0.00" value="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-xs text-uppercase text-muted">Effective Date</label>
                            <input type="date" name="effective_from" id="modal_effective" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4 bg-light">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4"><i class="fas fa-save me-1"></i> Save Structure</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const salaryModal = new bootstrap.Modal(document.getElementById('addSalaryModal'));
    
    document.querySelectorAll('.edit-salary-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('modal_employee_id').value = this.getAttribute('data-employee-id');
            document.getElementById('modal_basic').value = this.getAttribute('data-basic');
            document.getElementById('modal_house').value = this.getAttribute('data-house');
            document.getElementById('modal_transport').value = this.getAttribute('data-transport');
            document.getElementById('modal_other').value = this.getAttribute('data-other');
            document.getElementById('modal_deductions').value = this.getAttribute('data-deductions');
            document.getElementById('modal_effective').value = this.getAttribute('data-effective');
            salaryModal.show();
        });
    });
});
</script>
