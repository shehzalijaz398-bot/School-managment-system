<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('hr/dashboard') ?>" class="text-decoration-none text-muted small">&larr; HR Operations</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Shifts</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-clock-history text-primary me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Configure operational working shifts, grace periods, half-day thresholds, and staff assignments.</p>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#assignShiftModal">
                <i class="bi bi-person-check-fill me-1"></i> Assign Shift to Staff
            </button>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createShiftModal">
                <i class="bi bi-plus-lg me-1"></i> Add Shift Schedule
            </button>
        </div>
    </div>

    <!-- Shifts Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Active Shifts</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= count($shifts) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Configured across academic and support staff</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Staff With Assigned Shifts</div>
                <?php 
                $assignedCount = 0;
                foreach ($employees as $e) {
                    if (!empty($e['shift_id'])) $assignedCount++;
                }
                ?>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $assignedCount ?> / <?= count($employees) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    <?= (count($employees) - $assignedCount) ?> staff members pending assignment
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Default Campus Shift</div>
                <?php 
                $defaultShiftName = 'Not Set';
                foreach ($shifts as $s) {
                    if (!empty($s['is_default'])) {
                        $defaultShiftName = $s['name'] . ' (' . date('h:i A', strtotime($s['start_time'])) . ' - ' . date('h:i A', strtotime($s['end_time'])) . ')';
                        break;
                    }
                }
                ?>
                <div class="h6 fw-bold text-dark mt-1 mb-0 text-truncate"><?= htmlspecialchars($defaultShiftName) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Auto-applied to new staff appointments</div>
            </div>
        </div>
    </div>

    <!-- Shifts Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">Configured Shift Schedules</h6>
            <span class="badge bg-light border text-dark fw-semibold"><?= count($shifts) ?> Total Schedules</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($shifts)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-clock text-muted fs-1 d-block mb-2"></i>
                    <h6 class="fw-bold text-dark">No Shift Schedules Found</h6>
                    <p class="text-muted small mb-3">Create your institution's work timing schedules for morning, evening, or administrative staff.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#createShiftModal">
                        <i class="bi bi-plus-lg me-1"></i> Add First Shift
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Shift Name &amp; Code</th>
                                <th>Working Hours</th>
                                <th>Grace Period</th>
                                <th>Half-Day Threshold</th>
                                <th>Assigned Staff</th>
                                <th>Status</th>
                                <th class="pe-4 text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($shifts as $s): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="badge bg-primary-subtle text-primary fw-bold"><?= htmlspecialchars($s['code']) ?></span>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($s['name']) ?></div>
                                            <?php if (!empty($s['is_default'])): ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-2 py-0" style="font-size: 10px;">Default</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark">
                                            <i class="bi bi-sun text-warning me-1"></i><?= date('h:i A', strtotime($s['start_time'])) ?> &rarr; <?= date('h:i A', strtotime($s['end_time'])) ?>
                                        </div>
                                        <?php 
                                        $durationMinutes = (strtotime($s['end_time']) - strtotime($s['start_time'])) / 60;
                                        $durationHours = round($durationMinutes / 60, 1);
                                        ?>
                                        <div class="text-muted small" style="font-size: 11px;"><?= $durationHours ?> hours / day</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= (int)$s['late_grace_minutes'] ?> mins grace</span>
                                    </td>
                                    <td>
                                        <span class="text-muted small"><?= (int)$s['half_day_threshold_minutes'] ?> mins minimum</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-light border text-dark fw-bold px-2 py-1">
                                            <i class="bi bi-people me-1"></i><?= (int)($s['assigned_staff'] ?? 0) ?> staff
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($s['status'] === 'active'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <button type="button" class="btn btn-sm btn-light border text-dark edit-shift-btn" 
                                                data-id="<?= $s['id'] ?>"
                                                data-name="<?= htmlspecialchars($s['name']) ?>"
                                                data-code="<?= htmlspecialchars($s['code']) ?>"
                                                data-start="<?= $s['start_time'] ?>"
                                                data-end="<?= $s['end_time'] ?>"
                                                data-grace="<?= (int)$s['late_grace_minutes'] ?>"
                                                data-halfday="<?= (int)$s['half_day_threshold_minutes'] ?>"
                                                data-default="<?= !empty($s['is_default']) ? 1 : 0 ?>"
                                                data-bs-toggle="modal" data-bs-target="#createShiftModal">
                                            <i class="bi bi-pencil-square me-1"></i> Edit
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Create / Edit Shift Modal -->
<div class="modal fade" id="createShiftModal" tabindex="-1" aria-labelledby="createShiftModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/shifts') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="shift_id" value="">
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="createShiftModalLabel">Configure Shift Schedule</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold text-dark">Shift Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="shift_name" class="form-control" placeholder="e.g. Morning Faculty Shift" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold text-dark">Code <span class="text-danger">*</span></label>
                            <input type="text" name="code" id="shift_code" class="form-control text-uppercase" placeholder="MORN-1" required>
                        </div>

                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Start Time <span class="text-danger">*</span></label>
                            <input type="time" name="start_time" id="shift_start" class="form-control" value="08:00" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">End Time <span class="text-danger">*</span></label>
                            <input type="time" name="end_time" id="shift_end" class="form-control" value="15:00" required>
                        </div>

                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Late Grace (Minutes)</label>
                            <input type="number" name="late_grace_minutes" id="shift_grace" class="form-control" value="15" min="0" max="120">
                            <div class="text-muted" style="font-size: 11px;">Minutes past start before marked Late</div>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Half-Day Threshold (Mins)</label>
                            <input type="number" name="half_day_threshold_minutes" id="shift_halfday" class="form-control" value="240" min="60" max="600">
                            <div class="text-muted" style="font-size: 11px;">Minimum minutes for half-day credit</div>
                        </div>

                        <div class="col-12">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" name="is_default" value="1" id="shift_default">
                                <label class="form-check-label small fw-semibold text-dark" for="shift_default">
                                    Set as Default Institutional Shift
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Schedule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Assign Shift Modal -->
<div class="modal fade" id="assignShiftModal" tabindex="-1" aria-labelledby="assignShiftModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/shifts/assign') ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="assignShiftModalLabel">Assign Shift to Staff Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Staff Member <span class="text-danger">*</span></label>
                        <select name="employee_id" class="form-select" required>
                            <option value="">-- Select Staff Member --</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= $emp['id'] ?>">
                                    <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                                    <?= !empty($emp['shift_id']) ? ' [Has Shift]' : ' [Unassigned]' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Target Shift Schedule <span class="text-danger">*</span></label>
                        <select name="shift_id" class="form-select" required>
                            <option value="">-- Select Shift Schedule --</option>
                            <?php foreach ($shifts as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= htmlspecialchars($s['name']) ?> (<?= date('h:i A', strtotime($s['start_time'])) ?> - <?= date('h:i A', strtotime($s['end_time'])) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Assign Shift</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editBtns = document.querySelectorAll('.edit-shift-btn');
    editBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            document.getElementById('shift_id').value = this.dataset.id;
            document.getElementById('shift_name').value = this.dataset.name;
            document.getElementById('shift_code').value = this.dataset.code;
            document.getElementById('shift_start').value = this.dataset.start;
            document.getElementById('shift_end').value = this.dataset.end;
            document.getElementById('shift_grace').value = this.dataset.grace;
            document.getElementById('shift_halfday').value = this.dataset.halfday;
            document.getElementById('shift_default').checked = (this.dataset.default === '1');
            document.getElementById('createShiftModalLabel').textContent = 'Edit Shift Schedule';
        });
    });

    const createModal = document.getElementById('createShiftModal');
    createModal.addEventListener('hidden.bs.modal', function () {
        document.getElementById('shift_id').value = '';
        document.getElementById('shift_name').value = '';
        document.getElementById('shift_code').value = '';
        document.getElementById('shift_start').value = '08:00';
        document.getElementById('shift_end').value = '15:00';
        document.getElementById('shift_grace').value = '15';
        document.getElementById('shift_halfday').value = '240';
        document.getElementById('shift_default').checked = false;
        document.getElementById('createShiftModalLabel').textContent = 'Configure Shift Schedule';
    });
});
</script>
