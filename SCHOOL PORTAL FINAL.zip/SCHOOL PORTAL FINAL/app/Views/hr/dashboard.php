<?php
$headcount = $metrics['headcount'] ?? [];
$att = $metrics['attendance_today'] ?? [];
$attRate = $metrics['attendance_rate'] ?? 0;
$leaveMet = $metrics['leave_metrics'] ?? [];
$payMet = $metrics['payroll_metrics'] ?? [];
$taskMet = $metrics['task_metrics'] ?? [];
$perfMet = $metrics['perf_metrics'] ?? [];
$depts = $metrics['departments'] ?? [];
$pendingLeaves = $metrics['pending_leaves'] ?? [];
$holidays = $metrics['upcoming_holidays'] ?? [];
$selectedMonth = $metrics['selected_month'] ?? date('Y-m');
?>

<div class="container-fluid py-4">
    <!-- Executive Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h1 class="h3 mb-1 text-gray-800 fw-bold">
                <i class="bi bi-people-fill text-primary me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Centralized workforce analytics, attendance trends, leave standing, and operational workflows.</p>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <!-- Filter by Month -->
            <form method="GET" action="<?= url('hr/dashboard') ?>" class="d-flex align-items-center gap-2">
                <input type="month" name="month" class="form-control form-control-sm shadow-sm" value="<?= htmlspecialchars($selectedMonth) ?>" onchange="this.form.submit()">
                <?php if (!empty($filters['department_id'])): ?>
                    <input type="hidden" name="department_id" value="<?= (int)$filters['department_id'] ?>">
                <?php endif; ?>
            </form>
            <a href="<?= url('hr/tasks') ?>" class="btn btn-outline-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-list-check me-1"></i> Staff Tasks
            </a>
            <a href="<?= url('hr/employees/create') ?>" class="btn btn-primary btn-sm shadow-sm fw-semibold">
                <i class="bi bi-person-plus-fill me-1"></i> Onboard Staff
            </a>
        </div>
    </div>

    <!-- KPI Matrix (6 Operational Cards) -->
    <div class="row g-3 mb-4">
        <!-- 1. Staff Headcount -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Staff</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= (int)($headcount['total_staff'] ?? 0) ?></div>
                <div class="text-success small mt-1" style="font-size: 11px;">
                    <i class="bi bi-check-circle-fill"></i> <?= (int)($headcount['active_staff'] ?? 0) ?> Active
                    <?php if ((int)($headcount['on_leave_staff'] ?? 0) > 0): ?>
                        &middot; <span class="text-warning"><?= (int)$headcount['on_leave_staff'] ?> on leave</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- 2. Today's Attendance -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Today's Attendance</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $attRate ?>%</div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    <?= (int)($att['present_count'] ?? 0) ?> Present &middot; <?= (int)($att['late_count'] ?? 0) ?> Late
                </div>
            </div>
        </div>

        <!-- 3. Leave Approvals -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Pending Leaves</div>
                <div class="h3 fw-bold text-warning mt-1 mb-0"><?= (int)($leaveMet['pending_approvals'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    <?= (int)($leaveMet['approved_this_month'] ?? 0) ?> Approved this month
                </div>
            </div>
        </div>

        <!-- 4. Payroll Standing -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Monthly Payroll</div>
                <div class="h4 fw-bold text-dark mt-1 mb-0 text-truncate"><?= formatMoney((float)($payMet['total_disbursed'] ?? 0)) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    Pending: <?= formatMoney((float)($payMet['total_pending_payout'] ?? 0)) ?>
                </div>
            </div>
        </div>

        <!-- 5. Delegated Tasks -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-danger h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Staff Tasks</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= (int)($taskMet['pending_tasks'] ?? 0) ?></div>
                <div class="small mt-1 <?= ((int)($taskMet['overdue_tasks'] ?? 0) > 0) ? 'text-danger fw-semibold' : 'text-muted' ?>" style="font-size: 11px;">
                    <?= (int)($taskMet['overdue_tasks'] ?? 0) ?> Overdue Deadlines
                </div>
            </div>
        </div>

        <!-- 6. Faculty Performance -->
        <div class="col-6 col-lg-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-secondary h-100">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Performance Rating</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= number_format((float)($perfMet['avg_faculty_rating'] ?? 5.0), 1) ?> <span class="fs-6 text-warning"><i class="bi bi-star-fill"></i></span>
                </div>
                <div class="text-muted small mt-1" style="font-size: 11px;">
                    <?= (int)($perfMet['total_reviews'] ?? 0) ?> Reviews on record
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Left Column: Pending Leaves & Department Breakdown -->
        <div class="col-lg-8">
            <!-- Pending Leave Requests Panel -->
            <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white">
                <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-dark">
                        <i class="bi bi-calendar-check text-warning me-2"></i>Pending Staff Leave Approvals
                    </h6>
                    <a href="<?= url('leave') ?>" class="btn btn-sm btn-link text-decoration-none text-primary fw-semibold p-0">View All Leaves &rarr;</a>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($pendingLeaves)): ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-check2-circle text-success fs-1 d-block mb-1"></i>
                            <div class="fw-semibold text-dark">All Staff Leaves Reviewed</div>
                            <p class="small text-muted mb-0">No pending leave applications requiring approval.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Employee</th>
                                        <th>Department</th>
                                        <th>Leave Type</th>
                                        <th>Dates &amp; Duration</th>
                                        <th>Reason</th>
                                        <th class="pe-4 text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendingLeaves as $pl): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($pl['staff_name']) ?></div>
                                                <div class="text-muted small"><?= htmlspecialchars($pl['employee_code'] ?? '') ?></div>
                                            </td>
                                            <td><?= htmlspecialchars($pl['department_name'] ?? 'General') ?></td>
                                            <td>
                                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($pl['leave_type_name'] ?? 'Leave') ?></span>
                                            </td>
                                            <td>
                                                <div class="fw-semibold"><?= (float)$pl['days'] ?> day(s)</div>
                                                <div class="text-muted small"><?= date('M d', strtotime($pl['start_date'])) ?> &rarr; <?= date('M d', strtotime($pl['end_date'])) ?></div>
                                            </td>
                                            <td style="max-width: 220px;" class="text-truncate text-muted small">
                                                <?= htmlspecialchars($pl['reason'] ?: 'Personal reason') ?>
                                            </td>
                                            <td class="pe-4 text-end">
                                                <a href="<?= url('leave') ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1 fw-semibold">
                                                    Review
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Departmental Headcount Distribution -->
            <div class="card border-0 shadow-sm rounded-4 bg-white">
                <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-dark">
                        <i class="bi bi-diagram-3-fill text-primary me-2"></i>Departmental Faculty Distribution
                    </h6>
                    <span class="badge bg-primary-subtle text-primary fw-semibold px-3 py-1"><?= count($depts) ?> Departments Active</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Department Unit</th>
                                    <th>Staff Headcount</th>
                                    <th>Share of Total</th>
                                    <th class="pe-4 text-end">Roster</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $totalStaffActive = max(1, (int)($headcount['active_staff'] ?? 0));
                                foreach ($depts as $d): 
                                    $cnt = (int)$d['staff_count'];
                                    $pct = round(($cnt / $totalStaffActive) * 100, 1);
                                ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($d['name']) ?></td>
                                        <td>
                                            <span class="badge bg-light border text-dark fw-bold px-2 py-1"><?= $cnt ?> staff</span>
                                        </td>
                                        <td style="width: 250px;">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="progress flex-grow-1" style="height: 6px;">
                                                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $pct ?>%;"></div>
                                                </div>
                                                <span class="small text-muted fw-semibold" style="width: 45px;"><?= $pct ?>%</span>
                                            </div>
                                        </td>
                                        <td class="pe-4 text-end">
                                            <a href="<?= url('staff?department_id=' . $d['id']) ?>" class="btn btn-sm btn-light border text-dark">
                                                View Staff &rarr;
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Quick Workflows & Institutional Calendar -->
        <div class="col-lg-4">
            <!-- Operations Quick Action Console -->
            <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white">
                <div class="card-header bg-dark text-white rounded-top-4 py-3 px-4">
                    <h6 class="fw-bold mb-0"><i class="bi bi-lightning-charge-fill me-2"></i>HR &amp; Staff Operations Hub</h6>
                </div>
                <div class="card-body p-3">
                    <div class="list-group list-group-flush rounded-3">
                        <a href="<?= url('hr/shifts') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 mb-1 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-primary-subtle text-primary p-2">
                                    <i class="bi bi-clock-history fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Staff Shifts &amp; Work Timings</div>
                                    <div class="text-muted" style="font-size: 11px;">Configure arrival windows &amp; grace periods</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>

                        <a href="<?= url('hr/holidays') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 mb-1 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-success-subtle text-success p-2">
                                    <i class="bi bi-calendar-event fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Holiday Calendars &amp; Breaks</div>
                                    <div class="text-muted" style="font-size: 11px;">Institutional &amp; national calendar dates</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>

                        <a href="<?= url('hr/performance') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 mb-1 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-warning-subtle text-warning p-2">
                                    <i class="bi bi-award fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Performance Appraisals</div>
                                    <div class="text-muted" style="font-size: 11px;">Pedagogy, punctuality, &amp; star ratings</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>

                        <a href="<?= url('hr/trainings') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 mb-1 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-info-subtle text-info p-2">
                                    <i class="bi bi-mortarboard fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Professional Development</div>
                                    <div class="text-muted" style="font-size: 11px;">Workshops, hours, &amp; certifications</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>

                        <a href="<?= url('hr/tasks') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 mb-1 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-danger-subtle text-danger p-2">
                                    <i class="bi bi-check2-square fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Role-Based Tasks</div>
                                    <div class="text-muted" style="font-size: 11px;">Assign, track deadlines &amp; reminders</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>

                        <a href="<?= url('finance/payroll') ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center p-3 border-0 rounded-2 hover-light">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-secondary-subtle text-secondary p-2">
                                    <i class="bi bi-cash-stack fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark small">Payroll &amp; Salary Structures</div>
                                    <div class="text-muted" style="font-size: 11px;">Disbursement, payslips, &amp; deductions</div>
                                </div>
                            </div>
                            <i class="bi bi-chevron-right text-muted"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Upcoming Holidays Widget -->
            <div class="card border-0 shadow-sm rounded-4 bg-white">
                <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0 text-dark">
                        <i class="bi bi-calendar-heart text-danger me-2"></i>Upcoming School Holidays
                    </h6>
                    <a href="<?= url('hr/holidays') ?>" class="small text-primary text-decoration-none fw-semibold">View All</a>
                </div>
                <div class="card-body p-4">
                    <?php if (empty($holidays)): ?>
                        <div class="text-center py-3 text-muted small">
                            No upcoming holidays scheduled in the calendar.
                        </div>
                    <?php else: ?>
                        <ul class="list-unstyled mb-0">
                            <?php foreach ($holidays as $h): ?>
                                <li class="mb-3 pb-2 border-bottom last-border-0">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div class="fw-bold text-dark small"><?= htmlspecialchars($h['name']) ?></div>
                                        <span class="badge bg-light text-dark border small text-uppercase" style="font-size: 10px;"><?= htmlspecialchars($h['type']) ?></span>
                                    </div>
                                    <div class="text-muted small mt-1" style="font-size: 12px;">
                                        <i class="bi bi-clock me-1"></i>
                                        <?= date('M d, Y', strtotime($h['start_date'])) ?>
                                        <?php if ($h['start_date'] !== $h['end_date']): ?>
                                            &rarr; <?= date('M d, Y', strtotime($h['end_date'])) ?>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .hover-light:hover {
        background-color: #f8fafc !important;
    }
    .last-border-0:last-child {
        border-bottom: 0 !important;
        margin-bottom: 0 !important;
        padding-bottom: 0 !important;
    }
</style>
