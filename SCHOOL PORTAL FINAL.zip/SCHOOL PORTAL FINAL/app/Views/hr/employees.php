<?php
/**
 * Staff Directory View - CodeClove School Management Pro UI Match
 */
?>

<!-- Breadcrumbs & Header -->
<div class="mb-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item text-muted">Staff &amp; HR</li>
      <li class="breadcrumb-item active text-secondary" aria-current="page">Staff Directory</li>
    </ol>
  </nav>
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Staff Directory</h1>
      <p class="text-muted small mb-0">Manage faculty details, departments, and roles in one dashboard.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
      <!-- Export CSV Button -->
      <a href="<?= e(url('staff/export-csv')) ?>" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;" title="Export Staff Directory to CSV">
        <i data-lucide="download" style="width: 15px; height: 15px;"></i>
        <span>Export CSV</span>
      </a>

      <!-- Bulk Import Trigger -->
      <?php if (hasPermission('employees.manage')): ?>
        <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 fw-medium shadow-2xs" data-bs-toggle="modal" data-bs-target="#bulkImportStaffModal" style="border-radius: 8px; border-color: #cbd5e1; height: 38px;">
          <i data-lucide="file-up" style="width: 15px; height: 15px;"></i>
          <span>Bulk Import</span>
        </button>
      <?php endif; ?>

      <!-- Add Staff Trigger -->
      <?php if (hasPermission('employees.manage')): ?>
        <a href="<?= e(url('staff/create')) ?>" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold shadow-sm text-white text-decoration-none" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5; height: 38px; line-height: 24px;">
          <i data-lucide="plus" style="width: 16px; height: 16px;"></i>
          <span>Add Staff</span>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$newCreds = $_SESSION['new_staff_credentials'] ?? null;
unset($_SESSION['new_staff_credentials']);
?>

<?php if ($newCreds): ?>
  <!-- Staff Login Credentials Popup Modal -->
  <div class="modal fade" id="staffCredentialsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-2xl" style="border-radius: 16px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25);">
        <!-- Header -->
        <div class="p-4 text-white text-center position-relative" style="background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%);">
          <div class="d-inline-flex align-items-center justify-content-center rounded-circle mb-3 bg-white bg-opacity-20 shadow-sm" style="width: 52px; height: 52px;">
            <i data-lucide="key-round" style="width: 26px; height: 26px; color: #ffffff;"></i>
          </div>
          <h4 class="fw-bold mb-1 text-white" style="font-size: 19px; letter-spacing: -0.01em;">
            <?= !empty($newCreds['is_reset']) ? '🔑 Login Credentials Updated!' : '🎉 Staff Account Created Successfully!' ?>
          </h4>
          <p class="mb-0 text-white-50 small" style="font-size: 13px;">
            <?= !empty($newCreds['is_accountant']) ? 'Accountant login credentials are ready for dashboard access.' : 'Staff login credentials generated successfully.' ?>
          </p>
          <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <!-- Body -->
        <div class="modal-body p-4 bg-light">
          <!-- Staff Info Card -->
          <div class="d-flex align-items-center justify-content-between p-3 bg-white rounded-3 border mb-3 shadow-2xs">
            <div>
              <div class="fw-bold text-dark fs-6"><?= e($newCreds['name']) ?></div>
              <div class="text-muted small"><?= e($newCreds['employee_code']) ?> &bull; <?= e($newCreds['school_name']) ?></div>
            </div>
            <div>
              <span class="badge rounded-pill px-3 py-1.5 fw-semibold" style="background: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; font-size: 12px;">
                <?= e($newCreds['role_name']) ?>
              </span>
            </div>
          </div>

          <!-- Credentials Detail Box -->
          <div class="bg-white rounded-3 border p-3 shadow-2xs mb-3">
            <!-- School Code -->
            <?php if (!empty($newCreds['school_code'])): ?>
              <div class="d-flex align-items-center justify-content-between py-2 border-bottom">
                <span class="text-secondary small fw-medium">School Code</span>
                <div class="d-flex align-items-center gap-2">
                  <code class="fw-bold text-dark px-2 py-0.5 rounded bg-light" style="font-size: 13px;" id="credSchoolCode"><?= e($newCreds['school_code']) ?></code>
                  <button type="button" class="btn btn-sm btn-link text-muted p-0" onclick="copyCredText('<?= e($newCreds['school_code']) ?>', 'School Code')" title="Copy School Code">
                    <i data-lucide="copy" style="width: 14px; height: 14px;"></i>
                  </button>
                </div>
              </div>
            <?php endif; ?>

            <!-- Login Email -->
            <div class="d-flex align-items-center justify-content-between py-2 border-bottom">
              <span class="text-secondary small fw-medium">Login Email (Username)</span>
              <div class="d-flex align-items-center gap-2">
                <span class="fw-bold text-dark font-monospace" style="font-size: 13px;" id="credEmail"><?= e($newCreds['email']) ?></span>
                <button type="button" class="btn btn-sm btn-link text-muted p-0" onclick="copyCredText('<?= e($newCreds['email']) ?>', 'Email')" title="Copy Email">
                  <i data-lucide="copy" style="width: 14px; height: 14px;"></i>
                </button>
              </div>
            </div>

            <!-- Password -->
            <div class="d-flex align-items-center justify-content-between py-2 border-bottom">
              <span class="text-secondary small fw-medium">Login Password</span>
              <div class="d-flex align-items-center gap-2">
                <span class="badge bg-warning-subtle text-dark border px-2 py-1 fw-bold font-monospace" style="font-size: 14px;" id="credPassword"><?= e($newCreds['password']) ?></span>
                <button type="button" class="btn btn-sm btn-link text-muted p-0" onclick="copyCredText('<?= e($newCreds['password']) ?>', 'Password')" title="Copy Password">
                  <i data-lucide="copy" style="width: 14px; height: 14px;"></i>
                </button>
              </div>
            </div>

            <!-- Login URL -->
            <div class="d-flex align-items-center justify-content-between pt-2">
              <span class="text-secondary small fw-medium">Login Portal URL</span>
              <div class="d-flex align-items-center gap-2">
                <a href="<?= e($newCreds['login_url']) ?>" target="_blank" class="small text-primary text-decoration-none fw-medium text-truncate" style="max-width: 180px;">
                  <?= e($newCreds['login_url']) ?>
                </a>
                <button type="button" class="btn btn-sm btn-link text-muted p-0" onclick="copyCredText('<?= e($newCreds['login_url']) ?>', 'Login URL')" title="Copy Link">
                  <i data-lucide="copy" style="width: 14px; height: 14px;"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Quick Notice -->
          <div class="p-2.5 rounded-3 small d-flex align-items-start gap-2 mb-3" style="background:#eff6ff; color:#1e40af; font-size:12px; border: 1px solid #dbeafe;">
            <i data-lucide="info" style="width: 16px; height: 16px; flex-shrink: 0; margin-top: 1px;"></i>
            <span>Provide these credentials to the staff member. They will be directed straight to the <?= !empty($newCreds['is_accountant']) ? '<strong>Accountant Cockpit &amp; Finance Dashboard</strong>' : 'Dashboard' ?> upon signing in.</span>
          </div>

          <!-- 1-Click Copy All Template -->
          <button type="button" class="btn btn-primary w-100 py-2.5 d-flex align-items-center justify-content-center gap-2 fw-semibold shadow-sm mb-2" onclick="copyFullCredTemplate()" style="border-radius: 10px; background-color: #4f46e5; border-color: #4f46e5;">
            <i data-lucide="copy" style="width: 16px; height: 16px;"></i>
            <span id="copyFullBtnText">Copy Complete Credentials to Clipboard</span>
          </button>
          
          <a href="<?= e($newCreds['login_url']) ?>" target="_blank" class="btn btn-outline-secondary w-100 py-2 d-flex align-items-center justify-content-center gap-2 fw-medium" style="border-radius: 10px; font-size: 13px;">
            <i data-lucide="external-link" style="width: 14px; height: 14px;"></i>
            <span>Open Login Page in New Tab</span>
          </a>
        </div>

        <div class="modal-footer border-top px-4 py-2.5 bg-white justify-content-end">
          <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal" style="border-radius: 8px;">Dismiss</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Persistent Banner Above Table -->
  <div class="alert alert-success border-0 shadow-sm rounded-3 p-3 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-2" style="background: #f0fdf4; border: 1px solid #bbf7d0 !important;">
    <div class="d-flex align-items-center gap-2">
      <i data-lucide="check-circle-2" style="width: 20px; height: 20px; color: #16a34a;"></i>
      <div>
        <span class="fw-bold text-dark" style="font-size: 13.5px;">Login Credentials Active for <?= e($newCreds['name']) ?> (<?= e($newCreds['role_name']) ?>):</span>
        <span class="text-secondary small ms-1">Email: <strong><?= e($newCreds['email']) ?></strong> &bull; Password: <strong class="font-monospace text-dark bg-white px-2 py-0.5 rounded border"><?= e($newCreds['password']) ?></strong></span>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <button type="button" class="btn btn-sm btn-primary py-1 px-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#staffCredentialsModal" style="border-radius: 6px; font-size: 12px; background:#4f46e5; border-color:#4f46e5;">
        <i data-lucide="key" style="width: 13px; height: 13px;"></i> View Full Credentials
      </button>
    </div>
  </div>
<?php endif; ?>

<!-- 3-Filter Interactive Control Bar (Exact Screenshot Layout) -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-3">
    <form method="get" action="<?= e(url('staff')) ?>" id="staffFilterForm" class="row g-3 align-items-center m-0">
      <input type="hidden" name="limit" value="<?= (int)($limit ?? 10) ?>">
      <input type="hidden" name="sort" value="<?= e($sort ?? 'name') ?>">
      <input type="hidden" name="dir" value="<?= e($dir ?? 'asc') ?>">

      <!-- Filter 1: Search by name, email, designation.. -->
      <div class="col-12 col-md-6">
        <div class="position-relative">
          <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
          <input type="text" name="q" id="searchStaffInput" value="<?= e($filters['q'] ?? '') ?>" class="form-control form-control-sm ps-5" placeholder="Search by name, email, designation.." style="height: 40px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;">
          <?php if (!empty($filters['q'])): ?>
            <a href="<?= e(url('staff')) ?>" class="position-absolute text-muted" style="right: 12px; top: 11px;" title="Clear search">
              <i data-lucide="x" style="width: 15px; height: 15px;"></i>
            </a>
          <?php endif; ?>
        </div>
      </div>

      <!-- Filter 2: All Statuses -->
      <div class="col-12 col-sm-6 col-md-3">
        <select name="status" class="form-select form-select-sm" style="height: 40px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="">All Statuses</option>
          <option value="active" <?= (($filters['status'] ?? '') === 'active') ? 'selected' : '' ?>>Active</option>
          <option value="inactive" <?= (($filters['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
          <option value="suspended" <?= (($filters['status'] ?? '') === 'suspended') ? 'selected' : '' ?>>Suspended</option>
          <option value="terminated" <?= (($filters['status'] ?? '') === 'terminated') ? 'selected' : '' ?>>Terminated</option>
          <option value="on_leave" <?= (($filters['status'] ?? '') === 'on_leave') ? 'selected' : '' ?>>On Leave</option>
        </select>
      </div>

      <!-- Filter 3: All System Roles -->
      <div class="col-12 col-sm-6 col-md-3">
        <select name="role" class="form-select form-select-sm" style="height: 40px; border-radius: 8px; border-color: #e2e8f0; font-size: 13px;" onchange="this.form.submit()">
          <option value="">All System Roles</option>
          <?php foreach ($roles as $r): ?>
            <option value="<?= e($r['slug']) ?>" <?= (($filters['role'] ?? '') === $r['slug'] || ($filters['role'] ?? '') === $r['name']) ? 'selected' : '' ?>>
              <?= e($r['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </form>
  </div>
</div>

<!-- Bulk Action Floating Bar -->
<form method="post" action="<?= e(url('staff/bulk-action')) ?>" id="bulkStaffForm">
  <?= csrf_field() ?>
  <div id="bulkActionBar" class="card border-0 shadow-sm mb-3 d-none" style="border-radius: 10px; background: #f8fafc; border: 1px solid #cbd5e1 !important;">
    <div class="card-body p-2 px-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary rounded-pill px-2 py-1" id="selectedCountBadge" style="background-color: #4f46e5 !important;">0</span>
        <span class="small fw-semibold text-dark">staff member(s) selected</span>
      </div>
      <div class="d-flex align-items-center gap-2">
        <select name="bulk_status" class="form-select form-select-sm" style="width: 140px; height: 32px; border-radius: 6px; font-size: 12px;">
          <option value="active">Set Active</option>
          <option value="inactive">Set Inactive</option>
          <option value="suspended">Set Suspended</option>
          <option value="on_leave">Set On Leave</option>
        </select>
        <button type="submit" name="action" value="status" class="btn btn-sm btn-outline-secondary fw-medium" style="height: 32px; border-radius: 6px; font-size: 12px;">
          Apply Status
        </button>
        <button type="submit" name="action" value="deactivate" class="btn btn-sm btn-outline-danger fw-medium d-inline-flex align-items-center gap-1" style="height: 32px; border-radius: 6px; font-size: 12px;" onclick="return confirm('Are you sure you want to deactivate selected staff members?')">
          <i data-lucide="user-x" style="width: 13px; height: 13px;"></i>
          <span>Deactivate</span>
        </button>
        <button type="button" class="btn btn-sm btn-link text-muted p-0 ms-2" onclick="clearSelectedRows()" title="Cancel Selection">
          <i data-lucide="x" style="width: 16px; height: 16px;"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- Staff Table Card -->
  <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; overflow: hidden;">
    <?php if (empty($employees)): ?>
      <div class="text-center py-5 my-3">
        <div class="d-inline-flex align-items-center justify-content-center rounded-circle mb-3" style="width: 56px; height: 56px; background: #f8fafc; border: 1px solid #e2e8f0;">
          <i data-lucide="users" style="width: 26px; height: 26px; color: #94a3b8;"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1" style="font-size: 16px;">No Staff Members Found</h5>
        <p class="text-muted small mb-3">Add a new staff record or adjust filter parameters.</p>
        <?php if (hasPermission('employees.manage')): ?>
          <button type="button" class="btn btn-sm btn-primary px-3 py-2 fw-semibold" data-bs-toggle="modal" data-bs-target="#addStaffModal" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
            <span>Add Staff</span>
          </button>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle mb-0" id="staffDirectoryTable">
          <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
            <tr style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">
              <!-- Select All Checkbox -->
              <th class="ps-3 py-3" style="width: 40px;">
                <div class="form-check m-0">
                  <input class="form-check-input" type="checkbox" id="selectAllCheckbox" style="border-color: #cbd5e1; cursor: pointer;" onchange="toggleSelectAll(this)">
                </div>
              </th>

              <!-- Column: STAFF -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('name')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>STAFF</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: DESIGNATION & DEPT -->
              <th class="py-3 fw-bold">DESIGNATION &amp; DEPT</th>

              <!-- Column: CONTACT DETAILS -->
              <th class="py-3 fw-bold">CONTACT DETAILS</th>

              <!-- Column: SYSTEM ROLE -->
              <th class="py-3 fw-bold">SYSTEM ROLE</th>

              <!-- Column: JOINED ON -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('joined_on')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>JOINED ON</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: STATUS -->
              <th class="py-3 fw-bold" style="cursor: pointer;" onclick="sortBy('status')">
                <div class="d-inline-flex align-items-center gap-1">
                  <span>STATUS</span>
                  <i data-lucide="chevrons-up-down" style="width: 13px; height: 13px; color: #94a3b8;"></i>
                </div>
              </th>

              <!-- Column: ACTIONS -->
              <th class="pe-3 py-3 fw-bold text-end" style="width: 120px;">ACTIONS</th>
            </tr>
          </thead>
          <tbody style="font-size: 13px;">
            <?php foreach ($employees as $emp): ?>
              <?php
                $fullName = trim($emp['first_name'] . ' ' . $emp['last_name']);
                $initial = strtoupper(substr($emp['first_name'] ?: 'S', 0, 1));
                
                // Avatar background colors based on name hash
                $avatarGradients = [
                    'linear-gradient(135deg, #f43f5e 0%, #e11d48 100%)',
                    'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)',
                    'linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%)',
                    'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                    'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                    'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
                ];
                $gradIdx = abs(crc32($fullName)) % count($avatarGradients);
                $avatarBg = $avatarGradients[$gradIdx];

                // Role badge styling
                $roleName = $emp['role_name'] ?: 'Staff';
                $roleLower = strtolower($roleName);
                if (str_contains($roleLower, 'owner') || str_contains($roleLower, 'principal')) {
                    $roleStyle = 'background: #eff6ff; color: #4f46e5; border: 1px solid #dbeafe;';
                } elseif (str_contains($roleLower, 'admin')) {
                    $roleStyle = 'background: #eef2ff; color: #4338ca; border: 1px solid #e0e7ff;';
                } elseif (str_contains($roleLower, 'admission')) {
                    $roleStyle = 'background: #ecfeff; color: #0284c7; border: 1px solid #bae6fd;';
                } elseif (str_contains($roleLower, 'account') || str_contains($roleLower, 'finance')) {
                    $roleStyle = 'background: #f0f9ff; color: #0369a1; border: 1px solid #e0f2fe;';
                } elseif (str_contains($roleLower, 'teacher')) {
                    $roleStyle = 'background: #eff6ff; color: #2563eb; border: 1px solid #dbeafe;';
                } else {
                    $roleStyle = 'background: #f5f3ff; color: #6d28d9; border: 1px solid #ede9fe;';
                }

                // Status pill styling
                $st = strtolower($emp['status']);
                if ($st === 'active') {
                    $statusStyle = 'background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;';
                    $statusLabel = 'Active';
                } elseif ($st === 'inactive') {
                    $statusStyle = 'background: #f8fafc; color: #64748b; border: 1px solid #e2e8f0;';
                    $statusLabel = 'Inactive';
                } elseif ($st === 'suspended') {
                    $statusStyle = 'background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;';
                    $statusLabel = 'Suspended';
                } else {
                    $statusStyle = 'background: #fffbeb; color: #b45309; border: 1px solid #fde68a;';
                    $statusLabel = ucfirst($st);
                }

                $joinedDate = !empty($emp['joining_date']) ? date('Y-m-d', strtotime($emp['joining_date'])) : '—';
              ?>
              <tr class="staff-row" style="border-bottom: 1px solid #f1f5f9;">
                <!-- Row Checkbox -->
                <td class="ps-3 py-3">
                  <div class="form-check m-0">
                    <input class="form-check-input staff-checkbox" type="checkbox" name="staff_ids[]" value="<?= (int)$emp['id'] ?>" style="border-color: #cbd5e1; cursor: pointer;" onchange="updateSelectedCount()">
                  </div>
                </td>

                <!-- Staff Profile -->
                <td class="py-3">
                  <div class="d-flex align-items-center gap-3">
                    <?php if (!empty($emp['profile_image'])): ?>
                      <img src="<?= e(asset($emp['profile_image'])) ?>" alt="" class="rounded-circle" style="width: 36px; height: 36px; object-fit: cover;">
                    <?php else: ?>
                      <div class="d-flex align-items-center justify-content-center rounded-circle fw-bold text-white shadow-2xs" 
                           style="width: 36px; height: 36px; font-size: 13px; background: <?= $avatarBg ?>;">
                        <?= e($initial) ?>
                      </div>
                    <?php endif; ?>
                    <div>
                      <span class="fw-semibold text-dark d-block hover-primary" style="cursor: pointer; line-height: 1.25;" data-bs-toggle="modal" data-bs-target="#viewStaffModal<?= (int)$emp['id'] ?>">
                        <?= e($fullName) ?>
                      </span>
                      <span class="text-secondary font-monospace" style="font-size: 11px;">
                        <?= e($emp['employee_code']) ?>
                      </span>
                    </div>
                  </div>
                </td>

                <!-- Designation & Dept -->
                <td class="py-3">
                  <div class="fw-semibold text-dark" style="line-height: 1.25;">
                    <?= e($emp['designation'] ?? 'Staff') ?>
                  </div>
                  <div class="text-muted small" style="font-size: 11px;">
                    <?= e($emp['department'] ?? 'General') ?>
                  </div>
                </td>

                <!-- Contact Details -->
                <td class="py-3">
                  <div class="d-flex align-items-center gap-1 text-secondary" style="font-size: 12px; line-height: 1.25;">
                    <i data-lucide="mail" style="width: 12px; height: 12px; color: #94a3b8;"></i>
                    <span><?= e($emp['email'] ?: 'No email') ?></span>
                  </div>
                  <?php if (!empty($emp['phone'])): ?>
                    <div class="d-flex align-items-center gap-1 text-muted" style="font-size: 11px;">
                      <i data-lucide="phone" style="width: 11px; height: 11px; color: #94a3b8;"></i>
                      <span><?= e($emp['phone']) ?></span>
                    </div>
                  <?php endif; ?>
                </td>

                <!-- System Role -->
                <td class="py-3">
                  <span class="badge rounded-pill px-3 py-1 fw-medium" style="<?= $roleStyle ?> font-size: 11px;">
                    <?= e($roleName) ?>
                  </span>
                </td>

                <!-- Joined On -->
                <td class="py-3">
                  <span class="text-secondary font-monospace" style="font-size: 12px;">
                    <?= e($joinedDate) ?>
                  </span>
                </td>

                <!-- Status -->
                <td class="py-3">
                  <span class="badge rounded-pill px-3 py-1 fw-medium" style="<?= $statusStyle ?> font-size: 11px;">
                    <?= e($statusLabel) ?>
                  </span>
                </td>

                <!-- Actions -->
                <td class="pe-3 py-3 text-end">
                  <div class="d-inline-flex align-items-center gap-1">
                    <!-- Login Credentials & Password Reset Trigger -->
                    <?php if (hasPermission('employees.manage')): ?>
                      <button type="button" class="btn btn-sm btn-icon text-primary hover-icon p-1" data-bs-toggle="modal" data-bs-target="#resetPasswordModal<?= (int)$emp['id'] ?>" title="Login Access & Password" style="border-radius: 6px;">
                        <i data-lucide="key" style="width: 15px; height: 15px;"></i>
                      </button>
                    <?php endif; ?>

                    <!-- View Profile Trigger -->
                    <button type="button" class="btn btn-sm btn-icon text-muted hover-icon p-1" data-bs-toggle="modal" data-bs-target="#viewStaffModal<?= (int)$emp['id'] ?>" title="View Profile" style="border-radius: 6px;">
                      <i data-lucide="eye" style="width: 15px; height: 15px;"></i>
                    </button>

                    <!-- Edit Trigger -->
                    <?php if (hasPermission('employees.manage')): ?>
                      <button type="button" class="btn btn-sm btn-icon text-muted hover-icon p-1" data-bs-toggle="modal" data-bs-target="#editStaffModal<?= (int)$emp['id'] ?>" title="Edit Staff Member" style="border-radius: 6px;">
                        <i data-lucide="edit-3" style="width: 15px; height: 15px;"></i>
                      </button>

                      <!-- Deactivate / Delete Trigger -->
                      <button type="button" class="btn btn-sm btn-icon text-danger hover-icon p-1" data-bs-toggle="modal" data-bs-target="#deleteStaffModal<?= (int)$emp['id'] ?>" title="Deactivate Staff" style="border-radius: 6px;">
                        <i data-lucide="trash-2" style="width: 15px; height: 15px;"></i>
                      </button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Table Footer & Pagination -->
      <div class="p-3 border-top d-flex justify-content-between align-items-center flex-wrap gap-3 bg-white" style="border-color: #f1f5f9 !important;">
        <div class="text-muted small">
          Showing <span class="fw-semibold text-dark"><?= $startRecord ?></span> to <span class="fw-semibold text-dark"><?= $endRecord ?></span> of <span class="fw-semibold text-dark"><?= $total ?></span> records
        </div>

        <div class="d-flex align-items-center gap-3">
          <!-- Rows Selector -->
          <div class="d-flex align-items-center gap-1">
            <span class="text-muted small" style="font-size: 12px;">Rows:</span>
            <select class="form-select form-select-sm" style="width: 70px; height: 30px; font-size: 12px; border-radius: 6px; border-color: #cbd5e1;" onchange="changeLimit(this.value)">
              <option value="10" <?= ($limit ?? 10) == 10 ? 'selected' : '' ?>>10</option>
              <option value="25" <?= ($limit ?? 10) == 25 ? 'selected' : '' ?>>25</option>
              <option value="50" <?= ($limit ?? 10) == 50 ? 'selected' : '' ?>>50</option>
              <option value="100" <?= ($limit ?? 10) == 100 ? 'selected' : '' ?>>100</option>
            </select>
          </div>

          <!-- Pagination Links -->
          <?php if (($totalPages ?? 1) > 1): ?>
            <nav aria-label="Page navigation">
              <ul class="pagination pagination-sm m-0 gap-1">
                <li class="page-item <?= ($page ?? 1) <= 1 ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('staff?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) - 1])))) ?>">
                    <i data-lucide="chevron-left" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                  <?php if ($p == 1 || $p == $totalPages || ($p >= ($page - 2) && $p <= ($page + 2))): ?>
                    <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                      <a class="page-link rounded px-3" href="<?= e(url('staff?' . http_build_query(array_merge($filters, ['page' => $p])))) ?>"
                         style="<?= $p == $page ? 'background-color: #4f46e5; border-color: #4f46e5;' : '' ?>">
                        <?= $p ?>
                      </a>
                    </li>
                  <?php elseif ($p == 2 || $p == ($totalPages - 1)): ?>
                    <li class="page-item disabled"><span class="page-link rounded border-0 px-2">...</span></li>
                  <?php endif; ?>
                <?php endfor; ?>
                <li class="page-item <?= ($page ?? 1) >= $totalPages ? 'disabled' : '' ?>">
                  <a class="page-link rounded px-2" href="<?= e(url('staff?' . http_build_query(array_merge($filters, ['page' => ($page ?? 1) + 1])))) ?>">
                    <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
                  </a>
                </li>
              </ul>
            </nav>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</form>

<!-- MODALS SECTION -->

<!-- 1. ADD NEW STAFF MODAL -->
<?php if (hasPermission('employees.manage')): ?>
  <div class="modal fade" id="addStaffModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
        <form method="post" action="<?= e(url('hr/employees')) ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
            <div>
              <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Add New Staff Member</h5>
              <span class="text-muted small">Register faculty details, department assignment, and ERP access role.</span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body p-4">
            <!-- Section A: Personal Information -->
            <div class="mb-4">
              <h6 class="fw-bold text-secondary text-uppercase mb-3" style="font-size: 11px; letter-spacing: 0.05em;">Personal Information</h6>
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">First Name <span class="text-danger">*</span></label>
                  <input type="text" name="first_name" class="form-control form-control-sm" required placeholder="e.g. Rahul" style="height: 38px; border-radius: 8px;">
                </div>
                <div class="col-md-6">
                  <label class="form-label small fw-semibold text-secondary">Last Name <span class="text-danger">*</span></label>
                  <input type="text" name="last_name" class="form-control form-control-sm" required placeholder="e.g. Das" style="height: 38px; border-radius: 8px;">
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Gender</label>
                  <select name="gender" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Date of Birth</label>
                  <input type="date" name="date_of_birth" class="form-control form-control-sm" style="height: 38px; border-radius: 8px;">
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Phone Number</label>
                  <input type="text" name="phone" class="form-control form-control-sm" placeholder="e.g. +91 98760 20059" style="height: 38px; border-radius: 8px;">
                </div>
              </div>
            </div>

            <!-- Section B: Job & Department Details -->
            <div class="mb-4">
              <h6 class="fw-bold text-secondary text-uppercase mb-3" style="font-size: 11px; letter-spacing: 0.05em;">Job &amp; Department Details</h6>
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Designation <span class="text-danger">*</span></label>
                  <select name="designation_id" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;">
                    <option value="" disabled selected>Select Designation...</option>
                    <?php foreach ($designations as $ds): ?>
                      <option value="<?= (int)$ds['id'] ?>"><?= e($ds['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Department <span class="text-danger">*</span></label>
                  <select name="department_id" class="form-select form-select-sm" required style="height: 38px; border-radius: 8px;">
                    <option value="" disabled selected>Select Department...</option>
                    <?php foreach ($departments as $dp): ?>
                      <option value="<?= (int)$dp['id'] ?>"><?= e($dp['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Joining Date</label>
                  <input type="date" name="joining_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" style="height: 38px; border-radius: 8px;">
                </div>
              </div>
            </div>

            <!-- Section C: System Role & Login Access -->
            <div>
              <h6 class="fw-bold text-secondary text-uppercase mb-3" style="font-size: 11px; letter-spacing: 0.05em;">System Access &amp; Login Credentials</h6>
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">System Role</label>
                  <select name="role_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                    <option value="">No Login Access</option>
                    <?php foreach ($roles as $r): ?>
                      <?php $isAcc = in_array($r['slug'], ['accountant', 'finance'], true); ?>
                      <option value="<?= (int)$r['id'] ?>" <?= $r['slug'] === 'accountant' ? 'selected' : '' ?>>
                        <?= e($r['name']) ?> <?= $isAcc ? '★ (Accountant Access)' : '' ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Email Address (Login ID)</label>
                  <input type="email" name="email" class="form-control form-control-sm" placeholder="staff@example.com" style="height: 38px; border-radius: 8px;">
                </div>
                <div class="col-md-4">
                  <label class="form-label small fw-semibold text-secondary">Login Password</label>
                  <div class="input-group">
                    <input type="text" name="password" id="modalStaffPassword" class="form-control form-control-sm" placeholder="e.g. Staff@123" value="Staff@123" style="height: 38px; border-radius: 8px 0 0 8px;">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-2" onclick="generateModalStaffPassword()" title="Generate Random Password" style="border-color:#cbd5e1; font-size:11px;">
                      <i data-lucide="refresh-cw" style="width:13px;height:13px;"></i>
                    </button>
                  </div>
                </div>
              </div>
              <div class="text-muted small mt-2" style="font-size: 11.5px;">
                <i data-lucide="info" style="width: 13px; height: 13px; vertical-align: -2px;"></i>
                The full login credentials (Username, Password, School Code, Login Link) will be displayed in a popup right after saving.
              </div>
            </div>
          </div>

          <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
              <i data-lucide="check" style="width: 15px; height: 15px;"></i>
              <span>Save Staff Member</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- 2. BULK IMPORT STAFF MODAL -->
  <div class="modal fade" id="bulkImportStaffModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
        <form method="post" action="<?= e(url('staff/bulk-import')) ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
            <div>
              <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Bulk Import Staff</h5>
              <span class="text-muted small">Upload CSV file to admit multiple faculty and staff records at once.</span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body p-4">
            <div class="alert alert-info border-0 rounded-3 d-flex align-items-center justify-content-between p-3 mb-4" style="background-color: #eff6ff; color: #1e40af;">
              <div class="d-flex align-items-center gap-2">
                <i data-lucide="info" style="width: 18px; height: 18px;"></i>
                <span class="small">Expected columns: <code>first_name, last_name, employee_code, email, phone, joining_date</code></span>
              </div>
              <a href="data:text/csv;charset=utf-8,first_name,last_name,employee_code,email,phone,joining_date%0AJameel,Ahmed,EMP2026101,jameel@example.com,03001112233,2024-01-15%0ASara,Ali,EMP2026102,sara@example.com,03004445566,2024-02-01" download="sample_staff.csv" class="btn btn-sm btn-primary py-1 px-2 fw-semibold" style="font-size: 11px; border-radius: 6px;">
                Download Sample CSV
              </a>
            </div>

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">Choose CSV File (.csv) <span class="text-danger">*</span></label>
              <input type="file" name="csv_file" accept=".csv" required class="form-control" style="border-radius: 8px; padding: 0.5rem 0.75rem;">
            </div>
          </div>

          <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
              <i data-lucide="upload" style="width: 15px; height: 15px;"></i>
              <span>Upload &amp; Import</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- 3. VIEW STAFF MODALS & 4. EDIT STAFF MODALS -->
<?php if (!empty($employees)): ?>
  <?php foreach ($employees as $emp): ?>
    <?php $fName = trim($emp['first_name'] . ' ' . $emp['last_name']); ?>
    
    <!-- View Staff Modal -->
    <div class="modal fade" id="viewStaffModal<?= (int)$emp['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
          <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
            <div>
              <h5 class="modal-title fw-bold text-dark mb-0 fs-6"><?= e($fName) ?></h5>
              <span class="text-secondary font-monospace small"><?= e($emp['employee_code']) ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body p-4">
            <div class="row g-3">
              <div class="col-6">
                <span class="text-muted small d-block">Designation:</span>
                <span class="fw-semibold text-dark"><?= e($emp['designation'] ?? 'Staff') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Department:</span>
                <span class="fw-semibold text-dark"><?= e($emp['department'] ?? 'General') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Email Address:</span>
                <span class="fw-semibold text-dark"><?= e($emp['email'] ?: 'Not Specified') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Phone:</span>
                <span class="fw-semibold text-dark"><?= e($emp['phone'] ?: 'Not Specified') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">System Role:</span>
                <span class="badge bg-light text-primary border fw-medium"><?= e($emp['role_name'] ?: 'No Access') ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Status:</span>
                <span class="badge bg-light text-dark border fw-medium"><?= ucfirst(e($emp['status'])) ?></span>
              </div>
              <div class="col-6">
                <span class="text-muted small d-block">Joined On:</span>
                <span class="fw-semibold text-dark"><?= !empty($emp['joining_date']) ? date('d/m/Y', strtotime($emp['joining_date'])) : '—' ?></span>
              </div>
              <?php if (!empty($emp['address'])): ?>
                <div class="col-12">
                  <span class="text-muted small d-block">Address:</span>
                  <div class="p-2 bg-light rounded text-secondary small"><?= e($emp['address']) ?></div>
                </div>
              <?php endif; ?>
            </div>
          </div>
          <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Close</button>
            <?php if (hasPermission('employees.manage')): ?>
              <button type="button" class="btn btn-sm btn-outline-primary fw-medium d-inline-flex align-items-center gap-1.5" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#resetPasswordModal<?= (int)$emp['id'] ?>" style="border-radius: 8px;">
                <i data-lucide="key" style="width: 14px; height: 14px;"></i>
                <span>Login &amp; Password</span>
              </button>
              <button type="button" class="btn btn-sm btn-primary fw-semibold" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#editStaffModal<?= (int)$emp['id'] ?>" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
                Edit Profile
              </button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Staff Modal -->
    <?php if (hasPermission('employees.manage')): ?>
      <div class="modal fade" id="editStaffModal<?= (int)$emp['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
            <form method="post" action="<?= e(url('hr/employees/' . $emp['id'])) ?>">
              <?= csrf_field() ?>
              <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
                <div>
                  <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Edit Staff Member</h5>
                  <span class="text-muted small"><?= e($fName) ?> • <?= e($emp['employee_code']) ?></span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>

              <div class="modal-body p-4">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">First Name <span class="text-danger">*</span></label>
                    <input type="text" name="first_name" class="form-control form-control-sm" value="<?= e($emp['first_name']) ?>" required style="height: 38px; border-radius: 8px;">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Last Name <span class="text-danger">*</span></label>
                    <input type="text" name="last_name" class="form-control form-control-sm" value="<?= e($emp['last_name']) ?>" required style="height: 38px; border-radius: 8px;">
                  </div>
                  <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Email</label>
                    <input type="email" name="email" class="form-control form-control-sm" value="<?= e($emp['email']) ?>" style="height: 38px; border-radius: 8px;">
                  </div>
                  <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Phone</label>
                    <input type="text" name="phone" class="form-control form-control-sm" value="<?= e($emp['phone']) ?>" style="height: 38px; border-radius: 8px;">
                  </div>
                  <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Status</label>
                    <select name="status" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                      <option value="active" <?= $emp['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                      <option value="inactive" <?= $emp['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                      <option value="suspended" <?= $emp['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                      <option value="terminated" <?= $emp['status'] === 'terminated' ? 'selected' : '' ?>>Terminated</option>
                      <option value="on_leave" <?= $emp['status'] === 'on_leave' ? 'selected' : '' ?>>On Leave</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Designation</label>
                    <select name="designation_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                      <option value="">Select Designation...</option>
                      <?php foreach ($designations as $ds): ?>
                        <option value="<?= (int)$ds['id'] ?>" <?= ((int)$emp['designation_id'] === (int)$ds['id']) ? 'selected' : '' ?>>
                          <?= e($ds['name']) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Department</label>
                    <select name="department_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                      <option value="">Select Department...</option>
                      <?php foreach ($departments as $dp): ?>
                        <option value="<?= (int)$dp['id'] ?>" <?= ((int)$emp['department_id'] === (int)$dp['id']) ? 'selected' : '' ?>>
                          <?= e($dp['name']) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
              </div>

              <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
                <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
                  <i data-lucide="check" style="width: 15px; height: 15px;"></i>
                  <span>Update Staff Member</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Delete Staff Modal -->
      <div class="modal fade" id="deleteStaffModal<?= (int)$emp['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
          <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
            <form method="post" action="<?= e(url('hr/employees/' . $emp['id'] . '/delete')) ?>">
              <?= csrf_field() ?>
              <div class="modal-body p-4 text-center">
                <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger mb-3" style="width: 48px; height: 48px;">
                  <i data-lucide="alert-triangle" style="width: 24px; height: 24px;"></i>
                </div>
                <h6 class="fw-bold text-dark mb-1">Deactivate Staff Member?</h6>
                <p class="text-muted small mb-0">Are you sure you want to deactivate <strong><?= e($fName) ?></strong>? They will no longer have active system access.</p>
              </div>
              <div class="modal-footer border-0 p-3 pt-0 justify-content-center">
                <button type="button" class="btn btn-sm btn-light px-3" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
                <button type="submit" class="btn btn-sm btn-danger px-3 fw-semibold" style="border-radius: 8px;">Deactivate</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Manage Login Access & Reset Password Modal -->
      <div class="modal fade" id="resetPasswordModal<?= (int)$emp['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 shadow-lg" style="border-radius: 14px;">
            <form method="post" action="<?= e(url('staff/' . $emp['id'] . '/reset-password')) ?>">
              <?= csrf_field() ?>
              <div class="modal-header border-bottom px-4 py-3 bg-light" style="border-radius: 14px 14px 0 0;">
                <div class="d-flex align-items-center gap-2">
                  <div class="rounded-circle p-2 bg-primary-subtle text-primary">
                    <i data-lucide="key" style="width: 18px; height: 18px;"></i>
                  </div>
                  <div>
                    <h5 class="modal-title fw-bold text-dark mb-0 fs-6">Manage Login Access &amp; Password</h5>
                    <span class="text-muted small"><?= e($fName) ?> &bull; <?= e($emp['employee_code']) ?></span>
                  </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>

              <div class="modal-body p-4">
                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Login Email (Username)</label>
                  <input type="email" name="email" class="form-control" value="<?= e($emp['email']) ?>" required style="height: 38px; border-radius: 8px;">
                  <div class="text-muted" style="font-size: 11px;">The staff member uses this email as their Login ID.</div>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">System Role</label>
                  <select name="role_id" class="form-select form-select-sm" style="height: 38px; border-radius: 8px;">
                    <?php foreach ($roles as $r): ?>
                      <?php $isAcc = in_array($r['slug'], ['accountant', 'finance'], true); ?>
                      <option value="<?= (int)$r['id'] ?>" <?= ($emp['role_slug'] === $r['slug'] || ($isAcc && $emp['role_slug'] === 'accountant')) ? 'selected' : '' ?>>
                        <?= e($r['name']) ?> <?= $isAcc ? '★ (Accountant Access)' : '' ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Set New Password</label>
                  <div class="input-group">
                    <input type="text" name="password" id="resetPwdInput<?= (int)$emp['id'] ?>" class="form-control" placeholder="Enter new password" value="Staff@<?= rand(100, 999) ?>" style="height: 38px; border-radius: 8px 0 0 8px;">
                    <button type="button" class="btn btn-outline-secondary px-3" onclick="generateResetPwd(<?= (int)$emp['id'] ?>)" title="Generate Random Password" style="border-color:#cbd5e1; font-size:12px;">
                      <i data-lucide="refresh-cw" style="width:13px;height:13px;"></i> Generate
                    </button>
                  </div>
                  <div class="text-muted mt-1" style="font-size: 11px;">
                    Once updated, a credentials card will pop up with the new login details so you can share it.
                  </div>
                </div>
              </div>

              <div class="modal-footer border-top px-4 py-3 bg-light" style="border-radius: 0 0 14px 14px;">
                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Cancel</button>
                <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 fw-semibold px-3" style="border-radius: 8px; background-color: #4f46e5; border-color: #4f46e5;">
                  <i data-lucide="check-circle" style="width: 15px; height: 15px;"></i>
                  <span>Save &amp; Reveal Credentials</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    <?php endif; ?>
  <?php endforeach; ?>
<?php endif; ?>

<!-- Javascript Controls -->
<script>
// Checkbox Management
function toggleSelectAll(masterCheckbox) {
  const checkboxes = document.querySelectorAll('.staff-checkbox');
  checkboxes.forEach(cb => cb.checked = masterCheckbox.checked);
  updateSelectedCount();
}

function updateSelectedCount() {
  const checkboxes = document.querySelectorAll('.staff-checkbox:checked');
  const count = checkboxes.length;
  const bar = document.getElementById('bulkActionBar');
  const badge = document.getElementById('selectedCountBadge');
  
  if (badge) badge.textContent = count;
  if (bar) {
    if (count > 0) {
      bar.classList.remove('d-none');
    } else {
      bar.classList.add('d-none');
    }
  }

  const allCheckboxes = document.querySelectorAll('.staff-checkbox');
  const master = document.getElementById('selectAllCheckbox');
  if (master && allCheckboxes.length > 0) {
    master.checked = count === allCheckboxes.length;
  }
}

function clearSelectedRows() {
  document.querySelectorAll('.staff-checkbox').forEach(cb => cb.checked = false);
  const master = document.getElementById('selectAllCheckbox');
  if (master) master.checked = false;
  updateSelectedCount();
}

function changeLimit(newLimit) {
  const form = document.getElementById('staffFilterForm');
  form.querySelector('input[name="limit"]').value = newLimit;
  form.submit();
}

function sortBy(column) {
  const form = document.getElementById('staffFilterForm');
  const sortInput = form.querySelector('input[name="sort"]');
  const dirInput = form.querySelector('input[name="dir"]');

  if (sortInput.value === column) {
    dirInput.value = dirInput.value === 'asc' ? 'desc' : 'asc';
  } else {
    sortInput.value = column;
    dirInput.value = 'asc';
  }
  form.submit();
}

function copyCredText(text, label) {
  navigator.clipboard.writeText(text).then(() => {
    alert(label + ' copied to clipboard: ' + text);
  }).catch(() => {});
}

function copyFullCredTemplate() {
  const codeEl = document.getElementById('credSchoolCode');
  const emailEl = document.getElementById('credEmail');
  const pwdEl = document.getElementById('credPassword');
  
  const schoolCode = codeEl ? codeEl.innerText.trim() : '';
  const email = emailEl ? emailEl.innerText.trim() : '';
  const password = pwdEl ? pwdEl.innerText.trim() : '';
  
  let text = `School Portal Login Credentials\n` +
`----------------------------------------\n` +
`Role: Accountant\n`;
  if (schoolCode) {
    text += `School Code: ${schoolCode}\n`;
  }
  text += `Login URL: ${window.location.origin}/SCHOOL%20PORTAL%20FINAL/public/login\n` +
`Email / Login ID: ${email}\n` +
`Password: ${password}\n` +
`----------------------------------------\n` +
`Please sign in and change your password upon first login.`;

  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById('copyFullBtnText');
    if (btn) {
      const orig = btn.innerText;
      btn.innerText = 'Copied to Clipboard! ✓';
      setTimeout(() => { btn.innerText = orig; }, 3000);
    }
  }).catch(() => {
    alert('Failed to copy. Please manually copy the credentials.');
  });
}

function generateResetPwd(id) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let rand = '';
  for (let i = 0; i < 4; i++) {
    rand += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  const input = document.getElementById('resetPwdInput' + id);
  if (input) {
    input.value = 'Acc#' + rand + '!';
    input.focus();
  }
}

function generateModalStaffPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let rand = '';
  for (let i = 0; i < 4; i++) {
    rand += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  const input = document.getElementById('modalStaffPassword');
  if (input) {
    input.value = 'Acc#' + rand + '!';
    input.focus();
  }
}

document.addEventListener('DOMContentLoaded', function() {
  if (window.lucide) {
    lucide.createIcons();
  }
  
  // Auto-show Credentials Modal if new staff/accountant was just created
  const credModalEl = document.getElementById('staffCredentialsModal');
  if (credModalEl && typeof bootstrap !== 'undefined') {
    const credModal = new bootstrap.Modal(credModalEl);
    credModal.show();
  }
});
</script>

<style>
.hover-icon:hover {
  background-color: #f1f5f9 !important;
  color: #1e293b !important;
}
.hover-primary:hover {
  color: #4f46e5 !important;
}
.staff-row:hover {
  background-color: #f8fafc !important;
}
</style>
