<div class="container-fluid py-4">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= url('hr/dashboard') ?>" class="text-decoration-none text-muted small">&larr; HR Operations</a>
                <span class="text-muted small">/</span>
                <span class="text-muted small">Professional Development</span>
            </div>
            <h1 class="h3 mb-0 text-gray-800 fw-bold">
                <i class="bi bi-mortarboard text-info me-2"></i><?= htmlspecialchars($title) ?>
            </h1>
            <p class="text-muted small mb-0">Track teacher training hours, institutional workshops, certifications, and continuing education.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <!-- Filter by Staff -->
            <form method="GET" action="<?= url('hr/trainings') ?>" class="d-flex align-items-center">
                <select name="employee_id" class="form-select form-select-sm shadow-sm" onchange="this.form.submit()">
                    <option value="">All Staff Trainings</option>
                    <?php foreach ($employees as $emp): ?>
                        <option value="<?= $emp['id'] ?>" <?= ($selectedEmployee == $emp['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            <button type="button" class="btn btn-primary btn-sm shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#createTrainingModal">
                <i class="bi bi-plus-lg me-1"></i> Record Training Session
            </button>
        </div>
    </div>

    <!-- Training Analytics Cards -->
    <div class="row g-3 mb-4">
        <?php 
        $totalTrainings = count($trainings);
        $totalHours = 0.0;
        $certifiedCount = 0;
        $totalCost = 0.0;
        foreach ($trainings as $t) {
            $totalHours += (float)$t['hours'];
            $totalCost += (float)$t['cost'];
            if ($t['status'] === 'certified' || $t['status'] === 'completed') $certifiedCount++;
        }
        ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Training Hours</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0"><?= number_format($totalHours, 1) ?> hrs</div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Across all completed faculty sessions</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Completed &amp; Certified</div>
                <div class="h3 fw-bold text-success mt-1 mb-0"><?= $certifiedCount ?> / <?= $totalTrainings ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Successful course completions</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Institutional Investment</div>
                <div class="h4 fw-bold text-primary mt-1 mb-0 text-truncate"><?= formatMoney($totalCost) ?></div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Staff development expenditure</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-secondary">
                <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Avg Hours / Record</div>
                <div class="h3 fw-bold text-dark mt-1 mb-0">
                    <?= ($totalTrainings > 0) ? round($totalHours / $totalTrainings, 1) : 0 ?> hrs
                </div>
                <div class="text-muted small mt-1" style="font-size: 11px;">Average workshop length</div>
            </div>
        </div>
    </div>

    <!-- Trainings Table -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">Staff Training &amp; Professional Development History</h6>
            <span class="badge bg-light border text-dark fw-semibold"><?= $totalTrainings ?> Recorded</span>
        </div>
        <div class="card-body p-0">
            <?php if (empty($trainings)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-mortarboard text-muted fs-1 d-block mb-2"></i>
                    <h6 class="fw-bold text-dark">No Training Records Logged</h6>
                    <p class="text-muted small mb-3">Record pedagogical workshops, digital learning sessions, and compliance trainings.</p>
                    <button type="button" class="btn btn-primary btn-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#createTrainingModal">
                        <i class="bi bi-plus-lg me-1"></i> Record Training
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Staff Member</th>
                                <th>Training Course / Workshop</th>
                                <th>Provider &amp; Category</th>
                                <th>Dates &amp; Duration</th>
                                <th>Certificate Ref</th>
                                <th>Status</th>
                                <th class="pe-4 text-end">Profile</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($trainings as $t): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($t['employee_name']) ?></div>
                                        <div class="text-muted small"><?= htmlspecialchars($t['employee_code']) ?> &middot; <?= htmlspecialchars($t['department_name'] ?? 'General') ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($t['title']) ?></div>
                                        <?php if (!empty($t['notes'])): ?>
                                            <div class="text-muted small text-truncate" style="max-width: 200px;"><?= htmlspecialchars($t['notes']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($t['provider']) ?></div>
                                        <span class="badge bg-light text-dark border small" style="font-size: 11px;"><?= htmlspecialchars($t['category']) ?></span>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= (float)$t['hours'] ?> Hours</div>
                                        <div class="text-muted small">
                                            <?= date('M d, Y', strtotime($t['start_date'])) ?>
                                            <?php if ($t['start_date'] !== $t['end_date']): ?>
                                                &rarr; <?= date('M d, Y', strtotime($t['end_date'])) ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($t['certificate_ref'])): ?>
                                            <span class="badge bg-light border text-dark font-monospace"><?= htmlspecialchars($t['certificate_ref']) ?></span>
                                        <?php else: ?>
                                            <span class="text-muted small">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $statusClass = match($t['status']) {
                                            'certified' => 'bg-success-subtle text-success border-success-subtle',
                                            'completed' => 'bg-primary-subtle text-primary border-primary-subtle',
                                            default => 'bg-warning-subtle text-warning border-warning-subtle',
                                        };
                                        ?>
                                        <span class="badge border <?= $statusClass ?> text-capitalize px-2 py-1">
                                            <?= htmlspecialchars($t['status']) ?>
                                        </span>
                                    </td>
                                    <td class="pe-4 text-end">
                                        <a href="<?= url('hr/employees/' . $t['employee_id'] . '?tab=trainings') ?>" class="btn btn-sm btn-light border text-dark">
                                            View &rarr;
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Record Training Modal -->
<div class="modal fade" id="createTrainingModal" tabindex="-1" aria-labelledby="createTrainingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <form method="POST" action="<?= url('hr/trainings') ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-bottom py-3 px-4">
                    <h5 class="modal-title fw-bold text-dark" id="createTrainingModalLabel">Record Staff Training Session</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Staff Member <span class="text-danger">*</span></label>
                        <select name="employee_id" class="form-select" required>
                            <option value="">-- Select Staff Member --</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= $emp['id'] ?>" <?= ($selectedEmployee == $emp['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= htmlspecialchars($emp['employee_code']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Training Title / Course Name <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Modern Formative Assessment Techniques" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Training Provider</label>
                            <input type="text" name="provider" class="form-control" placeholder="e.g. Cambridge Academy" value="Internal Academy">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Disciplinary Category</label>
                            <select name="category" class="form-select">
                                <option value="Pedagogy">Pedagogy &amp; Teaching</option>
                                <option value="Digital Literacy">Digital Literacy &amp; EdTech</option>
                                <option value="Child Safeguarding">Child Safeguarding &amp; Safety</option>
                                <option value="Classroom Management">Classroom Management</option>
                                <option value="Leadership">Educational Leadership</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">Start Date <span class="text-danger">*</span></label>
                            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold text-dark">End Date <span class="text-danger">*</span></label>
                            <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-semibold text-dark">Hours <span class="text-danger">*</span></label>
                            <input type="number" step="0.5" name="hours" class="form-control" value="8.0" min="0.5" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold text-dark">Cost</label>
                            <input type="number" step="0.01" name="cost" class="form-control" value="0.00" min="0">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold text-dark">Status</label>
                            <select name="status" class="form-select">
                                <option value="completed" selected>Completed</option>
                                <option value="certified">Certified</option>
                                <option value="enrolled">Enrolled</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-dark">Certificate ID / Reference Token</label>
                        <input type="text" name="certificate_ref" class="form-control font-monospace" placeholder="e.g. CERT-2026-8849">
                    </div>

                    <div class="mb-0">
                        <label class="form-label small fw-semibold text-dark">Learning Outcomes &amp; Notes</label>
                        <textarea name="notes" rows="2" class="form-control" placeholder="Summary of takeaways or competencies mastered..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top py-3 px-4">
                    <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Training Record</button>
                </div>
            </form>
        </div>
    </div>
</div>
