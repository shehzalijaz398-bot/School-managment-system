<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800">Recruitment & Candidates</h2>
        <p class="text-muted mb-0">Manage job applicants, track interview progress, and hire new staff.</p>
    </div>
    <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm action-hover" data-bs-toggle="modal" data-bs-target="#addCandidateModal">
        <i class="fas fa-plus-circle"></i> Add New Candidate
    </button>
</div>

<div class="row g-4">
    <?php foreach ($candidates as $c): ?>
    <div class="col-md-6 col-xl-4">
        <div class="card candidate-card h-100 border-0 shadow-sm rounded-4 overflow-hidden position-relative">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-0 px-4 d-flex justify-content-between align-items-start">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar avatar-md bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold fs-5 shadow-sm" style="width: 50px; height: 50px;">
                        <?= strtoupper(substr($c['first_name'], 0, 1) . substr($c['last_name'], 0, 1)) ?>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold text-gray-800"><?= e($c['first_name'].' '.$c['last_name']) ?></h5>
                        <span class="text-muted small fw-medium"><i class="fas fa-briefcase text-primary me-1"></i> <?= e($c['position_applied']) ?></span>
                    </div>
                </div>
                <div>
                    <?php 
                        $statusClass = 'bg-secondary';
                        if($c['status'] == 'applied') $statusClass = 'bg-info';
                        if($c['status'] == 'screening') $statusClass = 'bg-warning text-dark';
                        if($c['status'] == 'interview') $statusClass = 'bg-primary';
                        if($c['status'] == 'selected') $statusClass = 'bg-success';
                        if($c['status'] == 'rejected') $statusClass = 'bg-danger';
                        if($c['status'] == 'hired') $statusClass = 'bg-dark';
                    ?>
                    <span class="badge <?= $statusClass ?> rounded-pill px-3 py-2 fw-semibold shadow-sm" style="font-size: 0.7rem; letter-spacing: 0.5px;">
                        <?= strtoupper($c['status']) ?>
                    </span>
                </div>
            </div>
            
            <div class="card-body px-4 py-3">
                <div class="mb-3">
                    <div class="d-flex align-items-center text-sm mb-2 text-secondary">
                        <div style="width: 25px;"><i class="fas fa-envelope text-muted"></i></div>
                        <?= e($c['email'] ?: 'No email provided') ?>
                    </div>
                    <div class="d-flex align-items-center text-sm mb-2 text-secondary">
                        <div style="width: 25px;"><i class="fas fa-phone-alt text-muted"></i></div>
                        <?= e($c['phone'] ?: 'No phone provided') ?>
                    </div>
                    <div class="d-flex align-items-center text-sm text-secondary">
                        <div style="width: 25px;"><i class="fas fa-building text-muted"></i></div>
                        <?= e($c['department'] ?: 'General / Unassigned') ?>
                    </div>
                </div>

                <!-- Update Status Form -->
                <form method="post" action="<?= e(url('hr/candidates/'.$c['id'].'/status')) ?>" class="d-flex align-items-center gap-2 mb-3 bg-light p-2 rounded-3 border border-light-subtle shadow-inner">
                    <?= csrf_field() ?>
                    <i class="fas fa-tasks text-muted ps-2"></i>
                    <select name="status" class="form-select form-select-sm border-0 bg-transparent fw-medium text-gray-700 shadow-none" onchange="this.form.submit()">
                        <?php foreach (['applied','screening','interview','selected','rejected'] as $st): ?>
                            <option value="<?= $st ?>" <?= $c['status']===$st?'selected':'' ?>><?= ucfirst($st) ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <?php if ($c['status'] !== 'hired' && $c['status'] !== 'rejected'): ?>
                <!-- Hire Form -->
                <div class="mt-3 pt-3 border-top border-dashed">
                    <h6 class="text-xs fw-bold text-success text-uppercase mb-2"><i class="fas fa-handshake me-1"></i> Make Offer & Hire</h6>
                    <form method="post" action="<?= e(url('hr/candidates/'.$c['id'].'/hire')) ?>">
                        <?= csrf_field() ?>
                        <div class="input-group input-group-sm mb-2 shadow-sm rounded-3 overflow-hidden">
                            <span class="input-group-text bg-white border-0 text-muted"><i class="fas fa-money-bill-wave"></i></span>
                            <input type="number" name="basic_salary" class="form-control border-0 bg-white" placeholder="Basic Salary (e.g. 50000)" required>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="as_teacher" value="1" id="teacherSwitch<?= $c['id'] ?>">
                                <label class="form-check-label text-sm fw-medium text-gray-700" for="teacherSwitch<?= $c['id'] ?>">Hire as Teacher</label>
                            </div>
                            <button class="btn btn-sm btn-success rounded-pill px-4 fw-bold action-hover shadow-sm">
                                Hire Now
                            </button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
                
                <?php if ($c['status'] === 'hired'): ?>
                    <div class="mt-3 pt-3 border-top border-dashed text-center">
                        <span class="text-success fw-bold"><i class="fas fa-check-circle me-1"></i> Successfully Hired</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($candidates)): ?>
    <div class="col-12">
        <div class="text-center py-5 text-muted bg-white rounded-4 shadow-sm">
            <i class="fas fa-user-tie fa-4x mb-3 text-light"></i>
            <h4 class="fw-bold text-gray-500">No Candidates Found</h4>
            <p class="mb-0">You currently don't have any job applicants.</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Add Candidate Modal -->
<div class="modal fade" id="addCandidateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-primary text-white px-4 py-3 border-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-user-plus me-2"></i> Add New Candidate</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="<?= e(url('hr/candidates')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body px-4 py-4 bg-light">
                    <div class="row g-3">
                        <h6 class="text-uppercase text-muted text-xs fw-bold mb-0 w-100"><i class="fas fa-id-card me-1"></i> Personal Details</h6>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" class="form-control rounded-3 shadow-sm border-0" required placeholder="e.g. Jane">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Last Name <span class="text-danger">*</span></label>
                            <input type="text" name="last_name" class="form-control rounded-3 shadow-sm border-0" required placeholder="e.g. Smith">
                        </div>
                        
                        <div class="col-md-6 mt-3">
                            <label class="form-label text-sm fw-semibold">Email Address</label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-envelope text-muted"></i></span>
                                <input type="email" name="email" class="form-control border-0 bg-white" placeholder="jane@example.com">
                            </div>
                        </div>
                        <div class="col-md-6 mt-3">
                            <label class="form-label text-sm fw-semibold">Phone Number</label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-phone-alt text-muted"></i></span>
                                <input type="text" name="phone" class="form-control border-0 bg-white" placeholder="+1 234 567 8900">
                            </div>
                        </div>

                        <h6 class="text-uppercase text-muted text-xs fw-bold mb-0 mt-4 w-100"><i class="fas fa-briefcase me-1"></i> Application Details</h6>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Position Applied For <span class="text-danger">*</span></label>
                            <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                <span class="input-group-text bg-white border-0"><i class="fas fa-user-tie text-muted"></i></span>
                                <input type="text" name="position_applied" class="form-control border-0 bg-white" required placeholder="e.g. Math Teacher, IT Support">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-sm fw-semibold">Target Department</label>
                            <select name="department_id" class="form-select rounded-3 shadow-sm border-0">
                                <option value="">Select Department (Optional)</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer px-4 py-3 border-top-0 bg-white">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-bold shadow-sm action-hover" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold shadow-sm action-hover"><i class="fas fa-save me-1"></i> Save Candidate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* Premium Hover & Animation Effects */
    .candidate-card {
        transition: all 0.35s cubic-bezier(0.25, 0.8, 0.25, 1);
        border: 1px solid #f1f5f9 !important;
    }
    .candidate-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px -10px rgba(0, 0, 0, 0.1) !important;
        border-color: #e2e8f0 !important;
    }
    .candidate-card .avatar {
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .candidate-card:hover .avatar {
        transform: scale(1.15) rotate(8deg);
        box-shadow: 0 5px 15px rgba(13, 110, 253, 0.25) !important;
    }
    
    .action-hover {
        transition: all 0.25s ease;
    }
    .action-hover:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0,0,0,0.1) !important;
        filter: brightness(1.05);
    }
    
    .border-dashed {
        border-top-style: dashed !important;
        border-top-color: #e2e8f0 !important;
    }
    
    .shadow-inner {
        box-shadow: inset 0 2px 4px 0 rgba(0, 0, 0, 0.03);
    }

    .form-control:focus, .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
    }
</style>
