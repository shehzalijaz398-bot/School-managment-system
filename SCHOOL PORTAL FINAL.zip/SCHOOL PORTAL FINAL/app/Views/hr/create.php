<?php
/**
 * CodeClove School Management Pro — Add New Staff Form
 * Pixel-perfect match to official CodeClove Add Staff workflow
 */
?>

<style>
.cc-staff-container {
  max-width: 980px;
  margin: 0 auto;
}
.cc-staff-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.5rem 1.75rem;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
  margin-bottom: 1.5rem;
  transition: border-color 0.15s ease;
}
.cc-staff-card:hover {
  border-color: #cbd5e1;
}
.cc-form-section-title {
  font-size: 0.76rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.cc-form-label {
  font-size: 0.82rem;
  font-weight: 600;
  color: #334155;
  margin-bottom: 0.35rem;
  display: block;
}
.cc-form-label .req {
  color: #dc2626;
  font-weight: 700;
}
.cc-input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background-color: #ffffff;
  font-size: 0.88rem;
  color: #0f172a;
  padding: 0.5rem 0.85rem;
  transition: all 0.15s ease-in-out;
  width: 100%;
}
.cc-input:focus {
  border-color: #4f46e5;
  outline: none;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.12);
}
.cc-input::placeholder {
  color: #94a3b8;
  font-size: 0.84rem;
}
.cc-input-group {
  position: relative;
}
.cc-input-icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #94a3b8;
  pointer-events: none;
}
.cc-photo-upload-box {
  width: 96px;
  height: 96px;
  border-radius: 12px;
  border: 1px dashed #cbd5e1;
  background-color: #f8fafc;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  overflow: hidden;
  position: relative;
}
.cc-photo-upload-box:hover {
  border-color: #4f46e5;
  background-color: #f5f3ff;
}
.cc-photo-upload-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.cc-inner-card {
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 1.15rem 1.25rem;
  margin-top: 1rem;
}
.cc-inner-title {
  font-size: 0.82rem;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 0.75rem;
  display: flex;
  align-items: center;
  gap: 0.45rem;
}
.cc-empty-docs {
  background-color: #f8fafc;
  border: 1px dashed #e2e8f0;
  border-radius: 10px;
  padding: 2rem 1.5rem;
  text-align: center;
  color: #64748b;
  font-size: 0.86rem;
}
.cc-btn-cancel {
  border: 1px solid #e2e8f0;
  background: #ffffff;
  color: #475569;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.25rem;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.cc-btn-cancel:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-btn-submit {
  background: #4f46e5;
  border: 1px solid #4f46e5;
  color: #ffffff;
  font-weight: 600;
  font-size: 0.86rem;
  padding: 0.55rem 1.5rem;
  border-radius: 8px;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(79, 70, 229, 0.2);
}
.cc-btn-submit:hover {
  background: #4338ca;
  border-color: #4338ca;
}
.cc-pill-badge {
  font-size: 0.72rem;
  font-weight: 600;
  padding: 0.2rem 0.55rem;
  border-radius: 9999px;
  background: rgba(79, 70, 229, 0.08);
  color: #4f46e5;
  border: 1px solid rgba(79, 70, 229, 0.2);
}
</style>

<div class="cc-staff-container mb-5">

  <!-- 1. Breadcrumbs -->
  <nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb mb-1" style="font-size: 13px;">
      <li class="breadcrumb-item"><a href="<?= e(url('staff')) ?>" class="text-muted text-decoration-none">Staff</a></li>
      <li class="breadcrumb-item"><a href="<?= e(url('staff')) ?>" class="text-muted text-decoration-none">Directory</a></li>
      <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Add New</li>
    </ol>
  </nav>

  <!-- 2. Page Header -->
  <div class="mb-4">
    <div class="d-flex align-items-center gap-2 mb-1">
      <a href="<?= e(url('staff')) ?>" class="btn btn-sm btn-white border d-inline-flex align-items-center justify-content-center text-muted" style="width: 32px; height: 32px; border-radius: 8px; background: #ffffff; border-color: #e2e8f0;" title="Back to Staff Directory">
        <i data-lucide="arrow-left" style="width: 18px; height: 18px;"></i>
      </a>
      <h1 class="h3 fw-bold text-dark mb-0" style="letter-spacing: -0.02em;">
        <?= e($title ?? 'Add New Staff') ?>
      </h1>
    </div>
    <p class="text-muted small mb-0 ps-1" style="margin-left: 36px;">Enter personal and institutional details to add a new staff.</p>
  </div>

  <form method="post" enctype="multipart/form-data" action="<?= e(url('staff')) ?>" id="addStaffForm">
    <?= csrf_field() ?>

    <!-- ==========================================
         CARD 1: 1. IDENTITY & DEMOGRAPHICS
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>1. IDENTITY & DEMOGRAPHICS</span>
      </div>

      <!-- Photo & Staff ID Row -->
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-4 mb-4">
        <!-- Photo Block -->
        <div class="d-flex align-items-center gap-3">
          <div class="cc-photo-upload-box" onclick="document.getElementById('staffPhotoInput').click();" title="Click to choose staff photo">
            <div id="staffPhotoPlaceholder" class="text-center">
              <i data-lucide="user" style="width: 28px; height: 28px; color: #94a3b8;"></i>
            </div>
            <img id="staffPhotoPreview" src="" style="display:none;">
          </div>
          <div>
            <div class="cc-form-label mb-1">Staff Photo</div>
            <button type="button" class="btn btn-sm btn-link text-decoration-none p-0 fw-semibold" style="color: #4f46e5; font-size: 13px;" onclick="document.getElementById('staffPhotoInput').click();">
              Choose Photo
            </button>
            <input type="file" name="profile_image" id="staffPhotoInput" accept="image/*" style="display:none;" onchange="previewStaffPhoto(this)">
            <div class="text-muted" style="font-size: 11px;">PNG or JPG up to 2MB recommended</div>
          </div>
        </div>

        <!-- Staff ID / Employee Code -->
        <div style="min-width: 260px;">
          <label class="cc-form-label">Staff ID / Employee Code</label>
          <input type="text" name="employee_code" class="cc-input" placeholder="Auto-generated if blank" value="<?= e($nextCode ?? '') ?>">
        </div>
      </div>

      <!-- 5-Column Name Row -->
      <div class="row g-2 mb-3">
        <div class="col-12 col-md-2">
          <label class="cc-form-label">Title</label>
          <select name="title" class="cc-input form-select">
            <option value="">Select...</option>
            <option value="Mr.">Mr.</option>
            <option value="Mrs.">Mrs.</option>
            <option value="Ms.">Ms.</option>
            <option value="Dr.">Dr.</option>
            <option value="Prof.">Prof.</option>
          </select>
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">First Name <span class="req">*</span></label>
          <input type="text" name="first_name" class="cc-input" required placeholder="e.g. Alice">
        </div>
        <div class="col-12 col-md-2">
          <label class="cc-form-label">Middle Name</label>
          <input type="text" name="middle_name" class="cc-input" placeholder="e.g. Marie">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Last Name <span class="req">*</span></label>
          <input type="text" name="last_name" class="cc-input" required placeholder="e.g. Smith">
        </div>
        <div class="col-12 col-md-2">
          <label class="cc-form-label">Preferred Name</label>
          <input type="text" name="preferred_name" class="cc-input" placeholder="e.g. Ali">
        </div>
      </div>

      <!-- 2-Column DOB & Gender Row -->
      <div class="row g-3">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Date of Birth</label>
          <div class="cc-input-group">
            <input type="date" name="date_of_birth" class="cc-input" placeholder="DD/MM/YYYY">
            <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Gender</label>
          <select name="gender" class="cc-input form-select">
            <option value="">Select gender identity...</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
            <option value="prefer_not">Prefer not to say</option>
          </select>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 2: 2. CONTACT & EMERGENCY DETAILS
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>2. CONTACT & EMERGENCY DETAILS</span>
      </div>

      <!-- Email & Phone Row (2 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Email Address <span class="req">*</span></label>
          <input type="email" name="email" class="cc-input" required placeholder="e.g. alice.smith@school.com">
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Primary Phone Number</label>
          <input type="text" name="phone" class="cc-input" placeholder="e.g. +1 (555) 012-3456">
        </div>
      </div>

      <!-- Residential Street Address (full width) -->
      <div class="mb-3">
        <label class="cc-form-label">Residential Street Address</label>
        <input type="text" name="street_address" class="cc-input" placeholder="e.g. 123 Main St, Apt 4B">
      </div>

      <!-- City, State, ZIP, Country (4 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-3">
          <label class="cc-form-label">City</label>
          <input type="text" name="city" class="cc-input" placeholder="e.g. Springfield">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">State / Province</label>
          <input type="text" name="state" class="cc-input" placeholder="e.g. Illinois">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">ZIP / Postal Code</label>
          <input type="text" name="zip" class="cc-input" placeholder="e.g. 62701">
        </div>
        <div class="col-12 col-md-3">
          <label class="cc-form-label">Country</label>
          <input type="text" name="country" class="cc-input" value="United States" placeholder="e.g. United States">
        </div>
      </div>

      <!-- Emergency Contact (Duty of Care) -->
      <div class="cc-inner-card">
        <div class="cc-inner-title">
          <i data-lucide="shield-alert" style="width: 16px; height: 16px; color: #4f46e5;"></i>
          <span>Emergency Contact (Duty of Care)</span>
        </div>
        <div class="row g-3">
          <div class="col-12 col-md-4">
            <label class="cc-form-label">Contact Person Name</label>
            <input type="text" name="emergency_contact_name" class="cc-input" placeholder="e.g. John Smith">
          </div>
          <div class="col-12 col-md-4">
            <label class="cc-form-label">Relationship</label>
            <input type="text" name="emergency_contact_relation" class="cc-input" placeholder="e.g. Spouse / Parent / Sibling">
          </div>
          <div class="col-12 col-md-4">
            <label class="cc-form-label">Emergency Phone</label>
            <input type="text" name="emergency_contact_phone" class="cc-input" placeholder="e.g. +1 (555) 987-6543">
          </div>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 3: 3. INSTITUTIONAL PLACEMENT & QUALIFICATIONS
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>3. INSTITUTIONAL PLACEMENT & QUALIFICATIONS</span>
      </div>

      <!-- Placement Row (3 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Designation / Job Title</label>
          <input type="text" name="designation_title" class="cc-input" placeholder="e.g. Senior English Teacher">
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Department</label>
          <select name="department_id" class="cc-input form-select">
            <option value="">Select department...</option>
            <?php foreach (($departments ?? []) as $d): ?>
              <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Joined Date</label>
          <div class="cc-input-group">
            <input type="date" name="joining_date" class="cc-input" value="<?= date('Y-m-d') ?>">
            <i data-lucide="calendar" class="cc-input-icon" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
      </div>

      <!-- Category & Employment Model Row (2 cols) -->
      <div class="row g-3 mb-4">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Staff Category</label>
          <select name="staff_category" class="cc-input form-select">
            <option value="">Select category...</option>
            <option value="Teaching" selected>Teaching</option>
            <option value="Non-Teaching">Non-Teaching</option>
            <option value="Administrative">Administrative</option>
            <option value="Support">Support</option>
            <option value="Management">Management</option>
          </select>
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Employment Model</label>
          <select name="employment_model" class="cc-input form-select">
            <option value="">Select employment model...</option>
            <option value="Full-time" selected>Full-time</option>
            <option value="Part-time">Part-time</option>
            <option value="Contract">Contract</option>
            <option value="Temporary">Temporary</option>
            <option value="Visiting">Visiting / Adjunct</option>
          </select>
        </div>
      </div>

      <!-- Academic Qualifications Sub-section -->
      <div class="cc-inner-card">
        <div class="cc-inner-title">
          <i data-lucide="graduation-cap" style="width: 16px; height: 16px; color: #4f46e5;"></i>
          <span>Academic Qualifications</span>
        </div>
        <div class="row g-3">
          <div class="col-12 col-md-6">
            <label class="cc-form-label">Highest Degree Earned</label>
            <input type="text" name="highest_degree" class="cc-input" placeholder="e.g. Master of Arts in English, M.Ed, B.Sc">
          </div>
          <div class="col-12 col-md-6">
            <label class="cc-form-label">Primary Subject / Specialization</label>
            <input type="text" name="specialization" class="cc-input" placeholder="e.g. Literature, AP Chemistry, Special Education">
          </div>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 4: 4. STATUTORY & REGIONAL INFORMATION
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>4. STATUTORY & REGIONAL INFORMATION</span>
        <span class="cc-pill-badge">Preset: India (IN)</span>
      </div>
      <p class="text-muted small mb-3">Statutory verification compliant with Ministry of Education UDISE+ Teacher Module and CBSE norms.</p>

      <!-- Row 1: NTC, Aadhaar, PAN (3 cols) -->
      <div class="row g-3 mb-3">
        <div class="col-12 col-md-4">
          <label class="cc-form-label">National Teacher Code (NTC)</label>
          <input type="text" name="ntc_code" class="cc-input" placeholder="e.g. TC-9123481">
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Aadhaar Number (or Last 4 Digits)</label>
          <input type="text" name="aadhaar_no" class="cc-input" placeholder="e.g. XXXX-XXXX-4819">
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">PAN Number (Tax ID)</label>
          <input type="text" name="pan_no" class="cc-input" placeholder="e.g. ABCDE1234F">
        </div>
      </div>

      <!-- Row 2: Social Category, Teacher Cadre, Professional Degree (3 cols) -->
      <div class="row g-3">
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Social Category (UDISE+)</label>
          <select name="social_category" class="cc-input form-select">
            <option value="General" selected>General</option>
            <option value="OBC">OBC</option>
            <option value="SC">SC</option>
            <option value="ST">ST</option>
          </select>
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Teacher Cadre / Teaching Level</label>
          <select name="teaching_level" class="cc-input form-select">
            <option value="PRT">PRT (Primary Teacher: Grades 1-5)</option>
            <option value="TGT">TGT (Trained Graduate Teacher: Grades 6-10)</option>
            <option value="PGT">PGT (Post Graduate Teacher: Grades 11-12)</option>
            <option value="Non-Teaching">Non-Teaching / Support</option>
          </select>
        </div>
        <div class="col-12 col-md-4">
          <label class="cc-form-label">Professional Teaching Degree</label>
          <select name="teaching_degree" class="cc-input form-select">
            <option value="B.Ed" selected>B.Ed (Bachelor of Education)</option>
            <option value="D.El.Ed">D.El.Ed (Diploma in Elementary Education)</option>
            <option value="M.Ed">M.Ed (Master of Education)</option>
            <option value="None">None / Other</option>
          </select>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 5: 5. ACCOUNT ACCESS & SECURITY
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>5. ACCOUNT ACCESS & SECURITY</span>
      </div>

      <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Assigned System Role</label>
          <select name="role_id" id="assignedRoleSelect" class="cc-input form-select" onchange="handleRoleChange(this)">
            <option value="">No System Role Assigned</option>
            <?php foreach (($roles ?? []) as $r): ?>
              <?php $isAcc = in_array($r['slug'], ['accountant', 'finance'], true); ?>
              <option value="<?= (int)$r['id'] ?>" data-slug="<?= e($r['slug']) ?>" <?= $r['slug'] === 'accountant' ? 'selected' : '' ?>>
                <?= e($r['name']) ?> <?= $isAcc ? '★ (Accountant / Finance Access)' : '' ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-6">
          <label class="cc-form-label">Profile Status <span class="req">*</span></label>
          <select name="status" class="cc-input form-select" required>
            <option value="active" selected>Active</option>
            <option value="on_leave">On Leave</option>
            <option value="suspended">Suspended</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      <!-- Role-specific banner for Accountant -->
      <div id="accountantRoleBanner" class="alert alert-primary border-0 rounded-3 p-3 mb-3" style="background:#eff6ff; color:#1e40af; border:1px solid #dbeafe !important;">
        <div class="d-flex align-items-center gap-2 mb-1">
          <i data-lucide="shield-check" style="width:18px;height:18px;color:#2563eb;"></i>
          <span class="fw-bold" style="font-size:13px;">Accountant / Finance Access Selected</span>
        </div>
        <div style="font-size:12px; line-height:1.5;">
          This staff member will have direct access to the <strong>Accountant Dashboard</strong>, Fee Structures, Invoices, Payment Collection, Expenses, and Defaulters Reports. Their login credentials will be displayed immediately after saving.
        </div>
      </div>

      <!-- Portal Login Account Checkbox & Password Generator -->
      <div class="pt-3 border-top">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="form-check mb-0">
            <input class="form-check-input" type="checkbox" name="create_user_account" id="createUserAccount" value="1" checked onchange="toggleAccountPassword(this)">
            <label class="form-check-label fw-semibold text-dark" for="createUserAccount" style="font-size: 13.5px;">
              Create Portal Login Account &amp; Access
            </label>
          </div>
          <span class="badge bg-success-subtle text-success px-2 py-1 rounded" style="font-size: 11px;">Active on Save</span>
        </div>
        <div class="text-muted small mb-3" style="margin-left: 1.5rem; font-size: 12px;">
          The staff member will use their email address as their Login ID. A popup with complete login credentials (Username, Password, School Code, Login Link) will appear once saved.
        </div>

        <div id="passwordFieldWrap" style="margin-left: 1.5rem;">
          <div class="row g-3 align-items-center">
            <div class="col-12 col-md-6">
              <label class="cc-form-label mb-1">Account Login Password</label>
              <div class="input-group">
                <input type="text" name="password" id="staffAccountPassword" class="cc-input" placeholder="Enter password (or click Generate)" value="Staff@123" style="border-top-right-radius:0; border-bottom-right-radius:0;">
                <button type="button" class="btn btn-outline-secondary px-3" id="togglePasswordBtn" onclick="toggleStaffPasswordVisibility()" title="Toggle View" style="border-color:#e2e8f0; background:#f8fafc;">
                  <i data-lucide="eye" id="togglePasswordIcon" style="width:16px;height:16px;"></i>
                </button>
                <button type="button" class="btn btn-outline-primary px-3 fw-medium" onclick="generateRandomStaffPassword()" title="Generate Random Password" style="border-color:#cbd5e1; font-size:12px;">
                  <i data-lucide="refresh-cw" style="width:14px;height:14px;"></i> Generate
                </button>
              </div>
              <div class="d-flex align-items-center justify-content-between mt-1">
                <div class="text-muted" style="font-size: 11px;">
                  Tip: Leave as default or generate a unique password. You will see it after saving!
                </div>
                <button type="button" class="btn btn-link p-0 text-decoration-none text-primary" style="font-size: 11px;" onclick="copyPasswordToClipboard()">
                  <i data-lucide="copy" style="width: 12px; height: 12px;"></i> Copy
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ==========================================
         CARD 6: 6. DOCUMENTS & VERIFICATION
         ========================================== -->
    <div class="cc-staff-card">
      <div class="cc-form-section-title">
        <span>6. DOCUMENTS & VERIFICATION</span>
      </div>

      <!-- Upload Row -->
      <div class="row g-2 mb-3 align-items-end">
        <div class="col-12 col-md-9">
          <label class="cc-form-label">Document Name</label>
          <input type="text" name="doc_name" id="docNameInput" class="cc-input" placeholder="e.g. Academic, Resume, Certifications, Contract">
        </div>
        <div class="col-12 col-md-3">
          <button type="button" class="btn btn-outline-secondary w-100 fw-semibold" style="height: 40px; border-radius: 8px; border-color: #cbd5e1; font-size: 13px;" onclick="document.getElementById('docFileInput').click();">
            Upload
          </button>
          <input type="file" name="staff_doc" id="docFileInput" style="display:none;" onchange="handleDocSelected(this)">
        </div>
      </div>

      <!-- Empty State / File List -->
      <div class="cc-empty-docs" id="emptyDocsNotice">
        <i data-lucide="file-text" style="width: 28px; height: 28px; color: #94a3b8; display: block; margin: 0 auto 0.5rem;"></i>
        <span>No documents uploaded yet.</span>
      </div>
      <div id="selectedDocList" style="display:none;" class="p-3 bg-white border rounded-3 mt-2"></div>
    </div>

    <!-- ==========================================
         FORM FOOTER (CANCEL & SAVE STAFF MEMBER)
         ========================================== -->
    <div class="d-flex align-items-center justify-content-end gap-2 pt-2">
      <a href="<?= e(url('staff')) ?>" class="btn cc-btn-cancel text-decoration-none">Cancel</a>
      <button type="submit" class="btn cc-btn-submit">Save Staff Member</button>
    </div>

  </form>
</div>

<script>
function previewStaffPhoto(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('staffPhotoPreview');
            const placeholder = document.getElementById('staffPhotoPlaceholder');
            preview.src = e.target.result;
            preview.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function toggleAccountPassword(checkbox) {
    const wrap = document.getElementById('passwordFieldWrap');
    if (wrap) {
        wrap.style.display = checkbox.checked ? 'block' : 'none';
    }
}

function handleRoleChange(select) {
    const selectedOption = select.options[select.selectedIndex];
    const slug = selectedOption ? (selectedOption.getAttribute('data-slug') || '') : '';
    const banner = document.getElementById('accountantRoleBanner');
    if (banner) {
        if (slug === 'accountant' || slug === 'finance') {
            banner.style.display = 'block';
        } else {
            banner.style.display = 'none';
        }
    }
}

function toggleStaffPasswordVisibility() {
    const pwd = document.getElementById('staffAccountPassword');
    const icon = document.getElementById('togglePasswordIcon');
    if (pwd.type === 'password') {
        pwd.type = 'text';
        if (icon) icon.setAttribute('data-lucide', 'eye-off');
    } else {
        pwd.type = 'password';
        if (icon) icon.setAttribute('data-lucide', 'eye');
    }
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function generateRandomStaffPassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    let rand = '';
    for (let i = 0; i < 4; i++) {
        rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const generated = 'Acc#' + rand + '!';
    const pwdInput = document.getElementById('staffAccountPassword');
    pwdInput.type = 'text';
    pwdInput.value = generated;
    pwdInput.focus();
    pwdInput.select();
    
    // Quick notification
    copyPasswordToClipboard(true);
}

function copyPasswordToClipboard(isSilent = false) {
    const pwd = document.getElementById('staffAccountPassword').value;
    if (!pwd) return;
    navigator.clipboard.writeText(pwd).then(() => {
        if (!isSilent) {
            alert('Password copied to clipboard: ' + pwd);
        }
    }).catch(() => {});
}

function handleDocSelected(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const emptyNotice = document.getElementById('emptyDocsNotice');
        const list = document.getElementById('selectedDocList');
        const docName = document.getElementById('docNameInput').value || file.name;

        emptyNotice.style.display = 'none';
        list.style.display = 'flex';
        list.className = 'd-flex align-items-center justify-content-between p-2.5 bg-white border rounded-3 mt-2';
        list.innerHTML = `
            <div class="d-flex align-items-center gap-2">
                <i data-lucide="file-check" style="width: 18px; height: 18px; color: #10b981;"></i>
                <div>
                    <div class="fw-semibold text-dark" style="font-size: 13px;">${docName}</div>
                    <div class="text-muted" style="font-size: 11px;">${(file.size / 1024).toFixed(1)} KB &bull; Ready to upload</div>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-link text-danger p-0" onclick="clearSelectedDoc()">
                <i data-lucide="trash-2" style="width: 15px; height: 15px;"></i>
            </button>
        `;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }
}

function clearSelectedDoc() {
    document.getElementById('docFileInput').value = '';
    document.getElementById('selectedDocList').style.display = 'none';
    document.getElementById('emptyDocsNotice').style.display = 'block';
}

document.addEventListener('DOMContentLoaded', function() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
</script>
