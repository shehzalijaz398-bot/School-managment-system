<?php
$emp = $employee ?? [];
$fullName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
$empCode = $emp['employee_code'] ?? 'EMP-N/A';
$dept = $emp['department_name'] ?? 'General Staff';
$designation = $emp['designation_name'] ?? 'Staff Member';
$status = strtolower((string)($emp['status'] ?? 'active'));
$joiningDate = !empty($emp['joining_date']) ? date('M d, Y', strtotime((string)$emp['joining_date'])) : 'N/A';
$salary = (float)($salary_structure['basic_salary'] ?? ($emp['basic_salary'] ?? 0));
$email = $emp['email'] ?? ($emp['user_email'] ?? 'N/A');
$phone = $emp['phone'] ?? ($emp['user_phone'] ?? 'N/A');
$activeTab = $_GET['tab'] ?? 'schedule';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div class="d-flex align-items-center gap-3">
    <a href="<?= e(url('staff')) ?>" class="btn btn-outline-secondary btn-sm rounded-circle p-1" style="width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;">
      <i data-lucide="arrow-left" style="width:18px;height:18px;"></i>
    </a>
    <div class="d-flex align-items-center gap-3">
      <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-4 shadow-sm" style="width:52px;height:52px;">
        <?= strtoupper(substr($fullName ?: 'E', 0, 1)) ?>
      </div>
      <div>
        <h2 class="mb-0 fw-bold text-dark fs-4"><?= e($fullName) ?></h2>
        <div class="d-flex align-items-center gap-2 mt-1 text-muted small">
          <span class="badge bg-light text-dark border font-monospace"><?= e($empCode) ?></span>
          <span>&bull;</span>
          <span><?= e($designation) ?> &middot; <?= e($dept) ?></span>
          <span>&bull;</span>
          <span class="badge <?= $status === 'active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' ?> text-uppercase" style="font-size:10px;">
            <?= e($status) ?>
          </span>
          <?php if (!empty($emp['shift_name'])): ?>
            <span>&bull;</span>
            <span class="badge bg-info-subtle text-info border border-info-subtle" style="font-size:10px;">
              <i class="bi bi-clock me-1"></i><?= e($emp['shift_name']) ?>
            </span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex gap-2">
    <?php if (hasPermission('employees.manage')): ?>
      <button type="button" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#addQualificationModal">
        <i data-lucide="graduation-cap" style="width:14px;height:14px;"></i> + Qualification
      </button>
      <button type="button" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#addContractModal">
        <i data-lucide="file-text" style="width:14px;height:14px;"></i> + Contract
      </button>
      <a href="<?= e(url('hr/employees/' . $emp['id'] . '/edit')) ?>" class="btn btn-primary btn-sm d-flex align-items-center gap-1 px-3 shadow-sm">
        <i data-lucide="edit" style="width:14px;height:14px;"></i> Edit Staff Record
      </a>
    <?php endif; ?>
  </div>
</div>

<!-- Metrics Matrix -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-success">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Attendance Rate</div>
      <div class="fs-4 fw-bold text-success mt-1"><?= $attendance_rate ?>%</div>
      <div class="text-muted" style="font-size:11px;"><?= (int)$attendance_counts['present'] ?> Present in last 90 days</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-primary">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Basic Salary</div>
      <div class="fs-4 fw-bold text-dark mt-1"><?= formatMoney($salary) ?></div>
      <div class="text-muted" style="font-size:11px;">Monthly Base Compensation</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-info">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Teaching Workload</div>
      <div class="fs-4 fw-bold text-info mt-1"><?= count($timetableSlots ?? []) ?></div>
      <div class="text-muted" style="font-size:11px;">Weekly Scheduled Periods</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white border-start border-4 border-warning">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size:11px;">Tenure / Joining</div>
      <div class="fs-5 fw-bold text-dark mt-1"><?= e($joiningDate) ?></div>
      <div class="text-muted" style="font-size:11px;">Official Appointment Record</div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Left Column: Personal & Employment Dossier -->
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white">
      <div class="card-header bg-white border-bottom pt-3 pb-2 px-4">
        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
          <i data-lucide="user" class="text-primary" style="width:16px;height:16px;"></i> Employment Dossier
        </h6>
      </div>
      <div class="card-body p-4">
        <div class="mb-3">
          <div class="text-muted small">Official Email</div>
          <div class="fw-semibold text-dark"><?= e($email) ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Contact Phone</div>
          <div class="fw-semibold text-dark"><?= e($phone) ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Department & Unit</div>
          <div class="fw-semibold text-dark"><?= e($dept) ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Designation Title</div>
          <div class="fw-semibold text-dark"><?= e($designation) ?></div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Shift & Work Timings</div>
          <div class="fw-semibold text-dark">
            <?= !empty($emp['shift_name']) ? e($emp['shift_name'] . ' (' . date('h:i A', strtotime($emp['shift_start'])) . ' - ' . date('h:i A', strtotime($emp['shift_end'])) . ')') : 'Standard Campus Shift' ?>
          </div>
        </div>
        <div class="mb-3">
          <div class="text-muted small">Portal Access Account</div>
          <div>
            <?php if (!empty($emp['user_id'])): ?>
              <span class="badge bg-success-subtle text-success">Active Portal User</span>
              <span class="text-muted small ms-1">(<?= e($emp['role_name'] ?? 'Staff') ?>)</span>
            <?php else: ?>
              <span class="badge bg-light text-muted border">No Portal Login</span>
            <?php endif; ?>
          </div>
        </div>
        <?php if (!empty($emp['address'])): ?>
          <div class="mb-0">
            <div class="text-muted small">Residential Address</div>
            <div class="small text-secondary"><?= e($emp['address']) ?></div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Leave Quota Summary Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white">
      <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
          <i data-lucide="calendar-check" class="text-success" style="width:16px;height:16px;"></i> Leave Balances (<?= date('Y') ?>)
        </h6>
        <a href="<?= url('leave') ?>" class="small text-primary text-decoration-none">Leave Hub</a>
      </div>
      <div class="card-body p-4">
        <?php if (empty($leave_balances)): ?>
          <p class="small text-muted mb-0">No leave quotas allocated for this employee.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-sm align-middle mb-0" style="font-size: 12px;">
              <thead class="text-muted">
                <tr>
                  <th>Leave Type</th>
                  <th class="text-center">Total</th>
                  <th class="text-center">Used</th>
                  <th class="text-end">Balance</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($leave_balances as $lb): ?>
                  <tr>
                    <td class="fw-semibold text-dark"><?= htmlspecialchars($lb['leave_type_name']) ?></td>
                    <td class="text-center text-muted"><?= (float)$lb['allocated_days'] ?></td>
                    <td class="text-center text-danger"><?= (float)$lb['used_days'] ?></td>
                    <td class="text-end fw-bold text-success"><?= (float)$lb['remaining_days'] ?> d</td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right Column: Tabbed Modules -->
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
      <div class="card-header bg-white border-bottom p-2">
        <ul class="nav nav-tabs border-0 flex-nowrap overflow-x-auto" id="staffTabs" role="tablist">
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'schedule') ? 'active' : '' ?> fw-semibold small text-nowrap" id="schedule-tab" data-bs-toggle="tab" data-bs-target="#schedule-pane" type="button" role="tab">
              <i data-lucide="calendar" style="width:14px;height:14px;" class="me-1"></i> Timetable (<?= count($timetableSlots ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'qualifications') ? 'active' : '' ?> fw-semibold small text-nowrap" id="qualifications-tab" data-bs-toggle="tab" data-bs-target="#qualifications-pane" type="button" role="tab">
              <i data-lucide="graduation-cap" style="width:14px;height:14px;" class="me-1"></i> Qualifications (<?= count($qualifications ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'contracts') ? 'active' : '' ?> fw-semibold small text-nowrap" id="contracts-tab" data-bs-toggle="tab" data-bs-target="#contracts-pane" type="button" role="tab">
              <i data-lucide="file-text" style="width:14px;height:14px;" class="me-1"></i> Contracts (<?= count($contracts ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'reviews') ? 'active' : '' ?> fw-semibold small text-nowrap" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews-pane" type="button" role="tab">
              <i data-lucide="award" style="width:14px;height:14px;" class="me-1"></i> Appraisals (<?= count($reviews ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'trainings') ? 'active' : '' ?> fw-semibold small text-nowrap" id="trainings-tab" data-bs-toggle="tab" data-bs-target="#trainings-pane" type="button" role="tab">
              <i data-lucide="mortarboard" style="width:14px;height:14px;" class="me-1"></i> Training (<?= count($trainings ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'tasks') ? 'active' : '' ?> fw-semibold small text-nowrap" id="tasks-tab" data-bs-toggle="tab" data-bs-target="#tasks-pane" type="button" role="tab">
              <i data-lucide="check-square" style="width:14px;height:14px;" class="me-1"></i> Tasks (<?= count($tasks ?? []) ?>)
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'payroll') ? 'active' : '' ?> fw-semibold small text-nowrap" id="payroll-tab" data-bs-toggle="tab" data-bs-target="#payroll-pane" type="button" role="tab">
              <i data-lucide="receipt" style="width:14px;height:14px;" class="me-1"></i> Payroll History
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'leaves') ? 'active' : '' ?> fw-semibold small text-nowrap" id="leaves-tab" data-bs-toggle="tab" data-bs-target="#leaves-pane" type="button" role="tab">
              <i data-lucide="clock" style="width:14px;height:14px;" class="me-1"></i> Leaves
            </button>
          </li>
          <li class="nav-item">
            <button class="nav-link <?= ($activeTab === 'activity') ? 'active' : '' ?> fw-semibold small text-nowrap" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity-pane" type="button" role="tab">
              <i data-lucide="activity" style="width:14px;height:14px;" class="me-1"></i> Timeline
            </button>
          </li>
        </ul>
      </div>

      <div class="card-body p-4">
        <div class="tab-content" id="staffTabContent">
          <!-- Timetable Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'schedule') ? 'show active' : '' ?>" id="schedule-pane" role="tabpanel">
            <?php if (empty($timetableSlots)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="calendar-off" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No teaching timetable entries assigned to this staff member.</p>
              </div>
            <?php else: 
              $dayNames = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'];
            ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Day</th>
                      <th>Period & Time</th>
                      <th>Class & Section</th>
                      <th>Subject</th>
                      <th>Room</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($timetableSlots as $tt): ?>
                      <tr>
                        <td class="fw-bold small"><?= $dayNames[(int)$tt['day_of_week']] ?? 'Day ' . $tt['day_of_week'] ?></td>
                        <td>
                          <div class="small fw-semibold text-dark"><?= e($tt['period_name']) ?></div>
                          <div class="text-muted" style="font-size:11px;"><?= e($tt['start_time']) ?> - <?= e($tt['end_time']) ?></div>
                        </td>
                        <td class="small fw-semibold"><?= e($tt['class_name']) ?> <?= e($tt['section_name'] ? '('.$tt['section_name'].')' : '') ?></td>
                        <td class="small text-primary fw-medium"><?= e($tt['subject_name']) ?></td>
                        <td class="small text-muted font-monospace"><?= e($tt['room'] ?: 'Main') ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Qualifications Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'qualifications') ? 'show active' : '' ?>" id="qualifications-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="fw-bold text-dark mb-0">Academic &amp; Professional Qualifications</h6>
              <button type="button" class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#addQualificationModal">
                <i class="bi bi-plus-lg me-1"></i> Add Qualification
              </button>
            </div>
            <?php if (empty($qualifications)): ?>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-mortarboard text-muted fs-2 d-block mb-2"></i>
                <p class="small mb-0">No academic qualifications recorded yet.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="table-light">
                    <tr>
                      <th>Degree / Certificate</th>
                      <th>Institution / University</th>
                      <th>Passing Year</th>
                      <th>Grade / GPA</th>
                      <th class="text-end">Document</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($qualifications as $q): ?>
                      <tr>
                        <td class="fw-bold text-dark"><?= htmlspecialchars($q['degree_title']) ?></td>
                        <td><?= htmlspecialchars($q['institution']) ?></td>
                        <td><span class="badge bg-light border text-dark"><?= (int)$q['passing_year'] ?></span></td>
                        <td><?= htmlspecialchars($q['grade_or_gpa'] ?: 'Passed') ?></td>
                        <td class="text-end">
                          <?php if (!empty($q['document_path'])): ?>
                            <a href="<?= url($q['document_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill py-0 px-2">
                              <i class="bi bi-file-earmark-arrow-down me-1"></i> View
                            </a>
                          <?php else: ?>
                            <span class="text-muted small">None</span>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Contracts Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'contracts') ? 'show active' : '' ?>" id="contracts-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="fw-bold text-dark mb-0">Employment Contracts &amp; Terms</h6>
              <button type="button" class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#addContractModal">
                <i class="bi bi-plus-lg me-1"></i> Add Contract
              </button>
            </div>
            <?php if (empty($contracts)): ?>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-file-text text-muted fs-2 d-block mb-2"></i>
                <p class="small mb-0">No formal contracts logged for this staff member.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="table-light">
                    <tr>
                      <th>Contract Type</th>
                      <th>Validity Period</th>
                      <th>Basic Salary</th>
                      <th>Notice Period</th>
                      <th>Status</th>
                      <th class="text-end">Document</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($contracts as $c): ?>
                      <tr>
                        <td>
                          <span class="badge bg-primary-subtle text-primary text-uppercase px-2 py-1"><?= htmlspecialchars($c['contract_type']) ?></span>
                        </td>
                        <td>
                          <div class="fw-semibold text-dark"><?= date('M d, Y', strtotime($c['start_date'])) ?></div>
                          <div class="text-muted small"><?= !empty($c['end_date']) ? ('Expires: ' . date('M d, Y', strtotime($c['end_date']))) : 'Indefinite / Permanent' ?></div>
                        </td>
                        <td class="fw-bold text-dark"><?= formatMoney((float)$c['basic_salary']) ?></td>
                        <td><?= (int)$c['notice_period_days'] ?> days</td>
                        <td>
                          <span class="badge bg-success-subtle text-success text-capitalize"><?= htmlspecialchars($c['status']) ?></span>
                        </td>
                        <td class="text-end">
                          <?php if (!empty($c['document_path'])): ?>
                            <a href="<?= url($c['document_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill py-0 px-2">
                              <i class="bi bi-download me-1"></i> View
                            </a>
                          <?php else: ?>
                            <span class="text-muted small">None</span>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Performance Reviews Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'reviews') ? 'show active' : '' ?>" id="reviews-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="fw-bold text-dark mb-0">Faculty Appraisals &amp; Review History</h6>
              <a href="<?= url('hr/performance?employee_id=' . $emp['id']) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                Conduct New Appraisal &rarr;
              </a>
            </div>
            <?php if (empty($reviews)): ?>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-star text-muted fs-2 d-block mb-2"></i>
                <p class="small mb-0">No performance appraisals conducted for this employee yet.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="table-light">
                    <tr>
                      <th>Review Period</th>
                      <th>Review Date</th>
                      <th>Overall Rating</th>
                      <th>Pedagogy</th>
                      <th>Punctuality</th>
                      <th>Compliance</th>
                      <th>Teamwork</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($reviews as $rev): ?>
                      <tr>
                        <td class="fw-semibold text-dark"><?= htmlspecialchars($rev['review_period']) ?></td>
                        <td><?= date('M d, Y', strtotime($rev['review_date'])) ?></td>
                        <td>
                          <span class="badge bg-warning text-dark fw-bold"><?= number_format((float)$rev['overall_rating'], 2) ?> ★</span>
                        </td>
                        <td><?= number_format((float)$rev['pedagogy_rating'], 1) ?></td>
                        <td><?= number_format((float)$rev['punctuality_rating'], 1) ?></td>
                        <td><?= number_format((float)$rev['compliance_rating'], 1) ?></td>
                        <td><?= number_format((float)$rev['teamwork_rating'], 1) ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Training Records Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'trainings') ? 'show active' : '' ?>" id="trainings-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="fw-bold text-dark mb-0">Professional Development &amp; Training</h6>
              <a href="<?= url('hr/trainings?employee_id=' . $emp['id']) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                Record Training &rarr;
              </a>
            </div>
            <?php if (empty($trainings)): ?>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-mortarboard text-muted fs-2 d-block mb-2"></i>
                <p class="small mb-0">No training sessions recorded for this staff member.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="table-light">
                    <tr>
                      <th>Workshop / Title</th>
                      <th>Provider</th>
                      <th>Category</th>
                      <th>Hours</th>
                      <th>Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($trainings as $tr): ?>
                      <tr>
                        <td class="fw-semibold text-dark"><?= htmlspecialchars($tr['title']) ?></td>
                        <td><?= htmlspecialchars($tr['provider']) ?></td>
                        <td><span class="badge bg-light border text-dark"><?= htmlspecialchars($tr['category']) ?></span></td>
                        <td><?= (float)$tr['hours'] ?> hrs</td>
                        <td><?= date('M d, Y', strtotime($tr['start_date'])) ?></td>
                        <td>
                          <span class="badge bg-success-subtle text-success text-capitalize"><?= htmlspecialchars($tr['status']) ?></span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Tasks Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'tasks') ? 'show active' : '' ?>" id="tasks-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="fw-bold text-dark mb-0">Delegated Tasks &amp; Deadlines</h6>
              <a href="<?= url('hr/tasks?employee_id=' . $emp['id']) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                Assign Task &rarr;
              </a>
            </div>
            <?php if (empty($tasks)): ?>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-check2-square text-muted fs-2 d-block mb-2"></i>
                <p class="small mb-0">No pending or delegated tasks assigned to this employee.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="table-light">
                    <tr>
                      <th>Task Title</th>
                      <th>Priority</th>
                      <th>Due Date</th>
                      <th>Status</th>
                      <th class="text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($tasks as $tsk): ?>
                      <tr>
                        <td class="fw-semibold text-dark"><?= htmlspecialchars($tsk['title']) ?></td>
                        <td>
                          <span class="badge bg-light text-dark border text-uppercase" style="font-size: 10px;"><?= htmlspecialchars($tsk['priority']) ?></span>
                        </td>
                        <td><?= date('M d, Y', strtotime($tsk['due_date'])) ?></td>
                        <td>
                          <span class="badge bg-primary-subtle text-primary text-capitalize"><?= str_replace('_', ' ', $tsk['status']) ?></span>
                        </td>
                        <td class="text-end">
                          <?php if ($tsk['status'] !== 'completed'): ?>
                            <form method="POST" action="<?= url('hr/tasks/' . $tsk['id'] . '/status') ?>" class="d-inline">
                              <?= csrf_field() ?>
                              <input type="hidden" name="status" value="completed">
                              <button type="submit" class="btn btn-sm btn-outline-success rounded-pill py-0 px-2" style="font-size: 11px;">
                                Mark Done
                              </button>
                            </form>
                          <?php else: ?>
                            <span class="text-success small"><i class="bi bi-check-circle-fill"></i></span>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Payroll Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'payroll') ? 'show active' : '' ?>" id="payroll-pane" role="tabpanel">
            <?php if (empty($payrolls)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="receipt" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No past payslips generated for this employee.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Month</th>
                      <th class="text-end">Base Salary</th>
                      <th class="text-end">Allowances</th>
                      <th class="text-end">Deductions</th>
                      <th class="text-end">Net Pay</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($payrolls as $py): ?>
                      <tr>
                        <td class="fw-semibold small"><?= e($py['month']) ?></td>
                        <td class="text-end small"><?= formatMoney((float)($py['basic_salary'] ?? 0)) ?></td>
                        <td class="text-end small text-success">+<?= formatMoney((float)($py['allowances'] ?? 0)) ?></td>
                        <td class="text-end small text-danger">-<?= formatMoney((float)($py['deductions'] ?? 0)) ?></td>
                        <td class="text-end fw-bold small text-dark"><?= formatMoney((float)($py['net_salary'] ?? 0)) ?></td>
                        <td class="text-center">
                          <span class="badge bg-success-subtle text-success text-uppercase" style="font-size:10px;">
                            <?= e($py['status'] ?? 'PAID') ?>
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Leaves Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'leaves') ? 'show active' : '' ?>" id="leaves-pane" role="tabpanel">
            <?php if (empty($leaves)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="calendar" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No recorded leaves taken by this employee.</p>
              </div>
            <?php else: ?>
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                  <thead class="bg-light text-muted small">
                    <tr>
                      <th>Leave Type</th>
                      <th>Duration</th>
                      <th>Days</th>
                      <th>Status</th>
                      <th>Reason</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($leaves as $lv): ?>
                      <tr>
                        <td class="small fw-semibold"><?= e($lv['leave_type_name'] ?? 'General') ?></td>
                        <td class="small text-muted">
                          <?= date('M d, Y', strtotime((string)$lv['start_date'])) ?> &rarr; <?= date('M d, Y', strtotime((string)$lv['end_date'])) ?>
                        </td>
                        <td class="small fw-bold"><?= (int)$lv['days'] ?></td>
                        <td>
                          <span class="badge <?= $lv['status'] === 'approved' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning-emphasis' ?> text-uppercase" style="font-size:10px;">
                            <?= e($lv['status']) ?>
                          </span>
                        </td>
                        <td class="small text-secondary text-truncate" style="max-width:180px;"><?= e($lv['reason'] ?? '') ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Activity & Audit Timeline Pane -->
          <div class="tab-pane fade <?= ($activeTab === 'activity') ? 'show active' : '' ?>" id="activity-pane" role="tabpanel">
            <?php if (empty($timeline_logs)): ?>
              <div class="text-center py-4 text-muted">
                <i data-lucide="activity" style="width:36px;height:36px;opacity:0.3;" class="mb-2"></i>
                <p class="small mb-0">No logged activity or audit actions recorded for this staff member yet.</p>
              </div>
            <?php else: ?>
              <div class="timeline p-2">
                <?php foreach ($timeline_logs as $log): ?>
                  <div class="d-flex gap-3 mb-3 pb-3 border-bottom border-light">
                    <div class="rounded-circle bg-info-subtle text-info d-flex align-items-center justify-content-center flex-shrink-0" style="width: 32px; height: 32px;">
                      <i data-lucide="clock" style="width: 15px; height: 15px;"></i>
                    </div>
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="fw-bold text-dark small text-capitalize"><?= e(str_replace(['.', '_'], ' ', $log['action'])) ?></span>
                        <span class="text-muted" style="font-size: 11px;"><?= date('M j, Y g:i A', strtotime($log['created_at'])) ?></span>
                      </div>
                      <div class="text-muted small mb-1">
                        Initiated by <strong class="text-dark"><?= e($log['author_name'] ?? 'System') ?></strong>
                        <?php if (!empty($log['author_role'])): ?>
                          <span class="badge bg-light text-secondary border ms-1" style="font-size: 10px;"><?= e($log['author_role']) ?></span>
                        <?php endif; ?>
                      </div>
                      <div class="small text-secondary">
                        Module: <code><?= e($log['module']) ?></code> &middot; Entity: <?= e($log['entity_type']) ?> #<?= (int) $log['entity_id'] ?>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Qualification Modal -->
<div class="modal fade" id="addQualificationModal" tabindex="-1" aria-labelledby="addQualificationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <form method="POST" action="<?= url("hr/employees/{$emp['id']}/qualifications") ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3 px-4">
          <h5 class="modal-title fw-bold text-dark" id="addQualificationModalLabel">Add Academic Qualification</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Degree / Certificate Title <span class="text-danger">*</span></label>
            <input type="text" name="degree_title" class="form-control" placeholder="e.g. Master of Science in Mathematics" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Awarding Institution / University <span class="text-danger">*</span></label>
            <input type="text" name="institution" class="form-control" placeholder="e.g. Stanford University" required>
          </div>
          <div class="row g-3 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Passing Year <span class="text-danger">*</span></label>
              <input type="number" name="passing_year" class="form-control" value="<?= date('Y') ?>" min="1970" max="<?= (int)date('Y') + 1 ?>" required>
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Grade / GPA / Division</label>
              <input type="text" name="grade_or_gpa" class="form-control" placeholder="e.g. 3.85 / 4.0 or First Class">
            </div>
          </div>
          <div class="mb-0">
            <label class="form-label small fw-semibold text-dark">Degree / Transcript Document (PDF, Image)</label>
            <input type="file" name="document" class="form-control" accept=".pdf,.png,.jpg,.jpeg">
          </div>
        </div>
        <div class="modal-footer border-top py-3 px-4">
          <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Qualification</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Add Contract Modal -->
<div class="modal fade" id="addContractModal" tabindex="-1" aria-labelledby="addContractModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <form method="POST" action="<?= url("hr/employees/{$emp['id']}/contracts") ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3 px-4">
          <h5 class="modal-title fw-bold text-dark" id="addContractModalLabel">Add Employment Contract</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Contract Classification <span class="text-danger">*</span></label>
            <select name="contract_type" class="form-select" required>
              <option value="permanent">Permanent / Full-Time</option>
              <option value="contract">Fixed-Term Contract</option>
              <option value="probation">Probationary Period</option>
              <option value="visiting">Visiting / Part-Time Faculty</option>
            </select>
          </div>
          <div class="row g-3 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Start Date <span class="text-danger">*</span></label>
              <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">End Date (Optional)</label>
              <input type="date" name="end_date" class="form-control">
            </div>
          </div>
          <div class="row g-3 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Basic Salary Compensation</label>
              <input type="number" step="0.01" name="basic_salary" class="form-control" value="<?= $salary ?>" min="0">
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Notice Period (Days)</label>
              <input type="number" name="notice_period_days" class="form-control" value="30" min="0">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Special Terms / Clauses</label>
            <textarea name="terms" rows="2" class="form-control" placeholder="Confidentiality, non-compete, or specific tenure terms..."></textarea>
          </div>
          <div class="mb-0">
            <label class="form-label small fw-semibold text-dark">Signed Agreement Scan (PDF, Image)</label>
            <input type="file" name="document" class="form-control" accept=".pdf,.png,.jpg,.jpeg">
          </div>
        </div>
        <div class="modal-footer border-top py-3 px-4">
          <button type="button" class="btn btn-light border rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Save Contract</button>
        </div>
      </form>
    </div>
  </div>
</div>
