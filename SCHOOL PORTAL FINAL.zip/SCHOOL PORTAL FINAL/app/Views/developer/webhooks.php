<div class="container-fluid py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="bi bi-code-square text-primary me-2"></i><?= htmlspecialchars($title) ?>
        </h1>
    </div>

    <!-- Active Webhooks & Setup Matrix -->
    <div class="row">
        <!-- Add Webhook Config -->
        <div class="col-lg-5 mb-4">
            <div class="card shadow border-left-primary h-100">
                <div class="card-header py-3 bg-light d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="bi bi-link-45deg me-2"></i> Register New Endpoint</h6>
                </div>
                <div class="card-body bg-white">
                    <form method="POST" action="<?= url('developer/webhooks/store') ?>" id="webhookForm">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark small text-uppercase">Target Endpoint URL</label>
                            <input type="url" class="form-control font-monospace text-primary border-primary border-opacity-25 shadow-sm" name="target_url" placeholder="https://api.yourdomain.com/webhook/receive" required>
                            <div class="form-text small text-muted"><i class="bi bi-info-circle me-1"></i> HTTPS endpoints are strongly recommended.</div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark small text-uppercase mb-2">Event Subscription Vectors</label>
                            <div class="p-3 border rounded bg-light border-secondary border-opacity-25">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="all" id="evtAll">
                                    <label class="form-check-label fw-bold text-danger" for="evtAll">All Platform Events (*)</label>
                                </div>
                                <hr class="my-2">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="invoice.created" id="evtInv" checked>
                                    <label class="form-check-label fw-bold text-secondary" for="evtInv">invoice.created</label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="student.admitted" id="evtStu">
                                    <label class="form-check-label fw-bold text-secondary" for="evtStu">student.admitted</label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="attendance.marked" id="evtAtt">
                                    <label class="form-check-label fw-bold text-secondary" for="evtAtt">attendance.marked</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="events[]" value="exam.graded" id="evtExm">
                                    <label class="form-check-label fw-bold text-secondary" for="evtExm">exam.graded</label>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info border-0 shadow-sm small">
                            <strong>Security Note:</strong> A secure <code>X-SaaS-Signature</code> header generated via HMAC-SHA256 will be appended to every dispatch using your unique Secret Token.
                        </div>

                        <div class="d-grid mt-3">
                            <button type="submit" class="btn btn-primary fw-bold shadow-sm">
                                Register Webhook Node
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Active Registries -->
        <div class="col-lg-7 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3 bg-dark">
                    <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-hdd-network-fill me-2"></i> Active Endpoint Registry</h6>
                </div>
                <div class="card-body bg-light p-0">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-hover table-bordered bg-white mb-0 align-middle">
                            <thead class="table-dark sticky-top" style="font-size: 0.85rem;">
                                <tr>
                                    <th class="ps-3">Target URL & Key</th>
                                    <th>Subscribed Events</th>
                                    <th class="text-center pe-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($webhooks as $w): ?>
                                <tr>
                                    <td class="ps-3">
                                        <div class="font-monospace text-primary fw-bold small text-truncate" style="max-width: 250px;" title="<?= htmlspecialchars($w['target_url']) ?>">
                                            <?= htmlspecialchars($w['target_url']) ?>
                                        </div>
                                        <div class="mt-1 small">
                                            <span class="text-muted fw-bold">Secret:</span> 
                                            <code class="text-danger fw-bold ms-1" style="cursor: pointer;" onclick="prompt('HMAC-SHA256 Secret Token:', '<?= htmlspecialchars($w['secret_token']) ?>')">whsec_••••••••••••</code>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                            $evts = json_decode($w['active_events'], true) ?? []; 
                                            foreach($evts as $e) {
                                                echo '<span class="badge bg-secondary me-1 mb-1 shadow-sm">' . htmlspecialchars($e) . '</span>';
                                            }
                                        ?>
                                    </td>
                                    <td class="text-center pe-3">
                                        <form method="POST" action="<?= url("developer/webhooks/{$w['id']}/delete") ?>" onsubmit="return confirm('WARNING: Destroying this webhook will permanently sever the API connection. Proceed?')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger border-0">
                                                <i class="bi bi-trash3-fill fs-5"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($webhooks)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-5"><i class="bi bi-braces fs-1 d-block mb-3 text-gray-300"></i> No webhooks registered.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dispatch Log Matrix -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-secondary d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-white"><i class="bi bi-terminal-fill me-2"></i> Operational Dispatch Matrix (Last 20)</h6>
            <span class="spinner-grow spinner-grow-sm text-info" role="status"></span>
        </div>
        <div class="card-body bg-black text-light p-0">
            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                <table class="table table-sm table-borderless table-hover mb-0" style="font-size: 0.8rem; font-family: 'Courier New', Courier, monospace;">
                    <thead class="sticky-top bg-dark text-white-50 border-bottom border-secondary">
                        <tr>
                            <th class="ps-3">Time</th>
                            <th>Event Vector</th>
                            <th>Endpoint URL</th>
                            <th>HTTP Code</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $log): ?>
                        <tr class="border-bottom border-secondary border-opacity-25">
                            <td class="text-white-50 ps-3">[<?= date('H:i:s', strtotime($log['attempted_at'])) ?>]</td>
                            <td class="text-info fw-bold"><?= htmlspecialchars($log['event_type']) ?></td>
                            <td class="text-warning text-truncate" style="max-width: 200px;" title="<?= htmlspecialchars($log['target_url']) ?>">
                                <?= htmlspecialchars($log['target_url']) ?>
                            </td>
                            <td>
                                <?php if($log['response_code'] >= 200 && $log['response_code'] < 300): ?>
                                    <span class="text-success fw-bold"><?= $log['response_code'] ?> OK</span>
                                <?php elseif($log['response_code'] === 0): ?>
                                    <span class="text-danger fw-bold">TIMEOUT</span>
                                <?php else: ?>
                                    <span class="text-danger fw-bold"><?= $log['response_code'] ?> ERR</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($log['status'] === 'delivered'): ?>
                                    <span class="badge bg-success rounded-0">DELIVERED</span>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded-0">FAILED</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($logs)): ?>
                        <tr><td colspan="5" class="text-center text-secondary py-4">Awaiting dispatch telemetry...</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('evtAll').addEventListener('change', function() {
        const checks = document.querySelectorAll('input[name="events[]"]:not(#evtAll)');
        checks.forEach(chk => chk.disabled = this.checked);
    });
</script>
