<div class="panel">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Attendance — <?= e($ctx['student']['first_name'].' '.$ctx['student']['last_name']) ?></h2>
    <div class="stat-card m-0" style="min-width:200px">
        <div class="label">Overall Attendance</div>
        <div class="value <?= $percentage >= 75 ? 'text-success' : 'text-danger' ?>"><?= e((string)$percentage) ?>%</div>
    </div>
  </div>

  <form method="GET" action="" class="mb-4">
      <div class="row align-items-end">
          <div class="col-md-4">
              <label class="form-label">Select Month</label>
              <select name="month" class="form-select" onchange="this.form.submit()">
                  <?php foreach ($months as $m): ?>
                      <option value="<?= e($m) ?>" <?= $m === $selectedMonth ? 'selected' : '' ?>>
                          <?= date('F Y', strtotime($m . '-01')) ?>
                      </option>
                  <?php endforeach; ?>
              </select>
          </div>
      </div>
  </form>

  <div class="widget-card border-0 shadow-sm">
      <h5 class="mb-3">Attendance for <?= date('F Y', strtotime($selectedMonth . '-01')) ?></h5>
      <?php if (empty($attendanceRows)): ?>
          <p class="text-muted">No attendance records found for this month.</p>
      <?php else: ?>
          <div class="table-responsive">
              <table class="table table-hover align-middle">
                  <thead>
                      <tr>
                          <th>Date</th>
                          <th>Day</th>
                          <th>Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($attendanceRows as $row): ?>
                          <?php 
                              $dateObj = new DateTime($row['attendance_date']);
                              $status = $row['status'];
                              $badgeClass = match($status) {
                                  'present' => 'bg-success',
                                  'absent' => 'bg-danger',
                                  'late' => 'bg-warning text-dark',
                                  'half_day' => 'bg-info',
                                  'leave' => 'bg-secondary',
                                  default => 'bg-light text-dark'
                              };
                          ?>
                          <tr>
                              <td><strong><?= $dateObj->format('d M, Y') ?></strong></td>
                              <td><?= $dateObj->format('l') ?></td>
                              <td>
                                  <span class="badge <?= $badgeClass ?> text-capitalize px-3 py-2" style="font-weight: 500; letter-spacing: 0.5px;">
                                      <?= e(str_replace('_', ' ', $status)) ?>
                                  </span>
                              </td>
                          </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      <?php endif; ?>
  </div>
</div>
