<?php $days = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun']; ?>
<div class="panel"><h2>Timetable</h2>
<table class="table table-sm"><thead><tr><th>Day</th><th>Time</th><th>Subject</th><th>Teacher</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e($days[(int)$r['day_of_week']] ?? '') ?></td><td><?= e(substr($r['start_time'],0,5).'-'.substr($r['end_time'],0,5)) ?></td><td><?= e($r['subject_name']) ?></td><td><?= e($r['teacher_name']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
