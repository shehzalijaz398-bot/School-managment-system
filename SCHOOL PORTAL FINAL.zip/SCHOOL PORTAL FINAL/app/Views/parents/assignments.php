<?php
// Forwards to modern student assignments portal with parent context
require_once dirname(__DIR__) . '/portal/student_assignments.php';
