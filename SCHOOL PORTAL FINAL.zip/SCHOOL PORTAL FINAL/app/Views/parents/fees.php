<div class="panel"><h2>Fee Status</h2>
<table class="table"><thead><tr><th>Invoice</th><th>Title</th><th>Total</th><th>Paid</th><th>Status</th></tr></thead><tbody>
<?php foreach ($invoices as $i): ?>
<tr><td><?= e($i['invoice_no']) ?></td><td><?= e($i['title']) ?></td><td><?= e(formatMoney($i['total_amount'])) ?></td><td><?= e(formatMoney($i['paid_amount'])) ?></td><td><?= statusBadge($i['status']) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
