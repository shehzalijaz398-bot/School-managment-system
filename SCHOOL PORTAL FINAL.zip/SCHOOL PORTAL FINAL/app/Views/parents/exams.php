<div class="panel"><h2>Exam Results</h2>
<?php foreach ($exams as $ex):
  $res = $service->studentResult((int)$ex['id'], (int)$ctx['student_id']);
  if (!$res['subjects']) continue;
?>
  <div class="border rounded p-3 mb-2">
    <strong><?= e($ex['name']) ?></strong>
    <div>Percentage: <?= e((string)$res['percentage']) ?>% · Grade: <?= e($res['grade']) ?></div>
    <a href="<?= e(url('exams/'.$ex['id'].'/report-card/'.$ctx['student_id'])) ?>">Report card</a>
  </div>
<?php endforeach; ?>
</div>
