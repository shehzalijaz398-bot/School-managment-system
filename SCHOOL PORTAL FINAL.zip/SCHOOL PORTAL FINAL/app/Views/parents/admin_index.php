<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex align-items-center gap-2">
    <div class="bg-primary bg-opacity-10 text-primary p-2 rounded-3">
      <i data-lucide="users"></i>
    </div>
    <h2 class="mb-0 h4 fw-bold text-dark">Parents & Guardians</h2>
  </div>
  <?php if (hasPermission('parents.create')): ?>
    <a href="<?= e(url('parents/create')) ?>" class="btn btn-primary d-flex align-items-center gap-2 px-4 py-2 shadow-sm rounded-pill">
      <i data-lucide="user-plus" style="width:18px;"></i> Add Parent/Guardian
    </a>
  <?php endif; ?>
</div>

<div class="panel border-0 shadow-sm p-4 mb-4 rounded-4">
  <form method="get" action="<?= e(url('parents')) ?>" class="row g-3 align-items-end">
    <div class="col-md-5">
      <label class="form-label small fw-semibold text-muted">Search Parent</label>
      <div class="input-group">
        <span class="input-group-text bg-white border-end-0 text-muted"><i data-lucide="search" style="width:16px;"></i></span>
        <input type="text" name="q" class="form-control border-start-0 ps-0" placeholder="Name, Email, or Phone..." value="<?= e($filters['q'] ?? '') ?>">
      </div>
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-outline-primary w-100 fw-semibold d-flex align-items-center justify-content-center gap-2">
        <i data-lucide="filter" style="width:16px;"></i> Filter
      </button>
    </div>
  </form>
</div>

<div class="panel border-0 shadow-sm p-0 overflow-hidden rounded-4">
  <div class="table-responsive">
    <table class="table table-hover table-borderless align-middle mb-0">
      <thead class="bg-light text-muted small text-uppercase" style="border-bottom: 2px solid #edf2f7;">
        <tr>
          <th class="ps-4 py-3 fw-semibold border-0">Name & Occupation</th>
          <th class="py-3 fw-semibold border-0">Contact</th>
          <th class="py-3 fw-semibold border-0">Linked Students</th>
          <th class="py-3 fw-semibold border-0">Status</th>
          <th class="pe-4 py-3 fw-semibold border-0 text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($parents)): ?>
          <tr><td colspan="5" class="text-center py-5 text-muted">No parents or guardians found.</td></tr>
        <?php else: ?>
          <?php foreach($parents as $p): ?>
            <tr class="border-bottom border-light" style="transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='rgba(2, 169, 216, 0.04)';" onmouseout="this.style.backgroundColor='transparent';">
              <td class="ps-4 py-3">
                <div class="d-flex align-items-center gap-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle text-white fw-bold shadow-sm" style="width:40px;height:40px;background:var(--sp-accent);">
                    <?= strtoupper(substr($p['first_name'], 0, 1)) ?>
                  </div>
                  <div>
                    <div class="fw-bold text-dark" style="font-size:0.95rem;"><?= e($p['first_name'] . ' ' . $p['last_name']) ?></div>
                    <div class="small text-muted"><?= e($p['occupation'] ?? 'Guardian') ?></div>
                  </div>
                </div>
              </td>
              <td class="py-3">
                <div class="small text-muted d-flex align-items-center gap-1 mb-1"><i data-lucide="mail" style="width:12px;"></i> <?= e($p['email'] ?? 'N/A') ?></div>
                <div class="small text-muted d-flex align-items-center gap-1"><i data-lucide="phone" style="width:12px;"></i> <?= e($p['phone'] ?? 'N/A') ?></div>
              </td>
              <td class="py-3">
                <?php if(!empty($p['children'])): ?>
                  <div class="d-flex flex-column gap-1">
                    <?php foreach($p['children'] as $child): ?>
                      <a href="<?= e(url('students/'.$child['id'])) ?>" class="text-decoration-none fw-semibold text-primary" style="font-size:0.85rem;">
                        <i data-lucide="user" style="width:12px;margin-right:2px;"></i> <?= e($child['first_name'] . ' ' . $child['last_name']) ?> 
                        <span class="text-muted fw-normal">(<?= e($child['class_name'] ?? 'N/A') ?>)</span>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php else: ?>
                  <span class="badge bg-light text-muted border">No linked students</span>
                <?php endif; ?>
              </td>
              <td class="py-3">
                <?= statusBadge($p['status'] ?? 1) ?>
              </td>
              <td class="text-end pe-4 py-3">
                <?php if(hasPermission('parents.edit')): ?>
                  <a href="<?= e(url("parents/{$p['id']}/edit")) ?>" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center text-primary" style="width:32px;height:32px; border-radius:0.5rem; transition:all 0.2s;" onmouseover="this.classList.add('bg-primary', 'bg-opacity-10');" onmouseout="this.classList.remove('bg-primary', 'bg-opacity-10');">
                    <i data-lucide="edit-2" style="width:16px;"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  
  <?php if(isset($totalPages) && $totalPages > 1): ?>
    <div class="p-3 border-top d-flex justify-content-between align-items-center bg-light">
      <div class="small text-muted">Page <?= $page ?> of <?= $totalPages ?></div>
      <div class="d-flex gap-2">
        <a href="?page=<?= $page - 1 ?>&q=<?= urlencode($filters['q'] ?? '') ?>" class="btn btn-sm btn-outline-secondary <?= $page <= 1 ? 'disabled' : '' ?>">Previous</a>
        <a href="?page=<?= $page + 1 ?>&q=<?= urlencode($filters['q'] ?? '') ?>" class="btn btn-sm btn-outline-secondary <?= $page >= $totalPages ? 'disabled' : '' ?>">Next</a>
      </div>
    </div>
  <?php endif; ?>
</div>
