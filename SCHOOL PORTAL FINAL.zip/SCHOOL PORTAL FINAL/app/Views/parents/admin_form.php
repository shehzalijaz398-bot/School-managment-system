<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex align-items-center gap-2">
    <div class="bg-primary bg-opacity-10 text-primary p-2 rounded-3">
      <i data-lucide="user-cog"></i>
    </div>
    <h2 class="mb-0 h4 fw-bold text-dark"><?= e($title) ?></h2>
  </div>
  <a href="<?= e(url('parents')) ?>" class="btn btn-outline-secondary d-flex align-items-center gap-2 rounded-pill shadow-sm">
    <i data-lucide="arrow-left" style="width:18px;"></i> Back to Directory
  </a>
</div>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="panel border-0 shadow-sm p-4 rounded-4">
      <form method="post" action="<?= e($parent ? url('parents/'.$parent['id']) : url('parents')) ?>">
        <?= csrf_field() ?>
        
        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="user" class="text-primary me-2"></i> Personal Information</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">First Name <span class="text-danger">*</span></label>
            <input type="text" name="first_name" class="form-control" required value="<?= e($parent['first_name'] ?? old('first_name')) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Last Name <span class="text-danger">*</span></label>
            <input type="text" name="last_name" class="form-control" required value="<?= e($parent['last_name'] ?? old('last_name')) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Relationship</label>
            <select name="relation_label" class="form-select">
              <option value="Father" <?= (($parent['relation_label'] ?? '') === 'Father') ? 'selected' : '' ?>>Father</option>
              <option value="Mother" <?= (($parent['relation_label'] ?? '') === 'Mother') ? 'selected' : '' ?>>Mother</option>
              <option value="Guardian" <?= (($parent['relation_label'] ?? 'Guardian') === 'Guardian') ? 'selected' : '' ?>>Guardian</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Occupation (Optional)</label>
            <input type="text" name="occupation" class="form-control" value="<?= e($parent['occupation'] ?? old('occupation')) ?>">
          </div>
        </div>

        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="phone" class="text-info me-2"></i> Contact Details</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Email Address <span class="text-danger">*</span></label>
            <input type="email" name="email" class="form-control" required value="<?= e($parent['email'] ?? old('email')) ?>">
            <div class="form-text small"><i data-lucide="lock" style="width:12px;"></i> This email acts as the login ID for the Parent Portal.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Primary Phone <span class="text-danger">*</span></label>
            <input type="text" name="phone" class="form-control" required value="<?= e($parent['phone'] ?? old('phone')) ?>">
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold">Residential Address</label>
            <textarea name="address" class="form-control" rows="3"><?= e($parent['address'] ?? old('address')) ?></textarea>
          </div>
        </div>

        <?php if (!$parent): ?>
        <h5 class="fw-bold text-dark mb-4 border-bottom pb-3"><i data-lucide="key" class="text-warning me-2"></i> Parent Portal Login Access</h5>
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Login Password</label>
            <div class="input-group">
              <input type="text" name="password" id="parentPasswordInput" class="form-control" value="Password@123" placeholder="Enter portal password">
              <button class="btn btn-outline-secondary" type="button" onclick="generateParentPassword()"><i data-lucide="refresh-cw" style="width:14px;height:14px;"></i> Generate</button>
            </div>
            <div class="form-text small">Default is <code>Password@123</code>. The parent uses their email address and this password to access the Parent Portal.</div>
          </div>
        </div>
        <?php endif; ?>

        <div class="text-end border-top pt-4">
          <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm d-flex align-items-center gap-2 ms-auto rounded-pill">
            <i data-lucide="save" style="width:18px;"></i> <?= $parent ? 'Update Profile' : 'Create Profile' ?>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function generateParentPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
  let pass = '';
  for (let i = 0; i < 10; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  const el = document.getElementById('parentPasswordInput');
  if (el) el.value = pass;
}
</script>
