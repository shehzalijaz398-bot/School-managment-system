<?php
$title = 'Unified Approvals & Workflow Hub';
$metricsData = $metrics ?? ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'approval_rate' => 100];
$activeStatus = $status ?? 'pending';
$activeType = $type ?? 'all';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="git-pull-request" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Enterprise Automation
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Centralized institutional governance for leaves, admissions, fee adjustments, and academic publications.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('workflows?status=pending')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="rotate-ccw" style="width: 14px; height: 14px;"></i> Refresh
    </a>
  </div>
</div>

<!-- Executive Metric Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Pending Action</div>
          <div class="fs-4 fw-bold text-warning"><?= (int) $metricsData['pending'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Awaiting Review</div>
        </div>
        <div class="rounded-3 p-2 bg-warning-subtle text-warning">
          <i data-lucide="clock" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Approved Requests</div>
          <div class="fs-4 fw-bold text-success"><?= (int) $metricsData['approved'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Processed Successfully</div>
        </div>
        <div class="rounded-3 p-2 bg-success-subtle text-success">
          <i data-lucide="check-circle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Rejected Requests</div>
          <div class="fs-4 fw-bold text-danger"><?= (int) $metricsData['rejected'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Declined with Remarks</div>
        </div>
        <div class="rounded-3 p-2 bg-danger-subtle text-danger">
          <i data-lucide="x-circle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Approval Velocity</div>
          <div class="fs-4 fw-bold text-primary"><?= $metricsData['approval_rate'] ?>%</div>
          <div class="text-muted" style="font-size: 11px;">Acceptance Index</div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="trending-up" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Workflow Control Console -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
  <div class="card-header bg-white border-bottom p-3">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
      <!-- Status Tabs -->
      <ul class="nav nav-pills gap-1">
        <li class="nav-nav-item">
          <a class="nav-link <?= $activeStatus === 'pending' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
             href="<?= e(url("workflows?status=pending&type={$activeType}")) ?>">
            Pending Reviews
            <?php if ($metricsData['pending'] > 0): ?>
              <span class="badge bg-warning text-dark ms-1"><?= $metricsData['pending'] ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $activeStatus === 'approved' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
             href="<?= e(url("workflows?status=approved&type={$activeType}")) ?>">
            Approved
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $activeStatus === 'rejected' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
             href="<?= e(url("workflows?status=rejected&type={$activeType}")) ?>">
            Rejected
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $activeStatus === 'all' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
             href="<?= e(url("workflows?status=all&type={$activeType}")) ?>">
            All History
          </a>
        </li>
      </ul>

      <!-- Entity Type Filter -->
      <div class="d-flex align-items-center gap-2">
        <label class="small text-muted text-nowrap mb-0">Module Category:</label>
        <select class="form-select form-select-sm" style="width: auto; min-width: 170px;" onchange="location.href='<?= e(url('workflows?status=' . $activeStatus . '&type=')) ?>' + this.value;">
          <option value="all" <?= $activeType === 'all' ? 'selected' : '' ?>>All Categories</option>
          <option value="leave_request" <?= $activeType === 'leave_request' ? 'selected' : '' ?>>Staff Leaves</option>
          <option value="admission" <?= $activeType === 'admission' ? 'selected' : '' ?>>Admissions</option>
          <option value="fee_waiver" <?= $activeType === 'fee_waiver' ? 'selected' : '' ?>>Fee Adjustments</option>
          <option value="exam_publish" <?= $activeType === 'exam_publish' ? 'selected' : '' ?>>Exam Publications</option>
        </select>
      </div>
    </div>
  </div>

  <!-- Table Body -->
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="bg-light text-muted small text-uppercase">
        <tr>
          <th style="width: 80px;" class="ps-4">ID</th>
          <th style="width: 140px;">Category</th>
          <th>Request Dossier</th>
          <th style="width: 180px;">Requester</th>
          <th style="width: 130px;">Submitted</th>
          <th style="width: 120px;" class="text-center">Status</th>
          <th style="width: 140px;" class="text-end pe-4">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($workflows)): ?>
          <tr>
            <td colspan="7" class="text-center py-5">
              <div class="py-4">
                <i data-lucide="check-check" class="text-success mb-2" style="width: 48px; height: 48px; opacity: 0.7;"></i>
                <h5 class="fw-bold text-dark mb-1">Queue Clear</h5>
                <p class="text-muted small mb-0">No approval workflows found for the selected filter criteria.</p>
              </div>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($workflows as $wf): 
            $stBadge = match ($wf['status']) {
              'approved' => 'bg-success-subtle text-success border border-success-subtle',
              'rejected' => 'bg-danger-subtle text-danger border border-danger-subtle',
              'cancelled' => 'bg-secondary-subtle text-secondary border border-secondary-subtle',
              default => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle',
            };
            $typeBadge = match ($wf['entity_type']) {
              'leave_request' => 'bg-primary-subtle text-primary',
              'admission' => 'bg-info-subtle text-info',
              'fee_waiver' => 'bg-warning-subtle text-dark',
              'exam_publish' => 'bg-purple-subtle text-purple',
              default => 'bg-light text-dark',
            };
          ?>
            <tr class="border-bottom">
              <td class="ps-4 font-monospace text-muted small">#<?= (int) $wf['id'] ?></td>
              <td>
                <span class="badge <?= $typeBadge ?> text-capitalize px-2 py-1 rounded-pill" style="font-size: 11px;">
                  <?= e(str_replace('_', ' ', $wf['entity_type'])) ?>
                </span>
              </td>
              <td>
                <div class="fw-bold text-dark"><?= e($wf['title']) ?></div>
                <?php if (!empty($wf['description'])): ?>
                  <div class="text-muted small text-truncate" style="max-width: 380px;"><?= e($wf['description']) ?></div>
                <?php endif; ?>
                <?php if (!empty($wf['reviewer_remarks'])): ?>
                  <div class="small text-secondary mt-1"><i data-lucide="message-square" style="width: 12px; height: 12px;"></i> <?= e($wf['reviewer_remarks']) ?></div>
                <?php endif; ?>
              </td>
              <td>
                <div class="fw-semibold text-dark small"><?= e($wf['requester_name'] ?? 'System User') ?></div>
                <div class="text-muted font-monospace" style="font-size: 11px;"><?= e($wf['requester_email'] ?? '') ?></div>
              </td>
              <td class="text-muted small">
                <?= date('M d, Y', strtotime((string)$wf['submitted_at'])) ?>
                <div class="text-muted" style="font-size: 10px;"><?= date('h:i A', strtotime((string)$wf['submitted_at'])) ?></div>
              </td>
              <td class="text-center">
                <span class="badge <?= $stBadge ?> text-uppercase px-2 py-1" style="font-size: 10.5px; letter-spacing: 0.04em;">
                  <?= e($wf['status']) ?>
                </span>
              </td>
              <td class="text-end pe-4">
                <?php if ($wf['status'] === 'pending'): ?>
                  <div class="d-flex justify-content-end gap-1">
                    <button type="button" 
                            class="btn btn-sm btn-outline-success px-2 py-1" 
                            onclick="openActionModal(<?= (int)$wf['id'] ?>, 'approve', '<?= e(addslashes($wf['title'])) ?>')"
                            title="Approve Request">
                      <i data-lucide="check" style="width: 14px; height: 14px;"></i> Approve
                    </button>
                    <button type="button" 
                            class="btn btn-sm btn-outline-danger px-2 py-1" 
                            onclick="openActionModal(<?= (int)$wf['id'] ?>, 'reject', '<?= e(addslashes($wf['title'])) ?>')"
                            title="Reject Request">
                      <i data-lucide="x" style="width: 14px; height: 14px;"></i> Reject
                    </button>
                  </div>
                <?php else: ?>
                  <span class="text-muted small font-monospace">Actioned</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Review Action Modal -->
<div class="modal fade" id="workflowActionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <form id="workflowActionForm" method="POST" action="">
        <?= csrf_field() ?>
        <input type="hidden" name="action" id="modalActionInput" value="">
        <div class="modal-header border-bottom-0 pb-0">
          <h5 class="modal-title fw-bold" id="modalActionTitle">Action Workflow</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body py-3">
          <p class="text-muted small" id="modalActionSubtitle"></p>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Reviewer Audit Remarks (Optional)</label>
            <textarea name="remarks" class="form-control" rows="3" placeholder="Enter decision justification or notes for the applicant..."></textarea>
          </div>
        </div>
        <div class="modal-footer border-top-0 pt-0">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-sm" id="modalSubmitBtn">Confirm Action</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openActionModal(id, action, title) {
  const form = document.getElementById('workflowActionForm');
  const actionInput = document.getElementById('modalActionInput');
  const titleEl = document.getElementById('modalActionTitle');
  const subEl = document.getElementById('modalActionSubtitle');
  const submitBtn = document.getElementById('modalSubmitBtn');

  form.action = '<?= e(url('workflows/')) ?>' + id + '/action';
  actionInput.value = action;

  if (action === 'approve') {
    titleEl.textContent = 'Approve Workflow Request';
    titleEl.className = 'modal-title fw-bold text-success';
    subEl.textContent = 'You are approving: "' + title + '". Target record will automatically update.';
    submitBtn.className = 'btn btn-sm btn-success px-3';
    submitBtn.textContent = 'Approve Request';
  } else {
    titleEl.textContent = 'Reject Workflow Request';
    titleEl.className = 'modal-title fw-bold text-danger';
    subEl.textContent = 'You are rejecting: "' + title + '". Please consider providing remarks below.';
    submitBtn.className = 'btn btn-sm btn-danger px-3';
    submitBtn.textContent = 'Reject Request';
  }

  const modal = new bootstrap.Modal(document.getElementById('workflowActionModal'));
  modal.show();
}
</script>
