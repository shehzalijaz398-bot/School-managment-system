<div class="text-center py-5">
  <h1>403</h1>
  <p><?= e($message ?? 'You do not have permission to access this resource.') ?></p>
  <a href="<?= e(url('dashboard')) ?>" class="btn btn-primary">Go to Dashboard</a>
</div>
