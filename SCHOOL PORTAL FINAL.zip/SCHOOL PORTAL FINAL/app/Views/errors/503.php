<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduled System Maintenance | <?= e(app_config('name', 'School Portal')) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg-gradient: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
            --card-bg: rgba(30, 41, 59, 0.7);
            --border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            background: var(--bg-gradient);
            color: var(--text-main);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            overflow-x: hidden;
        }

        .maintenance-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 24px;
            max-width: 580px;
            width: 100%;
            padding: 48px 40px;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 80px rgba(79, 70, 229, 0.15);
            animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .icon-bubble {
            width: 88px;
            height: 88px;
            border-radius: 50%;
            background: rgba(79, 70, 229, 0.15);
            border: 2px solid rgba(99, 102, 241, 0.4);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 28px;
            color: #818cf8;
            box-shadow: 0 0 30px rgba(99, 102, 241, 0.3);
            animation: pulse 3s infinite ease-in-out;
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 0 30px rgba(99, 102, 241, 0.3);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 0 45px rgba(99, 102, 241, 0.5);
            }
        }

        .icon-bubble svg {
            width: 44px;
            height: 44px;
        }

        h1 {
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -0.02em;
            margin-bottom: 14px;
            background: linear-gradient(135deg, #ffffff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            border-radius: 9999px;
            background: rgba(245, 158, 11, 0.12);
            border: 1px solid rgba(245, 158, 11, 0.3);
            color: #fbbf24;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #f59e0b;
            box-shadow: 0 0 10px #f59e0b;
            animation: blink 1.5s infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        p.description {
            font-size: 15px;
            line-height: 1.65;
            color: var(--text-muted);
            margin-bottom: 32px;
        }

        .info-grid {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 18px 24px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            text-align: left;
            margin-bottom: 32px;
        }

        .info-item span.label {
            display: block;
            font-size: 12px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .info-item span.value {
            font-size: 14px;
            font-weight: 600;
            color: #e2e8f0;
        }

        .btn-reload {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            background: var(--primary);
            color: #ffffff;
            border: none;
            padding: 13px 28px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s ease;
            box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);
        }

        .btn-reload:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(79, 70, 229, 0.5);
        }

        .footer-note {
            margin-top: 32px;
            font-size: 13px;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="maintenance-card">
        <div class="icon-bubble">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"></path>
            </svg>
        </div>

        <div class="status-badge">
            <span class="status-dot"></span>
            Scheduled System Upgrade in Progress
        </div>

        <h1>Platform Under Maintenance</h1>

        <p class="description">
            <?= htmlspecialchars($message ?? 'We are currently performing routine upgrades, performance enhancements, and security optimizations. All school records and data remain strictly safeguarded.') ?>
        </p>

        <div class="info-grid">
            <div class="info-item">
                <span class="label">Estimated Duration</span>
                <span class="value"><?= ceil(($retry ?? 300) / 60) ?> Minutes</span>
            </div>
            <div class="info-item">
                <span class="label">Auto-Refresh Window</span>
                <span class="value"><?= (int) ($retry ?? 300) ?> Seconds</span>
            </div>
            <div class="info-item">
                <span class="label">Started At</span>
                <span class="value"><?= htmlspecialchars($started_at ?? date('Y-m-d H:i:s')) ?></span>
            </div>
            <div class="info-item">
                <span class="label">Platform Status</span>
                <span class="value" style="color: #34d399;">Data Secure & Retained</span>
            </div>
        </div>

        <button class="btn-reload" onclick="window.location.reload();">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
            </svg>
            Check Platform Status
        </button>

        <p class="footer-note">
            <?= e(app_config('name', 'School Portal SaaS')) ?> &bull; Enterprise Resilience & High Availability
        </p>
    </div>

    <script>
        // Auto reload after retry interval
        const retrySec = <?= (int) ($retry ?? 300) ?>;
        if (retrySec > 0) {
            setTimeout(function() {
                window.location.reload();
            }, retrySec * 1000);
        }
    </script>
</body>
</html>
