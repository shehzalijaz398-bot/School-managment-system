<div class="text-center py-5">
  <h1>500</h1>
  <p>An unexpected error occurred. Please try again later.</p>
</div>
