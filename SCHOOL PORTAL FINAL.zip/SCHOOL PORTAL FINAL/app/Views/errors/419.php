<div class="container py-5 text-center">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card border-0 shadow-sm p-4 p-md-5 rounded-4">
        <div class="mb-4">
          <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning rounded-circle" style="width: 72px; height: 72px;">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
          </div>
        </div>
        <h1 class="h3 fw-bold text-dark mb-2">419 — Page or Session Expired</h1>
        <p class="text-muted mb-4"><?= e($message ?? 'Your session security token has expired due to inactivity. Please refresh the page and submit your form again.') ?></p>
        <div class="d-flex justify-content-center gap-2">
          <button type="button" onclick="window.location.reload();" class="btn btn-primary px-4 rounded-pill">
            Refresh Page
          </button>
          <a href="<?= e(url('login')) ?>" class="btn btn-outline-secondary px-4 rounded-pill">
            Return to Login
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
