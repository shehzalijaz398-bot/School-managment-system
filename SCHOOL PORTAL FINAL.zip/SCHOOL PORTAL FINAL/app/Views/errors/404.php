<div class="text-center py-5">
  <h1>404</h1>
  <p>Page not found.</p>
  <a href="<?= e(url('dashboard')) ?>" class="btn btn-primary">Go to Dashboard</a>
</div>
