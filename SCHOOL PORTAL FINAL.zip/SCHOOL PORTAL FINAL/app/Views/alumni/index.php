<?php
$layout = 'layouts/app';
$activeTab = $tab ?? 'members';
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($title ?? 'Alumni Association Network') ?>
        </h1>
        <p class="text-muted small mb-0">
            Graduate directory, passing out batch tracking, alumni reunions, career pathways, and mentorship records
        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('alumni/export-csv')) ?>" 
           class="btn btn-outline-secondary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
           style="font-size: 13px; font-weight: 500;">
            <i data-lucide="download" style="width: 15px; height: 15px;"></i>
            <span>Export Directory</span>
        </a>
        <button class="btn btn-outline-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm bg-white" 
                data-bs-toggle="modal" data-bs-target="#newEventModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="calendar-plus" style="width: 15px; height: 15px;"></i>
            <span>Host Reunion / Event</span>
        </button>
        <button class="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 rounded-pill shadow-sm" 
                data-bs-toggle="modal" data-bs-target="#newAlumniModal" 
                style="font-size: 13px; font-weight: 500;">
            <i data-lucide="user-plus" style="width: 16px; height: 16px;"></i>
            <span>Register Alumni</span>
        </button>
    </div>
</div>

<!-- 3 KPI Stat Metric Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
                        <i data-lucide="graduation-cap" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
                    </div>
                    <span class="badge rounded-pill bg-light text-dark px-2 py-1" style="font-size: 10px;">Graduates</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_alumni'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Registered Alumni Members</div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
                        <i data-lucide="layers" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
                    </div>
                    <span class="badge rounded-pill bg-success-subtle text-success px-2 py-1" style="font-size: 10px;">Generations</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['total_batches'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Graduating Batches Tracked</div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #fffbeb; width: 34px; height: 34px;">
                        <i data-lucide="calendar" style="width: 16px; height: 16px; stroke: #d97706;"></i>
                    </div>
                    <span class="badge rounded-pill bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">Upcoming</span>
                </div>
                <div class="h3 fw-bold text-dark mb-0"><?= (int)($stats['upcoming_events'] ?? 0) ?></div>
                <div class="text-muted small mt-1" style="font-size: 12px;">Reunions &amp; Networking Meets</div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs Navigation -->
<ul class="nav nav-pills gap-2 mb-4 p-1 bg-white rounded-3 shadow-sm border" style="width: fit-content;">
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'members' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('alumni?tab=members')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="users" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Alumni Directory (<?= count($alumni) ?>)
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link px-3 py-2 rounded-2 <?= $activeTab === 'events' ? 'active bg-primary' : 'text-dark' ?>" 
           href="<?= e(url('alumni?tab=events')) ?>" style="font-size: 13px; font-weight: 500;">
            <i data-lucide="calendar" style="width: 14px; height: 14px; margin-right: 6px;"></i>
            Reunions &amp; Events (<?= count($events) ?>)
        </a>
    </li>
</ul>

<!-- Tab 1: Directory -->
<?php if ($activeTab === 'members'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <!-- Filter bar -->
        <form method="GET" action="<?= e(url('alumni')) ?>" class="row g-2 align-items-center mb-3">
            <input type="hidden" name="tab" value="members">
            <div class="col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
                    <input type="text" name="q" class="form-control border-start-0" placeholder="Search by name, company, university or profession..." value="<?= e($filters['q'] ?? '') ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Graduation Years</option>
                    <?php foreach ($years as $yr): ?>
                        <option value="<?= (int)$yr ?>" <?= ((int)($filters['year'] ?? 0) === (int)$yr) ? 'selected' : '' ?>>
                            Class of <?= (int)$yr ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary w-100">Filter</button>
                <?php if (!empty($filters['q']) || !empty($filters['year'])): ?>
                    <a href="<?= e(url('alumni?tab=members')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 13px;">
                <thead class="table-light text-muted">
                    <tr>
                        <th class="ps-3">Alumni Name</th>
                        <th>Class of</th>
                        <th>Current Role / Company</th>
                        <th>Higher Education</th>
                        <th>Contact</th>
                        <th class="text-end pe-3">Profile Link</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($alumni)): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No alumni members registered yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($alumni as $al): ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark"><?= e($al['name']) ?></div>
                                    <div class="text-muted font-monospace" style="font-size: 11px;"><?= e($al['admission_no'] ?: '—') ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-primary-subtle text-primary fw-bold">Class of <?= (int)$al['passing_year'] ?></span>
                                </td>
                                <td>
                                    <div class="fw-medium text-dark"><?= e($al['current_profession'] ?: '—') ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><?= e($al['organization'] ?: '') ?></div>
                                </td>
                                <td>
                                    <?= e($al['higher_education'] ?: '—') ?>
                                </td>
                                <td>
                                    <div style="font-size: 12px;"><?= e($al['email'] ?: '—') ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><?= e($al['phone'] ?: '') ?></div>
                                </td>
                                <td class="text-end pe-3">
                                    <?php if (!empty($al['linkedin_url'])): ?>
                                        <a href="<?= e($al['linkedin_url']) ?>" target="_blank" class="btn btn-sm btn-outline-primary py-1 px-2 rounded-pill" style="font-size: 11px;">
                                            <i data-lucide="external-link" style="width: 12px; height: 12px; margin-right: 3px;"></i> LinkedIn
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted small">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tab 2: Events -->
<?php if ($activeTab === 'events'): ?>
<div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">Alumni Reunions &amp; Networking Sessions</h6>
            <button class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#newEventModal">
                <i data-lucide="plus" style="width: 14px; height: 14px; margin-right: 4px;"></i> Post Event
            </button>
        </div>
        <div class="row g-3">
            <?php if (empty($events)): ?>
                <div class="col-12 text-center py-4 text-muted">No alumni events scheduled. Click "Host Reunion" to publish one.</div>
            <?php else: ?>
                <?php foreach ($events as $ev): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 border rounded-3 p-3 shadow-sm bg-white">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-primary-subtle text-primary text-uppercase"><?= e($ev['status']) ?></span>
                                <span class="small text-muted"><?= date('M d, Y H:i', strtotime($ev['event_date'])) ?></span>
                            </div>
                            <h5 class="fw-bold text-dark mb-1"><?= e($ev['title']) ?></h5>
                            <div class="small text-muted mb-2">
                                <i data-lucide="map-pin" style="width: 13px; height: 13px; margin-right: 4px;"></i> <?= e($ev['venue'] ?: 'Campus Auditorium') ?>
                            </div>
                            <p class="small text-muted mb-3"><?= nl2br(e($ev['description'] ?? '')) ?></p>
                            <?php if (!empty($ev['contact_email'])): ?>
                                <div class="border-top pt-2 mt-auto small text-muted">
                                    RSVP: <a href="mailto:<?= e($ev['contact_email']) ?>" class="text-primary fw-medium"><?= e($ev['contact_email']) ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modal: New Alumni Member -->
<div class="modal fade" id="newAlumniModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('alumni/members')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Register Alumni Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">Full Name *</label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Ayesha Siddiqui" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Passing Out Year *</label>
                            <input type="number" name="passing_year" class="form-control" value="<?= date('Y') - 1 ?>" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Admission No (Optional)</label>
                            <input type="text" name="admission_no" class="form-control" placeholder="ADM-XXXX">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Or Link Existing Student</label>
                            <select name="student_id" class="form-select">
                                <option value="">None / External</option>
                                <?php foreach ($students as $st): ?>
                                    <option value="<?= (int)$st['id'] ?>">
                                        <?= e($st['first_name'] . ' ' . $st['last_name']) ?> (<?= e($st['admission_no']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="alumni@example.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="+92 300 0000000">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Current Profession / Job Title</label>
                            <input type="text" name="current_profession" class="form-control" placeholder="e.g. Senior Data Scientist">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Company / Organization</label>
                            <input type="text" name="organization" class="form-control" placeholder="e.g. Google, McKinsey">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Higher Education / Degree</label>
                            <input type="text" name="higher_education" class="form-control" placeholder="e.g. BS Computer Science, Stanford">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">LinkedIn URL</label>
                            <input type="url" name="linkedin_url" class="form-control" placeholder="https://linkedin.com/in/username">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Save Alumni</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: New Alumni Event -->
<div class="modal fade" id="newEventModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form method="POST" action="<?= e(url('alumni/events')) ?>">
                <?= csrf_field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Host Alumni Reunion / Meet</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Event Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Silver Jubilee Homecoming 2026" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Date &amp; Time *</label>
                            <input type="datetime-local" name="event_date" class="form-control" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Contact Email</label>
                            <input type="email" name="contact_email" class="form-control" placeholder="alumni@school.edu">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Venue</label>
                        <input type="text" name="venue" class="form-control" placeholder="Campus Main Auditorium & Lawns">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Event Details</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Networking agenda, dinner details, distinguished alumni awards..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">Publish Event</button>
                </div>
            </form>
        </div>
    </div>
</div>
