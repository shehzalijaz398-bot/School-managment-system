<?php
$title = $title ?? 'Class Learning Resources & Study Materials';
$classes = $classes ?? [];
$subjects = $subjects ?? [];
$resources = $resources ?? [];
$classId = $classId ?? 0;
$sectionId = $sectionId ?? null;
$subjectId = $subjectId ?? null;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <h2 class="h4 mb-0 fw-bold text-dark d-flex align-items-center gap-2">
      <i data-lucide="folder-git-2" class="text-primary" style="width: 24px; height: 24px;"></i>
      <?= e($title) ?>
    </h2>
    <p class="text-muted small mb-0 mt-1">
      Upload and distribute course syllabi, lecture notes, study guides, and digital learning documents to enrolled classes.
    </p>
  </div>
  <div>
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#uploadResourceModal">
      <i data-lucide="upload" style="width: 14px; height: 14px;"></i> Upload Resource
    </button>
  </div>
</div>

<!-- Class & Subject Filter Bar -->
<div class="card border-0 shadow-sm rounded-4 mb-4 p-3 bg-white">
  <form method="GET" action="<?= e(url('resources')) ?>" class="row g-2 align-items-end">
    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">Select Class</label>
      <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
        <?php foreach ($classes as $c): ?>
          <option value="<?= e($c['id']) ?>" <?= ((int)$c['id'] === $classId) ? 'selected' : '' ?>>
            <?= e($c['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">Filter by Subject</label>
      <select name="subject_id" class="form-select form-select-sm" onchange="this.form.submit()">
        <option value="">-- All Subjects --</option>
        <?php foreach ($subjects as $sub): ?>
          <option value="<?= e($sub['id']) ?>" <?= ((int)$sub['id'] === $subjectId) ? 'selected' : '' ?>>
            <?= e($sub['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-4 col-sm-12 d-flex gap-2">
      <button type="submit" class="btn btn-primary btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-1">
        <i data-lucide="filter" style="width: 14px; height: 14px;"></i> Filter
      </button>
      <a href="<?= e(url('resources')) ?>" class="btn btn-light btn-sm text-muted">Reset</a>
    </div>
  </form>
</div>

<!-- Resources Table -->
<div class="card border-0 shadow-sm rounded-4 bg-white">
  <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
    <h5 class="fw-bold text-dark mb-0" style="font-size: 15px;">Shared Documents</h5>
    <span class="badge bg-light text-muted border"><?= count($resources) ?> Documents</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="bg-light text-muted small text-uppercase">
          <tr>
            <th class="ps-4">Resource Title</th>
            <th>Subject</th>
            <th>Class / Section</th>
            <th>Uploaded By</th>
            <th>File Info</th>
            <th>Downloads</th>
            <th class="pe-4 text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($resources)): ?>
            <tr>
              <td colspan="7" class="text-center py-5 text-muted">
                <i data-lucide="file-x" style="width: 40px; height: 40px; opacity: 0.3;" class="mb-2"></i>
                <div class="fw-bold text-dark">No Resources Uploaded</div>
                <div class="small">Upload notes, presentations, or guides for this class.</div>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($resources as $res): ?>
              <tr>
                <td class="ps-4">
                  <div class="fw-bold text-dark"><?= e($res['title']) ?></div>
                  <?php if (!empty($res['description'])): ?>
                    <div class="text-muted small text-truncate" style="max-width: 320px; font-size: 11.5px;">
                      <?= e($res['description']) ?>
                    </div>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge bg-primary-subtle text-primary">
                    <?= e($res['subject_name'] ?? 'General') ?>
                  </span>
                </td>
                <td>
                  <span class="small fw-medium text-dark"><?= e($res['class_name'] ?? 'Class') ?></span>
                  <?php if (!empty($res['section_name'])): ?>
                    <span class="text-muted small">(Sec <?= e($res['section_name']) ?>)</span>
                  <?php else: ?>
                    <span class="text-muted small">(All Sections)</span>
                  <?php endif; ?>
                </td>
                <td class="small text-muted">
                  <?= e($res['uploader_name'] ?? 'Faculty') ?>
                  <div style="font-size: 10px;"><?= date('M j, Y', strtotime($res['created_at'])) ?></div>
                </td>
                <td>
                  <span class="badge bg-light text-secondary border font-monospace" style="font-size: 11px;">
                    <?= round(($res['file_size'] ?? 0) / 1024, 1) ?> KB
                  </span>
                </td>
                <td>
                  <span class="badge bg-light text-dark border">
                    <i data-lucide="download" style="width: 11px; height: 11px;" class="me-1"></i>
                    <?= (int)$res['download_count'] ?>
                  </span>
                </td>
                <td class="pe-4 text-end">
                  <div class="d-flex justify-content-end gap-1">
                    <a href="<?= e(url('resources/' . $res['id'] . '/download')) ?>" class="btn btn-sm btn-outline-primary d-flex align-items-center gap-1" title="Download Document">
                      <i data-lucide="download" style="width: 13px; height: 13px;"></i>
                    </a>
                    <form method="POST" action="<?= e(url('resources/' . $res['id'] . '/delete')) ?>" onsubmit="return confirm('Delete this resource permanently?');" class="d-inline">
                      <?= csrf_field() ?>
                      <button type="submit" class="btn btn-sm btn-light text-danger border" title="Delete">
                        <i data-lucide="trash-2" style="width: 13px; height: 13px;"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal: Upload Resource -->
<div class="modal fade" id="uploadResourceModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <div class="modal-header border-0 pb-0 pt-4 px-4">
        <h5 class="modal-title fw-bold text-dark">
          <i data-lucide="upload-cloud" class="text-primary me-2" style="width: 18px; height: 18px;"></i>
          Upload Class Resource
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="<?= e(url('resources')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Target Class *</label>
            <select name="class_id" class="form-select form-select-sm" required>
              <option value="">-- Select Class --</option>
              <?php foreach ($classes as $c): ?>
                <option value="<?= e($c['id']) ?>" <?= ((int)$c['id'] === $classId) ? 'selected' : '' ?>>
                  <?= e($c['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Subject (Optional)</label>
            <select name="subject_id" class="form-select form-select-sm">
              <option value="">-- General / No Subject --</option>
              <?php foreach ($subjects as $sub): ?>
                <option value="<?= e($sub['id']) ?>">
                  <?= e($sub['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Resource Title *</label>
            <input type="text" name="title" class="form-control form-control-sm" placeholder="e.g. Chapter 4 Motion & Energy Study Notes" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Description / Instructions</label>
            <textarea name="description" class="form-control form-control-sm" rows="3" placeholder="Brief context or instructions for students..."></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Select File * (PDF, DOCX, PPTX, ZIP, Images - Max 25MB)</label>
            <input type="file" name="file" class="form-control form-control-sm" required>
          </div>
        </div>
        <div class="modal-footer border-0 pt-0 px-4 pb-4">
          <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
            <i data-lucide="upload" style="width: 14px; height: 14px;"></i> Upload &amp; Share
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
