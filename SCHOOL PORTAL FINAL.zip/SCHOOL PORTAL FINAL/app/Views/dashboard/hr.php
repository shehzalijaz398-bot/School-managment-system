﻿<?php $s = $stats; ?>
<!-- Quick Actions -->
<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="<?= e(url('hr/employees')) ?>" class="btn btn-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="users" style="width:14px;height:14px;"></i> Employees
  </a>
  <a href="<?= e(url('leave')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="calendar-x" style="width:14px;height:14px;"></i> Leave Requests
  </a>
  <a href="<?= e(url('hr/candidates')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="briefcase" style="width:14px;height:14px;"></i> Recruitment
  </a>
  <a href="<?= e(url('attendance/staff')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="clipboard-check" style="width:14px;height:14px;"></i> Staff Attendance
  </a>
</div>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Active Employees</div>
        <div class="kpi-icon kpi-icon-primary"><i data-lucide="users" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value"><?= (int)($s['employees'] ?? 0) ?></div>
      <div class="kpi-trend flat"><i data-lucide="minus" style="width:11px;height:11px;"></i> On payroll</div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-warning">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Pending Leaves</div>
        <div class="kpi-icon kpi-icon-warning"><i data-lucide="calendar-x" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="color:var(--sp-warning);"><?= (int)($s['pending_leaves'] ?? 0) ?></div>
      <div class="kpi-trend <?= ($s['pending_leaves'] ?? 0) > 0 ? 'down' : 'up' ?>">
        <?= ($s['pending_leaves'] ?? 0) > 0 ? '<i data-lucide="clock" style="width:11px;height:11px;"></i> Need review' : '<i data-lucide="check-circle" style="width:11px;height:11px;"></i> All processed' ?>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-info">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Open Positions</div>
        <div class="kpi-icon kpi-icon-info"><i data-lucide="briefcase" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="color:var(--sp-info);"><?= (int)($s['candidates'] ?? 0) ?></div>
      <div class="kpi-trend flat"><i data-lucide="minus" style="width:11px;height:11px;"></i> In pipeline</div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-success">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Staff Present</div>
        <div class="kpi-icon kpi-icon-success"><i data-lucide="clipboard-check" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="color:var(--sp-success);"><?= (int)($s['staff_attendance']['present'] ?? 0) ?></div>
      <div class="kpi-trend up"><i data-lucide="check-circle" style="width:11px;height:11px;"></i> Today</div>
    </div>
  </div>
</div>

<!-- Recent HR Activity -->
<div class="panel">
  <div class="panel-header">
    <h3 class="panel-title">
      <div class="panel-title-icon" style="background:var(--sp-info-light);color:var(--sp-info);">
        <i data-lucide="activity" style="width:16px;height:16px;"></i>
      </div>
      Recent HR Activity
    </h3>
    <a href="<?= e(url('audit')) ?>" class="panel-view-all">Full log <i data-lucide="chevron-right" style="width:13px;height:13px;"></i></a>
  </div>
  <?php if (empty($s['recent'])): ?>
    <div class="empty-state">
      <div class="empty-state-icon"><i data-lucide="activity" style="width:28px;height:28px;"></i></div>
      <div class="empty-state-title">No Activity</div>
      <div class="empty-state-text">HR activity log will appear here.</div>
    </div>
  <?php else: ?>
    <ul class="activity-list">
      <?php foreach ($s['recent'] as $log): ?>
        <li class="activity-item">
          <div class="activity-dot activity-dot-info"><i data-lucide="zap" style="width:12px;height:12px;"></i></div>
          <div class="activity-body">
            <div class="activity-text">
              <span class="fw-semibold"><?= e($log['user_name'] ?? 'System') ?></span>
              <?= e($log['action']) ?>
            </div>
            <div class="activity-time"><i data-lucide="clock" style="width:10px;height:10px;"></i> <?= e(formatDate($log['created_at'] ?? '', 'd M Y H:i')) ?></div>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>