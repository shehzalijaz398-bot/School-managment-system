<?php $s = $stats; ?>
<!-- Quick Actions -->
<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="file-text" style="width:14px;height:14px;"></i> Fee Invoices
  </a>
  <a href="<?= e(url('finance/payments')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="dollar-sign" style="width:14px;height:14px;"></i> Collect Payment
  </a>
  <a href="<?= e(url('finance/payroll')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="coins" style="width:14px;height:14px;"></i> Payroll
  </a>
  <a href="<?= e(url('finance/expenses')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
    <i data-lucide="credit-card" style="width:14px;height:14px;"></i> Expenses
  </a>
</div>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-success">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Collected (MTD)</div>
        <div class="kpi-icon kpi-icon-success"><i data-lucide="banknote" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="font-size:1.3rem;color:var(--sp-success);"><?= e(formatMoney($s['fee_collected'] ?? 0)) ?></div>
      <div class="kpi-trend up"><i data-lucide="trending-up" style="width:11px;height:11px;"></i> This month</div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-danger">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Outstanding</div>
        <div class="kpi-icon kpi-icon-danger"><i data-lucide="alert-circle" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="font-size:1.3rem;color:var(--sp-danger);"><?= e(formatMoney($s['fee_outstanding'] ?? 0)) ?></div>
      <div class="kpi-trend down"><i data-lucide="trending-down" style="width:11px;height:11px;"></i> Needs action</div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-warning">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Expenses (MTD)</div>
        <div class="kpi-icon kpi-icon-warning"><i data-lucide="receipt" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="font-size:1.3rem;color:var(--sp-warning);"><?= e(formatMoney($s['month_expenses'] ?? 0)) ?></div>
      <div class="kpi-trend flat"><i data-lucide="minus" style="width:11px;height:11px;"></i> This month</div>
    </div>
  </div>
  <div class="col-6 col-md-3 kpi-animate">
    <div class="stat-card kpi-info">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div class="label">Pending Payroll</div>
        <div class="kpi-icon kpi-icon-info"><i data-lucide="coins" style="width:20px;height:20px;"></i></div>
      </div>
      <div class="value" style="color:var(--sp-info);"><?= (int)($s['pending_payroll'] ?? 0) ?></div>
      <div class="kpi-trend <?= ($s['pending_payroll'] ?? 0) > 0 ? 'down' : 'up' ?>">
        <?= ($s['pending_payroll'] ?? 0) > 0 ? '<i data-lucide="alert-circle" style="width:11px;height:11px;"></i> Pending' : '<i data-lucide="check-circle" style="width:11px;height:11px;"></i> Processed' ?>
      </div>
    </div>
  </div>
</div>

<!-- Recent Payments -->
<div class="panel">
  <div class="panel-header">
    <h3 class="panel-title">
      <div class="panel-title-icon" style="background:var(--sp-success-light);color:var(--sp-success);">
        <i data-lucide="receipt" style="width:16px;height:16px;"></i>
      </div>
      Recent Fee Payments
    </h3>
    <a href="<?= e(url('finance/payments')) ?>" class="panel-view-all">View all <i data-lucide="chevron-right" style="width:13px;height:13px;"></i></a>
  </div>
  <?php if (empty($s['recent_payments'])): ?>
    <div class="empty-state">
      <div class="empty-state-icon"><i data-lucide="receipt" style="width:28px;height:28px;"></i></div>
      <div class="empty-state-title">No Recent Payments</div>
      <div class="empty-state-text">Payment records will appear here.</div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th>Receipt #</th>
            <th>Student</th>
            <th>Method</th>
            <th>Date</th>
            <th class="text-end">Amount</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($s['recent_payments'] as $p): ?>
          <tr>
            <td><span class="badge-soft-primary badge"><?= e($p['receipt_no'] ?? '-') ?></span></td>
            <td class="fw-semibold"><?= e($p['student_name']) ?></td>
            <td><span class="badge-soft-info badge text-uppercase"><?= e($p['payment_method'] ?? '') ?></span></td>
            <td class="text-muted small"><?= e(formatDate($p['payment_date'] ?? '')) ?></td>
            <td class="text-end fw-bold" style="color:var(--sp-success);"><?= e(formatMoney($p['amount'] ?? 0)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>