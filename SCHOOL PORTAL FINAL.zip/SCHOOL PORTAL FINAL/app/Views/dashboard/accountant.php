<?php
$title = $title ?? 'Finance & Accounting Cockpit';
$todayCollected = (float)($stats['today_collected'] ?? 0);
$monthCollected = (float)($stats['month_collected'] ?? 0);
$totalOverdue   = (float)($stats['total_overdue'] ?? 0);
$overdueCount   = (int)($stats['overdue_count'] ?? 0);
$monthExpenses  = (float)($stats['month_expenses'] ?? 0);
$aging          = $stats['aging'] ?? [];
$recentPayments = $stats['recent_payments'] ?? [];
$overdueInvoices= $stats['overdue_invoices'] ?? [];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 font-weight-bold text-gray-800 mb-1">
            <i class="fas fa-coins text-success me-2"></i>Finance & Accounting Cockpit
        </h1>
        <p class="text-muted small mb-0">Revenue collection, overdue aging, cashier payments ledger & fee reminders.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('finance/payments/create')) ?>" class="btn btn-success btn-sm font-weight-bold">
            <i class="fas fa-plus-circle me-1"></i>Record Fee Payment
        </a>
        <a href="<?= e(url('finance/invoices')) ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-file-invoice-dollar me-1"></i>Invoices Ledger
        </a>
        <a href="<?= e(url('finance/expenses')) ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-receipt me-1"></i>Expenses
        </a>
    </div>
</div>

<!-- FINANCIAL KPIS -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-success border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Today's Fee Collection</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= formatMoney($todayCollected) ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-calendar-day me-1"></i><?= date('D, d M Y') ?></div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success">
                            <i class="fas fa-hand-holding-usd fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-primary border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Month-to-Date Revenue</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= formatMoney($monthCollected) ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-calendar-alt me-1"></i><?= date('F Y') ?></div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                            <i class="fas fa-chart-line fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-danger border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Overdue Fees</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= formatMoney($totalOverdue) ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-exclamation-circle text-danger me-1"></i><?= $overdueCount ?> Unpaid Invoices</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-danger bg-opacity-10 p-3 rounded-circle text-danger">
                            <i class="fas fa-file-invoice fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-warning border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Month Expenses</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= formatMoney($monthExpenses) ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-money-bill-wave me-1"></i>Operating Costs</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                            <i class="fas fa-receipt fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- OVERDUE AGING ANALYSIS ROW -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-dark">
            <i class="fas fa-hourglass-half text-primary me-2"></i>Receivables Aging Analysis
        </h6>
        <span class="text-muted small">Outstanding student invoices distributed across aging buckets</span>
    </div>
    <div class="card-body">
        <div class="row g-3 text-center">
            <div class="col-md-3">
                <div class="p-3 rounded bg-light border">
                    <div class="text-xs text-muted text-uppercase font-weight-bold mb-1">Current (Not Due)</div>
                    <div class="h5 mb-0 font-weight-bold text-success"><?= formatMoney((float)($aging['current'] ?? 0)) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="p-3 rounded bg-light border border-warning">
                    <div class="text-xs text-warning text-uppercase font-weight-bold mb-1">1 - 30 Days Overdue</div>
                    <div class="h5 mb-0 font-weight-bold text-dark"><?= formatMoney((float)($aging['1_30'] ?? 0)) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="p-3 rounded bg-light border border-danger">
                    <div class="text-xs text-danger text-uppercase font-weight-bold mb-1">31 - 60 Days Overdue</div>
                    <div class="h5 mb-0 font-weight-bold text-danger"><?= formatMoney((float)($aging['31_60'] ?? 0)) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="p-3 rounded bg-danger bg-opacity-10 border border-danger">
                    <div class="text-xs text-danger text-uppercase font-weight-bold mb-1">&gt; 60 Days Delinquent</div>
                    <div class="h5 mb-0 font-weight-bold text-danger"><?= formatMoney((float)($aging['60_plus'] ?? 0)) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- LEFT: RECENT PAYMENTS CASHIER LOG -->
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-receipt text-success me-2"></i>Recent Cashier Payments
                </h6>
                <a href="<?= e(url('finance/payments')) ?>" class="text-primary small font-weight-bold text-decoration-none">
                    All Payments (<?= count($recentPayments) ?>) &rarr;
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentPayments)): ?>
                    <div class="text-center py-4 text-muted small">No payment transactions recorded yet.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Receipt #</th>
                                    <th>Student</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($recentPayments as $p): ?>
                                <tr>
                                    <td class="font-weight-bold text-primary">
                                        <a href="<?= e(url('finance/payments/' . $p['id'])) ?>" class="text-decoration-none">
                                            <?= e($p['receipt_no'] ?? ('RCP-' . $p['id'])) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <div class="font-weight-bold text-dark"><?= e($p['first_name'] . ' ' . $p['last_name']) ?></div>
                                        <span class="text-muted text-xs"><?= e($p['class_name'] ?? 'Class') ?></span>
                                    </td>
                                    <td class="font-weight-bold text-success"><?= formatMoney((float)$p['amount']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= e(strtoupper($p['payment_method'] ?? 'cash')) ?></span></td>
                                    <td class="text-muted"><?= e(date('d M Y', strtotime($p['payment_date'] ?? $p['created_at']))) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- RIGHT: TOP OVERDUE INVOICES & ACTIONS -->
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-exclamation-triangle text-danger me-2"></i>Priority Overdue Collections
                </h6>
                <a href="<?= e(url('finance/invoices?status=overdue')) ?>" class="text-danger small font-weight-bold text-decoration-none">
                    View All &rarr;
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($overdueInvoices)): ?>
                    <div class="text-center py-4 text-muted small">
                        <i class="fas fa-check-circle fa-2x text-success mb-2"></i><br>
                        Zero overdue fee invoices! All students are paid up to date.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Student</th>
                                    <th>Due Amount</th>
                                    <th>Overdue</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($overdueInvoices as $inv): 
                                    $unpaid = (float)$inv['total_amount'] - (float)$inv['paid_amount'];
                                ?>
                                <tr>
                                    <td>
                                        <div class="font-weight-bold text-dark"><?= e($inv['first_name'] . ' ' . $inv['last_name']) ?></div>
                                        <span class="text-muted text-xs"><?= e($inv['class_name'] ?? 'Class') ?> &bull; <?= e($inv['invoice_no']) ?></span>
                                    </td>
                                    <td class="font-weight-bold text-danger"><?= formatMoney($unpaid) ?></td>
                                    <td><span class="badge bg-danger bg-opacity-10 text-danger"><?= (int)$inv['days_overdue'] ?> days</span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
