<?php
$s = $stats;
$period = $s['period'] ?? 'this_term';
$wp = $widget_prefs ?? (new \App\Services\UserProductivityService())->getDefaultDashboardWidgets();
?>

<!-- CodeClove School Management Pro — School Admin Cockpit -->
<div class="codeclove-dashboard">

  <!-- 1. Header Greeting & Term Badge -->
  <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
      <div class="d-flex align-items-center gap-2 mb-1">
        <h1 class="cc-greeting mb-0"><?= e($s['greeting'] ?? 'Good evening, School') ?></h1>
        <?php if (!empty($s['role_badge'])): ?>
          <span class="badge" style="background:#eef2ff; color:#4f46e5; font-size:12px; font-weight:600; border-radius:9999px; padding:3px 10px; border:1px solid #e0e7ff;"><?= e($s['role_badge']) ?></span>
        <?php endif; ?>
      </div>
      <div class="cc-date-subtitle text-muted"><?= e($s['today_date'] ?? date('l, d/m/Y')) ?></div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-1.5 shadow-sm" data-bs-toggle="modal" data-bs-target="#customizeDashboardModal" aria-label="Customize dashboard widgets" style="border-radius: 8px; font-weight: 600; font-size: 13px;">
        <i data-lucide="sliders" style="width:14px;height:14px;"></i>
        <span>Customize Widgets</span>
      </button>
      <div class="cc-term-pill">
        <i data-lucide="calendar" style="width:15px;height:15px;color:#4f46e5;"></i>
        <span><?= e($s['term_name'] ?? 'Term 2') ?></span>
      </div>
    </div>
  </div>

  <!-- 2. Setup Checklist Banner (CodeClove Dynamic Onboarding Widget) -->
  <?php if (!empty($wp['widget_checklist'])): ?>
  <?php
  $checklist = $s['setup_checklist'] ?? [];
  $completedCount = count(array_filter($checklist));
  $totalCount = count($checklist);
  $percent = $totalCount > 0 ? (int) round(($completedCount / $totalCount) * 100) : 100;
  $nextStep = null;
  $stepsMeta = [
      'preset'    => ['label' => 'Choose an education system preset', 'url' => url('settings?tab=education_system')],
      'session'   => ['label' => 'Create your first academic year', 'url' => url('academic-years')],
      'units'     => ['label' => 'Set up classes and sections', 'url' => url('classes')],
      'roles'     => ['label' => 'Configure staff roles and permissions', 'url' => url('roles')],
      'admission' => ['label' => 'Open admissions for enrolment', 'url' => url('admissions')],
  ];
  foreach ($stepsMeta as $k => $meta) {
      if (empty($checklist[$k])) {
          $nextStep = $meta;
          break;
      }
  }
  ?>
  <div id="ccSetupBanner" class="cc-setup-banner d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4" style="<?= $percent === 100 ? 'display:none;' : '' ?>">
    <div class="d-flex align-items-center gap-3">
      <div class="cc-setup-icon">
        <i data-lucide="sparkles" style="width:18px;height:18px;color:#4f46e5;"></i>
      </div>
      <div>
        <div class="d-flex align-items-center gap-2">
          <span class="fw-semibold text-dark small"><?= $completedCount ?> of <?= $totalCount ?> setup steps complete</span>
          <div class="cc-setup-bar-track">
            <div class="cc-setup-bar-fill" style="width: <?= $percent ?>%;"></div>
          </div>
          <span class="cc-setup-pct"><?= $percent ?>%</span>
        </div>
        <?php if ($nextStep): ?>
          <div class="text-muted small mt-0.5">Next: <?= e($nextStep['label']) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <?php if ($nextStep): ?>
        <a href="<?= e($nextStep['url']) ?>" class="btn btn-sm cc-btn-setup">Continue setup</a>
      <?php endif; ?>
      <button type="button" class="btn btn-sm btn-link text-muted p-1" onclick="dismissSetupBanner()" aria-label="Dismiss setup banner">
        <i data-lucide="x" style="width:16px;height:16px;"></i>
      </button>
    </div>
  </div>
  <?php endif; ?>

  <!-- 3. Highlight Summary Banners (Two Side-by-Side Cards) -->
  <?php if (!empty($wp['widget_attendance']) || !empty($wp['widget_action_items'])): ?>
  <div class="row g-3 mb-3">
    <!-- Today's Attendance -->
    <?php if (!empty($wp['widget_attendance'])): ?>
    <div class="col-12 <?= !empty($wp['widget_action_items']) ? 'col-md-6' : '' ?>">
      <a href="<?= e(url('attendance/students')) ?>" class="text-decoration-none">
        <div class="cc-highlight-card">
          <div class="cc-highlight-icon cc-icon-purple">
            <i data-lucide="calendar" style="width:20px;height:20px;"></i>
          </div>
          <div class="cc-highlight-content">
            <div class="cc-highlight-title">TODAY'S ATTENDANCE</div>
            <div class="cc-highlight-value">
              Students: <strong><?= (int)($s['student_att_present'] ?? 0) ?> / <?= (int)($s['student_att_total'] ?? 0) ?> (<?= e($s['student_att_pct'] ?? 0) ?>%)</strong> &nbsp;&bull;&nbsp; Staff: <strong><?= (int)($s['staff_att_present'] ?? 0) ?> / <?= (int)($s['staff_att_total'] ?? 0) ?> (<?= e($s['staff_att_pct'] ?? 0) ?>%)</strong>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>

    <!-- Action Items Pending -->
    <?php if (!empty($wp['widget_action_items'])): ?>
    <div class="col-12 <?= !empty($wp['widget_attendance']) ? 'col-md-6' : '' ?>">
      <a href="<?= e(url('admissions')) ?>" class="text-decoration-none">
        <div class="cc-highlight-card">
          <div class="cc-highlight-icon cc-icon-amber">
            <i data-lucide="bell" style="width:20px;height:20px;"></i>
          </div>
          <div class="cc-highlight-content">
            <div class="cc-highlight-title">ACTION ITEMS PENDING</div>
            <div class="cc-highlight-value">
              Admissions: <strong><?= (int)($s['pending_admissions'] ?? 0) ?> Reviews</strong> &nbsp;&bull;&nbsp; Staff Leaves: <strong><?= (int)($s['pending_staff'] ?? 0) ?> Pending</strong> &nbsp;&bull;&nbsp; Unsubmitted: <strong><?= (int)($s['unsubmitted_sections'] ?? 0) ?> Registers</strong>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- 4. Key Metric KPI Cards (Row of 5 Cards) -->
  <?php if (!empty($wp['widget_kpis'])): ?>
  <div class="row g-3 mb-4">
    <!-- Enrolled Students -->
    <div class="col-6 col-lg cc-col-5">
      <a href="<?= e(url('students')) ?>" class="cc-metric-card text-decoration-none">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="cc-metric-icon cc-icon-purple">
            <i data-lucide="users" style="width:19px;height:19px;"></i>
          </div>
          <span class="cc-badge cc-badge-purple">Active Directory</span>
        </div>
        <div class="cc-metric-value"><?= number_format((int)($s['enrolled_students'] ?? 0)) ?></div>
        <div class="cc-metric-label">Enrolled Students</div>
      </a>
    </div>

    <!-- Open Applications -->
    <div class="col-6 col-lg cc-col-5">
      <a href="<?= e(url('admissions')) ?>" class="cc-metric-card text-decoration-none">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="cc-metric-icon cc-icon-cyan">
            <i data-lucide="clipboard-list" style="width:19px;height:19px;"></i>
          </div>
          <span class="cc-badge cc-badge-cyan"><?= (int)($s['open_applications'] ?? 0) ?> in pipeline</span>
        </div>
        <div class="cc-metric-value"><?= (int)($s['open_applications'] ?? 0) ?></div>
        <div class="cc-metric-label">Open Applications</div>
      </a>
    </div>

    <!-- Active Staff -->
    <div class="col-6 col-lg cc-col-5">
      <a href="<?= e(url('hr/employees')) ?>" class="cc-metric-card text-decoration-none">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="cc-metric-icon cc-icon-amber">
            <i data-lucide="briefcase" style="width:19px;height:19px;"></i>
          </div>
          <span class="cc-badge cc-badge-amber"><?= (int)($s['active_staff'] ?? 0) ?> verified</span>
        </div>
        <div class="cc-metric-value"><?= (int)($s['active_staff'] ?? 0) ?></div>
        <div class="cc-metric-label">Active Staff</div>
      </a>
    </div>

    <!-- Outstanding Fees -->
    <div class="col-6 col-lg cc-col-5">
      <a href="<?= e(url('finance/invoices')) ?>" class="cc-metric-card text-decoration-none">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="cc-metric-icon cc-icon-green">
            <i data-lucide="credit-card" style="width:19px;height:19px;"></i>
          </div>
          <span class="cc-badge cc-badge-green">+<?= currencySymbol() ?><?= number_format((float)($s['recent_collected'] ?? 0), 2) ?> collected</span>
        </div>
        <div class="cc-metric-value"><?= currencySymbol() ?><?= number_format((float)($s['outstanding_amount'] ?? 0), 2) ?></div>
        <div class="cc-metric-label">Outstanding Fees</div>
      </a>
    </div>

    <!-- Overdue Invoices -->
    <div class="col-12 col-sm-6 col-lg cc-col-5">
      <a href="<?= e(url('reports/fees')) ?>" class="cc-metric-card text-decoration-none">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="cc-metric-icon cc-icon-red">
            <i data-lucide="alert-circle" style="width:19px;height:19px;"></i>
          </div>
          <span class="cc-badge cc-badge-red">Action</span>
        </div>
        <div class="cc-metric-value"><?= (int)($s['overdue_count'] ?? 0) ?></div>
        <div class="cc-metric-label">Overdue Invoices</div>
      </a>
    </div>
  </div>
  <?php endif; ?>

  <!-- 4.5 AI School Analytics & Operational Intelligence Banner -->
  <?php if (!empty($wp['widget_ai_analytics']) && !empty($s['ai_analytics'])): 
    $aiAnal = $s['ai_analytics'];
    $aiBrief = $aiAnal['ai_interpretation']['executive_summary'] ?? '';
    $briefSnippet = mb_substr(strip_tags($aiBrief), 0, 320) . '...';
    $anomList = $aiAnal['anomalies'] ?? [];
  ?>
  <div class="card border-0 shadow-sm rounded-4 mb-4" style="background: linear-gradient(135deg, #ffffff 0%, #fbfbfe 100%); border-left: 5px solid #4f46e5 !important;">
    <div class="card-body p-3 p-md-4">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2 pb-2 border-bottom">
        <div class="d-flex align-items-center gap-2">
          <div class="avatar bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
            <i data-lucide="sparkles" style="width: 17px; height: 17px;"></i>
          </div>
          <div>
            <h6 class="fw-bold mb-0 text-dark">AI Trend Intelligence &amp; Operational Highlights</h6>
            <small class="text-muted">Multi-Tenant Grounded · <?= e($aiAnal['reporting_period']['label'] ?? 'Current Period') ?></small>
          </div>
        </div>

        <div class="d-flex align-items-center gap-2">
          <a href="<?= e(url('analytics/school?period=' . urlencode($period))) ?>" class="btn btn-xs btn-outline-primary py-1 px-2.5 d-inline-flex align-items-center gap-1" style="font-size: 11.5px; font-weight: 600;">
            <span>Deep Dive Analytics</span>
            <i data-lucide="arrow-right" style="width: 12px; height: 12px;"></i>
          </a>
          <button type="button" class="btn btn-xs btn-primary py-1 px-2.5 d-inline-flex align-items-center gap-1 shadow-sm" style="font-size: 11.5px; font-weight: 600;" onclick="window.triggerChatbotPrompt('Summarize our school operational trends and areas needing attention')">
            <i data-lucide="message-square" style="width: 12px; height: 12px;"></i>
            <span>Ask Copilot</span>
          </button>
        </div>
      </div>

      <!-- Quick Anomalies Strip if any -->
      <?php if (!empty($anomList)): ?>
      <div class="d-flex flex-wrap gap-2 mb-2">
        <?php foreach (array_slice($anomList, 0, 2) as $an): ?>
          <span class="badge d-inline-flex align-items-center gap-1 py-1.5 px-2.5 rounded-pill" style="<?= ($an['severity'] ?? '') === 'critical' ? 'background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;' : 'background: #fffbeb; color: #92400e; border: 1px solid #fde68a;' ?>">
            <i data-lucide="<?= ($an['severity'] ?? '') === 'critical' ? 'alert-triangle' : 'alert-circle' ?>" style="width: 12px; height: 12px;"></i>
            <span><strong><?= e($an['title']) ?></strong>: <?= e(mb_substr($an['message'], 0, 90)) ?>...</span>
          </span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <p class="text-muted mb-0 small" style="line-height: 1.5;">
        <?= nl2br(e($briefSnippet)) ?>
      </p>
    </div>
  </div>
  <?php endif; ?>

  <!-- 5. Analytics Section -->
  <?php if (!empty($wp['widget_fee_chart'])): ?>
  <div class="mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
      <h2 class="cc-section-title mb-0">Analytics</h2>
      <div class="cc-period-filters">
        <a href="<?= e(url('dashboard?period=last_30_days')) ?>" class="cc-period-pill <?= $period === 'last_30_days' ? 'active' : '' ?>">Last 30 days</a>
        <a href="<?= e(url('dashboard?period=this_term')) ?>" class="cc-period-pill <?= $period === 'this_term' ? 'active' : '' ?>">This Term</a>
        <a href="<?= e(url('dashboard?period=this_year')) ?>" class="cc-period-pill <?= $period === 'this_year' ? 'active' : '' ?>">Academic Year</a>
      </div>
    </div>

    <div class="row g-3">
      <!-- Fee Collection Chart -->
      <div class="col-12 col-lg-6">
        <div class="cc-card h-100">
          <div class="cc-card-header d-flex align-items-center justify-content-between mb-2">
            <div>
              <div class="cc-card-title">Fee Collection</div>
              <div class="cc-card-subtitle text-muted"><?= currencySymbol() ?><?= number_format((float)($s['collected_total'] ?? 0), 2) ?> collected of <?= currencySymbol() ?><?= number_format((float)($s['billed_total'] ?? 0), 2) ?> billed</div>
            </div>
            <div>
              <span class="cc-badge-amber-text"><?= (int)($s['collected_pct'] ?? 38) ?>% collected</span>
            </div>
          </div>
          <div class="cc-chart-container" style="position: relative; height: 260px;">
            <canvas id="feeCollectionChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Admission Applications Trend Chart -->
      <div class="col-12 col-lg-6">
        <div class="cc-card h-100">
          <div class="cc-card-header mb-2">
            <div class="cc-card-title">Admission Applications Trend</div>
            <div class="cc-card-subtitle text-muted"><?= (int)($s['total_applications'] ?? 120) ?> total applications in selected period</div>
          </div>
          <div class="cc-chart-container" style="position: relative; height: 260px;">
            <canvas id="admissionsTrendChart"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- 6. Recent Activity Section -->
  <?php if (!empty($wp['widget_recent_activity'])): ?>
  <div class="cc-card mb-4">
    <div class="cc-card-header d-flex align-items-center justify-content-between border-bottom pb-3 mb-0">
      <div class="cc-card-title mb-0">Recent Activity</div>
      <a href="<?= e(url('audit')) ?>" class="cc-view-all text-decoration-none">
        View all <i data-lucide="arrow-right" style="width:14px;height:14px;"></i>
      </a>
    </div>

    <div class="cc-activity-list">
      <?php foreach (($s['recent_activities'] ?? []) as $act): ?>
      <div class="cc-activity-row">
        <div class="cc-activity-icon">
          <i data-lucide="file-text" style="width:16px;height:16px;"></i>
        </div>
        <div class="cc-activity-title">
          <?= $act['title'] ?>
        </div>
        <div class="cc-activity-role">
          <span class="cc-role-badge"><?= e($act['role'] ?? 'Administrator') ?></span>
        </div>
        <div class="cc-activity-time text-muted">
          <?= e($act['time'] ?? '') ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

</div>

<!-- Customize Dashboard Widgets Modal -->
<div class="modal fade" id="customizeDashboardModal" tabindex="-1" aria-labelledby="customizeDashboardModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-4">
      <form action="<?= e(url('dashboard/save-widgets')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="modal-header border-bottom py-3 px-4">
          <div class="d-flex align-items-center gap-2">
            <div class="rounded-3 p-2 bg-primary-subtle text-primary">
              <i data-lucide="layout-grid" style="width: 18px; height: 18px;"></i>
            </div>
            <div>
              <h5 class="modal-title fw-bold fs-6 mb-0" id="customizeDashboardModalLabel">Customize Dashboard Layout</h5>
              <small class="text-muted">Configure visible widgets and analytics cards</small>
            </div>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <p class="text-muted small mb-3">Toggle individual widgets on or off. Your layout preferences are automatically saved to your profile.</p>
          <div class="list-group list-group-flush gap-2">
            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="sparkles" class="text-primary" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Onboarding &amp; Setup Checklist</div>
                  <div class="text-muted" style="font-size: 11.5px;">Guided progress bar for school initialization</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_checklist]" value="1" <?= !empty($wp['widget_checklist']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="calendar" class="text-info" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Today's Attendance Summary</div>
                  <div class="text-muted" style="font-size: 11.5px;">Live student and faculty attendance percentage</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_attendance]" value="1" <?= !empty($wp['widget_attendance']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="bell" class="text-warning" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Action Items Pending</div>
                  <div class="text-muted" style="font-size: 11.5px;">Admission reviews and staff profile approvals</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_action_items]" value="1" <?= !empty($wp['widget_action_items']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="bar-chart-2" class="text-success" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Key Metric KPI Cards</div>
                  <div class="text-muted" style="font-size: 11.5px;">Enrolled students, staff, fees, and applications</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_kpis]" value="1" <?= !empty($wp['widget_kpis']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="cpu" class="text-primary" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">AI School Analytics Banner</div>
                  <div class="text-muted" style="font-size: 11.5px;">Multi-tenant executive summaries &amp; anomaly alerts</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_ai_analytics]" value="1" <?= !empty($wp['widget_ai_analytics']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="trending-up" class="text-danger" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Fee &amp; Admission Charts</div>
                  <div class="text-muted" style="font-size: 11.5px;">Interactive trends for billing, collection, and admissions</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_fee_chart]" value="1" <?= !empty($wp['widget_fee_chart']) ? 'checked' : '' ?>>
              </div>
            </label>

            <label class="list-group-item d-flex align-items-center justify-content-between p-3 border rounded-3 cursor-pointer">
              <div class="d-flex align-items-center gap-3">
                <i data-lucide="activity" class="text-secondary" style="width: 18px; height: 18px;"></i>
                <div>
                  <div class="fw-semibold text-dark small">Recent Activity Feed</div>
                  <div class="text-muted" style="font-size: 11.5px;">Latest audit logs and administrative actions</div>
                </div>
              </div>
              <div class="form-check form-switch m-0">
                <input class="form-check-input" type="checkbox" name="widgets[widget_recent_activity]" value="1" <?= !empty($wp['widget_recent_activity']) ? 'checked' : '' ?>>
              </div>
            </label>
          </div>
        </div>
        <div class="modal-footer border-top py-2.5 px-4 d-flex justify-content-between">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-sm btn-primary px-3 shadow-sm">Save Layout</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Chart.js Data & Initialization -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
function dismissSetupBanner() {
    const banner = document.getElementById('ccSetupBanner');
    if (banner) {
        banner.style.display = 'none';
        localStorage.setItem('codeclove-setup-banner', '1');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (localStorage.getItem('codeclove-setup-banner') === '1') {
        const banner = document.getElementById('ccSetupBanner');
        if (banner) banner.style.display = 'none';
    }

    // 1. Fee Collection Grouped Bar Chart (CodeClove Indigo #4f46e5 & Emerald #10b981)
    const feeCtx = document.getElementById('feeCollectionChart');
    if (feeCtx) {
        new Chart(feeCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($s['fee_chart_labels'] ?? ['Aug 26', 'Sep 26', 'Oct 26']) ?>,
                datasets: [
                    {
                        label: 'Billed',
                        data: <?= json_encode($s['fee_billed_series'] ?? [48000, 78000, 110360]) ?>,
                        backgroundColor: 'rgba(79, 70, 229, 0.65)',
                        borderRadius: 4,
                        barPercentage: 0.45,
                        categoryPercentage: 0.6
                    },
                    {
                        label: 'Collected',
                        data: <?= json_encode($s['fee_collected_series'] ?? [0, 24000, 41925]) ?>,
                        backgroundColor: '#10b981',
                        borderRadius: 4,
                        barPercentage: 0.45,
                        categoryPercentage: 0.6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'circle',
                            padding: 20,
                            font: { family: 'inherit', size: 12 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(ctx) {
                                return ctx.dataset.label + ': ₹' + Number(ctx.parsed.y).toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: 'inherit', size: 11 }, color: '#8c9ba5' }
                    },
                    y: {
                        grid: { color: '#f1f5f9' },
                        ticks: {
                            font: { family: 'inherit', size: 11 },
                            color: '#8c9ba5',
                            callback: function(val) {
                                return val >= 1000 ? (val / 1000) + 'k' : val;
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. Admission Applications Trend Curved Line/Area Chart (CodeClove Indigo #4f46e5)
    const admCtx = document.getElementById('admissionsTrendChart');
    if (admCtx) {
        const gradient = admCtx.getContext('2d').createLinearGradient(0, 0, 0, 240);
        gradient.addColorStop(0, 'rgba(79, 70, 229, 0.20)');
        gradient.addColorStop(1, 'rgba(79, 70, 229, 0.0)');

        new Chart(admCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($s['admission_labels'] ?? ['Aug 26', 'Sep 26', 'Oct 26']) ?>,
                datasets: [{
                    label: 'Applications',
                    data: <?= json_encode($s['admission_series'] ?? [10, 68, 52]) ?>,
                    borderColor: '#4f46e5',
                    borderWidth: 2.5,
                    backgroundColor: gradient,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#4f46e5',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        padding: 10,
                        titleFont: { size: 12 },
                        bodyFont: { size: 12 },
                        callbacks: {
                            label: function(ctx) {
                                return 'Applications: ' + ctx.parsed.y;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: 'inherit', size: 11 }, color: '#8c9ba5' }
                    },
                    y: {
                        grid: { color: '#f1f5f9' },
                        ticks: { font: { family: 'inherit', size: 11 }, color: '#8c9ba5' }
                    }
                }
            }
        });
    }
});
</script>