<?php
/**
 * Student Portal Dashboard - Genuine Data & Multitenant Isolation
 */

$student = $student ?? [];
$firstName = !empty($student['first_name']) ? $student['first_name'] : 'Student';
$lastName = !empty($student['last_name']) ? $student['last_name'] : '';
$studentDisplayName = trim($firstName . ' ' . $lastName);

$className = !empty($student['class_name']) ? $student['class_name'] : 'Class';
$sectionName = !empty($student['section_name']) ? $student['section_name'] : '';
$yearName = !empty($student['year_name']) ? $student['year_name'] : 'Academic Session';

$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$currentDateDisplay = date('l, M j, Y');

$todayTimetable = $todayTimetable ?? [];
$upcomingHomework = $upcomingHomework ?? [];
$announcements = $announcements ?? [];

// Calendar
$currentYear = (int) date('Y');
$currentMonth = (int) date('n');
$currentDay = (int) date('j');
$daysInMonth = (int) date('t');
$firstDayOfWeek = (int) date('N', strtotime("{$currentYear}-{$currentMonth}-01"));
$monthName = date('M Y');
?>

<!-- 1. Top Welcome Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
  <div class="card-body p-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
      <div>
        <div class="d-flex align-items-center gap-2 text-muted small mb-2" style="font-size: 13px;">
          <i data-lucide="calendar" style="width: 15px; height: 15px; color: #4f46e5;"></i>
          <span><?= e($currentDateDisplay) ?></span>
        </div>
        <h2 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
          <?= e($greeting) ?>, <?= e($studentDisplayName) ?>!
        </h2>
        <div class="text-secondary small fw-normal" style="font-size: 13px;">
          <?= e($className) ?><?= $sectionName ? ' • Section ' . e($sectionName) : '' ?> • <?= e($yearName) ?>
        </div>
      </div>

      <div class="d-flex align-items-center gap-2">
        <a href="<?= e(url('portal/resources')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 rounded-3 px-3 py-2 shadow-sm">
          <i data-lucide="book-marked" style="width: 14px; height: 14px;"></i>
          <span>Study Materials</span>
        </a>
        <span class="badge rounded-pill d-inline-flex align-items-center gap-1 px-3 py-2" style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 12px; font-weight: 500;">
          <i data-lucide="shield-check" style="width: 14px; height: 14px;"></i>
          <span>Enrolled Student</span>
        </span>
      </div>
    </div>
  </div>
</div>

<!-- 2. Three Metric Stat Cards Row -->
<div class="row g-4 mb-4">
  <!-- Metric 1: ATTENDANCE -->
  <div class="col-12 col-md-4">
    <a href="<?= e(url('portal/attendance')) ?>" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100 metric-hover-card" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; transition: all 0.2s ease;">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="small fw-bold text-uppercase" style="color: #64748b; font-size: 11px; letter-spacing: 0.05em;">ATTENDANCE</span>
            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #f0fdf4; width: 34px; height: 34px;">
              <i data-lucide="check-circle" style="width: 16px; height: 16px; stroke: #16a34a;"></i>
            </div>
          </div>
          <div class="h2 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= number_format($attendanceRate, 1) ?>%
          </div>
          <div class="d-flex align-items-center gap-1 mb-1">
            <span style="width: 7px; height: 7px; border-radius: 50%; background-color: <?= $attendanceRate >= 75 ? '#16a34a' : '#ef4444' ?>; display: inline-block;"></span>
            <span class="small fw-semibold" style="color: <?= $attendanceRate >= 75 ? '#16a34a' : '#ef4444' ?>; font-size: 12px;">
              <?= $attendanceRate >= 75 ? 'Good Standing' : 'Needs Regularity' ?>
            </span>
          </div>
          <div class="text-muted small" style="font-size: 12px;">
            <?= $presentCount ?> of <?= $totalAttendanceDays ?> days present
          </div>
        </div>
      </div>
    </a>
  </div>

  <!-- Metric 2: CURRICULUM -->
  <div class="col-12 col-md-4">
    <a href="<?= e(url('portal/academics')) ?>" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100 metric-hover-card" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; transition: all 0.2s ease;">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="small fw-bold text-uppercase" style="color: #64748b; font-size: 11px; letter-spacing: 0.05em;">CURRICULUM</span>
            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 34px; height: 34px;">
              <i data-lucide="book-open" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
            </div>
          </div>
          <div class="h2 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= (int) $subjectsCount ?> Subjects
          </div>
          <div class="d-flex align-items-center gap-1 mb-1">
            <span style="width: 7px; height: 7px; border-radius: 50%; background-color: #4f46e5; display: inline-block;"></span>
            <span class="small fw-semibold" style="color: #4f46e5; font-size: 12px;"><?= e($className) ?> Syllabus</span>
          </div>
          <div class="text-muted small" style="font-size: 12px;">
            Active Academic Subjects
          </div>
        </div>
      </div>
    </a>
  </div>

  <!-- Metric 3: FEE STANDING -->
  <div class="col-12 col-md-4">
    <a href="<?= e(url('portal/finance')) ?>" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100 metric-hover-card" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff; transition: all 0.2s ease;">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="small fw-bold text-uppercase" style="color: #64748b; font-size: 11px; letter-spacing: 0.05em;">FEE STANDING</span>
            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: <?= $totalDue > 0 ? '#fef2f2' : '#f0fdf4' ?>; width: 34px; height: 34px;">
              <i data-lucide="credit-card" style="width: 16px; height: 16px; stroke: <?= $totalDue > 0 ? '#ef4444' : '#16a34a' ?>;"></i>
            </div>
          </div>
          <div class="h2 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            $<?= number_format($totalDue, 2) ?>
          </div>
          <div class="d-flex align-items-center gap-1 mb-1">
            <span style="width: 7px; height: 7px; border-radius: 50%; background-color: <?= $totalDue <= 0 ? '#16a34a' : '#ef4444' ?>; display: inline-block;"></span>
            <span class="small fw-semibold" style="color: <?= $totalDue <= 0 ? '#16a34a' : '#ef4444' ?>; font-size: 12px;"><?= $totalDue <= 0 ? 'Fully Settled' : 'Pending Payment' ?></span>
          </div>
          <div class="text-muted small" style="font-size: 12px;">
            Paid $<?= number_format($totalPaid, 2) ?>
          </div>
        </div>
      </div>
    </a>
  </div>
</div>

<!-- 3. Bottom Grid: Today's Schedule & Announcements -->
<div class="row g-4">
  <!-- Left Column: Today's Schedule & Homework -->
  <div class="col-12 col-lg-7">
    <!-- Today's Schedule -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-header bg-white border-0 p-4 pb-2 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-3">
          <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: #eef2ff; width: 32px; height: 32px;">
            <i data-lucide="clock" style="width: 16px; height: 16px; stroke: #4f46e5;"></i>
          </div>
          <div>
            <h3 class="h6 fw-bold text-dark mb-0">Today's Schedule</h3>
            <span class="text-muted small" style="font-size: 12px;"><?= count($todayTimetable) ?> periods scheduled</span>
          </div>
        </div>
        <a href="<?= e(url('portal/timetable')) ?>" class="text-decoration-none small fw-semibold text-primary d-inline-flex align-items-center gap-1" style="font-size: 12px;">
          <span>Full Timetable</span>
          <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
        </a>
      </div>

      <div class="card-body p-0">
        <?php if (empty($todayTimetable)): ?>
          <div class="p-4 text-center text-muted">
            <i data-lucide="calendar" style="width: 32px; height: 32px; opacity: 0.3;" class="mb-2"></i>
            <div class="fw-semibold text-dark small">No Scheduled Classes Today</div>
            <div class="small text-muted">Enjoy your break or catch up on assigned homework.</div>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php foreach ($todayTimetable as $tt): ?>
              <div class="list-group-item px-4 py-3 border-bottom d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                  <div class="text-center font-monospace" style="min-width: 65px; line-height: 1.2;">
                    <div class="fw-bold text-dark" style="font-size: 13px;"><?= date('H:i', strtotime($tt['start_time'])) ?></div>
                    <div class="text-muted" style="font-size: 11px;">to <?= date('H:i', strtotime($tt['end_time'])) ?></div>
                  </div>
                  <div class="vr mx-1 text-muted opacity-25" style="height: 28px;"></div>
                  <div>
                    <h4 class="h6 fw-bold text-dark mb-0" style="font-size: 13.5px;"><?= e($tt['subject_name'] ?? 'Class Period') ?></h4>
                    <span class="text-secondary small" style="font-size: 11.5px; color: #64748b;">
                      Period <?= e((string)$tt['period_number']) ?> • <?= e($tt['teacher_name'] ?: 'Faculty') ?>
                      <?= !empty($tt['room_name']) ? ' • Room ' . e($tt['room_name']) : '' ?>
                    </span>
                  </div>
                </div>
                <span class="badge rounded-pill px-3 py-1 fw-normal" style="background: #f1f5f9; color: #475569; font-size: 11px;">
                  Active
                </span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Upcoming Homework Tasks -->
    <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="clipboard-list" style="width: 16px; height: 16px; color: #4f46e5;"></i>
          <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">Pending Homework &amp; Tasks</h3>
        </div>
        <a href="<?= e(url('portal/assignments')) ?>" class="text-decoration-none small fw-semibold text-primary" style="font-size: 12px;">View all</a>
      </div>
      <div class="card-body p-0">
        <?php if (empty($upcomingHomework)): ?>
          <div class="p-4 text-center text-muted">
            <i data-lucide="check" style="width: 28px; height: 28px; opacity: 0.3;" class="mb-1 text-success"></i>
            <div class="small fw-semibold text-dark">No Pending Tasks</div>
            <div class="text-muted" style="font-size: 11px;">You are all caught up on your assignments!</div>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php foreach ($upcomingHomework as $hw): ?>
              <div class="list-group-item p-3 border-bottom d-flex justify-content-between align-items-center">
                <div>
                  <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="badge bg-primary-subtle text-primary" style="font-size: 10px;"><?= e($hw['subject_name'] ?? 'Task') ?></span>
                    <h6 class="fw-bold text-dark mb-0" style="font-size: 13px;"><?= e($hw['title']) ?></h6>
                  </div>
                  <div class="text-muted small" style="font-size: 11.5px;">
                    Due: <span class="fw-medium text-danger"><?= date('M j, Y', strtotime($hw['due_date'])) ?></span>
                  </div>
                </div>
                <a href="<?= e(url('portal/assignments')) ?>" class="btn btn-sm btn-primary" style="font-size: 11.5px;">Submit</a>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right Column: Calendar & School Announcements -->
  <div class="col-12 col-lg-5">
    <!-- Calendar Card -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
        <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">Calendar Overview</h3>
        <span class="text-secondary small fw-medium"><?= e($monthName) ?></span>
      </div>

      <div class="card-body p-4">
        <div class="table-responsive">
          <table class="table table-borderless text-center mb-0" style="font-size: 12px;">
            <thead>
              <tr class="text-muted">
                <th class="p-1 fw-bold">MO</th>
                <th class="p-1 fw-bold">TU</th>
                <th class="p-1 fw-bold">WE</th>
                <th class="p-1 fw-bold">TH</th>
                <th class="p-1 fw-bold">FR</th>
                <th class="p-1 fw-bold">SA</th>
                <th class="p-1 fw-bold">SU</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $dayCounter = 1;
                $cellsWritten = 0;
                $totalWeeks = ceil(($firstDayOfWeek - 1 + $daysInMonth) / 7);

                for ($w = 0; $w < $totalWeeks; $w++):
              ?>
                <tr>
                  <?php for ($d = 1; $d <= 7; $d++): ?>
                    <td class="p-1" style="height: 38px;">
                      <?php 
                        $cellsWritten++;
                        if ($cellsWritten >= $firstDayOfWeek && $dayCounter <= $daysInMonth): 
                          $isToday = ($dayCounter === $currentDay);
                      ?>
                        <?php if ($isToday): ?>
                          <span style="width: 30px; height: 30px; border-radius: 50%; border: 1.5px solid #6366f1; color: #4f46e5; display: inline-flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; background: #eff6ff;">
                            <?= $dayCounter ?>
                          </span>
                        <?php else: ?>
                          <span class="text-secondary" style="font-size: 12px; font-weight: 500;">
                            <?= $dayCounter ?>
                          </span>
                        <?php endif; ?>
                        <?php $dayCounter++; ?>
                      <?php endif; ?>
                    </td>
                  <?php endfor; ?>
                </tr>
              <?php endfor; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Real School Announcements Card -->
    <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
      <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="bell" style="width: 15px; height: 15px; color: #4f46e5;"></i>
          <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">School Announcements</h3>
        </div>
        <a href="<?= e(url('noticeboard')) ?>" class="text-decoration-none small fw-semibold text-primary" style="font-size: 12px;">View all</a>
      </div>

      <div class="card-body p-0">
        <?php if (empty($announcements)): ?>
          <div class="p-4 text-center text-muted">
            <i data-lucide="bell-off" style="width: 28px; height: 28px; opacity: 0.3;" class="mb-1"></i>
            <div class="small fw-semibold text-dark">No Recent Announcements</div>
            <div class="text-muted" style="font-size: 11px;">School notices will appear here.</div>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php foreach ($announcements as $anc): ?>
              <div class="list-group-item p-3 border-bottom">
                <div class="d-flex justify-content-between align-items-start mb-1">
                  <h4 class="h6 fw-semibold text-dark mb-0" style="font-size: 12.5px;"><?= e($anc['title']) ?></h4>
                  <span class="badge rounded-pill bg-light text-muted border" style="font-size: 9.5px;">Notice</span>
                </div>
                <p class="text-secondary small mb-1" style="font-size: 11.5px; line-height: 1.4;">
                  <?= e(mb_substr($anc['body'], 0, 130)) ?><?= mb_strlen($anc['body']) > 130 ? '...' : '' ?>
                </p>
                <span class="text-muted font-monospace" style="font-size: 10px;">
                  <?= date('d/m/Y', strtotime($anc['created_at'])) ?>
                </span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<style>
.metric-hover-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.03) !important;
}
</style>
