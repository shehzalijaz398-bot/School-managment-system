<?php
$title = $title ?? 'Principal Executive Cockpit';
$studentsCount = (int)($stats['students'] ?? 0);
$teachersCount = (int)($stats['teachers'] ?? 0);
$classesCount  = (int)($stats['classes_count'] ?? 0);
$stdAtt = $stats['student_attendance'] ?? [];
$stfAtt = $stats['staff_attendance'] ?? [];
$unsubmitted = $stats['unsubmitted_sections'] ?? [];
$pendingLeaves = $stats['pending_leaves'] ?? [];
$atRiskStudents = $stats['at_risk_students'] ?? [];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 font-weight-bold text-gray-800 mb-1">
            <i class="fas fa-graduation-cap text-primary me-2"></i>Principal Executive Cockpit
        </h1>
        <p class="text-muted small mb-0">Institutional health, attendance compliance, pending approvals & daily operations overview.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('attendance/students')) ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-calendar-check me-1"></i>Attendance Matrix
        </a>
        <a href="<?= e(url('exams')) ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-file-signature me-1"></i>Examination Desk
        </a>
        <a href="<?= e(url('announcements/create')) ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-bullhorn me-1"></i>Broadcast Notice
        </a>
    </div>
</div>

<!-- TOP KPI METRICS -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-primary border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Active Students</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= number_format($studentsCount) ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-chalkboard me-1"></i>Across <?= $classesCount ?> Classes</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                            <i class="fas fa-user-graduate fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-success border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Student Attendance Today</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= (float)($stdAtt['percentage'] ?? 0) ?>%</div>
                        <div class="text-muted small mt-1"><?= (int)($stdAtt['present'] ?? 0) ?> Present / <?= (int)($stdAtt['total'] ?? 0) ?> Total</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success">
                            <i class="fas fa-check-double fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-info border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Teaching Faculty</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $teachersCount ?></div>
                        <div class="text-muted small mt-1">Staff Present Today: <?= (float)($stfAtt['percentage'] ?? 0) ?>%</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle text-info">
                            <i class="fas fa-chalkboard-teacher fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-warning border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Approvals</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= count($pendingLeaves) + (int)($stats['pending_admissions'] ?? 0) ?></div>
                        <div class="text-muted small mt-1"><?= count($pendingLeaves) ?> Leaves &bull; <?= (int)($stats['pending_admissions'] ?? 0) ?> Admissions</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                            <i class="fas fa-tasks fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ATTENTION BANNER: UNRECORDED ATTENDANCE -->
<?php if (!empty($unsubmitted)): ?>
<div class="alert alert-warning border-0 shadow-sm d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center">
        <div class="bg-warning text-dark p-2 rounded-circle me-3">
            <i class="fas fa-exclamation-triangle fa-lg"></i>
        </div>
        <div>
            <h6 class="mb-0 font-weight-bold">Daily Attendance Notice: <?= count($unsubmitted) ?> Section(s) Pending Today</h6>
            <div class="small text-muted">The following sections have not submitted morning attendance: 
                <strong><?= implode(', ', array_map(fn($s) => e($s['class_name'] . ' (' . $s['section_name'] . ')'), array_slice($unsubmitted, 0, 5))) ?><?= count($unsubmitted) > 5 ? ' and ' . (count($unsubmitted) - 5) . ' more' : '' ?></strong>
            </div>
        </div>
    </div>
    <a href="<?= e(url('attendance/students')) ?>" class="btn btn-warning btn-sm text-dark font-weight-bold">
        <i class="fas fa-clipboard-check me-1"></i>Open Register
    </a>
</div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <!-- LEFT COLUMN: PENDING LEAVES & AT-RISK STUDENTS -->
    <div class="col-lg-7">
        <!-- PENDING LEAVE REQUESTS -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-user-clock text-warning me-2"></i>Pending Staff Leave Approvals
                </h6>
                <a href="<?= e(url('leaves')) ?>" class="text-primary small font-weight-bold text-decoration-none">
                    View All (<?= count($pendingLeaves) ?>) &rarr;
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($pendingLeaves)): ?>
                    <div class="text-center py-4 text-muted small">
                        <i class="fas fa-check-circle fa-2x text-success mb-2"></i><br>
                        All staff leave requests are fully reviewed and up to date.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Staff Member</th>
                                    <th>Leave Type</th>
                                    <th>Duration</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($pendingLeaves as $leave): ?>
                                <tr>
                                    <td class="font-weight-bold text-dark"><?= e($leave['staff_name']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= e($leave['leave_type_name'] ?? 'Leave') ?></span></td>
                                    <td><?= e(date('d M', strtotime($leave['start_date']))) ?> - <?= e(date('d M Y', strtotime($leave['end_date']))) ?></td>
                                    <td>
                                        <a href="<?= e(url('leaves')) ?>" class="btn btn-sm btn-outline-primary py-0 px-2">
                                            Review
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- STUDENTS WITH AT-RISK ATTENDANCE -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-user-shield text-danger me-2"></i>Low Attendance Alerts (&lt; 75%)
                </h6>
                <span class="badge bg-danger bg-opacity-10 text-danger"><?= count($atRiskStudents) ?> At Risk</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($atRiskStudents)): ?>
                    <div class="text-center py-4 text-muted small">
                        <i class="fas fa-shield-alt fa-2x text-success mb-2"></i><br>
                        Institutional student attendance is in compliance (&ge; 75%).
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Student</th>
                                    <th>Class</th>
                                    <th>Attendance</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($atRiskStudents as $st): ?>
                                <tr>
                                    <td>
                                        <div class="font-weight-bold text-dark"><?= e($st['first_name'] . ' ' . $st['last_name']) ?></div>
                                        <span class="text-muted text-xs"><?= e($st['admission_no']) ?></span>
                                    </td>
                                    <td><?= e($st['class_name']) ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 6px; width: 70px;">
                                                <div class="progress-bar bg-danger" style="width: <?= (float)$st['attendance_pct'] ?>%"></div>
                                            </div>
                                            <span class="font-weight-bold text-danger"><?= (float)$st['attendance_pct'] ?>%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?= e(url('students/' . $st['id'])) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2">
                                            Profile
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- RIGHT COLUMN: QUICK SHORTCUTS & RECENT INSTITUTIONAL ACTIONS -->
    <div class="col-lg-5">
        <!-- QUICK MANAGEMENT ACTIONS -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 border-bottom">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-bolt text-warning me-2"></i>Principal Quick Actions
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-6">
                        <a href="<?= e(url('attendance/students')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-calendar-check text-primary fa-lg me-2"></i>
                            <span class="small font-weight-bold">Mark Attendance</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?= e(url('admissions')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-user-plus text-success fa-lg me-2"></i>
                            <span class="small font-weight-bold">Review Admissions</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?= e(url('timetable')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-table text-info fa-lg me-2"></i>
                            <span class="small font-weight-bold">Timetable Matrix</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?= e(url('exams')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-award text-warning fa-lg me-2"></i>
                            <span class="small font-weight-bold">Exam Results</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?= e(url('leaves')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-plane-departure text-secondary fa-lg me-2"></i>
                            <span class="small font-weight-bold">Leave Approvals</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?= e(url('finance/overview')) ?>" class="btn btn-light border w-100 text-start py-2 d-flex align-items-center">
                            <i class="fas fa-coins text-success fa-lg me-2"></i>
                            <span class="small font-weight-bold">Financial Glance</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- RECENT AUDIT ACTIVITY -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-history text-secondary me-2"></i>Recent Administrative Activity
                </h6>
                <a href="<?= e(url('audit')) ?>" class="text-primary small font-weight-bold text-decoration-none">Full Audit &rarr;</a>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush small">
                    <?php 
                    $activities = array_merge($stats['activity']['attendance'] ?? [], $stats['activity']['hr'] ?? []);
                    if (empty($activities)): 
                    ?>
                        <li class="list-group-item text-center py-4 text-muted">No recent activity logs found.</li>
                    <?php else: ?>
                        <?php foreach (array_slice($activities, 0, 5) as $act): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                            <div>
                                <div class="font-weight-bold text-dark"><?= e($act['action'] ?? 'System Event') ?></div>
                                <span class="text-muted text-xs"><?= e($act['user_name'] ?? 'Administrator') ?></span>
                            </div>
                            <span class="text-muted text-xs"><?= e(date('d M, H:i', strtotime($act['created_at'] ?? 'now'))) ?></span>
                        </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>