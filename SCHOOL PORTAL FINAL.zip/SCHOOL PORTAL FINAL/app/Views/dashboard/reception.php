<?php
$title = $title ?? 'Front Desk & Reception Cockpit';
$activeVisitors     = (int)($stats['active_visitors'] ?? 0);
$visitorsToday      = (int)($stats['visitors_today'] ?? 0);
$newInquiries       = (int)($stats['new_inquiries'] ?? 0);
$totalInquiriesMonth= (int)($stats['total_inquiries_month'] ?? 0);
$admissionsCount    = (int)($stats['admissions'] ?? 0);
$recentVisitors     = $stats['recent_visitors'] ?? [];
$recentInquiries    = $stats['recent_inquiries'] ?? [];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 font-weight-bold text-gray-800 mb-1">
            <i class="fas fa-concierge-bell text-primary me-2"></i>Front Desk & Reception Cockpit
        </h1>
        <p class="text-muted small mb-0">Visitor registry, campus security passes, incoming inquiries & admission follow-ups.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('reception/visitors/create')) ?>" class="btn btn-primary btn-sm font-weight-bold">
            <i class="fas fa-id-badge me-1"></i>New Visitor Pass
        </a>
        <a href="<?= e(url('admissions/inquiries/create')) ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-headset me-1"></i>Log Inquiry
        </a>
        <a href="<?= e(url('students/create')) ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-user-plus me-1"></i>Student Admission
        </a>
    </div>
</div>

<!-- TOP KPIS -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-warning border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Active on Campus</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $activeVisitors ?></div>
                        <div class="text-muted small mt-1">Visitors Currently Inside</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                            <i class="fas fa-user-shield fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-primary border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Visitors Today</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $visitorsToday ?></div>
                        <div class="text-muted small mt-1"><i class="fas fa-calendar-day me-1"></i><?= date('d M Y') ?></div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-success border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">New Inquiries</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $newInquiries ?></div>
                        <div class="text-muted small mt-1"><?= $totalInquiriesMonth ?> in last 30 days</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success">
                            <i class="fas fa-envelope-open-text fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card shadow-sm border-0 border-start border-info border-4 h-100 py-2">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Admissions Pipeline</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?= $admissionsCount ?></div>
                        <div class="text-muted small mt-1">Under Review & Scheduled</div>
                    </div>
                    <div class="col-auto">
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle text-info">
                            <i class="fas fa-user-graduate fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- LEFT: TODAY'S VISITORS LOG -->
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-id-card text-primary me-2"></i>Campus Visitors Today
                </h6>
                <a href="<?= e(url('reception')) ?>" class="text-primary small font-weight-bold text-decoration-none">
                    View Registry &rarr;
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentVisitors)): ?>
                    <div class="text-center py-4 text-muted small">No visitor check-ins recorded today.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Visitor</th>
                                    <th>Meeting Person</th>
                                    <th>Purpose</th>
                                    <th>Check In</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($recentVisitors as $v): 
                                    $isOnCampus = empty($v['check_out']);
                                ?>
                                <tr>
                                    <td>
                                        <div class="font-weight-bold text-dark"><?= e($v['visitor_name']) ?></div>
                                        <span class="text-muted text-xs"><?= e($v['phone'] ?? '-') ?></span>
                                    </td>
                                    <td><?= e($v['person_to_meet'] ?? 'General') ?></td>
                                    <td><span class="text-truncate d-inline-block" style="max-width: 140px;"><?= e($v['purpose'] ?? 'Visit') ?></span></td>
                                    <td><?= e(date('H:i', strtotime($v['check_in']))) ?></td>
                                    <td>
                                        <?php if ($isOnCampus): ?>
                                            <span class="badge bg-warning text-dark"><i class="fas fa-circle text-danger me-1"></i>On Campus</span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-muted border">Departed (<?= e(date('H:i', strtotime($v['check_out']))) ?>)</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- RIGHT: RECENT ADMISSION INQUIRIES -->
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-dark">
                    <i class="fas fa-clipboard-list text-success me-2"></i>Recent Admission Inquiries
                </h6>
                <a href="<?= e(url('admissions')) ?>" class="text-primary small font-weight-bold text-decoration-none">
                    Admissions Desk &rarr;
                </a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentInquiries)): ?>
                    <div class="text-center py-4 text-muted small">No new admission inquiries recorded.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th>Applicant</th>
                                    <th>Parent & Phone</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="small">
                                <?php foreach ($recentInquiries as $inq): ?>
                                <tr>
                                    <td>
                                        <div class="font-weight-bold text-dark"><?= e($inq['student_name']) ?></div>
                                        <span class="text-muted text-xs">Interested: <?= e($inq['class_name'] ?? 'Class') ?></span>
                                    </td>
                                    <td>
                                        <div><?= e($inq['parent_name'] ?? '-') ?></div>
                                        <span class="text-muted text-xs"><?= e($inq['phone'] ?? '-') ?></span>
                                    </td>
                                    <td>
                                        <?php
                                        $statusClass = match($inq['status']) {
                                            'new' => 'bg-warning text-dark',
                                            'contacted' => 'bg-info text-white',
                                            'converted' => 'bg-success text-white',
                                            default => 'bg-light text-dark border',
                                        };
                                        ?>
                                        <span class="badge <?= $statusClass ?>"><?= strtoupper(e($inq['status'])) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
