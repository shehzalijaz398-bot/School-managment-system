<?php
$todayClasses   = $stats['today_classes'] ?? [];
$assignedSubs   = $stats['assignments_teaching'] ?? [];
$recentAssign   = $stats['recent_assignments'] ?? [];
$announcements  = $stats['announcements'] ?? [];
$upcomingExams  = $stats['upcoming_exams'] ?? [];

$teacherName = $teacher['first_name'] ?? $user['name'] ?? 'Teacher';
if (!empty($teacher['last_name'])) {
    $teacherName .= ' ' . $teacher['last_name'];
}

// Distinct subjects count
$distinctSubjects = [];
foreach ($assignedSubs as $asg) {
    if (!empty($asg['subject_name'])) {
        $distinctSubjects[$asg['subject_name']] = true;
    }
}
$distinctSubjectCount = count($distinctSubjects);
?>

<div class="teacher-dashboard-wrap">

  <!-- 1. Teacher Welcome Banner -->
  <div class="card border-0 shadow-sm rounded-3 p-4 mb-4 bg-white cc-settings-card">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
      <div class="d-flex align-items-center gap-3">
        <div class="cc-card-icon-box" style="width: 48px; height: 48px; border-radius: 12px; font-size: 20px;">
          <i data-lucide="graduation-cap" style="width: 24px; height: 24px;"></i>
        </div>
        <div>
          <h1 class="h4 fw-bold text-dark mb-1" style="font-size: 20px;">
            Welcome back, <?= e($teacherName) ?> 👋
          </h1>
          <p class="text-muted mb-0" style="font-size: 13.5px;">
            Here is your daily teaching schedule, assigned classes, and student attendance shortcuts.
          </p>
        </div>
      </div>

      <!-- Quick Action Shortcuts -->
      <div class="d-flex flex-wrap align-items-center gap-2">
        <a href="<?= e(url('attendance/students')) ?>" class="btn text-white fw-semibold px-3 py-2 d-inline-flex align-items-center gap-2 cc-save-btn">
          <i data-lucide="calendar-check" style="width: 15px; height: 15px;"></i>
          <span>Mark Attendance</span>
        </a>
        <a href="<?= e(url('timetable')) ?>" class="btn btn-outline-secondary px-3 py-2 d-inline-flex align-items-center gap-2" style="border-radius: 8px; font-size: 13.5px;">
          <i data-lucide="calendar" style="width: 15px; height: 15px;"></i>
          <span>Timetable</span>
        </a>
        <a href="<?= e(url('students')) ?>" class="btn btn-outline-secondary px-3 py-2 d-inline-flex align-items-center gap-2" style="border-radius: 8px; font-size: 13.5px;">
          <i data-lucide="users" style="width: 15px; height: 15px;"></i>
          <span>Students</span>
        </a>
      </div>
    </div>
  </div>

  <!-- 2. KPI Metrics Row -->
  <div class="row g-3 mb-4">
    <!-- Card 1: Assigned Classes -->
    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-3 p-3 bg-white cc-settings-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium" style="font-size: 12.5px;">Assigned Classes</span>
          <div class="cc-card-icon-box" style="width: 32px; height: 32px;">
            <i data-lucide="book-open" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1"><?= count($assignedSubs) ?></div>
        <div class="text-muted" style="font-size: 12px;">Active class &amp; section links</div>
      </div>
    </div>

    <!-- Card 2: Periods Today -->
    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-3 p-3 bg-white cc-settings-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium" style="font-size: 12.5px;">Periods Today</span>
          <div class="cc-card-icon-box" style="width: 32px; height: 32px;">
            <i data-lucide="clock" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1"><?= count($todayClasses) ?></div>
        <div class="text-muted" style="font-size: 12px;"><?= date('l, d M') ?></div>
      </div>
    </div>

    <!-- Card 3: Teaching Subjects -->
    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-3 p-3 bg-white cc-settings-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium" style="font-size: 12.5px;">Teaching Subjects</span>
          <div class="cc-card-icon-box" style="width: 32px; height: 32px;">
            <i data-lucide="book-marked" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1"><?= $distinctSubjectCount ?></div>
        <div class="text-muted" style="font-size: 12px;">Subject specializations</div>
      </div>
    </div>

    <!-- Card 4: Quick Register -->
    <div class="col-sm-6 col-lg-3">
      <div class="card border-0 shadow-sm rounded-3 p-3 bg-white cc-settings-card h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="text-muted small fw-medium" style="font-size: 12.5px;">Student Attendance</span>
          <div class="cc-card-icon-box" style="width: 32px; height: 32px;">
            <i data-lucide="user-check" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="h3 fw-bold text-dark mb-1">Daily</div>
        <div class="text-muted" style="font-size: 12px;"><a href="<?= e(url('attendance/students')) ?>" class="text-decoration-none">Open Register &rarr;</a></div>
      </div>
    </div>
  </div>

  <!-- 3. Main Content: Today's Schedule & Assigned Subjects -->
  <div class="row g-4 mb-4">
    <!-- Left Column: Today's Class Schedule -->
    <div class="col-lg-7">
      <div class="card border-0 shadow-sm rounded-3 bg-white cc-settings-card h-100 overflow-hidden">
        <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
          <div class="d-flex align-items-center gap-2">
            <div class="cc-card-icon-box" style="width: 28px; height: 28px;">
              <i data-lucide="calendar-days" style="width: 15px; height: 15px;"></i>
            </div>
            <h2 class="h6 fw-bold text-dark mb-0" style="font-size: 15px;">Today's Class Schedule</h2>
          </div>
          <span class="badge rounded-pill px-2.5 py-1" style="background-color: var(--sp-primary-light, rgba(79, 70, 229, 0.1)); color: var(--sp-primary, #4f46e5); font-size: 11px;">
            <?= date('l, d M Y') ?>
          </span>
        </div>

        <div class="p-0">
          <?php if (empty($todayClasses)): ?>
            <div class="p-5 text-center">
              <div class="d-inline-flex align-items-center justify-content-center p-3 rounded-circle mb-3" style="background: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.08); color: var(--sp-primary, #4f46e5);">
                <i data-lucide="coffee" style="width: 32px; height: 32px;"></i>
              </div>
              <h3 class="h6 fw-bold text-dark mb-1">Free Day Ahead</h3>
              <p class="text-muted small mb-0">No teaching classes or periods are scheduled for today.</p>
            </div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-hover align-middle mb-0" style="font-size: 13.5px;">
                <thead class="bg-light">
                  <tr>
                    <th class="ps-3 py-2.5">Time</th>
                    <th class="py-2.5">Class &amp; Section</th>
                    <th class="py-2.5">Subject</th>
                    <th class="py-2.5">Room</th>
                    <th class="text-end pe-3 py-2.5">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($todayClasses as $c): ?>
                    <tr>
                      <td class="ps-3">
                        <span class="badge rounded-2 py-1 px-2 fw-medium" style="background: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.1); color: var(--sp-primary, #4f46e5); font-size: 11.5px;">
                          <?= e(substr($c['start_time'], 0, 5)) ?> – <?= e(substr($c['end_time'], 0, 5)) ?>
                        </span>
                      </td>
                      <td class="fw-semibold text-dark">
                        <?= e($c['class_name']) ?> <span class="text-muted">(Section <?= e($c['section_name']) ?>)</span>
                      </td>
                      <td>
                        <span class="fw-medium text-dark"><?= e($c['subject_name']) ?></span>
                      </td>
                      <td class="text-muted">
                        <?= e($c['room_no'] ?? 'Standard Room') ?>
                      </td>
                      <td class="text-end pe-3">
                        <a href="<?= e(url('attendance/students?class_id=' . $c['class_id'] . '&section_id=' . $c['section_id'])) ?>" class="btn btn-sm btn-outline-primary py-1 px-2.5 d-inline-flex align-items-center gap-1" style="font-size: 12px; border-radius: 6px;">
                          <i data-lucide="check" style="width: 12px; height: 12px;"></i> Mark Attendance
                        </a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Right Column: My Assigned Subjects & Classes -->
    <div class="col-lg-5">
      <div class="card border-0 shadow-sm rounded-3 bg-white cc-settings-card h-100 overflow-hidden">
        <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
          <div class="d-flex align-items-center gap-2">
            <div class="cc-card-icon-box" style="width: 28px; height: 28px;">
              <i data-lucide="book-marked" style="width: 15px; height: 15px;"></i>
            </div>
            <h2 class="h6 fw-bold text-dark mb-0" style="font-size: 15px;">My Assigned Subjects</h2>
          </div>
          <span class="text-muted small" style="font-size: 12px;"><?= count($assignedSubs) ?> Total</span>
        </div>

        <div class="p-3">
          <?php if (empty($assignedSubs)): ?>
            <div class="p-4 text-center">
              <div class="d-inline-flex align-items-center justify-content-center p-3 rounded-circle mb-3" style="background: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.08); color: var(--sp-primary, #4f46e5);">
                <i data-lucide="book-open" style="width: 28px; height: 28px;"></i>
              </div>
              <h3 class="h6 fw-bold text-dark mb-1">No Classes Assigned Yet</h3>
              <p class="text-muted small mb-0">Ask your school administrator to assign classes to your teacher profile.</p>
            </div>
          <?php else: ?>
            <div class="d-flex flex-column gap-2">
              <?php foreach ($assignedSubs as $a): ?>
                <div class="p-2.5 rounded-3 border bg-light d-flex align-items-center justify-content-between gap-2">
                  <div class="d-flex align-items-center gap-2.5">
                    <div class="d-flex align-items-center justify-content-center rounded-2" style="width: 34px; height: 34px; background: rgba(var(--sp-primary-rgb, 79, 70, 229), 0.12); color: var(--sp-primary, #4f46e5); font-weight: bold; font-size: 13px;">
                      <?= strtoupper(substr($a['subject_name'] ?? 'S', 0, 2)) ?>
                    </div>
                    <div>
                      <div class="fw-semibold text-dark" style="font-size: 13.5px;"><?= e($a['subject_name']) ?></div>
                      <div class="text-muted" style="font-size: 12px;"><?= e($a['class_name']) ?> &bull; Section <?= e($a['section_name']) ?></div>
                    </div>
                  </div>
                  <a href="<?= e(url('attendance/students?class_id=' . $a['class_id'] . '&section_id=' . $a['section_id'])) ?>" class="btn btn-sm btn-light border py-1 px-2.5 text-secondary" style="font-size: 12px;" title="Take Attendance">
                    Attendance
                  </a>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- 4. Bottom Row: School Announcements & Notes -->
  <div class="row g-4">
    <div class="col-12">
      <div class="card border-0 shadow-sm rounded-3 bg-white cc-settings-card overflow-hidden">
        <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
          <div class="d-flex align-items-center gap-2">
            <div class="cc-card-icon-box" style="width: 28px; height: 28px;">
              <i data-lucide="megaphone" style="width: 15px; height: 15px;"></i>
            </div>
            <h2 class="h6 fw-bold text-dark mb-0" style="font-size: 15px;">School Announcements</h2>
          </div>
        </div>

        <div class="p-3">
          <?php if (empty($announcements)): ?>
            <div class="p-4 text-center text-muted" style="font-size: 13.5px;">
              <i data-lucide="bell-off" class="d-block mx-auto mb-2 opacity-50" style="width: 24px; height: 24px;"></i>
              No active announcements for teaching staff right now.
            </div>
          <?php else: ?>
            <div class="row g-3">
              <?php foreach ($announcements as $n): ?>
                <div class="col-md-6 col-lg-4">
                  <div class="p-3 rounded-3 border bg-light h-100">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                      <span class="badge rounded-pill bg-primary-subtle text-primary fw-medium px-2 py-0.5" style="font-size: 11px;">Announcement</span>
                      <span class="text-muted" style="font-size: 11.5px;"><?= e(formatDate($n['created_at'] ?? date('Y-m-d'))) ?></span>
                    </div>
                    <div class="fw-bold text-dark mb-1" style="font-size: 14px;"><?= e($n['title']) ?></div>
                    <div class="text-muted" style="font-size: 12.5px; line-height: 1.4;"><?= nl2br(e(mb_strimwidth($n['body'] ?? '', 0, 150, '...'))) ?></div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

</div>