<?php
/**
 * Parent Portal Dashboard - Genuine Data & Multitenant Authorization
 */

$children = $children ?? [];
$student = $student ?? null;
$studentId = $studentId ?? 0;
$todayTimetable = $todayTimetable ?? [];
$announcements = $announcements ?? [];
$upcomingHomework = $upcomingHomework ?? [];
$unreadMessages = $unreadMessages ?? 0;
$warnings = $warnings ?? [];

$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$currentDateDisplay = date('l, M j, Y');

$currentYear = (int) date('Y');
$currentMonth = (int) date('n');
$currentDay = (int) date('j');
$daysInMonth = (int) date('t');
$firstDayOfWeek = (int) date('N', strtotime("{$currentYear}-{$currentMonth}-01"));
$monthName = date('M Y');
?>

<?php if (!$student): ?>
  <!-- Empty State for Parent with no linked children -->
  <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white mb-4">
    <div class="avatar bg-primary-subtle text-primary rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 64px; height: 64px;">
      <i data-lucide="users" style="width: 32px; height: 32px;"></i>
    </div>
    <h4 class="fw-bold text-dark mb-1">No Child Accounts Linked</h4>
    <p class="text-muted small mx-auto mb-4" style="max-width: 500px;">
      Your parent portal account is active, but there are no verified student records currently linked to your profile. Please contact the school admissions or administrative office to connect your child's enrollment.
    </p>
    <div>
      <a href="<?= e(url('support')) ?>" class="btn btn-primary btn-sm px-4 py-2 rounded-3 shadow-sm">
        <i data-lucide="help-circle" style="width: 14px; height: 14px;" class="me-1"></i> Contact School Helpdesk
      </a>
    </div>
  </div>
<?php else: 
  $studentDisplayName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
  $className = $student['class_name'] ?? 'Class';
  $sectionName = $student['section_name'] ?? '';
  $yearName = $student['year_name'] ?? 'Active Academic Session';
?>

  <!-- 1. Top Greeting Card with Child Switcher -->
  <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
    <div class="card-body p-4">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
          <div class="d-flex align-items-center gap-2 text-muted small mb-2" style="font-size: 13px;">
            <i data-lucide="calendar" style="width: 15px; height: 15px; color: #4f46e5;"></i>
            <span><?= e($currentDateDisplay) ?></span>
          </div>
          <h2 class="h3 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">
            <?= e($greeting) ?>, <?= e($studentDisplayName) ?>'s Parent!
          </h2>
          <div class="text-secondary small fw-normal" style="font-size: 13px;">
            <?= e($className) ?><?= $sectionName ? ' • Section ' . e($sectionName) : '' ?> • <?= e($yearName) ?>
          </div>
        </div>

        <div class="d-flex flex-wrap align-items-center gap-2">
          <?php if (count($children) > 1): ?>
            <form method="POST" action="<?= e(url('dashboard/switch-child')) ?>" class="d-flex align-items-center gap-2">
              <?= csrf_field() ?>
              <label class="small text-muted fw-semibold text-nowrap">Switch Student:</label>
              <select name="student_id" class="form-select form-select-sm" onchange="this.form.submit()" style="border-radius: 8px;">
                <?php foreach ($children as $ch): ?>
                  <option value="<?= e($ch['id']) ?>" <?= ((int)$ch['id'] === $studentId) ? 'selected' : '' ?>>
                    <?= e($ch['first_name'] . ' ' . $ch['last_name']) ?> (<?= e($ch['class_name'] ?? 'Class') ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </form>
          <?php endif; ?>

          <a href="<?= e(url('parent/messages')) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 rounded-3 px-3 py-2 shadow-sm">
            <i data-lucide="message-square" style="width: 14px; height: 14px;"></i>
            <span>Messages</span>
            <?php if ($unreadMessages > 0): ?>
              <span class="badge bg-danger rounded-pill ms-1"><?= $unreadMessages ?></span>
            <?php endif; ?>
          </a>

          <span class="badge rounded-pill d-inline-flex align-items-center gap-1 px-3 py-2" style="background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; font-size: 12px; font-weight: 500;">
            <i data-lucide="shield-check" style="width: 14px; height: 14px;"></i>
            <span>Authorized Ward</span>
          </span>
        </div>
      </div>
    </div>
  </div>

  <!-- 2. Three Metric Stat Cards Row -->
  <div class="row g-4 mb-4">
    <!-- Card 1: Attendance -->
    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm h-100 p-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-secondary fw-semibold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em; color: #64748b !important;">ATTENDANCE</span>
          <div style="background: #f0fdf4; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
            <i data-lucide="check-circle" style="width: 15px; height: 15px; color: #16a34a;"></i>
          </div>
        </div>
        <div class="h2 fw-bold text-dark mb-3" style="font-size: 32px; letter-spacing: -0.02em;">
          <?= number_format($attendanceRate, 1) ?>%
        </div>
        <div class="d-flex align-items-center gap-2 small text-secondary" style="font-size: 12px;">
          <?php if ($totalAttendanceDays > 0): ?>
            <span class="d-inline-flex align-items-center gap-1 <?= $attendanceRate >= 75 ? 'text-success' : 'text-danger' ?> fw-medium">
              <span style="width: 6px; height: 6px; border-radius: 50%; background-color: <?= $attendanceRate >= 75 ? '#16a34a' : '#ef4444' ?>; display: inline-block;"></span>
              <?= $attendanceRate >= 75 ? 'Good Standing' : 'Low Attendance' ?>
            </span>
            <span class="text-muted">•</span>
            <span class="text-muted"><?= $presentCount ?> of <?= $totalAttendanceDays ?> days present</span>
          <?php else: ?>
            <span class="text-muted">No attendance sessions logged yet</span>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Card 2: Curriculum -->
    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm h-100 p-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-secondary fw-semibold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em; color: #64748b !important;">CURRICULUM</span>
          <div style="background: #eef2ff; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
            <i data-lucide="book-open" style="width: 15px; height: 15px; color: #4f46e5;"></i>
          </div>
        </div>
        <div class="h2 fw-bold text-dark mb-3" style="font-size: 32px; letter-spacing: -0.02em;">
          <?= $subjectsCount ?> Subjects
        </div>
        <div class="d-flex align-items-center gap-2 small text-secondary" style="font-size: 12px;">
          <span class="d-inline-flex align-items-center gap-1 fw-medium" style="color: #4f46e5;">
            <span style="width: 6px; height: 6px; border-radius: 50%; background-color: #4f46e5; display: inline-block;"></span>
            Enrolled Syllabus
          </span>
          <span class="text-muted">•</span>
          <a href="<?= e(url('portal/resources?student_id=' . $studentId)) ?>" class="text-decoration-none text-muted">Study Materials</a>
        </div>
      </div>
    </div>

    <!-- Card 3: Fee Standing -->
    <div class="col-12 col-md-4">
      <div class="card border-0 shadow-sm h-100 p-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-secondary fw-semibold text-uppercase" style="font-size: 11px; letter-spacing: 0.05em; color: #64748b !important;">FEE STANDING</span>
          <div style="background: <?= $totalDue > 0 ? '#fef2f2' : '#f0fdf4' ?>; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
            <i data-lucide="wallet" style="width: 15px; height: 15px; color: <?= $totalDue > 0 ? '#ef4444' : '#16a34a' ?>;"></i>
          </div>
        </div>
        <div class="h2 fw-bold text-dark mb-3" style="font-size: 32px; letter-spacing: -0.02em;">
          $<?= number_format($totalDue, 2) ?>
        </div>
        <div class="d-flex align-items-center gap-2 small text-secondary" style="font-size: 12px;">
          <span class="d-inline-flex align-items-center gap-1 <?= $totalDue <= 0 ? 'text-success' : 'text-danger' ?> fw-medium">
            <span style="width: 6px; height: 6px; border-radius: 50%; background-color: <?= $totalDue <= 0 ? '#16a34a' : '#ef4444' ?>; display: inline-block;"></span>
            <?= $totalDue <= 0 ? 'Fully Settled' : 'Outstanding Due' ?>
          </span>
          <span class="text-muted">•</span>
          <span class="text-muted">Paid $<?= number_format($totalPaid, 2) ?></span>
        </div>
      </div>
    </div>
  </div>

  <!-- 3. Bottom Grid: Today's Schedule & Sidebar Column -->
  <div class="row g-4">
    <!-- Left Column: Today's Schedule & Homework -->
    <div class="col-12 col-lg-7">
      <!-- Today's Schedule Card -->
      <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
          <div>
            <h3 class="h5 fw-bold text-dark mb-1" style="font-size: 16px;">Today's Schedule</h3>
            <span class="text-muted small" style="font-size: 12px;"><?= count($todayTimetable) ?> periods scheduled</span>
          </div>
          <a href="<?= e(url('parent/timetable')) ?>" class="text-decoration-none small fw-semibold text-primary d-inline-flex align-items-center gap-1" style="font-size: 12px; color: #4f46e5 !important;">
            <span>Full Timetable</span>
            <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
          </a>
        </div>

        <div class="card-body p-0">
          <?php if (empty($todayTimetable)): ?>
            <div class="p-4 text-center text-muted">
              <i data-lucide="clock" style="width: 32px; height: 32px; opacity: 0.3;" class="mb-2"></i>
              <div class="fw-semibold text-dark small">No Scheduled Periods for Today</div>
              <div class="small text-muted">Classes resume on the next standard instructional day.</div>
            </div>
          <?php else: ?>
            <div class="schedule-timeline">
              <?php foreach ($todayTimetable as $tt): ?>
                <div class="d-flex align-items-center justify-content-between px-4 py-3" style="border-bottom: 1px solid #f8fafc;">
                  <div class="d-flex align-items-center gap-3">
                    <div class="text-center font-monospace" style="min-width: 65px; line-height: 1.2;">
                      <div class="fw-bold text-dark" style="font-size: 13px;"><?= date('H:i', strtotime($tt['start_time'])) ?></div>
                      <div class="text-muted" style="font-size: 11px;">to <?= date('H:i', strtotime($tt['end_time'])) ?></div>
                    </div>
                    <div class="vr mx-1 text-muted opacity-25" style="height: 28px;"></div>
                    <div>
                      <h4 class="h6 fw-bold text-dark mb-0" style="font-size: 13.5px;"><?= e($tt['subject_name'] ?? 'Class Period') ?></h4>
                      <span class="text-secondary small" style="font-size: 11.5px; color: #64748b;">
                        Period <?= e((string)$tt['period_number']) ?> • <?= e($tt['teacher_name'] ?: 'Faculty') ?>
                        <?= !empty($tt['room_name']) ? ' • Room ' . e($tt['room_name']) : '' ?>
                      </span>
                    </div>
                  </div>
                  <div>
                    <span class="badge rounded-pill px-3 py-1 fw-normal" style="background: #f1f5f9; color: #475569; font-size: 11px;">
                      Active
                    </span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Upcoming Homework Tasks -->
      <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="clipboard-check" style="width: 16px; height: 16px; color: #4f46e5;"></i>
            <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">Upcoming Homework &amp; Tasks</h3>
          </div>
          <a href="<?= e(url('parent/assignments')) ?>" class="text-decoration-none small fw-semibold text-primary" style="font-size: 12px;">View all</a>
        </div>
        <div class="card-body p-0">
          <?php if (empty($upcomingHomework)): ?>
            <div class="p-4 text-center text-muted">
              <i data-lucide="check" style="width: 28px; height: 28px; opacity: 0.3;" class="mb-1 text-success"></i>
              <div class="small fw-semibold text-dark">All Homework Up-To-Date</div>
              <div class="text-muted" style="font-size: 11px;">No pending assignments due for this class.</div>
            </div>
          <?php else: ?>
            <div class="list-group list-group-flush">
              <?php foreach ($upcomingHomework as $hw): ?>
                <div class="list-group-item p-3 border-bottom d-flex justify-content-between align-items-center">
                  <div>
                    <div class="d-flex align-items-center gap-2 mb-1">
                      <span class="badge bg-primary-subtle text-primary" style="font-size: 10px;"><?= e($hw['subject_name'] ?? 'Task') ?></span>
                      <h6 class="fw-bold text-dark mb-0" style="font-size: 13px;"><?= e($hw['title']) ?></h6>
                    </div>
                    <div class="text-muted small" style="font-size: 11.5px;">
                      Due: <span class="fw-medium text-danger"><?= date('M j, Y', strtotime($hw['due_date'])) ?></span>
                    </div>
                  </div>
                  <a href="<?= e(url('parent/assignments')) ?>" class="btn btn-sm btn-light border" style="font-size: 11.5px;">Details</a>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Right Column: Calendar Overview & Announcements -->
    <div class="col-12 col-lg-5">
      <!-- Calendar Overview Card -->
      <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
          <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">Calendar Overview</h3>
          <div class="d-flex align-items-center gap-1 text-secondary small fw-medium" style="font-size: 12.5px;">
            <span><?= e($monthName) ?></span>
          </div>
        </div>

        <div class="card-body p-4">
          <div class="calendar-month-grid mb-3">
            <div class="row g-0 text-center mb-2" style="font-size: 10px; font-weight: 600; color: #94a3b8;">
              <div class="col">MO</div>
              <div class="col">TU</div>
              <div class="col">WE</div>
              <div class="col">TH</div>
              <div class="col">FR</div>
              <div class="col">SA</div>
              <div class="col">SU</div>
            </div>
            
            <div class="row g-0 text-center" style="font-size: 12px; color: #475569;">
              <?php
                $dayCounter = 1;
                $emptyCols = $firstDayOfWeek - 1;
                
                for ($c = 0; $c < $emptyCols; $c++) {
                    echo '<div class="col py-2 text-muted opacity-25"></div>';
                }
                
                while ($dayCounter <= $daysInMonth) {
                    $isToday = ($dayCounter === $currentDay);
                    $todayStyle = $isToday ? 'background: #4f46e5; color: #ffffff; border-radius: 6px; font-weight: 600;' : '';
                    
                    echo '<div class="col py-1">';
                    echo '<div class="d-inline-flex align-items-center justify-content-center" style="width: 28px; height: 28px; ' . $todayStyle . '">';
                    echo $dayCounter;
                    echo '</div>';
                    echo '</div>';
                    
                    if (($emptyCols + $dayCounter) % 7 === 0 && $dayCounter < $daysInMonth) {
                        echo '</div><div class="row g-0 text-center" style="font-size: 12px; color: #475569;">';
                    }
                    $dayCounter++;
                }
                
                $remainingCols = (7 - (($emptyCols + $daysInMonth) % 7)) % 7;
                for ($c = 0; $c < $remainingCols; $c++) {
                    echo '<div class="col py-2 text-muted opacity-25"></div>';
                }
              ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Real School Announcements Card -->
      <div class="card border-0 shadow-sm" style="border-radius: 12px; border: 1px solid #e2e8f0 !important; background: #ffffff;">
        <div class="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center" style="border-color: #f1f5f9 !important;">
          <div class="d-flex align-items-center gap-2">
            <i data-lucide="megaphone" style="width: 15px; height: 15px; color: #4f46e5;"></i>
            <h3 class="h5 fw-bold text-dark mb-0" style="font-size: 15px;">School Announcements</h3>
          </div>
          <a href="<?= e(url('noticeboard')) ?>" class="text-decoration-none small fw-semibold text-primary" style="font-size: 12px;">View all</a>
        </div>

        <div class="card-body p-0">
          <?php if (empty($announcements)): ?>
            <div class="p-4 text-center text-muted">
              <i data-lucide="bell-off" style="width: 28px; height: 28px; opacity: 0.3;" class="mb-1"></i>
              <div class="small fw-semibold text-dark">No Recent Announcements</div>
              <div class="text-muted" style="font-size: 11px;">Institutional notices and updates will appear here.</div>
            </div>
          <?php else: ?>
            <div class="list-group list-group-flush">
              <?php foreach ($announcements as $anc): ?>
                <div class="list-group-item p-3 border-bottom">
                  <div class="d-flex justify-content-between align-items-start mb-1">
                    <h4 class="h6 fw-semibold text-dark mb-0" style="font-size: 12.5px;"><?= e($anc['title']) ?></h4>
                    <span class="badge rounded-pill bg-light text-muted border" style="font-size: 9.5px;">Official</span>
                  </div>
                  <p class="text-secondary small mb-1" style="font-size: 11.5px; line-height: 1.4;">
                    <?= e(mb_substr($anc['body'], 0, 140)) ?><?= mb_strlen($anc['body']) > 140 ? '...' : '' ?>
                  </p>
                  <span class="text-muted font-monospace" style="font-size: 10px;">
                    <?= date('d/m/Y', strtotime($anc['created_at'])) ?>
                  </span>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

<?php endif; ?>
