<?php
// Unified Settings Cockpit: Forward school_profile to settings view
require __DIR__ . '/../settings/index.php';
