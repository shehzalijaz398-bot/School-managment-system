<?php
$title = 'Workflow Automation Engine & Builder';
$metricsData = $metrics ?? ['total_rules' => 0, 'active_rules' => 0, 'total_executions' => 0, 'success_rate' => 100];
$rulesList = $rules ?? [];
$logsList = $logs ?? [];
$chainsList = $chains ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="cpu" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Smart Operations
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Visual workflow builder, automatic fee & attendance triggers, multi-tier approval chains, and dry-run execution previews.
    </p>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <button type="button" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#aiSuggestModal">
      <i data-lucide="sparkles" style="width: 14px; height: 14px;"></i> AI Assistant Setup
    </button>
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#createRuleModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> New Workflow Rule
    </button>
    <button type="button" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#approvalChainsModal">
      <i data-lucide="git-merge" style="width: 14px; height: 14px;"></i> Approval Chains
    </button>
    <form method="POST" action="<?= e(url('automations/run-now')) ?>" onsubmit="return confirm('Execute scheduled automation cycle now?');">
      <?= csrf_field() ?>
      <button type="submit" class="btn btn-dark btn-sm d-flex align-items-center gap-1">
        <i data-lucide="play" style="width: 14px; height: 14px;"></i> Run Scheduled Cycle
      </button>
    </form>
  </div>
</div>

<!-- Metrics Overview -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Active Rules</div>
          <div class="fs-4 fw-bold text-primary"><?= (int) $metricsData['active_rules'] ?> <span class="fs-6 text-muted fw-normal">/ <?= (int) $metricsData['total_rules'] ?></span></div>
          <div class="text-muted" style="font-size: 11px;">Automations Running</div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="sliders" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Total Executions</div>
          <div class="fs-4 fw-bold text-success"><?= (int) $metricsData['total_executions'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Triggered Actions</div>
        </div>
        <div class="rounded-3 p-2 bg-success-subtle text-success">
          <i data-lucide="zap" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Execution Reliability</div>
          <div class="fs-4 fw-bold text-info"><?= $metricsData['success_rate'] ?>%</div>
          <div class="text-muted" style="font-size: 11px;">Past 30 Days</div>
        </div>
        <div class="rounded-3 p-2 bg-info-subtle text-info">
          <i data-lucide="shield-check" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Approval Chains</div>
          <div class="fs-4 fw-bold text-dark"><?= count($chainsList) ?></div>
          <div class="text-muted" style="font-size: 11px;">Multi-Stage Governance</div>
        </div>
        <div class="rounded-3 p-2 bg-dark-subtle text-dark">
          <i data-lucide="git-pull-request" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Automation Rules Grid -->
<div class="row g-3 mb-4">
  <div class="col-12">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="git-branch" class="text-primary" style="width: 18px; height: 18px;"></i>
          Configurable Operations & Workflow Rules
        </h5>
        <span class="text-muted small"><?= count($rulesList) ?> Rules Configured</span>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Rule Name & Purpose</th>
                <th>Category</th>
                <th>Trigger Event</th>
                <th>Action Type</th>
                <th>Cooldown</th>
                <th>Executions</th>
                <th>Status</th>
                <th class="text-end pe-3">Controls</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($rulesList)): ?>
                <tr>
                  <td colspan="8" class="text-center py-4 text-muted">No automation rules configured.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($rulesList as $r): 
                  $catBadge = match($r['category']) {
                    'finance' => 'bg-success-subtle text-success border border-success-subtle',
                    'attendance' => 'bg-warning-subtle text-warning border border-warning-subtle',
                    'admissions' => 'bg-primary-subtle text-primary border border-primary-subtle',
                    'hr' => 'bg-info-subtle text-info border border-info-subtle',
                    default => 'bg-secondary-subtle text-secondary border border-secondary-subtle'
                  };
                ?>
                  <tr>
                    <td class="ps-3 py-3">
                      <div class="fw-bold text-dark"><?= e($r['name']) ?></div>
                      <div class="text-muted small" style="font-size: 12px;"><?= e($r['description'] ?? '') ?></div>
                    </td>
                    <td>
                      <span class="badge <?= $catBadge ?> px-2 py-1 rounded-pill small">
                        <?= ucfirst(e($r['category'])) ?>
                      </span>
                    </td>
                    <td>
                      <code class="text-dark small px-1 py-0.5 rounded bg-light border"><?= e($r['trigger_event']) ?></code>
                    </td>
                    <td>
                      <span class="small fw-semibold text-muted"><?= e(str_replace('_', ' ', ucfirst($r['action_type']))) ?></span>
                    </td>
                    <td>
                      <span class="small text-muted"><?= (int) $r['cooldown_hours'] ?>h</span>
                    </td>
                    <td>
                      <span class="badge bg-light text-dark border px-2 py-1"><?= (int) $r['execution_count'] ?></span>
                    </td>
                    <td>
                      <?php if ($r['is_active']): ?>
                        <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill small">Active</span>
                      <?php else: ?>
                        <span class="badge bg-secondary-subtle text-secondary px-2 py-1 rounded-pill small">Paused</span>
                      <?php endif; ?>
                    </td>
                    <td class="text-end pe-3">
                      <div class="d-inline-flex align-items-center gap-1">
                        <!-- Preview Impact Button -->
                        <button type="button" class="btn btn-sm btn-outline-info d-inline-flex align-items-center gap-1" style="font-size: 11px;" onclick="loadPreview(<?= (int) $r['id'] ?>)" title="Preview Execution Impact">
                          <i data-lucide="eye" style="width: 12px; height: 12px;"></i> Preview
                        </button>

                        <!-- Toggle Active/Pause -->
                        <form method="POST" action="<?= e(url('automations/' . $r['id'] . '/toggle')) ?>" class="d-inline">
                          <?= csrf_field() ?>
                          <input type="hidden" name="is_active" value="<?= $r['is_active'] ? '0' : '1' ?>">
                          <button type="submit" class="btn btn-sm <?= $r['is_active'] ? 'btn-outline-warning' : 'btn-outline-success' ?> d-inline-flex align-items-center gap-1" style="font-size: 11px;">
                            <?php if ($r['is_active']): ?>
                              <i data-lucide="pause" style="width: 12px; height: 12px;"></i> Pause
                            <?php else: ?>
                              <i data-lucide="play" style="width: 12px; height: 12px;"></i> Resume
                            <?php endif; ?>
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Execution History Audit Log -->
<div class="row g-3">
  <div class="col-12">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="history" class="text-primary" style="width: 18px; height: 18px;"></i>
          Live Execution History & Audit Trail
        </h5>
        <span class="text-muted small">Recent 30 Actions</span>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Execution Time</th>
                <th>Rule Code</th>
                <th>Trigger Event</th>
                <th>Target</th>
                <th>Action Performed</th>
                <th class="text-end pe-3">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($logsList)): ?>
                <tr>
                  <td colspan="6" class="text-center py-4 text-muted">
                    No automated actions executed yet. Click "Run Scheduled Cycle" to initiate a scan.
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach ($logsList as $l): ?>
                  <tr>
                    <td class="ps-3 py-2 small text-muted">
                      <?= date('M d, Y H:i:s', strtotime($l['created_at'])) ?>
                    </td>
                    <td>
                      <span class="badge bg-light text-dark border"><?= e($l['rule_code']) ?></span>
                    </td>
                    <td>
                      <code class="small text-muted"><?= e($l['trigger_event']) ?></code>
                    </td>
                    <td class="small">
                      <?= e($l['target_type']) ?> #<?= (int) $l['target_id'] ?>
                    </td>
                    <td class="small text-dark fw-medium">
                      <?= e($l['action_taken']) ?>
                    </td>
                    <td class="text-end pe-3">
                      <?php if ($l['status'] === 'success'): ?>
                        <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded-pill small">Success</span>
                      <?php elseif ($l['status'] === 'skipped'): ?>
                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-2 py-1 rounded-pill small">Skipped</span>
                      <?php else: ?>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1 rounded-pill small">Failed</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Visual Workflow Builder -->
<div class="modal fade" id="createRuleModal" tabindex="-1" aria-labelledby="createRuleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('automations/create')) ?>" id="ruleBuilderForm">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fs-6 fw-bold text-dark" id="createRuleModalLabel">
            <i data-lucide="sliders" class="text-primary me-1" style="width: 18px; height: 18px;"></i>
            Visual Workflow Builder
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="row g-3 mb-3">
            <div class="col-md-8">
              <label class="form-label small fw-semibold text-dark">Rule Name <span class="text-danger">*</span></label>
              <input type="text" name="name" id="builderRuleName" class="form-control form-control-sm" placeholder="e.g. Overdue Fee Notice 5 Days" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold text-dark">Category <span class="text-danger">*</span></label>
              <select name="category" id="builderCategory" class="form-select form-select-sm" required>
                <option value="finance">Finance</option>
                <option value="attendance">Attendance</option>
                <option value="admissions">Admissions</option>
                <option value="hr">HR & Staff</option>
                <option value="academics">Academics</option>
                <option value="general">General</option>
              </select>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Description</label>
            <input type="text" name="description" id="builderDescription" class="form-control form-control-sm" placeholder="Describe the trigger event and intended action...">
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-dark">Trigger Event <span class="text-danger">*</span></label>
              <select name="trigger_event" id="builderTrigger" class="form-select form-select-sm" required>
                <option value="fee.overdue_scan">fee.overdue_scan (Overdue Invoices Scan)</option>
                <option value="attendance.consecutive_absent">attendance.consecutive_absent (Consecutive Absences)</option>
                <option value="attendance.daily_unmarked">attendance.daily_unmarked (Unsubmitted Daily Register)</option>
                <option value="admission.unverified_followup">admission.unverified_followup (Pending Admission Follow-up)</option>
                <option value="leave.pending_scan">leave.pending_scan (Overdue Staff Leave Review)</option>
                <option value="exam.published">exam.published (Examination Results Publication)</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold text-dark">Condition Field</label>
              <input type="text" name="condition_key" id="builderConditionKey" class="form-control form-control-sm" placeholder="days_overdue_min" value="days_overdue_min">
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold text-dark">Condition Value</label>
              <input type="text" name="condition_value" id="builderConditionVal" class="form-control form-control-sm" placeholder="3" value="3">
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-dark">Action Type <span class="text-danger">*</span></label>
              <select name="action_type" id="builderActionType" class="form-select form-select-sm" required>
                <option value="notify_parent">notify_parent (Dispatch to Student Parents)</option>
                <option value="notify_admin">notify_admin (Alert Institution Administrators)</option>
                <option value="notify_class_students">notify_class_students (Broadcast to Class)</option>
                <option value="create_workflow_task">create_workflow_task (Push to Approval Queue)</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-dark">Notification Title</label>
              <input type="text" name="action_title" id="builderActionTitle" class="form-control form-control-sm" placeholder="e.g. Urgent Fee Reminder" value="Automated Operational Notice">
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold text-dark">Delivery Channels</label>
              <div class="d-flex gap-3 mt-1">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="channel[]" value="in_app" id="chanInApp" checked>
                  <label class="form-check-label small" for="chanInApp">In-App Notification</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="channel[]" value="email" id="chanEmail" checked>
                  <label class="form-check-label small" for="chanEmail">Email Queue</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="channel[]" value="sms" id="chanSms">
                  <label class="form-check-label small" for="chanSms">SMS / WhatsApp</label>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold text-dark">Cooldown Window</label>
              <div class="input-group input-group-sm">
                <input type="number" name="cooldown_hours" id="builderCooldown" class="form-control" value="24" min="0">
                <span class="input-group-text">hours</span>
              </div>
            </div>
            <div class="col-md-3 d-flex align-items-end">
              <div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" name="is_active" id="builderIsActive" value="1" checked>
                <label class="form-check-label small fw-semibold" for="builderIsActive">Active Immediately</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-1">
            <i data-lucide="check" style="width: 14px; height: 14px;"></i> Save Workflow Rule
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal: AI-Assisted Workflow Setup -->
<div class="modal fade" id="aiSuggestModal" tabindex="-1" aria-labelledby="aiSuggestModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-light">
        <h5 class="modal-title fs-6 fw-bold text-dark d-flex align-items-center gap-2" id="aiSuggestModalLabel">
          <i data-lucide="sparkles" class="text-primary" style="width: 18px; height: 18px;"></i>
          AI Workflow Synthesizer & Assistant
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <p class="text-muted small mb-3">
          Describe your operational goal in natural language. The AI will synthesize a complete rule configuration.
          <strong class="text-dark">Safety note:</strong> AI rules are never activated automatically — you review and confirm before saving.
        </p>

        <div class="mb-3">
          <label class="form-label small fw-semibold text-dark">Describe your rule:</label>
          <div class="input-group">
            <input type="text" id="aiPromptInput" class="form-control" placeholder="e.g., Send parents a reminder when fee invoice is overdue by 4 days">
            <button type="button" class="btn btn-primary d-flex align-items-center gap-1" id="aiGenerateBtn" onclick="runAiSynthesis()">
              <i data-lucide="cpu" style="width: 14px; height: 14px;"></i> Synthesize
            </button>
          </div>
        </div>

        <div id="aiResultContainer" class="d-none mt-3 p-3 bg-light rounded-3 border">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <h6 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
              <i data-lucide="check-circle" class="text-success" style="width: 16px; height: 16px;"></i>
              Proposed Workflow Configuration
            </h6>
            <span class="badge bg-warning text-dark">Requires Review</span>
          </div>
          <p class="text-muted small mb-2" id="aiExplanation"></p>
          <div class="bg-white p-2 rounded border font-monospace small mb-3" id="aiConfigPreview" style="font-size: 11px;"></div>
          <button type="button" class="btn btn-sm btn-success d-inline-flex align-items-center gap-1" onclick="applyAiSuggestion()">
            <i data-lucide="arrow-right-circle" style="width: 14px; height: 14px;"></i> Load into Builder to Review & Activate
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Execution Preview -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-light">
        <h5 class="modal-title fs-6 fw-bold text-dark d-flex align-items-center gap-2" id="previewModalLabel">
          <i data-lucide="eye" class="text-info" style="width: 18px; height: 18px;"></i>
          Execution Impact Preview (Dry-Run Simulation)
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4" id="previewModalBody">
        <div class="text-center py-4">
          <div class="spinner-border text-primary" role="status"></div>
          <div class="text-muted small mt-2">Evaluating live database conditions...</div>
        </div>
      </div>
      <div class="modal-footer bg-light">
        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close Preview</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Approval Chains Configuration -->
<div class="modal fade" id="approvalChainsModal" tabindex="-1" aria-labelledby="approvalChainsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-light">
        <h5 class="modal-title fs-6 fw-bold text-dark d-flex align-items-center gap-2" id="approvalChainsModalLabel">
          <i data-lucide="git-merge" class="text-primary" style="width: 18px; height: 18px;"></i>
          Institutional Multi-Tier Approval Chains
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <p class="text-muted small mb-3">
          Configure multi-stage approval workflows for staff leaves, expense claims, fee concessions, admissions, and exam releases.
        </p>

        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead class="table-light small text-uppercase" style="font-size: 11px;">
              <tr>
                <th>Entity Module</th>
                <th>Chain Name</th>
                <th>Sequential Review Stages</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($chainsList as $ch): ?>
                <tr>
                  <td class="fw-bold small text-dark"><?= e(strtoupper(str_replace('_', ' ', $ch['entity_type']))) ?></td>
                  <td class="small"><?= e($ch['name']) ?></td>
                  <td>
                    <div class="d-flex flex-wrap gap-1">
                      <?php foreach ($ch['stages'] as $stg): ?>
                        <span class="badge bg-light text-dark border px-2 py-0.5" style="font-size: 10px;">
                          Stage <?= (int) $stg['stage'] ?>: <?= e($stg['name']) ?> (<?= e($stg['role']) ?>)
                        </span>
                      <?php endforeach; ?>
                    </div>
                  </td>
                  <td>
                    <span class="badge bg-success-subtle text-success small">Enforced</span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer bg-light">
        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
let lastSuggestedConfig = null;

async function runAiSynthesis() {
  const prompt = document.getElementById('aiPromptInput').value.trim();
  if (!prompt) {
    alert('Please enter a description for the workflow.');
    return;
  }

  const btn = document.getElementById('aiGenerateBtn');
  btn.disabled = true;
  btn.innerText = 'Analyzing...';

  try {
    const res = await fetch('<?= e(url('api/v1/automations/ai-suggest')) ?>', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify({ prompt: prompt })
    });
    const data = await res.json();
    if (data.success && data.suggestion) {
      lastSuggestedConfig = data.suggestion;
      document.getElementById('aiExplanation').innerText = data.suggestion.preview_explanation;
      document.getElementById('aiConfigPreview').innerText = JSON.stringify(data.suggestion, null, 2);
      document.getElementById('aiResultContainer').classList.remove('d-none');
    } else {
      alert(data.error || 'Failed to generate proposal.');
    }
  } catch (err) {
    alert('Network error communicating with AI synthesizer.');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i data-lucide="cpu" style="width: 14px; height: 14px;"></i> Synthesize';
    if (window.lucide) lucide.createIcons();
  }
}

function applyAiSuggestion() {
  if (!lastSuggestedConfig) return;

  document.getElementById('builderRuleName').value = lastSuggestedConfig.name;
  document.getElementById('builderCategory').value = lastSuggestedConfig.category;
  document.getElementById('builderDescription').value = lastSuggestedConfig.description;
  document.getElementById('builderTrigger').value = lastSuggestedConfig.trigger_event;
  document.getElementById('builderActionType').value = lastSuggestedConfig.action_type;
  document.getElementById('builderActionTitle').value = lastSuggestedConfig.action_params.title || 'Operational Notice';
  document.getElementById('builderCooldown').value = lastSuggestedConfig.cooldown_hours || 24;

  const condKeys = Object.keys(lastSuggestedConfig.conditions || {});
  if (condKeys.length > 0) {
    document.getElementById('builderConditionKey').value = condKeys[0];
    document.getElementById('builderConditionVal').value = lastSuggestedConfig.conditions[condKeys[0]];
  }

  // Close AI modal and open builder modal
  const aiModalEl = document.getElementById('aiSuggestModal');
  const aiModal = bootstrap.Modal.getInstance(aiModalEl);
  if (aiModal) aiModal.hide();

  const builderModal = new bootstrap.Modal(document.getElementById('createRuleModal'));
  builderModal.show();
}

async function loadPreview(ruleId) {
  const modalEl = document.getElementById('previewModal');
  const body = document.getElementById('previewModalBody');
  body.innerHTML = `
    <div class="text-center py-4">
      <div class="spinner-border text-primary" role="status"></div>
      <div class="text-muted small mt-2">Evaluating live database conditions...</div>
    </div>`;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();

  try {
    const res = await fetch('<?= e(url('automations/')) ?>' + ruleId + '/preview', {
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    const data = await res.json();
    if (data.success && data.data) {
      const p = data.data;
      let samplesHtml = '';
      if (p.sample_records && p.sample_records.length > 0) {
        samplesHtml = `
          <h6 class="fw-bold small text-dark mt-3 mb-2">Sample Matching Records:</h6>
          <ul class="list-group list-group-flush border rounded-2 small">
            ${p.sample_records.map(r => `<li class="list-group-item py-2"><strong>${r.title}</strong> &mdash; <span class="text-muted">${r.detail}</span></li>`).join('')}
          </ul>`;
      } else {
        samplesHtml = `<div class="alert alert-secondary small mt-3 mb-0">Zero records currently qualify for this rule.</div>`;
      }

      body.innerHTML = `
        <div class="card bg-light border-0 p-3 mb-3">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <div class="fw-bold text-dark fs-6">${p.rule_name}</div>
              <div class="text-muted small">Trigger: <code>${p.trigger_event}</code> &bull; Target: <code>${p.target_type}</code></div>
            </div>
            <span class="badge bg-info-subtle text-info border border-info-subtle px-2 py-1">Dry-Run Preview</span>
          </div>
        </div>
        <div class="row g-2 text-center">
          <div class="col-4">
            <div class="p-2 border rounded bg-white">
              <div class="text-muted" style="font-size: 11px;">Total Matching</div>
              <div class="fs-5 fw-bold text-primary">${p.total_matched}</div>
            </div>
          </div>
          <div class="col-4">
            <div class="p-2 border rounded bg-white">
              <div class="text-muted" style="font-size: 11px;">In Cooldown Window</div>
              <div class="fs-5 fw-bold text-secondary">${p.cooldown_excluded}</div>
            </div>
          </div>
          <div class="col-4">
            <div class="p-2 border rounded bg-white">
              <div class="text-muted" style="font-size: 11px;">Actionable Now</div>
              <div class="fs-5 fw-bold text-success">${p.actionable_count}</div>
            </div>
          </div>
        </div>
        ${samplesHtml}
      `;
    } else {
      body.innerHTML = `<div class="alert alert-danger mb-0">${data.error || 'Preview could not be evaluated.'}</div>`;
    }
  } catch (err) {
    body.innerHTML = `<div class="alert alert-danger mb-0">Failed to load preview data from server.</div>`;
  }
}
</script>
