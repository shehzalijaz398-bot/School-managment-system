<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
  .inactive-wrap {
    min-height: 85vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem 1rem;
  }
  .inactive-card {
    max-width: 580px;
    width: 100%;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
    box-shadow: 0 20px 40px -10px rgba(15, 23, 42, 0.1), 0 1px 3px rgba(0,0,0,0.05);
    padding: 2.75rem 2.25rem;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .inactive-card-stripe {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: <?= !empty($isTrialExpired) ? 'linear-gradient(90deg, #f59e0b 0%, #ef4444 100%)' : 'linear-gradient(90deg, #ef4444 0%, #991b1b 100%)' ?>;
  }
  .inactive-icon-badge {
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    margin-bottom: 1.25rem;
    background: <?= !empty($isTrialExpired) ? '#fffbeb; color: #d97706;' : '#fef2f2; color: #dc2626;' ?>;
    box-shadow: 0 4px 12px <?= !empty($isTrialExpired) ? 'rgba(217, 119, 6, 0.15)' : 'rgba(220, 38, 38, 0.15)' ?>;
  }
</style>

<div class="inactive-wrap">
  <div class="inactive-card">
    <div class="inactive-card-stripe"></div>

    <div class="inactive-icon-badge">
      <i class="bi <?= !empty($isTrialExpired) ? 'bi-hourglass-bottom' : 'bi-shield-x' ?>"></i>
    </div>

    <h1 class="h3 fw-bold text-dark mb-2">
      <?= !empty($isTrialExpired) ? 'Trial Expired — 30-Day Free Trial Concluded' : 'School Access Suspended' ?>
    </h1>

    <p class="text-muted small mb-4 mx-auto" style="max-width: 460px; line-height: 1.6;">
      <?= !empty($isTrialExpired) ? 'Your school\'s free trial period has concluded. Please subscribe to an active plan to continue using the platform without interruption.' : e($message ?? 'Your subscription status is currently inactive. Please choose an active plan to continue using the platform without interruption.') ?>
    </p>

    <?php if (!empty($school)): ?>
      <div class="card bg-light border-0 rounded-3 p-3 mb-4 text-start">
        <div class="row g-2 small">
          <div class="col-sm-6">
            <span class="text-muted d-block" style="font-size: 11px;">School Name:</span>
            <span class="fw-bold text-dark"><?= e($school['name'] ?? 'Your School') ?></span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block" style="font-size: 11px;">School Code:</span>
            <span class="fw-bold font-monospace bg-white px-2 py-0.5 rounded border"><?= e($school['code'] ?? 'N/A') ?></span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block" style="font-size: 11px;">Current Status:</span>
            <span class="badge bg-danger-subtle text-danger fw-bold"><?= ucfirst(str_replace('_', ' ', $school['subscription_status'] ?? 'expired')) ?></span>
          </div>
          <?php if (!empty($school['trial_ends_at'])): ?>
            <div class="col-sm-6">
              <span class="text-muted d-block" style="font-size: 11px;">Trial Ended On:</span>
              <span class="fw-semibold text-danger"><?= date('M d, Y', strtotime($school['trial_ends_at'])) ?></span>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="d-flex flex-column gap-2 mb-4">
      <?php if (!empty($isTrialExpired)): ?>
        <a class="btn btn-primary py-2.5 fw-bold shadow-sm" href="<?= e(url('/#pricing')) ?>" style="border-radius: 8px;">
          <i class="bi bi-credit-card me-1"></i> Subscribe to an Active Plan Now &rarr;
        </a>
      <?php endif; ?>
      <a class="btn btn-outline-dark py-2.5 fw-semibold" href="mailto:<?= e(platform_setting('support_email', 'support@schoolportal.local')) ?>?subject=Subscription%20Inquiry%20-%20<?= urlencode($school['code'] ?? '') ?>">
        <i class="bi bi-headset me-1"></i> Contact Platform Operations &amp; Billing
      </a>
    </div>

    <div class="pt-3 border-top d-flex justify-content-between align-items-center">
      <form method="post" action="<?= e(url('logout')) ?>" style="margin: 0; width: 100%;">
        <?= csrf_field() ?>
        <button type="submit" class="btn btn-link text-muted btn-sm text-decoration-none w-100">
          <i class="bi bi-box-arrow-left me-1"></i> Sign Out from Account
        </button>
      </form>
    </div>
  </div>
</div>
