<?php
$currentDate = $date ?? date('Y-m-d');
$formattedDate = date('d/m/Y', strtotime($currentDate));
$isToday = ($currentDate === date('Y-m-d'));
?>

<div class="cc-staff-attendance-wrapper">
    <!-- Breadcrumb & Top Bar -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1 text-muted small" style="font-size: 0.82rem;">
                    <li class="breadcrumb-item"><a href="<?= e(url('hr/employees')) ?>" class="text-decoration-none text-muted">Staff & HR</a></li>
                    <li class="breadcrumb-item active text-dark fw-medium" aria-current="page">Attendance</li>
                </ol>
            </nav>
            <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Staff Attendance</h2>
            <p class="text-muted small mb-0">Record and manage daily or monthly staff attendance.</p>
        </div>

        <!-- Mode Switcher -->
        <div class="cc-view-switcher p-1 bg-white border rounded-pill shadow-sm d-inline-flex align-items-center">
            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium text-white shadow-none" style="background: #4f46e5; font-size: 0.85rem;" id="btnDailyRegister">
                Daily Register
            </button>
            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium text-muted border-0 bg-transparent shadow-none" style="font-size: 0.85rem;" id="btnMonthlyOverview" onclick="toggleMonthlyModal()">
                Monthly Overview
            </button>
        </div>
    </div>

    <!-- Filter & Controls Form -->
    <div class="card border-0 shadow-sm rounded-3 mb-3" style="border: 1px solid #eef2f6 !important;">
        <div class="card-body p-3">
            <form method="get" action="<?= e(url('attendance/staff')) ?>" id="attendanceFilterForm" class="row g-2 align-items-center">
                <!-- Department Filter -->
                <div class="col-12 col-md-auto" style="min-width: 170px;">
                    <select name="dept" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" onchange="document.getElementById('attendanceFilterForm').submit();" style="font-size: 0.86rem; height: 38px;">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= e($d['name']) ?>" <?= ($selectedDept === $d['name']) ? 'selected' : '' ?>>
                                <?= e($d['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Role Filter -->
                <div class="col-12 col-md-auto" style="min-width: 150px;">
                    <select name="role" class="form-select form-select-sm border-light-subtle rounded-3 shadow-none fw-medium text-secondary" onchange="document.getElementById('attendanceFilterForm').submit();" style="font-size: 0.86rem; height: 38px;">
                        <option value="">All Roles</option>
                        <?php foreach ($roles as $r): ?>
                            <option value="<?= e($r['name']) ?>" <?= ($selectedRole === $r['name']) ? 'selected' : '' ?>>
                                <?= e($r['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Date Navigator -->
                <div class="col-12 col-md-auto d-flex align-items-center gap-1">
                    <a href="<?= e(url('attendance/staff?date=' . $prevDate . ($selectedDept ? '&dept='.urlencode($selectedDept) : '') . ($selectedRole ? '&role='.urlencode($selectedRole) : ''))) ?>" 
                       class="btn btn-sm btn-light border border-light-subtle rounded-3 d-flex align-items-center justify-content-center text-secondary" 
                       style="width: 38px; height: 38px;" title="Previous Day">
                        <i data-lucide="chevron-left" style="width: 16px; height: 16px;"></i>
                    </a>

                    <div class="position-relative">
                        <input type="date" name="date" id="datePickerInput" value="<?= e($currentDate) ?>" 
                               class="form-control form-control-sm border-light-subtle rounded-3 text-center fw-medium text-dark shadow-none" 
                               style="height: 38px; font-size: 0.86rem; min-width: 145px;"
                               onchange="document.getElementById('attendanceFilterForm').submit();">
                    </div>

                    <a href="<?= e(url('attendance/staff?date=' . $nextDate . ($selectedDept ? '&dept='.urlencode($selectedDept) : '') . ($selectedRole ? '&role='.urlencode($selectedRole) : ''))) ?>" 
                       class="btn btn-sm btn-light border border-light-subtle rounded-3 d-flex align-items-center justify-content-center text-secondary" 
                       style="width: 38px; height: 38px;" title="Next Day">
                        <i data-lucide="chevron-right" style="width: 16px; height: 16px;"></i>
                    </a>

                    <a href="<?= e(url('attendance/staff?date=' . $todayDate . ($selectedDept ? '&dept='.urlencode($selectedDept) : '') . ($selectedRole ? '&role='.urlencode($selectedRole) : ''))) ?>" 
                       class="btn btn-sm btn-light border border-light-subtle rounded-3 fw-medium text-secondary px-3" 
                       style="height: 38px; font-size: 0.86rem;">
                        Today
                    </a>
                </div>

                <!-- Client Search Box -->
                <div class="col-12 col-md ms-md-auto">
                    <div class="position-relative">
                        <i data-lucide="search" class="position-absolute text-muted" style="left: 12px; top: 11px; width: 16px; height: 16px;"></i>
                        <input type="text" id="staffLiveSearch" class="form-control form-control-sm border-light-subtle rounded-3 ps-5 shadow-none" 
                               placeholder="Search staff..." style="height: 38px; font-size: 0.86rem;">
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Attendance Form containing KPIs & Register Table -->
    <form method="post" action="<?= e(url('attendance/staff')) ?>" id="staffAttendanceForm">
        <?= csrf_field() ?>
        <input type="hidden" name="date" value="<?= e($currentDate) ?>">

        <!-- KPI Metrics & Bulk Action Bar -->
        <div class="card border-0 shadow-sm rounded-3 mb-3" style="border: 1px solid #eef2f6 !important;">
            <div class="card-body p-3 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <!-- Left KPI Pills -->
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <!-- Submitted Status Badge -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-2" id="kpiSubmitted"
                          style="background: <?= $isSubmitted ? '#ecfdf5' : '#f8fafc' ?>; color: <?= $isSubmitted ? '#059669' : '#64748b' ?>; border: 1px solid <?= $isSubmitted ? '#a7f3d0' : '#e2e8f0' ?>; font-size: 0.82rem;">
                        <span class="rounded-circle" style="width: 8px; height: 8px; background: <?= $isSubmitted ? '#10b981' : '#94a3b8' ?>;"></span>
                        <?= $isSubmitted ? 'Submitted' : 'Not Saved' ?>
                    </span>

                    <!-- Total Staff -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium text-secondary bg-light border d-inline-flex align-items-center gap-1" style="font-size: 0.82rem;">
                        <i data-lucide="users" style="width: 13px; height: 13px;"></i>
                        <span id="kpiTotal"><?= (int)$totalStaff ?></span> Staff
                    </span>

                    <!-- Present -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-1" 
                          style="background: #ecfdf5; color: #047857; border: 1px solid #bbf7d0; font-size: 0.82rem;">
                        <i data-lucide="check" style="width: 13px; height: 13px;"></i>
                        Present: <span id="kpiPresent"><?= (int)$presentCount ?></span>
                        <span id="kpiLateSuffix" style="<?= $lateCount > 0 ? '' : 'display:none;' ?>">(+<span id="kpiLateCount"><?= (int)$lateCount ?></span>L)</span>
                    </span>

                    <!-- Absent -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-1" 
                          style="background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; font-size: 0.82rem;">
                        <i data-lucide="x" style="width: 13px; height: 13px;"></i>
                        Absent: <span id="kpiAbsent"><?= (int)$absentCount ?></span>
                    </span>

                    <!-- Half Day -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-1" 
                          style="background: #fffbeb; color: #b45309; border: 1px solid #fde68a; font-size: 0.82rem;">
                        <i data-lucide="sun" style="width: 13px; height: 13px;"></i>
                        Half: <span id="kpiHalf"><?= (int)$halfDayCount ?></span>
                    </span>

                    <!-- Rate -->
                    <span class="badge rounded-pill px-3 py-2 fw-medium d-inline-flex align-items-center gap-1" 
                          style="background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; font-size: 0.82rem;">
                        <i data-lucide="clock" style="width: 13px; height: 13px;"></i>
                        Rate: <span id="kpiRate"><?= (int)$rate ?></span>%
                    </span>
                </div>

                <!-- Right Action Buttons -->
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <button type="button" class="btn btn-sm btn-outline-secondary rounded-3 px-3 py-2 fw-medium d-flex align-items-center gap-1 shadow-none bg-white" 
                            id="btnMarkAllPresent" onclick="markAllPresent();" style="font-size: 0.85rem; border-color: #cbd5e1;">
                        <i data-lucide="check" style="width: 15px; height: 15px;"></i> Mark All Present
                    </button>

                    <button type="submit" class="btn btn-sm text-white rounded-3 px-4 py-2 fw-semibold d-flex align-items-center gap-1 shadow-none" 
                            style="background: #4f46e5; font-size: 0.85rem;">
                        <i data-lucide="save" style="width: 15px; height: 15px;"></i> Save
                    </button>
                </div>
            </div>
        </div>

        <!-- Register Table Card -->
        <div class="card border-0 shadow-sm rounded-3 overflow-hidden" style="border: 1px solid #eef2f6 !important;">
            <div class="table-responsive mb-0">
                <table class="table table-hover align-middle mb-0" id="staffAttendanceTable">
                    <thead style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                        <tr>
                            <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.75rem; width: 38%;">
                                Staff Member
                            </th>
                            <th scope="col" class="py-3 px-3 text-secondary small fw-semibold text-uppercase text-center" style="letter-spacing: 0.05em; font-size: 0.75rem; width: 38%;">
                                Status
                            </th>
                            <th scope="col" class="py-3 px-4 text-secondary small fw-semibold text-uppercase" style="letter-spacing: 0.05em; font-size: 0.75rem; width: 24%;">
                                Remarks / Note
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y" style="border-top: 0;">
                        <?php if (empty($employees)): ?>
                            <tr>
                                <td colspan="3" class="text-center py-5 text-muted">
                                    <div class="py-4">
                                        <i data-lucide="users" class="mb-2 text-muted" style="width: 42px; height: 42px; opacity: 0.4;"></i>
                                        <p class="mb-0 fw-medium">No staff members found matching the selected filters.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $avatarPalettes = [
                                ['bg' => '#fef3c7', 'text' => '#b45309'], // warm amber
                                ['bg' => '#e0e7ff', 'text' => '#4338ca'], // indigo
                                ['bg' => '#dcfce7', 'text' => '#15803d'], // emerald
                                ['bg' => '#e0f2fe', 'text' => '#0369a1'], // sky blue
                                ['bg' => '#f3e8ff', 'text' => '#7e22ce'], // purple
                                ['bg' => '#fee2e2', 'text' => '#b91c1c'], // rose
                                ['bg' => '#ffedd5', 'text' => '#c2410c'], // orange
                            ];

                            foreach ($employees as $idx => $emp): 
                                $eid = (int)$emp['id'];
                                $isSelf = ($currentEmployeeId && (int)$currentEmployeeId === $eid);
                                $status = $existing[$eid] ?? 'present';
                                $remark = $existingRemarks[$eid] ?? '';
                                
                                $firstInit = mb_strtoupper(mb_substr($emp['first_name'] ?? '', 0, 1));
                                $lastInit = mb_strtoupper(mb_substr($emp['last_name'] ?? '', 0, 1));
                                $initials = ($firstInit . $lastInit) ?: 'ST';
                                
                                $palette = $avatarPalettes[$eid % count($avatarPalettes)];
                                $fullName = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
                                $empCode = $emp['employee_code'] ?? ('EMP' . str_pad((string)$eid, 4, '0', STR_PAD_LEFT));
                                
                                $designation = $emp['designation_name'] ?? ($emp['designation'] ?? 'Staff Member');
                                $department = $emp['department_name'] ?? ($emp['department'] ?? 'General');
                            ?>
                            <tr class="staff-row" data-emp-id="<?= $eid ?>" data-name="<?= e(strtolower($fullName)) ?>" data-code="<?= e(strtolower($empCode)) ?>" style="border-bottom: 1px solid #f1f5f9;">
                                <!-- Staff Member Profile -->
                                <td class="py-3 px-4">
                                    <div class="d-flex align-items-center gap-3">
                                        <!-- Avatar with Initials -->
                                        <div class="rounded-circle d-flex align-items-center justify-content-center fw-semibold flex-shrink-0" 
                                             style="width: 40px; height: 40px; background-color: <?= $palette['bg'] ?>; color: <?= $palette['text'] ?>; font-size: 0.88rem;">
                                            <?= e($initials) ?>
                                        </div>

                                        <!-- Name, Monospace Code & Role details -->
                                        <div>
                                            <div class="d-flex align-items-center gap-2 mb-1">
                                                <span class="fw-bold text-dark" style="font-size: 0.92rem;">
                                                    <?= e($fullName) ?>
                                                </span>
                                                <span class="badge border bg-light text-muted font-monospace" style="font-size: 0.72rem; font-weight: 500; letter-spacing: 0.02em; padding: 2px 6px;">
                                                    <?= e($empCode) ?>
                                                </span>
                                                <?php if ($isSelf): ?>
                                                    <span class="badge rounded-pill bg-secondary text-white" style="font-size: 0.65rem;">You</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="text-muted small" style="font-size: 0.8rem;">
                                                <span><?= e($designation) ?></span>
                                                <span class="mx-1 text-muted" style="opacity: 0.6;">•</span>
                                                <span><?= e($department) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <!-- Status Segmented Toggle -->
                                <td class="py-3 px-3 text-center">
                                    <?php if ($isSelf): ?>
                                        <div class="text-muted small d-inline-flex align-items-center gap-1 bg-light px-3 py-1 rounded-pill border">
                                            <i data-lucide="lock" style="width: 13px; height: 13px;"></i> Cannot self-mark
                                        </div>
                                        <input type="hidden" name="status[<?= $eid ?>]" value="<?= e($status) ?>" id="status_input_<?= $eid ?>">
                                    <?php else: ?>
                                        <input type="hidden" name="status[<?= $eid ?>]" value="<?= e($status) ?>" id="status_input_<?= $eid ?>" class="row-status-input">
                                        
                                        <div class="btn-group btn-group-sm rounded-pill p-1 bg-light border shadow-none" role="group" id="status_group_<?= $eid ?>">
                                            <!-- Present -->
                                            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium status-btn status-btn-present <?= ($status === 'present') ? 'active' : '' ?>" 
                                                    data-status="present" onclick="setStatus(<?= $eid ?>, 'present')">
                                                <i data-lucide="check" class="me-1" style="width: 14px; height: 14px;"></i> Present
                                            </button>

                                            <!-- Absent -->
                                            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium status-btn status-btn-absent <?= ($status === 'absent') ? 'active' : '' ?>" 
                                                    data-status="absent" onclick="setStatus(<?= $eid ?>, 'absent')">
                                                <i data-lucide="x" class="me-1" style="width: 14px; height: 14px;"></i> Absent
                                            </button>

                                            <!-- Late -->
                                            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium status-btn status-btn-late <?= ($status === 'late') ? 'active' : '' ?>" 
                                                    data-status="late" onclick="setStatus(<?= $eid ?>, 'late')">
                                                <i data-lucide="clock" class="me-1" style="width: 14px; height: 14px;"></i> Late
                                            </button>

                                            <!-- Leave -->
                                            <button type="button" class="btn btn-sm rounded-pill px-3 py-1 fw-medium status-btn status-btn-leave <?= ($status === 'leave') ? 'active' : '' ?>" 
                                                    data-status="leave" onclick="setStatus(<?= $eid ?>, 'leave')">
                                                <i data-lucide="calendar-x" class="me-1" style="width: 14px; height: 14px;"></i> Leave
                                            </button>

                                            <!-- More Dropdown (Half Day / Holiday) -->
                                            <div class="btn-group btn-group-sm" role="group">
                                                <button type="button" class="btn btn-sm rounded-pill px-2 py-1 fw-medium status-btn status-btn-more dropdown-toggle <?= in_array($status, ['half_day', 'holiday']) ? 'active' : '' ?>" 
                                                        data-bs-toggle="dropdown" aria-expanded="false" id="moreBtn_<?= $eid ?>">
                                                    <span class="more-label"><?= ($status === 'half_day') ? 'Half' : (($status === 'holiday') ? 'Holiday' : 'More') ?></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 mt-1" style="font-size: 0.85rem; border: 1px solid #eef2f6 !important;">
                                                    <li>
                                                        <a class="dropdown-item py-2 d-flex align-items-center gap-2 <?= ($status === 'half_day') ? 'active fw-bold' : '' ?>" href="javascript:void(0)" onclick="setStatus(<?= $eid ?>, 'half_day')">
                                                            <i data-lucide="sun" style="width: 15px; height: 15px; color: #d97706;"></i> Half Day
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item py-2 d-flex align-items-center gap-2 <?= ($status === 'holiday') ? 'active fw-bold' : '' ?>" href="javascript:void(0)" onclick="setStatus(<?= $eid ?>, 'holiday')">
                                                            <i data-lucide="calendar" style="width: 15px; height: 15px; color: #4b5563;"></i> Holiday / Off
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <!-- Remarks / Note -->
                                <td class="py-3 px-4">
                                    <div class="remark-container" id="remarkContainer_<?= $eid ?>">
                                        <!-- Note input field (hidden by default unless editing or pre-filled) -->
                                        <div class="remark-edit-box <?= $remark !== '' ? 'd-none' : 'd-none' ?>" id="remarkEdit_<?= $eid ?>">
                                            <div class="input-group input-group-sm">
                                                <input type="text" name="remarks[<?= $eid ?>]" id="remarkInput_<?= $eid ?>" 
                                                       value="<?= e($remark) ?>" class="form-control form-control-sm rounded-3 border-light-subtle shadow-none" 
                                                       placeholder="Add remark..." style="font-size: 0.82rem;"
                                                       onblur="saveRemarkInline(<?= $eid ?>)">
                                                <button type="button" class="btn btn-light border-light-subtle rounded-3" onclick="saveRemarkInline(<?= $eid ?>)">
                                                    <i data-lucide="check" style="width: 14px; height: 14px;"></i>
                                                </button>
                                            </div>
                                        </div>

                                        <!-- If remark exists -->
                                        <div class="remark-display-box <?= $remark !== '' ? 'd-flex' : 'd-none' ?> align-items-center justify-content-between gap-2 p-1 px-2 rounded-3" 
                                             id="remarkDisplay_<?= $eid ?>" 
                                             style="background: #f8fafc; border: 1px dashed #cbd5e1; cursor: pointer;"
                                             onclick="openRemarkEdit(<?= $eid ?>)" title="Click to edit remark">
                                            <div class="d-flex align-items-center gap-2 text-secondary small text-truncate" style="font-size: 0.82rem;">
                                                <i data-lucide="file-text" style="width: 14px; height: 14px; color: #64748b; flex-shrink: 0;"></i>
                                                <span class="text-truncate" id="remarkText_<?= $eid ?>"><?= e($remark) ?></span>
                                            </div>
                                            <i data-lucide="edit-2" style="width: 12px; height: 12px; color: #94a3b8; flex-shrink: 0;"></i>
                                        </div>

                                        <!-- If empty note -->
                                        <button type="button" class="btn btn-sm text-secondary p-0 fw-medium d-flex align-items-center gap-1 border-0 bg-transparent <?= $remark === '' ? 'd-inline-flex' : 'd-none' ?>" 
                                                id="remarkAddBtn_<?= $eid ?>" onclick="openRemarkEdit(<?= $eid ?>)" style="font-size: 0.83rem; color: #64748b !important;">
                                            <i data-lucide="plus-circle" style="width: 14px; height: 14px; color: #94a3b8;"></i> Add note
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Table Footer -->
            <div class="p-3 bg-light border-top d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div class="text-muted small d-flex align-items-center gap-2">
                    <i data-lucide="info" style="width: 15px; height: 15px; color: #6366f1;"></i>
                    <span>Changes take effect once you click <strong>Save</strong>. Make sure all statuses are verified before submitting.</span>
                </div>
                <button type="submit" class="btn btn-sm text-white rounded-3 px-4 py-2 fw-semibold d-flex align-items-center gap-1 shadow-none" 
                        style="background: #4f46e5; font-size: 0.85rem;">
                    <i data-lucide="save" style="width: 15px; height: 15px;"></i> Save Attendance
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Monthly Overview Modal -->
<div class="modal fade" id="monthlyOverviewModal" tabindex="-1" aria-labelledby="monthlyOverviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-bottom py-3 px-4">
                <div>
                    <h5 class="modal-title fw-bold text-dark mb-0" id="monthlyOverviewModalLabel">Monthly Staff Attendance Overview</h5>
                    <p class="text-muted small mb-0">Aggregate view for <?= date('F Y', strtotime($currentDate)) ?></p>
                </div>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3 mb-4">
                    <div class="col-sm-4">
                        <div class="p-3 rounded-3 bg-light border text-center">
                            <span class="text-muted small fw-medium text-uppercase d-block mb-1">Average Rate</span>
                            <span class="h3 fw-bold text-primary mb-0"><?= (int)$rate ?>%</span>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="p-3 rounded-3 bg-light border text-center">
                            <span class="text-muted small fw-medium text-uppercase d-block mb-1">Total Active Staff</span>
                            <span class="h3 fw-bold text-dark mb-0"><?= (int)$totalStaff ?></span>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="p-3 rounded-3 bg-light border text-center">
                            <span class="text-muted small fw-medium text-uppercase d-block mb-1">Working Days (MTD)</span>
                            <span class="h3 fw-bold text-dark mb-0"><?= min((int)date('j', strtotime($currentDate)), 26) ?> Days</span>
                        </div>
                    </div>
                </div>

                <div class="alert alert-light border small text-muted mb-0">
                    <i data-lucide="check-circle" class="me-1 text-success" style="width: 16px; height: 16px;"></i>
                    Staff attendance register records are preserved in the central ledger with tamper-evident audit trails.
                </div>
            </div>
            <div class="modal-footer border-top py-2 px-4">
                <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
/* Button Group & Status segmented pills styling */
.status-btn {
    border: none !important;
    background: transparent !important;
    color: #64748b !important;
    font-size: 0.8rem !important;
    transition: all 0.15s ease-in-out;
}
.status-btn:hover {
    color: #1e293b !important;
    background: rgba(0, 0, 0, 0.04) !important;
}

/* Present: Emerald / Green */
.status-btn-present.active {
    background: #059669 !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(5, 150, 105, 0.3) !important;
}

/* Absent: Rose / Red */
.status-btn-absent.active {
    background: #dc2626 !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(220, 38, 38, 0.3) !important;
}

/* Late: Amber / Orange */
.status-btn-late.active {
    background: #d97706 !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(217, 119, 6, 0.3) !important;
}

/* Leave: Blue */
.status-btn-leave.active {
    background: #2563eb !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(37, 99, 235, 0.3) !important;
}

/* More / Half / Holiday */
.status-btn-more.active {
    background: #7c3aed !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(124, 58, 237, 0.3) !important;
}

.table > :not(caption) > * > * {
    padding: 0.75rem 0.75rem;
}

.staff-row:hover {
    background-color: #fafbfc !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Live search functionality
    const searchInput = document.getElementById('staffLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.staff-row');
            
            rows.forEach(row => {
                const name = row.getAttribute('data-name') || '';
                const code = row.getAttribute('data-code') || '';
                if (!query || name.includes(query) || code.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});

// Set Status for a staff member
function setStatus(empId, status) {
    const input = document.getElementById('status_input_' + empId);
    if (!input) return;
    input.value = status;

    const group = document.getElementById('status_group_' + empId);
    if (!group) return;

    // Reset all buttons in this group
    group.querySelectorAll('.status-btn').forEach(btn => btn.classList.remove('active'));

    const moreBtn = document.getElementById('moreBtn_' + empId);
    const moreLabel = moreBtn ? moreBtn.querySelector('.more-label') : null;

    if (status === 'present') {
        const btn = group.querySelector('.status-btn-present');
        if (btn) btn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'More';
    } else if (status === 'absent') {
        const btn = group.querySelector('.status-btn-absent');
        if (btn) btn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'More';
    } else if (status === 'late') {
        const btn = group.querySelector('.status-btn-late');
        if (btn) btn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'More';
    } else if (status === 'leave') {
        const btn = group.querySelector('.status-btn-leave');
        if (btn) btn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'More';
    } else if (status === 'half_day') {
        if (moreBtn) moreBtn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'Half';
    } else if (status === 'holiday') {
        if (moreBtn) moreBtn.classList.add('active');
        if (moreLabel) moreLabel.textContent = 'Holiday';
    }

    recalcKpis();
}

// Mark All Present
function markAllPresent() {
    const rows = document.querySelectorAll('.staff-row');
    rows.forEach(row => {
        const empId = row.getAttribute('data-emp-id');
        const input = document.getElementById('status_input_' + empId);
        // Only mark if not self locked
        if (input && !input.closest('td').querySelector('.bg-light.px-3')) {
            setStatus(empId, 'present');
        }
    });
}

// Recalculate KPI numbers in the banner
function recalcKpis() {
    const inputs = document.querySelectorAll('.row-status-input');
    let total = inputs.length;
    let present = 0;
    let absent = 0;
    let late = 0;
    let half = 0;
    let leave = 0;

    inputs.forEach(inp => {
        const v = inp.value;
        if (v === 'present') present++;
        else if (v === 'absent') absent++;
        else if (v === 'late') late++;
        else if (v === 'half_day') half++;
        else if (v === 'leave') leave++;
    });

    const kpiPresent = document.getElementById('kpiPresent');
    const kpiAbsent = document.getElementById('kpiAbsent');
    const kpiHalf = document.getElementById('kpiHalf');
    const kpiRate = document.getElementById('kpiRate');
    const kpiLateSuffix = document.getElementById('kpiLateSuffix');
    const kpiLateCount = document.getElementById('kpiLateCount');

    if (kpiPresent) kpiPresent.textContent = present;
    if (kpiAbsent) kpiAbsent.textContent = absent;
    if (kpiHalf) kpiHalf.textContent = half;
    if (kpiLateCount) kpiLateCount.textContent = late;
    if (kpiLateSuffix) {
        kpiLateSuffix.style.display = (late > 0) ? 'inline' : 'none';
    }

    if (total > 0 && kpiRate) {
        const effective = present + late + (half * 0.5);
        const ratePct = Math.round((effective / total) * 100);
        kpiRate.textContent = ratePct;
    }
}

// Remarks Inline editing
function openRemarkEdit(empId) {
    const editBox = document.getElementById('remarkEdit_' + empId);
    const displayBox = document.getElementById('remarkDisplay_' + empId);
    const addBtn = document.getElementById('remarkAddBtn_' + empId);
    const input = document.getElementById('remarkInput_' + empId);

    if (editBox) editBox.classList.remove('d-none');
    if (displayBox) displayBox.classList.remove('d-flex');
    if (displayBox) displayBox.classList.add('d-none');
    if (addBtn) addBtn.classList.remove('d-inline-flex');
    if (addBtn) addBtn.classList.add('d-none');

    if (input) {
        input.focus();
    }
}

function saveRemarkInline(empId) {
    const editBox = document.getElementById('remarkEdit_' + empId);
    const displayBox = document.getElementById('remarkDisplay_' + empId);
    const addBtn = document.getElementById('remarkAddBtn_' + empId);
    const input = document.getElementById('remarkInput_' + empId);
    const textSpan = document.getElementById('remarkText_' + empId);

    if (!input) return;
    const val = input.value.trim();

    if (editBox) editBox.classList.add('d-none');

    if (val !== '') {
        if (textSpan) textSpan.textContent = val;
        if (displayBox) {
            displayBox.classList.remove('d-none');
            displayBox.classList.add('d-flex');
        }
        if (addBtn) addBtn.classList.add('d-none');
    } else {
        if (displayBox) displayBox.classList.add('d-none');
        if (addBtn) {
            addBtn.classList.remove('d-none');
            addBtn.classList.add('d-inline-flex');
        }
    }
}

function toggleMonthlyModal() {
    const modalEl = document.getElementById('monthlyOverviewModal');
    if (modalEl && window.bootstrap) {
        const modal = new window.bootstrap.Modal(modalEl);
        modal.show();
    }
}
</script>
