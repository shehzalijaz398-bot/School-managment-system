<div class="panel">
  <h2>Student Attendance Report</h2>
  <form class="row g-2 mb-3" method="get">
    <div class="col-md-2"><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div>
    <div class="col-md-2"><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div>
    <div class="col-md-3">
      <select name="class_id" class="form-select">
        <?php foreach ($classes as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= (int)$classId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2"><input name="section_id" class="form-control" value="<?= (int)$sectionId ?>" placeholder="Section ID"></div>
    <div class="col-md-2"><button class="btn btn-outline-primary">Run</button></div>
  </form>
  <table class="table table-sm"><thead><tr><th>Date</th><th>Student</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?>
    <tr><td><?= e(formatDate($r['attendance_date'])) ?></td><td><?= e($r['student_name']) ?></td><td><?= statusBadge($r['status']) ?></td></tr>
  <?php endforeach; ?>
  </tbody></table>
</div>
