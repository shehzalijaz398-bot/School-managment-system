<?php
$classId = (int) ($classId ?? 0);
$sectionId = (int) ($sectionId ?? 0);
$date = $date ?? date('Y-m-d');
$sum = $summary ?? ['total' => count($students), 'present' => 0, 'late' => 0, 'absent' => 0, 'half' => 0, 'leave' => 0, 'rate_pct' => 0];

// Avatar pastel color palettes based on hash
$avatarColors = [
    ['bg' => '#ffedd5', 'color' => '#c2410c'], // Orange
    ['bg' => '#fef3c7', 'color' => '#b45309'], // Amber
    ['bg' => '#dcfce7', 'color' => '#15803d'], // Green
    ['bg' => '#ccfbf1', 'color' => '#0f766e'], // Teal
    ['bg' => '#fee2e2', 'color' => '#b91c1c'], // Red
    ['bg' => '#f3e8ff', 'color' => '#7e22ce'], // Purple
    ['bg' => '#e0e7ff', 'color' => '#4338ca'], // Indigo
    ['bg' => '#e0f2fe', 'color' => '#0369a1'], // Sky
    ['bg' => '#fce7f3', 'color' => '#be185d'], // Pink
];

// Helper to calculate previous and next dates
$prevDate = date('Y-m-d', strtotime($date . ' -1 day'));
$nextDate = date('Y-m-d', strtotime($date . ' +1 day'));
$todayDate = date('Y-m-d');
$displayDate = date('d/m/Y', strtotime($date));
?>

<div class="codeclove-attendance-wrap">

  <!-- 1. Top Filter & Controls Card -->
  <div class="cc-att-card mb-3">
    <div class="p-3">
      <form method="get" action="<?= e(url('attendance/students')) ?>" id="attFilterForm" class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        
        <!-- Left Dropdowns & Date Navigator -->
        <div class="d-flex flex-wrap align-items-center gap-2">
          
          <!-- Class Selector -->
          <div style="min-width: 140px;">
            <select name="class_id" class="form-select form-select-sm cc-att-select" onchange="document.getElementById('attFilterForm').submit();">
              <?php foreach ($classes as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= $classId == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Section Selector -->
          <div style="min-width: 130px;">
            <select name="section_id" class="form-select form-select-sm cc-att-select" onchange="document.getElementById('attFilterForm').submit();">
              <option value="0" <?= $sectionId == 0 ? 'selected' : '' ?>>All Sections</option>
              <?php foreach ($availableSections as $sec): ?>
                <option value="<?= (int)$sec['id'] ?>" <?= $sectionId == $sec['id'] ? 'selected' : '' ?>><?= e($sec['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Date Navigator: < | Date Picker | > | Today -->
          <div class="cc-date-nav d-flex align-items-center">
            <a href="<?= e(url('attendance/students?class_id=' . $classId . '&section_id=' . $sectionId . '&date=' . $prevDate)) ?>" class="cc-date-btn" title="Previous Day">
              <i data-lucide="chevron-left" style="width:14px;height:14px;"></i>
            </a>

            <div class="cc-date-picker-wrap">
              <input type="date" name="date" id="attDateInput" value="<?= e($date) ?>" class="cc-date-native" onchange="document.getElementById('attFilterForm').submit();">
              <label for="attDateInput" class="cc-date-display mb-0">
                <span><?= e($displayDate) ?></span>
                <i data-lucide="calendar" style="width:14px;height:14px;color:#64748b;"></i>
              </label>
            </div>

            <a href="<?= e(url('attendance/students?class_id=' . $classId . '&section_id=' . $sectionId . '&date=' . $nextDate)) ?>" class="cc-date-btn" title="Next Day">
              <i data-lucide="chevron-right" style="width:14px;height:14px;"></i>
            </a>

            <a href="<?= e(url('attendance/students?class_id=' . $classId . '&section_id=' . $sectionId . '&date=' . $todayDate)) ?>" class="cc-today-btn ms-2 text-decoration-none">
              today
            </a>
          </div>

        </div>

        <!-- Right Side: Search Box -->
        <div class="cc-att-search-wrap">
          <i data-lucide="search" class="cc-search-icon"></i>
          <input type="text" id="studentLiveSearch" class="form-control form-control-sm cc-att-search-input" placeholder="Search student...">
        </div>

      </form>
    </div>

    <!-- 2. Summary Status Badges & Action Buttons Bar -->
    <div class="cc-att-summary-bar d-flex flex-wrap align-items-center justify-content-between gap-3 px-3 py-2 border-top">
      
      <!-- Badges Cluster -->
      <div class="d-flex flex-wrap align-items-center gap-2">
        <!-- Submission Status -->
        <?php if ($isSubmitted): ?>
          <span class="cc-pill-badge cc-pill-submitted">
            <i data-lucide="check" style="width:13px;height:13px;"></i> Submitted
          </span>
        <?php else: ?>
          <span class="cc-pill-badge cc-pill-unsubmitted">
            <i data-lucide="clock" style="width:13px;height:13px;"></i> Not Submitted
          </span>
        <?php endif; ?>

        <!-- Students Count -->
        <span class="cc-pill-badge cc-pill-neutral">
          <i data-lucide="users" style="width:13px;height:13px;"></i> <span id="statTotalStudents"><?= $sum['total'] ?></span> Students
        </span>

        <!-- Present Count -->
        <span class="cc-pill-badge cc-pill-present">
          <i data-lucide="check" style="width:13px;height:13px;"></i> Present: <strong id="statPresentCount"><?= $sum['present'] ?></strong> (<span id="statLatePill">+<?= $sum['late'] ?>L</span>)
        </span>

        <!-- Absent Count -->
        <span class="cc-pill-badge cc-pill-absent">
          <i data-lucide="x" style="width:13px;height:13px;"></i> Absent: <strong id="statAbsentCount"><?= $sum['absent'] ?></strong>
        </span>

        <!-- Half Day Count -->
        <span class="cc-pill-badge cc-pill-half">
          <i data-lucide="sun" style="width:13px;height:13px;"></i> Half: <strong id="statHalfCount"><?= $sum['half'] ?></strong>
        </span>

        <!-- Rate % -->
        <span class="cc-pill-badge cc-pill-rate">
          <i data-lucide="pie-chart" style="width:13px;height:13px;"></i> Rate: <strong id="statRatePct"><?= $sum['rate_pct'] ?>%</strong>
        </span>
      </div>

      <!-- Action Buttons -->
      <div class="d-flex align-items-center gap-2">
        <button type="button" class="btn btn-sm cc-btn-outline-action" id="markAllPresentBtn">
          <i data-lucide="check" style="width:14px;height:14px;"></i> Mark All Present
        </button>
        <button type="button" class="btn btn-sm cc-btn-primary-save" id="saveAttendanceBtn">
          <i data-lucide="save" style="width:14px;height:14px;"></i> Save
        </button>
      </div>

    </div>
  </div>

  <!-- 3. Attendance Table Card -->
  <div class="cc-att-card">
    <?php if (!empty($students)): ?>
    <form method="post" action="<?= e(url('attendance/students')) ?>" id="attendanceSaveForm">
      <?= csrf_field() ?>
      <input type="hidden" name="class_id" value="<?= (int)$classId ?>">
      <input type="hidden" name="section_id" value="<?= (int)$sectionId ?>">
      <input type="hidden" name="date" value="<?= e($date) ?>">

      <div class="table-responsive">
        <table class="table align-middle mb-0 cc-att-table" id="attendanceTable">
          <thead>
            <tr>
              <th style="width: 38%;">STUDENT</th>
              <th style="width: 42%; text-align: center;">STATUS</th>
              <th style="width: 20%; text-align: end;">REMARKS / NOTE</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            foreach ($students as $index => $st):
                $sid = (int) $st['id'];
                $cur = $existing[$sid] ?? 'present';
                $note = $remarks[$sid] ?? '';
                $initials = strtoupper(substr($st['first_name'], 0, 1) . substr($st['last_name'] ?? '', 0, 1));
                if (strlen($initials) === 1) $initials = strtoupper(substr($st['first_name'], 0, 2));
                $fullName = trim($st['first_name'] . ' ' . ($st['last_name'] ?? ''));
                $color = $avatarColors[$index % count($avatarColors)];
                $sectionName = $st['section_name'] ?? 'A';
                $rollNo = $st['roll_no'] ?: ($index + 1);
                $admNo = $st['admission_no'] ?: ('STU' . str_pad((string)$sid, 8, '0', STR_PAD_LEFT));
            ?>
            <tr class="cc-student-row" data-student-id="<?= $sid ?>" data-name="<?= strtolower(e($fullName)) ?>" data-adm="<?= strtolower(e($admNo)) ?>" data-roll="<?= strtolower(e($rollNo)) ?>">
              
              <!-- Student Info -->
              <td>
                <div class="d-flex align-items-center gap-3">
                  <div class="cc-att-avatar" style="background-color: <?= $color['bg'] ?>; color: <?= $color['color'] ?>;">
                    <?= e($initials) ?>
                  </div>
                  <div>
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                      <span class="cc-student-name"><?= e($fullName) ?></span>
                      <span class="cc-adm-pill"><?= e($admNo) ?></span>
                    </div>
                    <div class="cc-student-meta">
                      Section <?= e($sectionName) ?> &bull; Roll: <?= e($rollNo) ?>
                    </div>
                  </div>
                </div>
              </td>

              <!-- Status Segmented Button Group -->
              <td class="text-center">
                <!-- Hidden Status Input -->
                <input type="hidden" name="status[<?= $sid ?>]" id="status_input_<?= $sid ?>" value="<?= e($cur) ?>" class="student-status-input">

                <div class="cc-status-group" data-student-id="<?= $sid ?>">
                  
                  <!-- Present -->
                  <button type="button" class="cc-status-btn btn-present <?= $cur === 'present' ? 'active' : '' ?>" data-status="present">
                    <i data-lucide="check" style="width:13px;height:13px;"></i> Present
                  </button>

                  <!-- Absent -->
                  <button type="button" class="cc-status-btn btn-absent <?= $cur === 'absent' ? 'active' : '' ?>" data-status="absent">
                    <i data-lucide="x" style="width:13px;height:13px;"></i> Absent
                  </button>

                  <!-- Late -->
                  <button type="button" class="cc-status-btn btn-late <?= $cur === 'late' ? 'active' : '' ?>" data-status="late">
                    <i data-lucide="clock" style="width:13px;height:13px;"></i> Late
                  </button>

                  <!-- Leave -->
                  <button type="button" class="cc-status-btn btn-leave <?= ($cur === 'leave' || $cur === 'excused') ? 'active' : '' ?>" data-status="leave">
                    <i data-lucide="file-text" style="width:13px;height:13px;"></i> Leave
                  </button>

                  <!-- More / Half Day Dropdown -->
                  <div class="dropdown d-inline-block">
                    <?php if ($cur === 'half_day'): ?>
                      <button type="button" class="cc-status-btn btn-half-day active dropdown-toggle" data-bs-toggle="dropdown">
                        <i data-lucide="sun" style="width:13px;height:13px;"></i> Half Day
                      </button>
                    <?php else: ?>
                      <button type="button" class="cc-status-btn btn-more dropdown-toggle" data-bs-toggle="dropdown">
                        More
                      </button>
                    <?php endif; ?>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 py-1" style="font-size:.82rem;">
                      <li>
                        <button type="button" class="dropdown-item py-2 d-flex align-items-center gap-2 cc-dropdown-status" data-student-id="<?= $sid ?>" data-status="half_day">
                          <i data-lucide="sun" style="width:14px;height:14px;color:#8b5cf6;"></i> Half Day
                        </button>
                      </li>
                      <li>
                        <button type="button" class="dropdown-item py-2 d-flex align-items-center gap-2 cc-dropdown-status" data-student-id="<?= $sid ?>" data-status="excused">
                          <i data-lucide="shield-check" style="width:14px;height:14px;color:#64748b;"></i> Excused
                        </button>
                      </li>
                    </ul>
                  </div>

                </div>
              </td>

              <!-- Remarks / Note -->
              <td class="text-end">
                <input type="hidden" name="remarks[<?= $sid ?>]" id="remark_input_<?= $sid ?>" value="<?= e($note) ?>" class="student-remark-input">
                
                <div id="note_wrap_<?= $sid ?>">
                  <?php if (!empty($note)): ?>
                    <button type="button" class="cc-note-pill edit-note-btn" data-student-id="<?= $sid ?>" data-note="<?= e($note) ?>">
                      <i data-lucide="message-square" style="width:13px;height:13px;"></i>
                      <span class="text-truncate" style="max-width: 140px;"><?= e($note) ?></span>
                    </button>
                  <?php else: ?>
                    <button type="button" class="cc-add-note-btn edit-note-btn" data-student-id="<?= $sid ?>" data-note="">
                      <i data-lucide="file-edit" style="width:13px;height:13px;"></i> Add note
                    </button>
                  <?php endif; ?>
                </div>
              </td>

            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </form>
    <?php else: ?>
      <div class="text-center py-5">
        <div class="mb-3">
          <i data-lucide="users" style="width:48px;height:48px;color:#94a3b8;opacity:.5;"></i>
        </div>
        <h5 class="fw-bold mb-1">No Students Found</h5>
        <p class="text-muted small mb-0">No active students are currently enrolled in this class or section.</p>
      </div>
    <?php endif; ?>
  </div>

</div>

<!-- Note Modal -->
<div class="modal fade" id="noteModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content shadow border-0" style="border-radius:12px;">
      <div class="modal-header py-2 px-3 border-bottom">
        <h6 class="modal-title fw-bold" style="font-size:.88rem;">Student Note / Remark</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" style="font-size:.7rem;"></button>
      </div>
      <div class="modal-body p-3">
        <input type="hidden" id="modalStudentId">
        <textarea id="modalNoteText" class="form-control" rows="3" placeholder="Enter reason or note (e.g. Arrived 10 mins late)..." style="font-size:.85rem;border-radius:8px;"></textarea>
      </div>
      <div class="modal-footer py-2 px-3 border-top">
        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" id="modalSaveNoteBtn">Save Note</button>
      </div>
    </div>
  </div>
</div>

<style>
/* CodeClove Student Attendance Styles */
.codeclove-attendance-wrap {
  width: 100%;
}
.cc-att-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.04);
}
.cc-att-select {
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  font-size: 0.84rem;
  color: #0f172a;
  background-color: #ffffff;
  padding: 0.45rem 2rem 0.45rem 0.75rem;
}
.cc-date-nav {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
}
.cc-date-btn {
  padding: 0.45rem 0.65rem;
  color: #64748b;
  display: flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  background: transparent;
  transition: background 0.15s ease;
}
.cc-date-btn:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-date-picker-wrap {
  position: relative;
  border-left: 1px solid #e2e8f0;
  border-right: 1px solid #e2e8f0;
}
.cc-date-native {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
  opacity: 0;
  cursor: pointer;
}
.cc-date-display {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  padding: 0.45rem 0.75rem;
  font-size: 0.82rem;
  font-weight: 500;
  color: #0f172a;
  cursor: pointer;
}
.cc-today-btn {
  font-size: 0.82rem;
  font-weight: 500;
  color: #64748b;
  border: 1px solid #e2e8f0;
  padding: 0.45rem 0.75rem;
  border-radius: 8px;
  background: #ffffff;
  transition: all 0.15s ease;
}
.cc-today-btn:hover {
  background: #f8fafc;
  color: #0f172a;
}
.cc-att-search-wrap {
  position: relative;
  min-width: 220px;
}
.cc-att-search-input {
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  padding-left: 2rem;
  font-size: 0.84rem;
  background-color: #f8fafc;
}
.cc-att-search-input:focus {
  background-color: #ffffff;
}

/* Summary Badges */
.cc-pill-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  font-size: 0.76rem;
  font-weight: 600;
  padding: 0.25rem 0.65rem;
  border-radius: 9999px;
  line-height: 1.2;
}
.cc-pill-submitted   { background: #ecfdf5; color: #059669; }
.cc-pill-unsubmitted { background: #fef3c7; color: #d97706; }
.cc-pill-neutral     { background: #f1f5f9; color: #475569; }
.cc-pill-present     { background: #ecfdf5; color: #059669; }
.cc-pill-absent      { background: #fef2f2; color: #dc2626; }
.cc-pill-half        { background: #fffbeb; color: #d97706; }
.cc-pill-rate        { background: #eff6ff; color: #2563eb; }

/* Action Buttons */
.cc-btn-outline-action {
  border: 1px solid #cbd5e1;
  background: #ffffff;
  color: #0f172a;
  border-radius: 8px;
  font-size: 0.8rem;
  font-weight: 600;
  padding: 0.4rem 0.85rem;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  transition: all 0.15s ease;
}
.cc-btn-outline-action:hover {
  background: #f8fafc;
  border-color: #94a3b8;
}
.cc-btn-primary-save {
  background: #2563eb;
  border: 1px solid #2563eb;
  color: #ffffff;
  border-radius: 8px;
  font-size: 0.8rem;
  font-weight: 600;
  padding: 0.4rem 1.15rem;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  transition: all 0.15s ease;
}
.cc-btn-primary-save:hover {
  background: #1d4ed8;
  color: #ffffff;
}

/* Attendance Table */
.cc-att-table {
  border-collapse: separate;
  border-spacing: 0;
}
.cc-att-table thead th {
  background: #f8fafc;
  color: #64748b;
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  padding: 0.75rem 1.25rem;
  border-bottom: 1px solid #e2e8f0;
}
.cc-att-table tbody tr {
  border-bottom: 1px solid #f1f5f9;
  transition: background 0.15s ease;
}
.cc-att-table tbody tr:hover {
  background-color: #fbfcfe;
}
.cc-att-table tbody td {
  padding: 0.85rem 1.25rem;
  border-bottom: 1px solid #f1f5f9;
}

/* Student Info Column */
.cc-att-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.82rem;
  flex-shrink: 0;
}
.cc-student-name {
  font-size: 0.88rem;
  font-weight: 600;
  color: #0f172a;
}
.cc-adm-pill {
  font-size: 0.68rem;
  font-family: inherit;
  color: #64748b;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  padding: 0.05rem 0.35rem;
}
.cc-student-meta {
  font-size: 0.75rem;
  color: #64748b;
  margin-top: 0.15rem;
}

/* Status Segmented Control Group */
.cc-status-group {
  display: inline-flex;
  align-items: center;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 2px;
  gap: 2px;
}
.cc-status-btn {
  border: none;
  background: transparent;
  padding: 0.35rem 0.65rem;
  font-size: 0.78rem;
  font-weight: 500;
  color: #64748b;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.cc-status-btn:hover:not(.active) {
  background: #f1f5f9;
  color: #0f172a;
}

/* Active Button States */
.cc-status-btn.btn-present.active {
  background: #10b981;
  color: #ffffff;
  font-weight: 600;
}
.cc-status-btn.btn-absent.active {
  background: #ef4444;
  color: #ffffff;
  font-weight: 600;
}
.cc-status-btn.btn-late.active {
  background: #f59e0b;
  color: #ffffff;
  font-weight: 600;
}
.cc-status-btn.btn-leave.active {
  background: #3b82f6;
  color: #ffffff;
  font-weight: 600;
}
.cc-status-btn.btn-half-day.active {
  background: #8b5cf6;
  color: #ffffff;
  font-weight: 600;
}

/* Remarks Buttons */
.cc-add-note-btn {
  background: transparent;
  border: 1px dashed #cbd5e1;
  border-radius: 6px;
  color: #64748b;
  font-size: 0.76rem;
  font-weight: 500;
  padding: 0.35rem 0.75rem;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cc-add-note-btn:hover {
  background: #f8fafc;
  border-color: #94a3b8;
  color: #0f172a;
}
.cc-note-pill {
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 9999px;
  color: #1d4ed8;
  font-size: 0.76rem;
  font-weight: 500;
  padding: 0.25rem 0.65rem;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cc-note-pill:hover {
  background: #dbeafe;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.lucide) window.lucide.createIcons();

    // 1. Live Search
    const searchInput = document.getElementById('studentLiveSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            const rows = document.querySelectorAll('.cc-student-row');
            rows.forEach(row => {
                const name = row.getAttribute('data-name') || '';
                const adm = row.getAttribute('data-adm') || '';
                const roll = row.getAttribute('data-roll') || '';
                if (name.includes(query) || adm.includes(query) || roll.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
            recalcSummary();
        });
    }

    // 2. Status Buttons Click Handlers
    document.querySelectorAll('.cc-status-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            const group = this.closest('.cc-status-group');
            if (!group) return;
            const studentId = group.getAttribute('data-student-id');
            const targetStatus = this.getAttribute('data-status');
            if (!targetStatus) return;

            // Remove active from sibling status buttons
            group.querySelectorAll('.cc-status-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // Reset More button text if previously half day
            const moreBtn = group.querySelector('.btn-more, .btn-half-day');
            if (moreBtn && targetStatus !== 'half_day') {
                moreBtn.className = 'cc-status-btn btn-more dropdown-toggle';
                moreBtn.innerHTML = 'More';
            }

            // Update hidden input
            const input = document.getElementById('status_input_' + studentId);
            if (input) input.value = targetStatus;

            recalcSummary();
        });
    });

    // 3. Dropdown status click (Half Day / Excused)
    document.querySelectorAll('.cc-dropdown-status').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const studentId = this.getAttribute('data-student-id');
            const targetStatus = this.getAttribute('data-status');
            const group = document.querySelector(`.cc-status-group[data-student-id="${studentId}"]`);
            if (!group) return;

            group.querySelectorAll('.cc-status-btn').forEach(b => b.classList.remove('active'));

            const moreBtn = group.querySelector('.btn-more, .btn-half-day');
            if (moreBtn) {
                if (targetStatus === 'half_day') {
                    moreBtn.className = 'cc-status-btn btn-half-day active dropdown-toggle';
                    moreBtn.innerHTML = '<i data-lucide="sun" style="width:13px;height:13px;"></i> Half Day';
                    if (window.lucide) window.lucide.createIcons();
                } else {
                    moreBtn.className = 'cc-status-btn btn-more active dropdown-toggle';
                    moreBtn.innerHTML = targetStatus.charAt(0).toUpperCase() + targetStatus.slice(1);
                }
            }

            const input = document.getElementById('status_input_' + studentId);
            if (input) input.value = targetStatus;

            recalcSummary();
        });
    });

    // 4. Mark All Present
    const markAllBtn = document.getElementById('markAllPresentBtn');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function() {
            document.querySelectorAll('.cc-student-row').forEach(row => {
                if (row.style.display === 'none') return; // only visible
                const sid = row.getAttribute('data-student-id');
                const group = row.querySelector('.cc-status-group');
                if (group) {
                    group.querySelectorAll('.cc-status-btn').forEach(b => b.classList.remove('active'));
                    const presentBtn = group.querySelector('.btn-present');
                    if (presentBtn) presentBtn.classList.add('active');

                    const moreBtn = group.querySelector('.btn-more, .btn-half-day');
                    if (moreBtn) {
                        moreBtn.className = 'cc-status-btn btn-more dropdown-toggle';
                        moreBtn.innerHTML = 'More';
                    }
                }
                const input = document.getElementById('status_input_' + sid);
                if (input) input.value = 'present';
            });
            recalcSummary();
        });
    }

    // 5. Save Button Trigger
    const saveBtn = document.getElementById('saveAttendanceBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            const form = document.getElementById('attendanceSaveForm');
            if (form) form.submit();
        });
    }

    // 6. Remarks / Note Modal
    const noteModalEl = document.getElementById('noteModal');
    let noteModal = null;
    if (noteModalEl && typeof bootstrap !== 'undefined') {
        noteModal = new bootstrap.Modal(noteModalEl);
    }

    document.querySelectorAll('.edit-note-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const sid = this.getAttribute('data-student-id');
            const noteInput = document.getElementById('remark_input_' + sid);
            const currentNote = noteInput ? noteInput.value : '';

            document.getElementById('modalStudentId').value = sid;
            document.getElementById('modalNoteText').value = currentNote;

            if (noteModal) noteModal.show();
        });
    });

    const modalSaveBtn = document.getElementById('modalSaveNoteBtn');
    if (modalSaveBtn) {
        modalSaveBtn.addEventListener('click', function() {
            const sid = document.getElementById('modalStudentId').value;
            const text = document.getElementById('modalNoteText').value.trim();

            const input = document.getElementById('remark_input_' + sid);
            if (input) input.value = text;

            const wrap = document.getElementById('note_wrap_' + sid);
            if (wrap) {
                if (text) {
                    wrap.innerHTML = `<button type="button" class="cc-note-pill edit-note-btn" data-student-id="${sid}" data-note="${escapeHtml(text)}"><i data-lucide="message-square" style="width:13px;height:13px;"></i> <span class="text-truncate" style="max-width:140px;">${escapeHtml(text)}</span></button>`;
                } else {
                    wrap.innerHTML = `<button type="button" class="cc-add-note-btn edit-note-btn" data-student-id="${sid}" data-note=""><i data-lucide="file-edit" style="width:13px;height:13px;"></i> Add note</button>`;
                }
                if (window.lucide) window.lucide.createIcons();

                // Re-bind click event
                wrap.querySelector('.edit-note-btn').addEventListener('click', function() {
                    document.getElementById('modalStudentId').value = sid;
                    document.getElementById('modalNoteText').value = document.getElementById('remark_input_' + sid).value;
                    if (noteModal) noteModal.show();
                });
            }

            if (noteModal) noteModal.hide();
        });
    }

    // Helper Escape HTML
    function escapeHtml(str) {
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // 7. Dynamic Summary Recalculation
    function recalcSummary() {
        let total = 0;
        let present = 0;
        let late = 0;
        let absent = 0;
        let half = 0;
        let leave = 0;

        document.querySelectorAll('.cc-student-row').forEach(row => {
            if (row.style.display === 'none') return;
            total++;
            const sid = row.getAttribute('data-student-id');
            const input = document.getElementById('status_input_' + sid);
            const status = input ? input.value : 'present';

            if (status === 'present') present++;
            else if (status === 'late') late++;
            else if (status === 'absent') absent++;
            else if (status === 'half_day') half++;
            else if (status === 'leave' || status === 'excused') leave++;
        });

        const effective = present + late + (half * 0.5);
        const rate = total > 0 ? Math.round((effective / total) * 100) : 0;

        const elTotal = document.getElementById('statTotalStudents');
        if (elTotal) elTotal.innerText = total;

        const elPres = document.getElementById('statPresentCount');
        if (elPres) elPres.innerText = present;

        const elLate = document.getElementById('statLatePill');
        if (elLate) elLate.innerText = '+' + late + 'L';

        const elAbs = document.getElementById('statAbsentCount');
        if (elAbs) elAbs.innerText = absent;

        const elHalf = document.getElementById('statHalfCount');
        if (elHalf) elHalf.innerText = half;

        const elRate = document.getElementById('statRatePct');
        if (elRate) elRate.innerText = rate + '%';
    }
});
</script>
