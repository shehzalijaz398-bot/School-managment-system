<?php
$title = 'Reports & Analytics';
$layout = 'layouts/app';
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i class="fas fa-chart-pie text-primary me-2"></i> <?= e($title) ?></h2>
        <p class="text-muted mb-0">Generate, view, and analyze comprehensive school data reports.</p>
    </div>
</div>

<!-- AI School Analytics Feature Card -->
<div class="card border-0 shadow-sm rounded-4 mb-4" style="background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%); color: #ffffff;">
    <div class="card-body p-4 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
            <div class="d-flex align-items-center gap-2 mb-2">
                <span class="badge" style="background: rgba(255, 255, 255, 0.2); color: #ffffff; font-size: 11px; padding: 4px 8px; border-radius: 9999px;">
                    <i class="fas fa-sparkles me-1"></i> AI-POWERED ENGINE
                </span>
                <span class="badge" style="background: rgba(16, 185, 129, 0.25); color: #a7f3d0; font-size: 11px; padding: 4px 8px; border-radius: 9999px;">
                    <i class="fas fa-shield-alt me-1"></i> VERIFIED DATA
                </span>
            </div>
            <h4 class="fw-bold mb-1 text-white">AI School Analytics &amp; Operational Insights</h4>
            <p class="mb-0 opacity-90 small" style="max-width: 650px;">
                Holistic multi-dimensional intelligence synthesizing attendance trends, fee collection velocity, examination pass rates, and actionable anomaly detection.
            </p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="<?= e(url('reports/trends')) ?>" class="btn btn-outline-light fw-bold px-3 py-2 rounded-3 text-nowrap">
                <i class="fas fa-chart-line me-1"></i> MoM Trends
            </a>
            <a href="<?= e(url('reports/executive')) ?>" class="btn btn-outline-light fw-bold px-3 py-2 rounded-3 text-nowrap">
                <i class="fas fa-file-alt me-1"></i> Executive Brief
            </a>
            <a href="<?= e(url('analytics/school')) ?>" class="btn btn-light text-primary fw-bold px-3 py-2 rounded-3 shadow-sm text-nowrap">
                Analytics Console <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Student Reports -->
    <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 h-100 report-card">
            <div class="card-body p-4 d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm" style="width: 50px; height: 50px;">
                        <i class="fas fa-user-graduate fa-lg"></i>
                    </div>
                    <h5 class="fw-bold mb-0 text-gray-800">Student Reports</h5>
                </div>
                <div class="list-group list-group-flush flex-grow-1 mb-3">
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/students')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-primary me-2"></i> Student Demographics
                        </a>
                        <a href="<?= e(url('reports/export/students')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/attendance')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-primary me-2"></i> Student Attendance
                        </a>
                        <a href="<?= e(url('reports/export/attendance')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Staff Reports -->
    <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 h-100 report-card">
            <div class="card-body p-4 d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar bg-success-subtle text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm" style="width: 50px; height: 50px;">
                        <i class="fas fa-chalkboard-teacher fa-lg"></i>
                    </div>
                    <h5 class="fw-bold mb-0 text-gray-800">Staff & HR</h5>
                </div>
                <div class="list-group list-group-flush flex-grow-1 mb-3">
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/staff-attendance')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-success me-2"></i> Staff Attendance
                        </a>
                        <a href="<?= e(url('reports/export/staff-attendance')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/leaves')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-success me-2"></i> Leave History
                        </a>
                        <a href="<?= e(url('reports/export/leaves')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Financial Reports -->
    <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 h-100 report-card">
            <div class="card-body p-4 d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar bg-warning-subtle text-warning rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm" style="width: 50px; height: 50px;">
                        <i class="fas fa-coins text-dark fa-lg"></i>
                    </div>
                    <h5 class="fw-bold mb-0 text-gray-800">Financial Reports</h5>
                </div>
                <div class="list-group list-group-flush flex-grow-1 mb-3">
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/fees')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-warning text-dark me-2"></i> Fee Collection
                        </a>
                        <a href="<?= e(url('reports/export/fees')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/payroll')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-warning text-dark me-2"></i> Payroll History
                        </a>
                        <a href="<?= e(url('reports/export/payroll')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/expenses')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-warning text-dark me-2"></i> Expenses & Ledger
                        </a>
                        <a href="<?= e(url('reports/export/expenses')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-1">
                        <a href="<?= e(url('reports/income-statement')) ?>" class="list-group-item list-group-item-action px-0 border-0 report-link flex-grow-1">
                            <i class="fas fa-angle-right text-warning text-dark me-2"></i> Income vs Expense Statement
                        </a>
                        <a href="<?= e(url('reports/export/income-statement')) ?>" class="btn btn-sm btn-outline-secondary py-0 px-2 small ms-2" title="Export CSV">
                            <i class="fas fa-download" style="font-size: 11px;"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .report-card {
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    }
    .report-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px -10px rgba(0,0,0,0.1) !important;
    }
    
    .report-link {
        transition: all 0.2s ease;
        border-radius: 6px !important;
        padding: 8px 12px !important;
        color: #4b5563;
        font-weight: 500;
    }
    .report-link:hover {
        background-color: #f8fafc;
        transform: translateX(5px);
        color: #0d6efd;
    }
    
    .bg-primary-subtle { background-color: #cfe2ff !important; }
    .bg-success-subtle { background-color: #d1e7dd !important; }
    .bg-warning-subtle { background-color: #fff3cd !important; }
</style>
