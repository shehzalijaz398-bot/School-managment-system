<?php
$title = 'Income vs. Expense Statement';
$d = $data ?? [];
$s = $d['summary'] ?? [
    'total_fees' => 0,
    'payment_count' => 0,
    'total_other_income' => 0,
    'gross_revenue' => 0,
    'total_refunds' => 0,
    'net_revenue' => 0,
    'total_expenses' => 0,
    'net_operating_surplus' => 0,
    'profit_margin_pct' => 0,
    'expense_ratio_pct' => 0,
    'is_profitable' => true,
];
$from = $from ?? date('Y-m-01');
$to = $to ?? date('Y-m-d');
$isProfitable = ($s['is_profitable'] ?? false);
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <a href="<?= e(url('reports')) ?>" class="btn btn-outline-secondary btn-sm p-1 rounded-circle" style="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
        <i data-lucide="arrow-left" style="width: 16px; height: 16px;"></i>
      </a>
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="scale" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Institutional P&amp;L reporting consolidating student fee inflows, ancillary revenues, verified refunds, and operating expenditures.
    </p>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= e(url('reports/export/income-statement?from=' . urlencode($from) . '&to=' . urlencode($to))) ?>" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1 shadow-sm">
      <i data-lucide="download" style="width: 14px; height: 14px;"></i> Export Statement CSV
    </a>
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1 shadow-sm">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Statement
    </button>
  </div>
</div>

<!-- Date Filter Form -->
<div class="card border-0 shadow-sm rounded-4 mb-4 p-3 bg-white">
  <form method="GET" action="<?= e(url('reports/income-statement')) ?>" class="row g-2 align-items-end">
    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">From Date</label>
      <input type="date" name="from" class="form-control form-control-sm" value="<?= e($from) ?>">
    </div>
    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">To Date</label>
      <input type="date" name="to" class="form-control form-control-sm" value="<?= e($to) ?>">
    </div>
    <div class="col-md-4 col-sm-12 d-flex gap-2">
      <button type="submit" class="btn btn-primary btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-1">
        <i data-lucide="filter" style="width: 14px; height: 14px;"></i> Generate Statement
      </button>
      <a href="<?= e(url('reports/income-statement')) ?>" class="btn btn-light btn-sm text-muted">
        Reset
      </a>
    </div>
  </form>
</div>

<!-- Executive KPI Summary Cards -->
<div class="row g-3 mb-4">
  <!-- Gross Revenue -->
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span class="text-muted small fw-semibold text-uppercase" style="letter-spacing: 0.5px; font-size: 0.72rem;">Gross Revenue</span>
        <div class="rounded-circle p-2 bg-primary-subtle text-primary">
          <i data-lucide="wallet" style="width: 16px; height: 16px;"></i>
        </div>
      </div>
      <h3 class="fw-bold mb-1 text-dark" style="font-size: 1.5rem;">$<?= number_format((float) $s['gross_revenue'], 2) ?></h3>
      <div class="d-flex justify-content-between text-muted small" style="font-size: 0.78rem;">
        <span>Fees: $<?= number_format((float) $s['total_fees'], 2) ?></span>
        <span>Other: $<?= number_format((float) $s['total_other_income'], 2) ?></span>
      </div>
    </div>
  </div>

  <!-- Refunds Issued -->
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span class="text-muted small fw-semibold text-uppercase" style="letter-spacing: 0.5px; font-size: 0.72rem;">Refunds Issued</span>
        <div class="rounded-circle p-2 bg-warning-subtle text-warning">
          <i data-lucide="rotate-ccw" style="width: 16px; height: 16px;"></i>
        </div>
      </div>
      <h3 class="fw-bold mb-1 text-dark" style="font-size: 1.5rem;">$<?= number_format((float) $s['total_refunds'], 2) ?></h3>
      <div class="d-flex justify-content-between text-muted small" style="font-size: 0.78rem;">
        <span>Net Revenue:</span>
        <span class="fw-semibold text-primary">$<?= number_format((float) $s['net_revenue'], 2) ?></span>
      </div>
    </div>
  </div>

  <!-- Operating Expenses -->
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span class="text-muted small fw-semibold text-uppercase" style="letter-spacing: 0.5px; font-size: 0.72rem;">Operating Expenses</span>
        <div class="rounded-circle p-2 bg-danger-subtle text-danger">
          <i data-lucide="trending-down" style="width: 16px; height: 16px;"></i>
        </div>
      </div>
      <h3 class="fw-bold mb-1 text-danger" style="font-size: 1.5rem;">$<?= number_format((float) $s['total_expenses'], 2) ?></h3>
      <div class="d-flex justify-content-between text-muted small" style="font-size: 0.78rem;">
        <span>Expense Ratio:</span>
        <span class="fw-semibold text-danger"><?= $s['expense_ratio_pct'] ?>%</span>
      </div>
    </div>
  </div>

  <!-- Net Operating Surplus / Margin -->
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-3 h-100 <?= $isProfitable ? 'bg-success text-white' : 'bg-danger text-white' ?>">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span class="small fw-semibold text-uppercase opacity-75" style="letter-spacing: 0.5px; font-size: 0.72rem;">Net Operating Balance</span>
        <div class="rounded-circle p-2 bg-white bg-opacity-25 text-white">
          <i data-lucide="<?= $isProfitable ? 'trending-up' : 'alert-circle' ?>" style="width: 16px; height: 16px;"></i>
        </div>
      </div>
      <h3 class="fw-bold mb-1" style="font-size: 1.5rem;">
        <?= $s['net_operating_surplus'] >= 0 ? '$' : '-$' ?><?= number_format(abs((float) $s['net_operating_surplus']), 2) ?>
      </h3>
      <div class="d-flex justify-content-between small opacity-90" style="font-size: 0.78rem;">
        <span>Profit Margin:</span>
        <span class="fw-bold"><?= $s['profit_margin_pct'] ?>%</span>
      </div>
    </div>
  </div>
</div>

<!-- Categorical Breakdowns Grid -->
<div class="row g-4 mb-4">
  <!-- Revenue Breakdown -->
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
      <div class="card-header bg-white border-0 pt-4 px-4 pb-0 d-flex justify-content-between align-items-center">
        <div>
          <h5 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
            <i data-lucide="pie-chart" class="text-primary" style="width: 18px; height: 18px;"></i> Revenue Sources
          </h5>
          <span class="text-muted small">Inflow breakdown across fee types and other incomes</span>
        </div>
        <span class="badge bg-success-subtle text-success rounded-pill px-3 py-1 fw-bold">
          $<?= number_format((float) $s['gross_revenue'], 2) ?> Total
        </span>
      </div>
      <div class="card-body p-4">
        <?php if (empty($d['incomes_by_category'])): ?>
          <div class="text-center py-4 text-muted">
            <i data-lucide="receipt" style="width: 36px; height: 36px; opacity: 0.3;" class="mb-2"></i>
            <p class="mb-0 small">No income recorded for this period.</p>
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="bg-light text-muted small text-uppercase">
                <tr>
                  <th class="border-0">Category</th>
                  <th class="border-0 text-end">Amount</th>
                  <th class="border-0 text-end">Share %</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $gross = (float) $s['gross_revenue'] ?: 1.0;
                foreach ($d['incomes_by_category'] as $cat => $amt): 
                  $share = round(($amt / $gross) * 100, 1);
                ?>
                <tr>
                  <td class="fw-medium text-dark">
                    <i data-lucide="arrow-down-right" class="text-success me-1" style="width: 14px; height: 14px;"></i>
                    <?= e($cat) ?>
                  </td>
                  <td class="text-end fw-bold text-dark">$<?= number_format((float) $amt, 2) ?></td>
                  <td class="text-end">
                    <span class="badge bg-light text-dark border"><?= $share ?>%</span>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Expense Breakdown -->
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
      <div class="card-header bg-white border-0 pt-4 px-4 pb-0 d-flex justify-content-between align-items-center">
        <div>
          <h5 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
            <i data-lucide="layers" class="text-danger" style="width: 18px; height: 18px;"></i> Expense Allocations
          </h5>
          <span class="text-muted small">Outflow breakdown by expenditure category</span>
        </div>
        <span class="badge bg-danger-subtle text-danger rounded-pill px-3 py-1 fw-bold">
          $<?= number_format((float) $s['total_expenses'], 2) ?> Total
        </span>
      </div>
      <div class="card-body p-4">
        <?php if (empty($d['expenses_by_category'])): ?>
          <div class="text-center py-4 text-muted">
            <i data-lucide="check-circle" style="width: 36px; height: 36px; opacity: 0.3;" class="mb-2"></i>
            <p class="mb-0 small">No expenses logged for this period.</p>
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="bg-light text-muted small text-uppercase">
                <tr>
                  <th class="border-0">Category</th>
                  <th class="border-0 text-end">Amount</th>
                  <th class="border-0 text-end">Share %</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $totExp = (float) $s['total_expenses'] ?: 1.0;
                foreach ($d['expenses_by_category'] as $cat => $amt): 
                  $share = round(($amt / $totExp) * 100, 1);
                ?>
                <tr>
                  <td class="fw-medium text-dark">
                    <i data-lucide="arrow-up-right" class="text-danger me-1" style="width: 14px; height: 14px;"></i>
                    <?= e($cat) ?>
                  </td>
                  <td class="text-end fw-bold text-danger">$<?= number_format((float) $amt, 2) ?></td>
                  <td class="text-end">
                    <span class="badge bg-light text-dark border"><?= $share ?>%</span>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Detailed Operating Expenses Ledger -->
<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
  <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
    <div>
      <h5 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
        <i data-lucide="file-text" class="text-secondary" style="width: 18px; height: 18px;"></i>
        Detailed Expense Transactions
      </h5>
      <span class="text-muted small">Itemized ledger of operational disbursements within selected timeframe</span>
    </div>
    <span class="badge bg-light text-dark border"><?= count($d['expenses'] ?? []) ?> Records</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="bg-light text-muted small text-uppercase">
          <tr>
            <th class="ps-4">Date</th>
            <th>Title &amp; Reference</th>
            <th>Category</th>
            <th>Payment Method</th>
            <th class="pe-4 text-end">Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($d['expenses'])): ?>
            <tr>
              <td colspan="5" class="text-center py-4 text-muted small">
                No expense entries found for the selected date range.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($d['expenses'] as $exp): ?>
              <tr>
                <td class="ps-4 text-muted small"><?= e($exp['expense_date']) ?></td>
                <td>
                  <div class="fw-bold text-dark"><?= e($exp['title']) ?></div>
                  <?php if (!empty($exp['reference_no'])): ?>
                    <div class="text-muted small">Ref: <?= e($exp['reference_no']) ?></div>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge bg-light text-dark border"><?= e($exp['category']) ?></span>
                </td>
                <td>
                  <span class="badge bg-secondary-subtle text-secondary"><?= strtoupper(e($exp['payment_method'] ?? 'N/A')) ?></span>
                </td>
                <td class="pe-4 text-end fw-bold text-danger">
                  $<?= number_format((float) $exp['amount'], 2) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
