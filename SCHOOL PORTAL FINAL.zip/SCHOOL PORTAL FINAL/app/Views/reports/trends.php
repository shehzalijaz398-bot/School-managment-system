<?php
$title = 'Historical Trends & MoM Analytics';
$series = $trends['series'] ?? [];
$comparisons = $trends['comparisons'] ?? [];
$currMonth = $trends['current_month'] ?? null;
$prevMonth = $trends['previous_month'] ?? null;
$months = $months ?? 6;

// Compute chart scaling
$maxRev = 100.0;
foreach ($series as $s) {
    if ($s['revenue'] > $maxRev) $maxRev = $s['revenue'];
    if ($s['invoiced'] > $maxRev) $maxRev = $s['invoiced'];
    if ($s['expense'] > $maxRev) $maxRev = $s['expense'];
}
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="trending-up" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Data Intelligence
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Institutional performance tracking, Month-over-Month (MoM) variance analysis, and cash flow velocity.
    </p>
  </div>
  <div class="d-flex gap-2">
    <div class="btn-group btn-group-sm" role="group">
      <a href="<?= e(url('reports/trends?months=3')) ?>" class="btn <?= $months === 3 ? 'btn-primary' : 'btn-outline-primary' ?>">3M</a>
      <a href="<?= e(url('reports/trends?months=6')) ?>" class="btn <?= $months === 6 ? 'btn-primary' : 'btn-outline-primary' ?>">6M</a>
      <a href="<?= e(url('reports/trends?months=12')) ?>" class="btn <?= $months === 12 ? 'btn-primary' : 'btn-outline-primary' ?>">12M</a>
    </div>
    <a href="<?= e(url('reports/executive')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="file-text" style="width: 14px; height: 14px;"></i> Executive Brief
    </a>
    <button onclick="window.print()" class="btn btn-outline-dark btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print
    </button>
  </div>
</div>

<!-- Month-over-Month (MoM) Variance KPI Row -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Revenue Velocity (MoM)</div>
          <div class="fs-4 fw-bold <?= $comparisons['revenue_growth']['diff'] >= 0 ? 'text-success' : 'text-danger' ?>">
            <?= $comparisons['revenue_growth']['diff'] >= 0 ? '+' : '' ?><?= $comparisons['revenue_growth']['percent'] ?>%
          </div>
          <div class="text-muted" style="font-size: 11px;">
            <?= $comparisons['revenue_growth']['diff'] >= 0 ? '+$' : '-$' ?><?= number_format(abs($comparisons['revenue_growth']['diff']), 2) ?> vs last mo
          </div>
        </div>
        <div class="rounded-3 p-2 <?= $comparisons['revenue_growth']['diff'] >= 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?>">
          <i data-lucide="<?= $comparisons['revenue_growth']['diff'] >= 0 ? 'arrow-up-right' : 'arrow-down-right' ?>" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Operating Expenses (MoM)</div>
          <div class="fs-4 fw-bold <?= $comparisons['expense_growth']['diff'] <= 0 ? 'text-success' : 'text-danger' ?>">
            <?= $comparisons['expense_growth']['diff'] >= 0 ? '+' : '' ?><?= $comparisons['expense_growth']['percent'] ?>%
          </div>
          <div class="text-muted" style="font-size: 11px;">
            <?= $comparisons['expense_growth']['diff'] >= 0 ? '+$' : '-$' ?><?= number_format(abs($comparisons['expense_growth']['diff']), 2) ?> variance
          </div>
        </div>
        <div class="rounded-3 p-2 <?= $comparisons['expense_growth']['diff'] <= 0 ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning' ?>">
          <i data-lucide="credit-card" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Student Attendance Variance</div>
          <div class="fs-4 fw-bold <?= $comparisons['attendance_diff'] >= 0 ? 'text-primary' : 'text-warning' ?>">
            <?= $comparisons['attendance_diff'] >= 0 ? '+' : '' ?><?= $comparisons['attendance_diff'] ?>%
          </div>
          <div class="text-muted" style="font-size: 11px;">
            Current: <?= $currMonth['student_attendance_rate'] ?? 0 ?>%
          </div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="user-check" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">New Admissions (MoM)</div>
          <div class="fs-4 fw-bold text-dark">
            <?= (int) ($currMonth['new_admissions'] ?? 0) ?>
          </div>
          <div class="text-muted" style="font-size: 11px;">
            <?= $comparisons['admissions_diff'] >= 0 ? '+' : '' ?><?= $comparisons['admissions_diff'] ?> vs previous mo
          </div>
        </div>
        <div class="rounded-3 p-2 bg-info-subtle text-info">
          <i data-lucide="user-plus" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Visual Trend Comparison Chart -->
<div class="row g-3 mb-4">
  <div class="col-12">
    <div class="card border-0 shadow-sm rounded-3 p-4 bg-white">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3 gap-2">
        <div>
          <h5 class="fw-bold mb-1 text-dark fs-6 d-flex align-items-center gap-2">
            <i data-lucide="bar-chart-3" class="text-primary" style="width: 18px; height: 18px;"></i>
            Revenue vs Invoiced Collections vs Operating Expenses
          </h5>
          <div class="text-muted small">Chronological <?= $months ?>-month comparison matrix</div>
        </div>
        <div class="d-flex gap-3 small">
          <span class="d-flex align-items-center gap-1 text-muted">
            <span class="d-inline-block rounded-circle" style="width: 10px; height: 10px; background-color: #2563eb;"></span> Collected
          </span>
          <span class="d-flex align-items-center gap-1 text-muted">
            <span class="d-inline-block rounded-circle" style="width: 10px; height: 10px; background-color: #93c5fd;"></span> Invoiced
          </span>
          <span class="d-flex align-items-center gap-1 text-muted">
            <span class="d-inline-block rounded-circle" style="width: 10px; height: 10px; background-color: #ef4444;"></span> Expenses
          </span>
        </div>
      </div>

      <!-- Pure SVG High-DPI Responsive Bar Chart -->
      <div style="width: 100%; height: 240px; position: relative;">
        <svg viewBox="0 0 1000 240" preserveAspectRatio="none" style="width: 100%; height: 100%;">
          <!-- Background Grid Lines -->
          <line x1="60" y1="20" x2="980" y2="20" stroke="#f1f5f9" stroke-width="1" />
          <line x1="60" y1="80" x2="980" y2="80" stroke="#f1f5f9" stroke-width="1" />
          <line x1="60" y1="140" x2="980" y2="140" stroke="#f1f5f9" stroke-width="1" />
          <line x1="60" y1="200" x2="980" y2="200" stroke="#e2e8f0" stroke-width="1.5" />

          <!-- Y-Axis Labels -->
          <text x="50" y="24" fill="#94a3b8" font-size="10" text-anchor="end"><?= number_format($maxRev) ?></text>
          <text x="50" y="114" fill="#94a3b8" font-size="10" text-anchor="end"><?= number_format($maxRev / 2) ?></text>
          <text x="50" y="204" fill="#94a3b8" font-size="10" text-anchor="end">0</text>

          <?php
            $count = count($series);
            $usableWidth = 920;
            $slotWidth = $count > 0 ? ($usableWidth / $count) : $usableWidth;
            $barWidth = min(28, $slotWidth * 0.22);
          ?>

          <?php foreach ($series as $idx => $s): ?>
            <?php
              $xCenter = 60 + ($idx * $slotWidth) + ($slotWidth / 2);
              $revHeight = $maxRev > 0 ? (($s['revenue'] / $maxRev) * 180) : 0;
              $invHeight = $maxRev > 0 ? (($s['invoiced'] / $maxRev) * 180) : 0;
              $expHeight = $maxRev > 0 ? (($s['expense'] / $maxRev) * 180) : 0;
            ?>
            <!-- Invoiced Bar -->
            <rect x="<?= $xCenter - $barWidth - ($barWidth / 2) ?>" y="<?= 200 - $invHeight ?>" width="<?= $barWidth ?>" height="<?= $invHeight ?>" fill="#93c5fd" rx="3" opacity="0.8" />
            <!-- Revenue Bar -->
            <rect x="<?= $xCenter - ($barWidth / 2) ?>" y="<?= 200 - $revHeight ?>" width="<?= $barWidth ?>" height="<?= $revHeight ?>" fill="#2563eb" rx="3" />
            <!-- Expense Bar -->
            <rect x="<?= $xCenter + ($barWidth / 2) ?>" y="<?= 200 - $expHeight ?>" width="<?= $barWidth ?>" height="<?= $expHeight ?>" fill="#ef4444" rx="3" opacity="0.85" />

            <!-- Month Label -->
            <text x="<?= $xCenter ?>" y="222" fill="#64748b" font-size="11" font-weight="600" text-anchor="middle">
              <?= e($s['short_key']) ?>
            </text>
          <?php endforeach; ?>
        </svg>
      </div>
    </div>
  </div>
</div>

<!-- Ledger Breakdown Table -->
<div class="row g-3">
  <div class="col-12">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <h5 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="table" class="text-primary" style="width: 18px; height: 18px;"></i>
          Monthly Ledger & Operational Efficiency Breakdown
        </h5>
        <span class="text-muted small">All Financial Amounts in Tenant Currency</span>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr class="text-muted small text-uppercase" style="font-size: 11px;">
                <th class="ps-3">Month</th>
                <th class="text-end">Invoiced</th>
                <th class="text-end">Collected</th>
                <th class="text-center">Collection Efficiency</th>
                <th class="text-end">Expenses</th>
                <th class="text-end">Net Operating Balance</th>
                <th class="text-center">Student Attendance</th>
                <th class="text-center pe-3">Staff Attendance</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($series as $s): ?>
                <tr>
                  <td class="ps-3 py-3 fw-bold text-dark">
                    <?= e($s['month_key']) ?>
                  </td>
                  <td class="text-end font-monospace">
                    <?= number_format($s['invoiced'], 2) ?>
                  </td>
                  <td class="text-end font-monospace text-primary fw-semibold">
                    <?= number_format($s['revenue'], 2) ?>
                  </td>
                  <td class="text-center">
                    <span class="badge <?= $s['collection_efficiency'] >= 80 ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning' ?> px-2 py-1 rounded-pill small">
                      <?= $s['collection_efficiency'] ?>%
                    </span>
                  </td>
                  <td class="text-end font-monospace text-danger">
                    <?= number_format($s['expense'], 2) ?>
                  </td>
                  <td class="text-end font-monospace fw-bold <?= $s['net_operating'] >= 0 ? 'text-success' : 'text-danger' ?>">
                    <?= $s['net_operating'] >= 0 ? '+' : '' ?><?= number_format($s['net_operating'], 2) ?>
                  </td>
                  <td class="text-center">
                    <span class="small fw-semibold text-dark"><?= $s['student_attendance_rate'] ?>%</span>
                  </td>
                  <td class="text-center pe-3">
                    <span class="small fw-semibold text-dark"><?= $s['staff_attendance_rate'] ?>%</span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
