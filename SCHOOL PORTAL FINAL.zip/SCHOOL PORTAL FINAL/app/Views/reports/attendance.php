<div class="panel no-print"><form class="row g-2 mb-3" method="get">
  <div class="col-auto"><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div>
  <div class="col-auto"><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div>
  <div class="col-auto"><select name="class_id" class="form-select"><option value="">All classes</option><?php foreach ($classes as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$classId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
  <div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div>
  <div class="col-auto"><button type="button" class="btn btn-primary" onclick="window.print()">Print</button></div>
</form></div>
<div class="panel"><h2>Attendance Report</h2>
<table class="table table-sm"><thead><tr><th>Date</th><th>Student</th><th>Class</th><th>Status</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e(formatDate($r['attendance_date'])) ?></td><td><?= e($r['student_name']) ?></td><td><?= e($r['class_name'].' '.$r['section_name']) ?></td><td><?= statusBadge($r['status']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
