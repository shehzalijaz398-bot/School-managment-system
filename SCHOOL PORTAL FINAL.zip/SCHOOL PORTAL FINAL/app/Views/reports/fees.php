<div class="panel no-print"><form class="row g-2 mb-3"><div class="col-auto"><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div><div class="col-auto"><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div><div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div><div class="col-auto"><button type="button" onclick="window.print()" class="btn btn-primary">Print</button></div></form></div>
<div class="panel"><h2>Fee Collection Report</h2>
<table class="table"><thead><tr><th>Date</th><th>Receipt</th><th>Student</th><th>Amount</th><th>Method</th></tr></thead><tbody>
<?php $total=0; foreach ($rows as $r): $total += (float)$r['amount']; ?>
<tr><td><?= e(formatDate($r['payment_date'])) ?></td><td><?= e($r['receipt_no']) ?></td><td><?= e($r['student_name']) ?></td><td><?= e(formatMoney($r['amount'])) ?></td><td><?= e($r['payment_method']) ?></td></tr>
<?php endforeach; ?>
</tbody><tfoot><tr><th colspan="3">Total</th><th><?= e(formatMoney($total)) ?></th><th></th></tr></tfoot></table>
</div>
