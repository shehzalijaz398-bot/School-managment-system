<div class="panel mb-3">
  <form class="row g-2 align-items-center" method="get">
    <div class="col-auto"><input type="date" name="from" class="form-control" value="<?= e($from) ?>"></div>
    <div class="col-auto"><input type="date" name="to" class="form-control" value="<?= e($to) ?>"></div>
    <div class="col-auto"><button class="btn btn-primary">Filter</button></div>
    <div class="col-auto ms-auto"><button type="button" class="btn btn-outline-secondary" onclick="window.print()">Print</button></div>
  </form>
</div>
<div class="panel">
  <h2><?= e($title) ?></h2>
  <div class="table-responsive">
    <table class="table table-sm table-striped">
      <thead><tr><th>Date</th><th>Employee Name</th><th>Status</th><th>Remarks</th></tr></thead>
      <tbody>
      <?php if(empty($rows)): ?>
        <tr><td colspan="4" class="text-center">No records found.</td></tr>
      <?php else: ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e(formatDate($r['attendance_date'])) ?></td>
            <td><?= e($r['employee_name']) ?></td>
            <td><?= statusBadge($r['status']) ?></td>
            <td><?= e($r['remarks']) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
