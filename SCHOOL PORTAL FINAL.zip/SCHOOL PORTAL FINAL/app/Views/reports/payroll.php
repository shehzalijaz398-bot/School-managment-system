<div class="panel no-print"><form class="row g-2 mb-3" method="get"><div class="col-auto"><input type="month" name="month" value="<?= e($month) ?>" class="form-control"></div><div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div><div class="col-auto"><button type="button" class="btn btn-primary" onclick="window.print()">Print</button></div></form></div>
<div class="panel"><h2>Payroll Report — <?= e($month) ?></h2>
<table class="table"><thead><tr><th>Employee</th><th>Basic</th><th>Allowances</th><th>Deductions</th><th>Net</th><th>Status</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e($r['employee_name']) ?></td><td><?= e(formatMoney($r['basic_salary'])) ?></td><td><?= e(formatMoney($r['allowances'])) ?></td><td><?= e(formatMoney($r['deductions'])) ?></td><td><?= e(formatMoney($r['net_salary'])) ?></td><td><?= statusBadge($r['status']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
