<div class="panel no-print"><form class="row g-2 mb-3" method="get"><div class="col-auto"><input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div><div class="col-auto"><input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div><div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div><div class="col-auto"><button type="button" class="btn btn-primary" onclick="window.print()">Print</button></div></form></div>
<div class="panel"><h2>Expense Report</h2>
<table class="table"><thead><tr><th>Date</th><th>Title</th><th>Category</th><th>Amount</th></tr></thead><tbody>
<?php $t=0; foreach ($rows as $r): $t+=(float)$r['amount']; ?><tr><td><?= e(formatDate($r['expense_date'])) ?></td><td><?= e($r['title']) ?></td><td><?= e($r['category']) ?></td><td><?= e(formatMoney($r['amount'])) ?></td></tr><?php endforeach; ?>
</tbody><tfoot><tr><th colspan="3">Total</th><th><?= e(formatMoney($t)) ?></th></tr></tfoot></table></div>
