<div class="panel mb-3">
  <form class="row g-2 align-items-center" method="get">
    <div class="col-auto">
      <select name="class_id" class="form-select">
        <option value="">All Classes</option>
        <?php foreach ($classes as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= $classId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-auto"><button class="btn btn-primary">Filter</button></div>
    <div class="col-auto ms-auto"><button type="button" class="btn btn-outline-secondary" onclick="window.print()">Print</button></div>
  </form>
</div>
<div class="panel">
  <h2><?= e($title) ?></h2>
  <div class="table-responsive">
    <table class="table table-sm table-striped">
      <thead><tr><th>Admission No</th><th>Student Name</th><th>Gender</th><th>DOB</th><th>Class</th><th>Section</th></tr></thead>
      <tbody>
      <?php if(empty($rows)): ?>
        <tr><td colspan="6" class="text-center">No records found.</td></tr>
      <?php else: ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e($r['admission_no']) ?></td>
            <td><?= e($r['student_name']) ?></td>
            <td><?= e(ucfirst($r['gender'] ?? '')) ?></td>
            <td><?= $r['date_of_birth'] ? e(formatDate($r['date_of_birth'])) : '-' ?></td>
            <td><?= e($r['class_name'] ?? 'Unassigned') ?></td>
            <td><?= e($r['section_name'] ?? 'Unassigned') ?></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
