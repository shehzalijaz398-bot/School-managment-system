<?php
$title = 'Executive Analytics & Cross-Module Summary';
$s = $summary ?? [];
$from = $from ?? date('Y-m-01');
$to = $to ?? date('Y-m-d');
$netBalance = (float) ($s['net_operating_balance'] ?? 0);
$isNetPositive = $netBalance >= 0;
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <a href="<?= e(url('reports')) ?>" class="btn btn-outline-secondary btn-sm p-1 rounded-circle" style="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
        <i data-lucide="arrow-left" style="width: 16px; height: 16px;"></i>
      </a>
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="bar-chart-2" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Institutional cross-module intelligence consolidating financials, attendance velocity, and operational capacity.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="printer" style="width: 14px; height: 14px;"></i> Print Brief
    </button>
  </div>
</div>

<!-- Date Filter Form -->
<div class="card border-0 shadow-sm rounded-4 mb-4 p-3 bg-white">
  <form method="GET" action="<?= e(url('reports/executive')) ?>" class="row g-2 align-items-end">
    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">From Date</label>
      <input type="date" name="from" class="form-control form-control-sm" value="<?= e($from) ?>">
    </div>
    <div class="col-md-4 col-sm-6">
      <label class="form-label small fw-semibold text-muted mb-1">To Date</label>
      <input type="date" name="to" class="form-control form-control-sm" value="<?= e($to) ?>">
    </div>
    <div class="col-md-4 col-sm-12 d-flex gap-2">
      <button type="submit" class="btn btn-primary btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-1">
        <i data-lucide="filter" style="width: 14px; height: 14px;"></i> Apply Filter
      </button>
      <a href="<?= e(url('reports/executive')) ?>" class="btn btn-light btn-sm text-secondary">
        Reset
      </a>
    </div>
  </form>
</div>

<!-- Executive Metric Matrix -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Fee Collections</div>
      <div class="fs-4 fw-bold text-success mt-1"><?= formatMoney((float)($s['fee_collected'] ?? 0)) ?></div>
      <div class="text-muted small" style="font-size: 11px;">
        <?= (int)($s['payment_count'] ?? 0) ?> Payments Received
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Operating Expenses</div>
      <div class="fs-4 fw-bold text-danger mt-1"><?= formatMoney((float)($s['expenses_total'] ?? 0)) ?></div>
      <div class="text-muted small" style="font-size: 11px;">
        <?= (int)($s['expense_count'] ?? 0) ?> Recorded Vouchers
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Net Cash Balance</div>
      <div class="fs-4 fw-bold <?= $isNetPositive ? 'text-primary' : 'text-danger' ?> mt-1">
        <?= formatMoney($netBalance) ?>
      </div>
      <div class="small fw-semibold <?= $isNetPositive ? 'text-success' : 'text-danger' ?>" style="font-size: 11px;">
        <?= $isNetPositive ? 'Operating Surplus' : 'Operating Deficit' ?>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100">
      <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Overdue Receivables</div>
      <div class="fs-4 fw-bold text-warning-emphasis mt-1"><?= formatMoney((float)($s['outstanding_total'] ?? 0)) ?></div>
      <div class="text-muted small" style="font-size: 11px;">
        <?= (int)($s['overdue_invoices_count'] ?? 0) ?> Unpaid / Partial Invoices
      </div>
    </div>
  </div>
</div>

<!-- Secondary Operational Index -->
<div class="row g-4 mb-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white h-100">
      <h5 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
        <i data-lucide="users" class="text-primary" style="width: 20px; height: 20px;"></i>
        Attendance Velocity & Consistency
      </h5>
      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-1">
          <span class="small fw-semibold text-secondary">Student Body Attendance Rate</span>
          <span class="small fw-bold text-dark"><?= $s['student_attendance_rate'] ?>%</span>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $s['student_attendance_rate'] ?>%"></div>
        </div>
        <div class="text-muted mt-1" style="font-size: 11px;">Calculated across all recorded classroom attendance entries.</div>
      </div>
      <div>
        <div class="d-flex justify-content-between align-items-center mb-1">
          <span class="small fw-semibold text-secondary">Faculty & Staff Presence Rate</span>
          <span class="small fw-bold text-dark"><?= $s['staff_attendance_rate'] ?>%</span>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar bg-success" role="progressbar" style="width: <?= $s['staff_attendance_rate'] ?>%"></div>
        </div>
        <div class="text-muted mt-1" style="font-size: 11px;">Institutional presence rate across academic and administrative departments.</div>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white h-100">
      <h5 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
        <i data-lucide="layers" class="text-success" style="width: 20px; height: 20px;"></i>
        Institutional Operational Capacity
      </h5>
      <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
        <span class="text-secondary small">Active Enrolled Students</span>
        <span class="fw-bold text-dark fs-6"><?= (int)($s['active_students'] ?? 0) ?></span>
      </div>
      <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
        <span class="text-secondary small">Active Faculty & Staff</span>
        <span class="fw-bold text-dark fs-6"><?= (int)($s['active_staff'] ?? 0) ?></span>
      </div>
      <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
        <span class="text-secondary small">Student-to-Teacher Ratio</span>
        <span class="fw-bold text-primary fs-6">
          <?= !empty($s['active_staff']) ? round((int)$s['active_students'] / (int)$s['active_staff'], 1) . ' : 1' : 'N/A' ?>
        </span>
      </div>
      <div class="d-flex justify-content-between align-items-center py-2">
        <span class="text-secondary small">Financial Health Ratio</span>
        <span class="badge <?= $isNetPositive ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger' ?> px-2 py-1">
          <?= $isNetPositive ? 'Solvent' : 'Monitoring' ?>
        </span>
      </div>
    </div>
  </div>
</div>

<!-- Quick Export Bar -->
<div class="card border-0 shadow-sm rounded-4 p-3 bg-light">
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
      <h6 class="fw-bold text-dark mb-0">Detailed Module CSV Exports</h6>
      <span class="text-muted small">Download raw audit-ready data tables for the current period (<?= e($from) ?> to <?= e($to) ?>)</span>
    </div>
    <div class="d-flex flex-wrap gap-2">
      <a href="<?= e(url("reports/export/fees?from={$from}&to={$to}")) ?>" class="btn btn-outline-secondary btn-sm">
        <i data-lucide="download" style="width: 12px; height: 12px;"></i> Fees
      </a>
      <a href="<?= e(url("reports/export/expenses?from={$from}&to={$to}")) ?>" class="btn btn-outline-secondary btn-sm">
        <i data-lucide="download" style="width: 12px; height: 12px;"></i> Expenses
      </a>
      <a href="<?= e(url("reports/export/attendance?from={$from}&to={$to}")) ?>" class="btn btn-outline-secondary btn-sm">
        <i data-lucide="download" style="width: 12px; height: 12px;"></i> Attendance
      </a>
      <a href="<?= e(url("reports/export/staff-attendance?from={$from}&to={$to}")) ?>" class="btn btn-outline-secondary btn-sm">
        <i data-lucide="download" style="width: 12px; height: 12px;"></i> Staff
      </a>
      <a href="<?= e(url("reports/export/leaves?from={$from}&to={$to}")) ?>" class="btn btn-outline-secondary btn-sm">
        <i data-lucide="download" style="width: 12px; height: 12px;"></i> Leaves
      </a>
    </div>
  </div>
</div>
