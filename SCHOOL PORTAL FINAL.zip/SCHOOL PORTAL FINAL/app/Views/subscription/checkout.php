<div class="container py-4" style="max-width: 960px;">
  <div class="mb-4">
    <a href="<?= e(url('subscription/plans')) ?>" class="text-decoration-none text-muted small fw-semibold">
      &larr; Back to all plans
    </a>
    <h1 class="h3 fw-bold text-dark mt-2 mb-1">Confirm Subscription Order</h1>
    <p class="text-muted small mb-0">Review your selected institutional tier, choose your billing interval, and initiate your subscription.</p>
  </div>

  <form method="post" action="<?= e(url('subscription/checkout')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="plan_id" value="<?= (int) $plan['id'] ?>">

    <div class="row g-4">
      <div class="col-lg-7">
        <!-- Plan details -->
        <div class="card border-0 shadow-sm rounded-4 mb-4">
          <div class="card-body p-4">
            <h5 class="fw-bold text-dark mb-3">1. Select Billing Interval</h5>

            <div class="row g-3 mb-4">
              <div class="col-sm-6">
                <label class="card p-3 border rounded-3 h-100 cursor-pointer interval-card" style="cursor: pointer;">
                  <div class="d-flex align-items-center gap-2 mb-1">
                    <input type="radio" name="billing_cycle" value="monthly" checked class="form-check-input" onchange="updateTotal('monthly')">
                    <span class="fw-bold text-dark">Monthly Billing</span>
                  </div>
                  <div class="text-muted small ps-4">
                    PKR <?= number_format((float) $plan['monthly_price'], 0) ?> billed every month
                  </div>
                </label>
              </div>

              <div class="col-sm-6">
                <label class="card p-3 border rounded-3 h-100 cursor-pointer interval-card" style="cursor: pointer;">
                  <div class="d-flex align-items-center gap-2 mb-1">
                    <input type="radio" name="billing_cycle" value="annual" class="form-check-input" onchange="updateTotal('annual')">
                    <span class="fw-bold text-dark">Annual Billing</span>
                    <span class="badge bg-success-subtle text-success small">Save ~15%</span>
                  </div>
                  <div class="text-muted small ps-4">
                    PKR <?= number_format((float) ($plan['annual_price'] ?? ($plan['monthly_price'] * 12)), 0) ?> billed annually
                  </div>
                </label>
              </div>
            </div>

            <h5 class="fw-bold text-dark mb-3">2. Payment Method</h5>

            <div class="d-flex flex-column gap-2 mb-4">
              <label class="p-3 border rounded-3 d-flex align-items-center justify-content-between" style="cursor: pointer;">
                <div class="d-flex align-items-center gap-3">
                  <input type="radio" name="payment_method" value="bank_transfer" checked class="form-check-input">
                  <div>
                    <span class="fw-bold text-dark d-block">Direct Bank Transfer / IBAN</span>
                    <span class="text-muted small">Transfer directly to our designated corporate banking account</span>
                  </div>
                </div>
                <i class="bi bi-bank2 fs-4 text-secondary"></i>
              </label>

              <label class="p-3 border rounded-3 d-flex align-items-center justify-content-between" style="cursor: pointer;">
                <div class="d-flex align-items-center gap-3">
                  <input type="radio" name="payment_method" value="raast_easypaisa" class="form-check-input">
                  <div>
                    <span class="fw-bold text-dark d-block">Raast / JazzCash / EasyPaisa</span>
                    <span class="text-muted small">Fast digital payment via Raast Instant or Mobile Wallets</span>
                  </div>
                </div>
                <i class="bi bi-phone-fill fs-4 text-secondary"></i>
              </label>

              <label class="p-3 border rounded-3 d-flex align-items-center justify-content-between" style="cursor: pointer;">
                <div class="d-flex align-items-center gap-3">
                  <input type="radio" name="payment_method" value="corporate_cheque" class="form-check-input">
                  <div>
                    <span class="fw-bold text-dark d-block">Corporate Pay Order / Cheque</span>
                    <span class="text-muted small">Issue a cross-cheque payable to the platform operator</span>
                  </div>
                </div>
                <i class="bi bi-file-earmark-text-fill fs-4 text-secondary"></i>
              </label>
            </div>

            <div class="p-3 rounded-3 bg-light border mb-4">
              <h6 class="fw-bold text-dark small mb-2"><i class="bi bi-info-circle-fill text-primary me-1"></i> Official Platform Settlement Account</h6>
              <div class="small text-muted">
                <div><strong>Bank Name:</strong> Habib Bank Limited (HBL) / Meezan Bank</div>
                <div><strong>Account Title:</strong> CodeClove Technologies (Pvt) Ltd - SaaS Operations</div>
                <div><strong>IBAN:</strong> PK36MEZN0001000123456789</div>
                <div><strong>Raast ID:</strong> 03001234567</div>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label fw-semibold small text-dark">Transaction / Deposit Reference (Optional)</label>
              <input type="text" name="transaction_reference" class="form-control" placeholder="e.g., FT-20261027-9812 or Bank Ref ID">
              <div class="form-text small">Enter your bank reference number or slip ID if payment has already been sent.</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Summary Sidebar -->
      <div class="col-lg-5">
        <div class="card border-0 shadow-sm rounded-4 sticky-top" style="top: 2rem;">
          <div class="card-body p-4">
            <h5 class="fw-bold text-dark mb-3">Order Summary</h5>

            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Institution:</span>
              <span class="fw-semibold text-dark"><?= e($school['name'] ?? 'Your School') ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">School Code:</span>
              <span class="fw-bold font-monospace"><?= e($school['code'] ?? 'N/A') ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Selected Tier:</span>
              <span class="fw-bold text-primary"><?= e($plan['name']) ?></span>
            </div>

            <hr class="my-3">

            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Subtotal:</span>
              <span class="fw-semibold text-dark" id="displaySubtotal">PKR <?= number_format((float) $plan['monthly_price'], 2) ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Platform Tax (0%):</span>
              <span class="fw-semibold text-dark">PKR 0.00</span>
            </div>

            <hr class="my-3">

            <div class="d-flex justify-content-between align-items-baseline mb-4">
              <span class="fs-5 fw-bold text-dark">Total Payable:</span>
              <span class="fs-4 fw-bold text-primary" id="displayTotal">PKR <?= number_format((float) $plan['monthly_price'], 2) ?></span>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2.5 fw-bold shadow-sm rounded-3">
              <i class="bi bi-shield-check me-1"></i> Generate Invoice &amp; Order &rarr;
            </button>

            <p class="text-muted small text-center mt-3 mb-0" style="font-size: 11px;">
              By confirming, an official SaaS platform invoice will be generated. Once payment is verified by Super Admin, your subscription will be instantly activated.
            </p>
          </div>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
  const monthlyPrice = <?= (float) $plan['monthly_price'] ?>;
  const annualPrice = <?= (float) ($plan['annual_price'] ?? ($plan['monthly_price'] * 12)) ?>;

  function updateTotal(cycle) {
    const total = cycle === 'annual' ? annualPrice : monthlyPrice;
    const formatted = 'PKR ' + total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('displaySubtotal').innerText = formatted;
    document.getElementById('displayTotal').innerText = formatted;
  }
</script>
