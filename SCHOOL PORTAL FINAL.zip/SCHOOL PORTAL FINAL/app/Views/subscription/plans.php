<div class="container-fluid py-4">
  <div class="text-center mb-5">
    <span class="badge bg-primary-subtle text-primary fw-bold text-uppercase px-3 py-1.5 rounded-pill mb-2" style="letter-spacing: 0.5px;">Institutional Pricing &amp; Plans</span>
    <h1 class="h2 fw-bold text-dark mb-2">Upgrade or Renew Your School Plan</h1>
    <p class="text-muted mx-auto" style="max-width: 600px;">Select the best package tailored to your student body size and institutional operational requirements. All plans include automated backups, multi-role portals, and dedicated data privacy.</p>
  </div>

  <div class="row g-4 justify-content-center">
    <?php foreach ($plans as $plan): ?>
      <?php $isCurrent = !empty($currentPlanId) && (int) $currentPlanId === (int) $plan['id']; ?>
      <div class="col-lg-4 col-md-6">
        <div class="card border-0 shadow-sm rounded-4 h-100 position-relative <?= $isCurrent ? 'border-primary border-2' : '' ?>" style="transition: transform 0.2s, box-shadow 0.2s;">
          <?php if ($isCurrent): ?>
            <div class="position-absolute top-0 start-50 translate-middle">
              <span class="badge bg-primary text-white fw-bold px-3 py-1 rounded-pill shadow-sm">
                <i class="bi bi-star-fill me-1"></i> Current Plan
              </span>
            </div>
          <?php endif; ?>

          <div class="card-body p-4 p-xl-5 d-flex flex-column">
            <h4 class="fw-bold text-dark mb-1"><?= e($plan['name']) ?></h4>
            <p class="text-muted small mb-4" style="min-height: 40px;"><?= e($plan['description'] ?? 'Complete institutional management solution.') ?></p>

            <div class="mb-4">
              <div class="d-flex align-items-baseline">
                <span class="h1 fw-bold text-dark mb-0">PKR <?= number_format((float) $plan['monthly_price'], 0) ?></span>
                <span class="text-muted ms-2 small">/ month</span>
              </div>
              <?php if (!empty($plan['annual_price']) && (float) $plan['annual_price'] > 0): ?>
                <div class="text-muted small mt-1">
                  or PKR <?= number_format((float) $plan['annual_price'], 0) ?> / year (save ~15%)
                </div>
              <?php endif; ?>
            </div>

            <div class="p-3 rounded-3 bg-light border mb-4">
              <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Student Quota:</span>
                <span class="fw-bold text-dark"><?= !empty($plan['student_limit']) ? number_format($plan['student_limit']) . ' Students' : 'Unlimited' ?></span>
              </div>
              <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Teacher Quota:</span>
                <span class="fw-bold text-dark"><?= !empty($plan['teacher_limit']) ? number_format($plan['teacher_limit']) . ' Teachers' : 'Unlimited' ?></span>
              </div>
              <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Staff Quota:</span>
                <span class="fw-bold text-dark"><?= !empty($plan['employee_limit']) ? number_format($plan['employee_limit']) . ' Staff' : 'Unlimited' ?></span>
              </div>
              <div class="d-flex justify-content-between small">
                <span class="text-muted">Cloud Storage:</span>
                <span class="fw-bold text-dark"><?= !empty($plan['storage_limit_mb']) ? number_format($plan['storage_limit_mb'] / 1024, 1) . ' GB' : 'Unlimited' ?></span>
              </div>
            </div>

            <h6 class="fw-bold text-dark mb-3 small text-uppercase" style="letter-spacing: 0.5px;">Included Modules</h6>
            <ul class="list-unstyled mb-4 small flex-grow-1">
              <?php if (!empty($plan['features'])): ?>
                <?php foreach ($plan['features'] as $feat): ?>
                  <li class="d-flex align-items-center gap-2 mb-2">
                    <i class="bi bi-check-circle-fill text-success"></i>
                    <span><?= e($feat['name']) ?></span>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li class="d-flex align-items-center gap-2 mb-2">
                  <i class="bi bi-check-circle-fill text-success"></i>
                  <span>Student &amp; Parent Portals</span>
                </li>
                <li class="d-flex align-items-center gap-2 mb-2">
                  <i class="bi bi-check-circle-fill text-success"></i>
                  <span>Teacher Portal &amp; Attendance</span>
                </li>
                <li class="d-flex align-items-center gap-2 mb-2">
                  <i class="bi bi-check-circle-fill text-success"></i>
                  <span>Fee Collection &amp; Invoicing</span>
                </li>
                <li class="d-flex align-items-center gap-2 mb-2">
                  <i class="bi bi-check-circle-fill text-success"></i>
                  <span>Examination &amp; Report Cards</span>
                </li>
              <?php endif; ?>
            </ul>

            <div class="mt-auto">
              <a href="<?= e(url("subscription/checkout/{$plan['id']}")) ?>" class="btn <?= $isCurrent ? 'btn-outline-primary' : 'btn-primary' ?> w-100 py-2.5 fw-bold shadow-sm">
                <?= $isCurrent ? 'Renew Current Plan &rarr;' : 'Choose This Plan &rarr;' ?>
              </a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
