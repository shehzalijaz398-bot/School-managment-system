<div class="container py-4" style="max-width: 860px;">
  <div class="d-flex justify-content-between align-items-center mb-4 d-print-none">
    <a href="<?= e(url('subscription')) ?>" class="text-decoration-none text-muted small fw-semibold">
      &larr; Back to Subscription Overview
    </a>
    <div class="d-flex gap-2">
      <button onclick="window.print()" class="btn btn-outline-dark btn-sm fw-semibold">
        <i class="bi bi-printer me-1"></i> Print Invoice
      </button>
      <a href="<?= e(url('subscription/plans')) ?>" class="btn btn-primary btn-sm fw-semibold">
        <i class="bi bi-grid-fill me-1"></i> Other Plans
      </a>
    </div>
  </div>

  <?php if ($invoice['status'] === 'pending'): ?>
    <div class="alert alert-warning border-0 shadow-sm rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between d-print-none">
      <div class="d-flex align-items-center gap-3">
        <i class="bi bi-hourglass-split fs-4 text-warning"></i>
        <div>
          <span class="fw-bold text-dark d-block">Pending Payment Verification</span>
          <span class="text-muted small">Please deposit PKR <?= number_format((float) $invoice['total_amount'], 2) ?> using the settlement details below. Once verified by platform administration, your subscription will be activated automatically.</span>
        </div>
      </div>
    </div>
  <?php elseif ($invoice['status'] === 'paid'): ?>
    <div class="alert alert-success border-0 shadow-sm rounded-4 p-3 mb-4 d-flex align-items-center gap-3 d-print-none">
      <i class="bi bi-check-circle-fill fs-4 text-success"></i>
      <div>
        <span class="fw-bold text-success d-block">Invoice Paid &amp; Verified</span>
        <span class="text-muted small">Payment of PKR <?= number_format((float) $invoice['paid_amount'], 2) ?> has been verified. Your school subscription is active.</span>
      </div>
    </div>
  <?php endif; ?>

  <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 bg-white">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
      <div>
        <div class="h3 fw-bold text-primary mb-1">CodeClove School Portal</div>
        <p class="text-muted small mb-0">Multi-Tenant Educational Cloud SaaS Platform</p>
        <p class="text-muted small mb-0">support@schoolportal.local | +92 (51) 123-4567</p>
      </div>
      <div class="text-end">
        <span class="badge <?= $invoice['status'] === 'paid' ? 'bg-success' : 'bg-warning text-dark' ?> fs-6 px-3 py-1.5 fw-bold text-uppercase rounded-pill mb-2">
          <?= ucfirst($invoice['status']) ?>
        </span>
        <div class="font-monospace fw-bold fs-5 text-dark"><?= e($invoice['invoice_no']) ?></div>
        <div class="text-muted small">Issued: <?= date('M d, Y', strtotime($invoice['created_at'])) ?></div>
        <div class="text-muted small">Due: <?= date('M d, Y', strtotime($invoice['due_date'])) ?></div>
      </div>
    </div>

    <!-- Bill to & School info -->
    <div class="row g-4 mb-4">
      <div class="col-sm-6">
        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Billed To (Institution):</span>
        <div class="fw-bold text-dark fs-5"><?= e($invoice['school_name']) ?></div>
        <div class="text-muted small">School Code: <span class="font-monospace fw-semibold text-dark"><?= e($invoice['school_code']) ?></span></div>
        <?php if (!empty($invoice['school_email'])): ?>
          <div class="text-muted small"><?= e($invoice['school_email']) ?></div>
        <?php endif; ?>
        <?php if (!empty($invoice['school_address'])): ?>
          <div class="text-muted small"><?= e($invoice['school_address']) ?></div>
        <?php endif; ?>
      </div>
      <div class="col-sm-6 text-sm-end">
        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Billing Period:</span>
        <div class="fw-semibold text-dark">
          <?= date('M d, Y', strtotime($invoice['billing_period_start'])) ?> &ndash; <?= date('M d, Y', strtotime($invoice['billing_period_end'])) ?>
        </div>
        <?php if (!empty($invoice['notes'])): ?>
          <div class="text-muted small mt-2"><strong>Notes:</strong> <?= e($invoice['notes']) ?></div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Line items -->
    <div class="table-responsive mb-4">
      <table class="table table-bordered align-middle">
        <thead class="table-light small text-uppercase">
          <tr>
            <th style="width: 50px;">#</th>
            <th>Item Description</th>
            <th class="text-end" style="width: 150px;">Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php $idx = 1; foreach ($items as $item): ?>
            <tr>
              <td class="text-muted"><?= $idx++ ?></td>
              <td class="fw-semibold text-dark"><?= e($item['description']) ?></td>
              <td class="text-end fw-bold text-dark">PKR <?= number_format((float) $item['amount'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot class="border-top">
          <tr>
            <td colspan="2" class="text-end fw-semibold text-muted">Subtotal:</td>
            <td class="text-end fw-semibold text-dark">PKR <?= number_format((float) $invoice['subtotal'], 2) ?></td>
          </tr>
          <?php if ((float) $invoice['discount'] > 0): ?>
            <tr>
              <td colspan="2" class="text-end fw-semibold text-success">Discount:</td>
              <td class="text-end fw-semibold text-success">- PKR <?= number_format((float) $invoice['discount'], 2) ?></td>
            </tr>
          <?php endif; ?>
          <?php if ((float) $invoice['tax'] > 0): ?>
            <tr>
              <td colspan="2" class="text-end fw-semibold text-muted">Tax:</td>
              <td class="text-end fw-semibold text-dark">PKR <?= number_format((float) $invoice['tax'], 2) ?></td>
            </tr>
          <?php endif; ?>
          <tr class="table-light">
            <td colspan="2" class="text-end fw-bold fs-5 text-dark">Total Amount Due:</td>
            <td class="text-end fw-bold fs-5 text-primary">PKR <?= number_format((float) $invoice['total_amount'], 2) ?></td>
          </tr>
          <tr>
            <td colspan="2" class="text-end fw-semibold text-muted">Amount Paid:</td>
            <td class="text-end fw-bold text-success">PKR <?= number_format((float) $invoice['paid_amount'], 2) ?></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- Payment details box -->
    <div class="p-3 rounded-3 bg-light border mb-4">
      <h6 class="fw-bold text-dark mb-2 small text-uppercase"><i class="bi bi-wallet2 me-1 text-primary"></i> Settlement Instructions</h6>
      <div class="row g-2 small text-muted">
        <div class="col-sm-6">
          <strong>Bank:</strong> Habib Bank Limited (HBL) / Meezan Bank<br>
          <strong>Account Title:</strong> CodeClove Technologies (Pvt) Ltd<br>
          <strong>Account / IBAN:</strong> PK36MEZN0001000123456789
        </div>
        <div class="col-sm-6">
          <strong>Raast ID / JazzCash:</strong> 03001234567<br>
          <strong>Invoice Reference:</strong> <span class="font-monospace text-dark fw-bold"><?= e($invoice['invoice_no']) ?></span><br>
          <strong>Support Contact:</strong> billing@schoolportal.local
        </div>
      </div>
    </div>

    <!-- Payment history if any -->
    <?php if (!empty($payments)): ?>
      <h6 class="fw-bold text-dark mb-2 small text-uppercase">Payment History</h6>
      <div class="table-responsive">
        <table class="table table-sm table-bordered small">
          <thead class="table-light">
            <tr>
              <th>Date</th>
              <th>Method</th>
              <th>Reference</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($payments as $p): ?>
              <tr>
                <td><?= date('M d, Y H:i', strtotime($p['paid_at'] ?? $p['created_at'])) ?></td>
                <td><?= ucfirst(str_replace('_', ' ', $p['payment_method'])) ?></td>
                <td class="font-monospace"><?= e($p['transaction_reference'] ?? 'N/A') ?></td>
                <td class="fw-bold text-success">PKR <?= number_format((float) $p['amount'], 2) ?></td>
                <td><span class="badge bg-success-subtle text-success"><?= ucfirst($p['payment_status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <div class="border-top pt-4 text-center text-muted small">
      Thank you for choosing CodeClove School Portal. This is an electronically generated official platform invoice.
    </div>
  </div>
</div>
