<div class="container-fluid py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h1 class="h3 fw-bold text-dark mb-1">Institutional Subscription &amp; Billing</h1>
      <p class="text-muted small mb-0">Manage your subscription plan, billing cycles, quotas, and invoices.</p>
    </div>
    <div class="d-flex gap-2">
      <a href="<?= e(url('subscription/plans')) ?>" class="btn btn-primary shadow-sm fw-semibold">
        <i class="bi bi-grid-fill me-1"></i> Browse Plans &amp; Upgrade
      </a>
    </div>
  </div>

  <?php if (!empty($isExpired)): ?>
    <div class="alert alert-danger border-0 shadow-sm rounded-4 p-4 mb-4 d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-3">
        <div class="bg-danger text-white rounded-circle p-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px;">
          <i class="bi bi-exclamation-triangle-fill fs-4"></i>
        </div>
        <div>
          <h5 class="fw-bold mb-1 text-danger">Subscription Has Expired</h5>
          <p class="mb-0 text-muted small">Your institutional access is currently suspended. Upgrade to a paid monthly or annual subscription to restore full school operations.</p>
        </div>
      </div>
      <a href="<?= e(url('subscription/plans')) ?>" class="btn btn-danger fw-bold px-4 py-2">
        Renew Subscription Now &rarr;
      </a>
    </div>
  <?php elseif ($status === 'trial'): ?>
    <div class="alert alert-warning border-0 shadow-sm rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-3">
        <div class="bg-warning text-dark rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
          <i class="bi bi-clock-history fs-5"></i>
        </div>
        <div>
          <span class="fw-bold text-dark d-block">30-Day Free Trial Active</span>
          <span class="text-muted small"><?= $remainingDays ?> day(s) remaining in your trial period. Upgrade at any time without losing any school data.</span>
        </div>
      </div>
      <a href="<?= e(url('subscription/plans')) ?>" class="btn btn-dark btn-sm fw-semibold px-3">
        Choose Plan &rarr;
      </a>
    </div>
  <?php endif; ?>

  <div class="row g-4 mb-4">
    <!-- Current Plan Card -->
    <div class="col-lg-4">
      <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <span class="badge bg-primary-subtle text-primary fw-bold text-uppercase px-2.5 py-1.5" style="letter-spacing: 0.5px;">Current Plan</span>
            <?php if ($status === 'active'): ?>
              <span class="badge bg-success text-white fw-bold"><i class="bi bi-check-circle-fill me-1"></i> Active</span>
            <?php elseif ($status === 'trial'): ?>
              <span class="badge bg-warning text-dark fw-bold"><i class="bi bi-hourglass-split me-1"></i> Free Trial</span>
            <?php else: ?>
              <span class="badge bg-danger text-white fw-bold"><i class="bi bi-x-circle-fill me-1"></i> Expired</span>
            <?php endif; ?>
          </div>

          <h3 class="fw-bold text-dark mb-1"><?= e($currentPlan['name'] ?? 'Trial Plan') ?></h3>
          <p class="text-muted small mb-4"><?= e($currentPlan['description'] ?? '30-day full access enterprise evaluation') ?></p>

          <div class="d-flex align-items-baseline mb-4">
            <span class="fs-2 fw-bold text-dark">PKR <?= number_format((float) ($currentPlan['monthly_price'] ?? 0), 0) ?></span>
            <span class="text-muted ms-1 small">/ month</span>
          </div>

          <div class="border-top pt-3">
            <div class="d-flex justify-content-between mb-2 small">
              <span class="text-muted">Status:</span>
              <span class="fw-bold text-capitalize"><?= e($status) ?></span>
            </div>
            <?php if ($status === 'trial'): ?>
              <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Trial Ends:</span>
                <span class="fw-semibold text-danger"><?= !empty($school['trial_ends_at']) ? date('M d, Y', strtotime($school['trial_ends_at'])) : 'N/A' ?></span>
              </div>
            <?php else: ?>
              <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Renewal Date:</span>
                <span class="fw-semibold text-dark"><?= !empty($school['subscription_ends_at']) ? date('M d, Y', strtotime($school['subscription_ends_at'])) : 'N/A' ?></span>
              </div>
            <?php endif; ?>
          </div>

          <div class="mt-4">
            <a href="<?= e(url('subscription/plans')) ?>" class="btn btn-outline-primary w-100 fw-semibold">
              <i class="bi bi-arrow-repeat me-1"></i> Change or Renew Plan
            </a>
          </div>
        </div>
      </div>
    </div>

    <!-- Institutional Quota Usage -->
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body p-4">
          <h5 class="fw-bold text-dark mb-3">Resource &amp; Quota Utilization</h5>

          <div class="row g-3">
            <!-- Student Quota -->
            <div class="col-md-4">
              <div class="p-3 rounded-3 bg-light border">
                <div class="d-flex align-items-center justify-content-between mb-2">
                  <span class="text-muted small fw-medium">Student Limit</span>
                  <i class="bi bi-mortarboard-fill text-primary"></i>
                </div>
                <div class="fs-4 fw-bold text-dark"><?= $studentCount ?></div>
                <div class="text-muted small">of <?= !empty($currentPlan['student_limit']) ? number_format($currentPlan['student_limit']) : 'Unlimited' ?> allowed</div>
              </div>
            </div>

            <!-- Teacher Quota -->
            <div class="col-md-4">
              <div class="p-3 rounded-3 bg-light border">
                <div class="d-flex align-items-center justify-content-between mb-2">
                  <span class="text-muted small fw-medium">Teacher Limit</span>
                  <i class="bi bi-person-badge-fill text-info"></i>
                </div>
                <div class="fs-4 fw-bold text-dark"><?= $teacherCount ?></div>
                <div class="text-muted small">of <?= !empty($currentPlan['teacher_limit']) ? number_format($currentPlan['teacher_limit']) : 'Unlimited' ?> allowed</div>
              </div>
            </div>

            <!-- Storage Quota -->
            <div class="col-md-4">
              <div class="p-3 rounded-3 bg-light border">
                <div class="d-flex align-items-center justify-content-between mb-2">
                  <span class="text-muted small fw-medium">Cloud Storage</span>
                  <i class="bi bi-cloud-arrow-up-fill text-success"></i>
                </div>
                <div class="fs-4 fw-bold text-dark">Active</div>
                <div class="text-muted small"><?= !empty($currentPlan['storage_limit_mb']) ? number_format($currentPlan['storage_limit_mb'] / 1024, 1) . ' GB' : 'Unlimited' ?></div>
              </div>
            </div>
          </div>

          <div class="mt-4 p-3 rounded-3 bg-primary-subtle text-primary border border-primary-subtle">
            <div class="d-flex gap-2">
              <i class="bi bi-shield-check fs-5"></i>
              <div class="small">
                <strong>Data Protection Guarantee:</strong> Your school data, admissions, student records, fee logs, and staff files are securely preserved indefinitely, even if your subscription expires.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Invoices Table -->
  <div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white border-0 py-3 px-4 d-flex justify-content-between align-items-center">
      <h5 class="fw-bold text-dark mb-0">Subscription Invoices &amp; Receipts</h5>
    </div>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light text-muted small text-uppercase">
          <tr>
            <th class="ps-4">Invoice #</th>
            <th>Billing Period</th>
            <th>Amount</th>
            <th>Due Date</th>
            <th>Status</th>
            <th class="text-end pe-4">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($invoices)): ?>
            <tr>
              <td colspan="6" class="text-center py-5 text-muted">
                <i class="bi bi-receipt fs-1 d-block mb-2 text-secondary"></i>
                No platform invoices issued yet.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($invoices as $inv): ?>
              <tr>
                <td class="ps-4 font-monospace fw-bold text-dark"><?= e($inv['invoice_no']) ?></td>
                <td class="small"><?= date('M d, Y', strtotime($inv['billing_period_start'])) ?> &ndash; <?= date('M d, Y', strtotime($inv['billing_period_end'])) ?></td>
                <td class="fw-bold text-dark">PKR <?= number_format((float) $inv['total_amount'], 2) ?></td>
                <td class="small text-muted"><?= date('M d, Y', strtotime($inv['due_date'])) ?></td>
                <td>
                  <?php if ($inv['status'] === 'paid'): ?>
                    <span class="badge bg-success-subtle text-success fw-bold px-2.5 py-1">Paid</span>
                  <?php elseif ($inv['status'] === 'pending'): ?>
                    <span class="badge bg-warning-subtle text-warning fw-bold px-2.5 py-1">Pending Verification</span>
                  <?php elseif ($inv['status'] === 'partial'): ?>
                    <span class="badge bg-info-subtle text-info fw-bold px-2.5 py-1">Partial</span>
                  <?php else: ?>
                    <span class="badge bg-secondary-subtle text-secondary fw-bold px-2.5 py-1"><?= ucfirst($inv['status']) ?></span>
                  <?php endif; ?>
                </td>
                <td class="text-end pe-4">
                  <a href="<?= e(url("subscription/invoice/{$inv['id']}")) ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-eye me-1"></i> View Details
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
