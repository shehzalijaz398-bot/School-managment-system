<?php
/**
 * CodeClove Enterprise AI Chatbot Overlay Widget
 * Floating reactive widget with streaming typography & markdown parsing.
 */
$currentUser = currentUser();
$isPlatform = false;
if (!$currentUser && class_exists('\\Core\\PlatformAuth') && \Core\PlatformAuth::check()) {
    $currentUser = \Core\PlatformAuth::user();
    $isPlatform = true;
}

if (!$currentUser) {
    return;
}

$currentSchool = currentSchool();
$userRole = $isPlatform ? 'super_admin' : ($currentUser['role_slug'] ?? 'school_admin');
$schoolName = $isPlatform ? 'SaaS Platform Management' : ($currentSchool['name'] ?? 'School Portal');
$roleTitle = match($userRole) {
    'super_admin', 'superadmin' => 'Platform Super Admin AI',
    'parent' => 'Parent Portal AI',
    'student' => 'Student AI Desk',
    'teacher' => 'Faculty AI Assistant',
    default => 'Enterprise AI Copilot'
};
?>
<!-- AI Chatbot Floating Trigger Button -->
<div id="cc-ai-widget-root">
  <button id="cc-ai-bubble-btn" class="cc-ai-bubble" type="button" aria-label="Open AI Assistant" title="AI School Copilot (Ctrl+J)">
    <div class="cc-ai-bubble-glow"></div>
    <div class="cc-ai-bubble-icon-wrap">
      <!-- Normal Icon -->
      <svg class="cc-ai-icon-sparkle" xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
        <path d="M5 3v4"/>
        <path d="M19 17v4"/>
        <path d="M3 5h4"/>
        <path d="M17 19h4"/>
      </svg>
      <!-- Close Icon (shown when active) -->
      <svg class="cc-ai-icon-close d-none" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </div>
    <span class="cc-ai-bubble-badge">AI</span>
  </button>

  <!-- AI Chat Window Overlay Card -->
  <div id="cc-ai-chat-panel" class="cc-ai-panel d-none" role="dialog" aria-modal="true" aria-labelledby="cc-ai-header-title">
    
    <!-- Top Header -->
    <div class="cc-ai-header">
      <div class="d-flex align-items-center gap-2.5">
        <div class="cc-ai-avatar">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
          </svg>
          <span class="cc-ai-status-dot" title="Active & Ready"></span>
        </div>
        <div>
          <div class="d-flex align-items-center gap-2">
            <h6 id="cc-ai-header-title" class="cc-ai-title mb-0"><?= e($roleTitle) ?></h6>
            <span class="cc-ai-role-pill"><?= e(strtoupper(str_replace('_', ' ', $userRole))) ?></span>
          </div>
          <small class="cc-ai-subtitle"><?= e($schoolName) ?> · Context-Aware</small>
        </div>
      </div>

      <!-- Controls -->
      <div class="cc-ai-header-actions">
        <button id="cc-ai-btn-new" class="cc-ai-header-btn" type="button" title="Start fresh conversation" aria-label="New conversation">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          <span>New</span>
        </button>
        <button id="cc-ai-btn-clear" class="cc-ai-icon-btn" type="button" title="Clear chat history" aria-label="Clear chat">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
        </button>
        <button id="cc-ai-btn-minimize" class="cc-ai-icon-btn" type="button" title="Minimize window" aria-label="Minimize">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
        </button>
      </div>
    </div>

    <!-- Message Stream History Container -->
    <div id="cc-ai-messages" class="cc-ai-body">
      <!-- Welcome Hero Prompt Card -->
      <div id="cc-ai-welcome-card" class="cc-ai-welcome">
        <div class="cc-ai-welcome-badge">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          Multi-Tenant RAG Engine
        </div>
        <h5>Hello, <?= e($currentUser['first_name'] ?? 'there') ?>! 👋</h5>
        <p class="text-muted mb-3" style="font-size: 13px;">
          I am your school's private AI assistant. All answers are queried in real time directly from your verified institutional database records.
        </p>

        <!-- Suggested Prompt Chips -->
        <div class="cc-ai-suggestions-title">SUGGESTED ACTIONS</div>
        <div id="cc-ai-suggestion-chips" class="cc-ai-chips-wrap">
          <?php if ($userRole === 'super_admin' || $userRole === 'superadmin'): ?>
            <button class="cc-ai-chip" data-prompt="Show platform school counts and active subscriptions">
              🏢 Platform schools & tiers
            </button>
            <button class="cc-ai-chip" data-prompt="What is the automated backup vault status?">
              🛡️ Backup vault health
            </button>
            <button class="cc-ai-chip" data-prompt="List available subscription tiers and pricing">
              💎 Subscription plans
            </button>
          <?php elseif ($userRole === 'parent'): ?>
            <button class="cc-ai-chip" data-prompt="Is my child's fee paid?">
              💳 Is my child's fee paid?
            </button>
            <button class="cc-ai-chip" data-prompt="What is my child's attendance record this month?">
              📅 Attendance record
            </button>
            <button class="cc-ai-chip" data-prompt="Show all pending assignments due soon">
              📚 Pending assignments
            </button>
            <button class="cc-ai-chip" data-prompt="Show latest fee receipts and payment history">
              🧾 Payment receipts
            </button>
          <?php elseif ($userRole === 'student'): ?>
            <button class="cc-ai-chip" data-prompt="Check my fee status and pending invoice balance">
              💳 Check my fee balance
            </button>
            <button class="cc-ai-chip" data-prompt="What is my current attendance percentage?">
              📅 Attendance percentage
            </button>
            <button class="cc-ai-chip" data-prompt="List my active homework assignments">
              📝 Homework desk
            </button>
            <button class="cc-ai-chip" data-prompt="What is today's class schedule?">
              ⏰ Today's schedule
            </button>
          <?php elseif ($userRole === 'teacher'): ?>
            <button class="cc-ai-chip" data-prompt="Show my class schedule today">
              ⏰ My schedule today
            </button>
            <button class="cc-ai-chip" data-prompt="How many students are enrolled in my class?">
              👥 My class students
            </button>
            <button class="cc-ai-chip" data-prompt="Guide me on creating a new assignment">
              📝 Create assignment guide
            </button>
            <button class="cc-ai-chip" data-prompt="How do I submit today's attendance?">
              ✅ Attendance instructions
            </button>
          <?php else: ?>
            <button class="cc-ai-chip" data-prompt="What is the overall fee collection and overdue sum?">
              📊 Fee collection overview
            </button>
            <button class="cc-ai-chip" data-prompt="How many students are currently enrolled?">
              👥 Enrollment metrics
            </button>
            <button class="cc-ai-chip" data-prompt="Check student Jose's fee invoice balance">
              🔍 Look up student Jose's fee
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Active Indicator / Streaming Status -->
    <div id="cc-ai-streaming-bar" class="cc-ai-streaming-bar d-none">
      <div class="d-flex align-items-center gap-2">
        <span class="spinner-grow spinner-grow-sm text-primary" role="status"></span>
        <span class="cc-ai-thinking-text">Consulting school database...</span>
      </div>
      <button id="cc-ai-btn-stop" class="btn btn-xs btn-outline-secondary py-0 px-2" style="font-size: 11px;">Stop</button>
    </div>

    <!-- Bottom Input Box -->
    <div class="cc-ai-footer">
      <form id="cc-ai-form" class="cc-ai-input-form" onsubmit="return false;">
        <div class="cc-ai-input-wrap">
          <textarea
            id="cc-ai-input"
            class="cc-ai-textarea"
            rows="1"
            placeholder="Ask about fees, attendance, assignments... (Enter to send)"
            aria-label="Ask the AI School Assistant a question"
            maxlength="1000"
            autocomplete="off"
            spellcheck="false"
          ></textarea>
          <button id="cc-ai-btn-send" class="cc-ai-send-btn" type="button" title="Send prompt" aria-label="Send">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </div>
      </form>
      <div class="d-flex align-items-center justify-content-between px-2 pt-1 text-muted cc-ai-meta-text">
        <span><kbd class="cc-ai-kbd">Ctrl+J</kbd> toggle · Multi-tenant protected</span>
        <span id="cc-ai-provider-badge" class="cc-ai-provider-tag">Gemini / OpenAI Active</span>
      </div>
    </div>

  </div>
</div>

<!-- AI Chatbot Custom Styles (CodeClove Architecture Compliant) -->
<style>
/* Bubble Trigger */
.cc-ai-bubble {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--sp-primary, #4f46e5) 0%, #2563eb 100%);
  color: #ffffff;
  border: none;
  box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.4), 0 8px 10px -6px rgba(79, 70, 229, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 1080;
  transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease;
  outline: none;
}
.cc-ai-bubble:hover {
  transform: scale(1.08) translateY(-2px);
  box-shadow: 0 16px 30px -4px rgba(79, 70, 229, 0.55);
}
.cc-ai-bubble:active {
  transform: scale(0.96);
}
.cc-ai-bubble-glow {
  position: absolute;
  inset: -3px;
  border-radius: 50%;
  background: inherit;
  filter: blur(8px);
  opacity: 0.45;
  z-index: -1;
  animation: ccAiPulse 3s infinite ease-in-out;
}
@keyframes ccAiPulse {
  0%, 100% { opacity: 0.35; transform: scale(1); }
  50% { opacity: 0.65; transform: scale(1.06); }
}
.cc-ai-bubble-badge {
  position: absolute;
  top: -3px;
  right: -3px;
  background: #10b981;
  color: #fff;
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 0.5px;
  padding: 2px 6px;
  border-radius: 10px;
  border: 2px solid var(--sp-card-bg, #ffffff);
}

/* Chat Panel */
.cc-ai-panel {
  position: fixed;
  bottom: 88px;
  right: 24px;
  width: 410px;
  max-width: calc(100vw - 32px);
  height: 600px;
  max-height: calc(100vh - 120px);
  background-color: var(--sp-card-bg, #ffffff);
  border: 1px solid var(--sp-border, #e2e8f0);
  border-radius: 20px;
  box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.18), 0 0 1px 1px rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  z-index: 1085;
  overflow: hidden;
  backdrop-filter: blur(16px);
  animation: ccAiSlideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
@keyframes ccAiSlideUp {
  from { opacity: 0; transform: translateY(16px) scale(0.96); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

/* Dark Mode Overrides */
[data-theme="dark"] .cc-ai-panel {
  background-color: rgba(22, 25, 34, 0.95);
  border-color: #262b3a;
  box-shadow: 0 24px 50px -10px rgba(0, 0, 0, 0.55), 0 0 0 1px rgba(255, 255, 255, 0.05);
}

/* Header */
.cc-ai-header {
  padding: 14px 18px;
  border-bottom: 1px solid var(--sp-border, #e2e8f0);
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--sp-card-bg, #ffffff);
}
[data-theme="dark"] .cc-ai-header {
  background: #191c26;
  border-color: #242836;
}
.cc-ai-avatar {
  position: relative;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: var(--sp-primary-light, rgba(79, 70, 229, 0.12));
  color: var(--sp-primary, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
}
.cc-ai-status-dot {
  position: absolute;
  bottom: -1px;
  right: -1px;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background-color: #10b981;
  border: 2px solid var(--sp-card-bg, #ffffff);
}
.cc-ai-title {
  font-size: 14.5px;
  font-weight: 700;
  color: var(--sp-text, #0f172a);
}
.cc-ai-subtitle {
  font-size: 11.5px;
  color: var(--sp-text-muted, #64748b);
}
.cc-ai-role-pill {
  font-size: 9.5px;
  font-weight: 700;
  background: var(--sp-primary-light, rgba(79, 70, 229, 0.12));
  color: var(--sp-primary, #4f46e5);
  padding: 2px 7px;
  border-radius: 6px;
  letter-spacing: 0.4px;
}
.cc-ai-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}
.cc-ai-icon-btn {
  background: transparent;
  border: none;
  color: var(--sp-text-muted, #64748b);
  width: 30px;
  height: 30px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cc-ai-icon-btn:hover {
  background: var(--sp-border-subtle, #f1f5f9);
  color: var(--sp-text, #0f172a);
}
[data-theme="dark"] .cc-ai-icon-btn:hover {
  background: #252a39;
  color: #fff;
}

/* Chat Body */
.cc-ai-body {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
  background: var(--sp-bg, #f8fafc);
  scroll-behavior: smooth;
}
[data-theme="dark"] .cc-ai-body {
  background: #0d0f15;
}

/* Welcome Card */
.cc-ai-welcome {
  background: var(--sp-card-bg, #ffffff);
  border: 1px solid var(--sp-border, #e2e8f0);
  border-radius: 14px;
  padding: 16px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
}
[data-theme="dark"] .cc-ai-welcome {
  background: #161922;
  border-color: #242938;
}
.cc-ai-welcome-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  font-weight: 700;
  color: #10b981;
  background: rgba(16, 185, 129, 0.1);
  padding: 3px 8px;
  border-radius: 6px;
  margin-bottom: 10px;
}
.cc-ai-welcome h5 {
  font-size: 15px;
  font-weight: 700;
  color: var(--sp-text, #0f172a);
  margin-bottom: 6px;
}
.cc-ai-suggestions-title {
  font-size: 10.5px;
  font-weight: 800;
  letter-spacing: 0.6px;
  color: var(--sp-text-muted, #64748b);
  margin-bottom: 8px;
}
.cc-ai-chips-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.cc-ai-chip {
  background: var(--sp-card-bg, #ffffff);
  border: 1px solid var(--sp-border, #e2e8f0);
  color: var(--sp-text, #0f172a);
  font-size: 12px;
  padding: 6px 11px;
  border-radius: 18px;
  cursor: pointer;
  text-align: left;
  transition: all 0.15s ease;
  line-height: 1.3;
}
.cc-ai-chip:hover {
  background: var(--sp-primary-light, rgba(79, 70, 229, 0.1));
  border-color: var(--sp-primary, #4f46e5);
  color: var(--sp-primary, #4f46e5);
  transform: translateY(-1px);
}
[data-theme="dark"] .cc-ai-chip {
  background: #1b1f2b;
  border-color: #282f42;
  color: #e2e8f0;
}
[data-theme="dark"] .cc-ai-chip:hover {
  background: rgba(79, 70, 229, 0.2);
  border-color: #6366f1;
  color: #818cf8;
}

/* Chat Messages */
.cc-ai-msg-row {
  display: flex;
  gap: 10px;
  margin-bottom: 4px;
}
.cc-ai-msg-user {
  justify-content: flex-end;
}
.cc-ai-msg-assistant {
  justify-content: flex-start;
}
.cc-ai-msg-bubble {
  max-width: 86%;
  padding: 11px 14px;
  border-radius: 16px;
  font-size: 13.5px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
}
.cc-ai-msg-user .cc-ai-msg-bubble {
  background: var(--sp-primary, #4f46e5);
  color: #ffffff;
  border-bottom-right-radius: 4px;
}
.cc-ai-msg-assistant .cc-ai-msg-bubble {
  background: var(--sp-card-bg, #ffffff);
  color: var(--sp-text, #0f172a);
  border: 1px solid var(--sp-border, #e2e8f0);
  border-bottom-left-radius: 4px;
}
[data-theme="dark"] .cc-ai-msg-assistant .cc-ai-msg-bubble {
  background: #161922;
  border-color: #252a38;
  color: #f1f5f9;
}

/* Markdown Elements inside AI messages */
.cc-ai-msg-bubble h1, .cc-ai-msg-bubble h2, .cc-ai-msg-bubble h3, .cc-ai-msg-bubble h4 {
  font-size: 14px;
  font-weight: 700;
  margin-top: 6px;
  margin-bottom: 6px;
  color: inherit;
}
.cc-ai-msg-bubble p {
  margin-bottom: 6px;
}
.cc-ai-msg-bubble p:last-child {
  margin-bottom: 0;
}
.cc-ai-msg-bubble ul, .cc-ai-msg-bubble ol {
  margin: 4px 0 6px 18px;
  padding: 0;
}
.cc-ai-msg-bubble li {
  margin-bottom: 3px;
}
.cc-ai-msg-bubble code {
  font-family: Consolas, monospace;
  background: rgba(0, 0, 0, 0.06);
  padding: 2px 5px;
  border-radius: 4px;
  font-size: 12px;
}
[data-theme="dark"] .cc-ai-msg-bubble code {
  background: rgba(255, 255, 255, 0.1);
}
.cc-ai-msg-bubble pre {
  background: #0f172a;
  color: #f8fafc;
  padding: 10px;
  border-radius: 8px;
  overflow-x: auto;
  font-size: 12px;
}
.cc-ai-msg-bubble a {
  color: var(--sp-primary, #4f46e5);
  text-decoration: underline;
  font-weight: 600;
}
.cc-ai-status-badge {
  display: inline-block;
  padding: 1px 6px;
  border-radius: 4px;
  font-size: 10.5px;
  font-weight: 700;
  margin: 0 2px;
}
.cc-badge-paid { background: #d1fae5; color: #065f46; }
.cc-badge-unpaid, .cc-badge-overdue { background: #fee2e2; color: #991b1b; }
.cc-badge-partial { background: #fef3c7; color: #92400e; }

/* Header New Button */
.cc-ai-header-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: rgba(255, 255, 255, 0.16);
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.28);
  border-radius: 6px;
  padding: 3px 8px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cc-ai-header-btn:hover {
  background: rgba(255, 255, 255, 0.28);
  transform: translateY(-1px);
}

/* Verified Institutional Record Badge */
.cc-ai-verified-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #ecfdf5;
  color: #065f46;
  border: 1px solid #a7f3d0;
  border-radius: 6px;
  padding: 3px 8px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.2px;
  margin-bottom: 8px;
}
[data-theme="dark"] .cc-ai-verified-badge {
  background: rgba(16, 185, 129, 0.12);
  color: #34d399;
  border-color: rgba(16, 185, 129, 0.28);
}

/* Responsive Table Wrapper */
.cc-ai-table-wrap {
  overflow-x: auto;
  margin: 8px 0;
  border-radius: 8px;
  border: 1px solid var(--sp-border, #e2e8f0);
}
[data-theme="dark"] .cc-ai-table-wrap {
  border-color: #2b334a;
}
.cc-ai-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11.5px;
  text-align: left;
}
.cc-ai-table th {
  background: var(--sp-border-subtle, #f1f5f9);
  color: var(--sp-text, #0f172a);
  font-weight: 700;
  padding: 6px 10px;
  border-bottom: 1px solid var(--sp-border, #cbd5e1);
  white-space: nowrap;
}
[data-theme="dark"] .cc-ai-table th {
  background: #191f2e;
  color: #e2e8f0;
  border-color: #2b334a;
}
.cc-ai-table td {
  padding: 6px 10px;
  border-bottom: 1px solid var(--sp-border-subtle, #f1f5f9);
  color: var(--sp-text, #1e293b);
}
[data-theme="dark"] .cc-ai-table td {
  border-color: #202637;
  color: #cbd5e1;
}
.cc-ai-table tr:last-child td {
  border-bottom: none;
}
.cc-ai-table tr:nth-child(even) {
  background: rgba(0, 0, 0, 0.015);
}
[data-theme="dark"] .cc-ai-table tr:nth-child(even) {
  background: rgba(255, 255, 255, 0.02);
}

/* Message Actions & Feedback */
.cc-ai-msg-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
  padding-top: 4px;
  border-top: 1px dashed rgba(0, 0, 0, 0.08);
}
[data-theme="dark"] .cc-ai-msg-actions {
  border-color: rgba(255, 255, 255, 0.08);
}
.cc-ai-action-btn {
  background: transparent;
  border: none;
  color: var(--sp-text-muted, #94a3b8);
  padding: 3px 6px;
  border-radius: 4px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}
.cc-ai-action-btn:hover {
  color: var(--sp-primary, #4f46e5);
  background: rgba(79, 70, 229, 0.08);
}
.cc-ai-action-btn.active {
  color: #10b981;
  background: rgba(16, 185, 129, 0.12);
}

/* Contextual Follow-up Suggestions */
.cc-ai-followups-wrap {
  margin-top: 8px;
  padding-top: 6px;
}
.cc-ai-followups-label {
  font-size: 10px;
  font-weight: 700;
  color: var(--sp-text-muted, #64748b);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 5px;
}
.cc-ai-followups-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
.cc-ai-followup-chip {
  background: var(--sp-card-bg, #ffffff);
  color: var(--sp-primary, #4f46e5);
  border: 1px solid var(--sp-primary-light, rgba(79, 70, 229, 0.25));
  border-radius: 12px;
  padding: 4px 10px;
  font-size: 11.5px;
  font-weight: 500;
  cursor: pointer;
  text-align: left;
  transition: all 0.15s ease;
}
.cc-ai-followup-chip:hover {
  background: var(--sp-primary, #4f46e5);
  color: #ffffff;
  border-color: var(--sp-primary, #4f46e5);
  transform: translateY(-1px);
}
[data-theme="dark"] .cc-ai-followup-chip {
  background: #171b26;
  color: #818cf8;
  border-color: rgba(99, 102, 241, 0.3);
}
[data-theme="dark"] .cc-ai-followup-chip:hover {
  background: #4f46e5;
  color: #ffffff;
}

/* Typing Cursor */
.cc-ai-cursor {
  display: inline-block;
  width: 6px;
  height: 14px;
  background-color: var(--sp-primary, #4f46e5);
  margin-left: 2px;
  vertical-align: middle;
  animation: ccBlink 0.8s infinite;
}
@keyframes ccBlink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}

/* Streaming Active Bar */
.cc-ai-streaming-bar {
  padding: 6px 14px;
  background: var(--sp-border-subtle, #f1f5f9);
  border-top: 1px solid var(--sp-border, #e2e8f0);
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11.5px;
}
[data-theme="dark"] .cc-ai-streaming-bar {
  background: #131620;
  border-color: #202432;
}

/* Footer / Input Area */
.cc-ai-footer {
  padding: 12px 14px;
  background: var(--sp-card-bg, #ffffff);
  border-top: 1px solid var(--sp-border, #e2e8f0);
}
[data-theme="dark"] .cc-ai-footer {
  background: #171a24;
  border-color: #242836;
}
.cc-ai-input-wrap {
  position: relative;
  display: flex;
  align-items: center;
  background: var(--sp-bg, #f8fafc);
  border: 1px solid var(--sp-border, #e2e8f0);
  border-radius: 12px;
  padding: 4px 6px 4px 12px;
  transition: all 0.2s ease;
}
.cc-ai-input-wrap:focus-within {
  border-color: var(--sp-primary, #4f46e5);
  box-shadow: 0 0 0 3px var(--sp-primary-light, rgba(79, 70, 229, 0.15));
}
[data-theme="dark"] .cc-ai-input-wrap {
  background: #0f1118;
  border-color: #292f42;
}
.cc-ai-textarea {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  resize: none;
  font-size: 13.5px;
  color: var(--sp-text, #0f172a);
  font-family: inherit;
  padding: 6px 0;
  max-height: 100px;
}
.cc-ai-textarea::placeholder {
  color: var(--sp-text-muted, #94a3b8);
}
.cc-ai-send-btn {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  background: var(--sp-primary, #4f46e5);
  color: #fff;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.15s ease;
}
.cc-ai-send-btn:hover {
  opacity: 0.92;
  transform: scale(1.04);
}
.cc-ai-send-btn:disabled {
  background: var(--sp-border, #cbd5e1);
  cursor: not-allowed;
  transform: none;
}
.cc-ai-meta-text {
  font-size: 11px;
}
.cc-ai-kbd {
  background: var(--sp-border-subtle, #f1f5f9);
  border: 1px solid var(--sp-border, #cbd5e1);
  padding: 1px 4px;
  border-radius: 4px;
  font-size: 10px;
}
[data-theme="dark"] .cc-ai-kbd {
  background: #1c2130;
  border-color: #2b334a;
}
.cc-ai-provider-tag {
  font-weight: 600;
  color: var(--sp-text-muted, #64748b);
}

/* Mobile full-screen docked */
@media (max-width: 480px) {
  .cc-ai-panel {
    bottom: 0;
    right: 0;
    width: 100vw;
    height: 100vh;
    height: 100dvh;
    max-height: 100vh;
    max-height: 100dvh;
    border-radius: 0;
    border: none;
  }
  .cc-ai-footer {
    padding-bottom: calc(12px + env(safe-area-inset-bottom, 0px));
  }
  .cc-ai-bubble {
    bottom: calc(18px + env(safe-area-inset-bottom, 0px));
    right: 18px;
  }
}
</style>

<!-- Real-Time AI Chatbot Client Script (Streaming + Markdown Engine) -->
<script>
(function() {
  'use strict';

  // DOM Elements
  const root = document.getElementById('cc-ai-widget-root');
  if (!root) return;

  const bubbleBtn = document.getElementById('cc-ai-bubble-btn');
  const panel = document.getElementById('cc-ai-chat-panel');
  const input = document.getElementById('cc-ai-input');
  const sendBtn = document.getElementById('cc-ai-btn-send');
  const messagesBox = document.getElementById('cc-ai-messages');
  const welcomeCard = document.getElementById('cc-ai-welcome-card');
  const streamingBar = document.getElementById('cc-ai-streaming-bar');
  const stopBtn = document.getElementById('cc-ai-btn-stop');
  const newBtn = document.getElementById('cc-ai-btn-new');
  const clearBtn = document.getElementById('cc-ai-btn-clear');
  const minimizeBtn = document.getElementById('cc-ai-btn-minimize');
  const providerBadge = document.getElementById('cc-ai-provider-badge');

  let isStreaming = false;
  let activeAbortController = null;
  let conversationHistory = [];
  let historyLoaded = false;

  // Toggle Chat Panel
  function togglePanel(open = null) {
    const isClosed = panel.classList.contains('d-none');
    const targetState = open !== null ? open : isClosed;

    if (targetState) {
      panel.classList.remove('d-none');
      bubbleBtn.querySelector('.cc-ai-icon-sparkle').classList.add('d-none');
      bubbleBtn.querySelector('.cc-ai-icon-close').classList.remove('d-none');
      input.focus();
      scrollBottom();
      loadHistoryIfEmpty();
    } else {
      panel.classList.add('d-none');
      bubbleBtn.querySelector('.cc-ai-icon-sparkle').classList.remove('d-none');
      bubbleBtn.querySelector('.cc-ai-icon-close').classList.add('d-none');
    }
  }

  bubbleBtn.addEventListener('click', () => togglePanel());
  minimizeBtn.addEventListener('click', () => togglePanel(false));

  // Global Keyboard Shortcut: Ctrl+J or Cmd+J
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
      e.preventDefault();
      togglePanel();
    } else if (e.key === 'Escape' && !panel.classList.contains('d-none')) {
      togglePanel(false);
    }
  });

  // Chip Click handler for welcome card
  document.querySelectorAll('.cc-ai-chip').forEach(chip => {
    chip.addEventListener('click', function() {
      const prompt = this.getAttribute('data-prompt');
      if (prompt) {
        input.value = prompt;
        sendMessage();
      }
    });
  });

  // Auto-resize textarea
  input.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 100) + 'px';
  });

  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  sendBtn.addEventListener('click', sendMessage);

  // Start Fresh Conversation Action
  if (newBtn) {
    newBtn.addEventListener('click', async () => {
      if (confirm('Start a fresh AI conversation?')) {
        conversationHistory = [];
        messagesBox.innerHTML = '';
        if (welcomeCard) {
          welcomeCard.classList.remove('d-none');
          messagesBox.appendChild(welcomeCard);
        }
        try {
          await fetch('<?= e(url("api/ai/chat/new")) ?>', {
            credentials: 'same-origin',
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
          });
        } catch (err) {}
        input.focus();
      }
    });
  }

  // Clear Chat History Action
  clearBtn.addEventListener('click', async () => {
    if (confirm('Clear current AI conversation history?')) {
      conversationHistory = [];
      messagesBox.innerHTML = '';
      if (welcomeCard) {
        welcomeCard.classList.remove('d-none');
        messagesBox.appendChild(welcomeCard);
      }
      try {
        await fetch('<?= e(url("api/ai/chat/clear")) ?>', {
          credentials: 'same-origin',
          method: 'POST',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
      } catch (err) {}
      input.focus();
    }
  });

  // Stop Generation
  stopBtn.addEventListener('click', () => {
    if (activeAbortController) {
      activeAbortController.abort();
      activeAbortController = null;
    }
    finishStreaming();
  });

  // Load Session History on Initial Panel Expansion
  async function loadHistoryIfEmpty() {
    if (historyLoaded) return;
    historyLoaded = true;

    try {
      const res = await fetch('<?= e(url("api/ai/chat/history")) ?>', {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        credentials: 'same-origin'
      });
      if (!res.ok) return;
      const data = await res.json();

      if (data.success && Array.isArray(data.history) && data.history.length > 0) {
        if (welcomeCard) welcomeCard.classList.add('d-none');
        conversationHistory = [];

        data.history.forEach(item => {
          if (item.role === 'user') {
            appendUserMessage(item.content);
            conversationHistory.push(item);
          } else if (item.role === 'assistant') {
            const bubble = createAssistantMessageBubble();
            const contentEl = bubble.querySelector('.cc-ai-content');
            contentEl.innerHTML = renderMarkdown(item.content);
            renderMessageActions(bubble, item.content, '');
            if (item.follow_ups && Array.isArray(item.follow_ups) && item.follow_ups.length > 0) {
              renderFollowUpChips(bubble, item.follow_ups);
            }
            conversationHistory.push(item);
          }
        });
        scrollBottom();
      }
    } catch (e) {}
  }

  // Core Send Message Action
  async function sendMessage() {
    const text = input.value.trim();
    if (!text || isStreaming) return;

    if (welcomeCard && !welcomeCard.classList.contains('d-none')) {
      welcomeCard.classList.add('d-none');
    }

    // Reset input
    input.value = '';
    input.style.height = 'auto';

    // Append User Message to UI
    appendUserMessage(text);
    conversationHistory.push({ role: 'user', content: text });

    // Prepare Assistant Bubble for streaming typography
    const assistantBubble = createAssistantMessageBubble();
    startStreaming();

    activeAbortController = new AbortController();

    try {
      const response = await fetch('<?= e(url("api/ai/chat")) ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        credentials: 'same-origin',
        signal: activeAbortController.signal,
        body: JSON.stringify({
          prompt: text,
          history: conversationHistory.slice(-8)
        })
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || `Server returned error HTTP ${response.status}`);
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || 'Unable to process query');
      }

      // Update provider badge
      if (data.metadata && data.metadata.provider) {
        providerBadge.textContent = `${data.metadata.provider.toUpperCase()} · ${data.metadata.latency_ms}ms`;
      }

      // Stream typography effect into the bubble
      await streamTypography(assistantBubble, data.reply);
      conversationHistory.push({
        role: 'assistant',
        content: data.reply,
        follow_ups: data.follow_ups || []
      });

      // Render consequential action confirmation card if required
      if (data.confirmation_required && data.confirmation_token) {
        renderActionConfirmationCard(assistantBubble, data);
      }

      // Render message actions (feedback & copy)
      renderMessageActions(assistantBubble, data.reply, text);

      // Render contextual follow-up question chips
      if (data.follow_ups && Array.isArray(data.follow_ups) && data.follow_ups.length > 0) {
        renderFollowUpChips(assistantBubble, data.follow_ups);
      }

    } catch (err) {
      if (err.name === 'AbortError') {
        assistantBubble.querySelector('.cc-ai-content').innerHTML += ' *(generation stopped)*';
      } else {
        assistantBubble.querySelector('.cc-ai-content').innerHTML = `
          <div class="text-danger d-flex align-items-center gap-1.5 py-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            <span>${escapeHtml(err.message || 'Connection error')}</span>
          </div>`;
      }
    } finally {
      finishStreaming();
      activeAbortController = null;
    }
  }

  // Append User Bubble
  function appendUserMessage(text) {
    const row = document.createElement('div');
    row.className = 'cc-ai-msg-row cc-ai-msg-user';
    row.innerHTML = `<div class="cc-ai-msg-bubble">${escapeHtml(text)}</div>`;
    messagesBox.appendChild(row);
    scrollBottom();
  }

  // Create Assistant Bubble with Cursor
  function createAssistantMessageBubble() {
    const row = document.createElement('div');
    row.className = 'cc-ai-msg-row cc-ai-msg-assistant';
    row.innerHTML = `
      <div class="cc-ai-msg-bubble">
        <div class="cc-ai-content"><span class="cc-ai-cursor"></span></div>
      </div>`;
    messagesBox.appendChild(row);
    scrollBottom();
    return row;
  }

  // Render Feedback and Copy Action Bar
  function renderMessageActions(bubbleRow, rawReply, promptText) {
    const existing = bubbleRow.querySelector('.cc-ai-msg-actions');
    if (existing) return;

    const bubbleEl = bubbleRow.querySelector('.cc-ai-msg-bubble');
    if (!bubbleEl) return;

    const actionsEl = document.createElement('div');
    actionsEl.className = 'cc-ai-msg-actions';
    actionsEl.innerHTML = `
      <button type="button" class="cc-ai-action-btn cc-ai-fb-btn" data-rating="helpful" title="Helpful response" aria-label="Helpful">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h3"/><path d="M15 5.88V4a2 2 0 0 0-2-2h-.28a2 2 0 0 0-2 1.7l-.56 4.18"/></svg>
      </button>
      <button type="button" class="cc-ai-action-btn cc-ai-fb-btn" data-rating="unhelpful" title="Unhelpful response" aria-label="Unhelpful">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-3"/><path d="M9 18.12V20a2 2 0 0 0 2 2h.28a2 2 0 0 0 2-1.7l.56-4.18"/></svg>
      </button>
      <button type="button" class="cc-ai-action-btn cc-ai-fb-btn" data-rating="inaccurate" title="Report inaccurate data" aria-label="Report inaccurate">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>
      </button>
      <button type="button" class="cc-ai-action-btn cc-ai-copy-btn" title="Copy answer" aria-label="Copy answer">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
      </button>
    `;
    bubbleEl.appendChild(actionsEl);

    // Feedback buttons listener
    actionsEl.querySelectorAll('.cc-ai-fb-btn').forEach(btn => {
      btn.addEventListener('click', async function() {
        const rating = this.getAttribute('data-rating');
        actionsEl.querySelectorAll('.cc-ai-fb-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');

        try {
          await fetch('<?= e(url("api/ai/chat/feedback")) ?>', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'same-origin',
            body: JSON.stringify({ rating, prompt: promptText })
          });
        } catch (e) {}
      });
    });

    // Copy button listener
    const copyBtn = actionsEl.querySelector('.cc-ai-copy-btn');
    if (copyBtn) {
      copyBtn.addEventListener('click', async function() {
        try {
          await navigator.clipboard.writeText(rawReply);
          const original = this.innerHTML;
          this.innerHTML = '<span style="font-size: 10px; font-weight: 700; color: #10b981;">Copied!</span>';
          setTimeout(() => { this.innerHTML = original; }, 1800);
        } catch (e) {}
      });
    }
  }

  // Render Contextual Follow-Up Question Chips
  function renderFollowUpChips(bubbleRow, followUps) {
    if (!followUps || followUps.length === 0) return;

    const wrap = document.createElement('div');
    wrap.className = 'cc-ai-followups-wrap';

    let chipsHtml = '<div class="cc-ai-followups-label">Suggested follow-ups:</div><div class="cc-ai-followups-chips">';
    followUps.forEach(q => {
      chipsHtml += `<button type="button" class="cc-ai-followup-chip" data-followup="${escapeHtml(q)}">${escapeHtml(q)}</button>`;
    });
    chipsHtml += '</div>';

    wrap.innerHTML = chipsHtml;
    bubbleRow.appendChild(wrap);

    // Attach click listeners to chips
    wrap.querySelectorAll('.cc-ai-followup-chip').forEach(btn => {
      btn.addEventListener('click', function() {
        const q = this.getAttribute('data-followup');
        if (q) {
          input.value = q;
          sendMessage();
        }
      });
    });

    scrollBottom();
  }

  // Render Consequential Action Confirmation Card
  function renderActionConfirmationCard(bubbleRow, data) {
    const bubbleEl = bubbleRow.querySelector('.cc-ai-msg-bubble');
    if (!bubbleEl) return;

    const card = document.createElement('div');
    card.className = 'cc-ai-confirm-card mt-2 p-2.5 rounded border border-warning-subtle bg-warning-subtle text-dark';
    card.style.fontSize = '12px';
    card.innerHTML = `
      <div class="d-flex align-items-center gap-1.5 fw-semibold text-warning-emphasis mb-1">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <span>Confirmation Required: ${escapeHtml(data.action_title || 'Administrative Action')}</span>
      </div>
      <div class="mb-2 text-muted-emphasis">${escapeHtml(data.summary || 'Please confirm execution.')}</div>
      <div class="d-flex gap-2">
        <button type="button" class="btn btn-sm btn-success cc-btn-confirm-exec d-flex align-items-center gap-1 py-1 px-2.5" style="font-size: 11px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          Confirm & Execute
        </button>
        <button type="button" class="btn btn-sm btn-outline-secondary cc-btn-cancel-exec py-1 px-2.5" style="font-size: 11px;">
          Dismiss
        </button>
      </div>
      <div class="cc-ai-confirm-status mt-2 d-none"></div>
    `;

    const confirmBtn = card.querySelector('.cc-btn-confirm-exec');
    const cancelBtn = card.querySelector('.cc-btn-cancel-exec');
    const statusDiv = card.querySelector('.cc-ai-confirm-status');

    cancelBtn.addEventListener('click', () => {
      card.remove();
    });

    confirmBtn.addEventListener('click', async () => {
      confirmBtn.disabled = true;
      cancelBtn.disabled = true;
      confirmBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Executing...';

      try {
        const res = await fetch('<?= e(url("api/ai/action/execute")) ?>', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          credentials: 'same-origin',
          body: JSON.stringify({ confirmation_token: data.confirmation_token })
        });

        const resData = await res.json();
        if (resData.success) {
          card.classList.remove('bg-warning-subtle', 'border-warning-subtle');
          card.classList.add('bg-success-subtle', 'border-success-subtle');
          card.innerHTML = `
            <div class="text-success-emphasis fw-semibold d-flex align-items-center gap-1.5 mb-1">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              <span>Action Successfully Executed</span>
            </div>
            <div class="text-secondary" style="font-size: 11.5px;">${escapeHtml(resData.message || 'Operation completed.')}</div>
          `;
        } else {
          statusDiv.classList.remove('d-none');
          statusDiv.innerHTML = `<span class="text-danger">${escapeHtml(resData.error || 'Execution failed.')}</span>`;
          confirmBtn.disabled = false;
          cancelBtn.disabled = false;
          confirmBtn.textContent = 'Retry';
        }
      } catch (err) {
        statusDiv.classList.remove('d-none');
        statusDiv.innerHTML = `<span class="text-danger">${escapeHtml(err.message || 'Network error.')}</span>`;
        confirmBtn.disabled = false;
        cancelBtn.disabled = false;
        confirmBtn.textContent = 'Retry';
      }
    });

    bubbleEl.appendChild(card);
    scrollBottom();
  }

  // Streaming Typography / Word-by-Word Rendering
  async function streamTypography(bubbleRow, markdownText) {
    const contentEl = bubbleRow.querySelector('.cc-ai-content');
    const words = markdownText.split(/(\s+)/);
    let currentHtml = '';
    let accumulated = '';

    for (let i = 0; i < words.length; i++) {
      if (!isStreaming && activeAbortController === null) break;
      accumulated += words[i];

      // Re-render markdown progressively
      currentHtml = renderMarkdown(accumulated);
      contentEl.innerHTML = currentHtml + '<span class="cc-ai-cursor"></span>';
      scrollBottom();

      // Typing Cadence (15-20ms per word)
      if (words[i].trim().length > 0) {
        await new Promise(r => setTimeout(r, 16));
      }
    }

    // Final clean render without cursor
    contentEl.innerHTML = renderMarkdown(markdownText);
    scrollBottom();
  }

  // Real-Time Markdown & Table Parser (Vanilla JS)
  function renderMarkdown(raw) {
    if (!raw) return '';
    let out = escapeHtml(raw);

    // Verified Institutional Record Badge
    out = out.replace(/\[VERIFIED_RECORD\]/g, '<div class="cc-ai-verified-badge"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg> Verified Institutional Record</div>');

    // Markdown Table Blocks
    out = parseMarkdownTables(out);

    // Headers: ### Head
    out = out.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    out = out.replace(/^#### (.*$)/gim, '<h4>$1</h4>');

    // Bold: **text**
    out = out.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Italics: *text*
    out = out.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Code: `text`
    out = out.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Status Badges
    out = out.replace(/\[PAID\]/gi, '<span class="cc-ai-status-badge cc-badge-paid">PAID</span>');
    out = out.replace(/\[UNPAID\]/gi, '<span class="cc-ai-status-badge cc-badge-unpaid">UNPAID</span>');
    out = out.replace(/\[OVERDUE\]/gi, '<span class="cc-ai-status-badge cc-badge-overdue">OVERDUE</span>');
    out = out.replace(/\[PARTIAL\]/gi, '<span class="cc-ai-status-badge cc-badge-partial">PARTIAL</span>');

    // Bullet Lists: - item
    out = out.replace(/^\s*-\s+(.*$)/gim, '<li>$1</li>');
    out = out.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');

    // Line breaks
    out = out.replace(/\n\n/g, '<p></p>');
    out = out.replace(/\n/g, '<br>');

    // Links: [Text](URL)
    out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    return out;
  }

  // Parse Markdown Tables
  function parseMarkdownTables(text) {
    const tableRegex = /((?:\|[^\n]+\|\r?\n)(?:\|[-: |]+\|\r?\n)(?:\|[^\n]+\|\r?\n?)+)/g;
    return text.replace(tableRegex, function(match) {
      const lines = match.trim().split(/\r?\n/);
      if (lines.length < 2) return match;

      const headerLine = lines[0];
      const headers = headerLine.split('|').slice(1, -1).map(h => h.trim());

      let html = '<div class="cc-ai-table-wrap"><table class="cc-ai-table"><thead><tr>';
      headers.forEach(h => {
        html += `<th>${h}</th>`;
      });
      html += '</tr></thead><tbody>';

      // Skip lines[1] which is the delimiter (|---|---|)
      for (let i = 2; i < lines.length; i++) {
        const rowLine = lines[i];
        if (!rowLine.includes('|')) continue;
        const cells = rowLine.split('|').slice(1, -1).map(c => c.trim());
        html += '<tr>';
        cells.forEach(c => {
          html += `<td>${c}</td>`;
        });
        html += '</tr>';
      }
      html += '</tbody></table></div>';
      return html;
    });
  }

  function startStreaming() {
    isStreaming = true;
    streamingBar.classList.remove('d-none');
    sendBtn.disabled = true;
  }

  function finishStreaming() {
    isStreaming = false;
    streamingBar.classList.add('d-none');
    sendBtn.disabled = false;
    input.focus();
  }

  function scrollBottom() {
    messagesBox.scrollTop = messagesBox.scrollHeight;
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

})();
</script>
