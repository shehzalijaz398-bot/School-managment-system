﻿<?php
$flashError   = flash('error');
$flashSuccess = flash('success');
$flashInfo    = flash('info');
$flashWarning = flash('warning');
?>
<?php if ($flashError): ?>
<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
  <i data-lucide="alert-circle" class="alert-icon" style="width:17px;height:17px;"></i>
  <div class="flex-grow-1"><?= e($flashError) ?></div>
  <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if ($flashSuccess): ?>
<div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
  <i data-lucide="check-circle-2" class="alert-icon" style="width:17px;height:17px;"></i>
  <div class="flex-grow-1"><?= e($flashSuccess) ?></div>
  <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if ($flashInfo): ?>
<div class="alert alert-info alert-dismissible fade show mb-3" role="alert">
  <i data-lucide="info" class="alert-icon" style="width:17px;height:17px;"></i>
  <div class="flex-grow-1"><?= e($flashInfo) ?></div>
  <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if ($flashWarning): ?>
<div class="alert alert-warning alert-dismissible fade show mb-3" role="alert">
  <i data-lucide="alert-triangle" class="alert-icon" style="width:17px;height:17px;"></i>
  <div class="flex-grow-1"><?= e($flashWarning) ?></div>
  <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>