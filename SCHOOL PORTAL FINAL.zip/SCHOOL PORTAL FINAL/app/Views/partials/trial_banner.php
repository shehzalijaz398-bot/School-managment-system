<?php
/**
 * Trial Status Banner Partial for School Portal
 * Displays authoritative server-side trial remaining days and upgrade CTAs.
 */

$schoolInfo = currentSchool();
if (!$schoolInfo) {
    return;
}

$subStatus = $schoolInfo['subscription_status'] ?? 'active';

// Only render banner if the school is on an active trial
if ($subStatus !== 'trial' || empty($schoolInfo['trial_ends_at'])) {
    return;
}

$now = time();
$trialEnd = strtotime($schoolInfo['trial_ends_at']);
$remainingSec = max(0, $trialEnd - $now);
$remainingDays = (int) ceil($remainingSec / 86400);

$isExpiringSoon = ($remainingDays <= 7);
$bannerClass = $isExpiringSoon ? 'border-warning bg-warning-subtle text-dark' : 'border-primary-subtle bg-primary-subtle text-dark';
$iconColor = $isExpiringSoon ? '#d97706' : '#2563eb';
?>

<div class="alert <?= $bannerClass ?> border d-flex align-items-center justify-content-between flex-wrap gap-3 py-2.5 px-3 mb-4 rounded-3 shadow-xs" id="schoolTrialBanner">
  <div class="d-flex align-items-center gap-2.5">
    <div class="d-inline-flex align-items-center justify-content-center p-2 rounded-circle" style="background: rgba(255,255,255,0.8);">
      <i data-lucide="<?= $isExpiringSoon ? 'alert-triangle' : 'clock' ?>" style="width: 18px; height: 18px; color: <?= $iconColor ?>;"></i>
    </div>
    <div>
      <div class="fw-bold small" style="font-size: 13.5px; line-height: 1.3;">
        <?php if ($isExpiringSoon && $remainingDays > 0): ?>
          Your trial expires soon. Choose a plan to continue without interruption.
        <?php elseif ($remainingDays > 0): ?>
          Your free trial is active.
        <?php else: ?>
          Your free trial has expired today.
        <?php endif; ?>
      </div>
      <div class="text-secondary small" style="font-size: 12px;">
        <?php if ($remainingDays > 0): ?>
          <strong><?= $remainingDays ?> day<?= $remainingDays !== 1 ? 's' : '' ?> remaining</strong> in your 30-day evaluation period (concludes <?= date('M d, Y', $trialEnd) ?>).
        <?php else: ?>
          Trial concluded on <?= date('M d, Y', $trialEnd) ?>. Please select a paid plan to maintain full operational access.
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="d-flex align-items-center gap-2">
    <a href="<?= e(url('subscription')) ?>" class="btn btn-sm <?= $isExpiringSoon ? 'btn-warning' : 'btn-primary' ?> fw-semibold py-1.5 px-3 d-inline-flex align-items-center gap-1.5" style="border-radius: 6px; font-size: 12.5px;">
      <i data-lucide="sparkles" style="width: 14px; height: 14px;"></i>
      <span><?= $isExpiringSoon ? 'Subscribe Now' : 'View Plans' ?></span>
    </a>
  </div>
</div>
