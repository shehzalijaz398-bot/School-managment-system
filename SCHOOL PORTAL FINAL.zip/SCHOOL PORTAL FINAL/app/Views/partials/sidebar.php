<?php
$school    = currentSchool();
$brandName = $school['name'] ?? 'CodeClove';
$rawUri    = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$current   = trim($rawUri, '/');

// Helper to check if any path matches current
if (!function_exists('isCcActive')) {
    function isCcActive(string $current, string $path): bool {
        $pathClean = trim($path, '/');
        if ($pathClean === '' || $pathClean === 'dashboard') {
            return str_contains($current, 'dashboard') || $current === '' || str_ends_with($current, '/public');
        }
        return str_contains($current, $pathClean);
    }
}

// Group active checks
$isAcademicsActive  = isCcActive($current, 'academic-sessions') || isCcActive($current, 'classes') || isCcActive($current, 'sections') || isCcActive($current, 'subjects') || isCcActive($current, 'timetable') || isCcActive($current, 'assignments') || isCcActive($current, 'calendar') || isCcActive($current, 'events');
$isStudentsActive   = (isCcActive($current, 'students') && !isCcActive($current, 'attendance/students') && !isCcActive($current, 'academic/promotion')) || isCcActive($current, 'admissions') || isCcActive($current, 'attendance/students') || isCcActive($current, 'academic/promotion') || isCcActive($current, 'discipline') || isCcActive($current, 'certificates') || isCcActive($current, 'identity/cards');
$isExamsActive      = isCcActive($current, 'exams');
$isStaffActive      = isCcActive($current, 'hr') || isCcActive($current, 'staff') || isCcActive($current, 'attendance/staff') || isCcActive($current, 'users') || isCcActive($current, 'roles');
$isFinanceActive    = isCcActive($current, 'finance') || isCcActive($current, 'reports/fees');
$isOperationsActive = isCcActive($current, 'inventory') || isCcActive($current, 'hostels') || isCcActive($current, 'library') || isCcActive($current, 'transport') || isCcActive($current, 'reception') || isCcActive($current, 'documents') || isCcActive($current, 'facilities');
$isCommunityActive  = isCcActive($current, 'alumni') || isCcActive($current, 'ptm') || isCcActive($current, 'announcements') || isCcActive($current, 'noticeboard') || isCcActive($current, 'communication') || isCcActive($current, 'support');
$isReportsActive    = isCcActive($current, 'reports') && !isCcActive($current, 'reports/fees');
$isAnalyticsActive  = isCcActive($current, 'analytics');
$isSettingsActive   = isCcActive($current, 'settings') || isCcActive($current, 'school/profile') || isCcActive($current, 'audit') || isCcActive($current, 'onboarding/wizard') || isCcActive($current, 'school/health');
$isLeaveActive      = isCcActive($current, 'leave') || isCcActive($current, 'leaves');
$isDashboardActive  = isCcActive($current, 'dashboard') && !$isAcademicsActive && !$isStudentsActive && !$isExamsActive && !$isStaffActive && !$isFinanceActive && !$isOperationsActive && !$isCommunityActive && !$isReportsActive && !$isSettingsActive && !$isLeaveActive && !$isAnalyticsActive;
?>

<?php
$userRole = \Core\Auth::roleSlug();
$isStudent = ($userRole === 'student');
$isParent = ($userRole === 'parent');
$isPortalUser = ($isStudent || $isParent);
$isAccountant = in_array($userRole, ['accountant', 'finance'], true);
$isTeacher = ($userRole === 'teacher');
$isAdmissionsOfficer = in_array($userRole, ['admissions_officer', 'admissions'], true);

$portalBrandTitle = $isParent ? 'Parent Portal' : ($isStudent ? 'Student Portal' : (!empty($school['name']) ? $school['name'] : 'CodeClove'));

$schoolLogoUrl = null;
if (!empty($school['logo'])) {
    $rawLogo = trim((string)$school['logo']);
    if (str_starts_with($rawLogo, 'http://') || str_starts_with($rawLogo, 'https://')) {
        $schoolLogoUrl = $rawLogo;
    } else {
        $cleanPath = ltrim($rawLogo, '/');
        $schoolLogoUrl = url($cleanPath);
    }
}
?>

<aside class="sidebar cc-sidebar" id="appSidebar">
  <!-- Brand Header -->
  <div class="cc-brand">
    <a href="<?= e(url('dashboard')) ?>" class="d-flex align-items-center gap-2 text-decoration-none">
      <div class="cc-brand-logo <?= $schoolLogoUrl ? 'has-custom-logo' : '' ?>" style="<?= $schoolLogoUrl ? 'background: transparent !important; border-radius: 8px !important; padding: 2px;' : ($isPortalUser ? 'background-color: #4f46e5 !important;' : '') ?>">
        <?php if ($schoolLogoUrl): ?>
          <img id="sidebarBrandLogoImg" src="<?= e($schoolLogoUrl) ?>" alt="<?= e($brandName) ?>" style="width: 100%; height: 100%; max-width: 36px; max-height: 36px; object-fit: contain; border-radius: 6px; display: block;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='block';">
          <svg style="display:none;" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="<?= $isPortalUser ? '#ffffff' : '#2563eb' ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"></path>
            <path d="M6 6h10"></path>
            <path d="M6 10h10"></path>
          </svg>
        <?php else: ?>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="<?= $isPortalUser ? '#ffffff' : '#2563eb' ?>" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"></path>
            <path d="M6 6h10"></path>
            <path d="M6 10h10"></path>
          </svg>
        <?php endif; ?>
      </div>
      <div class="cc-brand-info">
        <div class="cc-brand-title"><?= e($portalBrandTitle) ?></div>
        <?php if (!$isPortalUser): ?>
          <div class="cc-brand-subtitle">School Management</div>
        <?php endif; ?>
      </div>
    </a>
    <!-- Mobile Drawer Close Button -->
    <button type="button" id="sidebarCloseBtn" class="cc-icon-btn d-lg-none ms-auto" aria-label="Close navigation drawer" style="width: 34px; height: 34px; min-width: 34px;">
      <i data-lucide="x" style="width: 18px; height: 18px;"></i>
    </button>
  </div>

  <!-- Navigation Menu -->
  <nav class="cc-nav">
  <?php if ($isPortalUser): ?>
    <!-- Student / Parent Portal Navigation -->
    <?php
      $isPortalAttendance = isCcActive($current, 'attendance') || isCcActive($current, 'portal/attendance');
      $isPortalFinance = isCcActive($current, 'finance') || isCcActive($current, 'portal/finance');
      $isPortalTimetable = isCcActive($current, 'timetable') || isCcActive($current, 'portal/timetable');
      $isPortalAcademics = isCcActive($current, 'academics') || isCcActive($current, 'portal/academics') || isCcActive($current, 'subjects') || isCcActive($current, 'student/academics');
      $isPortalNotifications = isCcActive($current, 'notifications') || isCcActive($current, 'portal/notifications') || isCcActive($current, 'announcements') || isCcActive($current, 'student/notifications');
      $isPortalProfile = isCcActive($current, 'profile') || isCcActive($current, 'portal/profile') || isCcActive($current, 'student/profile');
      $isPortalAssignments = isCcActive($current, 'assignments') || isCcActive($current, 'portal/assignments') || isCcActive($current, 'parent/assignments');
      $isPortalLeaves = isCcActive($current, 'leaves') || isCcActive($current, 'portal/leaves') || isCcActive($current, 'leave');
      $isPortalResources = isCcActive($current, 'resources') || isCcActive($current, 'portal/resources');
      $isPortalMessages = isCcActive($current, 'messages') || isCcActive($current, 'parent/messages');
      $isPortalDashboard = $isDashboardActive && !$isPortalAttendance && !$isPortalLeaves && !$isPortalFinance && !$isPortalTimetable && !$isPortalAcademics && !$isPortalAssignments && !$isPortalNotifications && !$isPortalProfile && !$isPortalResources && !$isPortalMessages;
    ?>
    <a class="cc-nav-item <?= $isPortalDashboard ? 'active' : '' ?>" href="<?= e(url('dashboard')) ?>" title="Dashboard" style="<?= $isPortalDashboard ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="layout-grid" class="cc-nav-icon" style="<?= $isPortalDashboard ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Dashboard</span>
    </a>

    <a class="cc-nav-item <?= $isPortalAttendance ? 'active' : '' ?>" href="<?= e(url('portal/attendance')) ?>" title="Attendance" style="<?= $isPortalAttendance ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="calendar" class="cc-nav-icon" style="<?= $isPortalAttendance ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Attendance</span>
    </a>

    <a class="cc-nav-item <?= $isPortalLeaves ? 'active' : '' ?>" href="<?= e(url('portal/leaves')) ?>" title="Leave Applications" style="<?= $isPortalLeaves ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="calendar-x-2" class="cc-nav-icon" style="<?= $isPortalLeaves ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Leave Applications</span>
    </a>

    <a class="cc-nav-item <?= $isPortalFinance ? 'active' : '' ?>" href="<?= e(url('portal/finance')) ?>" title="Finance" style="<?= $isPortalFinance ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="credit-card" class="cc-nav-icon" style="<?= $isPortalFinance ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Finance &amp; Fees</span>
    </a>

    <a class="cc-nav-item <?= $isPortalTimetable ? 'active' : '' ?>" href="<?= e(url('portal/timetable')) ?>" title="Timetable" style="<?= $isPortalTimetable ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="clock" class="cc-nav-icon" style="<?= $isPortalTimetable ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Timetable</span>
    </a>

    <a class="cc-nav-item <?= $isPortalAcademics ? 'active' : '' ?>" href="<?= e(url('portal/academics')) ?>" title="Academics" style="<?= $isPortalAcademics ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="graduation-cap" class="cc-nav-icon" style="<?= $isPortalAcademics ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Academics</span>
    </a>

    <a class="cc-nav-item <?= $isPortalAssignments ? 'active' : '' ?>" href="<?= e(url('portal/assignments')) ?>" title="Home Tasks &amp; Diary" style="<?= $isPortalAssignments ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="book-marked" class="cc-nav-icon" style="<?= $isPortalAssignments ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Home Tasks (Diary)</span>
    </a>

    <a class="cc-nav-item <?= $isPortalResources ? 'active' : '' ?>" href="<?= e(url('portal/resources')) ?>" title="Learning Resources" style="<?= $isPortalResources ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="folder-down" class="cc-nav-icon" style="<?= $isPortalResources ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Study Resources</span>
    </a>

    <a class="cc-nav-item <?= $isPortalMessages ? 'active' : '' ?>" href="<?= e(url('parent/messages')) ?>" title="Teacher Messages" style="<?= $isPortalMessages ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="message-square" class="cc-nav-icon" style="<?= $isPortalMessages ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Teacher Chat</span>
    </a>

    <a class="cc-nav-item <?= $isPortalNotifications ? 'active' : '' ?>" href="<?= e(url('portal/notifications')) ?>" title="Notifications" style="<?= $isPortalNotifications ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="bell" class="cc-nav-icon" style="<?= $isPortalNotifications ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Notifications</span>
    </a>

    <a class="cc-nav-item <?= $isPortalProfile ? 'active' : '' ?>" href="<?= e(url('portal/profile')) ?>" title="Profile" style="<?= $isPortalProfile ? 'background: #4f46e5 !important; color: #ffffff !important; border-radius: 8px;' : '' ?>">
      <i data-lucide="user" class="cc-nav-icon" style="<?= $isPortalProfile ? 'stroke: #ffffff !important;' : '' ?>"></i>
      <span class="cc-nav-text">Profile</span>
    </a>

  <?php else: ?>
    <!-- 1. Dashboard -->
    <a class="cc-nav-item <?= $isDashboardActive ? 'active' : '' ?>" href="<?= e(url('dashboard')) ?>" title="Dashboard">
      <i data-lucide="layout-grid" class="cc-nav-icon"></i>
      <span class="cc-nav-text">Dashboard</span>
    </a>

    <!-- Task Center & Action Items -->
    <?php $isTasksActive = isCcActive($current, 'tasks'); ?>
    <a class="cc-nav-item <?= $isTasksActive ? 'active' : '' ?>" href="<?= e(url('tasks')) ?>" title="Central Task Center & Action Items">
      <i data-lucide="check-square" class="cc-nav-icon"></i>
      <span class="cc-nav-text">Task Center</span>
    </a>

    <!-- 2. Academics (Accordion) -->
    <div class="cc-nav-group <?= $isAcademicsActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isAcademicsActive ? 'header-active' : '' ?>" data-target="grp-academics">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="graduation-cap" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Academics</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isAcademicsActive ? 'show' : '' ?>" id="grp-academics">
        <a class="cc-sub-item <?= isCcActive($current, 'academic-sessions') ? 'active' : '' ?>" href="<?= e(url('academic-sessions')) ?>">
          <i data-lucide="calendar-days" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Academic Sessions</span>
        </a>
        <a class="cc-sub-item <?= (isCcActive($current, 'classes') && !isCcActive($current, 'sections') && !isCcActive($current, 'subjects')) ? 'active' : '' ?>" href="<?= e(url('classes')) ?>">
          <i data-lucide="layers" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Academic Units</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'sections') ? 'active' : '' ?>" href="<?= e(url('sections')) ?>">
          <i data-lucide="grid" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Academic Groups</span>
        </a>
        <?php if (!$isAccountant && !$isAdmissionsOfficer): ?>
          <a class="cc-sub-item <?= isCcActive($current, 'subjects') ? 'active' : '' ?>" href="<?= e(url('subjects')) ?>">
            <i data-lucide="book-open" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Subjects</span>
          </a>
          <a class="cc-sub-item <?= isCcActive($current, 'timetable') ? 'active' : '' ?>" href="<?= e(url('timetable')) ?>">
            <i data-lucide="clock" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Timetable</span>
          </a>
          <a class="cc-sub-item <?= isCcActive($current, 'assignments') ? 'active' : '' ?>" href="<?= e(url('assignments')) ?>">
            <i data-lucide="book-marked" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Home Tasks &amp; Diary</span>
          </a>
          <a class="cc-sub-item <?= isCcActive($current, 'resources') ? 'active' : '' ?>" href="<?= e(url('resources')) ?>">
            <i data-lucide="folder-down" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Class Study Materials</span>
          </a>
          <a class="cc-sub-item <?= (isCcActive($current, 'calendar') || isCcActive($current, 'events')) ? 'active' : '' ?>" href="<?= e(url('calendar')) ?>">
            <i data-lucide="calendar-range" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Calendar &amp; Events</span>
          </a>
        <?php endif; ?>
      </div>
    </div>

    <!-- 3. Students (Accordion) -->
    <div class="cc-nav-group <?= $isStudentsActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isStudentsActive ? 'header-active' : '' ?>" data-target="grp-students">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="users" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Students</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isStudentsActive ? 'show' : '' ?>" id="grp-students">
        <a class="cc-sub-item <?= (isCcActive($current, 'students') && !isCcActive($current, 'attendance') && !isCcActive($current, 'admissions')) ? 'active' : '' ?>" href="<?= e(url('students')) ?>">
          <i data-lucide="users" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Student Directory</span>
        </a>
        <?php if (!$isAccountant && !$isTeacher): ?>
          <a class="cc-sub-item <?= isCcActive($current, 'admissions') ? 'active' : '' ?>" href="<?= e(url('admissions')) ?>">
            <i data-lucide="user-plus" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Admissions</span>
          </a>
        <?php endif; ?>
        <?php if (!$isAdmissionsOfficer): ?>
          <a class="cc-sub-item <?= isCcActive($current, 'attendance/students') ? 'active' : '' ?>" href="<?= e(url('attendance/students')) ?>">
            <i data-lucide="check-circle-2" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Student Attendance</span>
          </a>
          <?php if (!$isAccountant && !$isTeacher): ?>
            <a class="cc-sub-item <?= isCcActive($current, 'academic/promotion') ? 'active' : '' ?>" href="<?= e(url('academic/promotion')) ?>">
              <i data-lucide="arrow-up-right" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
              <span>Promotion &amp; Rollover</span>
            </a>
          <?php endif; ?>
          <a class="cc-sub-item <?= isCcActive($current, 'discipline') ? 'active' : '' ?>" href="<?= e(url('discipline/logs')) ?>">
            <i data-lucide="alert-circle" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Discipline &amp; Conduct</span>
          </a>
          <a class="cc-sub-item <?= isCcActive($current, 'certificates') ? 'active' : '' ?>" href="<?= e(url('certificates')) ?>">
            <i data-lucide="file-badge" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Certificates &amp; TC</span>
          </a>
          <a class="cc-sub-item <?= isCcActive($current, 'identity/cards') ? 'active' : '' ?>" href="<?= e(url('identity/cards')) ?>">
            <i data-lucide="id-card" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Student &amp; Staff ID Badges</span>
          </a>
        <?php endif; ?>
      </div>
    </div>

    <!-- 4. Examinations (Accordion) - Available for Teachers & Admins -->
    <?php if (!$isAccountant && !$isAdmissionsOfficer): ?>
    <div class="cc-nav-group <?= $isExamsActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isExamsActive ? 'header-active' : '' ?>" data-target="grp-exams">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="file-check-2" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Examinations</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isExamsActive ? 'show' : '' ?>" id="grp-exams">
        <a class="cc-sub-item <?= (isCcActive($current, 'exams') && !isCcActive($current, 'analytics')) ? 'active' : '' ?>" href="<?= e(url('exams')) ?>">
          <i data-lucide="award" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Exams &amp; Gradebook</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'exams/analytics') ? 'active' : '' ?>" href="<?= e(url('exams/analytics')) ?>">
          <i data-lucide="trending-up" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Report Cards &amp; Positions</span>
        </a>
      </div>
    </div>
    <?php endif; ?>

    <!-- 5. Staff & HR (Accordion) - Hidden for Accountant, Teacher & Admissions Officer -->
    <?php if (!$isAccountant && !$isTeacher && !$isAdmissionsOfficer && (hasPermission('employees.manage') || hasPermission('employees.view'))): ?>
    <div class="cc-nav-group <?= $isStaffActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isStaffActive ? 'header-active' : '' ?>" data-target="grp-staff">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="user-cog" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Staff &amp; HR</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isStaffActive ? 'show' : '' ?>" id="grp-staff">
        <a class="cc-sub-item <?= isCcActive($current, 'hr/dashboard') ? 'active' : '' ?>" href="<?= e(url('hr/dashboard')) ?>">
          <i data-lucide="layout-dashboard" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>HR Dashboard</span>
        </a>
        <a class="cc-sub-item <?= (isCcActive($current, 'hr/employees') || isCcActive($current, 'staff')) && !isCcActive($current, 'hr/dashboard') && !isCcActive($current, 'hr/shifts') && !isCcActive($current, 'hr/holidays') && !isCcActive($current, 'hr/performance') && !isCcActive($current, 'hr/trainings') && !isCcActive($current, 'hr/tasks') ? 'active' : '' ?>" href="<?= e(url('hr/employees')) ?>">
          <i data-lucide="briefcase" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Staff Directory</span>
        </a>
        <a class="cc-sub-item <?= (isCcActive($current, 'attendance/staff') || isCcActive($current, 'staff/attendance')) ? 'active' : '' ?>" href="<?= e(url('attendance/staff')) ?>">
          <i data-lucide="user-check" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Staff Attendance</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/shifts') ? 'active' : '' ?>" href="<?= e(url('hr/shifts')) ?>">
          <i data-lucide="clock" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Staff Shifts</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/holidays') ? 'active' : '' ?>" href="<?= e(url('hr/holidays')) ?>">
          <i data-lucide="calendar" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Holiday Calendar</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/performance') ? 'active' : '' ?>" href="<?= e(url('hr/performance')) ?>">
          <i data-lucide="award" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Performance Appraisals</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/trainings') ? 'active' : '' ?>" href="<?= e(url('hr/trainings')) ?>">
          <i data-lucide="graduation-cap" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Staff Training</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/tasks') ? 'active' : '' ?>" href="<?= e(url('hr/tasks')) ?>">
          <i data-lucide="check-square" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Staff Tasks</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/candidates') ? 'active' : '' ?>" href="<?= e(url('hr/candidates')) ?>">
          <i data-lucide="user-plus" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Recruitment &amp; Candidates</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hr/salary-structures') ? 'active' : '' ?>" href="<?= e(url('hr/salary-structures')) ?>">
          <i data-lucide="calculator" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Salary Structures</span>
        </a>
        <a class="cc-sub-item <?= (isCcActive($current, 'users') || isCcActive($current, 'staff/roles') || isCcActive($current, 'roles')) ? 'active' : '' ?>" href="<?= e(url('staff/roles')) ?>">
          <i data-lucide="shield" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Roles &amp; Permissions</span>
        </a>
      </div>
    </div>
    <?php endif; ?>

    <!-- 6. Finance & Accounts (Accordion) - Hidden for Teacher & Admissions Officer -->
    <?php if (!$isTeacher && !$isAdmissionsOfficer): ?>
    <div class="cc-nav-group <?= $isFinanceActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isFinanceActive ? 'header-active' : '' ?>" data-target="grp-finance">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="receipt" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Finance</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isFinanceActive ? 'show' : '' ?>" id="grp-finance">
        <?php 
          $isFeeTypes = isCcActive($current, 'finance/fee-types');
          $isInvoices = isCcActive($current, 'finance/invoices');
          $isPayments = isCcActive($current, 'finance/ledger') || isCcActive($current, 'finance/payments');
          $isExpenses = isCcActive($current, 'finance/expenses');
          $isIncomes = isCcActive($current, 'finance/incomes');
          $isPayroll = isCcActive($current, 'finance/payroll');
          $isDefaulters = isCcActive($current, 'reports/fees') || isCcActive($current, 'finance/defaulters') || isCcActive($current, 'finance/reports/defaulters');
          $isOverview = !$isFeeTypes && !$isInvoices && !$isPayments && !$isExpenses && !$isIncomes && !$isPayroll && !$isDefaulters && (isCcActive($current, 'finance') || isCcActive($current, 'finance/overview') || isCcActive($current, 'finance/analytics'));
        ?>
        <a class="cc-sub-item <?= $isOverview ? 'active' : '' ?>" href="<?= e(url('finance')) ?>">
          <i data-lucide="bar-chart-2" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Overview</span>
        </a>
        <a class="cc-sub-item <?= $isFeeTypes ? 'active' : '' ?>" href="<?= e(url('finance/fee-types')) ?>">
          <i data-lucide="tag" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Fee Types</span>
        </a>
        <a class="cc-sub-item <?= $isInvoices ? 'active' : '' ?>" href="<?= e(url('finance/invoices')) ?>">
          <i data-lucide="file-text" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Invoices</span>
        </a>
        <a class="cc-sub-item <?= $isPayments ? 'active' : '' ?>" href="<?= e(url('finance/payments')) ?>">
          <i data-lucide="credit-card" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Payments</span>
        </a>
        <a class="cc-sub-item <?= $isExpenses ? 'active' : '' ?>" href="<?= e(url('finance/expenses')) ?>">
          <i data-lucide="trending-down" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Expenses</span>
        </a>
        <a class="cc-sub-item <?= $isIncomes ? 'active' : '' ?>" href="<?= e(url('finance/incomes')) ?>">
          <i data-lucide="trending-up" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Incomes</span>
        </a>
        <a class="cc-sub-item <?= $isPayroll ? 'active' : '' ?>" href="<?= e(url('finance/payroll')) ?>">
          <i data-lucide="banknote" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Payroll</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/reconciliation') ? 'active' : '' ?>" href="<?= e(url('finance/reconciliation')) ?>">
          <i data-lucide="scale" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Reconciliation</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/refunds') ? 'active' : '' ?>" href="<?= e(url('finance/refunds')) ?>">
          <i data-lucide="rotate-ccw" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Refunds</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/discounts') ? 'active' : '' ?>" href="<?= e(url('finance/discounts')) ?>">
          <i data-lucide="percent" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Discounts &amp; Awards</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/accounting') ? 'active' : '' ?>" href="<?= e(url('finance/accounting')) ?>">
          <i data-lucide="book-open" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Accounting (GL &amp; P&amp;L)</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/fee-structures') ? 'active' : '' ?>" href="<?= e(url('finance/fee-structures')) ?>">
          <i data-lucide="layers" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Fee Structures</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/concessions') ? 'active' : '' ?>" href="<?= e(url('finance/concessions')) ?>">
          <i data-lucide="award" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Concessions &amp; Waivers</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/vouchers') ? 'active' : '' ?>" href="<?= e(url('finance/vouchers')) ?>">
          <i data-lucide="file-check" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Payment Vouchers</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/budgets') ? 'active' : '' ?>" href="<?= e(url('finance/budgets')) ?>">
          <i data-lucide="pie-chart" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Department Budgets</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'finance/reminders') ? 'active' : '' ?>" href="<?= e(url('finance/reminders')) ?>">
          <i data-lucide="bell" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Fee Reminders</span>
        </a>
        <a class="cc-sub-item <?= $isDefaulters ? 'active' : '' ?>" href="<?= e(url('finance/reports/defaulters')) ?>">
          <i data-lucide="alert-triangle" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Defaulters Report</span>
        </a>
      </div>
    </div>
    <?php endif; ?>

    <!-- 7. Leave Management -->
    <a class="cc-nav-item <?= $isLeaveActive ? 'active' : '' ?>" href="<?= e(url('leave')) ?>" title="Leave Management">
      <i data-lucide="calendar-x-2" class="cc-nav-icon"></i>
      <span class="cc-nav-text">Leave Management</span>
    </a>

    <!-- 8. Operations & Facilities (Accordion) -->
    <?php if (!$isTeacher): ?>
    <div class="cc-nav-group <?= $isOperationsActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isOperationsActive ? 'header-active' : '' ?>" data-target="grp-operations">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="boxes" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Operations</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isOperationsActive ? 'show' : '' ?>" id="grp-operations">
        <a class="cc-sub-item <?= isCcActive($current, 'inventory') ? 'active' : '' ?>" href="<?= e(url('inventory')) ?>">
          <i data-lucide="box" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Inventory &amp; Assets</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'library') ? 'active' : '' ?>" href="<?= e(url('library')) ?>">
          <i data-lucide="book" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Library Management</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'transport') ? 'active' : '' ?>" href="<?= e(url('transport')) ?>">
          <i data-lucide="bus" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Transport &amp; Routes</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'hostels') ? 'active' : '' ?>" href="<?= e(url('hostels')) ?>">
          <i data-lucide="building-2" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Hostel &amp; Dormitory</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'reception') ? 'active' : '' ?>" href="<?= e(url('reception')) ?>">
          <i data-lucide="clipboard-list" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Reception &amp; Visitors</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'documents') ? 'active' : '' ?>" href="<?= e(url('documents')) ?>">
          <i data-lucide="folder-lock" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Document Center</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'facilities') ? 'active' : '' ?>" href="<?= e(url('facilities')) ?>">
          <i data-lucide="building" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Campus Facilities</span>
        </a>
      </div>
    </div>
    <?php endif; ?>

    <!-- 9. Community & Network (Accordion) -->
    <div class="cc-nav-group <?= $isCommunityActive ? 'is-open' : '' ?>">
      <button type="button" class="cc-nav-header <?= $isCommunityActive ? 'header-active' : '' ?>" data-target="grp-community">
        <div class="d-flex align-items-center gap-2">
          <i data-lucide="messages-square" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Community</span>
        </div>
        <i data-lucide="chevron-down" class="cc-nav-chevron"></i>
      </button>
      <div class="cc-nav-sub <?= $isCommunityActive ? 'show' : '' ?>" id="grp-community">
        <a class="cc-sub-item <?= isCcActive($current, 'announcements') ? 'active' : '' ?>" href="<?= e(url('announcements')) ?>">
          <i data-lucide="megaphone" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Noticeboard</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'alumni') ? 'active' : '' ?>" href="<?= e(url('alumni')) ?>">
          <i data-lucide="award" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Alumni Network</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'ptm') ? 'active' : '' ?>" href="<?= e(url('ptm/schedule')) ?>">
          <i data-lucide="calendar-check" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Parent-Teacher Meet (PTM)</span>
        </a>
        <a class="cc-sub-item <?= isCcActive($current, 'messages') ? 'active' : '' ?>" href="<?= e(url('parent/messages')) ?>">
          <i data-lucide="message-square" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Parent-Teacher Chat</span>
        </a>
        <?php if (!$isTeacher && !$isAccountant): ?>
          <a class="cc-sub-item <?= isCcActive($current, 'communication') ? 'active' : '' ?>" href="<?= e(url('communication/channels')) ?>">
            <i data-lucide="send" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
            <span>Broadcast Messaging</span>
          </a>
        <?php endif; ?>
        <a class="cc-sub-item <?= isCcActive($current, 'support') ? 'active' : '' ?>" href="<?= e(url('support')) ?>">
          <i data-lucide="help-circle" style="width:13px;height:13px;margin-right:6px;opacity:0.75;"></i>
          <span>Support Tickets</span>
        </a>
      </div>
    </div>

    <!-- Approvals & Workflows Hub -->
    <?php if (!$isTeacher && !$isAdmissionsOfficer): 
      $isWorkflowActive = isCcActive($current, 'workflows');
      $isAutomationActive = isCcActive($current, 'automations');
    ?>
      <a class="cc-nav-item <?= $isWorkflowActive ? 'active' : '' ?>" href="<?= e(url('workflows')) ?>" title="Approval Workflows">
        <i data-lucide="git-pull-request" class="cc-nav-icon"></i>
        <span class="cc-nav-text">Approval Workflows</span>
      </a>
      <a class="cc-nav-item <?= $isAutomationActive ? 'active' : '' ?>" href="<?= e(url('automations')) ?>" title="Workflow Automations">
        <i data-lucide="cpu" class="cc-nav-icon"></i>
        <span class="cc-nav-text">Workflow Automations</span>
      </a>
    <?php endif; ?>

    <!-- 10. AI Analytics & Business Intelligence -->
    <?php if (!$isPortalUser && !$isAdmissionsOfficer): ?>
      <a class="cc-nav-item <?= $isAnalyticsActive ? 'active' : '' ?>" href="<?= e(url('analytics/school')) ?>" title="Analytics &amp; AI Insights">
        <i data-lucide="sparkles" class="cc-nav-icon" style="color: #4f46e5;"></i>
        <span class="cc-nav-text">Analytics &amp; AI</span>
      </a>
      <a class="cc-nav-item <?= isCcActive($current, 'school/ai-intelligence') ? 'active' : '' ?>" href="<?= e(url('school/ai-intelligence')) ?>" title="AI Intelligence &amp; Predictive Analytics Cockpit">
        <i data-lucide="bot" class="cc-nav-icon" style="color: #6366f1;"></i>
        <span class="cc-nav-text">Smart AI Cockpit</span>
      </a>
    <?php endif; ?>

    <!-- 11. Reports & Analytics -->
    <?php if (!$isTeacher && !$isAdmissionsOfficer): ?>
      <a class="cc-nav-item <?= $isReportsActive ? 'active' : '' ?>" href="<?= e(url('reports')) ?>" title="Reports">
        <i data-lucide="pie-chart" class="cc-nav-icon"></i>
        <span class="cc-nav-text">Reports &amp; Analytics</span>
      </a>

      <!-- 11. Settings -->
      <a class="cc-nav-item <?= $isSettingsActive ? 'active' : '' ?>" href="<?= e(url('settings')) ?>" title="Settings">
        <i data-lucide="settings" class="cc-nav-icon"></i>
        <span class="cc-nav-text">Settings</span>
      </a>

      <?php if (hasPermission('settings.manage') || in_array($userRole, ['admin', 'school_admin', 'headmaster', 'principal'], true)): ?>
        <a class="cc-nav-item <?= isCcActive($current, 'onboarding/wizard') ? 'active' : '' ?>" href="<?= e(url('onboarding/wizard')) ?>" title="Quick Setup Wizard">
          <i data-lucide="wand-2" class="cc-nav-icon text-primary"></i>
          <span class="cc-nav-text">Setup Wizard</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'school/health') ? 'active' : '' ?>" href="<?= e(url('school/health')) ?>" title="School Health Center">
          <i data-lucide="heart-pulse" class="cc-nav-icon text-danger"></i>
          <span class="cc-nav-text">Health Center</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'admin/security') ? 'active' : '' ?>" href="<?= e(url('admin/security')) ?>" title="Security Center">
          <i data-lucide="shield-check" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Security Center</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'admin/system/health') ? 'active' : '' ?>" href="<?= e(url('admin/system/health')) ?>" title="System Health">
          <i data-lucide="activity" class="cc-nav-icon"></i>
          <span class="cc-nav-text">System Health</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'admin/system/backups') ? 'active' : '' ?>" href="<?= e(url('admin/system/backups')) ?>" title="Disaster Recovery">
          <i data-lucide="hard-drive-download" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Disaster Recovery</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'admin/integrations') ? 'active' : '' ?>" href="<?= e(url('admin/integrations')) ?>" title="Integration Center">
          <i data-lucide="share-2" class="cc-nav-icon"></i>
          <span class="cc-nav-text">API &amp; Webhooks</span>
        </a>
        <a class="cc-nav-item <?= isCcActive($current, 'admin/data') ? 'active' : '' ?>" href="<?= e(url('admin/data')) ?>" title="Data Import & Export">
          <i data-lucide="arrow-down-up" class="cc-nav-icon"></i>
          <span class="cc-nav-text">Import &amp; Export</span>
        </a>
      <?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>
  </nav>

  <!-- Sidebar Footer Collapse Toggle -->
  <div class="cc-sidebar-footer">
    <button type="button" class="cc-collapse-btn" id="sidebarCollapseToggle" title="Collapse (Ctrl+K)">
      <div class="d-flex align-items-center gap-2">
        <i data-lucide="panel-left-close" class="cc-collapse-icon" id="collapseIcon"></i>
        <span class="cc-collapse-text">Collapse</span>
      </div>
      <kbd class="cc-kbd-tag">Ctrl+K</kbd>
    </button>
  </div>
</aside>