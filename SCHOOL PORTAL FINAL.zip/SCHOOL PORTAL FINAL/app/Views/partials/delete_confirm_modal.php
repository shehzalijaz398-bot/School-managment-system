<!-- Global Delete Confirmation Modal -->
<div class="modal fade cc-delete-modal" id="globalDeleteConfirmModal" tabindex="-1" aria-labelledby="globalDeleteModalTitle" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 440px; margin-left: auto; margin-right: auto;">
    <div class="modal-content cc-delete-modal-content border-0">
      
      <!-- Modal Header -->
      <div class="cc-delete-modal-header">
        <h5 class="cc-delete-modal-title" id="globalDeleteModalTitle">Delete Subject</h5>
        <button type="button" class="cc-delete-modal-close" data-bs-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <!-- Modal Body -->
      <div class="cc-delete-modal-body">
        <div class="cc-delete-modal-icon-wrap">
          <svg class="cc-delete-modal-icon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
            <path d="M12 8v4"/>
            <path d="M12 16h.01"/>
          </svg>
        </div>
        <div class="cc-delete-modal-text-wrap">
          <div class="cc-delete-modal-msg" id="globalDeleteModalMsg">Are you sure you want to delete Art & Craft?</div>
          <div class="cc-delete-modal-subtext" id="globalDeleteModalSubtext">This action cannot be undone if it is mapped to classes.</div>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="cc-delete-modal-footer">
        <button type="button" class="cc-delete-btn-cancel" data-bs-dismiss="modal" id="globalDeleteModalCancelBtn">Cancel</button>
        <button type="button" class="cc-delete-btn-confirm" id="globalDeleteModalConfirmBtn">Delete</button>
      </div>

    </div>
  </div>
</div>
