<div class="auth-wrap">
  <div class="auth-card">
    <!-- Brand Header -->
    <div class="text-center mb-4">
      <div class="d-inline-flex align-items-center justify-content-center p-3 rounded-4 mb-3" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); width: 64px; height: 64px; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.12);">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"></path>
          <path d="M6 6h10"></path>
          <path d="M6 10h10"></path>
        </svg>
      </div>
      <div class="text-uppercase small fw-bold text-primary" style="font-size: 11px; letter-spacing: 0.08em;">
        <?= e(platform_setting('platform_name', 'School Portal SaaS')) ?>
      </div>
      <h1 class="h3 fw-bold text-dark mt-1 mb-1" style="letter-spacing: -0.02em;">Welcome Back</h1>
      <p class="text-muted small mb-0">Enter your credentials to access your administrative cockpit</p>
    </div>

    <!-- Flash Messages -->
    <?php require base_path('app/Views/partials/flash.php'); ?>
    <?php if (!empty($blocked)): ?>
      <div class="alert alert-warning border-0 small p-3 rounded-3 mb-3">
        School <strong><?= e($blocked['name'] ?? '') ?></strong> is currently <?= e($blocked['status'] ?? 'inactive') ?>.
      </div>
    <?php endif; ?>

    <!-- Login Form -->
    <form method="post" action="<?= e(url('login')) ?>" id="loginForm">
      <?= csrf_field() ?>
      <?php $prefilledSchool = (string) ($_GET['school'] ?? ($_SESSION['login_school_code'] ?? '')); ?>
      <?php if (!empty($prefilledSchool)): ?>
        <input type="hidden" name="school_code" value="<?= e($prefilledSchool) ?>">
        <div class="alert alert-light border small py-2 px-3 mb-3 d-flex align-items-center justify-content-between">
          <span class="text-muted">Target School: <strong class="text-primary font-monospace"><?= e($prefilledSchool) ?></strong></span>
          <span class="badge bg-primary-subtle text-primary">Pre-selected</span>
        </div>
      <?php endif; ?>

      <div class="mb-3">
        <label for="email" class="form-label small fw-semibold text-secondary mb-1">Email Address</label>
        <div class="input-group">
          <span class="input-group-text bg-white border-end-0" style="border-radius: 8px 0 0 8px; border-color: <?= hasError('email') ? '#ef4444' : '#e2e8f0' ?>;">
            <i data-lucide="mail" style="width: 16px; height: 16px; color: #94a3b8;"></i>
          </span>
          <input type="email" name="email" id="email" class="form-control border-start-0 <?= hasError('email') ? 'is-invalid border-danger' : '' ?>" value="<?= e((string) old('email', '')) ?>" placeholder="e.g. admin@school.com" required autofocus style="border-radius: 0 8px 8px 0; height: 44px; font-size: 14px; border-color: <?= hasError('email') ? '#ef4444' : '#e2e8f0' ?>;">
        </div>
        <?php if (hasError('email')): ?>
          <div class="text-danger small mt-1 fw-medium" style="font-size: 13px;">
            <i data-lucide="alert-circle" style="width: 14px; height: 14px; display: inline-block; vertical-align: -2px;"></i>
            <?= e(error('email')) ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center mb-1">
          <label for="password" class="form-label small fw-semibold text-secondary mb-0">Password</label>
          <a href="<?= e(url('forgot-password')) ?>" class="small text-decoration-none text-primary fw-medium" style="font-size: 12px;">Forgot password?</a>
        </div>
        <div class="input-group">
          <span class="input-group-text bg-white border-end-0" style="border-radius: 8px 0 0 8px; border-color: <?= hasError('password') ? '#ef4444' : '#e2e8f0' ?>;">
            <i data-lucide="lock" style="width: 16px; height: 16px; color: #94a3b8;"></i>
          </span>
          <input type="password" name="password" id="password" class="form-control border-start-0 <?= hasError('password') ? 'is-invalid border-danger' : '' ?>" placeholder="Enter your password" required style="height: 44px; font-size: 14px; border-right: none; border-color: <?= hasError('password') ? '#ef4444' : '#e2e8f0' ?>;">
          <button class="btn btn-outline-secondary d-flex align-items-center justify-content-center px-3" type="button" id="togglePassword" style="border-radius: 0 8px 8px 0; border: 1px solid <?= hasError('password') ? '#ef4444' : '#e2e8f0' ?>; border-left: none; background: #ffffff;">
            <i data-lucide="eye" id="eyeIcon" style="width: 16px; height: 16px; color: #64748b;"></i>
          </button>
        </div>
        <?php if (hasError('password')): ?>
          <div class="text-danger small mt-1 fw-medium" style="font-size: 13px;">
            <i data-lucide="alert-circle" style="width: 14px; height: 14px; display: inline-block; vertical-align: -2px;"></i>
            <?= e(error('password')) ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="form-check mb-4">
        <input class="form-check-input" type="checkbox" name="remember" value="1" id="remember" checked style="cursor: pointer;">
        <label class="form-check-label small text-secondary" for="remember" style="cursor: pointer; user-select: none;">
          Keep me signed in for 30 days
        </label>
      </div>

      <button type="submit" class="btn btn-primary w-100 fw-semibold d-flex align-items-center justify-content-center gap-2 shadow-sm" style="height: 44px; border-radius: 8px; font-size: 15px;">
        <span>Sign In to Dashboard</span>
        <i data-lucide="arrow-right" style="width: 16px; height: 16px;"></i>
      </button>

      <div class="mt-3 text-center">
        <span class="text-muted small">New School? </span>
        <a href="<?= e(url('register')) ?>" class="small text-decoration-none text-primary fw-semibold">
          Register your institution &amp; start 30-day free trial &rarr;
        </a>
      </div>
    </form>

    <!-- Footer Links -->
    <div class="mt-4 pt-3 border-top text-center small text-muted" style="font-size: 12px;">
      <a href="<?= e(url('pricing')) ?>" class="text-secondary text-decoration-none d-inline-flex align-items-center gap-1"><i data-lucide="sparkles" style="width:12px;height:12px;"></i> Subscription Plans</a> ·
      <a href="<?= e(url('help')) ?>" class="text-secondary text-decoration-none d-inline-flex align-items-center gap-1"><i data-lucide="help-circle" style="width:12px;height:12px;"></i> Help & Support</a>
    </div>
  </div>
</div>

<script>
  // Toggle password visibility
  document.getElementById('togglePassword').addEventListener('click', function (e) {
    const passwordInput = document.getElementById('password');
    const isPassword = passwordInput.getAttribute('type') === 'password';
    passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
    const eye = document.getElementById('eyeIcon');
    if (eye) {
      eye.setAttribute('data-lucide', isPassword ? 'eye-off' : 'eye');
      if (typeof lucide !== 'undefined') lucide.createIcons();
    }
  });

  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
</script>

