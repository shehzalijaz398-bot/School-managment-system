<div class="auth-wrap">
  <div class="auth-card">
    <h1>Forgot Password</h1>
    <p class="text-muted">Enter your account email to receive a reset link.</p>
    <?php require base_path('app/Views/partials/flash.php'); ?>
    <form method="post" action="<?= e(url('forgot-password')) ?>">
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Send Reset Link</button>
    </form>
    <div class="mt-3 text-center"><a href="<?= e(url('login')) ?>">Back to login</a></div>
  </div>
</div>
