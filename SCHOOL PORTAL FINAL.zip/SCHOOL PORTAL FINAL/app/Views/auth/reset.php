<div class="auth-wrap">
  <div class="auth-card">
    <h1>Reset Password</h1>
    <?php require base_path('app/Views/partials/flash.php'); ?>
    <form method="post" action="<?= e(url('reset-password')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="token" value="<?= e($token ?? '') ?>">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= e($email ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">New Password</label>
        <input type="password" name="password" class="form-control" required minlength="8">
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="password_confirmation" class="form-control" required minlength="8">
      </div>
      <button class="btn btn-primary w-100">Update Password</button>
    </form>
  </div>
</div>
