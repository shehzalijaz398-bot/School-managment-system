<?php
$title = 'Central Task Center & Action Items';
$summaryData = $summary ?? ['total' => 0, 'pending' => 0, 'in_progress' => 0, 'completed' => 0, 'overdue' => 0, 'due_today' => 0];
$activeStatus = $filterStatus ?? 'all';
$activePriority = $filterPriority ?? 'all';
$tasksList = $tasks ?? [];
$approvalsList = $pendingApprovals ?? [];
$remindersList = $operationalReminders ?? [];
$staffEmployees = $employees ?? [];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
  <div>
    <div class="d-flex align-items-center gap-2">
      <h2 class="h4 mb-0 fw-bold text-dark">
        <i data-lucide="check-square" class="text-primary me-1" style="width: 24px; height: 24px;"></i>
        <?= e($title) ?>
      </h2>
      <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 rounded-pill small">
        Action Console
      </span>
    </div>
    <p class="text-muted small mb-0 mt-1">
      Your personalized workspace for assigned tasks, approval queues, operational reminders, and deadline tracking.
    </p>
  </div>
  <div class="d-flex gap-2">
    <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newTaskModal">
      <i data-lucide="plus-circle" style="width: 14px; height: 14px;"></i> New Task
    </button>
    <a href="<?= e(url('workflows')) ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1">
      <i data-lucide="git-pull-request" style="width: 14px; height: 14px;"></i> Approvals Hub
    </a>
  </div>
</div>

<!-- Task Overview Metric Cards -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Pending Tasks</div>
          <div class="fs-4 fw-bold text-primary"><?= (int) $summaryData['pending'] ?> <span class="fs-6 text-muted fw-normal">/ <?= (int) $summaryData['total'] ?></span></div>
          <div class="text-muted" style="font-size: 11px;">Action Items Open</div>
        </div>
        <div class="rounded-3 p-2 bg-primary-subtle text-primary">
          <i data-lucide="clock" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Overdue Deadlines</div>
          <div class="fs-4 fw-bold text-danger"><?= (int) $summaryData['overdue'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Immediate Attention</div>
        </div>
        <div class="rounded-3 p-2 bg-danger-subtle text-danger">
          <i data-lucide="alert-triangle" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Completed Tasks</div>
          <div class="fs-4 fw-bold text-success"><?= (int) $summaryData['completed'] ?></div>
          <div class="text-muted" style="font-size: 11px;">Closed Action Items</div>
        </div>
        <div class="rounded-3 p-2 bg-success-subtle text-success">
          <i data-lucide="check-circle-2" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
      <div class="d-flex align-items-center justify-content-between">
        <div>
          <div class="text-muted small fw-semibold text-uppercase" style="font-size: 11px;">Pending Approvals</div>
          <div class="fs-4 fw-bold text-warning"><?= count($approvalsList) ?></div>
          <div class="text-muted" style="font-size: 11px;">Awaiting Review</div>
        </div>
        <div class="rounded-3 p-2 bg-warning-subtle text-warning">
          <i data-lucide="git-pull-request" style="width: 22px; height: 22px;"></i>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Operational Reminders Banner (If any) -->
<?php if (!empty($remindersList)): ?>
  <div class="mb-4">
    <div class="card border-0 shadow-sm rounded-3 bg-white">
      <div class="card-header bg-white border-bottom py-3">
        <h6 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="bell-ring" class="text-warning" style="width: 18px; height: 18px;"></i>
          Urgent Operational Actions & Reminders
        </h6>
      </div>
      <div class="card-body p-0">
        <div class="list-group list-group-flush">
          <?php foreach ($remindersList as $rem): ?>
            <div class="list-group-item d-flex flex-column flex-md-row justify-content-between align-items-md-center p-3 gap-2">
              <div class="d-flex align-items-start gap-3">
                <span class="badge <?= $rem['badge_class'] ?> px-2 py-1 rounded-pill mt-1 small">
                  <?= e($rem['badge']) ?>
                </span>
                <div>
                  <div class="fw-bold text-dark"><?= e($rem['title']) ?></div>
                  <div class="text-muted small"><?= e($rem['desc']) ?></div>
                </div>
              </div>
              <a href="<?= e($rem['action_url']) ?>" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 text-nowrap">
                <?= e($rem['action_label']) ?> <i data-lucide="chevron-right" style="width: 14px; height: 14px;"></i>
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- Main Task & Approvals Section -->
<div class="row g-4 mb-4">
  <!-- Tasks Column -->
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white border-bottom py-3 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
        <!-- Status Filter Pills -->
        <ul class="nav nav-pills gap-1">
          <li class="nav-item">
            <a class="nav-link <?= $activeStatus === 'all' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
               href="<?= e(url("tasks?status=all&priority={$activePriority}")) ?>">All</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeStatus === 'pending' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
               href="<?= e(url("tasks?status=pending&priority={$activePriority}")) ?>">Pending</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeStatus === 'in_progress' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
               href="<?= e(url("tasks?status=in_progress&priority={$activePriority}")) ?>">In Progress</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= $activeStatus === 'completed' ? 'active bg-primary' : 'text-secondary' ?> py-1 px-3 small fw-semibold rounded-pill" 
               href="<?= e(url("tasks?status=completed&priority={$activePriority}")) ?>">Completed</a>
          </li>
        </ul>

        <!-- Priority Filter -->
        <div class="d-flex align-items-center gap-2">
          <label class="small text-muted text-nowrap mb-0" style="font-size: 12px;">Priority:</label>
          <select class="form-select form-select-sm" style="width: auto;" onchange="location.href='<?= e(url('tasks?status=' . $activeStatus . '&priority=')) ?>' + this.value;">
            <option value="all" <?= $activePriority === 'all' ? 'selected' : '' ?>>All Priorities</option>
            <option value="urgent" <?= $activePriority === 'urgent' ? 'selected' : '' ?>>Urgent</option>
            <option value="high" <?= $activePriority === 'high' ? 'selected' : '' ?>>High</option>
            <option value="medium" <?= $activePriority === 'medium' ? 'selected' : '' ?>>Medium</option>
            <option value="low" <?= $activePriority === 'low' ? 'selected' : '' ?>>Low</option>
          </select>
        </div>
      </div>

      <div class="card-body p-0">
        <?php if (empty($tasksList)): ?>
          <div class="text-center py-5">
            <i data-lucide="check-circle" class="text-success mb-2" style="width: 44px; height: 44px; opacity: 0.6;"></i>
            <h6 class="fw-bold text-dark">No Tasks Found</h6>
            <p class="text-muted small mb-0">Your task list is clear for this filter category.</p>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php foreach ($tasksList as $t): 
              $isDone = ($t['status'] === 'completed');
              $isOverdue = (!$isDone && strtotime($t['due_date']) < strtotime(date('Y-m-d')));
              $prioBadge = match($t['priority']) {
                'urgent' => 'bg-danger text-white',
                'high' => 'bg-warning text-dark',
                'medium' => 'bg-info-subtle text-info',
                default => 'bg-light text-dark border',
              };
            ?>
              <div class="list-group-item d-flex align-items-start justify-content-between p-3 gap-3 border-bottom <?= $isDone ? 'bg-light' : '' ?>">
                <div class="d-flex align-items-start gap-3">
                  <!-- Toggle Completion Button -->
                  <form method="POST" action="<?= e(url("tasks/{$t['id']}/toggle")) ?>" class="mt-1">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm p-0 border-0 bg-transparent" title="<?= $isDone ? 'Mark as Pending' : 'Mark as Completed' ?>">
                      <?php if ($isDone): ?>
                        <i data-lucide="check-circle-2" class="text-success" style="width: 22px; height: 22px;"></i>
                      <?php else: ?>
                        <i data-lucide="circle" class="text-muted" style="width: 22px; height: 22px;"></i>
                      <?php endif; ?>
                    </button>
                  </form>

                  <div>
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                      <span class="fw-bold <?= $isDone ? 'text-decoration-line-through text-muted' : 'text-dark' ?>">
                        <?= e($t['title']) ?>
                      </span>
                      <span class="badge <?= $prioBadge ?> text-uppercase px-2 py-0.5 rounded-pill" style="font-size: 10px;">
                        <?= e($t['priority']) ?>
                      </span>
                      <?php if ($isOverdue): ?>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-0.5 rounded-pill" style="font-size: 10px;">
                          Overdue
                        </span>
                      <?php endif; ?>
                    </div>

                    <?php if (!empty($t['description'])): ?>
                      <p class="text-muted small mb-1 mt-1 <?= $isDone ? 'text-decoration-line-through' : '' ?>">
                        <?= e($t['description']) ?>
                      </p>
                    <?php endif; ?>

                    <div class="d-flex align-items-center gap-3 text-muted small mt-1 flex-wrap" style="font-size: 11px;">
                      <span><i data-lucide="calendar" style="width: 12px; height: 12px;"></i> Due: <strong><?= date('M j, Y', strtotime($t['due_date'])) ?></strong></span>
                      <?php if (!empty($t['assignee_name'])): ?>
                        <span><i data-lucide="user" style="width: 12px; height: 12px;"></i> Assignee: <?= e($t['assignee_name']) ?></span>
                      <?php endif; ?>
                      <?php if (!empty($t['assigner_name'])): ?>
                        <span><i data-lucide="user-check" style="width: 12px; height: 12px;"></i> Created by: <?= e($t['assigner_name']) ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>

                <div class="text-end text-nowrap">
                  <span class="badge <?= $isDone ? 'bg-success-subtle text-success' : ($t['status'] === 'in_progress' ? 'bg-info-subtle text-info' : 'bg-warning-subtle text-warning') ?> px-2 py-1 rounded-pill small">
                    <?= ucfirst(str_replace('_', ' ', $t['status'])) ?>
                  </span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Approvals & Workflow Queue Column -->
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm rounded-3">
      <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <h6 class="card-title mb-0 fw-bold fs-6 d-flex align-items-center gap-2">
          <i data-lucide="git-pull-request" class="text-primary" style="width: 18px; height: 18px;"></i>
          Pending Approvals
        </h6>
        <a href="<?= e(url('workflows')) ?>" class="text-primary small text-decoration-none">View All</a>
      </div>
      <div class="card-body p-0">
        <?php if (empty($approvalsList)): ?>
          <div class="text-center py-4 text-muted small">
            <i data-lucide="check-check" class="text-success mb-1" style="width: 32px; height: 32px; opacity: 0.6;"></i>
            <div>Zero pending approvals awaiting your review.</div>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php foreach ($approvalsList as $wf): ?>
              <div class="list-group-item p-3 border-bottom">
                <div class="d-flex justify-content-between align-items-start mb-1">
                  <span class="badge bg-light text-dark border px-2 py-0.5 rounded" style="font-size: 10px;">
                    <?= strtoupper(str_replace('_', ' ', $wf['entity_type'])) ?>
                  </span>
                  <span class="text-muted small" style="font-size: 10px;">
                    <?= date('M j, Y', strtotime($wf['submitted_at'])) ?>
                  </span>
                </div>
                <div class="fw-bold text-dark small mb-1"><?= e($wf['title']) ?></div>
                <div class="text-muted small mb-2" style="font-size: 11px;">
                  Requester: <?= e($wf['requester_name'] ?? 'Staff') ?>
                </div>
                <div class="d-flex gap-2">
                  <a href="<?= e(url('workflows?status=pending')) ?>" class="btn btn-outline-primary btn-sm py-0.5 px-2" style="font-size: 11px;">
                    Review Request
                  </a>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Modal: New Task -->
<div class="modal fade" id="newTaskModal" tabindex="-1" aria-labelledby="newTaskModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <form method="POST" action="<?= e(url('tasks/create')) ?>">
        <?= csrf_field() ?>
        <div class="modal-header bg-light">
          <h5 class="modal-title fs-6 fw-bold text-dark" id="newTaskModalLabel">
            <i data-lucide="plus-circle" class="text-primary me-1" style="width: 18px; height: 18px;"></i>
            Create New Staff / Action Task
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Task Title <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control form-control-sm" placeholder="e.g., Audit Midterm Exam Schedules" required>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-dark">Description & Checklist</label>
            <textarea name="description" class="form-control form-control-sm" rows="3" placeholder="Provide operational guidelines, checklist, or action requirements..."></textarea>
          </div>

          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Priority <span class="text-danger">*</span></label>
              <select name="priority" class="form-select form-select-sm" required>
                <option value="medium" selected>Medium</option>
                <option value="low">Low</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold text-dark">Due Date <span class="text-danger">*</span></label>
              <input type="date" name="due_date" class="form-control form-control-sm" value="<?= date('Y-m-d', strtotime('+3 days')) ?>" required>
            </div>
          </div>

          <?php if (!empty($staffEmployees)): ?>
            <div class="mb-3">
              <label class="form-label small fw-semibold text-dark">Assign To Staff Member</label>
              <select name="assigned_to" class="form-select form-select-sm">
                <option value="0">Self / Auto-Assign</option>
                <?php foreach ($staffEmployees as $emp): ?>
                  <option value="<?= (int) $emp['id'] ?>">
                    <?= e($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= e($emp['designation'] ?? 'Staff') ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          <?php endif; ?>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-1">
            <i data-lucide="check" style="width: 14px; height: 14px;"></i> Save Task
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
