<?php
$layout = 'layouts/app';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="h4 mb-1 fw-bold text-gray-800"><i data-lucide="bus" class="text-primary me-2"></i> Transport Management</h2>
        <p class="text-muted mb-0">Manage vehicles, drivers, routing configurations, and student assignments.</p>
    </div>
    <?php if (hasPermission('transport.manage')): ?>
    <div class="d-flex gap-2">
        <button class="btn btn-light border d-flex align-items-center gap-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#vehicleModal"><i data-lucide="truck"></i> Add Vehicle</button>
        <button class="btn btn-light border d-flex align-items-center gap-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#driverModal"><i data-lucide="user-check"></i> Add Driver</button>
        <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#routeModal"><i data-lucide="map"></i> Create Route</button>
    </div>
    <?php endif; ?>
</div>

<ul class="nav nav-tabs mb-4" id="transportTabs" role="tablist">
  <li class="nav-item" role="presentation"><button class="nav-link active fw-semibold" id="routes-tab" data-bs-toggle="tab" data-bs-target="#routes" type="button" role="tab">Routes</button></li>
  <li class="nav-item" role="presentation"><button class="nav-link fw-semibold" id="vehicles-tab" data-bs-toggle="tab" data-bs-target="#vehicles" type="button" role="tab">Vehicles</button></li>
  <li class="nav-item" role="presentation"><button class="nav-link fw-semibold" id="drivers-tab" data-bs-toggle="tab" data-bs-target="#drivers" type="button" role="tab">Drivers</button></li>
  <li class="nav-item" role="presentation"><button class="nav-link fw-semibold" id="students-tab" data-bs-toggle="tab" data-bs-target="#students" type="button" role="tab">Student Assignments</button></li>
</ul>

<div class="tab-content" id="transportTabsContent">
  <div class="tab-pane fade show active" id="routes" role="tabpanel">
      <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
          <div class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small text-uppercase">
                      <tr>
                          <th class="ps-4 border-0 py-3">Route Title</th>
                          <th class="border-0 py-3">Points (Start - End)</th>
                          <th class="border-0 py-3">Vehicle & Driver</th>
                          <th class="border-0 py-3">Monthly Fare</th>
                          <th class="border-0 py-3">Students</th>
                          <th class="pe-4 border-0 py-3 text-end">Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($routes as $r): ?>
                      <tr>
                          <td class="ps-4 fw-bold text-dark py-3"><i data-lucide="map-pin" style="width:14px;" class="text-primary me-1"></i> <?= e($r['title']) ?></td>
                          <td class="py-3 text-muted"><?= e($r['start_point']) ?> <i data-lucide="arrow-right" style="width:12px;"></i> <?= e($r['end_point']) ?></td>
                          <td class="py-3"><span class="badge bg-light text-dark border"><?= e($r['vehicle_no'] ?? 'Unassigned') ?></span> <span class="small text-muted ms-1"><?= e($r['driver_name'] ?? '') ?></span></td>
                          <td class="py-3 fw-semibold text-success"><?= e(formatMoney($r['fare'])) ?></td>
                          <td class="py-3"><span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-2"><?= (int)$r['assigned_students'] ?></span></td>
                          <td class="pe-4 py-3 text-end"><?= statusBadge($r['status']) ?></td>
                      </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>

  <div class="tab-pane fade" id="vehicles" role="tabpanel">
      <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
          <div class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small text-uppercase">
                      <tr>
                          <th class="ps-4 border-0 py-3">Vehicle No</th>
                          <th class="border-0 py-3">Model</th>
                          <th class="border-0 py-3">Capacity</th>
                          <th class="pe-4 border-0 py-3 text-end">Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($vehicles as $v): ?>
                      <tr>
                          <td class="ps-4 fw-bold text-dark py-3"><?= e($v['vehicle_no']) ?></td>
                          <td class="py-3 text-muted"><?= e($v['model']) ?></td>
                          <td class="py-3 fw-semibold"><?= (int)$v['capacity'] ?> Seats</td>
                          <td class="pe-4 py-3 text-end"><?= statusBadge($v['status']) ?></td>
                      </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>

  <div class="tab-pane fade" id="drivers" role="tabpanel">
      <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
          <div class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small text-uppercase">
                      <tr>
                          <th class="ps-4 border-0 py-3">Name</th>
                          <th class="border-0 py-3">Phone</th>
                          <th class="border-0 py-3">License No</th>
                          <th class="border-0 py-3">Salary</th>
                          <th class="pe-4 border-0 py-3 text-end">Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($drivers as $d): ?>
                      <tr>
                          <td class="ps-4 fw-bold text-dark py-3"><?= e($d['name']) ?></td>
                          <td class="py-3 text-muted"><?= e($d['phone']) ?></td>
                          <td class="py-3 text-muted"><?= e($d['license_no']) ?></td>
                          <td class="py-3 fw-semibold text-gray-800"><?= e(formatMoney($d['salary'])) ?></td>
                          <td class="pe-4 py-3 text-end"><?= statusBadge($d['status']) ?></td>
                      </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>

  <div class="tab-pane fade" id="students" role="tabpanel">
      <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
          <div class="card-header bg-white border-0 p-4 pb-0 d-flex justify-content-between align-items-center">
              <h6 class="mb-0 fw-bold">Active Student Assignments</h6>
              <?php if (hasPermission('transport.manage')): ?>
              <button class="btn btn-sm btn-outline-primary rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#assignModal">Assign Route</button>
              <?php endif; ?>
          </div>
          <div class="table-responsive mt-3">
              <table class="table table-hover align-middle mb-0">
                  <thead class="bg-light text-muted small text-uppercase">
                      <tr>
                          <th class="ps-4 border-0 py-3">Student Name</th>
                          <th class="border-0 py-3">Admission No</th>
                          <th class="border-0 py-3">Class & Section</th>
                          <th class="pe-4 border-0 py-3 text-end">Assigned Route</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($students as $s): ?>
                      <tr>
                          <td class="ps-4 fw-bold text-dark py-3"><?= e($s['first_name'].' '.$s['last_name']) ?></td>
                          <td class="py-3 text-muted"><?= e($s['admission_no']) ?></td>
                          <td class="py-3"><span class="badge bg-light text-dark border"><?= e($s['class_name'].' - '.$s['section_name']) ?></span></td>
                          <td class="pe-4 py-3 text-end">
                              <?php if(!empty($s['route_title'])): ?>
                                  <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2"><i data-lucide="check-circle" style="width:14px;" class="me-1"></i> <?= e($s['route_title']) ?></span>
                              <?php else: ?>
                                  <span class="text-muted small">Not Assigned</span>
                              <?php endif; ?>
                          </td>
                      </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</div>

<?php if (hasPermission('transport.manage')): ?>
<div class="modal fade" id="routeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-primary text-white border-0 px-4 py-3">
                <h5 class="modal-title fw-bold">Create Route</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= e(url('transport/routes')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4 bg-light">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Route Title *</label>
                        <input type="text" name="title" class="form-control rounded-3" required>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Start Point *</label>
                            <input type="text" name="start_point" class="form-control rounded-3" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">End Point *</label>
                            <input type="text" name="end_point" class="form-control rounded-3" required>
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Assign Vehicle</label>
                            <select name="vehicle_id" class="form-select rounded-3">
                                <option value="">Select...</option>
                                <?php foreach($vehicles as $v): ?><option value="<?= $v['id'] ?>"><?= e($v['vehicle_no']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Assign Driver</label>
                            <select name="driver_id" class="form-select rounded-3">
                                <option value="">Select...</option>
                                <?php foreach($drivers as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Monthly Fare *</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0">$</span>
                                <input type="number" step="0.01" name="fare" class="form-control border-start-0 ps-0" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Status *</label>
                            <select name="status" class="form-select rounded-3">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer px-4 border-0">
                    <button type="submit" class="btn btn-primary rounded-pill w-100 fw-bold shadow-sm">Save Route</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="vehicleModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-light border-0 px-4 py-3">
                <h5 class="modal-title fw-bold text-dark">Register Vehicle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= e(url('transport/vehicles')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Vehicle No (Registration) *</label>
                        <input type="text" name="vehicle_no" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Model / Make *</label>
                        <input type="text" name="model" class="form-control rounded-3" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Seating Capacity *</label>
                            <input type="number" name="capacity" class="form-control rounded-3" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Status *</label>
                            <select name="status" class="form-select rounded-3">
                                <option value="active">Active</option>
                                <option value="maintenance">Under Maintenance</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer px-4 border-0">
                    <button type="submit" class="btn btn-dark rounded-pill w-100 fw-bold shadow-sm">Save Vehicle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="driverModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-light border-0 px-4 py-3">
                <h5 class="modal-title fw-bold text-dark">Register Driver</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= e(url('transport/drivers')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Full Name *</label>
                        <input type="text" name="name" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Contact Phone *</label>
                        <input type="text" name="phone" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">License Number *</label>
                        <input type="text" name="license_no" class="form-control rounded-3" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Monthly Salary</label>
                            <input type="number" step="0.01" name="salary" class="form-control rounded-3" value="0.00" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted small fw-semibold">Status *</label>
                            <select name="status" class="form-select rounded-3">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer px-4 border-0">
                    <button type="submit" class="btn btn-dark rounded-pill w-100 fw-bold shadow-sm">Save Driver</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="assignModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-primary text-white border-0 px-4 py-3">
                <h5 class="modal-title fw-bold">Assign Student to Route</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="<?= e(url('transport/assign')) ?>">
                <?= csrf_field() ?>
                <div class="modal-body p-4 bg-light">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Select Student *</label>
                        <select name="student_id" class="form-select rounded-3 form-control" required>
                            <option value="">Search Student...</option>
                            <?php foreach($students as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['first_name'].' '.$s['last_name'].' ('.$s['admission_no'].')') ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-semibold">Select Route</label>
                        <select name="transport_route_id" class="form-select rounded-3 form-control">
                            <option value="">None (Remove Assignment)</option>
                            <?php foreach($routes as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['title'].' - $'.$r['fare']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer px-4 border-0">
                    <button type="submit" class="btn btn-primary rounded-pill w-100 fw-bold shadow-sm">Update Assignment</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
