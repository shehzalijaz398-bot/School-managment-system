<?php

declare(strict_types=1);

use Core\Auth;
use Core\CSRF;
use Core\Database;

if (!function_exists('env')) {
    function env(string $key, mixed $default = null): mixed {
        $val = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
        if ($val === false || $val === null) {
            return $default;
        }
        return match (strtolower((string) $val)) {
            'true', '(true)' => true,
            'false', '(false)' => false,
            'empty', '(empty)' => '',
            'null', '(null)' => null,
            default => $val,
        };
    }
}

function app_config(?string $key = null, mixed $default = null): mixed
{
    static $config = null;
    if ($config === null) {
        $config = require base_path('config/app.php');
    }
    if ($key === null) {
        return $config;
    }
    $parts = explode('.', $key);
    $value = $config;
    foreach ($parts as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) {
            return $default;
        }
        $value = $value[$part];
    }
    return $value;
}

function base_path(string $path = ''): string
{
    $root = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
    if ($path === '') {
        return $root;
    }
    return $root . DIRECTORY_SEPARATOR . ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path), DIRECTORY_SEPARATOR);
}

function public_path(string $path = ''): string
{
    return base_path('public' . ($path ? '/' . ltrim($path, '/') : ''));
}

function url(string $path = ''): string
{
    $base = rtrim((string) app_config('url'), '/');
    $path = ltrim($path, '/');
    return $path === '' ? $base . '/' : $base . '/' . $path;
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function redirect(string $to): never
{
    if (!str_starts_with($to, 'http')) {
        $to = url(ltrim($to, '/'));
    }
    header('Location: ' . $to);
    throw new \App\Exceptions\RedirectException("Redirected to $to");
}

function back(): never
{
    $ref = $_SERVER['HTTP_REFERER'] ?? url('dashboard');
    header('Location: ' . $ref);
    exit;
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', false);
}

function flash(string $key, mixed $value = null): mixed
{
    if ($value !== null) {
        $_SESSION['_flash'][$key] = $value;
        return null;
    }
    $val = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $val;
}

function hasFlash(string $key): bool
{
    return isset($_SESSION['_flash'][$key]);
}

function getFlash(string $key, mixed $default = null): mixed
{
    $val = $_SESSION['_flash'][$key] ?? $default;
    unset($_SESSION['_flash'][$key]);
    return $val;
}

function old(string $key, mixed $default = ''): mixed
{
    $old = $_SESSION['_flash']['old'] ?? [];
    return $old[$key] ?? $default;
}

function error(string $key): ?string
{
    $errors = $_SESSION['_flash']['errors'] ?? [];
    if (isset($errors[$key])) {
        return is_array($errors[$key]) ? (string) ($errors[$key][0] ?? '') : (string) $errors[$key];
    }
    return null;
}

function hasError(string $key): bool
{
    return isset($_SESSION['_flash']['errors'][$key]);
}

function session(?string $key = null, mixed $default = null): mixed
{
    if ($key === null) {
        return $_SESSION ?? [];
    }
    return $_SESSION[$key] ?? $default;
}


function view(string $name, array $data = [], ?string $layout = 'layouts/app'): void
{
    extract($data, EXTR_SKIP);
    $viewFile = base_path('app/Views/' . str_replace('.', '/', $name) . '.php');
    if (!is_file($viewFile)) {
        http_response_code(500);
        echo 'View not found: ' . e($name);
        return;
    }

    ob_start();
    require $viewFile;
    $content = ob_get_clean();

    if ($layout === null) {
        echo $content;
        return;
    }

    $layoutFile = base_path('app/Views/' . str_replace('.', '/', $layout) . '.php');
    require $layoutFile;
}

function csrf_field(): string
{
    return CSRF::field();
}

function csrfField(): string
{
    return CSRF::field();
}

function csrf_token(): string
{
    return CSRF::token();
}

function currentUser(): ?array
{
    return Auth::user();
}

function currentUserId(): ?int
{
    return Auth::id();
}

function currentSchoolId(): ?int
{
    return \Core\TenantContext::schoolId() ?? Auth::schoolId();
}

function currentSchool(): ?array
{
    return \Core\TenantContext::currentSchool();
}

function platform_user_id(): ?int
{
    return \Core\PlatformAuth::id();
}

function platform_user(): ?array
{
    return \Core\PlatformAuth::user();
}

function requireActiveTenant(): void
{
    \Core\TenantContext::requireActiveTenant();
}

function tenantHasFeature(string $slug): bool
{
    return \App\Services\Platform\FeatureAccessService::tenantHasFeature($slug);
}

function tenantWithinLimit(string $metric, int $additional = 1): bool
{
    return \App\Services\Platform\PlanLimitService::tenantWithinLimit($metric, $additional);
}

function platform_setting(string $key, mixed $default = null): mixed
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        if (\Core\Database::fetch('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', ['platform_settings'])) {
            foreach (\Core\Database::fetchAll('SELECT setting_key, setting_value FROM platform_settings') as $row) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        }
    }
    return $cache[$key] ?? $default;
}

function cache(?string $key = null, mixed $value = null, int $ttl = 300): mixed
{
    if ($key === null) {
        return new \Core\Cache();
    }
    if ($value === null) {
        return \Core\Cache\CacheManager::get($key);
    }
    return \Core\Cache\CacheManager::set($key, $value, $ttl);
}

function school_settings(?int $schoolId = null): array
{
    $tenantId = $schoolId ?? currentSchoolId();
    if (!$tenantId) {
        return [];
    }

    return \Core\Cache\CacheManager::remember(
        'all_school_settings',
        600,
        static function () use ($tenantId): array {
            $rows = \Core\Database::fetchAll('SELECT setting_key, setting_value FROM settings WHERE school_id = ?', [$tenantId]);
            $res = [];
            foreach ($rows as $r) {
                $res[$r['setting_key']] = $r['setting_value'];
            }
            return $res;
        },
        $tenantId
    );
}

function school_setting(string $key, mixed $default = null, ?int $schoolId = null): mixed
{
    $all = school_settings($schoolId);
    return $all[$key] ?? $default;
}

function hasPermission(string $permission): bool
{
    return Auth::hasPermission($permission);
}

function requirePermission(string $permission): void
{
    Auth::requirePermission($permission);
}

function isRole(string|array $roles): bool
{
    return Auth::isRole($roles);
}

function auditLog(
    string $action,
    string|array $module = 'general',
    ?string $entityType = null,
    ?int $entityId = null,
    ?array $oldValues = null,
    ?array $newValues = null
): void {
    if (is_array($module)) {
        $newValues = $module;
        $module = 'general';
    }
    \App\Helpers\Audit::log($action, $module, $entityType, $entityId, $oldValues, $newValues);
}

function officialActiveAcademicYearId(): ?int
{
    $schoolId = currentSchoolId();
    if (!$schoolId) {
        return null;
    }
    $row = Database::fetch(
        'SELECT id FROM academic_years WHERE school_id = ? AND is_active = 1 LIMIT 1',
        [$schoolId]
    );
    return $row ? (int) $row['id'] : null;
}

function activeAcademicYearId(): ?int
{
    $schoolId = currentSchoolId();
    if (!$schoolId) {
        return null;
    }
    if (!empty($_SESSION['selected_academic_year_id'])) {
        $selectedId = (int)$_SESSION['selected_academic_year_id'];
        $row = Database::fetch(
            'SELECT id FROM academic_years WHERE id = ? AND school_id = ? LIMIT 1',
            [$selectedId, $schoolId]
        );
        if ($row) {
            return (int)$row['id'];
        }
    }
    return officialActiveAcademicYearId();
}

function formatMoney(float|int|string $amount): string
{
    return number_format((float) $amount, 2);
}

function currencySymbol(?string $currency = null): string
{
    if ($currency === null) {
        $school = currentSchool();
        $currency = $school['currency'] ?? 'PKR';
    }
    $currency = strtoupper(trim($currency));
    return match ($currency) {
        'PKR' => 'Rs. ',
        'INR' => '₹',
        'USD' => '$',
        'GBP' => '£',
        'EUR' => '€',
        'AED' => 'AED ',
        'SAR' => 'SAR ',
        'CAD' => 'CA$ ',
        'AUD' => 'AU$ ',
        default => ($currency !== '' ? $currency . ' ' : '$'),
    };
}

function formatDate(?string $date, string $format = 'd M Y'): string
{
    if (!$date) {
        return '—';
    }
    try {
        return (new DateTime($date))->format($format);
    } catch (Throwable) {
        return e($date);
    }
}

function statusBadge(string $status): string
{
    $map = [
        'active' => 'success',
        'inactive' => 'secondary',
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'paid' => 'success',
        'draft' => 'secondary',
        'cancelled' => 'dark',
        'present' => 'success',
        'absent' => 'danger',
        'late' => 'warning',
        'leave' => 'info',
        'excused' => 'primary',
        'half_day' => 'warning',
        'holiday' => 'info',
    ];
    $class = $map[strtolower($status)] ?? 'secondary';
    return '<span class="badge text-bg-' . e($class) . '">' . e(ucwords(str_replace('_', ' ', $status))) . '</span>';
}

function canAccessMenu(string $permission): bool
{
    return hasPermission($permission);
}

function upload_file(array $file, string $subdir, array $allowedMimes): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('File upload failed.');
    }

    $max = (int) app_config('upload.max_size', 5 * 1024 * 1024);
    if (($file['size'] ?? 0) > $max) {
        throw new RuntimeException('File exceeds maximum allowed size.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!in_array($mime, $allowedMimes, true)) {
        throw new RuntimeException('Invalid file type.');
    }

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'image/svg+xml' => 'svg',
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'text/plain' => 'txt',
        default => 'bin',
    };

    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    $destDir = public_path('uploads/' . trim($subdir, '/'));
    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }
    $dest = $destDir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        if (PHP_SAPI === 'cli' && copy($file['tmp_name'], $dest)) {
            @unlink($file['tmp_name']);
        } else {
            throw new RuntimeException('Unable to store uploaded file.');
        }
    }

    return 'uploads/' . trim($subdir, '/') . '/' . $name;
}

function uploadFile(array $file, string $subdir = 'uploads', ?array $allowedMimes = null): ?string
{
    $allowedMimes = $allowedMimes ?? app_config('upload.allowed_images', [
        'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'
    ]);
    return upload_file($file, $subdir, $allowedMimes);
}

function notify_user(
    int $schoolId,
    int $userId,
    string $type,
    string $title,
    string $message,
    ?string $entityType = null,
    ?int $entityId = null,
    ?string $link = null
): void {
    Database::insert(
        'INSERT INTO notifications (school_id, user_id, type, title, message, entity_type, entity_id, link, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())',
        [$schoolId, $userId, $type, $title, $message, $entityType, $entityId, $link]
    );
}

function grade_from_percentage(float $percentage, int $schoolId): string
{
    $scales = \Core\Cache\CacheManager::remember(
        'school_grade_scales',
        3600,
        static function () use ($schoolId): array {
            return \Core\Database::fetchAll(
                'SELECT grade, min_percentage, max_percentage FROM grade_scales WHERE school_id = ? ORDER BY min_percentage DESC',
                [$schoolId]
            );
        },
        $schoolId
    );

    foreach ($scales as $s) {
        if ($percentage >= (float)$s['min_percentage'] && $percentage <= (float)$s['max_percentage']) {
            return (string)$s['grade'];
        }
    }
    return 'N/A';
}

if (!function_exists('__')) {
    function __(string $key, string $default = ''): string {
        return \Core\Language::translate($key, $default);
    }
}

if (!function_exists('is_json_request')) {
    function is_json_request(): bool {
        return (
            (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) ||
            (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json')) ||
            (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
            (!empty($_SERVER['REQUEST_URI']) && str_contains($_SERVER['REQUEST_URI'], '/api/'))
        );
    }
}

if (!function_exists('backup_encryption_key')) {
    function backup_encryption_key(): string {
        $rawKey = (string) app_config('backup_key', 'super_secret_unexposed_vault_key_AES_256');
        return hash('sha256', $rawKey, true);
    }
}

