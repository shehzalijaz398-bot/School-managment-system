<?php

declare(strict_types=1);

namespace App\Helpers;

use Core\Auth;
use Core\Database;

final class Audit
{
    public static function log(
        string $action,
        string $module,
        ?string $entityType = null,
        ?int $entityId = null,
        ?array $oldValues = null,
        ?array $newValues = null,
        ?int $schoolId = null,
        ?int $userId = null
    ): void {
        $schoolId = $schoolId ?? Auth::schoolId();
        $userId = $userId ?? Auth::id();

        if (!$schoolId) {
            return;
        }

        if ($userId) {
            $userExists = Database::fetch('SELECT id FROM users WHERE id = ? LIMIT 1', [$userId]);
            if (!$userExists) {
                $userId = null;
            }
        }

        $cleanOld = self::sanitizeData($oldValues);
        $cleanNew = self::sanitizeData($newValues);

        Database::insert(
            'INSERT INTO audit_logs
            (school_id, user_id, action, module, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
            [
                $schoolId,
                $userId,
                $action,
                $module,
                $entityType,
                $entityId,
                $cleanOld !== null ? json_encode($cleanOld, JSON_UNESCAPED_UNICODE) : null,
                $cleanNew !== null ? json_encode($cleanNew, JSON_UNESCAPED_UNICODE) : null,
                Auth::clientIp(),
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            ]
        );
    }

    /**
     * Recursively scrub credentials, tokens, and sensitive keys from logged audit payloads.
     */
    private static function sanitizeData(?array $data): ?array
    {
        if ($data === null) {
            return null;
        }

        $sensitiveKeys = [
            'password', 'passwd', 'password_hash', 'secret', 'token', 'access_token',
            'refresh_token', 'api_key', 'api_secret', 'authorization', 'credit_card', 'card_number',
            'cvv', 'cvc', 'pin', 'ssn', 'tax_id', 'auth_token', 'bearer', 'jwt',
            'private_key', 'session_id', 'cookie'
        ];

        $sanitized = [];
        foreach ($data as $key => $value) {
            $keyLower = strtolower((string) $key);
            $isSensitive = false;
            foreach ($sensitiveKeys as $sk) {
                if (str_contains($keyLower, $sk)) {
                    $isSensitive = true;
                    break;
                }
            }

            if ($isSensitive) {
                $sanitized[$key] = '[REDACTED]';
            } elseif (is_array($value)) {
                $sanitized[$key] = self::sanitizeData($value);
            } else {
                $sanitized[$key] = $value;
            }
        }
        return $sanitized;
    }
}
