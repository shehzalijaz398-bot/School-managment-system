# Finance & Fees Module Inspection Report

This document verifies the existing state of all finance-related tables in the database.

### Table: `academic_years`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `name`, `start_date`, `end_date`, `is_active`
- **Status Fields:** `is_active` (tinyint(1))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`

### Table: `classes`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `name`, `numeric_name`, `status`
- **Status Fields:** `status` (tinyint(1))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`

### Table: `employees`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `employee_code`, `first_name`, `last_name`, `email`, `phone`, `gender`, `date_of_birth`, `department_id`, `designation_id`, `employment_type`, `joining_date`, `contract_end_date`, `address`, `emergency_contact`, `status`, ...
- **Status Fields:** `gender` (enum('male','female','other')), `status` (enum('active','inactive','resigned','terminated','on_leave'))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `department_id` -> `departments`.`id`
  - `designation_id` -> `designations`.`id`
  - `school_id` -> `schools`.`id`

### Table: `expenses`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `title`, `category`, `amount`, `expense_date`, `payment_method`, `reference_no`, `notes`, `created_by`
- **Status Fields:** None
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`
  - `created_by` -> `users`.`id`

### Table: `fee_categories`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `name`, `amount`, `frequency`, `status`
- **Status Fields:** `frequency` (enum('one_time','monthly','term','annual')), `status` (tinyint(1))
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`

### Table: `incomes`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `title`, `category`, `amount`, `income_date`, `notes`, `created_by`
- **Status Fields:** None
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`
  - `created_by` -> `users`.`id`

### Table: `parents`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `first_name`, `last_name`, `email`, `phone`, `occupation`, `address`, `relation_label`, `status`
- **Status Fields:** `status` (tinyint(1))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `school_id` -> `schools`.`id`

### Table: `payment_transactions`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `payment_id`, `gateway`, `gateway_reference`, `amount`, `currency`, `status`, `raw_payload`
- **Status Fields:** `status` (varchar(30))
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `payment_id` -> `subscription_payments`.`id`
  - `school_id` -> `schools`.`id`

### Table: `payments`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `invoice_id`, `student_id`, `receipt_no`, `amount`, `payment_method`, `payment_date`, `reference_no`, `notes`, `received_by`
- **Status Fields:** `payment_method` (enum('cash','bank','card','online','cheque'))
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `invoice_id` -> `student_fee_invoices`.`id`
  - `school_id` -> `schools`.`id`
  - `student_id` -> `students`.`id`
  - `received_by` -> `users`.`id`

### Table: `payroll`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `employee_id`, `payroll_month`, `basic_salary`, `allowances`, `bonuses`, `deductions`, `leave_deduction`, `attendance_deduction`, `net_salary`, `status`, `payment_date`, `payment_method`, `notes`, `approved_by`, `created_by`
- **Status Fields:** `status` (enum('draft','pending','approved','paid','cancelled'))
- **Financial Amount Fields:** `basic_salary` (decimal(12,2)), `allowances` (decimal(12,2)), `bonuses` (decimal(12,2)), `deductions` (decimal(12,2)), `leave_deduction` (decimal(12,2)), `attendance_deduction` (decimal(12,2)), `net_salary` (decimal(12,2))
- **Foreign Keys:**
  - `approved_by` -> `users`.`id`
  - `created_by` -> `users`.`id`
  - `employee_id` -> `employees`.`id`
  - `school_id` -> `schools`.`id`

### Table: `payroll_items`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `payroll_id`, `label`, `type`, `amount`
- **Status Fields:** `type` (enum('earning','deduction'))
- **Financial Amount Fields:** `amount` (decimal(12,2))
- **Foreign Keys:**
  - `payroll_id` -> `payroll`.`id`
  - `school_id` -> `schools`.`id`

### Table: `salary_structures`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `employee_id`, `basic_salary`, `house_allowance`, `transport_allowance`, `other_allowance`, `deductions`, `effective_from`, `status`
- **Status Fields:** `status` (tinyint(1))
- **Financial Amount Fields:** `basic_salary` (decimal(12,2)), `house_allowance` (decimal(12,2)), `transport_allowance` (decimal(12,2)), `other_allowance` (decimal(12,2)), `deductions` (decimal(12,2))
- **Foreign Keys:**
  - `employee_id` -> `employees`.`id`
  - `school_id` -> `schools`.`id`

### Table: `sections`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `class_id`, `academic_year_id`, `name`, `capacity`, `class_teacher_id`, `status`
- **Status Fields:** `status` (tinyint(1))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `academic_year_id` -> `academic_years`.`id`
  - `class_id` -> `classes`.`id`
  - `class_teacher_id` -> `teachers`.`id`
  - `school_id` -> `schools`.`id`

### Table: `student_fee_invoice_items`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `invoice_id`, `fee_category_id`, `description`, `amount`
- **Status Fields:** None
- **Financial Amount Fields:** `fee_category_id` (bigint(20) unsigned), `amount` (decimal(12,2))
- **Foreign Keys:**
  - `fee_category_id` -> `fee_categories`.`id`
  - `invoice_id` -> `student_fee_invoices`.`id`
  - `school_id` -> `schools`.`id`

### Table: `student_fee_invoices`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `student_id`, `academic_year_id`, `invoice_no`, `title`, `invoice_date`, `due_date`, `subtotal`, `discount`, `late_fee`, `total_amount`, `paid_amount`, `status`, `notes`, `created_by`
- **Status Fields:** `status` (enum('unpaid','partial','paid','cancelled'))
- **Financial Amount Fields:** `subtotal` (decimal(12,2)), `discount` (decimal(12,2)), `late_fee` (decimal(12,2)), `total_amount` (decimal(12,2)), `paid_amount` (decimal(12,2))
- **Foreign Keys:**
  - `academic_year_id` -> `academic_years`.`id`
  - `school_id` -> `schools`.`id`
  - `student_id` -> `students`.`id`
  - `created_by` -> `users`.`id`

### Table: `students`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `admission_no`, `roll_no`, `first_name`, `last_name`, `gender`, `date_of_birth`, `class_id`, `section_id`, `academic_year_id`, `email`, `phone`, `address`, `admission_date`, `previous_school`, `medical_note`, ...
- **Status Fields:** `gender` (enum('male','female','other')), `status` (enum('active','inactive','graduated','transferred','suspended','withdrawn'))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `academic_year_id` -> `academic_years`.`id`
  - `class_id` -> `classes`.`id`
  - `school_id` -> `schools`.`id`
  - `section_id` -> `sections`.`id`

### Table: `teachers`
- **School/Tenant Column:** `school_id`
- **Important Columns:** `employee_id`, `qualification`, `specialization`, `experience_years`, `status`
- **Status Fields:** `status` (tinyint(1))
- **Financial Amount Fields:** None
- **Foreign Keys:**
  - `employee_id` -> `employees`.`id`
  - `school_id` -> `schools`.`id`

