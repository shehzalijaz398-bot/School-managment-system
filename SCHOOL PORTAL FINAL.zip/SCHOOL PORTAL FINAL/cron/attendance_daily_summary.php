<?php

declare(strict_types=1);

/**
 * Daily Attendance Summary CLI / Cron Task
 *
 * Runs daily at end-of-school (e.g. 15:00) to aggregate attendance compliance and dispatch alerts.
 * Usage:
 *   php cron/attendance_daily_summary.php [--date=YYYY-MM-DD] [--school_id=4]
 */

require_once dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\AttendanceSummaryService;
use Core\Database;

$args = array_slice($argv, 1);
$date = date('Y-m-d');
$targetSchoolId = null;

foreach ($args as $arg) {
    if (str_starts_with($arg, '--date=')) {
        $date = substr($arg, 7);
    }
    if (str_starts_with($arg, '--school_id=')) {
        $targetSchoolId = (int) substr($arg, 12);
    }
}

echo "\n" . str_repeat('=', 80) . "\n";
echo "  DAILY ATTENDANCE SUMMARY & COMPLIANCE RUNNER (Date: {$date})\n";
echo str_repeat('=', 80) . "\n\n";

$service = new AttendanceSummaryService();

if ($targetSchoolId !== null) {
    $schools = [['id' => $targetSchoolId]];
} else {
    $schools = Database::fetchAll("SELECT id, name FROM schools WHERE status = 1 OR status = 'active'");
}

foreach ($schools as $sch) {
    $schId = (int)$sch['id'];
    $summary = $service->generateDailySummary($schId, $date);
    $stdPct = $summary['student_attendance']['percentage'];
    $unsubCount = count($summary['unsubmitted_sections']);
    $lowCount = count($summary['low_attendance_classes']);
    echo "  [School ID {$schId}] Student Att: {$stdPct}% | Unsubmitted Sections: {$unsubCount} | Low Attendance Classes: {$lowCount}\n";
}

echo "\n" . str_repeat('=', 80) . "\n\n";
