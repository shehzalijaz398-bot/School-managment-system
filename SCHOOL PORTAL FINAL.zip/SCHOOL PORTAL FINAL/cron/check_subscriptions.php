<?php

declare(strict_types=1);

/**
 * Cron: sync expired subscriptions / trials
 * php cron/check_subscriptions.php
 */

require dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\Platform\SubscriptionService;
use Core\Database;

$lock = dirname(__DIR__) . '/storage/locks/check_subscriptions.lock';
@mkdir(dirname($lock), 0775, true);
$fp = fopen($lock, 'c');
if (!$fp || !flock($fp, LOCK_EX | LOCK_NB)) {
    echo "Already running\n";
    exit(0);
}

$n = SubscriptionService::syncExpired();
Database::insert(
    'INSERT INTO platform_audit_logs (actor_id, actor_type, action, module, school_id, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at)
     VALUES (NULL, ?, ?, ?, NULL, ?, NULL, NULL, ?, NULL, NULL, NOW())',
    ['system', 'cron.check_subscriptions', 'cron', 'job', json_encode(['expired' => $n])]
);

echo date('c') . " Expired/synced: {$n}\n";
flock($fp, LOCK_UN);
fclose($fp);
