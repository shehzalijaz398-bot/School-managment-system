<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\MessageQueueService;
use Core\Database;

try {
    $currentDay = (int) date('j');
    $schools = Database::fetchAll('SELECT id, name, fee_due_day FROM schools WHERE status = 1 AND deleted_at IS NULL');
    $queueService = new MessageQueueService();
    $totalWarningsSent = 0;

    foreach ($schools as $school) {
        $schoolId = (int) $school['id'];
        $feeDueDay = (int) ($school['fee_due_day'] ?? 7);

        // Check if current day is past the monthly fee due day
        if ($currentDay <= $feeDueDay) {
            continue;
        }

        $limit = 500;
        $offset = 0;

        while (true) {
            $invoices = Database::fetchAll(
                "SELECT i.id, i.invoice_no, i.student_id, i.total_amount, i.paid_amount,
                        s.first_name, s.last_name, s.phone AS student_phone
                 FROM student_fee_invoices i
                 INNER JOIN students s ON s.id = i.student_id AND s.school_id = i.school_id
                 WHERE i.school_id = ? 
                   AND i.status IN ('unpaid', 'partial') 
                   AND (i.last_warning_sent_at IS NULL OR i.last_warning_sent_at < DATE_SUB(NOW(), INTERVAL 24 HOUR))
                 ORDER BY i.id ASC LIMIT ? OFFSET ?",
                [$schoolId, $limit, $offset]
            );

            if (empty($invoices)) {
                break;
            }

            Database::beginTransaction();
            try {
                foreach ($invoices as $invoice) {
                    $invoiceId = (int) $invoice['id'];
                    $studentId = (int) $invoice['student_id'];
                    $balance = (float) $invoice['total_amount'] - (float) $invoice['paid_amount'];
                    $studentName = trim("{$invoice['first_name']} {$invoice['last_name']}");
                    
                    $message = "⚠️ OVERDUE FEE ALERT: Outstanding tuition balance for {$studentName} is $" . number_format($balance, 2) . " (Due Day: {$feeDueDay}th). Please settle immediately via the portal.";

                    Database::execute(
                        "INSERT INTO student_warnings (school_id, student_id, invoice_id, message, is_read, created_at) 
                         VALUES (?, ?, ?, ?, 0, NOW())",
                        [$schoolId, $studentId, $invoiceId, $message]
                    );

                    Database::execute(
                        "UPDATE student_fee_invoices SET last_warning_sent_at = NOW() WHERE id = ? AND school_id = ?",
                        [$invoiceId, $schoolId]
                    );

                    // Look up parent phone contact
                    $parent = Database::fetch(
                        'SELECT p.phone, p.first_name, p.last_name 
                         FROM student_parents sp
                         JOIN parents p ON p.id = sp.parent_id AND p.school_id = sp.school_id
                         WHERE sp.student_id = ? AND sp.school_id = ? LIMIT 1',
                        [$studentId, $schoolId]
                    );

                    $targetPhone = !empty($parent['phone']) ? $parent['phone'] : ($invoice['student_phone'] ?? null);

                    if (!empty($targetPhone)) {
                        $parentName = $parent ? trim("{$parent['first_name']} {$parent['last_name']}") : $studentName;
                        $queueService->enqueue(
                            schoolId: $schoolId,
                            channel: 'whatsapp',
                            recipient: $targetPhone,
                            payload: [
                                'body' => $message,
                                'template' => 'fee_due_warning',
                                'parameters' => [
                                    $parentName,
                                    '$' . number_format($balance, 2),
                                    date('Y-m-' . sprintf('%02d', $feeDueDay))
                                ],
                            ],
                            messageType: 'fee_reminder',
                            priority: MessageQueueService::PRIORITY_BULK,
                            recipientName: $parentName,
                            recipientId: $studentId,
                            recipientType: 'parent'
                        );
                    }

                    $totalWarningsSent++;
                }
                Database::commit();
            } catch (\Throwable $e) {
                Database::rollBack();
                error_log("Failed to process warnings for school {$schoolId}: " . $e->getMessage());
            }

            $offset += $limit;
            usleep(50000); 
        }
    }
    echo "Fee due warnings processed successfully. Generated and queued {$totalWarningsSent} alert(s).\n";
} catch (\Throwable $ex) {
    error_log("Cron Fee Due Warnings Error: " . $ex->getMessage());
    echo "Error processing fee due warnings: " . $ex->getMessage() . "\n";
    exit(1);
}
