<?php

declare(strict_types=1);

/**
 * Cron: expiry / renewal reminder notifications
 * php cron/send_expiry_notifications.php
 */

require dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\Platform\SubscriptionService;
use Core\Database;

$lock = dirname(__DIR__) . '/storage/locks/send_expiry_notifications.lock';
@mkdir(dirname($lock), 0775, true);
$fp = fopen($lock, 'c');
if (!$fp || !flock($fp, LOCK_EX | LOCK_NB)) {
    echo "Already running\n";
    exit(0);
}

$windows = [7, 15, 30];
$sent = 0;
foreach ($windows as $days) {
    foreach (SubscriptionService::expiringWithin($days) as $school) {
        $title = "Subscription expiring in {$days} days";
        $exists = Database::fetch(
            'SELECT id FROM platform_notifications
             WHERE school_id = ? AND type = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY) LIMIT 1',
            [(int) $school['id'], 'subscription.expiring.' . $days]
        );
        if ($exists) {
            continue;
        }
        Database::insert(
            'INSERT INTO platform_notifications (user_id, school_id, type, title, message, is_read, created_at)
             VALUES (NULL, ?, ?, ?, ?, 0, NOW())',
            [
                (int) $school['id'],
                'subscription.expiring.' . $days,
                $title,
                ($school['name'] ?? 'School') . ' (' . ($school['code'] ?? '') . ') expires on ' . ($school['subscription_ends_at'] ?? ''),
            ]
        );
        // School-side notification to admins
        $admins = Database::fetchAll(
            'SELECT u.id FROM users u INNER JOIN roles r ON r.id = u.role_id
             WHERE u.school_id = ? AND r.slug IN ("school_admin","principal") AND u.status = 1',
            [(int) $school['id']]
        );
        foreach ($admins as $a) {
            Database::insert(
                'INSERT INTO notifications (school_id, user_id, type, title, message, is_read, created_at)
                 VALUES (?, ?, ?, ?, ?, 0, NOW())',
                [
                    (int) $school['id'],
                    (int) $a['id'],
                    'subscription.expiring',
                    $title,
                    'Please renew your school subscription before ' . ($school['subscription_ends_at'] ?? 'expiry') . '.',
                ]
            );
        }
        $sent++;
    }
}

echo date('c') . " Expiry notifications created: {$sent}\n";
flock($fp, LOCK_UN);
fclose($fp);
