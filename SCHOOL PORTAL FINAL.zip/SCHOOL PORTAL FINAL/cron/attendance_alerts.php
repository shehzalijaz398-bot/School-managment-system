<?php

declare(strict_types=1);

/**
 * Automated Attendance Alerts & Daily Digest Dispatcher
 * Scheduled daily (e.g. 10:30 AM) to alert parents of unexcused absences
 * and summarize institutional attendance metrics for school leadership.
 */

require_once dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\AttendanceService;
use Core\Database;

$today = date('Y-m-d');
$attendanceService = new AttendanceService();

echo "===============================================================================\n";
echo "  SCHOOL PORTAL — AUTOMATED ATTENDANCE ALERTS CRON\n";
echo "  Execution Date: {$today} " . date('H:i:s') . "\n";
echo "===============================================================================\n";

$schools = Database::fetchAll('SELECT id, name FROM schools WHERE status = 1 AND deleted_at IS NULL');
$totalAlertsSent = 0;
$totalDigestsSent = 0;

foreach ($schools as $school) {
    $schoolId = (int) $school['id'];
    $schoolName = $school['name'];

    // 1. Fetch today's unnotified absent students
    $absentStudents = Database::fetchAll(
        'SELECT sa.student_id, sa.class_id, sa.attendance_date, s.first_name, s.last_name
         FROM student_attendance sa
         JOIN students s ON s.id = sa.student_id
         WHERE sa.school_id = ? AND sa.attendance_date = ? AND sa.status = "absent"',
        [$schoolId, $today]
    );

    $schoolAlerts = 0;
    foreach ($absentStudents as $absent) {
        $sent = $attendanceService->dispatchAbsenceAlert(
            $schoolId,
            (int) $absent['student_id'],
            (int) $absent['class_id'],
            $today
        );
        $schoolAlerts += $sent;
    }
    $totalAlertsSent += $schoolAlerts;

    // 2. Compute attendance summary for school leadership
    $summary = Database::fetch(
        'SELECT 
            COUNT(*) AS total_marked,
            SUM(CASE WHEN status = "present" THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN status = "absent" THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN status = "late" THEN 1 ELSE 0 END) AS late_count,
            SUM(CASE WHEN status = "half_day" THEN 1 ELSE 0 END) AS half_day_count
         FROM student_attendance
         WHERE school_id = ? AND attendance_date = ?',
        [$schoolId, $today]
    );

    $totalMarked = (int) ($summary['total_marked'] ?? 0);
    if ($totalMarked > 0) {
        $present = (int) ($summary['present_count'] ?? 0);
        $absent = (int) ($summary['absent_count'] ?? 0);
        $late = (int) ($summary['late_count'] ?? 0);
        $rate = round((($present + $late) / $totalMarked) * 100, 1);

        // Fetch school administrators
        $admins = Database::fetchAll(
            'SELECT u.id FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.school_id = ? AND r.slug IN ("admin", "super_admin", "school_admin") AND u.status = 1',
            [$schoolId]
        );

        $digestTitle = "📊 Daily Attendance Digest: {$rate}% ({$present}/{$totalMarked})";
        $digestMsg = "Today's Attendance for {$schoolName}: {$present} Present, {$absent} Absent, {$late} Late ({$rate}% attendance rate across {$totalMarked} students).";

        foreach ($admins as $admin) {
            $adminUserId = (int) $admin['id'];
            // Prevent duplicate digest on same day
            $dupDigest = Database::fetch(
                'SELECT id FROM notifications WHERE school_id = ? AND user_id = ? AND type = "attendance.digest" AND DATE(created_at) = CURDATE() LIMIT 1',
                [$schoolId, $adminUserId]
            );
            if (!$dupDigest) {
                Database::insert(
                    'INSERT INTO notifications (school_id, user_id, type, title, message, entity_type, entity_id, link, is_read, created_at)
                     VALUES (?, ?, "attendance.digest", ?, ?, "attendance", 0, "attendance/students", 0, NOW())',
                    [$schoolId, $adminUserId, $digestTitle, $digestMsg]
                );
                $totalDigestsSent++;
            }
        }
    }

    echo "  [Tenant #{$schoolId}] {$schoolName}: {$schoolAlerts} parent alerts, " . ($totalMarked > 0 ? "{$totalMarked} students logged ({$rate}%)" : "No attendance marked yet") . "\n";
}

echo "-------------------------------------------------------------------------------\n";
echo "  SUMMARY: {$totalAlertsSent} parent alerts dispatched, {$totalDigestsSent} admin digests delivered.\n";
echo "===============================================================================\n";
