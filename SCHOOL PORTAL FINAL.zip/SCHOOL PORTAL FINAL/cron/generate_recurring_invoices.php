<?php

declare(strict_types=1);

/**
 * Automated Recurring Fee Billing CLI / Cron Task
 *
 * Runs monthly to generate recurring fee invoices for all active institutions.
 * Usage:
 *   php cron/generate_recurring_invoices.php [--month=YYYY-MM] [--school_id=4]
 */

require_once dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\AutomatedBillingService;
use Core\Database;

$args = array_slice($argv, 1);
$month = date('Y-m'); // Default current month
$targetSchoolId = null;

foreach ($args as $arg) {
    if (str_starts_with($arg, '--month=')) {
        $month = substr($arg, 8);
    }
    if (str_starts_with($arg, '--school_id=')) {
        $targetSchoolId = (int) substr($arg, 12);
    }
}

echo "\n" . str_repeat('=', 80) . "\n";
echo "  AUTOMATED RECURRING FEE BILLING RUNNER (Billing Month: {$month})\n";
echo str_repeat('=', 80) . "\n\n";

$service = new AutomatedBillingService();

if ($targetSchoolId !== null) {
    $schools = [['id' => $targetSchoolId]];
} else {
    $schools = Database::fetchAll("SELECT id, name FROM schools WHERE status = 1 OR status = 'active'");
}

$grandTotalInvoices = 0;
$grandTotalAmount = 0.0;

foreach ($schools as $sch) {
    $schId = (int)$sch['id'];
    $result = $service->generateRecurringInvoices($schId, $month);
    echo "  [School ID {$schId}] " . ($result['message'] ?? 'Processed.') . "\n";
    $grandTotalInvoices += (int)($result['invoices_created'] ?? 0);
    $grandTotalAmount += (float)($result['total_billed'] ?? 0);
}

echo "\n--------------------------------------------------------------------------------\n";
echo "  RUN COMPLETE: {$grandTotalInvoices} total invoices generated, Total Billed: " . formatMoney($grandTotalAmount) . "\n";
echo str_repeat('=', 80) . "\n\n";
