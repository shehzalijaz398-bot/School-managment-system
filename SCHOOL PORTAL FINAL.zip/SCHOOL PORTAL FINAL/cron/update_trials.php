<?php

declare(strict_types=1);

/**
 * Cron: expire trials that passed trial_ends_at
 * php cron/update_trials.php
 */

require dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\Platform\TenantService;
use Core\Database;

$lock = dirname(__DIR__) . '/storage/locks/update_trials.lock';
@mkdir(dirname($lock), 0775, true);
$fp = fopen($lock, 'c');
if (!$fp || !flock($fp, LOCK_EX | LOCK_NB)) {
    echo "Already running\n";
    exit(0);
}

$rows = Database::fetchAll(
    'SELECT id FROM schools
     WHERE deleted_at IS NULL
       AND subscription_status = ?
       AND trial_ends_at IS NOT NULL
       AND trial_ends_at < NOW()',
    ['trial']
);

$n = 0;
foreach ($rows as $r) {
    TenantService::setStatus((int) $r['id'], 'expired', 0);
    Database::execute(
        'UPDATE subscriptions SET status = ?, updated_at = NOW() WHERE school_id = ? AND status = ?',
        ['expired', (int) $r['id'], 'trial']
    );
    $n++;
}

echo date('c') . " Trials expired: {$n}\n";
flock($fp, LOCK_UN);
fclose($fp);
