<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/core/bootstrap.php';

use Core\Database;

$dbConfig = require dirname(__DIR__) . '/config/database.php';
$dbHost = $dbConfig['host'] ?? '127.0.0.1';
$dbPort = (int) ($dbConfig['port'] ?? 3306);
$dbUser = $dbConfig['username'] ?? 'root';
$dbPass = $dbConfig['password'] ?? '';
$dbName = $dbConfig['database'] ?? 'school_portal';

$backupDir = dirname(__DIR__) . '/storage/backups';
if (!is_dir($backupDir)) {
    @mkdir($backupDir, 0755, true);
}

Database::execute("
    CREATE TABLE IF NOT EXISTS platform_backups (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        file_name VARCHAR(255) NOT NULL,
        file_size BIGINT NOT NULL DEFAULT 0,
        status VARCHAR(50) NOT NULL DEFAULT 'completed',
        storage_location VARCHAR(50) NOT NULL DEFAULT 'local',
        created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$timestamp = date('Ymd_His');
$sqlFile = $backupDir . '/sys_state_' . $timestamp . '.sql';
$gzFile = $sqlFile . '.gz';
$encFile = $gzFile . '.enc';

// 1. Attempt native mysqldump execution (check common binary locations)
$mysqldumpBin = 'mysqldump';
if (file_exists('C:/xampp/mysql/bin/mysqldump.exe')) {
    $mysqldumpBin = '"C:\\xampp\\mysql\\bin\\mysqldump.exe"';
}

$portArg = $dbPort ? " -P {$dbPort}" : '';
$passArg = $dbPass !== '' ? ' -p' . escapeshellarg($dbPass) : '';
$cmd = "{$mysqldumpBin} -h " . escapeshellarg($dbHost) . "{$portArg} -u " . escapeshellarg($dbUser) . "{$passArg} " . escapeshellarg($dbName) . " > " . escapeshellarg($sqlFile);

@exec($cmd);

// 2. Pure PHP PDO Fallback Dumper if mysqldump output is missing or empty
if (!file_exists($sqlFile) || filesize($sqlFile) < 100) {
    $pdo = Database::connection();
    $dumpHandle = fopen($sqlFile, 'w');
    if ($dumpHandle) {
        fwrite($dumpHandle, "-- CodeClove High-Availability Database Snapshot\n");
        fwrite($dumpHandle, "-- Generated at: " . date('Y-m-d H:i:s') . "\n");
        fwrite($dumpHandle, "SET FOREIGN_KEY_CHECKS=0;\n\n");

        $tables = $pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            // Skip backup tracking table itself
            if ($table === 'platform_backups') {
                continue;
            }

            $createTable = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch();
            if ($createTable && isset($createTable['Create Table'])) {
                fwrite($dumpHandle, "DROP TABLE IF EXISTS `{$table}`;\n");
                fwrite($dumpHandle, $createTable['Create Table'] . ";\n\n");
            }

            $rows = $pdo->query("SELECT * FROM `{$table}`")->fetchAll(\PDO::FETCH_ASSOC);
            if (!empty($rows)) {
                $cols = array_keys($rows[0]);
                $colNames = implode('`, `', $cols);

                foreach (array_chunk($rows, 100) as $chunk) {
                    $insertValues = [];
                    foreach ($chunk as $row) {
                        $escaped = array_map(function ($val) use ($pdo) {
                            return $val === null ? 'NULL' : $pdo->quote((string) $val);
                        }, array_values($row));
                        $insertValues[] = '(' . implode(', ', $escaped) . ')';
                    }
                    fwrite($dumpHandle, "INSERT INTO `{$table}` (`{$colNames}`) VALUES \n" . implode(",\n", $insertValues) . ";\n\n");
                }
            }
        }

        fwrite($dumpHandle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($dumpHandle);
    }
}

// 3. GZIP Compression
$sqlContent = file_get_contents($sqlFile);
$gzData = gzencode($sqlContent ?: '-- EMPTY ARCHIVE', 9);
file_put_contents($gzFile, $gzData);
unlink($sqlFile); // cleanup uncompressed SQL

// 4. AES-256-CBC Encryption
$encryptionKey = backup_encryption_key();
$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
$encrypted = openssl_encrypt(file_get_contents($gzFile), 'aes-256-cbc', $encryptionKey, 0, $iv);
file_put_contents($encFile, $iv . $encrypted);
unlink($gzFile); // cleanup plaintext gzip

$size = filesize($encFile);
$finalFileName = basename($encFile);

// Register snapshot in ledger
Database::insert(
    "INSERT INTO platform_backups (file_name, file_size, status, storage_location, created_at)
     VALUES (?, ?, 'completed', 'encrypted_vault', NOW())",
    [$finalFileName, $size]
);

// 5. Auto-Purge Logic: Cleanup backups older than 30 days
$oldBackups = Database::fetchAll(
    "SELECT id, file_name FROM platform_backups WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
);

foreach ($oldBackups as $old) {
    $oldPath = $backupDir . '/' . $old['file_name'];
    if (file_exists($oldPath)) {
        @unlink($oldPath);
    }
    Database::execute("DELETE FROM platform_backups WHERE id = ?", [$old['id']]);
}

echo "Engine Success: Snapshot {$finalFileName} ({$size} bytes) processed and secured in AES vault.\n";
