<?php

declare(strict_types=1);

/**
 * CLI Automation Runner
 * Usage: php cron/run_automations.php [school_id]
 */

require_once dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\AutomationRuleEngine;
use Core\Database;

echo "[" . date('Y-m-d H:i:s') . "] Starting Enterprise Automation Rules Engine...\n";

$engine = new AutomationRuleEngine();

$targetSchool = isset($argv[1]) ? (int) $argv[1] : null;

if ($targetSchool) {
    $schools = [['id' => $targetSchool, 'name' => "Tenant #{$targetSchool}"]];
} else {
    $schools = Database::fetchAll("SELECT id, name FROM schools WHERE status = 'active'");
}

$grandTotal = 0;

foreach ($schools as $s) {
    $schoolId = (int) $s['id'];
    echo "  -> Processing Tenant: {$s['name']} (ID: {$schoolId})...\n";
    $result = $engine->runScheduledAutomations($schoolId);
    echo "     * Fee Reminders: {$result['fee_reminders_sent']}\n";
    echo "     * Truancy Alerts: {$result['truancy_alerts_sent']}\n";
    echo "     * Leave Escalations: {$result['leave_escalations_sent']}\n";
    $grandTotal += $result['total_actions'];
}

echo "[" . date('Y-m-d H:i:s') . "] Automation Cycle Completed. Total Actions Executed: {$grandTotal}\n";
exit(0);
