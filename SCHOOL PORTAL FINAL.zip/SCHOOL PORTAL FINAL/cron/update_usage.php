<?php

declare(strict_types=1);

/**
 * Cron: refresh per-tenant usage snapshots
 * php cron/update_usage.php
 */

require dirname(__DIR__) . '/core/bootstrap.php';

use App\Services\Platform\UsageService;

$lock = dirname(__DIR__) . '/storage/locks/update_usage.lock';
@mkdir(dirname($lock), 0775, true);
$fp = fopen($lock, 'c');
if (!$fp || !flock($fp, LOCK_EX | LOCK_NB)) {
    echo "Already running\n";
    exit(0);
}

UsageService::snapshot();
echo date('c') . " Usage snapshots updated\n";
flock($fp, LOCK_UN);
fclose($fp);
